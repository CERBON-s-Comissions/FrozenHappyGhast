package com.blackgear.vanillabackport.client.resource;

import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.mojang.logging.LogUtils;
import java.io.IOException;
import java.io.Reader;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.class_2960;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_3695;
import net.minecraft.class_4080;
import net.minecraft.class_7654;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DynamicOps;
import com.mojang.serialization.JsonOps;
import org.slf4j.Logger;

public abstract class SimpleJsonResourceReloadListener<T> extends class_4080<Map<class_2960, T>> {
	private static final Logger LOGGER = LogUtils.getLogger();
	private final DynamicOps<JsonElement> ops;
	private final Codec<T> codec;
	private final class_7654 lister;
	
	protected SimpleJsonResourceReloadListener(Codec<T> codec, class_7654 lister) {
		this(JsonOps.INSTANCE, codec, lister);
	}
	
	protected SimpleJsonResourceReloadListener(DynamicOps<JsonElement> ops, Codec<T> codec, class_7654 lister) {
		this.ops = ops;
		this.codec = codec;
		this.lister = lister;
	}
	
	@Override
	protected Map<class_2960, T> method_18789(class_3300 manager, class_3695 profiler) {
		Map<class_2960, T> result = new HashMap<>();

		for (Entry<class_2960, class_3298> entry : this.lister.method_45113(manager).entrySet()) {
			class_2960 location = entry.getKey();
			class_2960 id = this.lister.method_45115(location);

			try {
				Reader reader = entry.getValue().method_43039();

				try {
					this.codec.parse(this.ops, StrictJsonParser.parse(reader)).ifSuccess(parsed -> {
						if (result.putIfAbsent(id, parsed) != null) {
							throw new IllegalStateException("Duplicate data file ignored with ID " + id);
						}
					}).ifError(error -> LOGGER.error("Couldn't parse data file '{}' from '{}': {}", id, location, error));
				} catch (Throwable throwable) {
					if (reader != null) {
						try {
							reader.close();
						} catch (Throwable throwablex) {
							throwable.addSuppressed(throwablex);
						}
					}

					throw throwable;
				}

				if (reader != null) {
					reader.close();
				}
			} catch (IllegalArgumentException | IOException | JsonParseException exception) {
				LOGGER.error("Couldn't parse data file {} from {}", id, location, exception);
			}
		}
		
		return result;
	}
}
