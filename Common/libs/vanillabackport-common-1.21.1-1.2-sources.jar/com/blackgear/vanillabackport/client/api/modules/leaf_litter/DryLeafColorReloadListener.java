package com.blackgear.vanillabackport.client.api.modules.leaf_litter;

import com.blackgear.platform.common.resource.RegistryAwareJsonReloadListener;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DynamicOps;
import com.mojang.serialization.JsonOps;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.class_1959;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_3695;
import net.minecraft.class_5455;
import net.minecraft.class_6880;
import net.minecraft.class_6885;
import net.minecraft.class_6895;
import net.minecraft.class_6903;
import net.minecraft.class_7924;

public class DryLeafColorReloadListener extends RegistryAwareJsonReloadListener {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    private static final List<Entry> ENTRIES = new CopyOnWriteArrayList<>();
    public static final DryLeafColorReloadListener INSTANCE = new DryLeafColorReloadListener();
    
    public DryLeafColorReloadListener() {
        super(GSON, "dry_foliage_colors");
    }
    
    @Override
    public void parse(Map<class_2960, JsonElement> map, class_5455 registryAccess, class_3300 resourceManager, class_3695 profilerFiller) {
        DynamicOps<JsonElement> ops = class_6903.method_46632(JsonOps.INSTANCE, registryAccess);
        
        List<Entry> loadedEntries = map.entrySet().stream()
            .map(entry -> Entry.CODEC.parse(ops, entry.getValue())
                .resultOrPartial(error -> VanillaBackport.LOGGER.error("Failed to parse dry foliage color {}: {}", entry.getKey(), error))
            )
            .flatMap(Optional::stream)
            .sorted(Comparator.comparingInt(Entry::priority).reversed())
            .toList();
        
        ENTRIES.clear();
        ENTRIES.addAll(loadedEntries);
        
        if (!ENTRIES.isEmpty()) {
            VanillaBackport.LOGGER.info("Loaded {} custom dry foliage color rule(s)", ENTRIES.size());
        }
    }
    
    public static OptionalInt getColorForBiome(class_6880<class_1959> biome) {
        for (Entry entry : ENTRIES) {
            if (entry.biomes().method_40241(biome)) {
                return OptionalInt.of(entry.color());
            }
        }
        
        return OptionalInt.empty();
    }
    
    public record Entry(class_6885<class_1959> biomes, int color, int priority) {
        public static final Codec<Entry> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            class_6895.method_40340(class_7924.field_41236).fieldOf("biome").forGetter(Entry::biomes),
            Codec.INT.fieldOf("color").forGetter(Entry::color),
            Codec.INT.optionalFieldOf("priority", 0).forGetter(Entry::priority)
        ).apply(instance, Entry::new));
    }
}