package com.blackgear.vanillabackport.client.api.experiment;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import org.joml.Matrix4f;

@Environment(EnvType.CLIENT)
public class EnvironmentalFogRenderer {
    public static void renderFog(
            class_4587 poseStack,
            float fogStart, float fogEnd, float fogHeight,
            float r, float g, float b, int fogAlpha,
            int numShells, int subdivisions
    ) {
        for (int s = numShells; s >= 1; s--) {
            float t = (float) s / numShells;

            float radius = fogStart + t * (fogEnd - fogStart);

            float smooth = t * t * (3.0f - 2.0f * t);
            int shellAlpha = (int) (fogAlpha * smooth);

            shellAlpha = Math.clamp(shellAlpha, 0, 255);

            renderCylinderShell(poseStack, radius, fogHeight, subdivisions, r, g, b, shellAlpha);
        }
    }

    private static void renderCylinderShell(
            class_4587 poseStack,
            float radius, float fogHeight,
            int subdivisions,
            float r, float g, float b, int currentAlpha
    ) {
        RenderSystem.setShader(class_757::method_34540);

        class_287 buffer = class_289.method_1348().method_60827(
                class_293.class_5596.field_27380,
                class_290.field_1576
        );

        Matrix4f matrix = poseStack.method_23760().method_23761();
        int verticalBands = Math.max(4, subdivisions / 2);

        for (int v = 0; v < verticalBands; v++) {
            float y0 = fogHeight * (-1.0f + 2.0f * v / verticalBands);
            float y1 = fogHeight * (-1.0f + 2.0f * (v + 1) / verticalBands);

            float t0 = Math.abs(y0 / fogHeight);
            float t1 = Math.abs(y1 / fogHeight);

            float hf0 = (float) Math.pow(Math.cos(t0 * Math.PI * 0.5), 8.0);
            float hf1 = (float) Math.pow(Math.cos(t1 * Math.PI * 0.5), 8.0);

            int a0 = Math.min(255, (int) (currentAlpha * hf0));
            int a1 = Math.min(255, (int) (currentAlpha * hf1));

            for (int j = 0; j <= subdivisions; j++) {
                float angle = (float) (2.0 * Math.PI * j / subdivisions);
                float x = (float) Math.cos(angle) * radius;
                float z = (float) Math.sin(angle) * radius;

                buffer.method_22918(matrix, x, y0, z).method_22915(r, g, b, a0);
                buffer.method_22918(matrix, x, y1, z).method_22915(r, g, b, a1);
            }
        }

        class_286.method_43433(buffer.method_60800());
    }
}