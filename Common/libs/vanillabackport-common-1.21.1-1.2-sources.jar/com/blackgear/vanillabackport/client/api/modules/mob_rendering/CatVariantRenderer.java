package com.blackgear.vanillabackport.client.api.modules.mob_rendering;

import com.blackgear.vanillabackport.common.api.modules.mob_variant.VariantDataHolder;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.cat.CatDataVariant;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1451;
import net.minecraft.class_2960;
import net.minecraft.class_3680;
import java.util.Optional;

@Environment(EnvType.CLIENT)
public class CatVariantRenderer extends SpecialMobRenderer<class_1451, class_3680<class_1451>> {
    @Override
    public Optional<class_2960> getTexture(class_1451 entity) {
        return VariantDataHolder.<CatDataVariant>getHolder(entity)
            .flatMap(VariantDataHolder::getVariantData)
            .map(variant -> variant.assetInfo().path());
    }

    @Override
    public Optional<class_3680<class_1451>> getModel(class_1451 entity) {
        return Optional.empty();
    }
}