package com.blackgear.vanillabackport.client.api.modules.falling_leaves;

import com.blackgear.vanillabackport.client.registries.ModParticles;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.blackgear.vanillabackport.core.data.tags.ModBlockTags;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2396;
import net.minecraft.class_2680;
import net.minecraft.class_5819;
import net.minecraft.class_5945;
import net.minecraft.class_9381;

@Environment(EnvType.CLIENT)
public class FallingLeavesModule {
    public void makeFallingLeavesParticles(class_1937 level, class_2338 pos, class_5819 random, class_2680 state, class_2338 offset) {
        if (random.method_43057() < VanillaBackport.CLIENT_CONFIG.fallingLeavesFrequency.get()) {
            if (!class_2248.method_9501(state.method_26220(level, offset), class_2350.field_11036)) {
                this.spawnFallingLeavesParticle(level, pos, random);
            }
        }
    }

    private void spawnFallingLeavesParticle(class_1937 level, class_2338 pos, class_5819 random) {
        class_2680 state = level.method_8320(pos);
        if (VanillaBackport.CLIENT_CONFIG.hasFallingLeaves.get()) {
            class_2396<class_9381> particle = null;

            if (state.method_26164(ModBlockTags.SPAWN_FALLING_LEAVES)) {
                particle = ModParticles.TINTED_LEAVES.get();
            } else if (state.method_26164(ModBlockTags.SPAWN_FALLING_NEEDLES)) {
                particle = ModParticles.TINTED_NEEDLES.get();
            }

            if (particle != null) {
                class_9381 option = class_9381.method_58256(particle, LeafColors.getClientLeafTintColor(pos));
                class_5945.method_49099(level, pos, random, option);
            }
        }
    }
}