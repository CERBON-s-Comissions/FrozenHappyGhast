package com.blackgear.vanillabackport.client.api.modules.music_toast;

import net.minecraft.class_368;
import net.minecraft.class_374;

public interface ToastModifier {
    ToastModifier DEFAULT = new ToastModifier() {};
    
    static ToastModifier of(class_368 toast) {
        return toast instanceof ToastModifier modifier ? modifier : DEFAULT;
    }
    
    default class_368.class_369 getWantedVisibility() {
        return class_368.class_369.field_2209;
    }
    
    default void update(class_374 component, long fullyVisibleForMs) { /* NO-OP */ }
    
    default float xPos(int screenWidth, float visiblePortion) {
        return 0.0F;
    }
    
    default float yPos(int firstSlotIndex) {
        return 0.0F;
    }
    
    default void onFinishedRendering() { /* NO-OP */ }
}