package com.blackgear.vanillabackport.client.api.modules.waypoints;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_5699;
import java.util.List;

@Environment(EnvType.CLIENT)
public record WaypointStyle(int nearDistance, int farDistance, List<class_2960> sprites, List<class_2960> spriteLocations) {
    private static final Codec<Integer> DISTANCE_CODEC = Codec.intRange(0, 60000000);
    public static final Codec<WaypointStyle> CODEC = RecordCodecBuilder.<WaypointStyle>create(instance -> instance.group(
        DISTANCE_CODEC.optionalFieldOf("near_distance", 128).forGetter(WaypointStyle::nearDistance),
        DISTANCE_CODEC.optionalFieldOf("far_distance", 332).forGetter(WaypointStyle::farDistance),
        class_5699.method_36973(class_2960.field_25139.listOf()).fieldOf("sprites").forGetter(WaypointStyle::sprites)
    ).apply(instance, WaypointStyle::new)).validate(WaypointStyle::validate);
    
    
    public WaypointStyle(int nearDistance, int farDistance, List<class_2960> sprites) {
        this(nearDistance, farDistance, sprites, sprites.stream().map(sprite -> sprite.method_45138("textures/gui/sprites/hud/locator_bar_dot/").method_48331(".png")).toList());
    }
    
    public DataResult<WaypointStyle> validate() {
        if (this.sprites.isEmpty()) {
            return DataResult.error(() -> "Must have at least one sprite icon");
        } else if (this.nearDistance <= 0) {
            return DataResult.error(() -> "Near distance (" + this.nearDistance + ") must be greater than zero");
        } else {
            return this.nearDistance >= this.farDistance
                ? DataResult.error(() -> "Far distance (" + this.farDistance + ") cannot be closer or equal to near distance (" + this.nearDistance + ")")
                : DataResult.success(this);
        }
    }
    
    public class_2960 sprite(float distance) {
        if (distance < this.nearDistance) {
            return this.spriteLocations.getFirst();
        } else if (distance >= this.farDistance) {
            return this.spriteLocations.getLast();
        } else if (this.spriteLocations.size() == 1) {
            return this.spriteLocations.getFirst();
        } else if (this.spriteLocations.size() == 3) {
            return this.spriteLocations.get(1);
        } else {
            int index = class_3532.method_48781((distance - this.nearDistance) / (this.farDistance - this.nearDistance), 1, this.spriteLocations.size() - 1);
            return this.spriteLocations.get(index);
        }
    }
}
