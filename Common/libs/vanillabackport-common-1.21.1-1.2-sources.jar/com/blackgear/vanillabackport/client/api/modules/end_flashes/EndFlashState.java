package com.blackgear.vanillabackport.client.api.modules.end_flashes;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_3532;
import net.minecraft.class_5819;
import net.minecraft.class_6575;

@Environment(EnvType.CLIENT)
public class EndFlashState {
    public static final int SOUND_DELAY_IN_TICKS = 30;
    private static final int FLASH_INTERVAL_IN_TICKS = 600;
    private static final int MAX_FLASH_OFFSET_IN_TICKS = 200;
    private static final int MIN_FLASH_DURATION_IN_TICKS = 100;
    private static final int MAX_FLASH_DURATION_IN_TICKS = 380;
    private long flashSeed;
    private int offset;
    private int duration;
    private float intensity;
    private float oldIntensity;
    private float xAngle;
    private float yAngle;
    
    public void tick(long clockTime) {
        this.calculateFlashParameters(clockTime);
        this.oldIntensity = this.intensity;
        this.intensity = this.calculateIntensity(clockTime);
    }
    
    private void calculateFlashParameters(long clockTime) {
        long seed = clockTime / FLASH_INTERVAL_IN_TICKS;
        if (seed != this.flashSeed) {
            class_5819 random = new class_6575(seed);
            random.method_43057();
            this.offset = class_3532.method_32751(random, 0, MAX_FLASH_OFFSET_IN_TICKS);
            this.duration = class_3532.method_32751(random, MIN_FLASH_DURATION_IN_TICKS, Math.min(MAX_FLASH_DURATION_IN_TICKS, FLASH_INTERVAL_IN_TICKS - this.offset));
            this.xAngle = class_3532.method_32750(random, -60.0F, 10.0F);
            this.yAngle = class_3532.method_32750(random, -180.0F, 180.0F);
            this.flashSeed = seed;
        }
    }
    
    private float calculateIntensity(long clockTime) {
        long clockTimeWithinInterval = clockTime % FLASH_INTERVAL_IN_TICKS;
        return clockTimeWithinInterval >= this.offset && clockTimeWithinInterval <= this.offset + this.duration
            ? class_3532.method_15374((float) (clockTimeWithinInterval - this.offset) * class_3532.field_29844 / this.duration)
            : 0.0F;
    }
    
    public float getXAngle() {
        return this.xAngle;
    }
    
    public float getYAngle() {
        return this.yAngle;
    }
    
    public float getIntensity(float partialTicks) {
        return class_3532.method_16439(partialTicks, this.oldIntensity, this.intensity);
    }
    
    public boolean isChangingIntensity() {
        return this.oldIntensity != this.intensity;
    }

    public boolean flashStartedThisTick() {
        return this.intensity > 0.0F && this.oldIntensity <= 0.0F;
    }
}