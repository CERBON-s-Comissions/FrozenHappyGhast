package com.blackgear.vanillabackport.client.api.modules.falling_leaves;

import com.blackgear.vanillabackport.client.api.modules.leaf_litter.DryFoliageColor;
import com.blackgear.vanillabackport.client.api.modules.leaf_litter.DryLeafColorReloadListener;
import com.blackgear.vanillabackport.core.mixin.common.access.BiomeAccessor;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1959;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4700;
import net.minecraft.class_638;
import net.minecraft.class_6539;
import net.minecraft.class_6880;
import java.util.OptionalInt;

@Environment(EnvType.CLIENT)
public class LeafColors {
    public static final class_6539 DRY_FOLIAGE_COLOR_RESOLVER = (biome, d, e) -> {
        class_1959.class_5482 settings = ((BiomeAccessor) (Object) biome).getClimateSettings();
        double temperature = class_3532.method_15363(settings.comp_844(), 0.0F, 1.0F);
        double humidity = class_3532.method_15363(settings.comp_846(), 0.0F, 1.0F);
        return DryFoliageColor.get(temperature, humidity);
    };

    public static int getAverageDryFoliageColor(class_2338 pos) {
        class_638 level = class_310.method_1551().field_1687;
        if (level == null) return DryFoliageColor.FOLIAGE_DRY_DEFAULT;
        
        class_6880<class_1959> biome = level.method_23753(pos);
        OptionalInt customColor = DryLeafColorReloadListener.getColorForBiome(biome);
        if (customColor.isPresent()) return customColor.getAsInt();
        
        return new class_4700(value -> level.method_23780(value, DRY_FOLIAGE_COLOR_RESOLVER)).method_23770(pos);
    }

    public static int getClientLeafTintColor(class_2338 pos) {
        class_638 level = class_310.method_1551().field_1687;
        if (level == null) return 0;

        class_2680 state = level.method_8320(pos);
        class_2248 block = state.method_26204();

        if (LeafColorReloadListener.hasCustomColor(block)) {
            return LeafColorReloadListener.getCustomColor(block);
        }

        return class_310.method_1551().method_1505().method_1697(state, level, pos, 0);
    }
}