package com.blackgear.vanillabackport.client.api.modules.mob_rendering;

import com.blackgear.vanillabackport.core.VanillaBackport;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1299;
import net.minecraft.class_1496;
import net.minecraft.class_2960;
import net.minecraft.class_549;
import net.minecraft.class_5617;
import java.util.Optional;

@Environment(EnvType.CLIENT)
public class ZombieHorseRenderer extends SpecialMobRenderer<class_1496, class_549<class_1496>> {
    private static final class_2960 TEXTURE = class_2960.method_60655(VanillaBackport.MOD_ID, "textures/entity/horse/horse_zombie.png");
    
    public ZombieHorseRenderer(class_5617.class_5618 context) { /* NO-OP */ }
    
    @Override
    public Optional<class_2960> getTexture(class_1496 entity) {
        return entity.method_5864() == class_1299.field_6048 ? Optional.of(TEXTURE) : Optional.empty();
    }
    
    @Override
    public Optional<class_549<class_1496>> getModel(class_1496 entity) {
        return Optional.empty();
    }
}