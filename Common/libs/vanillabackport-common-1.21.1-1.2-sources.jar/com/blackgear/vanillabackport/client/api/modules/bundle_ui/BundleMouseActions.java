package com.blackgear.vanillabackport.client.api.modules.bundle_ui;

import com.blackgear.platform.client.event.screen.HudInteractions;
import com.blackgear.platform.core.networking.PayloadDistributor;
import com.blackgear.platform.core.util.event.CancellableResult;
import com.blackgear.vanillabackport.common.api.modules.bundle_ui.BundleFeatures;
import com.blackgear.vanillabackport.core.data.tags.ModItemTags;
import com.blackgear.vanillabackport.core.network.ServerboundSelectBundleItemPacket;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_465;
import org.joml.Vector2i;

@Environment(EnvType.CLIENT)
public class BundleMouseActions implements ItemSlotMouseAction {
    public static final BundleMouseActions INSTANCE = new BundleMouseActions();
    private final ScrollWheelHandler scrollWheelHandler = new ScrollWheelHandler();

    public static void bootstrap() {
        HudInteractions.SCROLLING_PRE.register((minecraft, screen, mouseX, mouseY, deltaX, deltaY) -> {
            if (!BundleFeatures.onBundleUpdate()) return CancellableResult.PASS;

            if (screen instanceof class_465<?> container && container.field_2787 != null) {
                class_1735 slot = container.field_2787;
                if (slot.method_7681() && INSTANCE.matches(slot) && INSTANCE.onMouseScrolled(deltaY, slot.field_7874, slot.method_7677())) {
                    return CancellableResult.CANCEL;
                }
            }
            return CancellableResult.PASS;
        });

        HudInteractions.STOP_HOVERING.register((minecraft, screen, slot) -> {
            if (slot != null && slot.method_7681() && BundleFeatures.onBundleUpdate() && INSTANCE.matches(slot)) {
                INSTANCE.onStopHovering(slot);
            }
        });

        HudInteractions.SLOT_CLICK.register((minecraft, screen, slot, clickType) -> {
            if (slot != null && slot.method_7681() && BundleFeatures.onBundleUpdate() && INSTANCE.matches(slot)) {
                INSTANCE.onSlotClicked(slot, clickType);
            }
        });
    }

    @Override
    public boolean matches(class_1735 slot) {
        return slot.method_7677().method_31573(ModItemTags.BUNDLES);
    }

    @Override
    public boolean onMouseScrolled(double scrollDelta, int slotId, class_1799 stack) {
        int itemsToShow = BundleFeatures.getNumberOfItemsToShow(stack);
        if (itemsToShow == 0) return false;

        Vector2i scroll = this.scrollWheelHandler.onMouseScroll(scrollDelta);
        int delta = scroll.y == 0 ? -scroll.x : scroll.y;

        if (delta != 0) {
            int selectedItem = BundleFeatures.getSelectedItem(stack);
            int selectedItemIndex = ScrollWheelHandler.getNextScrollWheelSelection(delta, selectedItem, itemsToShow);
            if (selectedItem != selectedItemIndex) {
                this.toggleSelectedBundleItem(stack, slotId, selectedItemIndex);
            }
        }
        return true;
    }

    @Override
    public void onStopHovering(class_1735 slot) {
        this.unselectedBundleItem(slot.method_7677(), slot.field_7874);
    }

    @Override
    public void onSlotClicked(class_1735 slot, class_1713 clickType) {
        if (clickType == class_1713.field_7794 || clickType == class_1713.field_7791) {
            this.unselectedBundleItem(slot.method_7677(), slot.field_7874);
        }
    }

    private void toggleSelectedBundleItem(class_1799 stack, int slotId, int selectedItemIndex) {
        if (selectedItemIndex < BundleFeatures.getNumberOfItemsToShow(stack)) {
            BundleFeatures.toggleSelectedItem(stack, selectedItemIndex);
            PayloadDistributor.sendToServer(new ServerboundSelectBundleItemPacket(slotId, selectedItemIndex));
        }
    }

    public void unselectedBundleItem(class_1799 stack, int slotId) {
        this.toggleSelectedBundleItem(stack, slotId, -1);
    }
}