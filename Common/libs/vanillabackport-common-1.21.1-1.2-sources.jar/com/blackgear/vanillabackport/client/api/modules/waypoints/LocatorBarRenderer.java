package com.blackgear.vanillabackport.client.api.modules.waypoints;

import com.blackgear.platform.client.event.screen.hud.HudElementRegistryImpl;
import com.blackgear.platform.client.event.screen.hud.VanillaHudElements;
import com.blackgear.vanillabackport.common.api.modules.waypoints.TrackedWaypoint;
import com.blackgear.vanillabackport.common.api.modules.waypoints.TrackedWaypoint.*;
import com.blackgear.vanillabackport.common.api.modules.waypoints.Waypoint.Icon;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.blackgear.vanillabackport.core.util.Utilities.ColorUtils;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1007;
import net.minecraft.class_1297;
import net.minecraft.class_1316;
import net.minecraft.class_1657;
import net.minecraft.class_1664;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_5253.class_5254;
import net.minecraft.class_640;
import net.minecraft.class_7532;
import net.minecraft.class_8144;
import net.minecraft.class_9779;
import java.util.*;

@Environment(EnvType.CLIENT)
public class LocatorBarRenderer {
    public static final LocatorBarRenderer INSTANCE = new LocatorBarRenderer();
    
    private static final class_2960 LOCATOR_BAR_BACKGROUND = class_2960.method_60656("hud/locator_bar_background");
    private static final class_2960 LOCATOR_BAR_ARROW_UP = class_2960.method_60656("hud/locator_bar_arrow_up");
    private static final class_2960 LOCATOR_BAR_ARROW_DOWN = class_2960.method_60656("hud/locator_bar_arrow_down");
    
    private final class_310 minecraft = class_310.method_1551();
    
    public static void bootstrap() {
        HudElementRegistryImpl.attachElementBefore(
            VanillaHudElements.EXPERIENCE_LEVEL,
            class_2960.method_60656("locator_bar_background"),
            LocatorBarRenderer.INSTANCE::renderBackground
        );
        
        HudElementRegistryImpl.attachElementAfter(
            VanillaHudElements.EXPERIENCE_LEVEL,
            class_2960.method_60656("locator_bar_icons"),
            LocatorBarRenderer.INSTANCE::renderWaypoints
        );
    }
    
    public void renderBackground(class_332 graphics, class_9779 tracker) {
        if (this.shouldSkipRendering()) return;
        if (VanillaBackport.CLIENT_CONFIG.locatorDisplayInfoBar.get() && this.shouldHideBackgroundForHud()) return;
        
        graphics.method_52706(LOCATOR_BAR_BACKGROUND, (this.minecraft.method_22683().method_4486() - 182) / 2, this.minecraft.method_22683().method_4502() - 24 - 5, 182, 5);
    }
    
    public void renderWaypoints(class_332 graphics, class_9779 tracker) {
        if (this.shouldSkipRendering()) return;
        
        class_1297 cameraEntity = this.minecraft.field_1719;
        if (cameraEntity == null) return;
        
        class_1937 level = cameraEntity.method_37908();
        
        int top = this.minecraft.method_22683().method_4502() - 24 - 5;
        int screenMiddle = class_3532.method_15386((graphics.method_51421() - 9) / 2.0F);
        
        ClientWaypointManager.INSTANCE.forEachWaypoint(cameraEntity, waypoint -> {
            if (waypoint.id().left().map(uuid -> uuid.equals(cameraEntity.method_5667())).orElse(false)) return;
            
            double angle = waypoint.yawAngleToCamera(level, (Camera) this.minecraft.field_1773.method_19418());
            if (angle <= -60.0 || angle > 60.0) return;
            
            Icon icon = waypoint.icon();
            WaypointStyle style = WaypointStyleManager.INSTANCE.get(icon.style);
            
            float distance = class_3532.method_15355((float) waypoint.distanceSquared(cameraEntity));
            class_2960 sprite = style.sprite(distance);
            int color = icon.color.orElseGet(() -> waypoint.id().map(
                uuid -> ColorUtils.setBrightness(class_5254.method_58144(255, uuid.hashCode()), 0.9F),
                name -> ColorUtils.setBrightness(class_5254.method_58144(255, name.hashCode()), 0.9F)
            ));
            
            int dotPosition = class_3532.method_15357(angle * 173.0 / 2.0 / 60.0);
            int x = screenMiddle + dotPosition;
            
            boolean isFirstStyleSprite = sprite.equals(style.spriteLocations().getFirst());
            boolean renderedHead = VanillaBackport.CLIENT_CONFIG.locatorDisplayPlayerHeads.get()
                && isFirstStyleSprite
                && renderPlayerHeads(this.minecraft, graphics, x, top - 2, color, waypoint);
            
            if (!renderedHead) {
                graphics.method_51422(class_5254.method_27765(color) / 255.0F, class_5254.method_27766(color) / 255.0F, class_5254.method_27767(color) / 255.0F, class_5254.method_27762(color) / 255.0F);
                graphics.method_25290(sprite, x, top - 2, 0, 0, 9, 9, 9, 9);
                graphics.method_51422(1.0F, 1.0F, 1.0F, 1.0F);
            }
            
            PitchDirection pitchDirection = waypoint.pitchDirectionToCamera(level, (Projector) this.minecraft.field_1773);
            if (pitchDirection != PitchDirection.NONE) {
                class_2960 arrowSprite = (pitchDirection == PitchDirection.DOWN) ? LOCATOR_BAR_ARROW_DOWN : LOCATOR_BAR_ARROW_UP;
                int arrowTop = (pitchDirection == PitchDirection.DOWN) ? 6 : -6;
                
                graphics.method_52706(arrowSprite, x + 1, top + arrowTop, 7, 5);
            }
        });
    }
    
    private boolean willPrioritizeExperienceInfo() {
        if (VanillaBackport.CLIENT_CONFIG.locatorDisplayInfoBar.get()) return false;
        return this.minecraft.field_1724 != null && ExperienceDisplay.of(this.minecraft.field_1724).getExperienceDisplayStartTick() + 100 > this.minecraft.field_1724.field_6012;
    }
    
    private boolean willPrioritizeJumpInfo() {
        if (this.minecraft.field_1724 == null) return false;
        if (VanillaBackport.CLIENT_CONFIG.locatorDisplayInfoBar.get()) return false;
        return this.minecraft.field_1724.method_3151() > 0.0F
            || class_8144.method_49078(this.minecraft.field_1724.method_45773(), class_1316::method_45327, 0) > 0;
    }

    private boolean shouldHideBackgroundForHud() {
        if (this.minecraft.field_1724 == null) return false;
        if (this.minecraft.field_1724.method_45773() != null) return true;
        return this.minecraft.field_1761 != null && this.minecraft.field_1761.method_2913();
    }
    
    private boolean shouldSkipRendering() {
        if (!VanillaBackport.CLIENT_CONFIG.enableLocatorBar.get()) return true;
        if (!ClientWaypointManager.INSTANCE.hasWaypoints()) return true;
        
        if (this.minecraft.field_1724.method_45773() != null) return this.willPrioritizeJumpInfo();
        return this.minecraft.field_1761.method_2913() && this.willPrioritizeExperienceInfo();
    }
    
    private static boolean renderPlayerHeads(class_310 minecraft, class_332 graphics, int x, int y, int color, TrackedWaypoint waypoint) {
        UUID uuid = waypoint.id().left().orElse(null);
        if (uuid == null || minecraft.method_1562() == null) return false;
        
        class_640 info = minecraft.method_1562().method_2871(uuid);
        if (info == null) return false;
        
        int headX = x + 2;
        int headY = y + 2;
        int scale = 5;
        
        graphics.method_25294(headX, headY - 1, headX + scale, headY + scale + 1, color);
        graphics.method_25294(headX - 1, headY, headX + scale + 1, headY + scale, color);
        
        class_1657 player = minecraft.field_1687 != null ? minecraft.field_1687.method_18470(uuid) : null;
        boolean isUpsideDown = player != null && class_1007.method_38563(player);
        boolean showHat = player == null || player.method_7348(class_1664.field_7563);
        
        class_7532.method_44445(graphics, info.method_52810().comp_1626(), headX, headY, scale, showHat, isUpsideDown);
        return true;
    }
}