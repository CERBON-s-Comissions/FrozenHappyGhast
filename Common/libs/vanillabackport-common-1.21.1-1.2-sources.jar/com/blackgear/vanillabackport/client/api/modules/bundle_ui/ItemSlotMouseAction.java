package com.blackgear.vanillabackport.client.api.modules.bundle_ui;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;

@Environment(EnvType.CLIENT)
public interface ItemSlotMouseAction {
    boolean matches(class_1735 slot);

    boolean onMouseScrolled(double scrollDelta, int slotId, class_1799 stack);

    void onStopHovering(class_1735 slot);

    void onSlotClicked(class_1735 slot, class_1713 clickType);
}