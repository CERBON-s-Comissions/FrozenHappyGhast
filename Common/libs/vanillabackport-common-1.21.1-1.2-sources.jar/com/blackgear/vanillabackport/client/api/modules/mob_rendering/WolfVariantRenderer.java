package com.blackgear.vanillabackport.client.api.modules.mob_rendering;

import com.blackgear.vanillabackport.common.api.modules.mob_variant.VariantDataHolder;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.wolf.WolfDataVariant;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1493;
import net.minecraft.class_2960;
import net.minecraft.class_624;
import java.util.Optional;

@Environment(EnvType.CLIENT)
public class WolfVariantRenderer extends SpecialMobRenderer<class_1493, class_624<class_1493>> {
    @Override
    public Optional<class_2960> getTexture(class_1493 entity) {
        return VariantDataHolder.<WolfDataVariant>getHolder(entity)
            .flatMap(VariantDataHolder::getVariantData)
            .map(variant -> {
                var assets = variant.assetInfo();
                var texture = entity.method_6181() ? assets.tame() : (entity.method_29511() ? assets.angry() : assets.wild());
                return texture.path();
            });
    }
    
    @Override
    public Optional<class_624<class_1493>> getModel(class_1493 entity) {
        return Optional.empty();
    }
}