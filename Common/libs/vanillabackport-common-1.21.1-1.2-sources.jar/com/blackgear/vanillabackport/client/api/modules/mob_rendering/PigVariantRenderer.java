package com.blackgear.vanillabackport.client.api.modules.mob_rendering;

import com.blackgear.platform.core.BuiltInCoreRegistry;
import com.blackgear.platform.core.api.RegistryKey;
import com.blackgear.vanillabackport.client.level.model.entity.pig.ColdPigModel;
import com.blackgear.vanillabackport.client.registries.ModModelLayers;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.pig.PigVariant;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.pig.PigVariants;
import com.blackgear.vanillabackport.core.compat.ClientCompat;
import com.google.common.collect.Maps;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1452;
import net.minecraft.class_2960;
import net.minecraft.class_5617;
import net.minecraft.class_587;
import java.util.Map;

@Environment(EnvType.CLIENT)
public class PigVariantRenderer extends AbstractVariantRenderer<class_1452, class_587<class_1452>, PigVariant, PigVariant.ModelType> {
    public PigVariantRenderer(class_5617.class_5618 context) {
        super(context);
    }
    
    @Override
    protected Map<PigVariant.ModelType, class_587<class_1452>> bakeModels(class_5617.class_5618 context) {
        Map<PigVariant.ModelType, class_587<class_1452>> map = Maps.newEnumMap(PigVariant.ModelType.class);
        map.put(PigVariant.ModelType.NORMAL, null);
        map.put(PigVariant.ModelType.COLD, new ColdPigModel<>(context.method_32167(ModModelLayers.COLD_PIG)));
        return map;
    }
    
    @Override
    protected PigVariant.ModelType getModelType(PigVariant variant) {
        return variant.modelAndTexture().model();
    }
    
    @Override
    protected class_2960 getTexture(class_1452 pig, PigVariant variant) {
        if (ClientCompat.hasQuarkPigTexture(pig)) return null;
        return variant.modelAndTexture().asset().path();
    }
    
    @Override
    protected BuiltInCoreRegistry<PigVariant> getRegistry() {
        return PigVariants.REGISTRIES;
    }
    
    @Override
    protected RegistryKey<PigVariant> getDefaultVariant() {
        return PigVariants.TEMPERATE;
    }
}