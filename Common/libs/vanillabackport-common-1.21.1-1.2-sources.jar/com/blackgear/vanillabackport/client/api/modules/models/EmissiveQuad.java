package com.blackgear.vanillabackport.client.api.modules.models;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_777;

@Environment(EnvType.CLIENT)
public class EmissiveQuad extends class_777 {
    private static final int FULL_BRIGHTNESS = 0x00F000F0;

    public EmissiveQuad(class_777 original) {
        super(makeEmissive(original.method_3357().clone()),
            original.method_3359(),
            original.method_3358(),
            original.method_35788(),
            original.method_24874());
    }

    private static int[] makeEmissive(int[] vertexData) {
        int vertexSize = 8;
        int lightsOffset = 6;

        for (int i = 0; i < vertexData.length; i += vertexSize) {
            vertexData[i + lightsOffset] = FULL_BRIGHTNESS;
        }

        return vertexData;
    }
}