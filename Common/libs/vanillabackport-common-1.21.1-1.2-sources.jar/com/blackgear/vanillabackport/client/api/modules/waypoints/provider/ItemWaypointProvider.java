package com.blackgear.vanillabackport.client.api.modules.waypoints.provider;

import com.blackgear.vanillabackport.common.api.modules.waypoints.*;
import com.blackgear.vanillabackport.common.api.modules.waypoints.Waypoint.Icon;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.blackgear.vanillabackport.core.util.Utilities.ColorUtils;
import com.blackgear.vanillabackport.core.util.Utilities.HashUtils;
import com.mojang.datafixers.util.Either;
import io.netty.buffer.Unpooled;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_4208;
import net.minecraft.class_5253.class_5254;
import net.minecraft.class_5321;
import net.minecraft.class_746;
import net.minecraft.class_8012;
import net.minecraft.class_9276;
import net.minecraft.class_9291;
import net.minecraft.class_9334;
import java.util.*;

@Environment(EnvType.CLIENT)
public class ItemWaypointProvider implements WaypointProvider {
    private final Map<Either<UUID, String>, TrackedWaypoint> tracked = new HashMap<>();

    @Override
    public void tick(class_746 player, TrackedWaypointManager manager) {
        if (!VanillaBackport.CLIENT_CONFIG.locatorDisplayCompassInfo.get()) return;

        Map<Either<UUID, String>, TrackedWaypoint> discovered = new HashMap<>();
        class_5321<class_1937> dimension = player.method_37908().method_27983();

        for (class_1799 stack : player.method_31548().field_7547) {
            process(player, dimension, stack, discovered);
        }
        
        process(player, dimension, player.method_6079(), discovered);

        this.tracked.keySet().removeIf(id -> {
            if (discovered.containsKey(id)) return false;
            manager.untrackWaypoint(this.tracked.get(id));
            return true;
        });

        discovered.forEach((id, waypoint) -> {
            if (this.tracked.put(id, waypoint) == null) {
                manager.trackWaypoint(waypoint);
            } else {
                manager.updateWaypoint(waypoint);
            }
        });
    }

    private void process(class_1657 player, class_5321<class_1937> dimension, class_1799 stack, Map<Either<UUID, String>, TrackedWaypoint> waypoints) {
        if (stack.method_7960()) return;

        Optional<class_4208> lastDeathPos = player.method_43122();
        if (lastDeathPos.isPresent() && stack.method_31574(class_1802.field_38747)) {
            class_4208 pos = lastDeathPos.get();
            if (pos.comp_2207() == dimension) {
                Either<UUID, String> id = Either.right("death_" + pos);
                waypoints.put(id, createDeathWaypoint(id, pos));
            }
        }

        class_9291 tracker = stack.method_57824(class_9334.field_49614);
        if (tracker != null && tracker.comp_2402().isPresent()) {
            class_4208 pos = tracker.comp_2402().get();
            if (pos.comp_2207() == dimension) {
                Either<UUID, String> id = Either.right("lodestone_" + pos);
                waypoints.put(id, createLodestoneWaypoint(id, pos));
            }
        }

        class_9276 contents = stack.method_57824(class_9334.field_49650);
        if (contents != null) {
            contents.method_59707().forEach(bundledStack -> process(player, dimension, bundledStack, waypoints));
        }
    }

    private static TrackedWaypoint createDeathWaypoint(Either<UUID, String> id, class_4208 pos) {
        Icon icon = new Icon(WaypointStyleAssets.DEATH, Optional.of(class_8012.field_42973));
        return new TrackedWaypoint.Vec3iWaypoint(id, icon, positionBuf(pos.comp_2208()));
    }

    private static TrackedWaypoint createLodestoneWaypoint(Either<UUID, String> id, class_4208 pos) {
        Icon icon = new Icon();
        icon.style = WaypointStyleAssets.LODESTONE;
        icon.color = Optional.of(ColorUtils.setBrightness(class_5254.method_58144(255, HashUtils.position(pos)), 0.9F));
        return new TrackedWaypoint.Vec3iWaypoint(id, icon, positionBuf(pos.comp_2208()));
    }

    private static class_2540 positionBuf(class_2338 pos) {
        class_2540 buf = new class_2540(Unpooled.buffer());
        buf.method_10804(pos.method_10263());
        buf.method_10804(pos.method_10264());
        buf.method_10804(pos.method_10260());
        return buf;
    }
}