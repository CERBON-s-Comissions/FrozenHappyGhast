package com.blackgear.vanillabackport.client.api.modules.mob_rendering;

import com.blackgear.platform.core.BuiltInCoreRegistry;
import com.blackgear.platform.core.api.RegistryKey;
import com.blackgear.vanillabackport.client.level.model.entity.nautilus.NautilusModel;
import com.blackgear.vanillabackport.client.level.model.entity.nautilus.ZombieNautilusCoralModel;
import com.blackgear.vanillabackport.client.registries.ModModelLayers;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.nautilus.ZombieNautilus;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.nautilus.ZombieNautilusVariant;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.nautilus.ZombieNautilusVariants;
import com.google.common.collect.Maps;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2960;
import net.minecraft.class_5617;
import java.util.Map;

@Environment(EnvType.CLIENT)
public class ZombieNautilusVariantRenderer extends AbstractVariantRenderer<ZombieNautilus, NautilusModel<ZombieNautilus>, ZombieNautilusVariant, ZombieNautilusVariant.ModelType> {
    public ZombieNautilusVariantRenderer(class_5617.class_5618 context) {
        super(context);
    }

    @Override
    protected Map<ZombieNautilusVariant.ModelType, NautilusModel<ZombieNautilus>> bakeModels(class_5617.class_5618 context) {
        Map<ZombieNautilusVariant.ModelType, NautilusModel<ZombieNautilus>> map = Maps.newEnumMap(ZombieNautilusVariant.ModelType.class);
        map.put(ZombieNautilusVariant.ModelType.NORMAL, new NautilusModel<>(context.method_32167(ModModelLayers.ZOMBIE_NAUTILUS)));
        map.put(ZombieNautilusVariant.ModelType.WARM, new ZombieNautilusCoralModel<>(context.method_32167(ModModelLayers.ZOMBIE_NAUTILUS_CORAL)));
        return map;
    }

    @Override
    protected ZombieNautilusVariant.ModelType getModelType(ZombieNautilusVariant variant) {
        return variant.modelAndTexture().model();
    }
    
    @Override
    protected class_2960 getTexture(ZombieNautilus nautilus, ZombieNautilusVariant variant) {
        return variant.modelAndTexture().asset().path();
    }

    @Override
    protected BuiltInCoreRegistry<ZombieNautilusVariant> getRegistry() {
        return ZombieNautilusVariants.REGISTRIES;
    }

    @Override
    protected RegistryKey<ZombieNautilusVariant> getDefaultVariant() {
        return ZombieNautilusVariants.TEMPERATE;
    }
}