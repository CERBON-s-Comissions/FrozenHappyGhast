package com.blackgear.vanillabackport.client.api.modules.mob_rendering;

import com.blackgear.platform.core.BuiltInCoreRegistry;
import com.blackgear.platform.core.api.RegistryKey;
import com.blackgear.vanillabackport.client.level.model.entity.cow.ColdCowModel;
import com.blackgear.vanillabackport.client.level.model.entity.cow.WarmCowModel;
import com.blackgear.vanillabackport.client.registries.ModModelLayers;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.cow.CowVariant;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.cow.CowVariants;
import com.blackgear.vanillabackport.core.compat.ClientCompat;
import com.google.common.collect.Maps;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1430;
import net.minecraft.class_2960;
import net.minecraft.class_560;
import net.minecraft.class_5617;
import java.util.Map;

@Environment(EnvType.CLIENT)
public class CowVariantRenderer extends AbstractVariantRenderer<class_1430, class_560<class_1430>, CowVariant, CowVariant.ModelType> {
    public CowVariantRenderer(class_5617.class_5618 context) {
        super(context);
    }
    
    @Override
    protected Map<CowVariant.ModelType, class_560<class_1430>> bakeModels(class_5617.class_5618 context) {
        Map<CowVariant.ModelType, class_560<class_1430>> map = Maps.newEnumMap(CowVariant.ModelType.class);
        map.put(CowVariant.ModelType.NORMAL, null);
        map.put(CowVariant.ModelType.WARM, new WarmCowModel<>(context.method_32167(ModModelLayers.WARM_COW)));
        map.put(CowVariant.ModelType.COLD, new ColdCowModel<>(context.method_32167(ModModelLayers.COLD_COW)));
        return map;
    }
    
    @Override
    protected CowVariant.ModelType getModelType(CowVariant variant) {
        return variant.modelAndTexture().model();
    }
    
    @Override
    protected class_2960 getTexture(class_1430 cow, CowVariant variant) {
        if (ClientCompat.hasQuarkCowTexture(cow)) return null;
        return variant.modelAndTexture().asset().path();
    }
    
    @Override
    protected BuiltInCoreRegistry<CowVariant> getRegistry() {
        return CowVariants.REGISTRIES;
    }
    
    @Override
    protected RegistryKey<CowVariant> getDefaultVariant() {
        return CowVariants.TEMPERATE;
    }
}