package com.blackgear.vanillabackport.client.api.modules.mob_rendering;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1309;
import net.minecraft.class_5617;
import net.minecraft.class_583;
import net.minecraft.class_7213;
import net.minecraft.class_882;
import net.minecraft.class_884;
import net.minecraft.class_922;
import net.minecraft.class_929;
import net.minecraft.class_932;
import net.minecraft.class_961;
import net.minecraft.class_969;
import net.minecraft.client.renderer.entity.*;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

@Environment(EnvType.CLIENT) @SuppressWarnings({"unchecked", "rawtypes"})
public class DynamicMobRendererRegistry {
    private static final Map<Class<?>, Function<class_5617.class_5618, SpecialMobRenderer<?, ?>>> REGISTRY = new HashMap<>();
    
    static {
        register(class_884.class, context -> SpecialMobRenderer.create(context, CowVariantRenderer::new, RenderConditions.FARM_ANIMALS));
        register(class_932.class, context -> SpecialMobRenderer.create(context, PigVariantRenderer::new, RenderConditions.FARM_ANIMALS));
        register(class_882.class, context -> SpecialMobRenderer.create(context, ChickenVariantRenderer::new, RenderConditions.FARM_ANIMALS));
        register(class_7213.class, context -> new FrogVariantRenderer());
        register(class_929.class, context -> new CatVariantRenderer());
        register(class_969.class, context -> new WolfVariantRenderer());
        register(class_961.class, context -> SpecialMobRenderer.create(context, ZombieHorseRenderer::new, RenderConditions.ZOMBIE_HORSE));
    }
    
    public static <R extends class_922<T, M>, T extends class_1309, M extends class_583<T>> void register(Class<R> rendererClass, Function<class_5617.class_5618, SpecialMobRenderer<T, M>> factory) {
        REGISTRY.put(rendererClass, (Function) factory);
    }
    
    public static <T extends class_1309, M extends class_583<T>> SpecialMobRenderer<T, M> getRenderer(class_922<T, M> renderer, class_5617.class_5618 context) {
        Function<class_5617.class_5618, SpecialMobRenderer<?, ?>> factory = REGISTRY.get(renderer.getClass());
        return factory != null ? (SpecialMobRenderer<T, M>) factory.apply(context) : null;
    }
}