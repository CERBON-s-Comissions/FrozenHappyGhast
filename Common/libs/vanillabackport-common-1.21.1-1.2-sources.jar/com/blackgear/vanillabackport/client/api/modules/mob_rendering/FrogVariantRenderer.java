package com.blackgear.vanillabackport.client.api.modules.mob_rendering;

import com.blackgear.vanillabackport.common.api.modules.mob_variant.VariantDataHolder;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.frog.FrogDataVariant;
import com.blackgear.vanillabackport.core.compat.ClientCompat;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2960;
import net.minecraft.class_7102;
import net.minecraft.class_7198;
import java.util.Optional;

@Environment(EnvType.CLIENT)
public class FrogVariantRenderer extends SpecialMobRenderer<class_7102, class_7198<class_7102>> {
    @Override
    public Optional<class_2960> getTexture(class_7102 entity) {
        if (ClientCompat.hasQuarkFrogTexture(entity)) return Optional.empty();

        return VariantDataHolder.<FrogDataVariant>getHolder(entity)
            .flatMap(VariantDataHolder::getVariantData)
            .map(variant -> variant.assetInfo().path());
    }

    @Override
    public Optional<class_7198<class_7102>> getModel(class_7102 entity) {
        return Optional.empty();
    }
}