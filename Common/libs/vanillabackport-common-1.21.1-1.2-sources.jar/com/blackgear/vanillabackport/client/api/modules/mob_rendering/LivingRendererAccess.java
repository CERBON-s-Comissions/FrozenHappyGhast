package com.blackgear.vanillabackport.client.api.modules.mob_rendering;

import net.minecraft.class_1309;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_583;

public interface LivingRendererAccess<T extends class_1309, M extends class_583<T>> {
    M getDefaultModel();
    
    default void onRender(T entity, float entityYaw, float partialTicks, class_4587 pose, class_4597 buffer, int packedLight) { }
}