package com.blackgear.vanillabackport.client.api.modules.mob_rendering;

import com.blackgear.platform.core.BuiltInCoreRegistry;
import com.blackgear.platform.core.api.RegistryKey;
import com.blackgear.vanillabackport.client.level.model.entity.chicken.ColdChickenModel;
import com.blackgear.vanillabackport.client.registries.ModModelLayers;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.chicken.ChickenVariant;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.chicken.ChickenVariants;
import com.blackgear.vanillabackport.core.compat.ClientCompat;
import com.google.common.collect.Maps;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1428;
import net.minecraft.class_2960;
import net.minecraft.class_558;
import net.minecraft.class_5617;
import java.util.Map;

@Environment(EnvType.CLIENT)
public class ChickenVariantRenderer extends AbstractVariantRenderer<class_1428, class_558<class_1428>, ChickenVariant, ChickenVariant.ModelType> {
    public ChickenVariantRenderer(class_5617.class_5618 context) {
        super(context);
    }
    
    @Override
    protected Map<ChickenVariant.ModelType, class_558<class_1428>> bakeModels(class_5617.class_5618 context) {
        Map<ChickenVariant.ModelType, class_558<class_1428>> map = Maps.newEnumMap(ChickenVariant.ModelType.class);
        map.put(ChickenVariant.ModelType.NORMAL, null);
        map.put(ChickenVariant.ModelType.COLD, new ColdChickenModel<>(context.method_32167(ModModelLayers.COLD_CHICKEN)));
        return map;
    }
    
    @Override
    protected ChickenVariant.ModelType getModelType(ChickenVariant variant) {
        return variant.modelAndTexture().model();
    }
    
    @Override
    protected class_2960 getTexture(class_1428 chicken, ChickenVariant variant) {
        if (ClientCompat.hasQuarkChickenTexture(chicken)) return null;
        return variant.modelAndTexture().asset().path();
    }
    
    @Override
    protected BuiltInCoreRegistry<ChickenVariant> getRegistry() {
        return ChickenVariants.REGISTRIES;
    }
    
    @Override
    protected RegistryKey<ChickenVariant> getDefaultVariant() {
        return ChickenVariants.TEMPERATE;
    }
}