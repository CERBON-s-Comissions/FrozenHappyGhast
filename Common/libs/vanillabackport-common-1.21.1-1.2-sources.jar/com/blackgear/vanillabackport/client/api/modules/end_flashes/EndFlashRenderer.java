package com.blackgear.vanillabackport.client.api.modules.end_flashes;

import com.blackgear.vanillabackport.client.registries.ModSoundEvents;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.mojang.blaze3d.platform.GlStateManager.class_4534;
import com.mojang.blaze3d.platform.GlStateManager.class_4535;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import net.minecraft.class_1011;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_445;
import net.minecraft.class_4587;
import net.minecraft.class_5294;
import net.minecraft.class_638;
import net.minecraft.class_757;
import net.minecraft.class_7833;
import org.joml.Matrix4f;

import static com.mojang.blaze3d.platform.GlStateManager.*;

public class EndFlashRenderer {
    private static final class_2960 END_FLASH_LOCATION = class_2960.method_60656("textures/environment/end_flash.png");
    private static final int END_SKY_COLOR = 0xFFCD60AC;
    private static boolean endFlashNeedsUpdating = false;

    public static boolean needsLightmapUpdate() {
        return endFlashNeedsUpdating;
    }

    public static void tick(class_310 minecraft, class_638 level, EndFlashState state) {
        endFlashNeedsUpdating = false;
        
        if (!VanillaBackport.CLIENT_CONFIG.endFlashSkyVisuals.get()) return;
        if (state == null) return;

        state.tick(level.method_8510());
        
        endFlashNeedsUpdating = state.isChangingIntensity();

        if (state.flashStartedThisTick() && !(minecraft.field_1755 instanceof class_445)) {
            minecraft.method_1483().method_4872(
                new DirectionalSoundInstance(
                    ModSoundEvents.WEATHER_END_FLASH.get(),
                    class_3419.field_15252,
                    level.method_8409(),
                    minecraft.field_1773.method_19418(),
                    state.getXAngle(),
                    state.getYAngle()
                ), EndFlashState.SOUND_DELAY_IN_TICKS
            );
        }
    }
    
    public static void render(class_4587 poseStack, class_310 minecraft) {
        if (!VanillaBackport.CLIENT_CONFIG.endFlashSkyVisuals.get()) return;
        
        class_638 level = minecraft.field_1687;
        if (level == null || minecraft.field_1690.method_41784().method_41753() || minecraft.field_1705.method_1740().method_1800()) {
            return;
        }

        EndFlashState endFlashState = ((EndFlashGetter) level).endFlashState();
        if (endFlashState == null) return;

        float intensity = endFlashState.getIntensity(minecraft.method_60646().method_60637(true));
        if (intensity <= 1.0E-5F) return;

        poseStack.method_22903();
        
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(180.0F - endFlashState.getYAngle()));
        poseStack.method_22907(class_7833.field_40714.rotationDegrees(-90.0F - endFlashState.getXAngle()));
        poseStack.method_46416(0.0F, 100.0F, 0.0F);
        poseStack.method_22905(60.0F, 1.0F, 60.0F);

        Matrix4f matrix4f = poseStack.method_23760().method_23761();
        
        RenderSystem.enableBlend();
        RenderSystem.blendFuncSeparate(class_4535.SRC_ALPHA, class_4534.ONE, class_4535.ONE, class_4534.ZERO);
        RenderSystem.depthMask(false);
        RenderSystem.setShader(class_757::method_34543);
        RenderSystem.setShaderTexture(0, END_FLASH_LOCATION);
        
        class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1575);
        
        int colorValue = (int)(intensity * 255.0F);
        int color = (colorValue << 24) | (colorValue << 16) | (colorValue << 8) | colorValue;
        
        bufferBuilder.method_22918(matrix4f, -1.0F, 0.0F, -1.0F).method_22913(0.0F, 0.0F).method_39415(color);
        bufferBuilder.method_22918(matrix4f, 1.0F, 0.0F, -1.0F).method_22913(1.0F, 0.0F).method_39415(color);
        bufferBuilder.method_22918(matrix4f, 1.0F, 0.0F, 1.0F).method_22913(1.0F, 1.0F).method_39415(color);
        bufferBuilder.method_22918(matrix4f, -1.0F, 0.0F, 1.0F).method_22913(0.0F, 1.0F).method_39415(color);
        
        class_286.method_43433(bufferBuilder.method_60800());
        
        RenderSystem.depthMask(true);
        RenderSystem.defaultBlendFunc();
        poseStack.method_22909();
    }

    public static float calculateLightIntensity(class_310 minecraft, float partialTicks) {
        if (!VanillaBackport.CLIENT_CONFIG.endFlashTerrainVisuals.get()) return 0.0F;
        
        class_638 level = minecraft.field_1687;
        if (level == null || level.method_28103().method_29992() != class_5294.class_5401.field_25641) {
            return 0.0F;
        }

        EndFlashState state = ((EndFlashGetter) level).endFlashState();
        if (state == null || minecraft.field_1690.method_41784().method_41753()) {
            return 0.0F;
        }

        float intensity = state.getIntensity(partialTicks);
        if (intensity <= 0.0F) return 0.0F;

        if (minecraft.field_1705.method_1740().method_1800()) {
            intensity /= 3.0F;
        }

        return intensity;
    }
    
    public static void applyLightTint(class_1011 lightPixels, float intensity) {
        if (!VanillaBackport.CLIENT_CONFIG.endFlashTerrainVisuals.get() || intensity <= 0.0F) return;
        
        float fr = (END_SKY_COLOR & 0xFF) / 255.0F;
        float fg = ((END_SKY_COLOR >> 8) & 0xFF) / 255.0F;
        float fb = ((END_SKY_COLOR >> 16) & 0xFF) / 255.0F;
        
        for (int sky = 0; sky < 16; ++sky) {
            final float baseFlash = intensity * (sky / 15.0F);
            
            for (int block = 0; block < 16; ++block) {
                if (sky == 15 && block == 15) continue;
                
                int pixel = lightPixels.method_4315(block, sky);
                float r = (pixel & 0xFF) / 255.0F;
                float g = ((pixel >> 8) & 0xFF) / 255.0F;
                float b = ((pixel >> 16) & 0xFF) / 255.0F;
                
                float blockFactor = block / 15.0F;
                float invBlock = 1.0F - blockFactor;
                
                float lerpR = r + baseFlash * (fr - r);
                float lerpG = g + baseFlash * (fg - g);
                float lerpB = b + baseFlash * (fb - b);
                
                float addR = r + fr * baseFlash * invBlock;
                float addG = g + fg * baseFlash * invBlock * 0.4F;
                float addB = b + fb * baseFlash * invBlock * 1.2F;
                
                int nr = (int) (class_3532.method_15363(lerpR + blockFactor * (addR - lerpR), 0.0F, 1.0F) * 255.0F);
                int ng = (int) (class_3532.method_15363(lerpG + blockFactor * (addG - lerpG), 0.0F, 1.0F) * 255.0F);
                int nb = (int) (class_3532.method_15363(lerpB + blockFactor * (addB - lerpB), 0.0F, 1.0F) * 255.0F);
                
                lightPixels.method_4305(block, sky, 0xFF000000 | nr | (ng << 8) | (nb << 16));
            }
        }
    }
}