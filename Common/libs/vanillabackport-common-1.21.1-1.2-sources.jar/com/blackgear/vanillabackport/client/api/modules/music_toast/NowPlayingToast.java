package com.blackgear.vanillabackport.client.api.modules.music_toast;

import com.blackgear.vanillabackport.core.mixin.client.access.MusicManagerAccessor;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1111;
import net.minecraft.class_1767;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_368;
import net.minecraft.class_374;
import org.jetbrains.annotations.Nullable;

@Environment(EnvType.CLIENT)
public class NowPlayingToast implements class_368, ToastModifier {
    private static final class_2960 NOW_PLAYING_BACKGROUND_SPRITE = class_2960.method_60656("toast/now_playing");
    private static final class_2960 MUSIC_NOTES_SPRITE = class_2960.method_60656("icon/music_notes");
    private static final int TEXT_COLOR = class_1767.field_7967.method_16357();
    
    private static int musicNoteColorTick;
    private static long lastMusicNoteColorChange;
    private static int musicNoteColor = -1;
    
    private boolean updateToast;
    private double notificationDisplayTimeMultiplier;
    private final class_310 minecraft;
    private class_369 wantedVisibility = class_369.field_2209;
    
    public NowPlayingToast() {
        this.minecraft = class_310.method_1551();
    }
    
    public static void renderToast(class_332 graphics, class_327 font) {
        class_2960 currentSong = getCurrentSongName();
        if (currentSong == null) return;
        
        graphics.method_51448().method_22903();
        graphics.method_52706(NOW_PLAYING_BACKGROUND_SPRITE, 0, 0, getWidth(currentSong, font), 30);
        
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        
        float r = ((musicNoteColor >> 16) & 0xFF) / 255.0F;
        float g = ((musicNoteColor >> 8) & 0xFF) / 255.0F;
        float b = (musicNoteColor & 0xFF) / 255.0F;
        graphics.method_51422(r, g, b, 1.0F);
        graphics.method_52706(MUSIC_NOTES_SPRITE, 7, 7, 16, 16);
        graphics.method_51422(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.disableBlend();
        
        graphics.method_51439(font, getNowPlayingString(currentSong), 30, 15 - 9 / 2, TEXT_COLOR | 0xFF000000, false);
        graphics.method_51448().method_22909();
    }
    
    @Nullable
    private static class_2960 getCurrentSongName() {
        MusicManagerAccessor accessor = (MusicManagerAccessor) class_310.method_1551().method_1538();
        if (accessor.getCurrentMusic() != null) {
            class_1111 sound = accessor.getCurrentMusic().method_4776();
            if (sound != null) return sound.method_4767();
        }
        return null;
    }
    
    public static void tickMusicNotes() {
        if (getCurrentSongName() != null) {
            long now = System.currentTimeMillis();
            if (now > lastMusicNoteColorChange + 25L) {
                musicNoteColorTick++;
                lastMusicNoteColorChange = now;
                musicNoteColor = ColorLerper.getLerpedColor(ColorLerper.Type.MUSIC_NOTE, musicNoteColorTick);
            }
        }
    }
    
    private static class_2561 getNowPlayingString(@Nullable class_2960 location) {
        if (location == null) return class_2561.method_43473();
        String path = location.method_12832();
        String namespace = location.method_12836();
        String translationKey = path.replace("/", ".");
        return class_2561.method_48321(translationKey, formatFallbackName(namespace, path));
    }
    
    private static String formatFallbackName(String namespace, String path) {
        String songNameRaw = path.contains("/") ? path.substring(path.lastIndexOf('/') + 1) : path;
        return capitalizeString(namespace) + " - " + capitalizeString(songNameRaw);
    }
    
    private static String capitalizeString(String input) {
        if (input == null || input.isEmpty()) return "";
        StringBuilder result = new StringBuilder();
        boolean capitalizeNext = true;
        for (char ch : input.toCharArray()) {
            if (ch == '_') {
                result.append(' ');
                capitalizeNext = true;
            } else if (capitalizeNext) {
                result.append(Character.toUpperCase(ch));
                capitalizeNext = false;
            } else {
                result.append(ch);
            }
        }
        return result.toString();
    }
    
    public void showToast(class_315 options) {
        this.updateToast = true;
        this.notificationDisplayTimeMultiplier = options.method_48191().method_41753();
        this.setWantedVisibility(class_369.field_2210);
    }
    
    @Override
    public void update(class_374 component, long fullyVisibleForMs) {
        if (this.updateToast) {
            this.wantedVisibility = fullyVisibleForMs < 5000.0 * this.notificationDisplayTimeMultiplier ? class_369.field_2210 : class_369.field_2209;
            tickMusicNotes();
        }
    }
    
    @Override
    public class_368.class_369 method_1986(class_332 graphics, class_374 component, long timeSinceLastVisible) {
        renderToast(graphics, component.method_1995().field_1772);
        return this.wantedVisibility;
    }
    
    @Override
    public void onFinishedRendering() {
        this.updateToast = false;
    }
    
    @Override
    public int method_29049() {
        return getWidth(getCurrentSongName(), this.minecraft.field_1772);
    }
    
    private static int getWidth(@Nullable class_2960 currentSong, class_327 font) {
        return 30 + font.method_27525(getNowPlayingString(currentSong)) + 7;
    }
    
    @Override
    public int method_29050() {
        return 30;
    }
    
    @Override
    public float xPos(int screenWidth, float visiblePortion) {
        return this.method_29049() * visiblePortion - this.method_29049();
    }
    
    @Override
    public class_369 getWantedVisibility() {
        return this.wantedVisibility;
    }
    
    public void setWantedVisibility(class_369 visibility) {
        this.wantedVisibility = visibility;
    }
}