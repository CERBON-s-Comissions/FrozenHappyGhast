package com.blackgear.vanillabackport.client.api.modules.music_frequency;

import com.mojang.serialization.Codec;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_3532;
import net.minecraft.class_3542;
import net.minecraft.class_5195;
import net.minecraft.class_5819;
import org.jetbrains.annotations.Nullable;

@Environment(EnvType.CLIENT)
public enum MusicFrequency implements class_3542 {
    DEFAULT("DEFAULT", "options.music_frequency.default", 20),
    FREQUENT("FREQUENT", "options.music_frequency.frequent", 10),
    CONSTANT("CONSTANT", "options.music_frequency.constant", 0);
    
    public static final Codec<MusicFrequency> CODEC = class_3542.method_28140(MusicFrequency::values);
    private final String name;
    private final int maxFrequency;
    private final class_2561 caption;
    
    MusicFrequency(String name, String translationKey, int maxFrequency) {
        this.name = name;
        this.maxFrequency = maxFrequency * 1200;
        this.caption = class_2561.method_43471(translationKey);
    }
    
    public int getNextSongDelay(@Nullable class_5195 music, class_5819 random) {
        if (music == null) {
            return this.maxFrequency;
        } else if (this == CONSTANT) {
            return 100;
        } else {
            int minFrequency = Math.min(music.method_27280(), this.maxFrequency);
            int maxFrequency = Math.min(music.method_27281(), this.maxFrequency);
            return class_3532.method_15395(random, minFrequency, maxFrequency);
        }
    }
    
    public class_2561 caption() {
        return this.caption;
    }
    
    @Override
    public String method_15434() {
        return this.name;
    }
}