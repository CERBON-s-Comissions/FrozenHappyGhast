package com.blackgear.vanillabackport.client.api.modules.bundle_ui;

import com.blackgear.vanillabackport.common.api.modules.bundle_ui.BundleFeatures;
import com.blackgear.vanillabackport.core.data.tags.ModItemTags;
import java.util.EnumMap;
import java.util.Map;
import net.minecraft.class_1735;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4587;

public final class BundleRenderHandler {
    private static final class_2960 DEFAULT_BACK = class_2960.method_60656("textures/item/bundle_open_back.png");
    private static final class_2960 DEFAULT_FRONT = class_2960.method_60656("textures/item/bundle_open_front.png");

    private static final Map<class_1767, class_2960> BACK_TEXTURES = new EnumMap<>(class_1767.class);
    private static final Map<class_1767, class_2960> FRONT_TEXTURES = new EnumMap<>(class_1767.class);

    static {
        for (class_1767 color : class_1767.values()) {
            BACK_TEXTURES.put(color, class_2960.method_60656("textures/item/" + color.method_7792() + "_bundle_open_back.png"));
            FRONT_TEXTURES.put(color, class_2960.method_60656("textures/item/" + color.method_7792() + "_bundle_open_front.png"));
        }
    }

    public static boolean renderBundleContents(class_332 graphics, class_327 font, class_1735 slot, int imageWidth) {
        if (!BundleFeatures.onBundleUpdate()) return false;

        class_1799 stack = slot.method_7677();
        if (!stack.method_31573(ModItemTags.BUNDLES)) return false;

        class_1799 selectedItem = BundleFeatures.getSelectedItemStack(stack);
        if (selectedItem.method_7960()) return false;

        class_2960 backTexture = DEFAULT_BACK;
        class_2960 frontTexture = DEFAULT_FRONT;

        if (!stack.method_31574(class_1802.field_27023)) {
            for (Map.Entry<class_1767, class_2960> entry : BACK_TEXTURES.entrySet()) {
                if (stack.method_31574(BundleFeatures.getByColor(entry.getKey()))) {
                    backTexture = entry.getValue();
                    frontTexture = FRONT_TEXTURES.get(entry.getKey());
                    break;
                }
            }
        }

        int slotX = slot.field_7873;
        int slotY = slot.field_7872;
        class_4587 pose = graphics.method_51448();

        pose.method_22903();
        pose.method_46416(0.0F, 0.0F, 100.0F);

        graphics.method_25290(backTexture, slotX, slotY, 0, 0, 16, 16, 16, 16);
        graphics.method_51428(selectedItem, slotX, slotY, slotX + slotY * imageWidth);

        pose.method_22903();
        pose.method_46416(0.0F, 0.0F, 200.0F);
        graphics.method_25290(frontTexture, slotX, slotY, 0, 0, 16, 16, 16, 16);
        graphics.method_51431(font, stack, slotX, slotY);
        pose.method_22909();

        pose.method_22909();
        return true;
    }
}