package com.blackgear.vanillabackport.client.api.modules.waypoints.provider;

import com.blackgear.vanillabackport.common.api.modules.waypoints.TrackedWaypoint;
import com.blackgear.vanillabackport.common.api.modules.waypoints.WaypointStyleAsset;
import com.blackgear.vanillabackport.common.api.modules.waypoints.WaypointStyleAssets;
import com.mojang.datafixers.util.Either;
import io.netty.buffer.ByteBuf;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_3532;
import net.minecraft.class_5321;
import net.minecraft.class_8012;
import java.util.List;
import java.util.Optional;

@Environment(EnvType.CLIENT)
public final class CardinalWaypoint extends TrackedWaypoint {
    private static final double BACKGROUND_DISTANCE_SQUARED = 1_000_000.0;
    public final int yaw;
    
    private CardinalWaypoint(String id, class_5321<WaypointStyleAsset> style, int yaw) {
        super(Either.right("cardinal_" + id), new Icon(style, Optional.of(class_8012.field_42973)), TrackedWaypoint.Type.EMPTY);
        this.yaw = yaw;
    }
    
    public static List<CardinalWaypoint> createPoints() {
        return List.of(
            new CardinalWaypoint("north", WaypointStyleAssets.NORTH, -180),
            new CardinalWaypoint("northeast", WaypointStyleAssets.CORNER, -135),
            new CardinalWaypoint("east", WaypointStyleAssets.EAST, -90),
            new CardinalWaypoint("southeast", WaypointStyleAssets.CORNER, -45),
            new CardinalWaypoint("south", WaypointStyleAssets.SOUTH, 0),
            new CardinalWaypoint("southwest", WaypointStyleAssets.CORNER, 45),
            new CardinalWaypoint("west", WaypointStyleAssets.WEST, 90),
            new CardinalWaypoint("northwest", WaypointStyleAssets.CORNER, 135)
        );
    }
    
    @Override
    public void update(TrackedWaypoint waypoint) { /* NO-OP */ }
    
    @Override
    public void writeContents(ByteBuf buf) { /* NO-OP */ }
    
    @Override
    public double yawAngleToCamera(class_1937 level, Camera camera) {
        return class_3532.method_15381(camera.vb$yaw(), this.yaw);
    }
    
    @Override
    public PitchDirection pitchDirectionToCamera(class_1937 level, Projector projector) {
        return PitchDirection.NONE;
    }
    
    @Override
    public double distanceSquared(class_1297 entity) {
        return BACKGROUND_DISTANCE_SQUARED;
    }
}