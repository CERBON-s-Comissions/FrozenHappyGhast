package com.blackgear.vanillabackport.client.api.modules.end_flashes;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1101;
import net.minecraft.class_243;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_4184;
import net.minecraft.class_5819;

@Environment(EnvType.CLIENT)
public class DirectionalSoundInstance extends class_1101 {
    private final class_4184 camera;
    private final float xAngle;
    private final float yAngle;
    
    public DirectionalSoundInstance(
        class_3414 sound,
        class_3419 source,
        class_5819 random,
        class_4184 camera,
        float xAngle,
        float yAngle
    ) {
        super(sound, source, random);
        this.camera = camera;
        this.xAngle = xAngle;
        this.yAngle = yAngle;
    }
    
    private void setPosition() {
        class_243 direction = class_243.method_1030(this.xAngle, this.yAngle).method_1021(10.0);
        this.field_5439 = this.camera.method_19326().field_1352 + direction.field_1352;
        this.field_5450 = this.camera.method_19326().field_1351 + direction.field_1351;
        this.field_5449 = this.camera.method_19326().field_1350 + direction.field_1350;
        this.field_5440 = class_1114.field_5478;
    }
    
    @Override
    public void method_16896() {
        this.setPosition();
    }
}