package com.blackgear.vanillabackport.client.api.modules.waypoints;

import com.blackgear.vanillabackport.client.resource.SimpleJsonResourceReloadListener;
import com.blackgear.vanillabackport.common.api.modules.waypoints.WaypointStyleAsset;
import com.blackgear.vanillabackport.common.api.modules.waypoints.WaypointStyleAssets;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1047;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_3695;
import net.minecraft.class_5321;
import net.minecraft.class_7654;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Environment(EnvType.CLIENT)
public class WaypointStyleManager extends SimpleJsonResourceReloadListener<WaypointStyle> {
    private static final class_7654 ASSET_LISTER = class_7654.method_45114("waypoint_style");
    private static final WaypointStyle MISSING = new WaypointStyle(0, 1, List.of(class_1047.method_4539()));
    private Map<class_5321<WaypointStyleAsset>, WaypointStyle> waypointStyles = Map.of();
    public static final WaypointStyleManager INSTANCE = new WaypointStyleManager();
    
    public WaypointStyleManager() {
        super(WaypointStyle.CODEC, ASSET_LISTER);
    }
    
    @Override
    protected void apply(Map<class_2960, WaypointStyle> preparations, class_3300 manager, class_3695 profiler) {
        this.waypointStyles = preparations.entrySet().stream()
            .collect(Collectors.toUnmodifiableMap(e -> class_5321.method_29179(WaypointStyleAssets.ROOT_ID, e.getKey()), Map.Entry::getValue));
    }
    
    public WaypointStyle get(class_5321<WaypointStyleAsset> id) {
        return this.waypointStyles.getOrDefault(id, MISSING);
    }
}