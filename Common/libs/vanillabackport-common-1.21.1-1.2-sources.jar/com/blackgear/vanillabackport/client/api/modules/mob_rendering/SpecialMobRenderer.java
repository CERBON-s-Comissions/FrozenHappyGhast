package com.blackgear.vanillabackport.client.api.modules.mob_rendering;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1309;
import net.minecraft.class_2960;
import net.minecraft.class_5617;
import net.minecraft.class_583;
import net.minecraft.class_922;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;

@Environment(EnvType.CLIENT)
public abstract class SpecialMobRenderer <T extends class_1309, M extends class_583<T>> {
    public static <T extends class_1309, M extends class_583<T>, R extends SpecialMobRenderer<T, M>> SpecialMobRenderer<T, M> create(
        class_5617.class_5618 context,
        Function<class_5617.class_5618, R> factory,
        RenderConditions conditions
    ) {
        return new SpecialMobRenderer<>() {
            private R instance;
            private boolean initialized = false;
            
            private R get() {
                if (!this.initialized) {
                    if (conditions.apply()) {
                        this.instance = factory.apply(context);
                    }
                    
                    this.initialized = true;
                }
                
                return this.instance;
            }
            
            @Override
            public Optional<class_2960> getTexture(T entity) {
                R renderer = this.get();
                return renderer != null ? renderer.getTexture(entity) : Optional.empty();
            }
            
            @Override
            public Optional<M> getModel(T entity) {
                R renderer = this.get();
                return renderer != null ? renderer.getModel(entity) : Optional.empty();
            }
            
            @Override
            public void ifPresent(Consumer<SpecialMobRenderer<T, M>> consumer) {
                R renderer = this.get();
                if (renderer != null) {
                    consumer.accept(renderer);
                }
            }
        };
    }
    
    public static <T extends class_1309, M extends class_583<T>, R extends SpecialMobRenderer<T, M>> SpecialMobRenderer<T, M> create(
        class_5617.class_5618 context,
        Function<class_5617.class_5618, R> factory
    ) {
        return create(context, factory, RenderConditions.DEFAULT);
    }
    
    public static <R extends class_922<?, ?>, L> void append(class_922<?, ?> renderer, Class<R> clazz, RenderConditions condition, Function<R, L> factory, Consumer<L> appender) {
        if (clazz.isInstance(renderer) && condition.apply()) {
            R type = clazz.cast(renderer);
            appender.accept(factory.apply(type));
        }
    }
    
    public static <R extends class_922<?, ?>, L> void append(class_922<?, ?> renderer, Class<R> clazz, Function<R, L> factory, Consumer<L> appender) {
        append(renderer, clazz, RenderConditions.DEFAULT, factory, appender);
    }
    
    public abstract Optional<class_2960> getTexture(T entity);
    
    public abstract Optional<M> getModel(T entity);
    
    public boolean suppressScale(T entity) {
        return false;
    }
    
    public void ifPresent(Consumer<SpecialMobRenderer<T, M>> consumer) { /* NO-OP */ }
}