package com.blackgear.vanillabackport.client.api.modules.waypoints.provider;

import com.blackgear.vanillabackport.common.api.modules.waypoints.TrackedWaypointManager;
import net.minecraft.class_746;

public interface WaypointProvider {
    default void tick(class_746 player, TrackedWaypointManager manager) { /* NO-OP */ }
}