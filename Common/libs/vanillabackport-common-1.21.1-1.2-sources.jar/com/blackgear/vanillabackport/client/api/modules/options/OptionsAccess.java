package com.blackgear.vanillabackport.client.api.modules.options;

import com.blackgear.vanillabackport.client.api.modules.music_frequency.MusicFrequency;
import com.blackgear.vanillabackport.client.api.modules.music_toast.MusicToastDisplayState;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_7172;

@Environment(EnvType.CLIENT)
public interface OptionsAccess {
    class_7172<MusicFrequency> musicFrequency();
    
    class_7172<MusicToastDisplayState> musicToast();
}