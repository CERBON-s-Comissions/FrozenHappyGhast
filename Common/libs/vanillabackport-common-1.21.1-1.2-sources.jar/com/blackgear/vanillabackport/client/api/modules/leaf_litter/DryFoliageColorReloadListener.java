package com.blackgear.vanillabackport.client.api.modules.leaf_litter;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_3685;
import net.minecraft.class_3695;
import net.minecraft.class_4080;
import java.io.IOException;

@Environment(EnvType.CLIENT)
public class DryFoliageColorReloadListener extends class_4080<int[]> {
    private static final class_2960 LOCATION = class_2960.method_60656("textures/colormap/dry_foliage.png");
    public static final DryFoliageColorReloadListener INSTANCE = new DryFoliageColorReloadListener();

    @Override
    protected int[] prepare(class_3300 resourceManager, class_3695 profiler) {
        try {
            return class_3685.method_16049(resourceManager, LOCATION);
        } catch (IOException exception) {
            throw new IllegalStateException("Failed to load dry foliage color texture", exception);
        }
    }

    @Override
    protected void apply(int[] object, class_3300 resourceManager, class_3695 profiler) {
        DryFoliageColor.init(object);
    }
}