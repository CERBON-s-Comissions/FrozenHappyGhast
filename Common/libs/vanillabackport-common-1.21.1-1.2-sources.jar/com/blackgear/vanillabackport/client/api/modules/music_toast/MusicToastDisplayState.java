package com.blackgear.vanillabackport.client.api.modules.music_toast;

import com.mojang.serialization.Codec;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_3542;

@Environment(EnvType.CLIENT)
public enum MusicToastDisplayState implements class_3542 {
    NEVER("never", "options.musicToast.never"),
    PAUSE("pause", "options.musicToast.pauseMenu"),
    PAUSE_AND_TOAST("pause_and_toast", "options.musicToast.pauseMenuAndToast");
    
    public static final Codec<MusicToastDisplayState> CODEC = class_3542.method_28140(MusicToastDisplayState::values);
    private final String name;
    private final class_2561 text;
    private final class_2561 tooltip;
    
    MusicToastDisplayState(final String name, final String translationKey) {
        this.name = name;
        this.text = class_2561.method_43471(translationKey);
        this.tooltip = class_2561.method_43471(translationKey + ".tooltip");
    }
    
    public class_2561 text() {
        return this.text;
    }
    
    public class_2561 tooltip() {
        return this.tooltip;
    }
    
    @Override
    public String method_15434() {
        return this.name;
    }
    
    public boolean renderInPauseScreen() {
        return this != NEVER;
    }
    
    public boolean renderToast() {
        return this == PAUSE_AND_TOAST;
    }
}
