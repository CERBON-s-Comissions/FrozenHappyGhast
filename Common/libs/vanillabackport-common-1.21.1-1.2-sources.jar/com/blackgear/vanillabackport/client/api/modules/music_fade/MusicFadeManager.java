package com.blackgear.vanillabackport.client.api.modules.music_fade;

import com.blackgear.vanillabackport.common.registries.worldgen.ModBiomes;
import com.blackgear.vanillabackport.core.mixin.client.access.SoundEngineAccessor;
import com.blackgear.vanillabackport.core.mixin.client.access.SoundManagerAccessor;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1113;
import net.minecraft.class_1140;
import net.minecraft.class_1142;
import net.minecraft.class_1959;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4235;
import net.minecraft.class_6880;
import net.minecraft.class_746;
import org.jetbrains.annotations.Nullable;

@Environment(EnvType.CLIENT)
public class MusicFadeManager {
    private static final float FADE_OUT_FACTOR = 0.97F;
    private static final float FADE_IN_MIN_STEP = 5.0E-4F;
    private static final float FADE_IN_MAX_STEP = 0.005F;
    private static final float VOLUME_THRESHOLD = 1.0E-4F;

    private final class_1142 manager;
    private final class_310 minecraft;
    private float currentGain = 1.0F;

    public MusicFadeManager(class_1142 manager) {
        this.manager = manager;
        this.minecraft = class_310.method_1551();
    }

    public boolean tickFade(@Nullable class_1113 currentMusic) {
        if (currentMusic == null) return false;

        float targetVolume = this.getTargetVolume();
        if (this.currentGain == targetVolume) return false;

        return this.fadePlaying(targetVolume, currentMusic);
    }

    public boolean isSilentBiome() {
        class_746 player = this.minecraft.field_1724;
        if (player == null) return false;

        class_6880<class_1959> biome = player.method_37908().method_23753(player.method_24515());
        return biome.method_40225(ModBiomes.PALE_GARDEN);
    }

    public void onStartPlaying() {
        this.currentGain = this.getTargetVolume();
    }

    private boolean fadePlaying(float targetVolume, class_1113 currentMusic) {
        this.updateCurrentGain(targetVolume);

        if (this.currentGain <= VOLUME_THRESHOLD) {
            this.manager.method_4859();
            return false;
        }

        class_1140 engine = ((SoundManagerAccessor) this.minecraft.method_1483()).getSoundEngine();
        this.setVolume(engine, currentMusic, this.currentGain);
        return true;
    }

    private void updateCurrentGain(float targetVolume) {
        if (this.currentGain < targetVolume) {
            this.fadeIn(targetVolume);
        } else {
            this.fadeOut(targetVolume);
        }

        this.currentGain = class_3532.method_15363(this.currentGain, 0.0F, 1.0F);
    }

    private void fadeIn(float targetVolume) {
        float step = class_3532.method_15363(this.currentGain, FADE_IN_MIN_STEP, FADE_IN_MAX_STEP);
        this.currentGain = Math.min(this.currentGain + step, targetVolume);
    }

    private void fadeOut(float targetVolume) {
        this.currentGain = FADE_OUT_FACTOR * this.currentGain + (1 - FADE_OUT_FACTOR) * targetVolume;
        if (Math.abs(this.currentGain - targetVolume) < VOLUME_THRESHOLD) {
            this.currentGain = targetVolume;
        }
    }

    private float getTargetVolume() {
        return this.isSilentBiome() ? 0.0F : 1.0F;
    }

    private void setVolume(class_1140 engine, class_1113 instance, float volume) {
        SoundEngineAccessor accessor = (SoundEngineAccessor) engine;
        if (!accessor.isLoaded()) return;

        class_4235.class_4236 handle = accessor.getInstanceToChannel().get(instance);
        if (handle != null) {
            handle.method_19735(channel -> channel.method_19647(volume * accessor.callCalculateVolume(instance)));
        }
    }
}