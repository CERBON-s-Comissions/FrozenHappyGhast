package com.blackgear.vanillabackport.client.api.modules.music_toast;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_156;
import net.minecraft.class_315;
import net.minecraft.class_332;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_368;
import net.minecraft.class_368.class_369;
import net.minecraft.class_374;

@Environment(EnvType.CLIENT)
public class ToastInstance<T extends class_368> {
    private final class_374 component;
    private final T toast;
    private final int firstSlotIndex;
    private long animationStartTime;
    private long becameFullyVisibleAt;
    private class_369 visibility;
    private long fullyVisibleFor;
    private float visiblePortion;
    private boolean hasFinishedRendering;
    
    public ToastInstance(class_374 component, T toast, int firstSlotIndex) {
        this.component = component;
        this.toast = toast;
        this.firstSlotIndex = firstSlotIndex;
        this.resetToast();
    }
    
    public T getToast() {
        return this.toast;
    }
    
    public void resetToast() {
        this.animationStartTime = -1L;
        this.becameFullyVisibleAt = -1L;
        this.visibility = class_369.field_2209;
        this.fullyVisibleFor = 0L;
        this.visiblePortion = 0.0F;
        this.hasFinishedRendering = false;
    }
    
    public boolean hasFinishedRendering() {
        return this.hasFinishedRendering;
    }
    
    public void calculateVisiblePortion(long now) {
        float animationProgress = class_3532.method_15363((float) (now - this.animationStartTime) / 600.0F, 0.0F, 1.0F);
        animationProgress *= animationProgress;
        this.visiblePortion = this.visibility == class_369.field_2209
            ? 1.0F - animationProgress
            : animationProgress;
    }
    
    public void update() {
        long now = class_156.method_658();
        if (this.animationStartTime == -1L) {
            this.animationStartTime = now;
            this.visibility = class_369.field_2210;
        }
        
        if (this.visibility == class_369.field_2210 && now - this.animationStartTime <= 600L) {
            this.becameFullyVisibleAt = now;
        }
        
        ToastModifier toast = ToastModifier.of(this.toast);
        this.fullyVisibleFor = now - this.becameFullyVisibleAt;
        this.calculateVisiblePortion(now);
        toast.update(this.component, this.fullyVisibleFor);
        class_369 wantedVisibility = toast.getWantedVisibility();
        if (wantedVisibility != this.visibility) {
            this.animationStartTime = now - (int) ((1.0F - this.visiblePortion) * 600.0F);
            this.visibility = wantedVisibility;
        }
        
        boolean wasAlreadyFinishedRendering = this.hasFinishedRendering;
        this.hasFinishedRendering = this.visibility == class_369.field_2209 && now - this.animationStartTime > 600L;
        if (this.hasFinishedRendering && !wasAlreadyFinishedRendering) {
            toast.onFinishedRendering();
        }
    }
    
    public void render(class_332 graphics, int screenWidth) {
        if (!this.hasFinishedRendering) {
            ToastModifier toast = ToastModifier.of(this.toast);
            graphics.method_51448().method_22903();
            graphics.method_51448().method_22904(toast.xPos(screenWidth, this.visiblePortion), toast.yPos(this.firstSlotIndex), 800.0);
            this.toast.method_1986(graphics, this.component, this.fullyVisibleFor);
            graphics.method_51448().method_22909();
        }
    }
    
    public static float getFinalSoundSourceVolume(class_315 options, class_3419 source) {
        return source == class_3419.field_15250 ? options.method_1630(source) : options.method_1630(source) * options.method_1630(class_3419.field_15250);
    }
}