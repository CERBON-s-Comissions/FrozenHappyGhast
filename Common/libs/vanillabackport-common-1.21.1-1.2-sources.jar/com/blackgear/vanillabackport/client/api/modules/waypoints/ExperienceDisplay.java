package com.blackgear.vanillabackport.client.api.modules.waypoints;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_746;

@Environment(EnvType.CLIENT)
public interface ExperienceDisplay {
    static ExperienceDisplay of(class_746 player) {
        return (ExperienceDisplay) player;
    }
    
    int getExperienceDisplayStartTick();
    
    void setExperienceDisplayStartTick(int ticks);
}