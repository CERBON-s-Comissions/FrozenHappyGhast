package com.blackgear.vanillabackport.client.api.modules.mob_rendering;

import com.blackgear.platform.core.BuiltInCoreRegistry;
import com.blackgear.platform.core.api.RegistryKey;
import com.blackgear.vanillabackport.common.api.modules.mob_variant.VariantDataHolder;
import com.blackgear.vanillabackport.common.api.modules.mob_variant.VariantUtils;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1309;
import net.minecraft.class_2960;
import net.minecraft.class_5617;
import net.minecraft.class_583;
import java.util.Map;
import java.util.Optional;

@Environment(EnvType.CLIENT)
public abstract class AbstractVariantRenderer<T extends class_1309, M extends class_583<T>, V, E extends Enum<E>> extends SpecialMobRenderer<T, M> {
    protected final Map<E, M> modelByVariant;

    public AbstractVariantRenderer(class_5617.class_5618 context) {
        this.modelByVariant = this.bakeModels(context);
    }

    protected abstract Map<E, M> bakeModels(class_5617.class_5618 context);

    protected Optional<V> getVariant(T entity) {
        return VariantDataHolder.<V>getHolder(entity).flatMap(VariantDataHolder::getVariantData);
    }

    protected abstract E getModelType(V variant);

    protected abstract class_2960 getTexture(T entity, V variant);

    protected abstract BuiltInCoreRegistry<V> getRegistry();

    protected abstract RegistryKey<V> getDefaultVariant();

    private boolean isDefaultVariant(V variant) {
        return VariantUtils.matches(this.getRegistry(), variant, this.getDefaultVariant());
    }

    @Override
    public Optional<class_2960> getTexture(T entity) {
        Optional<V> variant = this.getVariant(entity);
        return variant.filter(v -> !this.isDefaultVariant(v)).map(v -> this.getTexture(entity, v));
    }

    @Override
    public Optional<M> getModel(T entity) {
        Optional<V> variant = this.getVariant(entity);
        if (variant.isEmpty()) return Optional.empty();

        E modelType = this.getModelType(variant.get());
        M model = this.modelByVariant.get(modelType);

        return Optional.ofNullable(model);
    }
}