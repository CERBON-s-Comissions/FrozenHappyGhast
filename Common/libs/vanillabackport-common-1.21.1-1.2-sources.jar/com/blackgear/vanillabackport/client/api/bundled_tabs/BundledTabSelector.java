package com.blackgear.vanillabackport.client.api.bundled_tabs;

import com.blackgear.platform.client.event.screen.HudInteractions;
import com.blackgear.platform.client.event.screen.HudRendering;
import com.blackgear.platform.client.event.screen.api.ScreenAccess;
import com.blackgear.platform.core.util.event.CancellableResult;
import com.blackgear.vanillabackport.client.api.modules.bundle_ui.ScrollWheelHandler;
import com.blackgear.vanillabackport.client.registries.ModBundledTabs;
import com.blackgear.vanillabackport.client.registries.ModCreativeTabs;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.blackgear.vanillabackport.core.mixin.client.access.CreativeModeInventoryScreenAccessor;
import com.mojang.blaze3d.systems.RenderSystem;
import org.joml.Vector2i;

import java.util.*;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3532;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_481;
import net.minecraft.class_7919;
import net.minecraft.class_9779;

public class BundledTabSelector {
    private static final class_2960 SELECTOR_BAR = VanillaBackport.resource("textures/gui/bundled_tabs/interface.png");
    private static final int VISIBLE_CATEGORIES = 5;

    private static BundledTabSelector instance;

    public static BundledTabSelector bootstrap() {
        if (instance == null) instance = new BundledTabSelector();
        return instance;
    }

    private int guiLeft;
    private int guiTop;
    private int scroll;

    private class_339 scrollUpButton;
    private class_339 scrollDownButton;
    private final ScrollWheelHandler scrollWheelHandler = new ScrollWheelHandler();

    private List<BundledTabs> bundles = new ArrayList<>();
    private class_1761 lastTab;

    private BundledTabSelector() {
        HudRendering.POST_INITIALIZE.register(this::init);
        HudRendering.RENDER_BACKGROUND.register(this::renderBackground);
        HudRendering.CLOSE_CONTAINER.register(this::onClose);
        HudInteractions.SCROLLING_PRE.register(this::onScroll);
    }

    private CancellableResult onScroll(class_310 client, class_437 screen, double mouseX, double mouseY, double scrollX, double scrollY) {
        if (!(screen instanceof class_481) || this.scrollUpButton == null || this.scrollDownButton == null) {
            return CancellableResult.PASS;
        }
    
        class_1761 tab = CreativeModeInventoryScreenAccessor.getSelectedTab();
        
        if (this.isValidTab(tab)) {
            if (mouseX >= this.guiLeft - 30 && mouseY >= this.guiTop + 2 && mouseX <= this.guiLeft && mouseY <= this.guiTop + 122) {
                Vector2i scroll = this.scrollWheelHandler.onMouseScroll(scrollY);
                int delta = scroll.y == 0 ? -scroll.x : scroll.y;
                
                if (delta != 0) {
                    this.scroll = class_3532.method_15340(this.scroll - delta, 0, this.getMaxScroll());
                    this.updateWidgets();
                }
                
                return CancellableResult.CANCEL;
            }
        }
        
        return CancellableResult.PASS;
    }

    private void init(class_310 minecraft, class_437 screen, ScreenAccess access) {
        if (screen instanceof class_481 creativeScreen) {
            if (this.bundles.isEmpty()) this.bundles = new ArrayList<>(ModBundledTabs.getTabs());
            this.guiLeft = creativeScreen.field_2776;
            this.guiTop = creativeScreen.field_2800;
            this.injectWidgets(creativeScreen, access::addRenderableWidget);
        }
    }

    private void renderBackground(class_310 minecraft, class_465<?> screen, class_332 graphics, int mouseX, int mouseY, class_9779 timer) {
        if (screen instanceof class_481 creativeScreen) {
            class_1761 tab = CreativeModeInventoryScreenAccessor.getSelectedTab();

            if (this.isValidTab(tab)) {
                graphics.method_25302(SELECTOR_BAR, this.guiLeft - 30, this.guiTop + 2, 0, 0, 30, 120);
            }

            if (this.lastTab != tab) {
                if (this.isValidTab(tab) && !this.isValidTab(this.lastTab)) {
                    this.bundles.forEach(BundledTabs::deselect);
                }
                
                this.onSwitchCreativeTab(tab, creativeScreen);
                this.lastTab = tab;
            }
        }
    }

    private void onClose(class_310 minecraft, class_437 screen) {
        if (screen instanceof class_481) {
            this.scrollUpButton = null;
            this.scrollDownButton = null;
            this.lastTab = null;

            this.bundles.forEach(bundle -> {
                bundle.setContentTab(null);
                bundle.deselect();
            });
        }
    }

    private boolean hasSelectedBundle() {
        return this.bundles.stream().anyMatch(BundledTabs::isSelected);
    }
    
    private List<BundledTabs> getActiveBundles() {
        return this.bundles.stream()
            .filter(tab -> !tab.isEmpty())
            .collect(Collectors.toList());
    }
    
    private void injectWidgets(class_481 screen, Consumer<class_339> widgets) {
        this.bundles.forEach(bundle -> {
            Tab tab = new Tab(this.guiLeft - 23, this.guiTop + 7, bundle, button -> {
                if (bundle.isSelected()) {
                    bundle.deselect();
                } else {
                    this.bundles.forEach(BundledTabs::deselect);
                    bundle.select();
                }
                this.updateItems(screen);
            });
            tab.field_22764 = false;
            widgets.accept(tab);
        });

        this.scrollUpButton = new ScrollButton(this.guiLeft - 24, this.guiTop + 6, 32, button -> {
            if (this.scroll > 0) this.scroll--;
            this.updateWidgets();
        });
        
        this.scrollDownButton = new ScrollButton(this.guiLeft - 24, this.guiTop + 108, 52, button -> {
            if (this.scroll < this.getMaxScroll()) this.scroll++;
            this.updateWidgets();
        });

        widgets.accept(this.scrollUpButton);
        widgets.accept(this.scrollDownButton);

        this.onSwitchCreativeTab(CreativeModeInventoryScreenAccessor.getSelectedTab(), screen);
    }

    private int getMaxScroll() {
        return Math.max(0, this.getActiveBundles().size() - VISIBLE_CATEGORIES);
    }

    private void updateItems(class_481 screen) {
        LinkedHashSet<class_1799> display = new LinkedHashSet<>();

        if (!this.hasSelectedBundle()) {
            ModCreativeTabs.VANILLA_BACKPORT.get().method_47313().forEach(stack -> display.add(stack.method_7972()));
        } else {
            this.bundles.stream()
                .filter(BundledTabs::isSelected)
                .forEach(bundle -> {
                    for (class_1799 stack : bundle.getDisplayItems()) {
                        if (!stack.method_7960()) {
                            display.add(stack.method_7972());
                        }
                    }
                });
        }

        class_2371<class_1799> items = screen.method_17577().field_2897;
        items.clear();
        items.addAll(display);
        screen.method_17577().method_2473(0);
    }

    private void updateWidgets() {
        if (this.scrollUpButton == null || this.scrollDownButton == null) return;
        this.bundles.forEach(bundle -> bundle.setVisible(false));
        
        for (int i = this.scroll; i < this.scroll + VISIBLE_CATEGORIES && i < this.getActiveBundles().size(); i++) {
            BundledTabs bundle = this.getActiveBundles().get(i);
            bundle.setY(this.guiTop + 18 * (i - this.scroll) + 18);
            bundle.setVisible(true);
        }

        boolean isValidTab = this.isValidTab(CreativeModeInventoryScreenAccessor.getSelectedTab());

        this.scrollUpButton.field_22764 = isValidTab && this.scroll > 0;
        this.scrollDownButton.field_22764 = isValidTab && this.scroll < this.getMaxScroll();
    }

    private void onSwitchCreativeTab(class_1761 tab, class_481 screen) {
        if (this.isValidTab(tab)) {
            this.updateWidgets();
            this.updateItems(screen);
        } else {
            if (this.scrollUpButton != null) this.scrollUpButton.field_22764 = false;
            if (this.scrollDownButton != null) this.scrollDownButton.field_22764 = false;
            this.bundles.forEach(bundle -> bundle.setVisible(false));
        }
    }

    private boolean isValidTab(class_1761 tab) {
        return tab == ModCreativeTabs.VANILLA_BACKPORT.get();
    }

    public static class Tab extends class_4185 {
        private final BundledTabs bundle;

        private Tab(int x, int y, BundledTabs bundle, class_4241 onPress) {
            super(x, y, 16, 16, class_2561.method_43473(), onPress, field_40754);
            this.bundle = bundle;
            bundle.setContentTab(this);
            this.method_47400(class_7919.method_47407(bundle.getTooltip()));
        }

        @Override
        protected void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
            graphics.method_51448().method_22903();
            graphics.method_51448().method_22904(0.0, 0.0, 20.0);
            this.renderSelected(graphics);
            graphics.method_51427(this.bundle.getIcon(), this.method_46426(), this.method_46427());
            graphics.method_51448().method_22909();
            this.renderHighlight(graphics);
        }

        private void renderSelected(class_332 graphics) {
            if (this.bundle.isSelected()) {
                graphics.method_25302(SELECTOR_BAR, this.method_46426() - 7, this.method_46427() - 1, 36, 24, 30, 19);
            }
        }

        private void renderHighlight(class_332 graphics) {
            if (this.method_49606() && !this.bundle.isSelected()) {
                graphics.method_51448().method_22903();
                graphics.method_51448().method_22904(0.0, 0.0, 20.0);
                RenderSystem.enableBlend();
                RenderSystem.defaultBlendFunc();
                graphics.method_25302(SELECTOR_BAR, this.method_46426(), this.method_46427(), 32, 44, 16, 16);
                RenderSystem.disableBlend();
                graphics.method_51448().method_22909();
            }
        }
    }

    public static class ScrollButton extends class_4185 {
        private final int uOffset;

        private ScrollButton(int x, int y, int uOffset, class_4241 onPress) {
            super(x, y, 18, 20, class_2561.method_43473(), onPress, field_40754);
            this.uOffset = uOffset;
        }

        @Override
        public void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
            int textureY = this.field_22762 ? 12 : 0;
            graphics.method_51448().method_22903();
            graphics.method_51448().method_22904(0.0, 0.0, 20.0);
            graphics.method_25302(SELECTOR_BAR, this.method_46426(), this.method_46427(), this.uOffset, textureY, 18, 11);
            graphics.method_51448().method_22909();
        }
    }
}