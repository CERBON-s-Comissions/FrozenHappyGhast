package com.blackgear.vanillabackport.client.api.modules.music_toast;

import com.blackgear.vanillabackport.core.util.Utilities.ColorUtils;
import com.google.common.collect.Maps;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1767;
import net.minecraft.class_3532;
import net.minecraft.class_5253.class_5254;
import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

@Environment(EnvType.CLIENT)
public class ColorLerper {
    public static final class_1767[] MUSIC_NOTE_COLORS = new class_1767[]{
        class_1767.field_7952,
        class_1767.field_7967,
        class_1767.field_7951,
        class_1767.field_7966,
        class_1767.field_7955,
        class_1767.field_7942,
        class_1767.field_7961,
        class_1767.field_7947,
        class_1767.field_7946,
        class_1767.field_7954,
        class_1767.field_7964,
        class_1767.field_7958
    };
    
    public static int getLerpedColor(final ColorLerper.Type type, final float tick) {
        int tickCount = class_3532.method_15375(tick);
        int value = tickCount / type.colorDuration;
        int colorCount = type.colors.length;
        int c1 = value % colorCount;
        int c2 = (value + 1) % colorCount;
        float subStep = (tickCount % type.colorDuration + class_3532.method_22450(tick)) / type.colorDuration;
        int color1 = type.getColor(type.colors[c1]);
        int color2 = type.getColor(type.colors[c2]);
        return ColorUtils.srgbLerp(subStep, color1, color2);
    }
    
    private static int getModifiedColor(final class_1767 color, final float brightness) {
        if (color == class_1767.field_7952) {
            return -1644826;
        } else {
            int src = color.method_7787();
            return class_5254.method_27764(
                255,
                class_3532.method_15340(class_3532.method_15375(class_5254.method_27765(src) * brightness), 0, 255),
                class_3532.method_15340(class_3532.method_15375(class_5254.method_27766(src) * brightness), 0, 255),
                class_3532.method_15340(class_3532.method_15375(class_5254.method_27767(src) * brightness), 0, 255)
            );
        }
    }
    
    @Environment(EnvType.CLIENT)
    public enum Type {
        MUSIC_NOTE(30, ColorLerper.MUSIC_NOTE_COLORS, 1.25F);
        
        private final int colorDuration;
        private final Map<class_1767, Integer> colorByDye;
        private final class_1767[] colors;
        
        Type(final int colorDuration, final class_1767[] colors, final float brightness) {
            this.colorDuration = colorDuration;
            this.colorByDye = Maps.newHashMap(
                Arrays.stream(colors)
                    .collect(Collectors.toMap(d -> d, color -> ColorLerper.getModifiedColor(color, brightness)))
            );
            this.colors = colors;
        }
        
        public final int getColor(final class_1767 dyeColor) {
            return this.colorByDye.get(dyeColor);
        }
    }
}