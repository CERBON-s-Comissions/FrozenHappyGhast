package com.blackgear.vanillabackport.client.api.modules.bundle_ui;

import com.blackgear.vanillabackport.common.api.modules.bundle_ui.BundleFeatures;
import com.blackgear.vanillabackport.common.api.modules.bundle_ui.ModernBundle;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.mojang.blaze3d.systems.RenderSystem;
import org.apache.commons.lang3.math.Fraction;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_5250;
import net.minecraft.class_9276;
import net.minecraft.class_9334;

public class BundleTooltipHandler {
    private static final class_2960 PROGRESSBAR_BORDER_SPRITE = class_2960.method_60656("container/bundle/bundle_progressbar_border");
    private static final class_2960 PROGRESSBAR_FILL_SPRITE = class_2960.method_60656("container/bundle/bundle_progressbar_fill");
    private static final class_2960 PROGRESSBAR_FULL_SPRITE = class_2960.method_60656("container/bundle/bundle_progressbar_full");
    private static final class_2960 BUNDLE_SLOT_HIGHLIGHT_BACK_TEXTURE = class_2960.method_60656("textures/container/bundle/slot_highlight_back.png");
    private static final class_2960 BUNDLE_SLOT_HIGHLIGHT_FRONT_TEXTURE = class_2960.method_60656("textures/container/bundle/slot_highlight_front.png");
    private static final class_2960 BUNDLE_SLOT_BACKGROUND_TEXTURE = class_2960.method_60656("textures/container/bundle/slot_background.png");
    
    private static final class_2561 BUNDLE_EMPTY_DESCRIPTION = class_2561.method_43471("item.minecraft.bundle.empty.description");
    private static final class_2561 BUNDLE_FULL = class_2561.method_43471("item.minecraft.bundle.full");
    private static final class_2561 BUNDLE_EMPTY = class_2561.method_43471("item.minecraft.bundle.empty");
    
    private final class_9276 contents;
    private int selectedItem;
    
    public BundleTooltipHandler(class_9276 contents) {
        this.contents = contents;
    }
    
    public void init(class_9276 contents) {
        this.selectedItem = ((ModernBundle) (Object) contents).getSelectedItem();
    }
    
    private int getSelectedItem() {
        return this.selectedItem;
    }
    
    private boolean hasSelectedItem() {
        return this.selectedItem != -1;
    }
    
    public int getHeight() {
        return this.contents.method_57429() ? 39 : this.backgroundHeight();
    }
    
    public int getWidth() {
        return gridSizeX() * 24;
    }
    
    private int backgroundHeight() {
        return this.itemGridHeight() + 13 + 8;
    }
    
    private int itemGridHeight() {
        return this.gridSizeY() * 24;
    }
    
    private int getContentXOffset(int width) {
        return (width - getWidth()) / 2;
    }

    private int gridSizeX() {
        return VanillaBackport.CLIENT_CONFIG.endlessBundleUi.get()
            ? Math.max(4, class_3532.method_15384(Math.sqrt(this.contents.method_57426())))
            : 4;
    }

    private int gridSizeY() {
        return class_3532.method_38788(this.slotCount(), gridSizeX());
    }
    
    private int slotCount() {
        return VanillaBackport.CLIENT_CONFIG.endlessBundleUi.get()
            ? this.contents.method_57426()
            : Math.min(12, this.contents.method_57426());
    }
    
    public boolean renderImage(class_327 font, int x, int y, class_332 graphics) {
        if (!BundleFeatures.onBundleUpdate()) return false;
        
        if (this.contents.method_57429()) {
            this.renderEmptyBundleTooltip(font, x, y, this.getWidth(), graphics);
        } else {
            this.renderBundleWithItemsTooltip(font, x, y, this.getWidth(), graphics);
        }
        
        return true;
    }
    
    private void renderEmptyBundleTooltip(class_327 font, int x, int y, int width, class_332 graphics) {
        this.drawEmptyBundleDescriptionText(x + this.getContentXOffset(width), y, font, graphics);
        this.drawProgressBar(x + this.getContentXOffset(width), y + this.getEmptyBundleDescriptionTextHeight(font) + 4, font, graphics);
    }
    
    private void renderBundleWithItemsTooltip(class_327 font, int x, int y, int width, class_332 graphics) {
        boolean maxDisplay = this.contents.method_57426() > 12;
        List<class_1799> stacks = this.getShownItems(((ModernBundle) (Object) this.contents).getNumberOfItemsToShow());
        int xOffset = x + this.getContentXOffset(width) + getWidth();
        int yOffset = y + this.gridSizeY() * 24;
        int index = 1;
        
        for (int row = 1; row <= this.gridSizeY(); row++) {
            for (int column = 1; column <= gridSizeX(); column++) {
                int slotX = xOffset - column * 24;
                int slotY = yOffset - row * 24;
                
                if (this.shouldRenderSurplusText(maxDisplay, column, row)) {
                    this.renderCount(slotX, slotY, this.getAmountOfHiddenItems(stacks), font, graphics);
                } else if (this.shouldRenderItemSlot(stacks, index)) {
                    this.renderSlot(index, slotX, slotY, stacks, index, font, graphics);
                    index++;
                }
            }
        }
        
        this.drawSelectedItemTooltip(font, graphics, x, y, width);
        this.drawProgressBar(x + this.getContentXOffset(width), y + this.itemGridHeight() + 4, font, graphics);
    }
    
    private List<class_1799> getShownItems(int max) {
        int size = Math.min(this.contents.method_57426(), max);
        return this.contents.method_59707().limit(size).toList();
    }
    
    private boolean shouldRenderSurplusText(boolean maxDisplay, int column, int row) {
        return !VanillaBackport.CLIENT_CONFIG.endlessBundleUi.get() && (maxDisplay && column * row == 1);
    }
    
    private boolean shouldRenderItemSlot(List<class_1799> items, int itemIndex) {
        return items.size() >= itemIndex;
    }
    
    private int getAmountOfHiddenItems(List<class_1799> items) {
        return this.contents.method_59707().skip(items.size()).mapToInt(class_1799::method_7947).sum();
    }
    
    private void renderSlot(int index, int x, int y, List<class_1799> stacks, int seed, class_327 font, class_332 graphics) {
        int itemIndex = stacks.size() - index;
        boolean isSelected = itemIndex == this.getSelectedItem();
        class_1799 stack = stacks.get(itemIndex);
        
        if (isSelected) {
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            graphics.method_25291(BUNDLE_SLOT_HIGHLIGHT_BACK_TEXTURE, x, y, 0, 0, 0, 24, 24, 24, 24);
            RenderSystem.disableBlend();
        } else {
            graphics.method_25291(BUNDLE_SLOT_BACKGROUND_TEXTURE, x, y, 0, 0, 0, 24, 24, 24, 24);
        }
        
        graphics.method_51428(stack, x + 4, y + 4, seed);
        graphics.method_51431(font, stack, x + 4, y + 4);
        
        if (isSelected) {
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            graphics.method_25291(BUNDLE_SLOT_HIGHLIGHT_FRONT_TEXTURE, x, y, 0, 0, 0, 24, 24, 24, 24);
            RenderSystem.disableBlend();
        }
    }
    
    private void renderCount(int x, int y, int value, class_327 font, class_332 graphics) {
        graphics.method_25300(font, "+" + value, x + 12, y + 10, -1);
    }
    
    private void drawSelectedItemTooltip(class_327 font, class_332 graphics, int x, int y, int width) {
        if (!this.hasSelectedItem()) return;
        
        class_1799 stack = this.contents.method_57422(this.getSelectedItem());
        class_5250 component = class_2561.method_43473().method_10852(stack.method_7964()).method_27692(stack.method_7932().method_58413());
        if (stack.method_57826(class_9334.field_49631)) {
            component.method_27692(class_124.field_1056);
        }
        
        int textWidth = font.method_30880(component.method_30937());
        int xOffset = x + (width / 2) - 12;
        graphics.method_51438(font, component, xOffset - (textWidth / 2), y - 15);
    }
    
    private void drawProgressBar(int x, int y, class_327 textRenderer, class_332 graphics) {
        graphics.method_52706(this.getProgressBarTexture(), x + 1, y, this.getProgressBarFill(), 13);
        graphics.method_52706(PROGRESSBAR_BORDER_SPRITE, x, y, getWidth(), 13);
        
        class_2561 component = this.getProgressBarFillText();
        if (component != null) {
            graphics.method_27534(textRenderer, component, x + (getWidth() / 2), y + 3, -1);
        }
    }
    
    private void drawEmptyBundleDescriptionText(int x, int y, class_327 font, class_332 graphics) {
        graphics.method_51440(font, BUNDLE_EMPTY_DESCRIPTION, x, y, getWidth(), -5592406);
    }
    
    private int getEmptyBundleDescriptionTextHeight(class_327 font) {
        return font.method_1728(BUNDLE_EMPTY_DESCRIPTION, getWidth()).size() * 9;
    }
    
    private int getProgressBarFill() {
        return class_3532.method_15340(class_3532.method_59515(this.contents.method_57428(), getWidth() - 2), 0, getWidth() - 2);
    }
    
    private class_2960 getProgressBarTexture() {
        return this.contents.method_57428().compareTo(Fraction.ONE) >= 0 ? PROGRESSBAR_FULL_SPRITE : PROGRESSBAR_FILL_SPRITE;
    }
    
    private class_2561 getProgressBarFillText() {
        if (this.contents.method_57429()) return BUNDLE_EMPTY;
        return this.contents.method_57428().compareTo(Fraction.ONE) >= 0 ? BUNDLE_FULL : null;
    }
}