package com.blackgear.vanillabackport.client.registries;

import com.blackgear.platform.core.helper.ParticleRegistry;
import com.blackgear.vanillabackport.client.level.particle.particleoptions.GeyserBaseParticleOptions;
import com.blackgear.vanillabackport.client.level.particle.particleoptions.GeyserParticleOptions;
import com.blackgear.vanillabackport.client.level.particle.particleoptions.TrailParticleOption;
import com.blackgear.vanillabackport.core.VanillaBackport;
import java.util.function.Supplier;
import net.minecraft.class_2338;
import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.minecraft.class_2400;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2675;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_9381;

public class ModParticles {
    public static final ParticleRegistry REGISTRIES = ParticleRegistry.create(VanillaBackport.NAMESPACE);

    public static final Supplier<class_2400> PALE_OAK_LEAVES = REGISTRIES.register("pale_oak_leaves", false);
    public static final Supplier<class_2396<TrailParticleOption>> TRAIL = REGISTRIES.register(
        "trail",
        false,
        particle -> TrailParticleOption.CODEC,
        particle -> TrailParticleOption.STREAM_CODEC
    );
    
    public static final Supplier<class_2400> FIREFLY = REGISTRIES.register("firefly", false);
    public static final Supplier<class_2396<class_9381>> TINTED_LEAVES = REGISTRIES.register(
        "tinted_leaves",
        false,
        class_9381::method_58254,
        class_9381::method_58261
    );
    public static final Supplier<class_2396<class_9381>> TINTED_NEEDLES = REGISTRIES.register(
        "tinted_needles",
        false,
        class_9381::method_58254,
        class_9381::method_58261
    );
    
    public static final Supplier<class_2400> COPPER_FIRE_FLAME = REGISTRIES.register("copper_fire_flame", false);
    
    public static final Supplier<class_2400> SULFUR_BUBBLES = REGISTRIES.register("sulfur_bubbles", false);
    public static final Supplier<class_2400> NOXIOUS_GAS = REGISTRIES.register("noxious_gas", false);
    public static final Supplier<class_2400> NOXIOUS_GAS_CLOUD = REGISTRIES.register("noxious_gas_cloud", false);
    public static final Supplier<class_2400> SULFUR_CUBE_GOO = REGISTRIES.register("sulfur_cube_goo", false);
    public static final Supplier<class_2396<GeyserParticleOptions>> GEYSER = REGISTRIES.register(
        "geyser",
        true,
        GeyserParticleOptions::codec,
        GeyserParticleOptions::streamCodec
    );
    public static final Supplier<class_2396<GeyserBaseParticleOptions>> GEYSER_BASE = REGISTRIES.register(
        "geyser_base",
        true,
        GeyserBaseParticleOptions::codec,
        GeyserBaseParticleOptions::streamCodec
    );
    public static final Supplier<class_2396<GeyserBaseParticleOptions>> GEYSER_POOF = REGISTRIES.register(
        "geyser_poof",
        true,
        GeyserBaseParticleOptions::codec,
        GeyserBaseParticleOptions::streamCodec
    );
    public static final Supplier<class_2396<GeyserParticleOptions>> GEYSER_PLUME = REGISTRIES.register(
        "geyser_plume",
        true,
        GeyserParticleOptions::codec,
        GeyserParticleOptions::streamCodec
    );
    public static final Supplier<class_2400> RED_POPLAR_LEAVES = REGISTRIES.register("red_poplar_leaves", false);
    public static final Supplier<class_2400> ORANGE_POPLAR_LEAVES = REGISTRIES.register("orange_poplar_leaves", false);
    public static final Supplier<class_2400> YELLOW_POPLAR_LEAVES = REGISTRIES.register("yellow_poplar_leaves", false);

    public static <T extends class_2394> int sendParticles(class_3218 level, T particle, double x, double y, double z, int particleCount, double xOffset, double yOffset, double zOffset, double speed) {
        return sendParticles(level, particle, false, false, x, y, z, particleCount, xOffset, yOffset, zOffset, speed);
    }

    public static <T extends class_2394> int sendParticles(class_3218 level, T particle, boolean longDistance, boolean overrideLimiter, double x, double y, double z, int particleCount, double xOffset, double yOffset, double zOffset, double speed) {
        class_2675 packet = new class_2675(particle, overrideLimiter, x, y, z, (float) xOffset, (float) yOffset, (float) zOffset, (float) speed, particleCount);
        int sent = 0;

        for (int i = 0; i < level.method_18456().size(); i++) {
            class_3222 player = level.method_18456().get(i);
            if (sendParticles(level, player, longDistance, x, y, z, packet)) {
                sent++;
            }
        }

        return sent;
    }

    public static <T extends class_2394> boolean sendParticles(class_3218 level, class_3222 player, T particle, boolean longDistance, boolean overrideLimiter, double x, double y, double z, int particleCount, double xOffset, double yOffset, double zOffset, double speed) {
        class_2675 packet = new class_2675(particle, overrideLimiter, x, y, z, (float) xOffset, (float) yOffset, (float) zOffset, (float) speed, particleCount);
        return sendParticles(level, player, longDistance, x, y, z, packet);
    }

    private static boolean sendParticles(class_3218 level, class_3222 player, boolean longDistance, double x, double y, double z, class_2596<?> packet) {
        if (player.method_37908() != level) {
            return false;
        } else {
            class_2338 pos = player.method_24515();
            if (pos.method_19769(new class_243(x, y, z), longDistance ? 512.0 : 32.0)) {
                player.field_13987.method_14364(packet);
                return true;
            } else {
                return false;
            }
        }
    }
}