package com.blackgear.vanillabackport.client.registries;

import com.blackgear.platform.core.helper.SoundRegistry;
import com.blackgear.vanillabackport.core.VanillaBackport;
import java.util.function.Supplier;
import net.minecraft.class_3414;
import net.minecraft.class_6880;

public class ModSoundEvents {
    public static final SoundRegistry REGISTRIES = SoundRegistry.create(VanillaBackport.NAMESPACE);

    // BLOCKS
    public static final Supplier<class_3414> EYEBLOSSOM_OPEN_LONG = REGISTRIES.soundEvent("block.eyeblossom.open_long");
    public static final Supplier<class_3414> EYEBLOSSOM_OPEN = REGISTRIES.soundEvent("block.eyeblossom.open");
    public static final Supplier<class_3414> EYEBLOSSOM_CLOSE_LONG = REGISTRIES.soundEvent("block.eyeblossom.close_long");
    public static final Supplier<class_3414> EYEBLOSSOM_CLOSE = REGISTRIES.soundEvent("block.eyeblossom.close");
    public static final Supplier<class_3414> EYEBLOSSOM_IDLE = REGISTRIES.soundEvent("block.eyeblossom.idle");

    public static final Supplier<class_3414> PALE_HANGING_MOSS_IDLE = REGISTRIES.soundEvent("block.pale_hanging_moss.idle");

    public static final Supplier<class_3414> CREAKING_HEART_BREAK = REGISTRIES.soundEvent("block.creaking_heart.break");
    public static final Supplier<class_3414> CREAKING_HEART_FALL = REGISTRIES.soundEvent("block.creaking_heart.fall");
    public static final Supplier<class_3414> CREAKING_HEART_HIT = REGISTRIES.soundEvent("block.creaking_heart.hit");
    public static final Supplier<class_3414> CREAKING_HEART_HURT = REGISTRIES.soundEvent("block.creaking_heart.hurt");
    public static final Supplier<class_3414> CREAKING_HEART_PLACE = REGISTRIES.soundEvent("block.creaking_heart.place");
    public static final Supplier<class_3414> CREAKING_HEART_STEP = REGISTRIES.soundEvent("block.creaking_heart.step");
    public static final Supplier<class_3414> CREAKING_HEART_IDLE = REGISTRIES.soundEvent("block.creaking_heart.idle");
    public static final Supplier<class_3414> CREAKING_HEART_SPAWN = REGISTRIES.soundEvent("block.creaking_heart.spawn");

    public static final Supplier<class_3414> RESIN_BREAK = REGISTRIES.soundEvent("block.resin.break");
    public static final Supplier<class_3414> RESIN_FALL = REGISTRIES.soundEvent("block.resin.fall");
    public static final Supplier<class_3414> RESIN_PLACE = REGISTRIES.soundEvent("block.resin.place");
    public static final Supplier<class_3414> RESIN_STEP = REGISTRIES.soundEvent("block.resin.step");

    public static final Supplier<class_3414> RESIN_BRICKS_BREAK = REGISTRIES.soundEvent("block.resin_bricks.break");
    public static final Supplier<class_3414> RESIN_BRICKS_FALL = REGISTRIES.soundEvent("block.resin_bricks.fall");
    public static final Supplier<class_3414> RESIN_BRICKS_HIT = REGISTRIES.soundEvent("block.resin_bricks.hit");
    public static final Supplier<class_3414> RESIN_BRICKS_PLACE = REGISTRIES.soundEvent("block.resin_bricks.place");
    public static final Supplier<class_3414> RESIN_BRICKS_STEP = REGISTRIES.soundEvent("block.resin_bricks.step");

    public static final Supplier<class_3414> DRIED_GHAST_BREAK = REGISTRIES.soundEvent("block.dried_ghast.break");
    public static final Supplier<class_3414> DRIED_GHAST_STEP = REGISTRIES.soundEvent("block.dried_ghast.step");
    public static final Supplier<class_3414> DRIED_GHAST_FALL = REGISTRIES.soundEvent("block.dried_ghast.fall");
    public static final Supplier<class_3414> DRIED_GHAST_AMBIENT = REGISTRIES.soundEvent("block.dried_ghast.ambient");
    public static final Supplier<class_3414> DRIED_GHAST_AMBIENT_WATER = REGISTRIES.soundEvent("block.dried_ghast.ambient_water");
    public static final Supplier<class_3414> DRIED_GHAST_PLACE = REGISTRIES.soundEvent("block.dried_ghast.place");
    public static final Supplier<class_3414> DRIED_GHAST_PLACE_IN_WATER = REGISTRIES.soundEvent("block.dried_ghast.place_in_water");
    public static final Supplier<class_3414> DRIED_GHAST_TRANSITION = REGISTRIES.soundEvent("block.dried_ghast.transition");

    public static final Supplier<class_3414> LEAF_LITTER_BREAK = REGISTRIES.soundEvent("block.leaf_litter.break");
    public static final Supplier<class_3414> LEAF_LITTER_STEP = REGISTRIES.soundEvent("block.leaf_litter.step");
    public static final Supplier<class_3414> LEAF_LITTER_PLACE = REGISTRIES.soundEvent("block.leaf_litter.place");
    public static final Supplier<class_3414> LEAF_LITTER_HIT = REGISTRIES.soundEvent("block.leaf_litter.hit");
    public static final Supplier<class_3414> LEAF_LITTER_FALL = REGISTRIES.soundEvent("block.leaf_litter.fall");

    public static final Supplier<class_3414> CACTUS_FLOWER_BREAK = REGISTRIES.soundEvent("block.cactus_flower.break");
    public static final Supplier<class_3414> CACTUS_FLOWER_PLACE = REGISTRIES.soundEvent("block.cactus_flower.place");

    public static final Supplier<class_3414> FIREFLY_BUSH_IDLE = REGISTRIES.soundEvent("block.firefly_bush.idle");
    public static final Supplier<class_3414> SAND_IDLE = REGISTRIES.soundEvent("block.sand.idle");
    public static final Supplier<class_3414> DEAD_BUSH_IDLE = REGISTRIES.soundEvent("block.deadbush.idle");
    public static final Supplier<class_3414> DRY_GRASS = REGISTRIES.soundEvent("block.dry_grass.ambient");

    public static final Supplier<class_3414> SULFUR_BREAK = REGISTRIES.soundEvent("block.sulfur.break");
    public static final Supplier<class_3414> SULFUR_STEP = REGISTRIES.soundEvent("block.sulfur.step");
    public static final Supplier<class_3414> SULFUR_PLACE = REGISTRIES.soundEvent("block.sulfur.place");
    public static final Supplier<class_3414> SULFUR_HIT = REGISTRIES.soundEvent("block.sulfur.hit");
    public static final Supplier<class_3414> SULFUR_FALL = REGISTRIES.soundEvent("block.sulfur.fall");

    public static final Supplier<class_3414> POTENT_SULFUR_BREAK = REGISTRIES.soundEvent("block.potent_sulfur.break");
    public static final Supplier<class_3414> POTENT_SULFUR_STEP = REGISTRIES.soundEvent("block.potent_sulfur.step");
    public static final Supplier<class_3414> POTENT_SULFUR_PLACE = REGISTRIES.soundEvent("block.potent_sulfur.place");
    public static final Supplier<class_3414> POTENT_SULFUR_HIT = REGISTRIES.soundEvent("block.potent_sulfur.hit");
    public static final Supplier<class_3414> POTENT_SULFUR_FALL = REGISTRIES.soundEvent("block.potent_sulfur.fall");

    public static final Supplier<class_3414> CINNABAR_BREAK = REGISTRIES.soundEvent("block.cinnabar.break");
    public static final Supplier<class_3414> CINNABAR_STEP = REGISTRIES.soundEvent("block.cinnabar.step");
    public static final Supplier<class_3414> CINNABAR_PLACE = REGISTRIES.soundEvent("block.cinnabar.place");
    public static final Supplier<class_3414> CINNABAR_HIT = REGISTRIES.soundEvent("block.cinnabar.hit");
    public static final Supplier<class_3414> CINNABAR_FALL = REGISTRIES.soundEvent("block.cinnabar.fall");

    public static final Supplier<class_3414> NOXIOUS_GAS = REGISTRIES.soundEvent("block.potent_sulfur.noxious_gas");
    public static final Supplier<class_3414> GEYSER_ERUPTION_START = REGISTRIES.soundEvent("block.potent_sulfur.geyser_eruption");
    public static final Supplier<class_3414> GEYSER_ERUPTION_ACTIVE = REGISTRIES.soundEvent("block.potent_sulfur.geyser_eruption_active");
    public static final Supplier<class_3414> GEYSER_CONTINUOUS_START = REGISTRIES.soundEvent("block.potent_sulfur.geyser_continuous_eruption_start");
    public static final Supplier<class_3414> GEYSER_CONTINUOUS_ACTIVE = REGISTRIES.soundEvent("block.potent_sulfur.geyser_continuous_eruption_active");
    
    public static final Supplier<class_3414> COPPER_CHEST_CLOSE = REGISTRIES.soundEvent("block.copper_chest.close");
    public static final Supplier<class_3414> COPPER_CHEST_OPEN = REGISTRIES.soundEvent("block.copper_chest.open");
    public static final Supplier<class_3414> COPPER_CHEST_WEATHERED_CLOSE = REGISTRIES.soundEvent("block.copper_chest_weathered.close");
    public static final Supplier<class_3414> COPPER_CHEST_WEATHERED_OPEN = REGISTRIES.soundEvent("block.copper_chest_weathered.open");
    public static final Supplier<class_3414> COPPER_CHEST_OXIDIZED_CLOSE = REGISTRIES.soundEvent("block.copper_chest_oxidized.close");
    public static final Supplier<class_3414> COPPER_CHEST_OXIDIZED_OPEN = REGISTRIES.soundEvent("block.copper_chest_oxidized.open");
    
    public static final Supplier<class_3414> COPPER_GOLEM_STATUE_BREAK = REGISTRIES.soundEvent("block.copper_golem_statue.break");
    public static final Supplier<class_3414> COPPER_GOLEM_STATUE_PLACE = REGISTRIES.soundEvent("block.copper_golem_statue.place");
    public static final Supplier<class_3414> COPPER_GOLEM_STATUE_HIT = REGISTRIES.soundEvent("block.copper_golem_statue.hit");
    public static final Supplier<class_3414> COPPER_GOLEM_STATUE_STEP = REGISTRIES.soundEvent("block.copper_golem_statue.step");
    public static final Supplier<class_3414> COPPER_GOLEM_STATUE_FALL = REGISTRIES.soundEvent("block.copper_golem_statue.fall");
    
    public static final Supplier<class_3414> SHELF_ACTIVATE = REGISTRIES.soundEvent("block.shelf.activate");
    public static final Supplier<class_3414> SHELF_BREAK = REGISTRIES.soundEvent("block.shelf.break");
    public static final Supplier<class_3414> SHELF_DEACTIVATE = REGISTRIES.soundEvent("block.shelf.deactivate");
    public static final Supplier<class_3414> SHELF_FALL = REGISTRIES.soundEvent("block.shelf.fall");
    public static final Supplier<class_3414> SHELF_HIT = REGISTRIES.soundEvent("block.shelf.hit");
    public static final Supplier<class_3414> SHELF_MULTI_SWAP = REGISTRIES.soundEvent("block.shelf.multi_swap");
    public static final Supplier<class_3414> SHELF_PLACE = REGISTRIES.soundEvent("block.shelf.place");
    public static final Supplier<class_3414> SHELF_PLACE_ITEM = REGISTRIES.soundEvent("block.shelf.place_item");
    public static final Supplier<class_3414> SHELF_SINGLE_SWAP = REGISTRIES.soundEvent("block.shelf.single_swap");
    public static final Supplier<class_3414> SHELF_STEP = REGISTRIES.soundEvent("block.shelf.step");
    public static final Supplier<class_3414> SHELF_TAKE_ITEM = REGISTRIES.soundEvent("block.shelf.take_item");
    
    // ITEMS
    public static final Supplier<class_3414> BUNDLE_INSERT_FAIL = REGISTRIES.soundEvent("item.bundle.insert_fail");
    
    public static final class_6880<class_3414> ARMOR_EQUIP_COPPER = REGISTRIES.holder("item.armor.equip_copper");
    
    public static final class_6880<class_3414> LUNGE_1 = REGISTRIES.holder("item.spear.lunge_1");
    public static final class_6880<class_3414> LUNGE_2 = REGISTRIES.holder("item.spear.lunge_2");
    public static final class_6880<class_3414> LUNGE_3 = REGISTRIES.holder("item.spear.lunge_3");
    public static final class_6880<class_3414> SPEAR_USE = REGISTRIES.holder("item.spear.use");
    public static final class_6880<class_3414> SPEAR_HIT = REGISTRIES.holder("item.spear.hit");
    public static final class_6880<class_3414> SPEAR_ATTACK = REGISTRIES.holder("item.spear.attack");
    public static final class_6880<class_3414> SPEAR_WOOD_USE = REGISTRIES.holder("item.spear_wood.use");
    public static final class_6880<class_3414> SPEAR_WOOD_HIT = REGISTRIES.holder("item.spear_wood.hit");
    public static final class_6880<class_3414> SPEAR_WOOD_ATTACK = REGISTRIES.holder("item.spear_wood.attack");

    public static final Supplier<class_3414> BUCKET_EMPTY_SULFUR_CUBE = REGISTRIES.soundEvent("item.bucket.empty_sulfur_cube");
    public static final Supplier<class_3414> BUCKET_FILL_SULFUR_CUBE = REGISTRIES.soundEvent("item.bucket.fill_sulfur_cube");

    // ENTITIES
    public static final Supplier<class_3414> CREAKING_AMBIENT = REGISTRIES.soundEvent("entity.creaking.ambient");
    public static final Supplier<class_3414> CREAKING_ACTIVATE = REGISTRIES.soundEvent("entity.creaking.activate");
    public static final Supplier<class_3414> CREAKING_DEACTIVATE = REGISTRIES.soundEvent("entity.creaking.deactivate");
    public static final Supplier<class_3414> CREAKING_ATTACK = REGISTRIES.soundEvent("entity.creaking.attack");
    public static final Supplier<class_3414> CREAKING_DEATH = REGISTRIES.soundEvent("entity.creaking.death");
    public static final Supplier<class_3414> CREAKING_STEP = REGISTRIES.soundEvent("entity.creaking.step");
    public static final Supplier<class_3414> CREAKING_FREEZE = REGISTRIES.soundEvent("entity.creaking.freeze");
    public static final Supplier<class_3414> CREAKING_UNFREEZE = REGISTRIES.soundEvent("entity.creaking.unfreeze");
    public static final Supplier<class_3414> CREAKING_SPAWN = REGISTRIES.soundEvent("entity.creaking.spawn");
    public static final Supplier<class_3414> CREAKING_SWAY = REGISTRIES.soundEvent("entity.creaking.sway");
    public static final Supplier<class_3414> CREAKING_TWITCH = REGISTRIES.soundEvent("entity.creaking.twitch");

    public static final Supplier<class_3414> GHASTLING_AMBIENT = REGISTRIES.soundEvent("entity.ghastling.ambient");
    public static final Supplier<class_3414> GHASTLING_DEATH = REGISTRIES.soundEvent("entity.ghastling.death");
    public static final Supplier<class_3414> GHASTLING_HURT = REGISTRIES.soundEvent("entity.ghastling.hurt");
    public static final Supplier<class_3414> GHASTLING_SPAWN = REGISTRIES.soundEvent("entity.ghastling.spawn");

    public static final Supplier<class_3414> HAPPY_GHAST_AMBIENT = REGISTRIES.soundEvent("entity.happy_ghast.ambient");
    public static final Supplier<class_3414> HAPPY_GHAST_DEATH = REGISTRIES.soundEvent("entity.happy_ghast.death");
    public static final Supplier<class_3414> HAPPY_GHAST_HURT = REGISTRIES.soundEvent("entity.happy_ghast.hurt");
    public static final Supplier<class_3414> HAPPY_GHAST_RIDING = REGISTRIES.soundEvent("entity.happy_ghast.riding");

    public static final Supplier<class_3414> HARNESS_EQUIP = REGISTRIES.soundEvent("entity.happy_ghast.equip");
    public static final Supplier<class_3414> HARNESS_UNEQUIP = REGISTRIES.soundEvent("entity.happy_ghast.unequip");
    public static final Supplier<class_3414> HARNESS_GOGGLES_UP = REGISTRIES.soundEvent("entity.happy_ghast.harness_goggles_up");
    public static final Supplier<class_3414> HARNESS_GOGGLES_DOWN = REGISTRIES.soundEvent("entity.happy_ghast.harness_goggles_down");

    public static final Supplier<class_3414> PARROT_IMITATE_CREAKING = REGISTRIES.soundEvent("entity.parrot.imitate.creaking");
    public static final Supplier<class_3414> PARROT_IMITATE_PARCHED = REGISTRIES.register("entity.parrot.imitate.parched");
    public static final Supplier<class_3414> PARROT_IMITATE_CAMEL_HUSK = REGISTRIES.register("entity.parrot.imitate.camel_husk");
    
    public static final Supplier<class_3414> WOLF_PUGLIN_AMBIENT = REGISTRIES.soundEvent("entity.wolf_puglin.ambient");
    public static final Supplier<class_3414> WOLF_PUGLIN_DEATH = REGISTRIES.soundEvent("entity.wolf_puglin.death");
    public static final Supplier<class_3414> WOLF_PUGLIN_GROWL = REGISTRIES.soundEvent("entity.wolf_puglin.growl");
    public static final Supplier<class_3414> WOLF_PUGLIN_HURT = REGISTRIES.soundEvent("entity.wolf_puglin.hurt");
    public static final Supplier<class_3414> WOLF_PUGLIN_PANT = REGISTRIES.soundEvent("entity.wolf_puglin.pant");
    public static final Supplier<class_3414> WOLF_PUGLIN_WHINE = REGISTRIES.soundEvent("entity.wolf_puglin.whine");

    public static final Supplier<class_3414> WOLF_SAD_AMBIENT = REGISTRIES.soundEvent("entity.wolf_sad.ambient");
    public static final Supplier<class_3414> WOLF_SAD_DEATH = REGISTRIES.soundEvent("entity.wolf_sad.death");
    public static final Supplier<class_3414> WOLF_SAD_GROWL = REGISTRIES.soundEvent("entity.wolf_sad.growl");
    public static final Supplier<class_3414> WOLF_SAD_HURT = REGISTRIES.soundEvent("entity.wolf_sad.hurt");
    public static final Supplier<class_3414> WOLF_SAD_PANT = REGISTRIES.soundEvent("entity.wolf_sad.pant");
    public static final Supplier<class_3414> WOLF_SAD_WHINE = REGISTRIES.soundEvent("entity.wolf_sad.whine");

    public static final Supplier<class_3414> WOLF_ANGRY_AMBIENT = REGISTRIES.soundEvent("entity.wolf_angry.ambient");
    public static final Supplier<class_3414> WOLF_ANGRY_DEATH = REGISTRIES.soundEvent("entity.wolf_angry.death");
    public static final Supplier<class_3414> WOLF_ANGRY_GROWL = REGISTRIES.soundEvent("entity.wolf_angry.growl");
    public static final Supplier<class_3414> WOLF_ANGRY_HURT = REGISTRIES.soundEvent("entity.wolf_angry.hurt");
    public static final Supplier<class_3414> WOLF_ANGRY_PANT = REGISTRIES.soundEvent("entity.wolf_angry.pant");
    public static final Supplier<class_3414> WOLF_ANGRY_WHINE = REGISTRIES.soundEvent("entity.wolf_angry.whine");

    public static final Supplier<class_3414> WOLF_GRUMPY_AMBIENT = REGISTRIES.soundEvent("entity.wolf_grumpy.ambient");
    public static final Supplier<class_3414> WOLF_GRUMPY_DEATH = REGISTRIES.soundEvent("entity.wolf_grumpy.death");
    public static final Supplier<class_3414> WOLF_GRUMPY_GROWL = REGISTRIES.soundEvent("entity.wolf_grumpy.growl");
    public static final Supplier<class_3414> WOLF_GRUMPY_HURT = REGISTRIES.soundEvent("entity.wolf_grumpy.hurt");
    public static final Supplier<class_3414> WOLF_GRUMPY_PANT = REGISTRIES.soundEvent("entity.wolf_grumpy.pant");
    public static final Supplier<class_3414> WOLF_GRUMPY_WHINE = REGISTRIES.soundEvent("entity.wolf_grumpy.whine");

    public static final Supplier<class_3414> WOLF_BIG_AMBIENT = REGISTRIES.soundEvent("entity.wolf_big.ambient");
    public static final Supplier<class_3414> WOLF_BIG_DEATH = REGISTRIES.soundEvent("entity.wolf_big.death");
    public static final Supplier<class_3414> WOLF_BIG_GROWL = REGISTRIES.soundEvent("entity.wolf_big.growl");
    public static final Supplier<class_3414> WOLF_BIG_HURT = REGISTRIES.soundEvent("entity.wolf_big.hurt");
    public static final Supplier<class_3414> WOLF_BIG_PANT = REGISTRIES.soundEvent("entity.wolf_big.pant");
    public static final Supplier<class_3414> WOLF_BIG_WHINE = REGISTRIES.soundEvent("entity.wolf_big.whine");

    public static final Supplier<class_3414> WOLF_CUTE_AMBIENT = REGISTRIES.soundEvent("entity.wolf_cute.ambient");
    public static final Supplier<class_3414> WOLF_CUTE_DEATH = REGISTRIES.soundEvent("entity.wolf_cute.death");
    public static final Supplier<class_3414> WOLF_CUTE_GROWL = REGISTRIES.soundEvent("entity.wolf_cute.growl");
    public static final Supplier<class_3414> WOLF_CUTE_HURT = REGISTRIES.soundEvent("entity.wolf_cute.hurt");
    public static final Supplier<class_3414> WOLF_CUTE_PANT = REGISTRIES.soundEvent("entity.wolf_cute.pant");
    public static final Supplier<class_3414> WOLF_CUTE_WHINE = REGISTRIES.soundEvent("entity.wolf_cute.whine");

    public static final Supplier<class_3414> SULFUR_CUBE_ABSORB = REGISTRIES.soundEvent("entity.sulfur_cube.absorb");
    public static final Supplier<class_3414> SULFUR_CUBE_BOUNCE = REGISTRIES.soundEvent("entity.sulfur_cube.bounce");
    public static final Supplier<class_3414> SULFUR_CUBE_DEATH = REGISTRIES.soundEvent("entity.sulfur_cube.death");
    public static final Supplier<class_3414> SULFUR_CUBE_EJECT = REGISTRIES.soundEvent("entity.sulfur_cube.eject");
    public static final Supplier<class_3414> SULFUR_CUBE_HURT = REGISTRIES.soundEvent("entity.sulfur_cube.hurt");
    public static final Supplier<class_3414> SULFUR_CUBE_JUMP = REGISTRIES.soundEvent("entity.sulfur_cube.jump");

    public static final class_6880<class_3414> SULFUR_CUBE_REGULAR_HIT = REGISTRIES.holder("entity.sulfur_cube.regular.hit");
    public static final class_6880<class_3414> SULFUR_CUBE_REGULAR_PUSH = REGISTRIES.holder("entity.sulfur_cube.regular.push");
    public static final class_6880<class_3414> SULFUR_CUBE_BOUNCY_HIT = REGISTRIES.holder("entity.sulfur_cube.bouncy.hit");
    public static final class_6880<class_3414> SULFUR_CUBE_BOUNCY_PUSH = REGISTRIES.holder("entity.sulfur_cube.bouncy.push");
    public static final class_6880<class_3414> SULFUR_CUBE_SLOW_BOUNCY_HIT = REGISTRIES.holder("entity.sulfur_cube.slow_bouncy.hit");
    public static final class_6880<class_3414> SULFUR_CUBE_SLOW_BOUNCY_PUSH = REGISTRIES.holder("entity.sulfur_cube.slow_bouncy.push");
    public static final class_6880<class_3414> SULFUR_CUBE_SLOW_FLAT_HIT = REGISTRIES.holder("entity.sulfur_cube.slow_flat.hit");
    public static final class_6880<class_3414> SULFUR_CUBE_SLOW_FLAT_PUSH = REGISTRIES.holder("entity.sulfur_cube.slow_flat.push");
    public static final class_6880<class_3414> SULFUR_CUBE_FAST_FLAT_HIT = REGISTRIES.holder("entity.sulfur_cube.fast_flat.hit");
    public static final class_6880<class_3414> SULFUR_CUBE_FAST_FLAT_PUSH = REGISTRIES.holder("entity.sulfur_cube.fast_flat.push");
    public static final class_6880<class_3414> SULFUR_CUBE_LIGHT_HIT = REGISTRIES.holder("entity.sulfur_cube.light.hit");
    public static final class_6880<class_3414> SULFUR_CUBE_LIGHT_PUSH = REGISTRIES.holder("entity.sulfur_cube.light.push");
    public static final class_6880<class_3414> SULFUR_CUBE_FAST_SLIDING_HIT = REGISTRIES.holder("entity.sulfur_cube.fast_sliding.hit");
    public static final class_6880<class_3414> SULFUR_CUBE_FAST_SLIDING_PUSH = REGISTRIES.holder("entity.sulfur_cube.fast_sliding.push");
    public static final class_6880<class_3414> SULFUR_CUBE_SLOW_SLIDING_HIT = REGISTRIES.holder("entity.sulfur_cube.slow_sliding.hit");
    public static final class_6880<class_3414> SULFUR_CUBE_SLOW_SLIDING_PUSH = REGISTRIES.holder("entity.sulfur_cube.slow_sliding.push");
    public static final class_6880<class_3414> SULFUR_CUBE_STICKY_HIT = REGISTRIES.holder("entity.sulfur_cube.sticky.hit");
    public static final class_6880<class_3414> SULFUR_CUBE_STICKY_PUSH = REGISTRIES.holder("entity.sulfur_cube.sticky.push");
    public static final class_6880<class_3414> SULFUR_CUBE_HIGH_RESISTANCE_HIT = REGISTRIES.holder("entity.sulfur_cube.high_resistance.hit");
    public static final class_6880<class_3414> SULFUR_CUBE_HIGH_RESISTANCE_PUSH = REGISTRIES.holder("entity.sulfur_cube.high_resistance.push");
    public static final class_6880<class_3414> SULFUR_CUBE_EXPLOSIVE_HIT = REGISTRIES.holder("entity.sulfur_cube.explosive.hit");
    public static final class_6880<class_3414> SULFUR_CUBE_EXPLOSIVE_PUSH = REGISTRIES.holder("entity.sulfur_cube.explosive.push");
    public static final class_6880<class_3414> SULFUR_CUBE_HOT_HIT = REGISTRIES.holder("entity.sulfur_cube.hot.hit");
    public static final class_6880<class_3414> SULFUR_CUBE_HOT_PUSH = REGISTRIES.holder("entity.sulfur_cube.hot.push");

    public static final Supplier<class_3414> SULFUR_CUBE_SQUISH = REGISTRIES.soundEvent("entity.sulfur_cube.squish");

    public static final Supplier<class_3414> SULFUR_CUBE_SMALL_DEATH = REGISTRIES.soundEvent("entity.small_sulfur_cube.death");
    public static final Supplier<class_3414> SULFUR_CUBE_SMALL_HURT = REGISTRIES.soundEvent("entity.small_sulfur_cube.hurt");
    public static final Supplier<class_3414> SULFUR_CUBE_SMALL_JUMP = REGISTRIES.soundEvent("entity.small_sulfur_cube.jump");
    public static final Supplier<class_3414> SULFUR_CUBE_SMALL_SQUISH = REGISTRIES.soundEvent("entity.small_sulfur_cube.squish");
    public static final Supplier<class_3414> SULFUR_CUBE_SMALL_EAT = REGISTRIES.soundEvent("entity.small_sulfur_cube.eat");
    
    public static final Supplier<class_3414> COPPER_GOLEM_STEP = REGISTRIES.soundEvent("entity.copper_golem.step");
    public static final Supplier<class_3414> COPPER_GOLEM_HURT = REGISTRIES.soundEvent("entity.copper_golem.hurt");
    public static final Supplier<class_3414> COPPER_GOLEM_DEATH = REGISTRIES.soundEvent("entity.copper_golem.death");
    
    public static final Supplier<class_3414> COPPER_GOLEM_WEATHERED_STEP = REGISTRIES.soundEvent("entity.copper_golem_weathered.step");
    public static final Supplier<class_3414> COPPER_GOLEM_WEATHERED_HURT = REGISTRIES.soundEvent("entity.copper_golem_weathered.hurt");
    public static final Supplier<class_3414> COPPER_GOLEM_WEATHERED_DEATH = REGISTRIES.soundEvent("entity.copper_golem_weathered.death");
    
    public static final Supplier<class_3414> COPPER_GOLEM_OXIDIZED_STEP = REGISTRIES.soundEvent("entity.copper_golem_oxidized.step");
    public static final Supplier<class_3414> COPPER_GOLEM_OXIDIZED_HURT = REGISTRIES.soundEvent("entity.copper_golem_oxidized.hurt");
    public static final Supplier<class_3414> COPPER_GOLEM_OXIDIZED_DEATH = REGISTRIES.soundEvent("entity.copper_golem_oxidized.death");
    
    public static final Supplier<class_3414> COPPER_GOLEM_SPIN = REGISTRIES.soundEvent("entity.copper_golem.spin");
    public static final Supplier<class_3414> COPPER_GOLEM_WEATHERED_SPIN = REGISTRIES.soundEvent("entity.copper_golem_weathered.spin");
    public static final Supplier<class_3414> COPPER_GOLEM_OXIDIZED_SPIN = REGISTRIES.soundEvent("entity.copper_golem_oxidized.spin");
    
    public static final Supplier<class_3414> COPPER_GOLEM_ITEM_GET = REGISTRIES.soundEvent("entity.copper_golem.no_item_get");
    public static final Supplier<class_3414> COPPER_GOLEM_ITEM_NO_GET = REGISTRIES.soundEvent("entity.copper_golem.no_item_no_get");
    public static final Supplier<class_3414> COPPER_GOLEM_ITEM_DROP = REGISTRIES.soundEvent("entity.copper_golem.item_drop");
    public static final Supplier<class_3414> COPPER_GOLEM_ITEM_NO_DROP = REGISTRIES.soundEvent("entity.copper_golem.item_no_drop");
    
    public static final Supplier<class_3414> COPPER_GOLEM_BECOME_STATUE = REGISTRIES.soundEvent("entity.copper_golem_become_statue");
    public static final Supplier<class_3414> COPPER_GOLEM_SPAWN = REGISTRIES.soundEvent("entity.copper_golem.spawn");
    public static final Supplier<class_3414> COPPER_GOLEM_SHEAR = REGISTRIES.soundEvent("entity.copper_golem.shear");
    
    public static final Supplier<class_3414> PARCHED_AMBIENT = REGISTRIES.register("entity.parched.ambient");
    public static final Supplier<class_3414> PARCHED_DEATH = REGISTRIES.register("entity.parched.death");
    public static final Supplier<class_3414> PARCHED_HURT = REGISTRIES.register("entity.parched.hurt");
    public static final Supplier<class_3414> PARCHED_STEP = REGISTRIES.register("entity.parched.step");
    
    public static final Supplier<class_3414> CAMEL_HUSK_AMBIENT = REGISTRIES.register("entity.camel_husk.ambient");
    public static final Supplier<class_3414> CAMEL_HUSK_DASH = REGISTRIES.register("entity.camel_husk.dash");
    public static final Supplier<class_3414> CAMEL_HUSK_DASH_READY = REGISTRIES.register("entity.camel_husk.dash_ready");
    public static final Supplier<class_3414> CAMEL_HUSK_DEATH = REGISTRIES.register("entity.camel_husk.death");
    public static final Supplier<class_3414> CAMEL_HUSK_EAT = REGISTRIES.register("entity.camel_husk.eat");
    public static final Supplier<class_3414> CAMEL_HUSK_HURT = REGISTRIES.register("entity.camel_husk.hurt");
    public static final Supplier<class_3414> CAMEL_HUSK_SADDLE = REGISTRIES.register("entity.camel_husk.saddle");
    public static final Supplier<class_3414> CAMEL_HUSK_SIT = REGISTRIES.register("entity.camel_husk.sit");
    public static final Supplier<class_3414> CAMEL_HUSK_STAND = REGISTRIES.register("entity.camel_husk.stand");
    public static final Supplier<class_3414> CAMEL_HUSK_STEP = REGISTRIES.register("entity.camel_husk.step");
    public static final Supplier<class_3414> CAMEL_HUSK_STEP_SAND = REGISTRIES.register("entity.camel_husk.step_sand");
    
    public static final Supplier<class_3414> ZOMBIE_HORSE_ANGRY = REGISTRIES.register("entity.zombie_horse.angry");
    public static final Supplier<class_3414> ZOMBIE_HORSE_EAT = REGISTRIES.register("entity.zombie_horse.eat");
    
    public static final Supplier<class_3414> NAUTILUS_AMBIENT = REGISTRIES.register("entity.nautilus.ambient");
    public static final Supplier<class_3414> NAUTILUS_AMBIENT_ON_LAND = REGISTRIES.register("entity.nautilus.ambient_land");
    public static final Supplier<class_3414> NAUTILUS_DASH = REGISTRIES.register("entity.nautilus.dash");
    public static final Supplier<class_3414> NAUTILUS_DASH_ON_LAND = REGISTRIES.register("entity.nautilus.dash_land");
    public static final Supplier<class_3414> NAUTILUS_DASH_READY = REGISTRIES.register("entity.nautilus.dash_ready");
    public static final Supplier<class_3414> NAUTILUS_DASH_READY_ON_LAND = REGISTRIES.register("entity.nautilus.dash_ready_land");
    public static final Supplier<class_3414> NAUTILUS_DEATH = REGISTRIES.register("entity.nautilus.death");
    public static final Supplier<class_3414> NAUTILUS_DEATH_ON_LAND = REGISTRIES.register("entity.nautilus.death_land");
    public static final Supplier<class_3414> NAUTILUS_EAT = REGISTRIES.register("entity.nautilus.eat");
    public static final Supplier<class_3414> NAUTILUS_HURT = REGISTRIES.register("entity.nautilus.hurt");
    public static final Supplier<class_3414> NAUTILUS_HURT_ON_LAND = REGISTRIES.register("entity.nautilus.hurt_land");
    public static final Supplier<class_3414> NAUTILUS_SWIM = REGISTRIES.register("entity.nautilus.swim");
    
    public static final Supplier<class_3414> NAUTILUS_RIDING = REGISTRIES.register("entity.nautilus.riding");
    
    public static final Supplier<class_3414> BABY_NAUTILUS_AMBIENT = REGISTRIES.register("entity.baby_nautilus.ambient");
    public static final Supplier<class_3414> BABY_NAUTILUS_AMBIENT_ON_LAND = REGISTRIES.register("entity.baby_nautilus.ambient_land");
    public static final Supplier<class_3414> BABY_NAUTILUS_DEATH = REGISTRIES.register("entity.baby_nautilus.death");
    public static final Supplier<class_3414> BABY_NAUTILUS_DEATH_ON_LAND = REGISTRIES.register("entity.baby_nautilus.death_land");
    public static final Supplier<class_3414> BABY_NAUTILUS_EAT = REGISTRIES.register("entity.baby_nautilus.eat");
    public static final Supplier<class_3414> BABY_NAUTILUS_HURT = REGISTRIES.register("entity.baby_nautilus.hurt");
    public static final Supplier<class_3414> BABY_NAUTILUS_HURT_ON_LAND = REGISTRIES.register("entity.baby_nautilus.hurt_land");
    public static final Supplier<class_3414> BABY_NAUTILUS_SWIM = REGISTRIES.register("entity.baby_nautilus.swim");
    
    public static final Supplier<class_3414> ZOMBIE_NAUTILUS_AMBIENT = REGISTRIES.register("entity.zombie_nautilus.ambient");
    public static final Supplier<class_3414> ZOMBIE_NAUTILUS_AMBIENT_ON_LAND = REGISTRIES.register("entity.zombie_nautilus.ambient_land");
    public static final Supplier<class_3414> ZOMBIE_NAUTILUS_DASH = REGISTRIES.register("entity.zombie_nautilus.dash");
    public static final Supplier<class_3414> ZOMBIE_NAUTILUS_DASH_ON_LAND = REGISTRIES.register("entity.zombie_nautilus.dash_land");
    public static final Supplier<class_3414> ZOMBIE_NAUTILUS_DASH_READY = REGISTRIES.register("entity.zombie_nautilus.dash_ready");
    public static final Supplier<class_3414> ZOMBIE_NAUTILUS_DASH_READY_ON_LAND = REGISTRIES.register("entity.zombie_nautilus.dash_ready_land");
    public static final Supplier<class_3414> ZOMBIE_NAUTILUS_DEATH = REGISTRIES.register("entity.zombie_nautilus.death");
    public static final Supplier<class_3414> ZOMBIE_NAUTILUS_DEATH_ON_LAND = REGISTRIES.register("entity.zombie_nautilus.death_land");
    public static final Supplier<class_3414> ZOMBIE_NAUTILUS_EAT = REGISTRIES.register("entity.zombie_nautilus.eat");
    public static final Supplier<class_3414> ZOMBIE_NAUTILUS_HURT = REGISTRIES.register("entity.zombie_nautilus.hurt");
    public static final Supplier<class_3414> ZOMBIE_NAUTILUS_HURT_ON_LAND = REGISTRIES.register("entity.zombie_nautilus.hurt_land");
    public static final Supplier<class_3414> ZOMBIE_NAUTILUS_SWIM = REGISTRIES.register("entity.zombie_nautilus.swim");
    
    public static final Supplier<class_3414> PARROT_IMITATE_ZOMBIE_NAUTILUS = REGISTRIES.register("entity.parrot.imitate.zombie_nautilus");
    
    public static final Supplier<class_3414> NAUTILUS_SADDLE_UNDERWATER_EQUIP = REGISTRIES.register("item.nautilus_saddle_underwater_equip");
    public static final Supplier<class_3414> NAUTILUS_SADDLE_EQUIP = REGISTRIES.register("item.nautilus_saddle_equip");
    public static final Supplier<class_3414> ARMOR_EQUIP_NAUTILUS = REGISTRIES.register("item.armor.equip_nautilus");
    public static final Supplier<class_3414> ARMOR_UNEQUIP_NAUTILUS = REGISTRIES.register("item.armor.unequip_nautilus");
    
    // MISCELLANEOUS
    public static final Supplier<class_3414> CUSHION_BREAK = REGISTRIES.register("entity.cushion.break");
    public static final Supplier<class_3414> CUSHION_PLACE = REGISTRIES.register("entity.cushion.place");
    public static final Supplier<class_3414> CUSHION_SIT = REGISTRIES.register("entity.cushion.sit");
    public static final Supplier<class_3414> CUSHION_GET_UP = REGISTRIES.register("entity.cushion.get_up");
    
    // WEATHER
    public static final Supplier<class_3414> WEATHER_END_FLASH = REGISTRIES.register("weather.end_flash");
    
    // BACKGROUND MUSIC
    public static final class_6880<class_3414> MUSIC_BIOME_SULFUR_CAVES = REGISTRIES.holder("music.overworld.sulfur_caves");

    // RECORDS
    public static final class_6880<class_3414> MUSIC_DISC_TEARS = REGISTRIES.holder("music_disc.tears");
    public static final class_6880<class_3414> MUSIC_DISC_LAVA_CHICKEN = REGISTRIES.holder("music_disc.lava_chicken");
    public static final class_6880<class_3414> MUSIC_DISC_BOUNCE = REGISTRIES.holder("music_disc.bounce");
    
    // Wilderness Bound
    
    public static final Supplier<class_3414> SHELF_MUSHROOM_BREAK = REGISTRIES.register("block.shelf_mushroom.break");
    public static final Supplier<class_3414> SHELF_MUSHROOM_FALL = REGISTRIES.register("block.shelf_mushroom.fall");
    public static final Supplier<class_3414> SHELF_MUSHROOM_PLACE = REGISTRIES.register("block.shelf_mushroom.place");
    public static final Supplier<class_3414> SHELF_MUSHROOM_STEP = REGISTRIES.register("block.shelf_mushroom.step");
    public static final Supplier<class_3414> SHELF_MUSHROOM_BOUNCE = REGISTRIES.register("block.shelf_mushroom.bounce");
    
    public static final Supplier<class_3414> POPLAR_LEAVES_BREAK = REGISTRIES.register("block.poplar_leaves.break");
    public static final Supplier<class_3414> POPLAR_LEAVES_HIT = REGISTRIES.register("block.poplar_leaves.hit");
    public static final Supplier<class_3414> POPLAR_LEAVES_FALL = REGISTRIES.register("block.poplar_leaves.fall");
    public static final Supplier<class_3414> POPLAR_LEAVES_PLACE = REGISTRIES.register("block.poplar_leaves.place");
    public static final Supplier<class_3414> POPLAR_LEAVES_STEP = REGISTRIES.register("block.poplar_leaves.step");
    public static final class_6880<class_3414> POPLAR_LEAVES_AMBIENT = REGISTRIES.holder("block.poplar_leaves.ambient");
    
    public static final Supplier<class_3414> STRAW_BED_BREAK = REGISTRIES.register("block.straw_bed.break");
    public static final Supplier<class_3414> STRAW_BED_BREAK_LEAVE = REGISTRIES.register("block.straw_bed.break_leave");
    public static final Supplier<class_3414> STRAW_BED_STEP = REGISTRIES.register("block.straw_bed.step");
    public static final Supplier<class_3414> STRAW_BED_PLACE = REGISTRIES.register("block.straw_bed.place");
    public static final Supplier<class_3414> STRAW_BED_HIT = REGISTRIES.register("block.straw_bed.hit");
    public static final Supplier<class_3414> STRAW_BED_FALL = REGISTRIES.register("block.straw_bed.fall");
    
    public static final Supplier<class_3414> RED_SHRUB_BREAK = REGISTRIES.register("block.red_shrub.break");
    public static final Supplier<class_3414> RED_SHRUB_PLACE = REGISTRIES.register("block.red_shrub.place");
}