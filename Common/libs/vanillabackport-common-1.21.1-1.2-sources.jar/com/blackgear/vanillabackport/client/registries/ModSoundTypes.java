package com.blackgear.vanillabackport.client.registries;

import com.blackgear.platform.core.helper.SoundRegistry;
import com.blackgear.vanillabackport.core.VanillaBackport;
import net.minecraft.class_2498;
import net.minecraft.class_3417;

public class ModSoundTypes {
    public static final SoundRegistry REGISTRIES = SoundRegistry.create(VanillaBackport.NAMESPACE);

    public static final class_2498 CREAKING_HEART = REGISTRIES.soundType(
        ModSoundEvents.CREAKING_HEART_BREAK,
        ModSoundEvents.CREAKING_HEART_STEP,
        ModSoundEvents.CREAKING_HEART_PLACE,
        ModSoundEvents.CREAKING_HEART_HIT,
        ModSoundEvents.CREAKING_HEART_FALL
    );
    public static final class_2498 RESIN = REGISTRIES.soundType(
        ModSoundEvents.RESIN_BREAK,
        ModSoundEvents.RESIN_STEP,
        ModSoundEvents.RESIN_PLACE,
        () -> class_3417.field_42593,
        ModSoundEvents.RESIN_FALL
    );
    public static final class_2498 RESIN_BRICKS = REGISTRIES.soundType(
        ModSoundEvents.RESIN_BRICKS_BREAK,
        ModSoundEvents.RESIN_BRICKS_STEP,
        ModSoundEvents.RESIN_BRICKS_PLACE,
        ModSoundEvents.RESIN_BRICKS_HIT,
        ModSoundEvents.RESIN_BRICKS_FALL
    );
    public static final class_2498 DRIED_GHAST = REGISTRIES.soundType(
        ModSoundEvents.DRIED_GHAST_BREAK,
        ModSoundEvents.DRIED_GHAST_STEP,
        () -> class_3417.field_42593,
        () -> class_3417.field_42593,
        ModSoundEvents.DRIED_GHAST_FALL
    );
    public static final class_2498 LEAF_LITTER = REGISTRIES.soundType(
        ModSoundEvents.LEAF_LITTER_BREAK,
        ModSoundEvents.LEAF_LITTER_STEP,
        ModSoundEvents.LEAF_LITTER_PLACE,
        ModSoundEvents.LEAF_LITTER_HIT,
        ModSoundEvents.LEAF_LITTER_FALL
    );
    public static final class_2498 CACTUS_FLOWER = REGISTRIES.soundType(
        ModSoundEvents.CACTUS_FLOWER_BREAK,
        () -> class_3417.field_42593,
        ModSoundEvents.CACTUS_FLOWER_PLACE,
        () -> class_3417.field_42593,
        () -> class_3417.field_42593
    );
    public static final class_2498 CINNABAR = REGISTRIES.soundType(
        ModSoundEvents.CINNABAR_BREAK,
        ModSoundEvents.CINNABAR_STEP,
        ModSoundEvents.CINNABAR_PLACE,
        ModSoundEvents.CINNABAR_HIT,
        ModSoundEvents.CINNABAR_FALL
    );
    public static final class_2498 SULFUR = REGISTRIES.soundType(
        ModSoundEvents.SULFUR_BREAK,
        ModSoundEvents.SULFUR_STEP,
        ModSoundEvents.SULFUR_PLACE,
        ModSoundEvents.SULFUR_HIT,
        ModSoundEvents.SULFUR_FALL
    );
    public static final class_2498 POTENT_SULFUR = REGISTRIES.soundType(
        ModSoundEvents.POTENT_SULFUR_BREAK,
        ModSoundEvents.POTENT_SULFUR_STEP,
        ModSoundEvents.POTENT_SULFUR_PLACE,
        ModSoundEvents.POTENT_SULFUR_HIT,
        ModSoundEvents.POTENT_SULFUR_FALL
    );
    public static final class_2498 COPPER_GOLEM_STATUE = REGISTRIES.soundType(
        ModSoundEvents.COPPER_GOLEM_STATUE_BREAK,
        ModSoundEvents.COPPER_GOLEM_STATUE_STEP,
        ModSoundEvents.COPPER_GOLEM_STATUE_PLACE,
        ModSoundEvents.COPPER_GOLEM_STATUE_HIT,
        ModSoundEvents.COPPER_GOLEM_STATUE_FALL
    );
    public static final class_2498 WOODEN_SHELF = REGISTRIES.soundType(
        ModSoundEvents.SHELF_BREAK,
        ModSoundEvents.SHELF_STEP,
        ModSoundEvents.SHELF_PLACE,
        ModSoundEvents.SHELF_HIT,
        ModSoundEvents.SHELF_FALL
    );
    public static final class_2498 SHELF_MUSHROOM = REGISTRIES.soundType(
        ModSoundEvents.SHELF_MUSHROOM_BREAK,
        ModSoundEvents.SHELF_MUSHROOM_STEP,
        ModSoundEvents.SHELF_MUSHROOM_PLACE,
        () -> class_3417.field_42593,
        ModSoundEvents.SHELF_MUSHROOM_FALL
    );
    public static final class_2498 POPLAR_LEAVES = REGISTRIES.soundType(
        ModSoundEvents.POPLAR_LEAVES_BREAK,
        ModSoundEvents.POPLAR_LEAVES_STEP,
        ModSoundEvents.POPLAR_LEAVES_PLACE,
        ModSoundEvents.POPLAR_LEAVES_HIT,
        ModSoundEvents.POPLAR_LEAVES_FALL
    );
    public static final class_2498 STRAW_BED = REGISTRIES.soundType(
        ModSoundEvents.STRAW_BED_BREAK,
        ModSoundEvents.STRAW_BED_STEP,
        ModSoundEvents.STRAW_BED_PLACE,
        ModSoundEvents.STRAW_BED_HIT,
        ModSoundEvents.STRAW_BED_FALL
    );
    public static final class_2498 RED_SHRUB = REGISTRIES.soundType(
        ModSoundEvents.RED_SHRUB_BREAK,
        () -> class_3417.field_42593,
        ModSoundEvents.RED_SHRUB_PLACE,
        () -> class_3417.field_42593,
        () -> class_3417.field_42593
    );
}