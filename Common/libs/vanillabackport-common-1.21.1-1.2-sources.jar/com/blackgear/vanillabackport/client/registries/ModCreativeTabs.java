package com.blackgear.vanillabackport.client.registries;

import com.blackgear.platform.core.CoreRegistry;
import com.blackgear.vanillabackport.client.api.bundled_tabs.BundledTabs;
import com.blackgear.vanillabackport.core.VanillaBackport;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_7924;

public interface ModCreativeTabs {
    CoreRegistry<class_1761> TABS = CoreRegistry.create(class_7924.field_44688, VanillaBackport.MOD_ID);

    Supplier<class_1761> VANILLA_BACKPORT = TABS.register(
        "vanilla_backport",
        () -> class_1761.method_47307(class_1761.class_7915.field_41049, 3)
            .method_47321(class_2561.method_43470("Vanilla Backport"))
            .method_47320(() -> new class_1799(class_1802.field_27023))
            .method_47317((parameters, output) -> {
                synchronized (ModCreativeTabs.class) {
                    var provider = parameters.comp_1253();
                    List<BundledTabs> tabs = ModBundledTabs.getTabs();

                    tabs.forEach(tab -> tab.populate(provider));
                    tabs.stream()
                        .flatMap(tab -> tab.getDisplayItems().stream())
                        .filter(stack -> !stack.method_7960())
                        .forEach(output::method_45420);
                }
            })
            .method_47324()
    );
}