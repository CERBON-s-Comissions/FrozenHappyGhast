package com.blackgear.vanillabackport.client.registries;

import com.blackgear.vanillabackport.client.api.bundled_tabs.BundledTabs;
import com.blackgear.vanillabackport.common.level.blocks.CopperGolemStatueBlock;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import com.blackgear.vanillabackport.common.registries.enchantment.ModEnchantments;
import com.blackgear.vanillabackport.common.registries.items.ModItems;
import com.blackgear.vanillabackport.common.registries.items.ModPaintingVariants;
import com.blackgear.vanillabackport.core.ModChecker;
import com.blackgear.vanillabackport.core.VanillaBackport;
import net.minecraft.class_1534;
import net.minecraft.class_1772;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1889;
import net.minecraft.class_2246;
import net.minecraft.class_2509;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_6903;
import net.minecraft.class_7924;
import net.minecraft.class_9275;
import net.minecraft.class_9279;
import net.minecraft.class_9334;
import net.minecraft.world.item.*;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;

public class ModBundledTabs {
    private static final List<BundledTabs> FILTERS = new ArrayList<>();

    public static final BundledTabs BUNDLES_OF_BRAVERY = register(
        BundledTabs.builder()
            .title(class_2561.method_43471("bundled_tab.bundles_of_bravery.title"))
            .icon(new class_1799(class_1802.field_27023))
            .displayItems((provider, output) -> {
                output.accept(class_1802.field_27023);
                output.accept(ModItems.WHITE_BUNDLE.get());
                output.accept(ModItems.LIGHT_GRAY_BUNDLE.get());
                output.accept(ModItems.GRAY_BUNDLE.get());
                output.accept(ModItems.BLACK_BUNDLE.get());
                output.accept(ModItems.BROWN_BUNDLE.get());
                output.accept(ModItems.RED_BUNDLE.get());
                output.accept(ModItems.ORANGE_BUNDLE.get());
                output.accept(ModItems.YELLOW_BUNDLE.get());
                output.accept(ModItems.LIME_BUNDLE.get());
                output.accept(ModItems.GREEN_BUNDLE.get());
                output.accept(ModItems.CYAN_BUNDLE.get());
                output.accept(ModItems.LIGHT_BLUE_BUNDLE.get());
                output.accept(ModItems.BLUE_BUNDLE.get());
                output.accept(ModItems.PURPLE_BUNDLE.get());
                output.accept(ModItems.MAGENTA_BUNDLE.get());
                output.accept(ModItems.PINK_BUNDLE.get());
            })
            .build()
    );

    public static final BundledTabs THE_GARDEN_AWAKENS = register(
        BundledTabs.builder()
            .title(class_2561.method_43471("bundled_tab.the_garden_awakens.title"))
            .icon(new class_1799(ModBlocks.OPEN_EYEBLOSSOM.get()))
            .displayItems((provider, output) -> {
                output.accept(ModBlocks.CREAKING_HEART.get());
                output.accept(ModBlocks.PALE_OAK_LOG.get());
                output.accept(ModBlocks.STRIPPED_PALE_OAK_LOG.get());
                output.accept(ModBlocks.PALE_OAK_WOOD.get());
                output.accept(ModBlocks.STRIPPED_PALE_OAK_WOOD.get());
                output.accept(ModBlocks.PALE_OAK_PLANKS.get());
                output.accept(ModBlocks.PALE_OAK_STAIRS.get());
                output.accept(ModBlocks.PALE_OAK_SLAB.get());
                output.accept(ModBlocks.PALE_OAK_SIGN.getFirst().get());
                output.accept(ModBlocks.PALE_OAK_HANGING_SIGN.getFirst().get());
                output.accept(ModBlocks.PALE_OAK_BUTTON.get());
                output.accept(ModBlocks.PALE_OAK_PRESSURE_PLATE.get());
                output.accept(ModBlocks.PALE_OAK_DOOR.get());
                output.accept(ModBlocks.PALE_OAK_FENCE.get());
                output.accept(ModBlocks.PALE_OAK_FENCE_GATE.get());
                output.accept(ModBlocks.PALE_OAK_TRAPDOOR.get());
                output.accept(ModItems.PALE_OAK_BOAT.get());
                output.accept(ModItems.PALE_OAK_CHEST_BOAT.get());
                output.accept(ModBlocks.PALE_HANGING_MOSS.get());
                output.accept(ModBlocks.PALE_MOSS_BLOCK.get());
                output.accept(ModBlocks.PALE_MOSS_CARPET.get());
                output.accept(ModBlocks.PALE_OAK_LEAVES.get());
                output.accept(ModBlocks.PALE_OAK_SAPLING.get());
                output.accept(ModItems.CREAKING_SPAWN_EGG.get());
                output.accept(ModBlocks.CLOSED_EYEBLOSSOM.get());
                output.accept(ModBlocks.OPEN_EYEBLOSSOM.get());
                output.accept(ModBlocks.RESIN_BLOCK.get());
                output.accept(ModBlocks.RESIN_BRICKS.get());
                output.accept(ModBlocks.CHISELED_RESIN_BRICKS.get());
                output.accept(ModBlocks.RESIN_BRICK_STAIRS.get());
                output.accept(ModBlocks.RESIN_BRICK_SLAB.get());
                output.accept(ModBlocks.RESIN_BRICK_WALL.get());
                output.accept(ModBlocks.RESIN_CLUMP.get());
                output.accept(ModItems.RESIN_BRICK.get());
            })
            .build()
    );

    public static final BundledTabs SPRING_TO_LIFE = register(
        BundledTabs.builder()
            .title(class_2561.method_43471("bundled_tab.spring_to_life.title"))
            .icon(new class_1799(ModBlocks.WILDFLOWERS.get()))
            .displayItems((provider, output) -> {
                output.accept(ModBlocks.BUSH.get());
                output.accept(ModBlocks.FIREFLY_BUSH.get());
                output.accept(ModBlocks.WILDFLOWERS.get());
                output.accept(ModBlocks.LEAF_LITTER.get());
                output.accept(ModBlocks.CACTUS_FLOWER.get());
                output.accept(ModBlocks.SHORT_DRY_GRASS.get());
                output.accept(ModBlocks.TALL_DRY_GRASS.get());
                output.accept(ModItems.BROWN_EGG.get());
                output.accept(ModItems.BLUE_EGG.get());
            })
            .build()
    );

    public static final BundledTabs CHASE_THE_SKIES = register(
        BundledTabs.builder()
            .title(class_2561.method_43471("bundled_tab.chase_the_skies.title"))
            .icon(new class_1799(ModItems.BLUE_HARNESS.get()))
            .displayItems((provider, output) -> {
                output.accept(ModBlocks.DRIED_GHAST.get());
                output.accept(ModItems.HAPPY_GHAST_SPAWN_EGG.get());
                output.accept(ModItems.WHITE_HARNESS.get());
                output.accept(ModItems.ORANGE_HARNESS.get());
                output.accept(ModItems.MAGENTA_HARNESS.get());
                output.accept(ModItems.LIGHT_BLUE_HARNESS.get());
                output.accept(ModItems.YELLOW_HARNESS.get());
                output.accept(ModItems.LIME_HARNESS.get());
                output.accept(ModItems.PINK_HARNESS.get());
                output.accept(ModItems.GRAY_HARNESS.get());
                output.accept(ModItems.LIGHT_GRAY_HARNESS.get());
                output.accept(ModItems.CYAN_HARNESS.get());
                output.accept(ModItems.PURPLE_HARNESS.get());
                output.accept(ModItems.BLUE_HARNESS.get());
                output.accept(ModItems.BROWN_HARNESS.get());
                output.accept(ModItems.GREEN_HARNESS.get());
                output.accept(ModItems.RED_HARNESS.get());
                output.accept(ModItems.BLACK_HARNESS.get());
                output.accept(ModItems.MUSIC_DISC_TEARS.get());
            })
            .build()
    );

    public static final BundledTabs HOT_AS_LAVA = register(
        BundledTabs.builder()
            .title(class_2561.method_43471("bundled_tab.hot_as_lava.title"))
            .icon(new class_1799(ModItems.MUSIC_DISC_LAVA_CHICKEN.get()))
            .displayItems((provider, output) -> {
                output.accept(ModItems.MUSIC_DISC_LAVA_CHICKEN.get());
                provider.method_46759(class_7924.field_41209)
                    .ifPresent(variants -> variants.method_42017()
                        .filter(holder -> holder.method_40225(ModPaintingVariants.DENNIS))
                        .forEach(reference -> {
                            class_6903<class_2520> ops = provider.method_57093(class_2509.field_11560);
                            class_9279 customData = class_9279.field_49302
                                .method_57447(ops, class_1534.field_49238, reference)
                                .getOrThrow()
                                .method_57451(tag -> tag.method_10582("id", "minecraft:painting"));
                            class_1799 stack = new class_1799(class_1802.field_8892);
                            stack.method_57379(class_9334.field_49609, customData);
                            output.accept(stack);
                        }));
            })
            .build()
    );
    
    public static final BundledTabs COPPER_AGE = register(
        BundledTabs.builder()
            .title(class_2561.method_43471("bundled_tab.copper_age.title"))
            .icon(() -> {
                class_1799 stack = new class_1799(ModBlocks.COPPER_GOLEM_STATUE.get());
                stack.method_57379(class_9334.field_49623, class_9275.field_49284.method_57420(CopperGolemStatueBlock.POSE, CopperGolemStatueBlock.Pose.RUNNING));
                return stack;
            })
            .displayItems((provider, output) -> {
                output.accept(ModBlocks.COPPER_CHEST.get());
                output.accept(ModBlocks.EXPOSED_COPPER_CHEST.get());
                output.accept(ModBlocks.WEATHERED_COPPER_CHEST.get());
                output.accept(ModBlocks.OXIDIZED_COPPER_CHEST.get());
                
                output.accept(ModBlocks.WAXED_COPPER_CHEST.get());
                output.accept(ModBlocks.WAXED_EXPOSED_COPPER_CHEST.get());
                output.accept(ModBlocks.WAXED_WEATHERED_COPPER_CHEST.get());
                output.accept(ModBlocks.WAXED_OXIDIZED_COPPER_CHEST.get());
                
                output.accept(ModBlocks.OAK_SHELF.get());
                output.accept(ModBlocks.BIRCH_SHELF.get());
                output.accept(ModBlocks.SPRUCE_SHELF.get());
                output.accept(ModBlocks.JUNGLE_SHELF.get());
                output.accept(ModBlocks.ACACIA_SHELF.get());
                output.accept(ModBlocks.DARK_OAK_SHELF.get());
                output.accept(ModBlocks.CRIMSON_SHELF.get());
                output.accept(ModBlocks.WARPED_SHELF.get());
                output.accept(ModBlocks.MANGROVE_SHELF.get());
                output.accept(ModBlocks.BAMBOO_SHELF.get());
                output.accept(ModBlocks.CHERRY_SHELF.get());
                output.accept(ModBlocks.PALE_OAK_SHELF.get());
                
                output.accept(ModBlocks.COPPER_GOLEM_STATUE.get());
                output.accept(ModBlocks.EXPOSED_COPPER_GOLEM_STATUE.get());
                output.accept(ModBlocks.WEATHERED_COPPER_GOLEM_STATUE.get());
                output.accept(ModBlocks.OXIDIZED_COPPER_GOLEM_STATUE.get());
                
                output.accept(ModBlocks.WAXED_COPPER_GOLEM_STATUE.get());
                output.accept(ModBlocks.WAXED_EXPOSED_COPPER_GOLEM_STATUE.get());
                output.accept(ModBlocks.WAXED_WEATHERED_COPPER_GOLEM_STATUE.get());
                output.accept(ModBlocks.WAXED_OXIDIZED_COPPER_GOLEM_STATUE.get());
                
                if (VanillaBackport.COMMON_CONFIG.hasWeatheringLightningRods.get() || !ModChecker.CAVERNS_AND_CHASMS) {
                    output.accept(ModBlocks.EXPOSED_LIGHTNING_ROD.get());
                    output.accept(ModBlocks.WEATHERED_LIGHTNING_ROD.get());
                    output.accept(ModBlocks.OXIDIZED_LIGHTNING_ROD.get());
                    
                    output.accept(ModBlocks.WAXED_LIGHTNING_ROD.get());
                    output.accept(ModBlocks.WAXED_EXPOSED_LIGHTNING_ROD.get());
                    output.accept(ModBlocks.WAXED_WEATHERED_LIGHTNING_ROD.get());
                    output.accept(ModBlocks.WAXED_OXIDIZED_LIGHTNING_ROD.get());
                }
                
                output.accept(ModItems.COPPER_GOLEM_SPAWN_EGG.get());
                
                if (VanillaBackport.COMMON_CONFIG.hasCopperToolSet.get()) {
                    output.accept(ModItems.COPPER_SWORD.get());
                    output.accept(ModItems.COPPER_AXE.get());
                    output.accept(ModItems.COPPER_PICKAXE.get());
                    output.accept(ModItems.COPPER_SHOVEL.get());
                    output.accept(ModItems.COPPER_HOE.get());
                    
                    output.accept(ModItems.COPPER_HELMET.get());
                    output.accept(ModItems.COPPER_CHESTPLATE.get());
                    output.accept(ModItems.COPPER_LEGGINGS.get());
                    output.accept(ModItems.COPPER_BOOTS.get());
                    
                    output.accept(ModItems.COPPER_HORSE_ARMOR.get());
                }
                
                if (VanillaBackport.COMMON_CONFIG.hasCopperNuggets.get()) {
                    output.accept(ModItems.COPPER_NUGGET.get());
                }
                
                output.accept(ModBlocks.COPPER_TORCH.getFirst().get());
                ModBlocks.COPPER_LANTERN.asList().forEach(block -> output.accept(block.get()));
                ModBlocks.COPPER_BARS.asList().forEach(block -> output.accept(block.get()));
                ModBlocks.COPPER_CHAIN.asList().forEach(block -> output.accept(block.get()));
            })
            .build()
    );
    
    public static final BundledTabs MOUNTS_OF_MAYHEM = register(
        BundledTabs.builder()
            .title(class_2561.method_43471("bundled_tab.mounts_of_mayhem.title"))
            .icon(new class_1799(ModItems.IRON_SPEAR.get()))
            .displayItems((provider, output) -> {
                output.accept(ModItems.COPPER_NAUTILUS_ARMOR.get());
                output.accept(ModItems.IRON_NAUTILUS_ARMOR.get());
                output.accept(ModItems.GOLDEN_NAUTILUS_ARMOR.get());
                output.accept(ModItems.DIAMOND_NAUTILUS_ARMOR.get());
                output.accept(ModItems.NETHERITE_NAUTILUS_ARMOR.get());
                
                output.accept(ModItems.NETHERITE_HORSE_ARMOR.get());
                
                if (VanillaBackport.COMMON_CONFIG.hasSpears.get()) {
                    output.accept(ModItems.WOODEN_SPEAR.get());
                    output.accept(ModItems.STONE_SPEAR.get());
                    
                    if (VanillaBackport.COMMON_CONFIG.hasCopperToolSet.get()) {
                        output.accept(ModItems.COPPER_SPEAR.get());
                    }
                    
                    output.accept(ModItems.IRON_SPEAR.get());
                    output.accept(ModItems.GOLDEN_SPEAR.get());
                    output.accept(ModItems.DIAMOND_SPEAR.get());
                    output.accept(ModItems.NETHERITE_SPEAR.get());
                }
                
                output.accept(ModItems.CAMEL_HUSK_SPAWN_EGG.get());
                output.accept(ModItems.NAUTILUS_SPAWN_EGG.get());
                output.accept(ModItems.PARCHED_SPAWN_EGG.get());
                output.accept(ModItems.ZOMBIE_NAUTILUS_SPAWN_EGG.get());
                
                provider.method_46759(class_7924.field_41265).ifPresent(enchantments -> {
                    enchantments.method_42017()
                        .filter(holder -> holder.method_40225(ModEnchantments.LUNGE))
                        .flatMap(reference -> IntStream.rangeClosed(reference.comp_349().method_8187(), reference.comp_349().method_8183()).mapToObj(level -> class_1772.method_7808(new class_1889(reference, level))))
                        .forEach(output::accept);
                });
            })
            .build()
    );
    
    public static final BundledTabs CHAOS_CUBED = register(
        BundledTabs.builder()
            .title(class_2561.method_43471("bundled_tab.chaos_cubed.title"))
            .icon(new class_1799(ModItems.SULFUR_CUBE_BUCKET.get()))
            .displayItems((provider, output) -> {
                output.accept(ModBlocks.CINNABAR.get());
                output.accept(ModBlocks.CINNABAR_SLAB.get());
                output.accept(ModBlocks.CINNABAR_STAIRS.get());
                output.accept(ModBlocks.CINNABAR_WALL.get());
                output.accept(ModBlocks.POLISHED_CINNABAR.get());
                output.accept(ModBlocks.POLISHED_CINNABAR_SLAB.get());
                output.accept(ModBlocks.POLISHED_CINNABAR_STAIRS.get());
                output.accept(ModBlocks.POLISHED_CINNABAR_WALL.get());
                output.accept(ModBlocks.CINNABAR_BRICKS.get());
                output.accept(ModBlocks.CINNABAR_BRICK_SLAB.get());
                output.accept(ModBlocks.CINNABAR_BRICK_STAIRS.get());
                output.accept(ModBlocks.CINNABAR_BRICK_WALL.get());
                output.accept(ModBlocks.CHISELED_CINNABAR.get());
                output.accept(ModBlocks.POTENT_SULFUR.get());
                output.accept(ModBlocks.SULFUR.get());
                output.accept(ModBlocks.SULFUR_SLAB.get());
                output.accept(ModBlocks.SULFUR_STAIRS.get());
                output.accept(ModBlocks.SULFUR_WALL.get());
                output.accept(ModBlocks.POLISHED_SULFUR.get());
                output.accept(ModBlocks.POLISHED_SULFUR_SLAB.get());
                output.accept(ModBlocks.POLISHED_SULFUR_STAIRS.get());
                output.accept(ModBlocks.POLISHED_SULFUR_WALL.get());
                output.accept(ModBlocks.SULFUR_BRICKS.get());
                output.accept(ModBlocks.SULFUR_BRICK_SLAB.get());
                output.accept(ModBlocks.SULFUR_BRICK_STAIRS.get());
                output.accept(ModBlocks.SULFUR_BRICK_WALL.get());
                output.accept(ModBlocks.CHISELED_SULFUR.get());
                output.accept(ModBlocks.SULFUR_SPIKE.get());
                output.accept(ModItems.SULFUR_CUBE_BUCKET.get());
                output.accept(ModItems.SULFUR_CUBE_SPAWN_EGG.get());
                output.accept(ModItems.MUSIC_DISC_BOUNCE.get());
            })
            .build()
    );
    
    public static final BundledTabs WILDERNESS_BOUND = register(
        BundledTabs.builder()
            .title(class_2561.method_43471("bundled_tab.wilderness_bound.title"))
            .icon(new class_1799(class_2246.field_17350))
            .displayItems((provider, output) -> {
                output.accept(ModBlocks.POPLAR_LOG.get());
                output.accept(ModBlocks.STRIPPED_POPLAR_LOG.get());
                output.accept(ModBlocks.POPLAR_WOOD.get());
                output.accept(ModBlocks.STRIPPED_POPLAR_WOOD.get());
                output.accept(ModBlocks.POPLAR_PLANKS.get());
                output.accept(ModBlocks.POPLAR_STAIRS.get());
                output.accept(ModBlocks.POPLAR_SLAB.get());
                output.accept(ModBlocks.POPLAR_SIGN.getFirst().get());
                output.accept(ModBlocks.POPLAR_HANGING_SIGN.getFirst().get());
                output.accept(ModBlocks.POPLAR_BUTTON.get());
                output.accept(ModBlocks.POPLAR_PRESSURE_PLATE.get());
                output.accept(ModBlocks.POPLAR_DOOR.get());
                output.accept(ModBlocks.POPLAR_FENCE.get());
                output.accept(ModBlocks.POPLAR_FENCE_GATE.get());
                output.accept(ModBlocks.POPLAR_TRAPDOOR.get());
                output.accept(ModBlocks.POPLAR_SHELF.get());
                output.accept(ModItems.POPLAR_BOAT.get());
                output.accept(ModItems.POPLAR_CHEST_BOAT.get());
                output.accept(ModBlocks.RED_POPLAR_LEAVES.get());
                output.accept(ModBlocks.ORANGE_POPLAR_LEAVES.get());
                output.accept(ModBlocks.YELLOW_POPLAR_LEAVES.get());
                output.accept(ModBlocks.POPLAR_SAPLING.get());
                output.accept(ModBlocks.RED_SHRUB.get());
                output.accept(ModBlocks.SHELF_MUSHROOM.get());
                output.accept(ModBlocks.WHITE_WOOL_STAIRS.get());
                output.accept(ModBlocks.WHITE_WOOL_SLAB.get());
                output.accept(ModBlocks.WHITE_CONCRETE_STAIRS.get());
                output.accept(ModBlocks.WHITE_CONCRETE_SLAB.get());
                output.accept(ModItems.WHITE_CUSHION.get());
                output.accept(ModBlocks.LIGHT_GRAY_WOOL_STAIRS.get());
                output.accept(ModBlocks.LIGHT_GRAY_WOOL_SLAB.get());
                output.accept(ModBlocks.LIGHT_GRAY_CONCRETE_STAIRS.get());
                output.accept(ModBlocks.LIGHT_GRAY_CONCRETE_SLAB.get());
                output.accept(ModItems.LIGHT_GRAY_CUSHION.get());
                output.accept(ModBlocks.GRAY_WOOL_STAIRS.get());
                output.accept(ModBlocks.GRAY_WOOL_SLAB.get());
                output.accept(ModBlocks.GRAY_CONCRETE_STAIRS.get());
                output.accept(ModBlocks.GRAY_CONCRETE_SLAB.get());
                output.accept(ModItems.GRAY_CUSHION.get());
                output.accept(ModBlocks.BLACK_WOOL_STAIRS.get());
                output.accept(ModBlocks.BLACK_WOOL_SLAB.get());
                output.accept(ModBlocks.BLACK_CONCRETE_STAIRS.get());
                output.accept(ModBlocks.BLACK_CONCRETE_SLAB.get());
                output.accept(ModItems.BLACK_CUSHION.get());
                output.accept(ModBlocks.BROWN_WOOL_STAIRS.get());
                output.accept(ModBlocks.BROWN_WOOL_SLAB.get());
                output.accept(ModBlocks.BROWN_CONCRETE_STAIRS.get());
                output.accept(ModBlocks.BROWN_CONCRETE_SLAB.get());
                output.accept(ModItems.BROWN_CUSHION.get());
                output.accept(ModBlocks.RED_WOOL_STAIRS.get());
                output.accept(ModBlocks.RED_WOOL_SLAB.get());
                output.accept(ModBlocks.RED_CONCRETE_STAIRS.get());
                output.accept(ModBlocks.RED_CONCRETE_SLAB.get());
                output.accept(ModItems.RED_CUSHION.get());
                output.accept(ModBlocks.ORANGE_WOOL_STAIRS.get());
                output.accept(ModBlocks.ORANGE_WOOL_SLAB.get());
                output.accept(ModBlocks.ORANGE_CONCRETE_STAIRS.get());
                output.accept(ModBlocks.ORANGE_CONCRETE_SLAB.get());
                output.accept(ModItems.ORANGE_CUSHION.get());
                output.accept(ModBlocks.YELLOW_WOOL_STAIRS.get());
                output.accept(ModBlocks.YELLOW_WOOL_SLAB.get());
                output.accept(ModBlocks.YELLOW_CONCRETE_STAIRS.get());
                output.accept(ModBlocks.YELLOW_CONCRETE_SLAB.get());
                output.accept(ModItems.YELLOW_CUSHION.get());
                output.accept(ModBlocks.LIME_WOOL_STAIRS.get());
                output.accept(ModBlocks.LIME_WOOL_SLAB.get());
                output.accept(ModBlocks.LIME_CONCRETE_STAIRS.get());
                output.accept(ModBlocks.LIME_CONCRETE_SLAB.get());
                output.accept(ModItems.LIME_CUSHION.get());
                output.accept(ModBlocks.GREEN_WOOL_STAIRS.get());
                output.accept(ModBlocks.GREEN_WOOL_SLAB.get());
                output.accept(ModBlocks.GREEN_CONCRETE_STAIRS.get());
                output.accept(ModBlocks.GREEN_CONCRETE_SLAB.get());
                output.accept(ModItems.GREEN_CUSHION.get());
                output.accept(ModBlocks.CYAN_WOOL_STAIRS.get());
                output.accept(ModBlocks.CYAN_WOOL_SLAB.get());
                output.accept(ModBlocks.CYAN_CONCRETE_STAIRS.get());
                output.accept(ModBlocks.CYAN_CONCRETE_SLAB.get());
                output.accept(ModItems.CYAN_CUSHION.get());
                output.accept(ModBlocks.LIGHT_BLUE_WOOL_STAIRS.get());
                output.accept(ModBlocks.LIGHT_BLUE_WOOL_SLAB.get());
                output.accept(ModBlocks.LIGHT_BLUE_CONCRETE_STAIRS.get());
                output.accept(ModBlocks.LIGHT_BLUE_CONCRETE_SLAB.get());
                output.accept(ModItems.LIGHT_BLUE_CUSHION.get());
                output.accept(ModBlocks.BLUE_WOOL_STAIRS.get());
                output.accept(ModBlocks.BLUE_WOOL_SLAB.get());
                output.accept(ModBlocks.BLUE_CONCRETE_STAIRS.get());
                output.accept(ModBlocks.BLUE_CONCRETE_SLAB.get());
                output.accept(ModItems.BLUE_CUSHION.get());
                output.accept(ModBlocks.PURPLE_WOOL_STAIRS.get());
                output.accept(ModBlocks.PURPLE_WOOL_SLAB.get());
                output.accept(ModBlocks.PURPLE_CONCRETE_STAIRS.get());
                output.accept(ModBlocks.PURPLE_CONCRETE_SLAB.get());
                output.accept(ModItems.PURPLE_CUSHION.get());
                output.accept(ModBlocks.MAGENTA_WOOL_STAIRS.get());
                output.accept(ModBlocks.MAGENTA_WOOL_SLAB.get());
                output.accept(ModBlocks.MAGENTA_CONCRETE_STAIRS.get());
                output.accept(ModBlocks.MAGENTA_CONCRETE_SLAB.get());
                output.accept(ModItems.MAGENTA_CUSHION.get());
                output.accept(ModBlocks.PINK_WOOL_STAIRS.get());
                output.accept(ModBlocks.PINK_WOOL_SLAB.get());
                output.accept(ModBlocks.PINK_CONCRETE_STAIRS.get());
                output.accept(ModBlocks.PINK_CONCRETE_SLAB.get());
                output.accept(ModItems.PINK_CUSHION.get());
                output.accept(ModBlocks.STRAW_BED.get());
            })
            .build()
    );

    public static BundledTabs register(BundledTabs builder) {
        FILTERS.add(builder);
        return builder;
    }

    public static List<BundledTabs> getTabs() {
        return FILTERS;
    }
}