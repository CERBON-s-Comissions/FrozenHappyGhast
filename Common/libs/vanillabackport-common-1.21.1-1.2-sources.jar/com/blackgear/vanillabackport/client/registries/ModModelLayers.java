package com.blackgear.vanillabackport.client.registries;

import net.minecraft.class_2960;
import net.minecraft.class_5601;

public class ModModelLayers {
    // The Garden Awakens
    public static final class_5601 CREAKING = register("creaking");
    public static final class_5601 CUSTOM_BOAT = register("custom_boat");
    public static final class_5601 CUSTOM_CHEST_BOAT = register("custom_chest_boat");

    // Spring to Life
    public static final class_5601 COLD_PIG = register("cold_pig");
    public static final class_5601 COLD_CHICKEN = register("cold_chicken");
    public static final class_5601 COLD_COW = register("cold_cow");
    public static final class_5601 WARM_COW = register("warm_cow");

    // Chase the Skies
    public static final class_5601 HAPPY_GHAST = register("happy_ghast");
    public static final class_5601 HAPPY_GHAST_HARNESS = register("happy_ghast", "harness");
    public static final class_5601 HAPPY_GHAST_ROPES = register("happy_ghast", "ropes");
    
    // COPPER AGE
    public static final class_5601 COPPER_GOLEM = register("copper_golem");
    public static final class_5601 COPPER_GOLEM_RUNNING = register("copper_golem_running");
    public static final class_5601 COPPER_GOLEM_SITTING = register("copper_golem_sitting");
    public static final class_5601 COPPER_GOLEM_STAR = register("copper_golem_star");
    
    // MOUNTS OF MAYHEM
    public static final class_5601 PARCHED = register("parched");
    public static final class_5601 PARCHED_INNER_ARMOR = register("parched", "inner_armor");
    public static final class_5601 PARCHED_OUTER_ARMOR = register("parched", "outer_armor");
    
    public static final class_5601 CAMEL_HUSK = register("camel_husk");
    
    public static final class_5601 UNDEAD_HORSE_ARMOR = register("undead_horse_armor");
    
    public static final class_5601 NAUTILUS = register("nautilus");
    public static final class_5601 NAUTILUS_BABY = register("nautilus_baby");
    public static final class_5601 NAUTILUS_ARMOR = register("nautilus_armor");
    public static final class_5601 NAUTILUS_SADDLE = register("nautilus", "saddle");
    public static final class_5601 ZOMBIE_NAUTILUS = register("zombie_nautilus");
    public static final class_5601 ZOMBIE_NAUTILUS_CORAL = register("zombie_nautilus", "coral");
    
    // CHAOS CUBED
    public static final class_5601 SULFUR_CUBE = register("sulfur_cube");
    public static final class_5601 SULFUR_CUBE_INNER = register("sulfur_cube", "inner");
    public static final class_5601 SULFUR_CUBE_SMALL = register("sulfur_cube_small");
    public static final class_5601 SULFUR_CUBE_SMALL_INNER = register("sulfur_cube_small", "inner");
    
    // MISC
    public static final class_5601 CUSHION = register("cushion");

    private static class_5601 register(String name) {
        return register(name, "main");
    }

    private static class_5601 register(String name, String layer) {
        return new class_5601(class_2960.method_60656(name), layer);
    }
}