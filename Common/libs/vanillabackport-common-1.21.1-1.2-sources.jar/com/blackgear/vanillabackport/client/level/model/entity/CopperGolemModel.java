package com.blackgear.vanillabackport.client.level.model.entity;

import com.blackgear.vanillabackport.client.level.animation.CopperGolemAnimation;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.golem.copper_golem.CopperGolem;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.golem.copper_golem.CopperGolemState;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1304;
import net.minecraft.class_1306;
import net.minecraft.class_3881;
import net.minecraft.class_3882;
import net.minecraft.class_4587;
import net.minecraft.class_5597;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_630;
import net.minecraft.class_7833;
import net.minecraft.client.model.geom.builders.*;

@Environment(EnvType.CLIENT)
public class CopperGolemModel<T extends CopperGolem> extends class_5597<T> implements class_3881, class_3882 {
    private T entity;
    private final class_630 root;
    private final class_630 head;
    private final class_630 body;
    private final class_630 rightArm;
    private final class_630 leftArm;
    
    public CopperGolemModel(class_630 root) {
        this.root = root;
        this.body = this.root.method_32086("body");
        this.head = this.body.method_32086("head");
        this.rightArm = this.body.method_32086("right_arm");
        this.leftArm = this.body.method_32086("left_arm");
    }
    
    public static class_5607 createBodyLayer() {
        class_5609 meshDefinition = new class_5609();
        class_5610 root = meshDefinition.method_32111();
        class_5610 body = root.method_32117(
            "body", class_5606.method_32108().method_32101(0, 15).method_32098(-4.0F, -6.0F, -3.0F, 8.0F, 6.0F, 6.0F, class_5605.field_27715), class_5603.method_32090(0.0F, -5.0F, 0.0F)
        );
        body.method_32117(
            "head",
            class_5606.method_32108()
                .method_32101(0, 0)
                .method_32098(-4.0F, -5.0F, -5.0F, 8.0F, 5.0F, 10.0F, new class_5605(0.015F))
                .method_32101(56, 0)
                .method_32098(-1.0F, -2.0F, -6.0F, 2.0F, 3.0F, 2.0F, class_5605.field_27715)
                .method_32101(37, 8)
                .method_32098(-1.0F, -9.0F, -1.0F, 2.0F, 4.0F, 2.0F, new class_5605(-0.015F))
                .method_32101(37, 0)
                .method_32098(-2.0F, -13.0F, -2.0F, 4.0F, 4.0F, 4.0F, new class_5605(-0.015F)),
            class_5603.method_32090(0.0F, -6.0F, 0.0F)
        );
        body.method_32117(
            "right_arm",
            class_5606.method_32108().method_32101(36, 16).method_32098(-3.0F, -1.0F, -2.0F, 3.0F, 10.0F, 4.0F, class_5605.field_27715),
            class_5603.method_32090(-4.0F, -6.0F, 0.0F)
        );
        body.method_32117(
            "left_arm", class_5606.method_32108().method_32101(50, 16).method_32098(0.0F, -1.0F, -2.0F, 3.0F, 10.0F, 4.0F, class_5605.field_27715), class_5603.method_32090(4.0F, -6.0F, 0.0F)
        );
        root.method_32117(
            "right_leg", class_5606.method_32108().method_32101(0, 27).method_32098(-4.0F, 0.0F, -2.0F, 4.0F, 5.0F, 4.0F, class_5605.field_27715), class_5603.method_32090(0.0F, -5.0F, 0.0F)
        );
        root.method_32117(
            "left_leg", class_5606.method_32108().method_32101(16, 27).method_32098(0.0F, 0.0F, -2.0F, 4.0F, 5.0F, 4.0F, class_5605.field_27715), class_5603.method_32090(0.0F, -5.0F, 0.0F)
        );
        return class_5607.method_32110(meshDefinition, 64, 64);
    }
    
    public static class_5607 createRunningPoseBodyLayer() {
        class_5609 meshDefinition = new class_5609();
        class_5610 root = meshDefinition.method_32111();
        class_5610 body = root.method_32117("body", class_5606.method_32108(), class_5603.method_32090(-1.064F, -5.0F, 0.0F));
        body.method_32117(
            "body_r1",
            class_5606.method_32108().method_32101(0, 15).method_32098(-4.02F, -6.116F, -3.5F, 8.0F, 6.0F, 6.0F, new class_5605(0.0F)),
            class_5603.method_32091(1.1F, 0.1F, 0.7F, 0.1204F, -0.0064F, -0.0779F)
        );
        body.method_32117(
            "head",
            class_5606.method_32108()
                .method_32101(0, 0)
                .method_32098(-4.0F, -5.1F, -5.0F, 8.0F, 5.0F, 10.0F, new class_5605(0.0F))
                .method_32101(56, 0)
                .method_32098(-1.02F, -2.1F, -6.0F, 2.0F, 3.0F, 2.0F, new class_5605(0.0F))
                .method_32101(37, 8)
                .method_32098(-1.02F, -9.1F, -1.0F, 2.0F, 4.0F, 2.0F, new class_5605(-0.015F))
                .method_32101(37, 0)
                .method_32098(-2.0F, -13.1F, -2.0F, 4.0F, 4.0F, 4.0F, new class_5605(-0.015F)),
            class_5603.method_32090(0.7F, -5.6F, -1.8F)
        );
        class_5610 right_arm = body.method_32117("right_arm", class_5606.method_32108(), class_5603.method_32090(-4.0F, -6.0F, 0.0F));
        right_arm.method_32117(
            "right_arm_r1",
            class_5606.method_32108().method_32101(36, 16).method_32098(-3.052F, -1.11F, -2.036F, 3.0F, 10.0F, 4.0F, new class_5605(0.0F)),
            class_5603.method_32091(0.7F, -0.248F, -1.62F, 1.0036F, 0.0F, 0.0F)
        );
        class_5610 left_arm = body.method_32117("left_arm", class_5606.method_32108(), class_5603.method_32090(4.0F, -6.0F, 0.0F));
        left_arm.method_32117(
            "left_arm_r1",
            class_5606.method_32108().method_32101(50, 16).method_32098(0.032F, -1.1F, -2.0F, 3.0F, 10.0F, 4.0F, new class_5605(0.0F)),
            class_5603.method_32091(0.732F, 0.0F, 0.0F, -0.8715F, -0.0535F, -0.0449F)
        );
        class_5610 right_leg = root.method_32117("right_leg", class_5606.method_32108(), class_5603.method_32090(-3.064F, -5.0F, 0.0F));
        right_leg.method_32117(
            "right_leg_r1",
            class_5606.method_32108().method_32101(0, 27).method_32098(-1.856F, -0.1F, -1.09F, 4.0F, 5.0F, 4.0F, new class_5605(0.0F)),
            class_5603.method_32091(1.048F, 0.0F, -0.9F, -0.8727F, 0.0F, 0.0F)
        );
        class_5610 left_leg = root.method_32117("left_leg", class_5606.method_32108(), class_5603.method_32090(0.936F, -5.0F, 0.0F));
        left_leg.method_32117(
            "left_leg_r1",
            class_5606.method_32108().method_32101(16, 27).method_32098(-2.088F, -0.1F, -2.0F, 4.0F, 5.0F, 4.0F, new class_5605(0.0F)),
            class_5603.method_32091(1.0F, 0.0F, 0.0F, 0.7854F, 0.0F, 0.0F)
        );
        return class_5607.method_32110(meshDefinition, 64, 64);
    }
    
    public static class_5607 createSittingPoseBodyLayer() {
        class_5609 meshDefinition = new class_5609();
        class_5610 root = meshDefinition.method_32111();
        class_5610 body = root.method_32117(
            "body",
            class_5606.method_32108()
                .method_32101(3, 19)
                .method_32098(-3.0F, -4.0F, -4.525F, 6.0F, 1.0F, 6.0F, new class_5605(0.0F))
                .method_32101(0, 15)
                .method_32098(-4.0F, -3.0F, -3.525F, 8.0F, 6.0F, 6.0F, new class_5605(0.0F)),
            class_5603.method_32090(0.0F, -3.0F, 2.325F)
        );
        body.method_32117(
            "body_r1",
            class_5606.method_32108().method_32101(3, 18).method_32098(-4.0F, -3.0F, -2.2F, 8.0F, 6.0F, 3.0F, new class_5605(0.0F)),
            class_5603.method_32091(0.0F, -1.0F, -4.325F, 0.0F, 0.0F, -3.1416F)
        );
        class_5610 head = body.method_32117(
            "head",
            class_5606.method_32108()
                .method_32101(37, 8)
                .method_32098(-1.0F, -7.0F, -3.3F, 2.0F, 4.0F, 2.0F, new class_5605(-0.015F))
                .method_32101(37, 0)
                .method_32098(-2.0F, -11.0F, -4.3F, 4.0F, 4.0F, 4.0F, new class_5605(-0.015F))
                .method_32101(0, 0)
                .method_32098(-4.0F, -3.0F, -7.325F, 8.0F, 5.0F, 10.0F, new class_5605(0.0F))
                .method_32101(56, 0)
                .method_32098(-1.0F, 0.0F, -8.325F, 2.0F, 3.0F, 2.0F, new class_5605(0.0F)),
            class_5603.method_32090(0.0F, -6.0F, -0.2F)
        );
        class_5610 right_arm = body.method_32117("right_arm", class_5606.method_32108(), class_5603.method_32091(-4.0F, -5.6F, -1.8F, 0.4363F, 0.0F, 0.0F));
        right_arm.method_32117(
            "right_arm_r1",
            class_5606.method_32108().method_32101(36, 16).method_32098(-3.075F, -0.9733F, -1.9966F, 3.0F, 10.0F, 4.0F, new class_5605(0.0F)),
            class_5603.method_32091(0.0F, 0.0893F, 0.1198F, -1.0472F, 0.0F, 0.0F)
        );
        class_5610 left_arm = body.method_32117("left_arm", class_5606.method_32108(), class_5603.method_32091(4.0F, -5.6F, -1.7F, 0.4363F, 0.0F, 0.0F));
        left_arm.method_32117(
            "left_arm_r1",
            class_5606.method_32108().method_32101(50, 16).method_32098(0.075F, -1.0443F, -1.8997F, 3.0F, 10.0F, 4.0F, new class_5605(0.0F)),
            class_5603.method_32091(0.0F, -0.0015F, -0.0808F, -1.0472F, 0.0F, 0.0F)
        );
        class_5610 right_leg = root.method_32117("right_leg", class_5606.method_32108(), class_5603.method_32090(-2.1F, -2.1F, -2.075F));
        right_leg.method_32117(
            "right_leg_r1",
            class_5606.method_32108().method_32101(0, 27).method_32098(-2.0F, 0.975F, 0.0F, 4.0F, 5.0F, 4.0F, new class_5605(0.0F)),
            class_5603.method_32091(0.05F, -1.9F, 1.075F, -1.5708F, 0.0F, 0.0F)
        );
        class_5610 left_leg = root.method_32117("left_leg", class_5606.method_32108(), class_5603.method_32090(2.0F, -2.0F, -2.075F));
        left_leg.method_32117(
            "left_leg_r1",
            class_5606.method_32108().method_32101(16, 27).method_32098(-2.0F, 0.975F, 0.0F, 4.0F, 5.0F, 4.0F, new class_5605(0.0F)),
            class_5603.method_32091(0.05F, -2.0F, 1.075F, -1.5708F, 0.0F, 0.0F)
        );
        return class_5607.method_32110(meshDefinition, 64, 64);
    }
    
    public static class_5607 createStarPoseBodyLayer() {
        class_5609 meshDefinition = new class_5609();
        class_5610 root = meshDefinition.method_32111();
        class_5610 body = root.method_32117(
            "body", class_5606.method_32108().method_32101(0, 15).method_32098(-4.0F, -6.0F, -3.0F, 8.0F, 6.0F, 6.0F, new class_5605(0.0F)), class_5603.method_32090(0.0F, -5.0F, 0.0F)
        );
        body.method_32117(
            "head",
            class_5606.method_32108()
                .method_32101(0, 0)
                .method_32098(-4.0F, -5.0F, -5.0F, 8.0F, 5.0F, 10.0F, new class_5605(0.0F))
                .method_32101(56, 0)
                .method_32098(-1.0F, -2.0F, -6.0F, 2.0F, 3.0F, 2.0F, new class_5605(0.0F))
                .method_32101(37, 8)
                .method_32098(-1.0F, -9.0F, -1.0F, 2.0F, 4.0F, 2.0F, new class_5605(-0.015F))
                .method_32101(37, 0)
                .method_32098(-2.0F, -13.0F, -2.0F, 4.0F, 4.0F, 4.0F, new class_5605(-0.015F)),
            class_5603.method_32090(0.0F, -6.0F, 0.0F)
        );
        class_5610 right_arm = body.method_32117("right_arm", class_5606.method_32108(), class_5603.method_32090(-4.0F, -6.0F, 0.0F));
        right_arm.method_32117(
            "right_arm_r1",
            class_5606.method_32108().method_32101(36, 16).method_32098(-1.5F, -5.0F, -2.0F, 3.0F, 10.0F, 4.0F, new class_5605(0.0F)),
            class_5603.method_32091(1.0F, 1.0F, 0.0F, 0.0F, 0.0F, 1.9199F)
        );
        right_arm.method_32117("rightItem", class_5606.method_32108(), class_5603.method_32090(-1.0F, 7.4F, -1.0F));
        class_5610 left_arm = body.method_32117("left_arm", class_5606.method_32108(), class_5603.method_32090(4.0F, -6.0F, 0.0F));
        left_arm.method_32117(
            "left_arm_r1",
            class_5606.method_32108().method_32101(50, 16).method_32098(-1.5F, -5.0F, -2.0F, 3.0F, 10.0F, 4.0F, new class_5605(0.0F)),
            class_5603.method_32091(-1.0F, 1.0F, 0.0F, 0.0F, 0.0F, -1.9199F)
        );
        class_5610 right_leg = root.method_32117("right_leg", class_5606.method_32108(), class_5603.method_32090(-3.0F, -5.0F, 0.0F));
        right_leg.method_32117(
            "right_leg_r1",
            class_5606.method_32108().method_32101(0, 27).method_32098(-2.0F, -2.5F, -2.0F, 4.0F, 5.0F, 4.0F, new class_5605(0.0F)),
            class_5603.method_32091(0.35F, 2.0F, 0.01F, 0.0F, 0.0F, 0.2618F)
        );
        class_5610 left_leg = root.method_32117("left_leg", class_5606.method_32108(), class_5603.method_32090(1.0F, -5.0F, 0.0F));
        left_leg.method_32117(
            "left_leg_r1",
            class_5606.method_32108().method_32101(16, 27).method_32098(-2.0F, -2.5F, -2.0F, 4.0F, 5.0F, 4.0F, new class_5605(0.0F)),
            class_5603.method_32091(1.65F, 2.0F, 0.0F, 0.0F, 0.0F, -0.2618F)
        );
        return class_5607.method_32110(meshDefinition, 64, 64);
    }
    
    @Override
    public class_630 method_32008() {
        return this.root;
    }
    
    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        this.entity = entity;
        
        this.method_32008().method_32088().forEach(class_630::method_41923);
        this.head.field_3654 = headPitch * (float) (Math.PI / 180F);
        this.head.field_3675 = netHeadYaw * (float) (Math.PI / 180F);
        
        if (!entity.method_6084(class_1304.field_6173) && !entity.method_6084(class_1304.field_6171)) {
            this.method_48741(CopperGolemAnimation.COPPER_GOLEM_WALK, limbSwing, limbSwingAmount, 2.0F, 2.5F);
        } else {
            this.method_48741(CopperGolemAnimation.COPPER_GOLEM_WALK_ITEM, limbSwing, limbSwingAmount, 2.0F, 2.5F);
            this.poseHeldItemArmsIfStill();
        }

        this.method_43781(entity.getIdleAnimationState(), CopperGolemAnimation.COPPER_GOLEM_IDLE, ageInTicks);
        this.method_43781(entity.getInteractionGetItemAnimationState(), CopperGolemAnimation.COPPER_GOLEM_CHEST_INTERACTION_NOITEM_GET, ageInTicks);
        this.method_43781(entity.getInteractionGetNoItemAnimationState(), CopperGolemAnimation.COPPER_GOLEM_CHEST_INTERACTION_NOITEM_NOGET, ageInTicks);
        this.method_43781(entity.getInteractionDropItemAnimationState(), CopperGolemAnimation.COPPER_GOLEM_CHEST_INTERACTION_ITEM_DROP, ageInTicks);
        this.method_43781(entity.getInteractionDropNoItemAnimationState(), CopperGolemAnimation.COPPER_GOLEM_CHEST_INTERACTION_ITEM_NODROP, ageInTicks);
    }
    
    @Override
    public void method_2803(class_1306 arn, class_4587 poseStack) {
        this.root.method_22703(poseStack);
        this.body.method_22703(poseStack);
        class_630 activeArm = arn == class_1306.field_6183 ? this.rightArm : this.leftArm;
        activeArm.method_22703(poseStack);
        if (this.entity != null) {
            if (this.entity.getState().equals(CopperGolemState.IDLE)) {
                poseStack.method_22907(class_7833.field_40716.rotationDegrees(arn == class_1306.field_6183 ? -90.0F : 90.0F));
                poseStack.method_46416(0.0F, 0.0F, 0.125F);
            } else {
                poseStack.method_22905(0.55F, 0.55F, 0.55F);
                poseStack.method_46416(-0.125F, 0.3125F, -0.1875F);
            }
        }
    }
    
    @Override
    public class_630 method_2838() {
        return this.head;
    }
    
    public void applyBlockOnAntennaTransform(class_4587 poseStack) {
        this.root.method_22703(poseStack);
        this.body.method_22703(poseStack);
        this.head.method_22703(poseStack);
        poseStack.method_22904(0.0, -2.25, 0.0);
    }
    
    private void poseHeldItemArmsIfStill() {
        this.rightArm.field_3654 = Math.min(this.rightArm.field_3654, -0.87266463F);
        this.leftArm.field_3654 = Math.min(this.leftArm.field_3654, -0.87266463F);
        this.rightArm.field_3675 = Math.min(this.rightArm.field_3675, -0.1134464F);
        this.leftArm.field_3675 = Math.max(this.leftArm.field_3675, 0.1134464F);
        this.rightArm.field_3674 = Math.min(this.rightArm.field_3674, -0.064577185F);
        this.leftArm.field_3674 = Math.max(this.leftArm.field_3674, 0.064577185F);
    }
}