package com.blackgear.vanillabackport.client.level.layer;

import com.blackgear.vanillabackport.client.registries.ModModelLayers;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1496;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_3489;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4059;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5253.class_5254;
import net.minecraft.class_549;
import net.minecraft.class_5599;
import net.minecraft.class_9282;

@Environment(EnvType.CLIENT)
public class UndeadHorseArmorLayer extends class_3887<class_1496, class_549<class_1496>> {
	private final class_549<class_1496> model;

	public UndeadHorseArmorLayer(class_3883<class_1496, class_549<class_1496>> renderer, class_5599 models) {
		super(renderer);
		this.model = new class_549<>(models.method_32072(ModModelLayers.UNDEAD_HORSE_ARMOR));
	}

	@Override
	public void render(
		class_4587 poseStack,
		class_4597 buffer,
		int packedLight,
		class_1496 entity,
		float limbSwing,
		float limbSwingAmount,
		float partialTicks,
		float ageInTicks,
		float netHeadYaw,
		float headPitch
	) {
		class_1799 equipment = entity.method_56676();
		if (equipment.method_7909() instanceof class_4059 armor && armor.method_55756() == class_4059.class_9076.field_47825) {
			this.method_17165().method_17081(this.model);
			this.model.method_17084(entity, limbSwing, limbSwingAmount, partialTicks);
			this.model.method_17085(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
			int color = equipment.method_31573(class_3489.field_48803) ? class_5254.method_57174(class_9282.method_57470(equipment, -6265536)) : -1;
			
			class_4588 consumer = buffer.getBuffer(class_1921.method_23578(armor.method_18454()));
			this.model.method_2828(poseStack, consumer, packedLight, class_4608.field_21444, color);
		}
	}
}
