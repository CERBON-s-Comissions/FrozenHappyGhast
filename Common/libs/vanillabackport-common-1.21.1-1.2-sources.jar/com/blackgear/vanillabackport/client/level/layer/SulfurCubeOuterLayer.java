package com.blackgear.vanillabackport.client.level.layer;

import com.blackgear.vanillabackport.client.level.model.entity.sulfur_cube.SmallSulfurCubeModel;
import com.blackgear.vanillabackport.client.level.model.entity.sulfur_cube.SulfurCubeModel;
import com.blackgear.vanillabackport.client.registries.ModModelLayers;
import com.blackgear.vanillabackport.common.level.entities.mob.monster.sulfur_cube.SulfurCube;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_5599;
import net.minecraft.class_583;
import net.minecraft.class_922;

@Environment(EnvType.CLIENT)
public class SulfurCubeOuterLayer extends class_3887<SulfurCube, SulfurCubeModel> {
    private static final class_2960 SULFUR_CUBE_OUTER_LOCATION = class_2960.method_60656("textures/entity/sulfur_cube/sulfur_cube_outer.png");
    private static final class_2960 SULFUR_CUBE_OUTER_SMALL_LOCATION = class_2960.method_60656("textures/entity/sulfur_cube/sulfur_cube_outer_small.png");

    private final SulfurCubeModel normalModel;
    private final SmallSulfurCubeModel smallModel;

    public SulfurCubeOuterLayer(class_3883<SulfurCube, SulfurCubeModel> renderer, class_5599 modelSet) {
        super(renderer);
        this.normalModel = new SulfurCubeModel(modelSet.method_32072(ModModelLayers.SULFUR_CUBE));
        this.smallModel = new SmallSulfurCubeModel(modelSet.method_32072(ModModelLayers.SULFUR_CUBE_SMALL));
    }

    @Override
    public void render(
        class_4587 poseStack,
        class_4597 buffer,
        int packedLight,
        SulfurCube cube,
        float limbSwing,
        float limbSwingAmount,
        float partialTick,
        float ageInTicks,
        float netHeadYaw,
        float headPitch
    ) {
        class_310 minecraft = class_310.method_1551();
        boolean glowing = minecraft.method_27022(cube) && cube.method_5767();
        if (!cube.method_5767() || glowing) {
            class_583<SulfurCube> model = cube.method_6109() ? this.smallModel : this.normalModel;
            class_2960 texture = cube.method_6109() ? SULFUR_CUBE_OUTER_SMALL_LOCATION : SULFUR_CUBE_OUTER_LOCATION;
            class_4588 vertexConsumer = buffer.getBuffer(class_1921.method_23580(texture));

            if (glowing) {
                vertexConsumer = buffer.getBuffer(class_1921.method_23287(this.method_23194(cube)));
            }

            this.method_17165().method_17081(model);
            model.method_2816(cube, limbSwing, limbSwingAmount, partialTick);
            model.method_2819(cube, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
            model.method_2828(poseStack, vertexConsumer, packedLight, class_922.method_23622(cube, 0.0F), -1);
        }
    }
}
