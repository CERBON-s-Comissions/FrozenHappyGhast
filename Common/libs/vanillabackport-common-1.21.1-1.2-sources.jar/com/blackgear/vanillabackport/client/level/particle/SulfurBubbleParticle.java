package com.blackgear.vanillabackport.client.level.particle;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2338;
import net.minecraft.class_2400;
import net.minecraft.class_3612;
import net.minecraft.class_3999;
import net.minecraft.class_4002;
import net.minecraft.class_4003;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;
import net.minecraft.client.particle.*;

@Environment(EnvType.CLIENT)
public class SulfurBubbleParticle extends class_4003 {
    private final double yStart;
    private final double yEnd;
    private final float sizeStart;
    private double yPrev;

    public SulfurBubbleParticle(
        class_638 level,
        double x,
        double y,
        double z,
        double xSpeed,
        double ySpeed,
        double zSpeed
    ) {
        super(level, x, y, z, xSpeed, ySpeed, zSpeed);
        this.field_3844 = -0.04F;
        this.field_28786 = 0.85F;
        this.method_3080(0.02F, 0.02F);
        this.field_3852 = xSpeed * 0.2F + (this.field_3840.method_43057() * 2.0F - 1.0F) * 0.02F;
        this.field_3850 = zSpeed * 0.2F + (this.field_3840.method_43057() * 2.0F - 1.0F) * 0.02F;
        this.sizeStart = 0.02F + 0.02F * this.field_3840.method_43057();
        this.field_17867 = this.sizeStart;
        this.field_3847 = Integer.MAX_VALUE;
        this.yStart = this.field_3838;
        this.yEnd = this.field_3838 + 4.0 - 1.0;
        this.yPrev = y;
    }

    @Override
    public void method_3070() {
        super.method_3070();
        if (!this.field_3843 && !this.field_3851.method_8316(class_2338.method_49637(this.field_3874, this.field_3854, this.field_3871)).method_33659(class_3612.field_15910)) {
            this.method_3085();
        }

        if (!this.field_3843 && this.field_3854 >= this.yEnd) {
            this.method_3085();
        }

        if (!this.field_3843 && this.field_3854 <= this.yPrev) {
            this.method_3085();
        }

        this.field_3852 = this.field_3852 + this.randomHorizontalWiggling();
        this.field_3850 = this.field_3850 + this.randomHorizontalWiggling();
        this.method_3069(this.field_3852, 0.0, this.field_3850);
        float travelProgress = (float) ((this.field_3854 - this.yStart) / (this.yEnd - this.yStart));
        this.field_17867 = this.sizeStart + travelProgress * (0.15F - this.sizeStart);
        this.yPrev = this.field_3854;
    }

    private double randomHorizontalWiggling() {
        return this.field_3840.method_43057() * 0.003F * (this.field_3840.method_43056() ? 1 : -1) * 0.5;
    }

    @Override
    public class_3999 method_18122() {
        return class_3999.field_17828;
    }

    @Environment(EnvType.CLIENT)
    public record Provider(class_4002 sprite) implements class_707<class_2400> {
        @Override
        public class_703 createParticle(
            class_2400 type,
            class_638 level,
            double x,
            double y,
            double z,
            double xSpeed,
            double ySpeed,
            double zSpeed
        ) {
            SulfurBubbleParticle particle = new SulfurBubbleParticle(level, x, y, z, xSpeed, ySpeed, zSpeed);
            particle.method_18140(this.sprite);
            return particle;
        }
    }
}