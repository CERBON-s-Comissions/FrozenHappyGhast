package com.blackgear.vanillabackport.client.level.animation;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_7179;
import net.minecraft.class_7184;
import net.minecraft.class_7186;
import net.minecraft.class_7187;

@Environment(EnvType.CLIENT)
public class NautilusAnimation {
	public static final class_7184 SWIMMING = class_7184.class_7185.method_41818(1.0F)
		.method_41817()
		.method_41820(
			"body",
			new class_7179(
				class_7179.class_7183.field_37888,
				new class_7186(0.0F, class_7187.method_41822(1.0, 1.0, 1.0), class_7179.class_7181.field_37884),
				new class_7186(0.5F, class_7187.method_41822(1.0, 1.0, 1.2F), class_7179.class_7181.field_37884),
				new class_7186(0.75F, class_7187.method_41822(1.0, 1.0, 0.9F), class_7179.class_7181.field_37884),
				new class_7186(0.875F, class_7187.method_41822(1.0, 1.0, 1.0), class_7179.class_7181.field_37884),
				new class_7186(1.0F, class_7187.method_41822(1.0, 1.0, 1.0), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"upper_mouth",
			new class_7179(
				class_7179.class_7183.field_37887,
				new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.5F, class_7187.method_41829(30.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.75F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.875F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"upper_mouth",
			new class_7179(
				class_7179.class_7183.field_37888,
				new class_7186(0.0F, class_7187.method_41822(1.0, 1.0, 1.0), class_7179.class_7181.field_37884),
				new class_7186(0.5F, class_7187.method_41822(1.0, 1.0, 1.4F), class_7179.class_7181.field_37884),
				new class_7186(0.75F, class_7187.method_41822(1.0, 1.0, 0.9F), class_7179.class_7181.field_37884),
				new class_7186(0.875F, class_7187.method_41822(1.0, 1.0, 1.0), class_7179.class_7181.field_37884),
				new class_7186(1.0F, class_7187.method_41822(1.0, 1.0, 1.0), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"inner_mouth",
			new class_7179(
				class_7179.class_7183.field_37888,
				new class_7186(0.0F, class_7187.method_41822(1.0, 1.0, 1.0), class_7179.class_7181.field_37884),
				new class_7186(0.5F, class_7187.method_41822(0.8F, 0.8F, 1.0), class_7179.class_7181.field_37884),
				new class_7186(0.75F, class_7187.method_41822(1.0, 1.0, 0.9F), class_7179.class_7181.field_37884),
				new class_7186(0.875F, class_7187.method_41822(1.0, 1.0, 1.0), class_7179.class_7181.field_37884),
				new class_7186(1.0F, class_7187.method_41822(1.0, 1.0, 1.0), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"lower_mouth",
			new class_7179(
				class_7179.class_7183.field_37887,
				new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.5F, class_7187.method_41829(-30.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.75F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.875F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"lower_mouth",
			new class_7179(
				class_7179.class_7183.field_37888,
				new class_7186(0.0F, class_7187.method_41822(1.0, 1.0, 1.0), class_7179.class_7181.field_37884),
				new class_7186(0.5F, class_7187.method_41822(1.0, 1.0, 1.4F), class_7179.class_7181.field_37884),
				new class_7186(0.75F, class_7187.method_41822(1.0, 1.0, 0.9F), class_7179.class_7181.field_37884),
				new class_7186(0.875F, class_7187.method_41822(1.0, 1.0, 1.0), class_7179.class_7181.field_37884),
				new class_7186(1.0F, class_7187.method_41822(1.0, 1.0, 1.0), class_7179.class_7181.field_37884)
			)
		)
		.method_41821();
}
