package com.blackgear.vanillabackport.client.level.renderer.entity;

import com.blackgear.platform.client.api.model.CustomBoatModel;
import com.blackgear.vanillabackport.common.level.entities.boat.BoatRegistry;
import com.blackgear.vanillabackport.common.level.entities.boat.BoatRegistry.BoatType;
import com.blackgear.vanillabackport.common.level.entities.boat.CustomBoatBehavior;
import com.mojang.datafixers.util.Pair;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1690;
import net.minecraft.class_2960;
import net.minecraft.class_4595;
import net.minecraft.class_5617;
import net.minecraft.class_881;
import java.util.Map;

@Environment(EnvType.CLIENT)
public class CustomBoatRenderer extends class_881 implements CustomBoatModel {
    private final Map<BoatType, Pair<class_2960, class_4595<class_1690>>> boatResource;

    public CustomBoatRenderer(class_5617.class_5618 context, boolean chestBoat) {
        super(context, chestBoat);
        this.boatResource = BoatRegistry.createModels(context, chestBoat);
    }

    public Pair<class_2960, class_4595<class_1690>> getModelWithLocation(class_1690 boat) {
        return boat instanceof CustomBoatBehavior custom ? this.boatResource.get(custom.getBoatType()) : this.boatResource.get(BoatRegistry.getType(BoatRegistry.DEFAULT_TYPE));
    }
}