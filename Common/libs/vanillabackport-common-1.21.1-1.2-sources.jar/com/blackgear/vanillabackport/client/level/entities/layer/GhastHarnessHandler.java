package com.blackgear.vanillabackport.client.level.entities.layer;

import com.blackgear.vanillabackport.client.level.layer.GhastEquipmentManager;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1799;
import net.minecraft.class_2960;

/**
 * added for retro-compatibility with Dye the World, highly recommended for the dev to migrate!
 */
@Environment(EnvType.CLIENT) @Deprecated(forRemoval = true)
public class GhastHarnessHandler {
    public static void register(class_1799 stack, class_2960 texture) {
        GhastEquipmentManager.register(stack.method_7909(), texture);
    }
}