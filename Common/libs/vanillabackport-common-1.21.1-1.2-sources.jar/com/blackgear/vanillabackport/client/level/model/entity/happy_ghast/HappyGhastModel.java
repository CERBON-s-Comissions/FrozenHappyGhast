package com.blackgear.vanillabackport.client.level.model.entity.happy_ghast;

import com.blackgear.vanillabackport.common.level.entities.mob.animal.happy_ghast.HappyGhast;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1304;
import net.minecraft.class_3532;
import net.minecraft.class_5597;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_630;
import net.minecraft.client.model.geom.builders.*;

@Environment(EnvType.CLIENT)
public class HappyGhastModel<T extends HappyGhast> extends class_5597<T> {
    private final class_630 root;
    private final class_630 body;
    private final class_630 inner_body;
    private final class_630[] tentacles = new class_630[9];

    public HappyGhastModel(class_630 root) {
        this.root = root;
        this.body = root.method_32086("body");
        this.inner_body = this.body.method_32086("inner_body");
        
        for (int i = 0; i < this.tentacles.length; i++) {
            this.tentacles[i] = this.body.method_32086(createTentacleName(i));
        }
    }

    private static String createTentacleName(int index) {
        return "tentacle" + index;
    }

    public static class_5607 createBodyLayer(class_5605 deformation) {
        class_5609 mesh = new class_5609();
        class_5610 root = mesh.method_32111();
        class_5610 body = root.method_32117(
            "body",
            class_5606.method_32108().method_32101(0, 0).method_32098(-8.0F, -8.0F, -8.0F, 16.0F, 16.0F, 16.0F, deformation),
            class_5603.method_32090(0.0F, 16.0F, 0.0F)
        );

        body.method_32117(
            "inner_body",
            class_5606.method_32108().method_32101(0, 32).method_32098(-8.0F, -16.0F, -8.0F, 16.0F, 16.0F, 16.0F, deformation.method_32094(-0.5F)),
            class_5603.method_32090(0.0F, 8.0F, 0.0F)
        );

        body.method_32117(
            createTentacleName(0),
            class_5606.method_32108()
                .method_32101(0, 0)
                .method_32098(-1.0F, 0.0F, -1.0F, 2.0F, 5.0F, 2.0F, deformation),
            class_5603.method_32090(-3.75F, 7.0F, -5.0F)
        );
        body.method_32117(
            createTentacleName(1),
            class_5606.method_32108()
                .method_32101(0, 0)
                .method_32098(-1.0F, 0.0F, -1.0F, 2.0F, 7.0F, 2.0F, deformation),
            class_5603.method_32090(1.25F, 7.0F, -5.0F)
        );
        body.method_32117(
            createTentacleName(2),
            class_5606.method_32108()
                .method_32101(0, 0)
                .method_32098(-1.0F, 0.0F, -1.0F, 2.0F, 4.0F, 2.0F, deformation),
            class_5603.method_32090(6.25F, 7.0F, -5.0F)
        );
        body.method_32117(
            createTentacleName(3),
            class_5606.method_32108()
                .method_32101(0, 0)
                .method_32098(-1.0F, 0.0F, -1.0F, 2.0F, 5.0F, 2.0F, deformation),
            class_5603.method_32090(-6.25F, 7.0F, 0.0F)
        );
        body.method_32117(
            createTentacleName(4),
            class_5606.method_32108()
                .method_32101(0, 0)
                .method_32098(-1.0F, 0.0F, -1.0F, 2.0F, 5.0F, 2.0F, deformation),
            class_5603.method_32090(-1.25F, 7.0F, 0.0F)
        );
        body.method_32117(
            createTentacleName(5),
            class_5606.method_32108()
                .method_32101(0, 0)
                .method_32098(-1.0F, 0.0F, -1.0F, 2.0F, 7.0F, 2.0F, deformation),
            class_5603.method_32090(3.75F, 7.0F, 0.0F)
        );
        body.method_32117(
            createTentacleName(6),
            class_5606.method_32108()
                .method_32101(0, 0)
                .method_32098(-1.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F, deformation),
            class_5603.method_32090(-3.75F, 7.0F, 5.0F)
        );
        body.method_32117(
            createTentacleName(7),
            class_5606.method_32108()
                .method_32101(0, 0)
                .method_32098(-1.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F, deformation),
            class_5603.method_32090(1.25F, 7.0F, 5.0F)
        );
        body.method_32117(
            createTentacleName(8),
            class_5606.method_32108()
                .method_32101(0, 0)
                .method_32098(-1.0F, 0.0F, -1.0F, 2.0F, 5.0F, 2.0F, deformation),
            class_5603.method_32090(6.25F, 7.0F, 5.0F)
        );

        return class_5607.method_32110(mesh, 64, 64);
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        this.inner_body.field_3665 = entity.method_6109();

        if (entity.method_6084(class_1304.field_6174)) {
            this.body.field_37938 = 0.9375F;
            this.body.field_37939 = 0.9375F;
            this.body.field_37940 = 0.9375F;
        }
        
        for (int i = 0; i < this.tentacles.length; i++) {
            this.tentacles[i].field_3654 = 0.2F * class_3532.method_15374(ageInTicks * 0.3F + (float) i) + 0.4F;
        }
    }

    @Override
    public class_630 method_32008() {
        return this.root;
    }
}