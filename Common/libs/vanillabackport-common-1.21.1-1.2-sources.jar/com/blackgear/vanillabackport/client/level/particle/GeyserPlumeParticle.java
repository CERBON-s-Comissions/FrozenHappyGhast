package com.blackgear.vanillabackport.client.level.particle;

import com.blackgear.vanillabackport.client.level.particle.particleoptions.GeyserParticleOptions;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_3532;
import net.minecraft.class_3999;
import net.minecraft.class_4002;
import net.minecraft.class_4003;
import net.minecraft.class_5819;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;
import net.minecraft.client.particle.*;

@Environment(EnvType.CLIENT)
public class GeyserPlumeParticle extends class_4003 {
    private final class_4002 sprites;
    private final double startY;
    private final double maxY;
    private final float initialPropulsion;
    private final float horizontalSprayX;
    private final float horizontalSprayZ;
    private final float minSize;
    private final float maxSize;
    private boolean done;

    public GeyserPlumeParticle(
        class_638 level,
        double x,
        double y,
        double z,
        double xSpeed,
        double ySpeed,
        double zSpeed,
        GeyserParticleOptions options,
        class_4002 sprites
    ) {
        super(level, x, y, z, xSpeed, ySpeed, zSpeed);
        int plumeHeight = 5 * Math.max(1, options.waterBlocks());
        this.field_3862 = true;
        this.field_28787 = true;
        this.field_3847 = plumeHeight * 5;
        this.field_3869 = 0.0;
        this.startY = y;
        this.maxY = this.startY + plumeHeight - 1.0;
        this.horizontalSprayX = (level.method_8409().method_43057() - 0.5F) * 0.2F;
        this.horizontalSprayZ = (level.method_8409().method_43057() - 0.5F) * 0.2F;
        this.field_28786 = 1.0F;
        this.initialPropulsion = (options.waterBlocks() == 1 ? 1.5F : 1.0F) * plumeHeight * 1.45F;
        this.field_3844 = -this.initialPropulsion;
        float size = this.field_17867 * 0.75F;
        this.minSize = size * (2.0F + plumeHeight / 8.0F);
        this.maxSize = size * (3.0F + plumeHeight / 8.0F);
        this.field_17867 = this.minSize;
        this.sprites = sprites;
        this.method_18142(sprites);
    }

    @Override
    public void method_3070() {
        super.method_3070();
        if (!this.done && (this.field_3869 < 0.0 || this.field_3854 > this.maxY || this.field_3854 == this.field_3838)) {
            this.field_3847 = Math.min(this.field_3847, this.field_3866 + 5);
            this.field_28786 = 0.0F;
            this.done = true;
        }

        double yProgressLinear = class_3532.method_15350((this.field_3854 - this.startY) / (this.maxY - this.startY), 0.0, 1.0);
        double yProgressExponential = Math.pow(yProgressLinear, 3.0);
        this.field_3844 = this.initialPropulsion * (float) yProgressExponential * 0.12F;
        this.field_3852 = yProgressLinear * this.horizontalSprayX;
        this.field_3850 = yProgressLinear * this.horizontalSprayZ;
        this.method_18142(this.sprites);
        this.field_17867 = minSize + (float) (yProgressLinear * (this.maxSize - this.minSize));
    }

    @Override
    public class_3999 method_18122() {
        return class_3999.field_17828;
    }

    @Environment(EnvType.CLIENT)
    public record Provider(class_4002 sprites) implements class_707<GeyserParticleOptions> {
        @Override
        public class_703 createParticle(
            GeyserParticleOptions options,
            class_638 level,
            double x,
            double y,
            double z,
            double xSpeed,
            double ySpeed,
            double zSpeed
        ) {
            class_5819 random = level.method_8409();
            double randomX = x + (random.method_43057() - 0.5F) * 0.2F;
            double randomY = y + random.method_43057();
            double randomZ = z + (random.method_43057() - 0.5F) * 0.2F;
            return new GeyserPlumeParticle(level, randomX, randomY, randomZ, xSpeed, ySpeed, zSpeed, options, this.sprites);
        }
    }
}