package com.blackgear.vanillabackport.client.level.particle;

import com.blackgear.vanillabackport.client.level.particle.particleoptions.GeyserBaseParticleOptions;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_4002;
import net.minecraft.class_4794;
import net.minecraft.class_5819;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;

@Environment(EnvType.CLIENT)
public class GeyserBaseParticle extends class_4794 {
    protected GeyserBaseParticle(
        class_638 level,
        double x,
        double y,
        double z,
        double xAux,
        double yAux,
        double zAux,
        float burstImpulse,
        float size,
        class_4002 sprites
    ) {
        super(level, x, y, z, burstImpulse, burstImpulse, burstImpulse, xAux, yAux, zAux, size, sprites, 0.0F, 0, 0, true);
        this.field_28786 = 0.725F;
        this.field_3861 = 1.0F;
        this.field_3842 = 1.0F;
        this.field_3859 = 1.0F;
        this.field_3869 = Math.abs(this.field_3869);
        float lifetime = 0.8F + 0.2F * level.method_8409().method_43057();
        this.field_3847 = (int) (25.0F * lifetime);
    }

    @Environment(EnvType.CLIENT)
    public record Provider(class_4002 sprites) implements class_707<GeyserBaseParticleOptions> {
        @Override
        public class_703 createParticle(
            GeyserBaseParticleOptions type,
            class_638 level,
            double x,
            double y,
            double z,
            double xSpeed,
            double ySpeed,
            double zSpeed
        ) {
            class_5819 random = level.method_8409();
            double randomX = x + (random.method_43057() - 0.5F) * 0.5F;
            double randomY = y + (random.method_43057() - 0.5F) * 0.5F + 0.2F;
            double randomZ = z + (random.method_43057() - 0.5F) * 0.5F;
            float burstImpulse = type.burstImpulseBase() + 0.25F + type.waterBlocks();
            float size = 3.0F + 0.125F * type.waterBlocks();
            return new GeyserBaseParticle(
                level,
                randomX,
                randomY,
                randomZ,
                xSpeed,
                ySpeed,
                zSpeed,
                burstImpulse,
                size,
                this.sprites
            );
        }
    }
}