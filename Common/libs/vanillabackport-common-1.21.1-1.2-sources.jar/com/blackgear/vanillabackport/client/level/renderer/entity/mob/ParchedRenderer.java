package com.blackgear.vanillabackport.client.level.renderer.entity.mob;

import com.blackgear.vanillabackport.client.registries.ModModelLayers;
import com.blackgear.vanillabackport.common.level.entities.mob.monster.skeleton.Parched;
import net.minecraft.class_2960;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_5617;
import net.minecraft.class_946;
import net.minecraft.client.model.geom.builders.*;

public class ParchedRenderer extends class_946<Parched> {
    private static final class_2960 PARCHED_SKELETON_LOCATION = class_2960.method_60656("textures/entity/skeleton/parched.png");
    
    public ParchedRenderer(class_5617.class_5618 context) {
        super(context, ModModelLayers.PARCHED, ModModelLayers.PARCHED_INNER_ARMOR, ModModelLayers.PARCHED_OUTER_ARMOR);
    }
    
    @Override
    public class_2960 getTextureLocation(Parched entity) {
        return PARCHED_SKELETON_LOCATION;
    }
    
    public static class_5607 createSingleModelDualBodyLayer() {
        class_5609 mesh = new class_5609();
        class_5610 root = mesh.method_32111();
        root.method_32117(
            "body",
            class_5606.method_32108()
                .method_32101(16, 16)
                .method_32097(-4.0F, 0.0F, -2.0F, 8.0F, 12.0F, 4.0F)
                .method_32101(28, 0)
                .method_32097(-4.0F, 10.0F, -2.0F, 8.0F, 1.0F, 4.0F)
                .method_32101(16, 48)
                .method_32098(-4.0F, 0.0F, -2.0F, 8.0F, 12.0F, 4.0F, new class_5605(0.025F)),
            class_5603.method_32090(0.0F, 0.0F, 0.0F)
        );
        root.method_32117(
            "head",
            class_5606.method_32108()
                .method_32101(0, 0)
                .method_32097(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F)
                .method_32101(0, 32)
                .method_32098(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F, new class_5605(0.2F)),
            class_5603.method_32090(0.0F, 0.0F, 0.0F)
        );
        root.method_32117("hat", class_5606.method_32108(), class_5603.field_27701);
        root.method_32117(
            "right_arm",
            class_5606.method_32108().method_32101(40, 16).method_32097(-1.0F, -2.0F, -1.0F, 2.0F, 12.0F, 2.0F).method_32101(42, 33).method_32097(-1.55F, -2.025F, -1.5F, 3.0F, 12.0F, 3.0F),
            class_5603.method_32090(-5.5F, 2.0F, 0.0F)
        );
        root.method_32117(
            "left_arm",
            class_5606.method_32108().method_32101(56, 16).method_32097(-1.0F, -2.0F, -1.0F, 2.0F, 12.0F, 2.0F).method_32101(40, 48).method_32097(-1.45F, -2.025F, -1.5F, 3.0F, 12.0F, 3.0F),
            class_5603.method_32090(5.5F, 2.0F, 0.0F)
        );
        root.method_32117(
            "right_leg",
            class_5606.method_32108().method_32101(0, 16).method_32097(-1.0F, 0.0F, -1.0F, 2.0F, 12.0F, 2.0F).method_32101(0, 49).method_32097(-1.5F, -0.0F, -1.5F, 3.0F, 12.0F, 3.0F),
            class_5603.method_32090(-2.0F, 12.0F, 0.0F)
        );
        root.method_32117(
            "left_leg",
            class_5606.method_32108().method_32101(0, 16).method_32097(-1.0F, 0.0F, -1.0F, 2.0F, 12.0F, 2.0F).method_32101(4, 49).method_32097(-1.5F, 0.0F, -1.5F, 3.0F, 12.0F, 3.0F),
            class_5603.method_32090(2.0F, 12.0F, 0.0F)
        );
        return class_5607.method_32110(mesh, 64, 64);
    }
}