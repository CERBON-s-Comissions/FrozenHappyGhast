package com.blackgear.vanillabackport.client.level.layer;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1299;
import net.minecraft.class_1472;
import net.minecraft.class_1767;
import net.minecraft.class_2960;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5253;
import net.minecraft.class_5599;
import net.minecraft.class_5602;
import net.minecraft.class_598;
import net.minecraft.class_601;

@Environment(EnvType.CLIENT)
public class SheepWoolUndercoatLayer extends class_3887<class_1472, class_601<class_1472>> {
    private static final class_2960 SHEEP_WOOL_UNDERCOAT_TEXTURE = class_2960.method_60656("textures/entity/sheep/sheep_wool_undercoat.png");
    private final class_598<class_1472> model;

    public SheepWoolUndercoatLayer(class_3883<class_1472, class_601<class_1472>> renderer, class_5599 models) {
        super(renderer);
        this.model = new class_598<>(models.method_32072(class_5602.field_27593));
    }

    @Override
    public void render(class_4587 poseStack, class_4597 buffer, int packedLight, class_1472 sheep, float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        if (sheep.method_5864() == class_1299.field_6115 && !sheep.method_5767()) {
            int color;
            if (sheep.method_16914() && "jeb_".equals(sheep.method_5477().getString())) {
                int offset = sheep.field_6012 / 25 + sheep.method_5628();
                int size = class_1767.values().length;
                int fromIndex = offset % size;
                int toIndex = (offset + 1) % size;
                float delta = ((float)(sheep.field_6012 % 25) + partialTick) / 25.0F;
                int fromColor = class_1472.method_6634(class_1767.method_7791(fromIndex));
                int toColor = class_1472.method_6634(class_1767.method_7791(toIndex));
                color = class_5253.class_5254.method_48780(delta, fromColor, toColor);
            } else {
                color = class_1472.method_6634(sheep.method_6633());
            }

            method_23196(this.method_17165(), this.model, SHEEP_WOOL_UNDERCOAT_TEXTURE, poseStack, buffer, packedLight, sheep, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, partialTick, color);
        }
    }
}
