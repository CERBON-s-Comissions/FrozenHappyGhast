package com.blackgear.vanillabackport.client.level.renderer.entity.mob;

import com.blackgear.vanillabackport.client.api.modules.mob_rendering.SpecialMobRenderer;
import com.blackgear.vanillabackport.client.api.modules.mob_rendering.ZombieNautilusVariantRenderer;
import com.blackgear.vanillabackport.client.level.layer.SimpleEquipmentLayer;
import com.blackgear.vanillabackport.client.level.model.entity.nautilus.NautilusModel;
import com.blackgear.vanillabackport.client.registries.ModModelLayers;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.nautilus.AbstractNautilus;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.nautilus.ZombieNautilus;
import com.blackgear.vanillabackport.common.level.items.NautilusArmorItem;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import net.minecraft.class_927;
import java.util.Optional;

@Environment(EnvType.CLIENT)
public class ZombieNautilusRenderer extends class_927<ZombieNautilus, NautilusModel<ZombieNautilus>> {
    private static final class_2960 NAUTILUS_LOCATION = class_2960.method_60656("textures/entity/nautilus/zombie_nautilus.png");
    private final SpecialMobRenderer<ZombieNautilus, NautilusModel<ZombieNautilus>> renderer;
    private final NautilusModel<ZombieNautilus> fallback;
    
    public ZombieNautilusRenderer(class_5617.class_5618 context) {
        super(context, new NautilusModel<>(context.method_32167(ModModelLayers.ZOMBIE_NAUTILUS)), 0.7F);
        this.renderer = SpecialMobRenderer.create(context, ZombieNautilusVariantRenderer::new);
        this.fallback = new NautilusModel<>(context.method_32167(ModModelLayers.ZOMBIE_NAUTILUS));
        this.method_4046(new SimpleEquipmentLayer<>(
            this,
            entity -> entity.method_56676().method_7909() instanceof NautilusArmorItem armor
                ? Optional.ofNullable(armor.getTexture())
                : Optional.empty(),
            entity -> true,
            new NautilusModel<>(context.method_32167(ModModelLayers.NAUTILUS_ARMOR)),
            null
        ));
        this.method_4046(SimpleEquipmentLayer.of(
            this,
            NautilusRenderer.NAUTILUS_SADDLE_LOCATION,
            AbstractNautilus::method_6725,
            new NautilusModel<>(context.method_32167(ModModelLayers.NAUTILUS_SADDLE)),
            null
        ));
    }
    
    @Override
    public class_2960 getTextureLocation(ZombieNautilus entity) {
        return this.renderer.getTexture(entity).orElse(NAUTILUS_LOCATION);
    }
    
    @Override
    public void render(ZombieNautilus entity, float entityYaw, float partialTicks, class_4587 poseStack, class_4597 buffer, int packedLight) {
        this.field_4737 = this.renderer.getModel(entity).orElse(this.fallback);
        super.method_4054(entity, entityYaw, partialTicks, poseStack, buffer, packedLight);
    }
}