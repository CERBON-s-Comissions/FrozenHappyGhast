package com.blackgear.vanillabackport.client.level.model.entity.nautilus;

import com.blackgear.vanillabackport.client.level.animation.NautilusAnimation;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.nautilus.AbstractNautilus;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_3532;
import net.minecraft.class_5597;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_630;
import net.minecraft.client.model.geom.builders.*;

@Environment(EnvType.CLIENT)
public class NautilusModel<T extends AbstractNautilus> extends class_5597<T> {
    protected final class_630 body;
    protected final class_630 nautilus;
    
    public NautilusModel(class_630 root) {
        this.nautilus = root.method_32086("root");
        this.body = this.nautilus.method_32086("body");
    }
    
    public static class_5607 createBodyLayer() {
        return class_5607.method_32110(createBodyMesh(), 128, 128);
    }
    
    public static class_5609 createBodyMesh() {
        class_5609 meshdefinition = new class_5609();
        class_5610 partdefinition = meshdefinition.method_32111();
        class_5610 nautilus = partdefinition.method_32117("root", class_5606.method_32108(), class_5603.method_32090(0.0F, 29.0F, -6.0F));
        nautilus.method_32117(
            "shell",
            class_5606.method_32108()
                .method_32101(0, 0)
                .method_32098(-7.0F, -10.0F, -7.0F, 14.0F, 10.0F, 16.0F, new class_5605(0.0F))
                .method_32101(0, 26)
                .method_32098(-7.0F, 0.0F, -7.0F, 14.0F, 8.0F, 20.0F, new class_5605(0.0F))
                .method_32101(48, 26)
                .method_32098(-7.0F, 0.0F, 6.0F, 14.0F, 8.0F, 0.0F, new class_5605(0.0F)),
            class_5603.method_32090(0.0F, -13.0F, 5.0F)
        );
        class_5610 body = nautilus.method_32117(
            "body",
            class_5606.method_32108()
                .method_32101(0, 54)
                .method_32098(-5.0F, -4.51F, -3.0F, 10.0F, 8.0F, 14.0F, new class_5605(0.0F))
                .method_32101(0, 76)
                .method_32098(-5.0F, -4.51F, 7.0F, 10.0F, 8.0F, 0.0F, new class_5605(0.0F)),
            class_5603.method_32090(0.0F, -8.5F, 12.3F)
        );
        body.method_32117(
            "upper_mouth",
            class_5606.method_32108().method_32101(54, 54).method_32098(-5.0F, -2.0F, 0.0F, 10.0F, 4.0F, 4.0F, new class_5605(-0.001F)),
            class_5603.method_32090(0.0F, -2.51F, 7.0F)
        );
        body.method_32117(
            "inner_mouth",
            class_5606.method_32108().method_32101(54, 70).method_32098(-3.0F, -2.0F, -0.5F, 6.0F, 4.0F, 4.0F, new class_5605(0.0F)),
            class_5603.method_32090(0.0F, -0.51F, 7.5F)
        );
        body.method_32117(
            "lower_mouth",
            class_5606.method_32108().method_32101(54, 62).method_32098(-5.0F, -1.98F, 0.0F, 10.0F, 4.0F, 4.0F, new class_5605(-0.001F)),
            class_5603.method_32090(0.0F, 1.49F, 7.0F)
        );
        return meshdefinition;
    }
    
    public static class_5607 createBabyBodyLayer() {
        class_5609 meshdefinition = new class_5609();
        class_5610 partdefinition = meshdefinition.method_32111();
        class_5610 nautilus = partdefinition.method_32117("root", class_5606.method_32108(), class_5603.method_32090(-0.5F, 28.0F, -0.5F));
        nautilus.method_32117(
            "shell",
            class_5606.method_32108()
                .method_32101(0, 0)
                .method_32098(-6.0F, -4.0F, -1.0F, 7.0F, 4.0F, 7.0F, new class_5605(0.0F))
                .method_32101(0, 11)
                .method_32098(-6.0F, 0.0F, -1.0F, 7.0F, 4.0F, 9.0F, new class_5605(0.0F))
                .method_32101(23, 11)
                .method_32098(-6.0F, 0.0F, 5.0F, 7.0F, 4.0F, 0.0F, new class_5605(0.0F)),
            class_5603.method_32090(3.0F, -8.0F, -2.0F)
        );
        class_5610 body = nautilus.method_32117(
            "body",
            class_5606.method_32108()
                .method_32101(0, 24)
                .method_32098(-2.5F, -3.01F, -1.0F, 5.0F, 4.0F, 7.0F, new class_5605(0.0F))
                .method_32101(0, 35)
                .method_32098(-2.5F, -3.01F, 4.1F, 5.0F, 4.0F, 0.0F, new class_5605(0.0F)),
            class_5603.method_32090(0.5F, -5.0F, 3.0F)
        );
        body.method_32117(
            "upper_mouth",
            class_5606.method_32108().method_32101(24, 24).method_32098(-2.5F, -1.0F, 0.0F, 5.0F, 2.0F, 2.0F, new class_5605(-0.001F)),
            class_5603.method_32090(0.0F, -2.01F, 3.9F)
        );
        body.method_32117(
            "inner_mouth",
            class_5606.method_32108().method_32101(24, 32).method_32098(-1.5F, -1.0F, -1.0F, 3.0F, 2.0F, 2.0F, new class_5605(0.0F)),
            class_5603.method_32090(0.0F, -1.01F, 4.9F)
        );
        body.method_32117(
            "lower_mouth",
            class_5606.method_32108().method_32101(24, 28).method_32098(-2.5F, -1.0F, 0.0F, 5.0F, 2.0F, 2.0F, new class_5605(-0.001F)),
            class_5603.method_32090(0.0F, -0.01F, 3.9F)
        );
        return class_5607.method_32110(meshdefinition, 64, 64);
    }
    
    public static class_5607 createSaddleLayer() {
        class_5609 meshdefinition = createBodyMesh();
        class_5610 partdefinition = meshdefinition.method_32111();
        class_5610 nautilus = partdefinition.method_32117("root", class_5606.method_32108(), class_5603.method_32090(0.0F, 29.0F, -6.0F));
        nautilus.method_32117(
            "shell",
            class_5606.method_32108().method_32101(0, 0).method_32098(-7.0F, -10.0F, -7.0F, 14.0F, 10.0F, 16.0F, new class_5605(0.2F)),
            class_5603.method_32090(0.0F, -13.0F, 5.0F)
        );
        return class_5607.method_32110(meshdefinition, 128, 128);
    }
    
    public static class_5607 createBodyArmorLayer() {
        class_5609 meshdefinition = createBodyMesh();
        class_5610 partdefinition = meshdefinition.method_32111();
        class_5610 nautilus = partdefinition.method_32117("root", class_5606.method_32108(), class_5603.method_32090(0.0F, 29.0F, -6.0F));
        nautilus.method_32117(
            "shell",
            class_5606.method_32108()
                .method_32101(0, 0)
                .method_32098(-7.0F, -10.0F, -7.0F, 14.0F, 10.0F, 16.0F, new class_5605(0.01F))
                .method_32101(0, 26)
                .method_32098(-7.0F, 0.0F, -7.0F, 14.0F, 8.0F, 20.0F, new class_5605(0.01F))
                .method_32101(48, 26)
                .method_32098(-7.0F, 0.0F, 6.0F, 14.0F, 8.0F, 0.0F, new class_5605(0.0F)),
            class_5603.method_32090(0.0F, -13.0F, 5.0F)
        );
        return class_5607.method_32110(meshdefinition, 128, 128);
    }
    
    @Override
    public class_630 method_32008() {
        return this.nautilus;
    }
    
    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        this.method_32008().method_32088().forEach(class_630::method_41923);
        this.applyBodyRotation(netHeadYaw, headPitch);
        this.method_48741(NautilusAnimation.SWIMMING, limbSwing + ageInTicks / 5.0F, limbSwingAmount + 0.2F, 2.0F, 3.0F);
    }
    
    private void applyBodyRotation(float yRot, float xRot) {
        yRot = class_3532.method_15363(yRot, -10.0F, 10.0F);
        xRot = class_3532.method_15363(xRot, -10.0F, 10.0F);
        this.body.field_3675 = yRot * class_3532.field_29847;
        this.body.field_3654 = xRot * class_3532.field_29847;
        
    }
}