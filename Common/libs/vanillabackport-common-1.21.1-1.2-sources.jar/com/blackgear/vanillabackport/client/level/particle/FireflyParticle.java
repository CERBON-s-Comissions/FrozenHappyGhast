package com.blackgear.vanillabackport.client.level.particle;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2338;
import net.minecraft.class_2400;
import net.minecraft.class_3532;
import net.minecraft.class_3999;
import net.minecraft.class_4002;
import net.minecraft.class_4003;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;
import net.minecraft.client.particle.*;

@Environment(EnvType.CLIENT)
public class FireflyParticle extends class_4003 {
    private static final float PARTICLE_FADE_OUT_LIGHT_TIME = 0.3F;
    private static final float PARTICLE_FADE_IN_LIGHT_TIME = 0.1F;
    private static final float PARTICLE_FADE_OUT_ALPHA_TIME = 0.5F;
    private static final float PARTICLE_FADE_IN_ALPHA_TIME = 0.3F;
    private static final int PARTICLE_MIN_LIFETIME = 200;
    private static final int PARTICLE_MAX_LIFETIME = 300;

    protected FireflyParticle(class_638 level, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
        super(level, x, y, z, xSpeed, ySpeed, zSpeed);
        this.field_28787 = true;
        this.field_28786 = 0.96F;
        this.field_17867 *= 0.75F;
        this.field_3869 *= 0.8F;
        this.field_3852 *= 0.8F;
        this.field_3850 *= 0.8F;
    }

    @Override
    public class_3999 method_18122() {
        return class_3999.field_17829;
    }

    @Override
    protected int method_3068(float partialTick) {
        return (int) (255.0F * this.getFadeAmount(this.getLifetimeProgress(this.field_3866 + partialTick), PARTICLE_FADE_IN_LIGHT_TIME, PARTICLE_FADE_OUT_LIGHT_TIME));
    }

    @Override
    public void method_3070() {
        super.method_3070();
        if (!this.field_3851.method_8320(class_2338.method_49637(this.field_3874, this.field_3854, this.field_3871)).method_26215()) {
            this.method_3085();
        } else {
            this.method_3083(this.getFadeAmount(this.getLifetimeProgress(this.field_3866), PARTICLE_FADE_IN_ALPHA_TIME, PARTICLE_FADE_OUT_ALPHA_TIME));
            if (Math.random() > 0.95 || this.field_3866 == 1) {
                this.method_34753(-0.05 + 0.1F * Math.random(), -0.05 + 0.1F * Math.random(), -0.05 + 0.1F * Math.random());
            }
        }
    }

    private float getLifetimeProgress(float age) {
        return class_3532.method_15363(age / this.field_3847, 0.0F, 1.0F);
    }

    private float getFadeAmount(float lifetime, float fadeIn, float fadeOut) {
        if (lifetime >= 1.0F - fadeIn) {
            return (1.0F - lifetime) / fadeIn;
        } else {
            return lifetime <= fadeOut ? lifetime / fadeOut : 1.0F;
        }
    }

    @Environment(EnvType.CLIENT)
    public record Provider(class_4002 sprite) implements class_707<class_2400> {
        @Override
        public class_703 createParticle(class_2400 type, class_638 level, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
            FireflyParticle particle = new FireflyParticle(level, x, y, z, 0.5 - level.field_9229.method_43058(), level.field_9229.method_43056() ? ySpeed : -ySpeed, 0.5 - level.field_9229.method_43058());
            particle.method_3077(level.field_9229.method_39332(PARTICLE_MIN_LIFETIME, PARTICLE_MAX_LIFETIME));
            particle.method_3087(1.5F);
            particle.method_18140(this.sprite);
            particle.method_3083(0.0F);
            return particle;
        }
    }
}