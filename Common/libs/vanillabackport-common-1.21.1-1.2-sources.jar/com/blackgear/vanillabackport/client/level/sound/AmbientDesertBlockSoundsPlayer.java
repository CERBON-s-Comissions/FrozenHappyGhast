package com.blackgear.vanillabackport.client.level.sound;

import com.blackgear.vanillabackport.client.registries.ModSoundEvents;
import com.blackgear.vanillabackport.core.data.tags.ModBlockTags;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2902;
import net.minecraft.class_3419;
import net.minecraft.class_3481;
import net.minecraft.class_5819;

public class AmbientDesertBlockSoundsPlayer {
    private static final int IDLE_SOUND_CHANCE = 2100;
    private static final int DRY_GRASS_SOUND_CHANCE = 200;
    private static final int DEAD_BUSH_SOUND_CHANCE = 130;
    private static final int DEAD_BUSH_SOUND_BADLANDS_DECREASED_CHANCE = 3;
    private static final int SURROUNDING_BLOCKS_PLAY_SOUND_THRESHOLD = 3;
    private static final int SURROUNDING_BLOCKS_DISTANCE_HORIZONTAL_CHECK = 8;
    private static final int SURROUNDING_BLOCKS_DISTANCE_VERTICAL_CHECK = 5;
    private static final int HORIZONTAL_DIRECTIONS = 4;

    public static void playAmbientSandSounds(class_1937 level, class_2338 pos, class_5819 random) {
        if (!level.method_8320(pos).method_26164(class_3481.field_15466)) return;

        if (level.method_8320(pos.method_10084()).method_27852(class_2246.field_10124)) {
            if (random.method_43048(IDLE_SOUND_CHANCE) == 0 && shouldPlayAmbientSandSound(level, pos)) {
                level.method_8486(pos.method_10263(), pos.method_10264(), pos.method_10260(), ModSoundEvents.SAND_IDLE.get(), class_3419.field_15256, 1.0F, 1.0F, false);
            }
        }
    }

    public static void playAmbientDryGrassSounds(class_1937 level, class_2338 pos, class_5819 random) {
        if (random.method_43048(DRY_GRASS_SOUND_CHANCE) == 0 && shouldPlayDesertDryVegetationBlockSounds(level, pos.method_10074())) {
            level.method_8486(pos.method_10263(), pos.method_10264(), pos.method_10260(), ModSoundEvents.DRY_GRASS.get(), class_3419.field_15256, 1.0F, 1.0F, false);
        }
    }

    public static void playAmbientDeadBushSounds(class_1937 level, class_2338 pos, class_5819 random) {
        if (random.method_43048(DEAD_BUSH_SOUND_CHANCE) == 0) {
            class_2680 belowPos = level.method_8320(pos.method_10074());
            if ((belowPos.method_27852(class_2246.field_10534) || belowPos.method_26164(class_3481.field_36265)) && random.method_43048(DEAD_BUSH_SOUND_BADLANDS_DECREASED_CHANCE) != 0) {
                return;
            }

            if (shouldPlayDesertDryVegetationBlockSounds(level, pos.method_10074())) {
                level.method_8486(pos.method_10263(), pos.method_10264(), pos.method_10260(), ModSoundEvents.DEAD_BUSH_IDLE.get(), class_3419.field_15256, 1.0F, 1.0F, false);
            }
        }
    }

    public static boolean shouldPlayDesertDryVegetationBlockSounds(class_1937 level, class_2338 belowPos) {
        return level.method_8320(belowPos).method_26164(ModBlockTags.TRIGGERS_AMBIENT_DESERT_DRY_VEGETATION_BLOCK_SOUNDS)
            && level.method_8320(belowPos.method_10074()).method_26164(ModBlockTags.TRIGGERS_AMBIENT_DESERT_DRY_VEGETATION_BLOCK_SOUNDS);
    }

    private static boolean shouldPlayAmbientSandSound(class_1937 level, class_2338 pos) {
        int matchingBlocksFound = 0, sidesChecked = 0;
        class_2338.class_2339 mutablePos = pos.method_25503();

        for (class_2350 dir : class_2350.class_2353.field_11062) {
            mutablePos.method_10101(pos).method_10104(dir, SURROUNDING_BLOCKS_DISTANCE_HORIZONTAL_CHECK);
            if (columnContainsTriggeringBlock(level, mutablePos) && matchingBlocksFound++ >= SURROUNDING_BLOCKS_PLAY_SOUND_THRESHOLD) {
                return true;
            }

            sidesChecked++;
            int remainingSides = HORIZONTAL_DIRECTIONS - sidesChecked;
            int potentialMatches = remainingSides + matchingBlocksFound;
            if (potentialMatches < SURROUNDING_BLOCKS_PLAY_SOUND_THRESHOLD) {
                return false;
            }
        }

        return false;
    }

    private static boolean columnContainsTriggeringBlock(class_1937 level, class_2338.class_2339 mutablePos) {
        int surfaceY = level.method_8624(class_2902.class_2903.field_13202, mutablePos.method_10263(), mutablePos.method_10260()) - 1;
        if (Math.abs(surfaceY - mutablePos.method_10264()) > SURROUNDING_BLOCKS_DISTANCE_VERTICAL_CHECK) {
            mutablePos.method_10104(class_2350.field_11036, 6);
            class_2680 aboveBlockState = level.method_8320(mutablePos);
            mutablePos.method_10098(class_2350.field_11033);

            for (int i = 0; i < 10; i++) {
                class_2680 currentBlockState = level.method_8320(mutablePos);
                if (aboveBlockState.method_26215() && canTriggerAmbientDesertSandSounds(currentBlockState)) {
                    return true;
                }

                aboveBlockState = currentBlockState;
                mutablePos.method_10098(class_2350.field_11033);
            }

            return false;
        } else {
            boolean hasAirAbove = level.method_8320(mutablePos.method_33098(surfaceY + 1)).method_26215();
            return hasAirAbove && canTriggerAmbientDesertSandSounds(level.method_8320(mutablePos.method_33098(surfaceY)));
        }
    }

    private static boolean canTriggerAmbientDesertSandSounds(class_2680 state) {
        return state.method_26164(ModBlockTags.TRIGGERS_AMBIENT_DESERT_SAND_BLOCK_SOUNDS);
    }
}