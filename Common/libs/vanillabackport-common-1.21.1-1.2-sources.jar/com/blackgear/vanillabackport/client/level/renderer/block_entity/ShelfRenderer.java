package com.blackgear.vanillabackport.client.level.renderer.block_entity;

import com.blackgear.vanillabackport.client.level.renderer.item.ModelBoundingBoxManager;
import com.blackgear.vanillabackport.common.level.blocks.ShelfBlock;
import com.blackgear.vanillabackport.common.level.block_entities.ShelfBlockEntity;
import it.unimi.dsi.fastutil.HashCommon;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_238;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5614;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_827;
import net.minecraft.class_918;

public class ShelfRenderer implements class_827<ShelfBlockEntity> {
    private static final float BASE_ITEM_SCALE = 0.25F;
    private static final float TARGET_EXTRA_SCALE = 2.0F;
    private static final float SLOT_WIDTH = 4.0F / 16.0F;
    private static final float SLOT_HEIGHT = 8.0F / 16.0F;
    private static final float ITEM_OFFSET_X = 0.3125F;
    
    private final Map<class_1792, ItemScaleData> cache = new HashMap<>();
    private final class_918 itemRenderer;
    
    public ShelfRenderer(class_5614.class_5615 context) {
        this.itemRenderer = context.method_43335();
    }
    
    @Override
    public void render(ShelfBlockEntity shelf, float partialTick, class_4587 pose, class_4597 buffer, int packedLight, int packedOverlay) {
        class_2350 direction = shelf.method_11010().method_11654(ShelfBlock.FACING);
        float yRot = direction.method_10166().method_10179() ? -direction.method_10144() : 180.0F;
        
        class_2371<class_1799> items = shelf.getItems();
        int seed = HashCommon.long2int(shelf.method_11016().method_10063());
        boolean alignToBottom = shelf.getAlignItemsToBottom();
        
        for (int slot = 0; slot < items.size(); slot++) {
            class_1799 stack = items.get(slot);
            if (stack.method_7960()) continue;
            
            float slotOffsetX = (slot - 1) * ITEM_OFFSET_X;
            
            pose.method_22903();
            pose.method_46416(0.5F, 0.5F, 0.5F);
            pose.method_22907(class_7833.field_40716.rotationDegrees(yRot));
            pose.method_22907(class_7833.field_40716.rotationDegrees(180.0F));
            pose.method_46416(-slotOffsetX, alignToBottom ? -0.25F : 0.0F, 0.27F);
            pose.method_22905(BASE_ITEM_SCALE, BASE_ITEM_SCALE, BASE_ITEM_SCALE);
            
            class_1937 level = shelf.method_10997();
            class_1087 model = this.itemRenderer.method_4019(stack, level, null, seed + slot);
            ItemScaleData scaleData = this.getItemScaleData(stack, model, level, seed + slot);
            class_238 bounds = scaleData.bounds();
            
            pose.method_22905(scaleData.scale(), scaleData.scale(), scaleData.scale());
            
            double offsetY = -bounds.field_1322;
            if (!alignToBottom) offsetY += -(bounds.field_1325 - bounds.field_1322) / 2.0;
            pose.method_22904(0.0, offsetY, 0.0);
            
            boolean isCustom = model.method_4713();
            if (isCustom) {
                Vector3f scale = model.method_4709().method_3503(class_811.field_4319).field_4285;
                pose.method_22903();
                pose.method_22905(0.9F / normalizeScale(scale.x()), 0.9F / normalizeScale(scale.y()), 0.9F / normalizeScale(scale.z()));
                this.itemRenderer.method_23178(stack, class_811.field_4319, packedLight, packedOverlay, pose, buffer, level, seed + slot);
                pose.method_22909();
            } else {
                this.itemRenderer.method_23178(stack, class_811.field_4319, packedLight, packedOverlay, pose, buffer, level, seed + slot);
            }
            
            pose.method_22909();
        }
    }
    
    private static float normalizeScale(float value) {
        return Math.abs(value) > class_3532.field_29849 ? value : 1.0F;
    }
    
    private ItemScaleData getItemScaleData(class_1799 stack, class_1087 model, class_1937 level, int seed) {
        return this.cache.computeIfAbsent(stack.method_7909(), key -> computeItemScale(stack, model, level, seed));
    }
    
    private ItemScaleData computeItemScale(class_1799 stack, class_1087 model, class_1937 level, int seed) {
        class_238 bounds = ModelBoundingBoxManager.INSTANCE.getModelBoundingBox(model, stack, this.itemRenderer, level, seed);
        double width = bounds.field_1320 - bounds.field_1323;
        double height = bounds.field_1325 - bounds.field_1322;
        
        boolean isCustom = model.method_4713();
        if (!isCustom && isFlatModel(bounds)) {
            return new ItemScaleData(bounds, 1.0F);
        }
        
        float scale = calculateOptimalScale(width, height, isCustom);
        return new ItemScaleData(bounds, scale);
    }
    
    private static float calculateOptimalScale(double width, double height, boolean customRenderer) {
        float scale = TARGET_EXTRA_SCALE;
        double projectedWidth = width * BASE_ITEM_SCALE * TARGET_EXTRA_SCALE;
        
        if (projectedWidth > SLOT_WIDTH && width > class_3532.field_29849) {
            scale = (float) (SLOT_WIDTH / (width * BASE_ITEM_SCALE));
        }
        
        double projectedHeight = height * BASE_ITEM_SCALE * scale;
        float allowedHeight = customRenderer ? SLOT_HEIGHT : SLOT_WIDTH;
        
        if (projectedHeight > allowedHeight && height > class_3532.field_29849) {
            float heightScale = (float) (allowedHeight / (height * BASE_ITEM_SCALE));
            scale = Math.min(scale, heightScale);
        }
        
        return scale;
    }
    
    private static boolean isFlatModel(class_238 box) {
        double smallestDimension = Math.min(box.field_1320 - box.field_1323, Math.min(box.field_1325 - box.field_1322, box.field_1324 - box.field_1321));
        return smallestDimension < 0.06255;
    }
    
    private record ItemScaleData(class_238 bounds, float scale) {}
}