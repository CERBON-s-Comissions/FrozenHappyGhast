package com.blackgear.vanillabackport.client.level.particle;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2400;
import net.minecraft.class_3999;
import net.minecraft.class_4002;
import net.minecraft.class_4003;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;
import net.minecraft.client.particle.*;

@Environment(EnvType.CLIENT)
public class SulfurCubeParticle extends class_4003 {
    private final float uo;
    private final float vo;

    public SulfurCubeParticle(
        class_638 level,
        double x,
        double y,
        double z,
        double xSpeed,
        double ySpeed,
        double zSpeed
    ) {
        this(level, x, y, z);
        this.field_3852 *= 0.1F;
        this.field_3869 *= 0.1F;
        this.field_3850 *= 0.1F;
        this.field_3852 += xSpeed;
        this.field_3869 += ySpeed;
        this.field_3850 += zSpeed;
    }

    public class_3999 method_18122() {
        return class_3999.field_17828;
    }

    public SulfurCubeParticle(
        class_638 level,
        double x,
        double y,
        double z
    ) {
        super(level, x, y, z, 0.0, 0.0, 0.0);
        this.field_3844 = 1.0F;
        this.field_17867 /= 2.0F;
        this.uo = this.field_3840.method_43057() * 3.0F;
        this.vo = this.field_3840.method_43057() * 3.0F;
    }

    @Override
    protected float method_18133() {
        return this.field_17886.method_4580((this.uo + 1.0F) / 4.0F);
    }

    @Override
    protected float method_18134() {
        return this.field_17886.method_4580(this.uo / 4.0F);
    }

    @Override
    protected float method_18135() {
        return this.field_17886.method_4570(this.vo / 4.0F);
    }

    @Override
    protected float method_18136() {
        return this.field_17886.method_4570((this.vo + 1.0F) / 4.0F);
    }

    @Environment(EnvType.CLIENT)
    public record Provider(class_4002 sprites) implements class_707<class_2400> {
        @Override
        public class_703 createParticle(class_2400 type, class_638 level, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
            SulfurCubeParticle particle = new SulfurCubeParticle(level, x, y, z, xSpeed, ySpeed, zSpeed);
            particle.method_18140(this.sprites);
            return particle;
        }
    }
}