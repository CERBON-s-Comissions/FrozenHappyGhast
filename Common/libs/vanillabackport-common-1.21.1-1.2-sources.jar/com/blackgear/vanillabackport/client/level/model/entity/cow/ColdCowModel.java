package com.blackgear.vanillabackport.client.level.model.entity.cow;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1430;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_630;
import net.minecraft.client.model.geom.builders.*;

@Environment(EnvType.CLIENT)
public class ColdCowModel<T extends class_1430> extends CowVariantModel<T> {
    public ColdCowModel(class_630 root) {
        super(root);
    }

    public static class_5607 method_31990() {
        class_5609 mesh = createBaseCowModel();
        class_5610 root = mesh.method_32111();
        root.method_32117(
            "body",
            class_5606.method_32108()
                .method_32101(20, 32)
                .method_32098(-6.0F, -10.0F, -7.0F, 12.0F, 18.0F, 10.0F, new class_5605(0.5F))
                .method_32101(18, 4)
                .method_32097(-6.0F, -10.0F, -7.0F, 12.0F, 18.0F, 10.0F)
                .method_32101(52, 0)
                .method_32097(-2.0F, 2.0F, -8.0F, 4.0F, 6.0F, 1.0F),
            class_5603.method_32091(0.0F, 5.0F, 2.0F, ((float) Math.PI / 2F), 0.0F, 0.0F)
        );
        class_5610 head = root.method_32117(
            "head",
            class_5606.method_32108()
                .method_32101(0, 0)
                .method_32097(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 6.0F)
                .method_32101(9, 33)
                .method_32097(-3.0F, 1.0F, -7.0F, 6.0F, 3.0F, 1.0F),
            class_5603.method_32090(0.0F, 4.0F, -8.0F)
        );
        head.method_32117(
            "right_horn",
            class_5606.method_32108()
                .method_32101(0, 40)
                .method_32097(-1.5F, -4.5F, -0.5F, 2.0F, 6.0F, 2.0F),
            class_5603.method_32091(-4.5F, -2.5F, -3.5F, 1.5708F, 0.0F, 0.0F)
        );
        head.method_32117(
            "left_horn",
            class_5606.method_32108()
                .method_32101(0, 32)
                .method_32097(-1.5F, -3.0F, -0.5F, 2.0F, 6.0F, 2.0F),
            class_5603.method_32091(5.5F, -2.5F, -5.0F, 1.5708F, 0.0F, 0.0F)
        );

        return class_5607.method_32110(mesh, 64, 64);
    }
}