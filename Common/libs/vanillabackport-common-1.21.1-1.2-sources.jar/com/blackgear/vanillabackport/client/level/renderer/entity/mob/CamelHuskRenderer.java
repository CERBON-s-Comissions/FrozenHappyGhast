package com.blackgear.vanillabackport.client.level.renderer.entity.mob;

import com.blackgear.vanillabackport.client.registries.ModModelLayers;
import net.minecraft.class_2960;
import net.minecraft.class_5617;
import net.minecraft.class_7689;
import net.minecraft.class_7763;

public class CamelHuskRenderer extends class_7763 {
    public static final class_2960 CAMEL_HUSK_LOCATION = class_2960.method_60656("textures/entity/camel/camel_husk.png");
    
    public CamelHuskRenderer(class_5617.class_5618 context) {
        super(context, ModModelLayers.CAMEL_HUSK);
    }
    
    @Override
    public class_2960 method_45801(class_7689 entity) {
        return CAMEL_HUSK_LOCATION;
    }
}