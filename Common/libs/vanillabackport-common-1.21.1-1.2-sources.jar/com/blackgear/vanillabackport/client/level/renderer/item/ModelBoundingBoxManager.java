package com.blackgear.vanillabackport.client.level.renderer.item;

import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4608;
import net.minecraft.class_777;
import net.minecraft.class_804;
import net.minecraft.class_811;
import net.minecraft.class_918;

public class ModelBoundingBoxManager {
    public static final ModelBoundingBoxManager INSTANCE = new ModelBoundingBoxManager();
    private static final class_2350[] CULL_FACES = { class_2350.field_11033, class_2350.field_11036, class_2350.field_11043, class_2350.field_11035, class_2350.field_11039, class_2350.field_11034, null };
    private final Map<class_1792, class_238> cache = new HashMap<>();
    
    public class_238 getModelBoundingBox(class_1087 model, class_1799 stack, class_918 renderer, class_1937 level, int seed) {
        return this.cache.computeIfAbsent(stack.method_7909(), i -> compute(model, stack, renderer, level, seed));
    }
    
    private static class_238 compute(class_1087 model, class_1799 stack, class_918 renderer, class_1937 level, int seed) {
        if (model.method_4713()) {
            return computeForCustomRenderer(stack, renderer, level, seed);
        }

        float minX = Float.POSITIVE_INFINITY, minY = Float.POSITIVE_INFINITY, minZ = Float.POSITIVE_INFINITY;
        float maxX = Float.NEGATIVE_INFINITY, maxY = Float.NEGATIVE_INFINITY, maxZ = Float.NEGATIVE_INFINITY;

        class_804 transform = model.method_4709().method_3503(class_811.field_4319);
        class_4587 poseStack = new class_4587();
        transform.method_23075(false, poseStack);
        poseStack.method_46416(-0.5F, -0.5F, -0.5F);
        Matrix4f pose = poseStack.method_23760().method_23761();
        Vector4f pos = new Vector4f();

        for (class_2350 direction : CULL_FACES) {
            for (class_777 quad : model.method_4707(null, direction, level.method_8409())) {
                class_2350 quadDir = quad.method_3358();
                if (quadDir == class_2350.field_11035 || quadDir == class_2350.field_11043) continue;

                int[] vertices = quad.method_3357();
                for (int i = 0; i < 4; i++) {
                    int offset = i * 8;
                    float x = Float.intBitsToFloat(vertices[offset]);
                    float y = Float.intBitsToFloat(vertices[offset + 1]);
                    float z = Float.intBitsToFloat(vertices[offset + 2]);
                    pose.transform(x, y, z, 1.0F, pos);

                    minX = Math.min(minX, pos.x);
                    minY = Math.min(minY, pos.y);
                    minZ = Math.min(minZ, pos.z);
                    maxX = Math.max(maxX, pos.x);
                    maxY = Math.max(maxY, pos.y);
                    maxZ = Math.max(maxZ, pos.z);
                }
            }
        }

        if (minX == Float.POSITIVE_INFINITY) {
            return fallback();
        }

        return new class_238(minX, minY, minZ, maxX, maxY, maxZ);
    }
    
    private static class_238 computeForCustomRenderer(class_1799 stack, class_918 renderer, class_1937 level, int seed) {
        class_4587 pose = new class_4587();
        CustomRendererBoundManager manager = new CustomRendererBoundManager();
        
        renderer.method_23178(stack, class_811.field_4319, 15728880, class_4608.field_21444, pose, renderType -> manager, level, seed);
    
        if (!manager.hasData()) {
            return fallback();
        }
        
        class_238 box = manager.toAABB();
        class_1087 model = renderer.method_4019(stack, level, null, seed);
        class_804 transform = model.method_4709().method_3503(class_811.field_4319);
        Vector3f scale = transform.field_4285;

        float scaleX = Math.abs(scale.x()) > 1.0E-4F ? scale.x() : 1.0F;
        float scaleY = Math.abs(scale.y()) > 1.0E-4F ? scale.y() : 1.0F;
        float scaleZ = Math.abs(scale.z()) > 1.0E-4F ? scale.z() : 1.0F;

        return new class_238(
            box.field_1323 / scaleX, box.field_1322 / scaleY, box.field_1321 / scaleZ,
            box.field_1320 / scaleX, box.field_1325 / scaleY, box.field_1324 / scaleZ
        );
    }
    
    private static class_238 fallback() {
        return new class_238(-0.25, -0.25, -0.25, 0.25, 0.25, 0.25);
    }
    
    private static final class CustomRendererBoundManager implements class_4588 {
        private double minX = Double.POSITIVE_INFINITY, minY = Double.POSITIVE_INFINITY, minZ = Double.POSITIVE_INFINITY;
        private double maxX = Double.NEGATIVE_INFINITY, maxY = Double.NEGATIVE_INFINITY, maxZ = Double.NEGATIVE_INFINITY;
        private boolean hasData = false;
        
        @Override
        public class_4588 method_22912(float x, float y, float z) {
            hasData = true;
            minX = Math.min(minX, x);
            minY = Math.min(minY, y);
            minZ = Math.min(minZ, z);
            maxX = Math.max(maxX, x);
            maxY = Math.max(maxY, y);
            maxZ = Math.max(maxZ, z);
            return this;
        }
        
        @Override public class_4588 method_1336(int r, int g, int b, int a) { return this; }
        @Override public class_4588 method_22913(float u, float v) { return this; }
        @Override public class_4588 method_60796(int u, int v) { return this; }
        @Override public class_4588 method_22921(int u, int v) { return this; }
        @Override public class_4588 method_22914(float x, float y, float z) { return this; }
        
        boolean hasData() { return hasData; }
        class_238 toAABB() { return new class_238(minX, minY, minZ, maxX, maxY, maxZ); }
    }
}