package com.blackgear.vanillabackport.client.level.model.entity.sulfur_cube;

import com.blackgear.vanillabackport.common.level.entities.mob.monster.sulfur_cube.SulfurCube;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_5597;
import net.minecraft.class_5603;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_630;

@Environment(EnvType.CLIENT)
public class SulfurCubeModel extends class_5597<SulfurCube> {
    private final class_630 root;
    private final boolean skipRendering;

    public SulfurCubeModel(class_630 root) {
        this.root = root;
        this.skipRendering = false;
    }

    public SulfurCubeModel(class_630 root, boolean skipRendering) {
        this.root = root;
        this.skipRendering = skipRendering;
    }

    public static class_5607 createOuterBodyLayer() {
        class_5609 mesh = new class_5609();
        class_5610 root = mesh.method_32111();
        root.method_32117(
            "cube",
            class_5606.method_32108().method_32101(0, 0).method_32097(-9.0F, -9.0F, -9.0F, 18.0F, 18.0F, 18.0F),
            class_5603.field_27701
        );
        return class_5607.method_32110(mesh, 128, 128);
    }

    public static class_5607 createInnerBodyLayer() {
        class_5609 mesh = new class_5609();
        class_5610 root = mesh.method_32111();
        root.method_32117(
            "cube",
            class_5606.method_32108().method_32101(0, 36).method_32097(-8.0F, -8.0F, -8.0F, 16.0F, 16.0F, 16.0F),
            class_5603.field_27701
        );
        return class_5607.method_32110(mesh, 128, 128);
    }

    @Override
    public class_630 method_32008() {
        return this.root;
    }

    @Override
    public void setupAnim(SulfurCube entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {

    }

    @Override
    public void method_2828(class_4587 poseStack, class_4588 buffer, int packedLight, int packedOverlay, int color) {
        if (this.skipRendering) return;
        super.method_2828(poseStack, buffer, packedLight, packedOverlay, color);
    }
}