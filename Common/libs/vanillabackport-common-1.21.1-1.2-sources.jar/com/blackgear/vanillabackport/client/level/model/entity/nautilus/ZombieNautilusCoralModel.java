package com.blackgear.vanillabackport.client.level.model.entity.nautilus;

import com.blackgear.vanillabackport.common.level.entities.mob.animal.nautilus.AbstractNautilus;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_5603;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_630;

@Environment(EnvType.CLIENT)
public class ZombieNautilusCoralModel<T extends AbstractNautilus> extends NautilusModel<T> {
	private final class_630 corals;

	public ZombieNautilusCoralModel(final class_630 root) {
		super(root);
		class_630 shell = this.nautilus.method_32086("shell");
		this.corals = shell.method_32086("corals");
	}

	public static class_5607 createBodyLayer() {
		class_5609 mesh = createBodyMesh();
		class_5610 corals = mesh.method_32111()
			.method_32116("root")
			.method_32116("shell")
			.method_32117("corals", class_5606.method_32108(), class_5603.method_32090(8.0F, 4.5F, -8.0F));
		class_5610 yellowCoral = corals.method_32117("yellow_coral", class_5606.method_32108(), class_5603.method_32090(0.0F, -11.0F, 11.0F));
		yellowCoral.method_32117(
			"yellow_coral_second",
			class_5606.method_32108().method_32101(0, 85).method_32097(-4.5F, -3.5F, 0.0F, 6.0F, 8.0F, 0.0F),
			class_5603.method_32091(0.0F, 0.0F, 2.0F, 0.0F, -0.7854F, 0.0F)
		);
		yellowCoral.method_32117(
			"yellow_coral_first",
			class_5606.method_32108().method_32101(0, 85).method_32097(-4.5F, -3.5F, 0.0F, 6.0F, 8.0F, 0.0F),
			class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.7854F, 0.0F)
		);
		class_5610 pinkCoral = corals.method_32117(
			"pink_coral", class_5606.method_32108().method_32101(-8, 94).method_32097(-4.5F, 4.5F, 0.0F, 6.0F, 0.0F, 8.0F), class_5603.method_32090(-12.5F, -18.0F, 11.0F)
		);
		pinkCoral.method_32117(
			"pink_coral_second",
			class_5606.method_32108().method_32101(-8, 94).method_32097(-3.0F, 0.0F, -4.0F, 6.0F, 0.0F, 8.0F),
			class_5603.method_32091(-1.5F, 4.5F, 4.0F, 0.0F, 0.0F, 1.5708F)
		);
		class_5610 blueCoral = corals.method_32117("blue_coral", class_5606.method_32108(), class_5603.method_32090(-14.0F, 0.0F, 5.5F));
		blueCoral.method_32117(
			"blue_second",
			class_5606.method_32108().method_32101(0, 102).method_32097(-3.5F, -5.5F, 0.0F, 5.0F, 10.0F, 0.0F),
			class_5603.method_32091(0.0F, 0.0F, -2.0F, 0.0F, 0.7854F, 0.0F)
		);
		blueCoral.method_32117(
			"blue_first",
			class_5606.method_32108().method_32101(0, 102).method_32097(-3.5F, -5.5F, 0.0F, 5.0F, 10.0F, 0.0F),
			class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -0.7854F, 0.0F)
		);
		class_5610 redCoral = corals.method_32117("red_coral", class_5606.method_32108(), class_5603.method_32090(0.0F, 0.0F, 0.0F));
		redCoral.method_32117(
			"red_coral_second",
			class_5606.method_32108().method_32101(0, 112).method_32097(-2.5F, -5.5F, 0.0F, 4.0F, 10.0F, 0.0F),
			class_5603.method_32091(-0.5F, -1.0F, 1.5F, 0.0F, -0.829F, 0.0F)
		);
		redCoral.method_32117(
			"red_coral_first",
			class_5606.method_32108().method_32101(0, 112).method_32097(-4.5F, -5.5F, 0.0F, 6.0F, 10.0F, 0.0F),
			class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.7854F, 0.0F)
		);
		return class_5607.method_32110(mesh, 128, 128);
	}
	
	@Override
	public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
		super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
		this.corals.field_3665 = entity.method_56676().method_7960();
	}
}