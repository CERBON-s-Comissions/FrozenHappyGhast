package com.blackgear.vanillabackport.client.level.model.entity.cow;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1430;
import net.minecraft.class_560;
import net.minecraft.class_5603;
import net.minecraft.class_5606;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_630;

@Environment(EnvType.CLIENT)
public class CowVariantModel<T extends class_1430> extends class_560<T> {
    public CowVariantModel(class_630 root) {
        super(root);
    }

    static class_5609 createBaseCowModel() {
        class_5609 mesh = new class_5609();
        class_5610 root = mesh.method_32111();
        root.method_32117(
            "head",
            class_5606.method_32108()
                .method_32101(0, 0)
                .method_32097(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 6.0F)
                .method_32101(1, 33)
                .method_32097(-3.0F, 1.0F, -7.0F, 6.0F, 3.0F, 1.0F)
                .method_32101(22, 0)
                .method_32102("right_horn", -5.0F, -5.0F, -5.0F, 1.0F, 3.0F, 1.0F)
                .method_32101(22, 0)
                .method_32102("left_horn", 4.0F, -5.0F, -5.0F, 1.0F, 3.0F, 1.0F),
            class_5603.method_32090(0.0F, 4.0F, -8.0F)
        );
        root.method_32117(
            "body",
            class_5606.method_32108()
                .method_32101(18, 4)
                .method_32097(-6.0F, -10.0F, -7.0F, 12.0F, 18.0F, 10.0F)
                .method_32101(52, 0)
                .method_32097(-2.0F, 2.0F, -8.0F, 4.0F, 6.0F, 1.0F),
            class_5603.method_32091(0.0F, 5.0F, 2.0F, ((float) Math.PI / 2F), 0.0F, 0.0F)
        );

        class_5606 leftLeg = class_5606.method_32108()
            .method_32096().method_32101(0, 16)
            .method_32097(-2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F);
        class_5606 rightLeg = class_5606.method_32108()
            .method_32101(0, 16)
            .method_32097(-2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F);

        root.method_32117(
            "right_hind_leg",
            rightLeg,
            class_5603.method_32090(-4.0F, 12.0F, 7.0F)
        );
        root.method_32117(
            "left_hind_leg",
            leftLeg,
            class_5603.method_32090(4.0F, 12.0F, 7.0F)
        );
        root.method_32117(
            "right_front_leg",
            rightLeg,
            class_5603.method_32090(-4.0F, 12.0F, -5.0F)
        );
        root.method_32117(
            "left_front_leg",
            leftLeg,
            class_5603.method_32090(4.0F, 12.0F, -5.0F)
        );

        return mesh;
    }
}