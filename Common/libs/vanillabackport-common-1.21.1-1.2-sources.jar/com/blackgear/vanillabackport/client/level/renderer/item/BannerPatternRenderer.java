package com.blackgear.vanillabackport.client.level.renderer.item;

import com.blackgear.platform.core.util.event.ResultHolder;
import com.blackgear.vanillabackport.core.VanillaBackport;
import org.jetbrains.annotations.NotNull;

import java.util.Set;
import net.minecraft.class_1087;
import net.minecraft.class_1091;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_763;
import net.minecraft.class_811;

public class BannerPatternRenderer extends BackportedItemRenderer {
  private static final Set<class_1792> BANNER_PATTERNS = Set.of(
      class_1802.field_8573, class_1802.field_49815, class_1802.field_8498, class_1802.field_18674,
      class_1802.field_49816, class_1802.field_8159, class_1802.field_23831, class_1802.field_8891
  );
  private static final class_1091 BLANK_MODEL_LOCATION = class_1091.method_61078(VanillaBackport.resource("blank_banner_pattern"));
  public static final BannerPatternRenderer INSTANCE = new BannerPatternRenderer();

  public BannerPatternRenderer() {
    super(VanillaBackport.CLIENT_CONFIG.hasModernBannerPatternTextures, BANNER_PATTERNS);
  }

  @Override
  public ResultHolder<class_1087> renderFirstPerson(class_1799 itemStack, class_811 itemDisplayContext, class_763 itemModelShaper) {
    return BANNER_PATTERNS.contains(itemStack.method_7909())
        ? super.renderFirstPerson(itemStack, itemDisplayContext, itemModelShaper)
        : getResult(itemModelShaper);
  }

  @Override
  public ResultHolder<class_1087> renderThirdPerson(class_1799 itemStack, class_763 itemModelShaper) {
    return BANNER_PATTERNS.contains(itemStack.method_7909())
        ? super.renderThirdPerson(itemStack, itemModelShaper)
        : getResult(itemModelShaper);
  }

  private static @NotNull ResultHolder<class_1087> getResult(class_763 itemModelShaper) {
    return ResultHolder.submit(itemModelShaper.method_3303().method_4742(BLANK_MODEL_LOCATION));
  }

  @Override
  public Set<class_1091> registerModels() {
    Set<class_1091> locations = super.registerModels();
    locations.add(BLANK_MODEL_LOCATION);
    return locations;
  }
}
