package com.blackgear.vanillabackport.client.level.renderer.entity.mob;

import com.blackgear.vanillabackport.client.level.layer.SulfurCubeInnerLayer;
import com.blackgear.vanillabackport.client.level.layer.SulfurCubeOuterLayer;
import com.blackgear.vanillabackport.client.level.model.entity.sulfur_cube.SulfurCubeModel;
import com.blackgear.vanillabackport.client.registries.ModModelLayers;
import com.blackgear.vanillabackport.common.level.entities.mob.monster.sulfur_cube.SulfurCube;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import net.minecraft.class_927;

@Environment(EnvType.CLIENT)
public class SulfurCubeRenderer extends class_927<SulfurCube, SulfurCubeModel> {
    private static final class_2960 SULFUR_CUBE_INNER_LOCATION = class_2960.method_60656("textures/entity/sulfur_cube/sulfur_cube_inner.png");

    public SulfurCubeRenderer(class_5617.class_5618 context) {
        super(context, new SulfurCubeModel(context.method_32167(ModModelLayers.SULFUR_CUBE_INNER), true), 0.25F);
        this.method_4046(new SulfurCubeInnerLayer(this, context.method_32170(), context.method_43337()));
        this.method_4046(new SulfurCubeOuterLayer(this, context.method_32170()));
    }

    @Override
    public void render(SulfurCube cube, float entityYaw, float partialTicks, class_4587 pose, class_4597 buffer, int packedLight) {
        this.field_4673 = 0.25F * (float) cube.getSize();
        super.method_4054(cube, entityYaw, partialTicks, pose, buffer, packedLight);
    }

    @Override
    protected void scale(SulfurCube cube, class_4587 pose, float partialTicks) {
        // downscale slightly
        pose.method_22905(0.999F, 0.999F, 0.999F);
        pose.method_46416(0.0F, 0.001F, 0.0F);

        // apply size and squish
        float size = (float) cube.getSize();
        float squish = cube.getContainedBlock().method_7960() ? class_3532.method_16439(partialTicks, cube.oSquish, cube.squish) / (size * 0.5F + 1.0F) : 0.0F;
        float progress = 1.0F / (squish + 1.0F);
        pose.method_22905(progress * size, 1.0F / progress * size, progress * size);

        int fuse = cube.getFuse();
        if (fuse > -1 && (float)fuse - partialTicks + 1.0F < 10.0F) {
            float swell = 1.0F - ((float)fuse - partialTicks + 1.0F) / 10.0F;
            swell = class_3532.method_15363(swell, 0.0F, 1.0F);
            swell *= swell;
            swell *= swell;
            float scale = 1.0F + swell * 0.3F;
            pose.method_22905(scale, scale, scale);
        }

        float vOffset = cube.method_6109() ? 1.24F : 0.98F;
        float extraDownscale = cube.method_6109() ? 1.0F : 0.5F;
        float onePixelUpIfVisible = (cube.method_5767() ? 0.0F : 1.0F) / 16.0F;
        pose.method_22905(extraDownscale, extraDownscale, extraDownscale);
        pose.method_46416(-0.0F, vOffset - onePixelUpIfVisible, -0.0F);
    }

    @Override
    public class_2960 getTextureLocation(SulfurCube entity) {
        return SULFUR_CUBE_INNER_LOCATION;
    }
}