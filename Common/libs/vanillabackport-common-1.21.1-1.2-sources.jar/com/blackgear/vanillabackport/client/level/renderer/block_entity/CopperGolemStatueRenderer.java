package com.blackgear.vanillabackport.client.level.renderer.block_entity;

import com.blackgear.vanillabackport.client.level.model.block_entity.CopperGolemStatueModel;
import com.blackgear.vanillabackport.client.registries.ModModelLayers;
import com.blackgear.vanillabackport.common.level.blocks.CopperGolemStatueBlock;
import com.blackgear.vanillabackport.common.level.blocks.CopperGolemStatueBlock.Pose;
import com.blackgear.vanillabackport.common.level.block_entities.CopperGolemStatueBlockEntity;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.golem.copper_golem.CopperGolemOxidationLevels;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlockStateProperties;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_5599;
import net.minecraft.class_5614;
import net.minecraft.class_827;
import java.util.HashMap;
import java.util.Map;

@Environment(EnvType.CLIENT)
public class CopperGolemStatueRenderer implements class_827<CopperGolemStatueBlockEntity> {
    public final Map<Pose, CopperGolemStatueModel> models = new HashMap<>();
    
    public CopperGolemStatueRenderer(class_5614.class_5615 context) {
        class_5599 models = context.method_32142();
        this.models.put(Pose.STANDING, new CopperGolemStatueModel(models.method_32072(ModModelLayers.COPPER_GOLEM)));
        this.models.put(Pose.RUNNING, new CopperGolemStatueModel(models.method_32072(ModModelLayers.COPPER_GOLEM_RUNNING)));
        this.models.put(Pose.SITTING, new CopperGolemStatueModel(models.method_32072(ModModelLayers.COPPER_GOLEM_SITTING)));
        this.models.put(Pose.STAR, new CopperGolemStatueModel(models.method_32072(ModModelLayers.COPPER_GOLEM_STAR)));
    }
    
    @Override
    public void render(
        CopperGolemStatueBlockEntity statue,
        float partialTick,
        class_4587 pose,
        class_4597 buffer,
        int packedLight,
        int packedOverlay
    ) {
        if (statue.method_11010().method_26204() instanceof CopperGolemStatueBlock block) {
            pose.method_22903();
            pose.method_22904(0.5, 0.0, 0.5);
            CopperGolemStatueModel model = this.models.get(statue.method_11010().method_11654(ModBlockStateProperties.COPPER_GOLEM_POSE));
            class_2350 direction = statue.method_11010().method_11654(CopperGolemStatueBlock.FACING);
            class_1921 renderType = class_1921.method_23578(CopperGolemOxidationLevels.getOxidationLevel(block.getWeatheringState()).texture());
            model.setupAnim(direction);
            class_4588 consumer = buffer.getBuffer(renderType);
            model.method_2828(pose, consumer, packedLight, packedOverlay, -1);
            pose.method_22909();
        }
    }
}