package com.blackgear.vanillabackport.client.level.animation;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_7179;
import net.minecraft.class_7184;
import net.minecraft.class_7186;
import net.minecraft.class_7187;

@Environment(EnvType.CLIENT)
public class CreakingAnimation {
    public static final class_7184 CREAKING_WALK = class_7184.class_7185.method_41818(1.125F)
        .method_41817()
        .method_41820(
            "upper_body",
            new class_7179(
                class_7179.class_7183.field_37887,
                new class_7186(0.0F, class_7187.method_41829(26.8802F, -23.399F, -9.0616F), class_7179.class_7181.field_37884),
                new class_7186(0.125F, class_7187.method_41829(-2.2093F, 5.9119F, 0.0675F), class_7179.class_7181.field_37884),
                new class_7186(0.5417F, class_7187.method_41829(23.0778F, 14.2906F, 4.6066F), class_7179.class_7181.field_37884),
                new class_7186(0.7083F, class_7187.method_41829(-10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.875F, class_7187.method_41829(7.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(1.125F, class_7187.method_41829(26.8802F, -23.399F, -9.0616F), class_7179.class_7181.field_37884)
            )
        )
        .method_41820(
            "head",
            new class_7179(
                class_7179.class_7183.field_37887,
                new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.0417F, class_7187.method_41829(-17.5F, -62.5F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.0833F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.4167F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.4583F, class_7187.method_41829(0.0F, 15.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.5F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(1.0417F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(1.0833F, class_7187.method_41829(-37.1532F, 81.1131F, -28.3621F), class_7179.class_7181.field_37884),
                new class_7186(1.125F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
            )
        )
        .method_41820(
            "right_arm",
            new class_7179(
                class_7179.class_7183.field_37887,
                new class_7186(0.0F, class_7187.method_41829(12.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.25F, class_7187.method_41829(-32.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.875F, class_7187.method_41829(12.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(1.125F, class_7187.method_41829(-15.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
            )
        )
        .method_41820(
            "left_arm",
            new class_7179(
                class_7179.class_7183.field_37887,
                new class_7186(0.0F, class_7187.method_41829(-15.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.125F, class_7187.method_41829(10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.5417F, class_7187.method_41829(-25.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.75F, class_7187.method_41829(-9.0923F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.7917F, class_7187.method_41829(-15.137F, -66.7758F, 13.9603F), class_7179.class_7181.field_37884),
                new class_7186(0.8333F, class_7187.method_41829(-9.0923F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(1.0F, class_7187.method_41829(10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(1.125F, class_7187.method_41829(-15.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
            )
        )
        .method_41820(
            "left_leg",
            new class_7179(
                class_7179.class_7183.field_37887,
                new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.25F, class_7187.method_41829(30.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.375F, class_7187.method_41829(49.8924F, -3.8282F, 3.2187F), class_7179.class_7181.field_37884),
                new class_7186(0.5F, class_7187.method_41829(17.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.625F, class_7187.method_41829(-56.5613F, -12.2403F, -8.7374F), class_7179.class_7181.field_37884),
                new class_7186(0.9167F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(1.125F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
            )
        )
        .method_41820(
            "left_leg",
            new class_7179(
                class_7179.class_7183.field_37886,
                new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 2.0F), class_7179.class_7181.field_37884),
                new class_7186(0.25F, class_7187.method_41823(0.0F, 0.1846F, 0.5979F), class_7179.class_7181.field_37884),
                new class_7186(0.375F, class_7187.method_41823(0.0F, -0.0665F, -2.2177F), class_7179.class_7181.field_37884),
                new class_7186(0.5F, class_7187.method_41823(0.0F, 1.3563F, -4.3474F), class_7179.class_7181.field_37884),
                new class_7186(0.625F, class_7187.method_41823(0.0F, 0.1047F, -1.6556F), class_7179.class_7181.field_37884),
                new class_7186(0.9167F, class_7187.method_41823(0.0F, 0.0F, -1.0F), class_7179.class_7181.field_37884),
                new class_7186(1.125F, class_7187.method_41823(0.0F, 0.0F, 2.0F), class_7179.class_7181.field_37884)
            )
        )
        .method_41820(
            "right_leg",
            new class_7179(
                class_7179.class_7183.field_37887,
                new class_7186(0.0F, class_7187.method_41829(25.5305F, 11.3125F, 5.3525F), class_7179.class_7181.field_37884),
                new class_7186(0.125F, class_7187.method_41829(-49.5628F, 7.3556F, 6.7933F), class_7179.class_7181.field_37884),
                new class_7186(0.25F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.4583F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.9167F, class_7187.method_41829(30.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(1.0417F, class_7187.method_41829(55.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(1.125F, class_7187.method_41829(25.5305F, 11.3125F, 5.3525F), class_7179.class_7181.field_37884)
            )
        )
        .method_41820(
            "right_leg",
            new class_7179(
                class_7179.class_7183.field_37886,
                new class_7186(0.0F, class_7187.method_41823(0.0F, 0.9674F, -3.6578F), class_7179.class_7181.field_37884),
                new class_7186(0.125F, class_7187.method_41823(0.0F, -0.2979F, -0.9411F), class_7179.class_7181.field_37884),
                new class_7186(0.25F, class_7187.method_41823(0.0F, -0.3F, -0.94F), class_7179.class_7181.field_37884),
                new class_7186(0.4583F, class_7187.method_41823(0.0F, -0.3F, 1.06F), class_7179.class_7181.field_37884),
                new class_7186(1.125F, class_7187.method_41823(0.0F, 0.9674F, -3.6578F), class_7179.class_7181.field_37884)
            )
        )
        .method_41821();
    public static final class_7184 CREAKING_ATTACK = class_7184.class_7185.method_41818(0.7083F)
        .method_41817()
        .method_41820(
            "upper_body",
            new class_7179(
                class_7179.class_7183.field_37887,
                new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.0833F, class_7187.method_41829(0.0F, 45.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.1667F, class_7187.method_41829(-115.0F, 67.5F, -90.0F), class_7179.class_7181.field_37884),
                new class_7186(0.375F, class_7187.method_41829(67.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.5417F, class_7187.method_41829(0.0F, 45.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.7083F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
            )
        )
        .method_41820(
            "upper_body",
            new class_7179(
                class_7179.class_7183.field_37886,
                new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.0833F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.2917F, class_7187.method_41823(0.0F, -2.7716F, -1.1481F), class_7179.class_7181.field_37884),
                new class_7186(0.375F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.5417F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.7083F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
            )
        )
        .method_41820(
            "upper_body",
            new class_7179(
                class_7179.class_7183.field_37888,
                new class_7186(0.0F, class_7187.method_41822(1.0, 1.0, 1.0), class_7179.class_7181.field_37884),
                new class_7186(0.7083F, class_7187.method_41822(1.0, 1.0, 1.0), class_7179.class_7181.field_37884)
            )
        )
        .method_41820(
            "head",
            new class_7179(
                class_7179.class_7183.field_37887,
                new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.1667F, class_7187.method_41829(0.0F, -45.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.25F, class_7187.method_41829(-11.25F, -45.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.2917F, class_7187.method_41829(-117.3939F, 76.6331F, -130.1483F), class_7179.class_7181.field_37884),
                new class_7186(0.4167F, class_7187.method_41829(-45.0F, -45.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.5F, class_7187.method_41829(60.0F, -45.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.5833F, class_7187.method_41829(60.0F, -45.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.625F, class_7187.method_41829(0.0F, -45.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.7083F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
            )
        )
        .method_41820(
            "head",
            new class_7179(
                class_7179.class_7183.field_37886,
                new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.1667F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.4167F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.5F, class_7187.method_41823(0.3827F, 0.5133F, -0.7682F), class_7179.class_7181.field_37884),
                new class_7186(0.5833F, class_7187.method_41823(0.3827F, 0.5133F, -0.7682F), class_7179.class_7181.field_37884),
                new class_7186(0.625F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.7083F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
            )
        )
        .method_41820(
            "head",
            new class_7179(
                class_7179.class_7183.field_37888,
                new class_7186(0.1667F, class_7187.method_41822(1.0, 1.0, 1.0), class_7179.class_7181.field_37884),
                new class_7186(0.4167F, class_7187.method_41822(1.0, 1.0, 1.0), class_7179.class_7181.field_37884),
                new class_7186(0.5F, class_7187.method_41822(1.0, 1.3F, 1.0), class_7179.class_7181.field_37884),
                new class_7186(0.625F, class_7187.method_41822(1.0, 1.0, 1.0), class_7179.class_7181.field_37884)
            )
        )
        .method_41820(
            "right_arm",
            new class_7179(
                class_7179.class_7183.field_37887,
                new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.1667F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.25F, class_7187.method_41829(7.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.4583F, class_7187.method_41829(55.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.625F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.7083F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
            )
        )
        .method_41820(
            "right_arm",
            new class_7179(
                class_7179.class_7183.field_37886,
                new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.1667F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.625F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.7083F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
            )
        )
        .method_41820(
            "left_leg",
            new class_7179(
                class_7179.class_7183.field_37887,
                new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.1667F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.625F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.7083F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
            )
        )
        .method_41820(
            "left_leg",
            new class_7179(
                class_7179.class_7183.field_37886,
                new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.1667F, class_7187.method_41823(0.0F, 0.0F, -2.0F), class_7179.class_7181.field_37884),
                new class_7186(0.625F, class_7187.method_41823(0.0F, 0.0F, -2.0F), class_7179.class_7181.field_37884),
                new class_7186(0.7083F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
            )
        )
        .method_41820(
            "right_leg",
            new class_7179(
                class_7179.class_7183.field_37887,
                new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.1667F, class_7187.method_41829(0.0F, 45.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.625F, class_7187.method_41829(0.0F, 45.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.7083F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
            )
        )
        .method_41820(
            "right_leg",
            new class_7179(
                class_7179.class_7183.field_37886,
                new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.1667F, class_7187.method_41823(0.7071F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.625F, class_7187.method_41823(0.7071F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.7083F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
            )
        )
        .method_41820(
            "left_arm",
            new class_7179(
                class_7179.class_7183.field_37887,
                new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.1667F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.25F, class_7187.method_41829(10.3453F, 14.7669F, 2.664F), class_7179.class_7181.field_37884),
                new class_7186(0.4583F, class_7187.method_41829(57.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.625F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.7083F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
            )
        )
        .method_41820(
            "left_arm",
            new class_7179(
                class_7179.class_7183.field_37886,
                new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.7083F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
            )
        )
        .method_41821();
    public static final class_7184 CREAKING_INVULNERABLE = class_7184.class_7185.method_41818(0.2917F)
        .method_41820(
            "upper_body",
            new class_7179(
                class_7179.class_7183.field_37887,
                new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.0833F, class_7187.method_41829(-5.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.1667F, class_7187.method_41829(5.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.25F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
            )
        )
        .method_41820(
            "upper_body",
            new class_7179(
                class_7179.class_7183.field_37886,
                new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.0833F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.25F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
            )
        )
        .method_41820(
            "right_arm",
            new class_7179(
                class_7179.class_7183.field_37887,
                new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.0833F, class_7187.method_41829(17.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.1667F, class_7187.method_41829(-15.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.25F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
            )
        )
        .method_41820(
            "right_arm",
            new class_7179(
                class_7179.class_7183.field_37886,
                new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.25F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
            )
        )
        .method_41820(
            "left_arm",
            new class_7179(
                class_7179.class_7183.field_37887,
                new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.0833F, class_7187.method_41829(20.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.1667F, class_7187.method_41829(-15.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.25F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
            )
        )
        .method_41820(
            "left_arm",
            new class_7179(
                class_7179.class_7183.field_37886,
                new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.25F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
            )
        )
        .method_41821();
    public static final class_7184 CREAKING_DEATH = class_7184.class_7185.method_41818(2.25F)
        .method_41820(
            "upper_body",
            new class_7179(
                class_7179.class_7183.field_37887,
                new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.0833F, class_7187.method_41829(-40.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.1667F, class_7187.method_41829(-5.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.2917F, class_7187.method_41829(7.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.5833F, class_7187.method_41829(16.25F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.6667F, class_7187.method_41829(29.0814F, 62.5516F, 26.5771F), class_7179.class_7181.field_37884),
                new class_7186(0.75F, class_7187.method_41829(12.2115F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(1.0F, class_7187.method_41829(10.25F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(1.0417F, class_7187.method_41829(-47.64F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(1.125F, class_7187.method_41829(21.96F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(1.25F, class_7187.method_41829(12.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(2.25F, class_7187.method_41829(17.3266F, 7.9022F, -0.1381F), class_7179.class_7181.field_37884)
            )
        )
        .method_41820(
            "upper_body",
            new class_7179(
                class_7179.class_7183.field_37886,
                new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.0833F, class_7187.method_41823(0.0F, 0.557F, 1.2659F), class_7179.class_7181.field_37884),
                new class_7186(0.1667F, class_7187.method_41823(0.0F, -2.0889F, -0.3493F), class_7179.class_7181.field_37884),
                new class_7186(0.2917F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
            )
        )
        .method_41820(
            "upper_body",
            new class_7179(
                class_7179.class_7183.field_37888,
                new class_7186(0.0F, class_7187.method_41822(1.0, 1.0, 1.0), class_7179.class_7181.field_37884),
                new class_7186(0.0833F, class_7187.method_41822(1.0, 1.1F, 1.0), class_7179.class_7181.field_37884),
                new class_7186(0.1667F, class_7187.method_41822(1.0, 0.9F, 1.0), class_7179.class_7181.field_37884),
                new class_7186(0.2917F, class_7187.method_41822(1.0, 1.0, 1.0), class_7179.class_7181.field_37884)
            )
        )
        .method_41820(
            "right_arm",
            new class_7179(
                class_7179.class_7183.field_37887,
                new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.2917F, class_7187.method_41829(-10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.5F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(1.25F, class_7187.method_41829(-10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(1.5417F, class_7187.method_41829(-10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(1.5833F, class_7187.method_41829(-12.1479F, -34.3927F, 6.9326F), class_7179.class_7181.field_37884),
                new class_7186(1.6667F, class_7187.method_41829(-10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
            )
        )
        .method_41820(
            "right_arm",
            new class_7179(
                class_7179.class_7183.field_37886,
                new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.2917F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
            )
        )
        .method_41820(
            "left_arm",
            new class_7179(
                class_7179.class_7183.field_37887,
                new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.2917F, class_7187.method_41829(-10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.5F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.8333F, class_7187.method_41829(-4.4444F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.875F, class_7187.method_41829(-26.7402F, -78.831F, 26.3025F), class_7179.class_7181.field_37884),
                new class_7186(0.9583F, class_7187.method_41829(-5.5556F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(1.25F, class_7187.method_41829(-10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
            )
        )
        .method_41820(
            "left_arm",
            new class_7179(
                class_7179.class_7183.field_37886,
                new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.2917F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
            )
        )
        .method_41820(
            "head",
            new class_7179(
                class_7179.class_7183.field_37887,
                new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.0833F, class_7187.method_41829(-5.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.2917F, class_7187.method_41829(10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.5F, class_7187.method_41829(2.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.5417F, class_7187.method_41829(5.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.5833F, class_7187.method_41829(-67.4168F, -12.9552F, -8.0231F), class_7179.class_7181.field_37884),
                new class_7186(0.6667F, class_7187.method_41829(8.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(1.0F, class_7187.method_41829(10.773F, -29.5608F, -5.3627F), class_7179.class_7181.field_37884),
                new class_7186(1.25F, class_7187.method_41829(10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(1.7917F, class_7187.method_41829(10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(1.8333F, class_7187.method_41829(12.9625F, 39.2735F, 8.2901F), class_7179.class_7181.field_37884),
                new class_7186(1.9167F, class_7187.method_41829(10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
            )
        )
        .method_41820(
            "head",
            new class_7179(
                class_7179.class_7183.field_37886,
                new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                new class_7186(0.2917F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
            )
        )
        .method_41821();
}