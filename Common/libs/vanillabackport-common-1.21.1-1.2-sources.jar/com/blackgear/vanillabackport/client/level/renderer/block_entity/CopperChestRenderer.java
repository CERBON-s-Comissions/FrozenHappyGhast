package com.blackgear.vanillabackport.client.level.renderer.block_entity;

import com.blackgear.vanillabackport.common.level.blocks.CopperChestBlock;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1921;
import net.minecraft.class_1937;
import net.minecraft.class_2281;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_2618;
import net.minecraft.class_2680;
import net.minecraft.class_2745;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4730;
import net.minecraft.class_4732;
import net.minecraft.class_4737;
import net.minecraft.class_5602;
import net.minecraft.class_5614;
import net.minecraft.class_630;
import net.minecraft.class_7833;
import net.minecraft.class_827;

import static net.minecraft.class_4722.field_21709;

@Environment(EnvType.CLIENT)
public class CopperChestRenderer<T extends class_2586 & class_2618> implements class_827<T> {
    private final class_630 lid;
    private final class_630 bottom;
    private final class_630 lock;
    private final class_630 doubleLeftLid;
    private final class_630 doubleLeftBottom;
    private final class_630 doubleLeftLock;
    private final class_630 doubleRightLid;
    private final class_630 doubleRightBottom;
    private final class_630 doubleRightLock;
    
    public CopperChestRenderer(class_5614.class_5615 context) {
        class_630 chest = context.method_32140(class_5602.field_27689);
        this.bottom = chest.method_32086("bottom");
        this.lid = chest.method_32086("lid");
        this.lock = chest.method_32086("lock");
        class_630 left = context.method_32140(class_5602.field_27551);
        this.doubleLeftBottom = left.method_32086("bottom");
        this.doubleLeftLid = left.method_32086("lid");
        this.doubleLeftLock = left.method_32086("lock");
        class_630 right = context.method_32140(class_5602.field_27552);
        this.doubleRightBottom = right.method_32086("bottom");
        this.doubleRightLid = right.method_32086("lid");
        this.doubleRightLock = right.method_32086("lock");
    }
    
    @Override
    public void method_3569(T blockEntity, float partialTick, class_4587 poseStack, class_4597 bufferSource, int packedLight, int packedOverlay) {
        class_1937 level = blockEntity.method_10997();
        boolean hasLevel = level != null;
        class_2680 blockState = hasLevel ? blockEntity.method_11010() : blockEntity.method_11010().method_11657(class_2281.field_10768, class_2350.field_11035);
        class_2745 chestType = blockState.method_28498(class_2281.field_10770) ? blockState.method_11654(class_2281.field_10770) : class_2745.field_12569;
        if (blockState.method_26204() instanceof CopperChestBlock chest) {
            poseStack.method_22903();
            float angle = blockState.method_11654(class_2281.field_10768).method_10144();
            poseStack.method_46416(0.5F, 0.5F, 0.5F);
            poseStack.method_22907(class_7833.field_40716.rotationDegrees(-angle));
            poseStack.method_46416(-0.5F, -0.5F, -0.5F);
            class_4732.class_4734<? extends class_2595> combineResult;
            if (hasLevel) {
                combineResult = chest.method_24167(blockState, level, blockEntity.method_11016(), true);
            } else {
                combineResult = class_4732.class_3923::method_24174;
            }
            
            float open = combineResult.apply(class_2281.method_24166(blockEntity)).get(partialTick);
            open = 1.0F - open;
            open = 1.0F - open * open * open;
            int light = combineResult.apply(new class_4737<>()).applyAsInt(packedLight);
            class_4730 material = getChestMaterialType(chest, chestType);
            class_4588 vertexConsumer = material.method_24145(bufferSource, class_1921::method_23576);
            if (chestType != class_2745.field_12569) {
                if (chestType == class_2745.field_12574) {
                    this.render(poseStack, vertexConsumer, this.doubleLeftLid, this.doubleLeftLock, this.doubleLeftBottom, open, light, packedOverlay);
                } else {
                    this.render(poseStack, vertexConsumer, this.doubleRightLid, this.doubleRightLock, this.doubleRightBottom, open, light, packedOverlay);
                }
            } else {
                this.render(poseStack, vertexConsumer, this.lid, this.lock, this.bottom, open, light, packedOverlay);
            }
            
            poseStack.method_22909();
        }
    }
    
    private static class_4730 getChestMaterialType(CopperChestBlock chest, class_2745 type) {
        return switch (chest.getState()) {
            case field_28705 -> getChestType(type, "copper_exposed");
            case field_28706 -> getChestType(type, "copper_weathered");
            case field_28707 -> getChestType(type, "copper_oxidized");
            default -> getChestType(type, "copper");
        };
    }
    
    private static class_4730 getChestType(class_2745 type, String chest) {
        return switch (type) {
            case field_12574 -> chestMaterial(chest + "_left");
            case field_12571 -> chestMaterial(chest + "_right");
            default -> chestMaterial(chest);
        };
    }
    
    private static class_4730 chestMaterial(String chestName) {
        return new class_4730(field_21709, class_2960.method_60656("entity/chest/" + chestName));
    }
    
    private void render(class_4587 poseStack, class_4588 consumer, class_630 lidPart, class_630 lockPart, class_630 bottomPart, float lidAngle, int packedLight, int packedOverlay) {
        lidPart.field_3654 = -(lidAngle * class_3532.field_29845);
        lockPart.field_3654 = lidPart.field_3654;
        lidPart.method_22698(poseStack, consumer, packedLight, packedOverlay);
        lockPart.method_22698(poseStack, consumer, packedLight, packedOverlay);
        bottomPart.method_22698(poseStack, consumer, packedLight, packedOverlay);
    }
}