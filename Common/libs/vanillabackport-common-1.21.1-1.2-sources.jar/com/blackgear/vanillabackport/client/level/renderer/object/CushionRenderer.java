package com.blackgear.vanillabackport.client.level.renderer.object;

import com.blackgear.vanillabackport.client.level.model.object.CushionModel;
import com.blackgear.vanillabackport.client.registries.ModModelLayers;
import com.blackgear.vanillabackport.common.level.entities.decoration.Cushion;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_156;
import net.minecraft.class_1767;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5617;
import net.minecraft.class_7833;
import net.minecraft.class_897;
import java.util.EnumMap;

@Environment(EnvType.CLIENT)
public class CushionRenderer extends class_897<Cushion> {
    private static final EnumMap<class_1767, class_2960> TEXTURES_BY_COLOR = class_156.method_654(new EnumMap<>(class_1767.class), textures -> {
        for (class_1767 color : class_1767.values()) {
            textures.put(color, class_2960.method_60656("textures/entity/cushion/" + color.method_7792() + "_cushion.png"));
        }
    });
    private final CushionModel model;
    
    public CushionRenderer(class_5617.class_5618 context) {
        super(context);
        this.model = new CushionModel(context.method_32167(ModModelLayers.CUSHION));
    }
    
    @Override
    public class_2960 getTextureLocation(Cushion cushion) {
        return TEXTURES_BY_COLOR.get(cushion.getColor());
    }
    
    @Override
    public void render(Cushion cushion, float entityYaw, float partialTick, class_4587 pose, class_4597 buffer, int packedLight) {
        pose.method_22903();
        pose.method_22907(class_7833.field_40716.rotationDegrees(class_2350.method_10150(cushion.method_36454()).method_10144()));
        pose.method_22907(class_7833.field_40714.rotationDegrees(180.0F));
        pose.method_22904(0.0, -0.25, 0.0);
        class_4588 consumer = buffer.getBuffer(class_1921.method_23576(this.getTextureLocation(cushion)));
        this.model.method_2828(pose, consumer, packedLight, class_4608.field_21444, -1);
        pose.method_22909();
        super.method_3936(cushion, entityYaw, partialTick, pose, buffer, packedLight);
    }
}
