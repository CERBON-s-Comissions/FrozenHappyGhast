package com.blackgear.vanillabackport.client.level.particle;

import com.blackgear.vanillabackport.client.registries.ModParticles;
import com.blackgear.vanillabackport.common.level.block_entities.PotentSulfurBlockEntity;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2400;
import net.minecraft.class_243;
import net.minecraft.class_3998;
import net.minecraft.class_5819;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;
import org.jetbrains.annotations.Nullable;

@Environment(EnvType.CLIENT)
public class NoxiousGasCloudParticle extends class_3998 {
    public NoxiousGasCloudParticle(class_638 level, double x, double y, double z) {
        super(level, x, y, z);
        this.field_3847 = 20;
    }

    @Override
    public void method_3070() {
        super.method_3070();
        if (this.field_3866 % 2 == 0) {
            class_2338 sourceBlock = class_2338.method_49637(this.field_3874, this.field_3854, this.field_3871);
            class_243 particlePos = pickRandomParticleSpawnPoint(this.field_3851, sourceBlock);
            if (PotentSulfurBlockEntity.canBeReachedByNoxiousGas(this.field_3851, sourceBlock, particlePos)) {
                spawnNoxiousGasParticle(this.field_3851, particlePos);
            }
        }
    }

    private static class_243 pickRandomParticleSpawnPoint(class_1937 level, class_2338 centerBlock) {
        class_5819 random = level.method_8409();
        class_243 horizontalDirection = new class_243(random.method_43057() - 0.5F, 0.0, random.method_43057() - 0.5F).method_1029();
        float distance = random.method_43057() * 3.0F;
        return centerBlock.method_46558().method_1019(horizontalDirection.method_1021(distance)).method_1023(0.0, 0.25, 0.0);
    }

    private static void spawnNoxiousGasParticle(class_1937 level, class_243 pos) {
        level.method_8494(ModParticles.NOXIOUS_GAS.get(), pos.field_1352, pos.field_1351, pos.field_1350, 0.0, 0.0, 0.0);
    }

    @Environment(EnvType.CLIENT)
    public static class Provider implements class_707<class_2400> {
        @Override @Nullable
        public class_703 createParticle(
            class_2400 type,
            class_638 level,
            double x,
            double y,
            double z,
            double xSpeed,
            double ySpeed,
            double zSpeed
        ) {
            return new NoxiousGasCloudParticle(level, x, y, z);
        }
    }
}