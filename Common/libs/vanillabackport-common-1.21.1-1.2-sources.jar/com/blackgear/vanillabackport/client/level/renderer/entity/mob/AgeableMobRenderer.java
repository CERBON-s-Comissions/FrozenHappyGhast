package com.blackgear.vanillabackport.client.level.renderer.entity.mob;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1308;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import net.minecraft.class_583;
import net.minecraft.class_927;

@Environment(EnvType.CLIENT)
public abstract class AgeableMobRenderer<T extends class_1308, M extends class_583<T>> extends class_927<T, M> {
    private final M adultModel;
    private final M babyModel;
    
    public AgeableMobRenderer(class_5617.class_5618 context, M adultModel, M babyModel, float shadowRadius) {
        super(context, adultModel, shadowRadius);
        this.adultModel = adultModel;
        this.babyModel = babyModel;
    }
    
    @Override
    public void render(T entity, float entityYaw, float partialTicks, class_4587 poseStack, class_4597 buffer, int packedLight) {
        this.field_4737 = entity.method_6109() ? this.babyModel : this.adultModel;
        super.method_4054(entity, entityYaw, partialTicks, poseStack, buffer, packedLight);
    }
}