package com.blackgear.vanillabackport.client.level.renderer.item;

import com.blackgear.platform.client.v2.render.ItemRendererRegistry;
import com.blackgear.platform.core.util.event.ResultHolder;
import com.blackgear.vanillabackport.common.registries.items.ModItems;
import com.google.common.collect.ImmutableSet;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1087;
import net.minecraft.class_1091;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_2960;
import net.minecraft.class_763;
import net.minecraft.class_7923;
import net.minecraft.class_811;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

@Environment(EnvType.CLIENT)
public class SpearRenderer implements ItemRendererRegistry.Renderer {
    public static final SpearRenderer INSTANCE = new SpearRenderer();
    public static final Set<class_1935> SPEARS = Set.of(
        ModItems.WOODEN_SPEAR.get(),
        ModItems.STONE_SPEAR.get(),
        ModItems.COPPER_SPEAR.get(),
        ModItems.IRON_SPEAR.get(),
        ModItems.GOLDEN_SPEAR.get(),
        ModItems.DIAMOND_SPEAR.get(),
        ModItems.NETHERITE_SPEAR.get()
    );
    
    private static final Map<class_1935, class_1091> SPEAR_MODELS = buildModels();
    
    private static Map<class_1935, class_1091> buildModels() {
        Map<class_1935, class_1091> models = new HashMap<>(SPEARS.size());
        for (class_1935 item : SPEARS) models.put(item, create(item.method_8389()));
        return models;
    }
    
    private static class_1091 create(class_1792 item) {
        return new class_1091(class_2960.method_60656(class_7923.field_41178.method_10221(item).method_12832() + "_in_hand"), "inventory");
    }
    
    @Override
    public ResultHolder<class_1087> renderFirstPerson(class_1799 stack, class_811 context, class_763 shaper) {
        return context == class_811.field_4317 || context == class_811.field_4319 || context == class_811.field_4318
            ? ResultHolder.pass()
            : ResultHolder.submit(shaper.method_3303().method_4742(SPEAR_MODELS.get(stack.method_7909())));
    }
    
    @Override
    public ResultHolder<class_1087> renderThirdPerson(class_1799 stack, class_763 shaper) {
        return ResultHolder.pass();
    }
    
    @Override
    public Set<class_1091> registerModels() {
        return ImmutableSet.copyOf(SPEAR_MODELS.values());
    }
}