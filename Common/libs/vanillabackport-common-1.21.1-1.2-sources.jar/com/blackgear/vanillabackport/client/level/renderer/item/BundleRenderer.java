package com.blackgear.vanillabackport.client.level.renderer.item;

import com.blackgear.platform.client.v2.render.ItemRendererRegistry;
import com.blackgear.platform.core.util.event.ResultHolder;
import com.blackgear.vanillabackport.common.registries.items.ModItems;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.google.common.collect.ImmutableSet;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1087;
import net.minecraft.class_1091;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1935;
import net.minecraft.class_763;
import net.minecraft.class_7923;
import net.minecraft.class_811;
import net.minecraft.world.item.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

@Environment(EnvType.CLIENT)
public class BundleRenderer implements ItemRendererRegistry.Renderer {
    public static final BundleRenderer INSTANCE = new BundleRenderer();
    public static final Set<class_1935> BUNDLES = Set.of(
        class_1802.field_27023,
        ModItems.WHITE_BUNDLE.get(),
        ModItems.ORANGE_BUNDLE.get(),
        ModItems.MAGENTA_BUNDLE.get(),
        ModItems.LIGHT_BLUE_BUNDLE.get(),
        ModItems.YELLOW_BUNDLE.get(),
        ModItems.LIME_BUNDLE.get(),
        ModItems.PINK_BUNDLE.get(),
        ModItems.GRAY_BUNDLE.get(),
        ModItems.LIGHT_GRAY_BUNDLE.get(),
        ModItems.CYAN_BUNDLE.get(),
        ModItems.BLUE_BUNDLE.get(),
        ModItems.BROWN_BUNDLE.get(),
        ModItems.GREEN_BUNDLE.get(),
        ModItems.RED_BUNDLE.get(),
        ModItems.BLACK_BUNDLE.get(),
        ModItems.PURPLE_BUNDLE.get()
    );

    private static final Map<class_1935, class_1091> BUNDLE_MODELS = buildModels();

    private static Map<class_1935, class_1091> buildModels() {
        Map<class_1935, class_1091> models = new HashMap<>(BUNDLES.size());
        for (class_1935 item : BUNDLES) {
            models.put(item, create(item.method_8389()));
        }
        
        return models;
    }

    private static class_1091 create(class_1792 item) {
        return new class_1091(VanillaBackport.resource(class_7923.field_41178.method_10221(item).method_12832()), "inventory");
    }

    @Override
    public boolean shouldUse() {
        return VanillaBackport.CLIENT_CONFIG.hasModernBundleModels.get();
    }

    @Override
    public ResultHolder<class_1087> renderFirstPerson(class_1799 stack, class_811 context, class_763 shaper) {
        return ResultHolder.submit(shaper.method_3303().method_4742(BUNDLE_MODELS.get(stack.method_7909())));
    }

    @Override
    public ResultHolder<class_1087> renderThirdPerson(class_1799 stack, class_763 shaper) {
        return ResultHolder.submit(shaper.method_3303().method_4742(BUNDLE_MODELS.get(stack.method_7909())));
    }

    @Override
    public Set<class_1091> registerModels() {
        return ImmutableSet.copyOf(BUNDLE_MODELS.values());
    }
}