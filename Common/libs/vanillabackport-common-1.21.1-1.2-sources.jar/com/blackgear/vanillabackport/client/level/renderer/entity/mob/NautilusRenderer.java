package com.blackgear.vanillabackport.client.level.renderer.entity.mob;

import com.blackgear.vanillabackport.client.level.layer.SimpleEquipmentLayer;
import com.blackgear.vanillabackport.client.level.model.entity.nautilus.NautilusModel;
import com.blackgear.vanillabackport.client.registries.ModModelLayers;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.nautilus.AbstractNautilus;
import com.blackgear.vanillabackport.common.level.items.NautilusArmorItem;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2960;
import net.minecraft.class_5617;
import java.util.Optional;

@Environment(EnvType.CLIENT)
public class NautilusRenderer<T extends AbstractNautilus> extends AgeableMobRenderer<T, NautilusModel<T>> {
    private static final class_2960 NAUTILUS_LOCATION = class_2960.method_60656("textures/entity/nautilus/nautilus.png");
    private static final class_2960 NAUTILUS_BABY_LOCATION = class_2960.method_60656("textures/entity/nautilus/nautilus_baby.png");
    static final class_2960 NAUTILUS_SADDLE_LOCATION = class_2960.method_60656("textures/entity/nautilus/saddle/saddle.png");
    
    public NautilusRenderer(class_5617.class_5618 context) {
        super(context, new NautilusModel<>(context.method_32167(ModModelLayers.NAUTILUS)), new NautilusModel<>(context.method_32167(ModModelLayers.NAUTILUS_BABY)), 0.7F);
        this.method_4046(new SimpleEquipmentLayer<>(
            this,
            entity -> entity.method_56676().method_7909() instanceof NautilusArmorItem armor
                ? Optional.ofNullable(armor.getTexture())
                : Optional.empty(),
            entity -> true,
            new NautilusModel<>(context.method_32167(ModModelLayers.NAUTILUS_ARMOR)),
            null
        ));
        this.method_4046(SimpleEquipmentLayer.of(
            this,
            NAUTILUS_SADDLE_LOCATION,
            AbstractNautilus::method_6725,
            new NautilusModel<>(context.method_32167(ModModelLayers.NAUTILUS_SADDLE)),
            null
        ));
    }
    
    @Override
    public class_2960 getTextureLocation(T entity) {
        return entity.method_6109() ? NAUTILUS_BABY_LOCATION : NAUTILUS_LOCATION;
    }
}