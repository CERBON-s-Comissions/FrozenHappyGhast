package com.blackgear.vanillabackport.client.level.layer;

import com.blackgear.vanillabackport.client.level.model.entity.sulfur_cube.SmallSulfurCubeModel;
import com.blackgear.vanillabackport.client.level.model.entity.sulfur_cube.SulfurCubeModel;
import com.blackgear.vanillabackport.client.registries.ModModelLayers;
import com.blackgear.vanillabackport.common.level.entities.mob.monster.sulfur_cube.SulfurCube;
import com.blackgear.vanillabackport.core.mixin.client.access.BlockRenderDispatcherAccessor;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1059;
import net.minecraft.class_1087;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2248;
import net.minecraft.class_2464;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5599;
import net.minecraft.class_583;
import net.minecraft.class_776;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_922;

@Environment(EnvType.CLIENT)
public class SulfurCubeInnerLayer extends class_3887<SulfurCube, SulfurCubeModel> {
    private static final class_2960 SULFUR_CUBE_INNER_LOCATION = class_2960.method_60656("textures/entity/sulfur_cube/sulfur_cube_inner.png");
    private static final class_2960 SULFUR_CUBE_INNER_SMALL_LOCATION = class_2960.method_60656("textures/entity/sulfur_cube/sulfur_cube_inner_small.png");

    private final SulfurCubeModel normalModel;
    private final SmallSulfurCubeModel smallModel;
    private final class_776 blockRenderer;

    public SulfurCubeInnerLayer(class_3883<SulfurCube, SulfurCubeModel> renderer, class_5599 modelSet, class_776 blockRenderer) {
        super(renderer);
        this.normalModel = new SulfurCubeModel(modelSet.method_32072(ModModelLayers.SULFUR_CUBE_INNER));
        this.smallModel = new SmallSulfurCubeModel(modelSet.method_32072(ModModelLayers.SULFUR_CUBE_SMALL_INNER));
        this.blockRenderer = blockRenderer;
    }

    @Override
    public void render(
        class_4587 pose,
        class_4597 buffer,
        int packedLight,
        SulfurCube cube,
        float limbSwing,
        float limbSwingAmount,
        float partialTick,
        float ageInTicks,
        float netHeadYaw,
        float headPitch
    ) {
        float fuse = cube.getFuseRemainingTicks(partialTick);
        int overlayCoords = fuse > 0.0F && isLit(fuse)
            ? class_4608.method_23625(class_4608.method_23210(1.0F), 10)
            : class_922.method_23622(cube, 0.0F);

        class_1799 containedBlock = cube.getContainedBlock();
        if (!containedBlock.method_7960()) {
            pose.method_22903();
            pose.method_22907(class_7833.field_40714.rotationDegrees(180.0F));
            if (cube.method_6109()) pose.method_22905(0.5F, 0.5F, 0.5F);

            pose.method_46416(-0.5F, -0.518F, -0.5F);
            class_2680 state = class_2248.method_9503(containedBlock.method_7909()).method_9564(); //TODO: apply matching properties from item
            renderSingleBlock(state, pose, buffer, packedLight, overlayCoords);
            pose.method_22909();
        } else if (!cube.method_5767()) {
            class_2960 texture = cube.method_6109() ? SULFUR_CUBE_INNER_SMALL_LOCATION : SULFUR_CUBE_INNER_LOCATION;
            class_583<SulfurCube> model = cube.method_6109() ? this.smallModel : this.normalModel;
            class_1921 renderType = class_1921.method_23572(texture);
            model.method_2828(pose, buffer.getBuffer(renderType), packedLight, overlayCoords, -1);
        }
    }

    private void renderSingleBlock(class_2680 state, class_4587 pose, class_4597 buffer, int packedLight, int packedOverlay) {
        class_2464 renderShape = state.method_26217();
        if (renderShape != class_2464.field_11455) {
            switch (renderShape) {
                case field_11458:
                    class_1087 bakedModel = this.blockRenderer.method_3349(state);
                    int colors = ((BlockRenderDispatcherAccessor) this.blockRenderer).getBlockColors().method_1697(state, null, null, 0);
                    float red = (float)(colors >> 16 & 255) / 255.0F;
                    float green = (float)(colors >> 8 & 255) / 255.0F;
                    float blue = (float)(colors & 255) / 255.0F;
                    this.blockRenderer.method_3350().method_3367(pose.method_23760(), buffer.getBuffer(class_1921.method_23578(class_1059.field_5275)), state, bakedModel, red, green, blue, packedLight, packedOverlay);
                    break;
                case field_11456:
                    ((BlockRenderDispatcherAccessor) this.blockRenderer).getBlockEntityRenderer().method_3166(new class_1799(state.method_26204()), class_811.field_4315, pose, buffer, packedLight, packedOverlay);
            }
        }
    }

    public boolean isLit(float fuse) {
        return !(fuse < 0.0F) && (int) (fuse / 5.0F) % 2 == 0;
    }
}