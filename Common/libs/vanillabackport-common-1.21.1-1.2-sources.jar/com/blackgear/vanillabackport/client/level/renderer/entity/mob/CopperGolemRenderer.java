package com.blackgear.vanillabackport.client.level.renderer.entity.mob;

import com.blackgear.vanillabackport.client.level.layer.BlockDecorationLayer;
import com.blackgear.vanillabackport.client.level.layer.LivingEntityEmissiveLayer;
import com.blackgear.vanillabackport.client.level.model.entity.CopperGolemModel;
import com.blackgear.vanillabackport.client.registries.ModModelLayers;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.golem.copper_golem.CopperGolem;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.golem.copper_golem.CopperGolemOxidationLevels;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_5617;
import net.minecraft.class_927;
import net.minecraft.class_989;
import java.util.function.Function;

@Environment(EnvType.CLIENT)
public class CopperGolemRenderer extends class_927<CopperGolem, CopperGolemModel<CopperGolem>> {
    public CopperGolemRenderer(class_5617.class_5618 context) {
        super(context, new CopperGolemModel<>(context.method_32167(ModModelLayers.COPPER_GOLEM)), 0.5F);
        this.method_4046(new LivingEntityEmissiveLayer<>(
            this,
            getEyeTextureLocationProvider(),
            (golem, ageInTicks) -> 1.0F,
            new CopperGolemModel<>(context.method_32167(ModModelLayers.COPPER_GOLEM)),
            class_1921::method_23026,
            false
        ));
        this.method_4046(new class_989<>(this, context.method_43338()));
        this.method_4046(new BlockDecorationLayer<>(
            this,
            context.method_43337(),
            golem -> {
                class_1799 antennaItem = golem.method_6118(CopperGolem.EQUIPMENT_SLOT_ANTENNA);
                if (antennaItem.method_7909() instanceof class_1747 block) {
                    return block.method_7711().method_9564();
                } else {
                    return null;
                }
            },
            this.field_4737::applyBlockOnAntennaTransform));
    }

    private Function<CopperGolem, class_2960> getEyeTextureLocationProvider() {
        return golem -> CopperGolemOxidationLevels.getOxidationLevel(golem.getWeatherState()).eyeTexture();
    }

    @Override
    public class_2960 getTextureLocation(CopperGolem entity) {
        return CopperGolemOxidationLevels.getOxidationLevel(entity.getWeatherState()).texture();
    }

    @Override
    protected void scale(CopperGolem livingEntity, class_4587 poseStack, float partialTickTime) {
        super.method_4042(livingEntity, poseStack, partialTickTime);
        poseStack.method_22904(0.0, 1.5, 0.0);
    }
}