package com.blackgear.vanillabackport.client.level.model.entity.happy_ghast;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_5597;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_630;
import net.minecraft.client.model.geom.builders.*;

@Environment(EnvType.CLIENT)
public class HappyGhastHarnessModel<T extends class_1297> extends class_5597<T> {
    private final class_630 root;
    private final class_630 goggles;

    public HappyGhastHarnessModel(class_630 root) {
        this.root = root;
        this.goggles = root.method_32086("goggles");
    }

    public static class_5607 createHarnessLayer() {
        class_5609 mesh = new class_5609();
        class_5610 root = mesh.method_32111();
        root.method_32117(
            "harness",
            class_5606.method_32108()
                .method_32101(0, 0)
                .method_32097(-8.0F, -16.0F, -8.0F, 16.0F, 16.0F, 16.0F),
            class_5603.method_32090(0.0F, 24.0F, 0.0F)
        );
        root.method_32117(
            "goggles",
            class_5606.method_32108()
                .method_32101(0, 32)
                .method_32098(-8.0F, -2.5F, -2.5F, 16.0F, 5.0F, 5.0F, new class_5605(0.15F)),
            class_5603.method_32090(0.0F, 14.0F, -5.5F)
        );
        return class_5607.method_32110(mesh, 64, 64);
    }

    @Override
    public void method_2819(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        if (entity.method_5782()) {
            this.goggles.field_3654 = 0.0F;
            this.goggles.field_3656 = 14.0F;
        } else {
            this.goggles.field_3654 = -0.7854F;
            this.goggles.field_3656 = 9.0F;
        }
    }

    @Override
    public class_630 method_32008() {
        return this.root;
    }
}