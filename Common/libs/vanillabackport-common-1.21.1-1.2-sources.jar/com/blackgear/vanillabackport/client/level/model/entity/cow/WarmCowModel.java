package com.blackgear.vanillabackport.client.level.model.entity.cow;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1430;
import net.minecraft.class_5603;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_630;
import net.minecraft.client.model.geom.builders.*;

@Environment(EnvType.CLIENT)
public class WarmCowModel<T extends class_1430> extends CowVariantModel<T> {
    public WarmCowModel(class_630 root) {
        super(root);
    }

    public static class_5607 method_31990() {
        class_5609 mesh = createBaseCowModel();
        class_5610 root = mesh.method_32111();
        root.method_32117(
            "head",
            class_5606.method_32108()
                .method_32101(0, 0)
                .method_32097(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 6.0F)
                .method_32101(1, 33)
                .method_32097(-3.0F, 1.0F, -7.0F, 6.0F, 3.0F, 1.0F)
                .method_32101(27, 0)
                .method_32097(-8.0F, -3.0F, -5.0F, 4.0F, 2.0F, 2.0F)
                .method_32101(39, 0)
                .method_32097(-8.0F, -5.0F, -5.0F, 2.0F, 2.0F, 2.0F)
                .method_32101(27, 0)
                .method_32096()
                .method_32097(4.0F, -3.0F, -5.0F, 4.0F, 2.0F, 2.0F)
                .method_32106(false)
                .method_32101(39, 0)
                .method_32096()
                .method_32097(6.0F, -5.0F, -5.0F, 2.0F, 2.0F, 2.0F)
                .method_32106(false),
            class_5603.method_32090(0.0F, 4.0F, -8.0F)
        );

        return class_5607.method_32110(mesh, 64, 64);
    }
}