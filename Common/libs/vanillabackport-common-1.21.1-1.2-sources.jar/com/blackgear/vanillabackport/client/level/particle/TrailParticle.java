package com.blackgear.vanillabackport.client.level.particle;

import com.blackgear.vanillabackport.client.level.particle.particleoptions.TrailParticleOption;
import com.blackgear.vanillabackport.core.util.Utilities.ColorUtils;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_3999;
import net.minecraft.class_4002;
import net.minecraft.class_4003;
import net.minecraft.class_5253.class_5254;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;
import net.minecraft.client.particle.*;

@Environment(EnvType.CLIENT)
public class TrailParticle extends class_4003 {
    private final class_243 target;

    protected TrailParticle(class_638 level, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed, class_243 target, int color) {
        super(level, x, y, z, xSpeed, ySpeed, zSpeed);
        color = ColorUtils.scaleRGB(color, 0.875F + this.field_3840.method_43057() * 0.25F, 0.875F + this.field_3840.method_43057() * 0.25F, 0.875F + this.field_3840.method_43057() * 0.25F);
        this.field_3861 = class_5254.method_27765(color) / 255.0F;
        this.field_3842 = class_5254.method_27766(color) / 255.0F;
        this.field_3859 = class_5254.method_27767(color) / 255.0F;
        this.field_17867 = 0.26F;
        this.target = target;
    }

    @Override
    public class_3999 method_18122() {
        return class_3999.field_17828;
    }

    @Override
    public void method_3070() {
        this.field_3858 = this.field_3874;
        this.field_3838 = this.field_3854;
        this.field_3856 = this.field_3871;
        if (this.field_3866++ >= this.field_3847) {
            this.method_3085();
        } else {
            int ticksRemaining = this.field_3847 - this.field_3866;
            double alpha = 1.0 / ticksRemaining;
            this.field_3874 = class_3532.method_16436(alpha, this.field_3874, this.target.method_10216());
            this.field_3854 = class_3532.method_16436(alpha, this.field_3854, this.target.method_10214());
            this.field_3871 = class_3532.method_16436(alpha, this.field_3871, this.target.method_10215());
        }
    }

    @Override
    protected int method_3068(float partialTick) {
        return 15728880;
    }

    @Environment(EnvType.CLIENT)
    public record Provider(class_4002 sprites) implements class_707<TrailParticleOption> {
        @Override
        public class_703 createParticle(TrailParticleOption option, class_638 level, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
            TrailParticle particle = new TrailParticle(level, x, y, z, xSpeed, ySpeed, zSpeed, option.target(), option.color());
            particle.method_18140(this.sprites);
            particle.method_3077(option.duration());
            return particle;
        }
    }
}