package com.blackgear.vanillabackport.client.level.sound;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1101;
import net.minecraft.class_1113;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_3414;
import net.minecraft.class_3532;

@Environment(EnvType.CLIENT)
public class RidingEntitySoundInstance extends class_1101 {
    private final class_1657 player;
    private final class_1297 entity;
    private final boolean underwaterSound;
    private final float volumeMin;
    private final float volumeMax;
    private final float volumeAmplifier;
    
    public RidingEntitySoundInstance(
        class_1657 player,
        class_1297 entity,
        boolean underwaterSound,
        class_3414 sound,
        float volumeMin,
        float volumeMax,
        float volumeAmplifier
    ) {
        super(sound, entity.method_5634(), class_1113.method_43221());
        this.player = player;
        this.entity = entity;
        this.underwaterSound = underwaterSound;
        this.volumeMin = volumeMin;
        this.volumeMax = volumeMax;
        this.volumeAmplifier = volumeAmplifier;
        this.field_5440 = class_1114.field_5478;
        this.field_5446 = true;
        this.field_5451 = 0;
        this.field_5442 = volumeMin;
    }
    
    @Override
    public boolean method_26273() {
        return !this.entity.method_5701();
    }
    
    @Override
    public boolean method_4785() {
        return true;
    }
    
    private boolean shouldNotPlayUnderwaterSound() {
        return this.underwaterSound != this.entity.method_5869();
    }
    
    protected float getEntitySpeed() {
        return (float) this.entity.method_18798().method_1033();
    }
    
    protected boolean shouldPlaySound() {
        return true;
    }
    
    @Override
    public void method_16896() {
        if (this.entity.method_31481() || !this.player.method_5765() || this.player.method_5854() != this.entity) {
            this.method_24876();
        } else if (this.shouldNotPlayUnderwaterSound()) {
            this.field_5442 = this.volumeMin;
        } else {
            float speed = this.getEntitySpeed();
            if (speed >= 0.01F && this.shouldPlaySound()) {
                this.field_5442 = this.volumeAmplifier * class_3532.method_37166(this.volumeMin, this.volumeMax, speed);
            } else {
                this.field_5442 = this.volumeMin;
            }
        }
    }
}