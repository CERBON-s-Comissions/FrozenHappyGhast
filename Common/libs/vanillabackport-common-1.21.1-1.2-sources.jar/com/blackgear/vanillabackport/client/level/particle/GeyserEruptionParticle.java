package com.blackgear.vanillabackport.client.level.particle;

import com.blackgear.vanillabackport.client.level.particle.particleoptions.GeyserBaseParticleOptions;
import com.blackgear.vanillabackport.client.level.particle.particleoptions.GeyserParticleOptions;
import com.blackgear.vanillabackport.client.registries.ModParticles;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_3998;
import net.minecraft.class_4002;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;

@Environment(EnvType.CLIENT)
public class GeyserEruptionParticle extends class_3998 {
    private final int waterBlocks;
    private final double xa;
    private final double ya;
    private final double za;
    private final GeyserParticleOptions plumeParticle;
    private final GeyserBaseParticleOptions baseParticle;
    private final GeyserBaseParticleOptions poofParticle;

    protected GeyserEruptionParticle(
        class_638 level,
        double x,
        double y,
        double z,
        double xAux,
        double yAux,
        double zAux,
        GeyserParticleOptions options
    ) {
        super(level, x, y, z);
        this.xa = xAux;
        this.ya = yAux;
        this.za = zAux;
        this.waterBlocks = options.waterBlocks();
        this.field_3847 = 20;
        this.plumeParticle = new GeyserParticleOptions(ModParticles.GEYSER_PLUME.get(), this.waterBlocks);
        this.baseParticle = new GeyserBaseParticleOptions(ModParticles.GEYSER_BASE.get(), this.waterBlocks, 1.5F);
        this.poofParticle = new GeyserBaseParticleOptions(ModParticles.GEYSER_POOF.get(), this.waterBlocks, 2.0F);
    }

    @Override
    public void method_3070() {
        super.method_3070();
        if (this.field_3866 % 2 == 0) {
            for (int i = 0; i < 2; i++) {
                this.field_3851.method_8406(this.baseParticle, this.field_3874, this.field_3854, this.field_3871, this.xa, this.ya, this.za);
            }
        }

        for (int i = 0; i < this.waterBlocks + 2; i++) {
            this.field_3851.method_8406(this.plumeParticle, this.field_3874, this.field_3854, this.field_3871, this.xa, this.ya, this.za);
        }

        if (this.field_3866 % 10 == 0) {
            for (int i = 0; i < 20; i++) {
                this.field_3851.method_8406(this.poofParticle, this.field_3874, this.field_3854, this.field_3871, this.xa, this.ya, this.za);
            }
        }
    }

    @Environment(EnvType.CLIENT)
    public record Provider(class_4002 sprites) implements class_707<GeyserParticleOptions> {
        @Override
        public class_703 createParticle(
            GeyserParticleOptions type,
            class_638 level,
            double x,
            double y,
            double z,
            double xSpeed,
            double ySpeed,
            double zSpeed
        ) {
            return new GeyserEruptionParticle(level, x, y, z, xSpeed, ySpeed, zSpeed, type);
        }
    }
}