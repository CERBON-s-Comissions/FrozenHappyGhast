package com.blackgear.vanillabackport.client.level.particle.particleoptions;

import com.blackgear.vanillabackport.client.registries.ModParticles;
import com.blackgear.vanillabackport.core.util.AdditionalCodecs;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.minecraft.class_243;
import net.minecraft.class_5699;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record TrailParticleOption(class_243 target, int color, int duration) implements class_2394 {
    public static final MapCodec<TrailParticleOption> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
        class_243.field_38277.fieldOf("target").forGetter(TrailParticleOption::target),
        AdditionalCodecs.RGB_COLOR_CODEC.fieldOf("color").forGetter(TrailParticleOption::color),
        class_5699.field_33442.fieldOf("duration").forGetter(TrailParticleOption::duration)
    ).apply(instance, TrailParticleOption::new));
    
    public static final class_9139<class_9129, TrailParticleOption> STREAM_CODEC = class_9139.method_56436(
        AdditionalCodecs.VEC3_STREAM_CODEC, TrailParticleOption::target,
        class_9135.field_49675, TrailParticleOption::color,
        class_9135.field_48550, TrailParticleOption::duration,
        TrailParticleOption::new);

    @Override
    public class_2396<?> method_10295() {
        return ModParticles.TRAIL.get();
    }
}