package com.blackgear.vanillabackport.client.level.model.entity.sulfur_cube;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_5603;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_630;

@Environment(EnvType.CLIENT)
public class SmallSulfurCubeModel extends SulfurCubeModel {
    public SmallSulfurCubeModel(class_630 root) {
        super(root);
    }

    public static class_5607 createOuterBodyLayer() {
        class_5609 mesh = new class_5609();
        class_5610 root = mesh.method_32111();
        root.method_32117("cube", class_5606.method_32108().method_32101(0, 0).method_32097(-5.0F, -5.0F, -5.0F, 10.0F, 10.0F, 10.0F), class_5603.field_27701);
        return class_5607.method_32110(mesh, 64, 64);
    }

    public static class_5607 createInnerBodyLayer() {
        class_5609 mesh = new class_5609();
        class_5610 root = mesh.method_32111();
        root.method_32117("cube", class_5606.method_32108().method_32101(0, 20).method_32097(-4.0F, -4.0F, -4.0F, 8.0F, 8.0F, 8.0F), class_5603.field_27701);
        return class_5607.method_32110(mesh, 64, 64);
    }
}