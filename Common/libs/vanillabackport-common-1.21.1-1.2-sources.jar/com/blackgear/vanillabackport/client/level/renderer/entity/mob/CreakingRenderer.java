package com.blackgear.vanillabackport.client.level.renderer.entity.mob;

import com.blackgear.vanillabackport.client.level.layer.LivingEntityEmissiveLayer;
import com.blackgear.vanillabackport.client.level.model.entity.CreakingModel;
import com.blackgear.vanillabackport.client.registries.ModModelLayers;
import com.blackgear.vanillabackport.common.level.entities.mob.monster.creaking.Creaking;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_5617;
import net.minecraft.class_927;

@Environment(EnvType.CLIENT)
public class CreakingRenderer<T extends Creaking> extends class_927<T, CreakingModel<T>> {
    private static final class_2960 TEXTURE_LOCATION = class_2960.method_60656("textures/entity/creaking/creaking.png");
    private static final class_2960 EYES_TEXTURE_LOCATION = class_2960.method_60656("textures/entity/creaking/creaking_eyes.png");

    public CreakingRenderer(class_5617.class_5618 context) {
        super(context, new CreakingModel<>(context.method_32167(ModModelLayers.CREAKING)), 0.6F);
        this.method_4046(new LivingEntityEmissiveLayer<>(
            this,
            creaking -> EYES_TEXTURE_LOCATION,
            (creaking, ageInTicks) -> creaking.shouldEyesGlow() ? 1.0F : 0.0F,
            new CreakingModel<>(context.method_32167(ModModelLayers.CREAKING)),
            class_1921::method_23026,
            true
        ));
    }

    @Override
    public class_2960 getTextureLocation(Creaking entity) {
        return TEXTURE_LOCATION;
    }
}