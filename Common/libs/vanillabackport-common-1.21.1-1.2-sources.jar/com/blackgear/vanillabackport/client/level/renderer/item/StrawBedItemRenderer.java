package com.blackgear.vanillabackport.client.level.renderer.item;

import com.blackgear.platform.client.v2.render.DynamicItemRenderer;
import com.blackgear.platform.core.util.event.ResultHolder;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1087;
import net.minecraft.class_1091;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2244;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2742;
import net.minecraft.class_310;
import net.minecraft.class_325;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4696;
import net.minecraft.class_763;
import net.minecraft.class_776;
import net.minecraft.class_811;
import net.minecraft.class_918;
import java.util.Collections;
import java.util.Set;

@Environment(EnvType.CLIENT)
public class StrawBedItemRenderer implements DynamicItemRenderer.Renderer {
    public static final StrawBedItemRenderer INSTANCE = new StrawBedItemRenderer();
    
    private static final class_2680 HEAD_STATE = ModBlocks.STRAW_BED.get().method_9564()
        .method_11657(class_2244.field_11177, class_2350.field_11035)
        .method_11657(class_2244.field_9967, class_2742.field_12560);
    
    private static final class_2680 FOOT_STATE = ModBlocks.STRAW_BED.get().method_9564()
        .method_11657(class_2244.field_11177, class_2350.field_11035)
        .method_11657(class_2244.field_9967, class_2742.field_12557);
    
    @Override
    public void renderFirstPerson(
        class_1799 stack,
        class_811 context,
        boolean leftHand,
        class_4587 pose,
        class_4597 buffer,
        int light,
        int overlay,
        class_1087 model,
        class_763 shaper,
        class_325 colors
    ) {
        if (stack.method_31574(ModBlocks.STRAW_BED.get().method_8389())) {
            class_776 renderer = class_310.method_1551().method_1541();
            
            class_1087 headModel = renderer.method_3349(HEAD_STATE);
            class_1087 footModel = renderer.method_3349(FOOT_STATE);
            
            class_1921 renderType = class_4696.method_23678(stack, true);
            class_4588 vertices = class_918.method_29711(buffer, renderType, true, stack.method_7958());
            
            pose.method_22903();
            
            model.method_4709().method_3503(context).method_23075(leftHand, pose);
            
            pose.method_46416(-0.5F, -0.5F, -0.5F);
            
            pose.method_22903();
            pose.method_46416(0.0F, 0.0F, -0.3F);
            this.renderModelLists(headModel, stack, light, overlay, pose, vertices, colors);
            pose.method_22909();
            
            pose.method_22903();
            pose.method_46416(0.0F, 0.0F, -1.3F);
            this.renderModelLists(footModel, stack, light, overlay, pose, vertices, colors);
            pose.method_22909();
            
            pose.method_22909();
        }
    }
    
    @Override
    public ResultHolder<class_1087> renderThirdPerson(class_1799 stack, class_763 shaper) {
        return ResultHolder.pass();
    }
    
    @Override
    public Set<class_1091> registerModels() {
        return Collections.emptySet();
    }
}