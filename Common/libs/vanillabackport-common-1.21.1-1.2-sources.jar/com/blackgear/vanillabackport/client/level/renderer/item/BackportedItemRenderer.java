package com.blackgear.vanillabackport.client.level.renderer.item;

import com.blackgear.platform.client.v2.render.ItemRendererRegistry;
import com.blackgear.platform.core.util.config.ConfigBuilder;
import com.blackgear.platform.core.util.event.ResultHolder;
import com.blackgear.vanillabackport.core.VanillaBackport;
import org.jetbrains.annotations.NotNull;

import java.util.Set;
import java.util.stream.Collectors;
import net.minecraft.class_1087;
import net.minecraft.class_1091;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_763;
import net.minecraft.class_7923;
import net.minecraft.class_811;

public class BackportedItemRenderer implements ItemRendererRegistry.Renderer {
  private final ConfigBuilder.ConfigValue<Boolean> configValue;
  private final Set<class_1792> items;

  public BackportedItemRenderer(ConfigBuilder.ConfigValue<Boolean> configValue, Set<class_1792> items) {
    this.configValue = configValue;
    this.items = items;
  }

  private static class_1091 getModelResourceLocation(class_1792 item) {
    class_2960 originalItem = class_7923.field_41178.method_10221(item);
    class_2960 backportItem = VanillaBackport.resource(originalItem.method_12832());
    return new class_1091(backportItem, "inventory");
  }

  private static @NotNull ResultHolder<class_1087> getModel(class_1799 itemStack, class_763 itemModelShaper) {
    class_1091 modelResourceLocation = getModelResourceLocation(itemStack.method_7909());
    return ResultHolder.submit(itemModelShaper.method_3303().method_4742(modelResourceLocation));
  }

  @Override
  public ResultHolder<class_1087> renderFirstPerson(class_1799 itemStack, class_811 itemDisplayContext, class_763 itemModelShaper) {
    return getModel(itemStack, itemModelShaper);
  }

  @Override
  public ResultHolder<class_1087> renderThirdPerson(class_1799 itemStack, class_763 itemModelShaper) {
    return getModel(itemStack, itemModelShaper);
  }

  @Override
  public Set<class_1091> registerModels() {
    return items
        .stream()
        .map(BackportedItemRenderer::getModelResourceLocation)
        .collect(Collectors.toSet());
  }

  @Override
  public boolean shouldUse() {
    return configValue.get();
  }
}
