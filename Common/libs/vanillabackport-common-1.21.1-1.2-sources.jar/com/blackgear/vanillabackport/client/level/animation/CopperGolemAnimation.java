package com.blackgear.vanillabackport.client.level.animation;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_7179;
import net.minecraft.class_7184;
import net.minecraft.class_7186;
import net.minecraft.class_7187;

@Environment(EnvType.CLIENT)
public class CopperGolemAnimation {
	public static final class_7184 COPPER_GOLEM_WALK = class_7184.class_7185.method_41818(0.8333F)
		.method_41817()
		.method_41820(
			"body",
			new class_7179(
				class_7179.class_7183.field_37887,
				new class_7186(0.0F, class_7187.method_41829(10.0F, 15.0F, 0.0F), class_7179.class_7181.field_37885),
				new class_7186(0.2083F, class_7187.method_41829(10.0F, -1.87F, -10.0F), class_7179.class_7181.field_37885),
				new class_7186(0.4167F, class_7187.method_41829(10.0F, -15.0F, 0.0F), class_7179.class_7181.field_37885),
				new class_7186(0.625F, class_7187.method_41829(10.0F, -0.82F, 10.0F), class_7179.class_7181.field_37885),
				new class_7186(0.8333F, class_7187.method_41829(10.0F, 15.0F, 0.0F), class_7179.class_7181.field_37885)
			)
		)
		.method_41820(
			"head",
			new class_7179(
				class_7179.class_7183.field_37887,
				new class_7186(0.0F, class_7187.method_41829(-10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
				new class_7186(0.2083F, class_7187.method_41829(-10.0F, 1.87F, 10.0F), class_7179.class_7181.field_37885),
				new class_7186(0.4167F, class_7187.method_41829(-10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
				new class_7186(0.625F, class_7187.method_41829(-10.0F, 0.82F, -10.0F), class_7179.class_7181.field_37885),
				new class_7186(0.8333F, class_7187.method_41829(-10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885)
			)
		)
		.method_41820(
			"right_arm",
			new class_7179(
				class_7179.class_7183.field_37887,
				new class_7186(0.0F, class_7187.method_41829(70.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
				new class_7186(0.4167F, class_7187.method_41829(-80.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
				new class_7186(0.8333F, class_7187.method_41829(70.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885)
			)
		)
		.method_41820(
			"left_arm",
			new class_7179(
				class_7179.class_7183.field_37887,
				new class_7186(0.0F, class_7187.method_41829(-80.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
				new class_7186(0.4167F, class_7187.method_41829(70.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
				new class_7186(0.8333F, class_7187.method_41829(-80.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885)
			)
		)
		.method_41820(
			"right_leg",
			new class_7179(
				class_7179.class_7183.field_37887,
				new class_7186(0.0F, class_7187.method_41829(-60.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
				new class_7186(0.4167F, class_7187.method_41829(60.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
				new class_7186(0.8333F, class_7187.method_41829(-60.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885)
			)
		)
		.method_41820(
			"left_leg",
			new class_7179(
				class_7179.class_7183.field_37887,
				new class_7186(0.0F, class_7187.method_41829(60.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
				new class_7186(0.4167F, class_7187.method_41829(-60.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
				new class_7186(0.8333F, class_7187.method_41829(60.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885)
			)
		)
		.method_41821();
	public static final class_7184 COPPER_GOLEM_IDLE = class_7184.class_7185.method_41818(3.5F)
		.method_41820(
			"body",
			new class_7179(
				class_7179.class_7183.field_37887,
				new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41829(0.0F, -35.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.5F, class_7187.method_41829(0.0F, -35.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.625F, class_7187.method_41829(0.0F, 35.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.2083F, class_7187.method_41829(0.0F, 35.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.7083F, class_7187.method_41829(0.0F, 35.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(3.5F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"head",
			new class_7179(
				class_7179.class_7183.field_37887,
				new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.5F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.625F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.2083F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.5F, class_7187.method_41829(0.0F, 300.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.6667F, class_7187.method_41829(0.0F, 300.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.75F, class_7187.method_41829(-25.0F, 300.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.7083F, class_7187.method_41829(-25.0F, 300.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(3.0F, class_7187.method_41829(0.0F, 360.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(3.5F, class_7187.method_41829(0.0F, 360.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41821();
	public static final class_7184 COPPER_GOLEM_WALK_ITEM = class_7184.class_7185.method_41818(0.8333F)
		.method_41817()
		.method_41820(
			"body",
			new class_7179(
				class_7179.class_7183.field_37887,
				new class_7186(0.0F, class_7187.method_41829(10.0F, 7.5F, 0.0F), class_7179.class_7181.field_37885),
				new class_7186(0.2083F, class_7187.method_41829(10.0F, -1.87F, -5.0F), class_7179.class_7181.field_37885),
				new class_7186(0.4167F, class_7187.method_41829(10.0F, -7.5F, 0.0F), class_7179.class_7181.field_37885),
				new class_7186(0.625F, class_7187.method_41829(10.0F, -0.82F, 5.0F), class_7179.class_7181.field_37885),
				new class_7186(0.8333F, class_7187.method_41829(10.0F, 7.5F, 0.0F), class_7179.class_7181.field_37885)
			)
		)
		.method_41820(
			"head",
			new class_7179(
				class_7179.class_7183.field_37887,
				new class_7186(0.0F, class_7187.method_41829(-10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
				new class_7186(0.2083F, class_7187.method_41829(-10.0F, 1.87F, 10.0F), class_7179.class_7181.field_37885),
				new class_7186(0.4167F, class_7187.method_41829(-10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
				new class_7186(0.625F, class_7187.method_41829(-10.0F, 0.82F, -10.0F), class_7179.class_7181.field_37885),
				new class_7186(0.8333F, class_7187.method_41829(-10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885)
			)
		)
		.method_41820(
			"right_arm",
			new class_7179(
				class_7179.class_7183.field_37887,
				new class_7186(0.0F, class_7187.method_41829(-59.78638F, -6.49053F, -3.76613F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"left_arm",
			new class_7179(
				class_7179.class_7183.field_37887, new class_7186(0.0F, class_7187.method_41829(-59.78638F, 6.49053F, 3.76613F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"left_arm",
			new class_7179(
				class_7179.class_7183.field_37886, new class_7186(0.0F, class_7187.method_41823(-0.21129F, -0.0212F, -0.07004F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"right_leg",
			new class_7179(
				class_7179.class_7183.field_37887,
				new class_7186(0.0F, class_7187.method_41829(-30.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
				new class_7186(0.4167F, class_7187.method_41829(30.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
				new class_7186(0.8333F, class_7187.method_41829(-30.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885)
			)
		)
		.method_41820(
			"left_leg",
			new class_7179(
				class_7179.class_7183.field_37887,
				new class_7186(0.0F, class_7187.method_41829(30.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
				new class_7186(0.4167F, class_7187.method_41829(-30.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
				new class_7186(0.8333F, class_7187.method_41829(30.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885)
			)
		)
		.method_41821();
	public static final class_7184 COPPER_GOLEM_CHEST_INTERACTION_ITEM_DROP = class_7184.class_7185.method_41818(3.0F)
		.method_41817()
		.method_41820(
			"body",
			new class_7179(
				class_7179.class_7183.field_37887,
				new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.1667F, class_7187.method_41829(18.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2917F, class_7187.method_41829(24.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.375F, class_7187.method_41829(15.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.4167F, class_7187.method_41829(12.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.5833F, class_7187.method_41829(12.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.75F, class_7187.method_41829(12.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.8333F, class_7187.method_41829(14.72765F, -31.63886F, -7.85085F), class_7179.class_7181.field_37884),
				new class_7186(0.9167F, class_7187.method_41829(14.72765F, -31.63886F, -7.85085F), class_7179.class_7181.field_37884),
				new class_7186(1.0417F, class_7187.method_41829(14.72765F, -31.63886F, -7.85085F), class_7179.class_7181.field_37884),
				new class_7186(1.125F, class_7187.method_41829(12.40525F, -4.4E-4F, 0.00829F), class_7179.class_7181.field_37884),
				new class_7186(1.2083F, class_7187.method_41829(12.40525F, -4.4E-4F, 0.00829F), class_7179.class_7181.field_37884),
				new class_7186(1.2917F, class_7187.method_41829(13.92716F, 26.80536F, 6.38918F), class_7179.class_7181.field_37884),
				new class_7186(1.625F, class_7187.method_41829(13.93F, 26.81F, 6.39F), class_7179.class_7181.field_37884),
				new class_7186(1.6667F, class_7187.method_41829(21.43F, 26.81F, 6.39F), class_7179.class_7181.field_37884),
				new class_7186(1.7917F, class_7187.method_41829(21.43F, 26.81F, 6.39F), class_7179.class_7181.field_37884),
				new class_7186(1.8333F, class_7187.method_41829(13.93F, 26.81F, 6.39F), class_7179.class_7181.field_37884),
				new class_7186(2.0417F, class_7187.method_41829(13.93F, 26.81F, 6.39F), class_7179.class_7181.field_37884),
				new class_7186(2.125F, class_7187.method_41829(12.40725F, 0.0F, 0.00783F), class_7179.class_7181.field_37884),
				new class_7186(2.1667F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.2917F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.375F, class_7187.method_41829(-7.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.4167F, class_7187.method_41829(-10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.4583F, class_7187.method_41829(-10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.5417F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.625F, class_7187.method_41829(15.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.6667F, class_7187.method_41829(17.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.7083F, class_7187.method_41829(22.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.875F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"body",
			new class_7179(
				class_7179.class_7183.field_37886,
				new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2083F, class_7187.method_41823(0.0F, 0.6F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.4167F, class_7187.method_41823(0.0F, 0.5F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.625F, class_7187.method_41823(0.0F, 0.4F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.6667F, class_7187.method_41823(-0.01805F, 0.88303F, -0.09783F), class_7179.class_7181.field_37884),
				new class_7186(1.7917F, class_7187.method_41823(-0.01805F, 0.88303F, -0.09783F), class_7179.class_7181.field_37884),
				new class_7186(1.8333F, class_7187.method_41823(0.0F, 0.6F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.0417F, class_7187.method_41823(0.0F, 0.6F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.1667F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.2917F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.375F, class_7187.method_41823(0.0F, 0.0F, -1.0F), class_7179.class_7181.field_37884),
				new class_7186(2.4583F, class_7187.method_41823(0.0F, 0.0F, -1.0F), class_7179.class_7181.field_37884),
				new class_7186(2.5417F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.875F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(3.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"head",
			new class_7179(
				class_7179.class_7183.field_37887,
				new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.1667F, class_7187.method_41829(-20.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2083F, class_7187.method_41829(-20.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.25F, class_7187.method_41829(-2.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2917F, class_7187.method_41829(-5.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.375F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.4167F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.5833F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.6667F, class_7187.method_41829(0.0F, -20.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.75F, class_7187.method_41829(0.0F, -20.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.8333F, class_7187.method_41829(0.0F, 10.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.0417F, class_7187.method_41829(0.0F, 10.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.1667F, class_7187.method_41829(0.0F, 10.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.2083F, class_7187.method_41829(0.0F, 27.5F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.2917F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.4167F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.4583F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.5F, class_7187.method_41829(0.0F, -2.5F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.625F, class_7187.method_41829(0.0F, -2.5F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.6667F, class_7187.method_41829(9.73588F, -1.93433F, -3.73384F), class_7179.class_7181.field_37884),
				new class_7186(1.7083F, class_7187.method_41829(9.73588F, -1.93433F, -3.73384F), class_7179.class_7181.field_37884),
				new class_7186(1.7917F, class_7187.method_41829(10.15255F, -1.93433F, -3.73384F), class_7179.class_7181.field_37884),
				new class_7186(1.8333F, class_7187.method_41829(17.86088F, -1.93433F, -3.73384F), class_7179.class_7181.field_37884),
				new class_7186(1.875F, class_7187.method_41829(17.23588F, -1.93433F, -3.73384F), class_7179.class_7181.field_37884),
				new class_7186(1.9167F, class_7187.method_41829(17.23588F, -1.93433F, -3.73384F), class_7179.class_7181.field_37884),
				new class_7186(2.0417F, class_7187.method_41829(17.23588F, -1.93433F, -3.73384F), class_7179.class_7181.field_37884),
				new class_7186(2.0833F, class_7187.method_41829(-0.26F, -1.93F, -3.73F), class_7179.class_7181.field_37884),
				new class_7186(2.1667F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.4583F, class_7187.method_41829(-10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.5417F, class_7187.method_41829(-15.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.6667F, class_7187.method_41829(-15.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.7083F, class_7187.method_41829(-5.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.875F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"head",
			new class_7179(
				class_7179.class_7183.field_37886,
				new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.1667F, class_7187.method_41823(0.0F, -0.15451F, 0.47553F), class_7179.class_7181.field_37884),
				new class_7186(0.25F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.4167F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.0417F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.1667F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.2917F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.4167F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.4583F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.5F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.625F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.6667F, class_7187.method_41823(-0.22438F, 0.82319F, -1.27252F), class_7179.class_7181.field_37884),
				new class_7186(1.875F, class_7187.method_41823(-0.22438F, 0.82319F, -1.27252F), class_7179.class_7181.field_37884),
				new class_7186(1.9167F, class_7187.method_41823(-0.22438F, 0.82319F, -1.27252F), class_7179.class_7181.field_37884),
				new class_7186(2.0417F, class_7187.method_41823(-0.22438F, 0.82319F, -1.27252F), class_7179.class_7181.field_37884),
				new class_7186(2.0833F, class_7187.method_41823(-0.39F, 0.52F, -2.21F), class_7179.class_7181.field_37884),
				new class_7186(2.1667F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.4583F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.6667F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.875F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(3.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"right_arm",
			new class_7179(
				class_7179.class_7183.field_37887,
				new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.1667F, class_7187.method_41829(-7.38733F, 1.29876F, 9.91615F), class_7179.class_7181.field_37884),
				new class_7186(0.2917F, class_7187.method_41829(-7.38733F, 1.29876F, 9.91615F), class_7179.class_7181.field_37884),
				new class_7186(0.375F, class_7187.method_41829(10.0F, 0.0F, 32.5F), class_7179.class_7181.field_37884),
				new class_7186(0.4167F, class_7187.method_41829(-34.55418F, 11.73507F, 36.8361F), class_7179.class_7181.field_37884),
				new class_7186(0.4583F, class_7187.method_41829(-117.82767F, 2.94538F, 0.22703F), class_7179.class_7181.field_37884),
				new class_7186(0.5417F, class_7187.method_41829(-97.7902F, 0.73403F, 1.39387F), class_7179.class_7181.field_37884),
				new class_7186(0.5833F, class_7187.method_41829(-92.79F, 0.73F, 1.39F), class_7179.class_7181.field_37884),
				new class_7186(0.75F, class_7187.method_41829(-92.79F, 0.73F, 1.39F), class_7179.class_7181.field_37884),
				new class_7186(0.8333F, class_7187.method_41829(-95.83405F, 33.18639F, -0.40081F), class_7179.class_7181.field_37884),
				new class_7186(1.5F, class_7187.method_41829(-95.83F, 33.19F, -0.4F), class_7179.class_7181.field_37884),
				new class_7186(1.5833F, class_7187.method_41829(-44.60123F, 10.14454F, 8.66307F), class_7179.class_7181.field_37884),
				new class_7186(1.8333F, class_7187.method_41829(-4.31506F, 6.54961F, 13.21388F), class_7179.class_7181.field_37884),
				new class_7186(2.0833F, class_7187.method_41829(-4.31506F, 6.54961F, 13.21388F), class_7179.class_7181.field_37884),
				new class_7186(2.125F, class_7187.method_41829(-4.31506F, 6.54961F, 13.21388F), class_7179.class_7181.field_37884),
				new class_7186(2.2083F, class_7187.method_41829(-113.7629F, 21.38835F, 15.48184F), class_7179.class_7181.field_37884),
				new class_7186(2.4583F, class_7187.method_41829(-113.76F, 21.39F, 15.48F), class_7179.class_7181.field_37884),
				new class_7186(2.5417F, class_7187.method_41829(-39.99304F, 7.3511F, 14.05666F), class_7179.class_7181.field_37884),
				new class_7186(2.625F, class_7187.method_41829(68.07913F, -3.61348F, 1.39182F), class_7179.class_7181.field_37884),
				new class_7186(2.6667F, class_7187.method_41829(193.16708F, -1.90441F, -0.43495F), class_7179.class_7181.field_37884),
				new class_7186(2.7083F, class_7187.method_41829(250.66708F, -1.90441F, -0.43495F), class_7179.class_7181.field_37884),
				new class_7186(2.7917F, class_7187.method_41829(264.19006F, -4.41519F, -0.66792F), class_7179.class_7181.field_37884),
				new class_7186(2.8333F, class_7187.method_41829(270.53693F, 16.03493F, 0.47968F), class_7179.class_7181.field_37884),
				new class_7186(2.875F, class_7187.method_41829(319.31668F, 17.97846F, 1.34328F), class_7179.class_7181.field_37884),
				new class_7186(2.9167F, class_7187.method_41829(0.0F, -5.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"right_arm",
			new class_7179(
				class_7179.class_7183.field_37886,
				new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2917F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.375F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.5833F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.75F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.8333F, class_7187.method_41823(0.25358F, -0.20153F, 2.21248F), class_7179.class_7181.field_37884),
				new class_7186(1.5F, class_7187.method_41823(0.25F, -0.2F, 2.21F), class_7179.class_7181.field_37884),
				new class_7186(1.5417F, class_7187.method_41823(-0.79739F, -0.10573F, 1.70592F), class_7179.class_7181.field_37884),
				new class_7186(1.5833F, class_7187.method_41823(-0.26323F, -1.46323F, 0.66566F), class_7179.class_7181.field_37884),
				new class_7186(1.8333F, class_7187.method_41823(-0.51052F, -0.38088F, 0.79745F), class_7179.class_7181.field_37884),
				new class_7186(2.0833F, class_7187.method_41823(-0.51052F, -0.38088F, 0.79745F), class_7179.class_7181.field_37884),
				new class_7186(2.125F, class_7187.method_41823(-0.51052F, -0.38088F, 0.79745F), class_7179.class_7181.field_37884),
				new class_7186(2.4583F, class_7187.method_41823(-0.51F, -0.38F, 0.8F), class_7179.class_7181.field_37884),
				new class_7186(2.875F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(3.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"left_arm",
			new class_7179(
				class_7179.class_7183.field_37887,
				new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2083F, class_7187.method_41829(25.0F, 0.0F, -37.5F), class_7179.class_7181.field_37884),
				new class_7186(0.25F, class_7187.method_41829(-21.59341F, -12.60837F, -45.69252F), class_7179.class_7181.field_37884),
				new class_7186(0.2917F, class_7187.method_41829(-120.7755F, -5.21988F, -2.02064F), class_7179.class_7181.field_37884),
				new class_7186(0.375F, class_7187.method_41829(-98.27419F, -1.79323F, -1.15048F), class_7179.class_7181.field_37884),
				new class_7186(0.4167F, class_7187.method_41829(-93.27F, -1.79F, -1.15F), class_7179.class_7181.field_37884),
				new class_7186(0.5417F, class_7187.method_41829(-93.27419F, -1.79323F, -1.15048F), class_7179.class_7181.field_37884),
				new class_7186(0.5833F, class_7187.method_41829(-93.55693F, -22.3224F, 3.64383F), class_7179.class_7181.field_37884),
				new class_7186(0.7083F, class_7187.method_41829(-93.55693F, -22.3224F, 3.64383F), class_7179.class_7181.field_37884),
				new class_7186(1.1667F, class_7187.method_41829(-93.55693F, -22.3224F, 3.64383F), class_7179.class_7181.field_37884),
				new class_7186(1.2083F, class_7187.method_41829(-95.75F, -2.42F, 5.97F), class_7179.class_7181.field_37884),
				new class_7186(1.25F, class_7187.method_41829(-98.4029F, -17.39503F, 6.85104F), class_7179.class_7181.field_37884),
				new class_7186(1.2917F, class_7187.method_41829(-101.24523F, -29.87096F, 7.69993F), class_7179.class_7181.field_37884),
				new class_7186(1.5833F, class_7187.method_41829(-101.25F, -29.87F, 7.7F), class_7179.class_7181.field_37884),
				new class_7186(1.6667F, class_7187.method_41829(-88.17772F, -42.09094F, 10.96195F), class_7179.class_7181.field_37884),
				new class_7186(1.8333F, class_7187.method_41829(-88.17772F, -42.09094F, 10.96195F), class_7179.class_7181.field_37884),
				new class_7186(2.0417F, class_7187.method_41829(-88.17772F, -42.09094F, 10.96195F), class_7179.class_7181.field_37884),
				new class_7186(2.25F, class_7187.method_41829(-88.17772F, -42.09094F, 10.96195F), class_7179.class_7181.field_37884),
				new class_7186(2.2917F, class_7187.method_41829(-88.17772F, -42.09094F, 10.96195F), class_7179.class_7181.field_37884),
				new class_7186(2.3333F, class_7187.method_41829(-88.58526F, -17.10045F, 11.7676F), class_7179.class_7181.field_37884),
				new class_7186(2.4583F, class_7187.method_41829(-88.59F, -17.1F, 11.77F), class_7179.class_7181.field_37884),
				new class_7186(2.5417F, class_7187.method_41829(-46.59531F, -16.13694F, -3.85578F), class_7179.class_7181.field_37884),
				new class_7186(2.875F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"left_arm",
			new class_7179(
				class_7179.class_7183.field_37886,
				new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2083F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.4167F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.2083F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.5833F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.6667F, class_7187.method_41823(-0.00677F, -0.76064F, 3.19059F), class_7179.class_7181.field_37884),
				new class_7186(2.4583F, class_7187.method_41823(0.0512F, -0.76176F, 3.12882F), class_7179.class_7181.field_37884),
				new class_7186(2.875F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(3.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"right_leg",
			new class_7179(
				class_7179.class_7183.field_37887,
				new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2083F, class_7187.method_41829(7.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.125F, class_7187.method_41829(7.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.1667F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.2917F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.375F, class_7187.method_41829(2.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.4583F, class_7187.method_41829(5.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.5417F, class_7187.method_41829(5.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.5833F, class_7187.method_41829(5.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.625F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.875F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"right_leg",
			new class_7179(
				class_7179.class_7183.field_37886,
				new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2083F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.125F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.1667F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.2917F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.375F, class_7187.method_41823(0.0F, 0.0909F, -0.10834F), class_7179.class_7181.field_37884),
				new class_7186(2.4583F, class_7187.method_41823(0.0F, 0.09F, -0.11F), class_7179.class_7181.field_37884),
				new class_7186(2.5417F, class_7187.method_41823(0.0F, 0.09F, -0.11F), class_7179.class_7181.field_37884),
				new class_7186(2.875F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(3.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"left_leg",
			new class_7179(
				class_7179.class_7183.field_37887,
				new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2083F, class_7187.method_41829(-10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.125F, class_7187.method_41829(-10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.1667F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.2917F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.375F, class_7187.method_41829(2.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.4583F, class_7187.method_41829(5.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.5417F, class_7187.method_41829(5.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.5833F, class_7187.method_41829(5.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.625F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"left_leg",
			new class_7179(
				class_7179.class_7183.field_37886,
				new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2083F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.125F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.1667F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.2917F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.375F, class_7187.method_41823(0.0F, 0.0909F, -0.10834F), class_7179.class_7181.field_37884),
				new class_7186(2.4583F, class_7187.method_41823(0.0F, 0.09F, -0.11F), class_7179.class_7181.field_37884),
				new class_7186(2.5417F, class_7187.method_41823(0.0F, 0.09F, -0.11F), class_7179.class_7181.field_37884),
				new class_7186(3.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41821();
	public static final class_7184 COPPER_GOLEM_CHEST_INTERACTION_ITEM_NODROP = class_7184.class_7185.method_41818(3.0F)
		.method_41817()
		.method_41820(
			"body",
			new class_7179(
				class_7179.class_7183.field_37887,
				new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.1667F, class_7187.method_41829(18.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2917F, class_7187.method_41829(24.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.375F, class_7187.method_41829(15.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.4167F, class_7187.method_41829(12.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.5833F, class_7187.method_41829(12.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.75F, class_7187.method_41829(12.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.8333F, class_7187.method_41829(14.72765F, -31.63886F, -7.85085F), class_7179.class_7181.field_37884),
				new class_7186(0.9167F, class_7187.method_41829(14.72765F, -31.63886F, -7.85085F), class_7179.class_7181.field_37884),
				new class_7186(1.0417F, class_7187.method_41829(14.72765F, -31.63886F, -7.85085F), class_7179.class_7181.field_37884),
				new class_7186(1.125F, class_7187.method_41829(12.40525F, -4.4E-4F, 0.00829F), class_7179.class_7181.field_37884),
				new class_7186(1.2083F, class_7187.method_41829(12.40525F, -4.4E-4F, 0.00829F), class_7179.class_7181.field_37884),
				new class_7186(1.2917F, class_7187.method_41829(13.92716F, 26.80536F, 6.38918F), class_7179.class_7181.field_37884),
				new class_7186(1.625F, class_7187.method_41829(13.93F, 26.81F, 6.39F), class_7179.class_7181.field_37884),
				new class_7186(1.6667F, class_7187.method_41829(21.43F, 26.81F, 6.39F), class_7179.class_7181.field_37884),
				new class_7186(1.7917F, class_7187.method_41829(21.43F, 26.81F, 6.39F), class_7179.class_7181.field_37884),
				new class_7186(1.8333F, class_7187.method_41829(13.93F, 26.81F, 6.39F), class_7179.class_7181.field_37884),
				new class_7186(2.0417F, class_7187.method_41829(13.93F, 26.81F, 6.39F), class_7179.class_7181.field_37884),
				new class_7186(2.1667F, class_7187.method_41829(12.40725F, 0.0F, 0.00783F), class_7179.class_7181.field_37884),
				new class_7186(2.25F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.3333F, class_7187.method_41829(-2.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.5F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.875F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"body",
			new class_7179(
				class_7179.class_7183.field_37886,
				new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2083F, class_7187.method_41823(0.0F, 0.6F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.4167F, class_7187.method_41823(0.0F, 0.5F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.625F, class_7187.method_41823(0.0F, 0.4F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.6667F, class_7187.method_41823(-0.01805F, 0.88303F, -0.09783F), class_7179.class_7181.field_37884),
				new class_7186(1.7917F, class_7187.method_41823(-0.01805F, 0.88303F, -0.09783F), class_7179.class_7181.field_37884),
				new class_7186(1.8333F, class_7187.method_41823(0.0F, 0.6F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.0417F, class_7187.method_41823(0.0F, 0.6F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.25F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.3333F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.5F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.875F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(3.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"head",
			new class_7179(
				class_7179.class_7183.field_37887,
				new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.1667F, class_7187.method_41829(-20.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2083F, class_7187.method_41829(-20.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.25F, class_7187.method_41829(-2.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2917F, class_7187.method_41829(-5.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.375F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.4167F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.5833F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.6667F, class_7187.method_41829(0.0F, -20.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.75F, class_7187.method_41829(0.0F, -20.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.8333F, class_7187.method_41829(0.0F, 10.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.0417F, class_7187.method_41829(0.0F, 10.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.1667F, class_7187.method_41829(0.0F, 10.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.2083F, class_7187.method_41829(0.0F, 27.5F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.2917F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.4167F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.4583F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.5F, class_7187.method_41829(0.0F, -2.5F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.625F, class_7187.method_41829(0.0F, -2.5F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.6667F, class_7187.method_41829(9.73588F, -1.93433F, -3.73384F), class_7179.class_7181.field_37884),
				new class_7186(1.7083F, class_7187.method_41829(9.73588F, -1.93433F, -3.73384F), class_7179.class_7181.field_37884),
				new class_7186(1.7917F, class_7187.method_41829(10.15255F, -1.93433F, -3.73384F), class_7179.class_7181.field_37884),
				new class_7186(1.8333F, class_7187.method_41829(17.86088F, -1.93433F, -3.73384F), class_7179.class_7181.field_37884),
				new class_7186(1.875F, class_7187.method_41829(17.23588F, -1.93433F, -3.73384F), class_7179.class_7181.field_37884),
				new class_7186(1.9167F, class_7187.method_41829(17.23588F, -1.93433F, -3.73384F), class_7179.class_7181.field_37884),
				new class_7186(2.0417F, class_7187.method_41829(17.23588F, -1.93433F, -3.73384F), class_7179.class_7181.field_37884),
				new class_7186(2.0833F, class_7187.method_41829(-0.26F, -1.93F, -3.73F), class_7179.class_7181.field_37884),
				new class_7186(2.25F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.2917F, class_7187.method_41829(1.25F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.3333F, class_7187.method_41829(2.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.6667F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.9583F, class_7187.method_41829(0.0F, -360.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"head",
			new class_7179(
				class_7179.class_7183.field_37886,
				new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.1667F, class_7187.method_41823(0.0F, -0.15451F, 0.47553F), class_7179.class_7181.field_37884),
				new class_7186(0.25F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.4167F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.0417F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.1667F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.2917F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.4167F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.4583F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.5F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.625F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.6667F, class_7187.method_41823(-0.22438F, 0.82319F, -1.27252F), class_7179.class_7181.field_37884),
				new class_7186(1.875F, class_7187.method_41823(-0.22438F, 0.82319F, -1.27252F), class_7179.class_7181.field_37884),
				new class_7186(1.9167F, class_7187.method_41823(-0.22438F, 0.82319F, -1.27252F), class_7179.class_7181.field_37884),
				new class_7186(2.0417F, class_7187.method_41823(-0.22438F, 0.82319F, -1.27252F), class_7179.class_7181.field_37884),
				new class_7186(2.0833F, class_7187.method_41823(-0.39F, 0.52F, -2.21F), class_7179.class_7181.field_37884),
				new class_7186(2.25F, class_7187.method_41823(0.0F, 0.0F, 0.5F), class_7179.class_7181.field_37884),
				new class_7186(2.2917F, class_7187.method_41823(0.0F, -0.01091F, -0.02988F), class_7179.class_7181.field_37884),
				new class_7186(2.3333F, class_7187.method_41823(0.0F, -0.01F, -0.03F), class_7179.class_7181.field_37884),
				new class_7186(2.6667F, class_7187.method_41823(0.0F, -0.01F, -0.03F), class_7179.class_7181.field_37884),
				new class_7186(2.9583F, class_7187.method_41823(0.0F, -0.01F, -0.03F), class_7179.class_7181.field_37884),
				new class_7186(3.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"right_arm",
			new class_7179(
				class_7179.class_7183.field_37887,
				new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.1667F, class_7187.method_41829(-7.38733F, 1.29876F, 9.91615F), class_7179.class_7181.field_37884),
				new class_7186(0.2917F, class_7187.method_41829(-7.38733F, 1.29876F, 9.91615F), class_7179.class_7181.field_37884),
				new class_7186(0.375F, class_7187.method_41829(10.0F, 0.0F, 32.5F), class_7179.class_7181.field_37884),
				new class_7186(0.4167F, class_7187.method_41829(-34.55418F, 11.73507F, 36.8361F), class_7179.class_7181.field_37884),
				new class_7186(0.4583F, class_7187.method_41829(-117.82767F, 2.94538F, 0.22703F), class_7179.class_7181.field_37884),
				new class_7186(0.5417F, class_7187.method_41829(-97.7902F, 0.73403F, 1.39387F), class_7179.class_7181.field_37884),
				new class_7186(0.5833F, class_7187.method_41829(-92.79F, 0.73F, 1.39F), class_7179.class_7181.field_37884),
				new class_7186(0.75F, class_7187.method_41829(-92.79F, 0.73F, 1.39F), class_7179.class_7181.field_37884),
				new class_7186(0.8333F, class_7187.method_41829(-95.83405F, 33.18639F, -0.40081F), class_7179.class_7181.field_37884),
				new class_7186(1.5F, class_7187.method_41829(-95.83F, 33.19F, -0.4F), class_7179.class_7181.field_37884),
				new class_7186(1.5833F, class_7187.method_41829(-44.60123F, 10.14454F, 8.66307F), class_7179.class_7181.field_37884),
				new class_7186(1.8333F, class_7187.method_41829(-4.31506F, 6.54961F, 13.21388F), class_7179.class_7181.field_37884),
				new class_7186(2.0833F, class_7187.method_41829(-4.31506F, 6.54961F, 13.21388F), class_7179.class_7181.field_37884),
				new class_7186(2.1667F, class_7187.method_41829(-4.31506F, 6.54961F, 13.21388F), class_7179.class_7181.field_37884),
				new class_7186(2.25F, class_7187.method_41829(-6.53898F, 13.96898F, 14.34786F), class_7179.class_7181.field_37884),
				new class_7186(2.3333F, class_7187.method_41829(3.50393F, -4.70737F, 8.3608F), class_7179.class_7181.field_37884),
				new class_7186(2.4583F, class_7187.method_41829(3.50393F, -4.70737F, 8.3608F), class_7179.class_7181.field_37884),
				new class_7186(2.5F, class_7187.method_41829(3.90089F, -4.3843F, 3.35549F), class_7179.class_7181.field_37884),
				new class_7186(2.5417F, class_7187.method_41829(3.9F, -4.38F, 3.36F), class_7179.class_7181.field_37884),
				new class_7186(2.9167F, class_7187.method_41829(3.9F, -4.38F, 3.36F), class_7179.class_7181.field_37884),
				new class_7186(2.9583F, class_7187.method_41829(3.90089F, -4.3843F, 3.35549F), class_7179.class_7181.field_37884),
				new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"right_arm",
			new class_7179(
				class_7179.class_7183.field_37886,
				new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2917F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.375F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.5833F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.75F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.8333F, class_7187.method_41823(0.25358F, -0.20153F, 2.21248F), class_7179.class_7181.field_37884),
				new class_7186(1.5F, class_7187.method_41823(0.25F, -0.2F, 2.21F), class_7179.class_7181.field_37884),
				new class_7186(1.5417F, class_7187.method_41823(-0.79739F, -0.10573F, 1.70592F), class_7179.class_7181.field_37884),
				new class_7186(1.5833F, class_7187.method_41823(-0.26323F, -1.46323F, 0.66566F), class_7179.class_7181.field_37884),
				new class_7186(1.8333F, class_7187.method_41823(-0.51052F, -0.38088F, 0.79745F), class_7179.class_7181.field_37884),
				new class_7186(2.0833F, class_7187.method_41823(-0.51052F, -0.38088F, 0.79745F), class_7179.class_7181.field_37884),
				new class_7186(2.1667F, class_7187.method_41823(-0.51052F, -0.38088F, 0.79745F), class_7179.class_7181.field_37884),
				new class_7186(2.25F, class_7187.method_41823(-0.46F, -0.34F, 0.72F), class_7179.class_7181.field_37884),
				new class_7186(2.3333F, class_7187.method_41823(-0.46F, 0.1159F, -0.30086F), class_7179.class_7181.field_37884),
				new class_7186(2.4583F, class_7187.method_41823(-0.46F, 0.1159F, -0.30086F), class_7179.class_7181.field_37884),
				new class_7186(2.5F, class_7187.method_41823(-0.46F, 0.1159F, -0.30086F), class_7179.class_7181.field_37884),
				new class_7186(2.5417F, class_7187.method_41823(-0.46F, -0.88F, -0.3F), class_7179.class_7181.field_37884),
				new class_7186(2.9167F, class_7187.method_41823(-0.46F, -0.88F, -0.3F), class_7179.class_7181.field_37884),
				new class_7186(2.9583F, class_7187.method_41823(-0.46F, 0.1159F, -0.30086F), class_7179.class_7181.field_37884),
				new class_7186(3.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"left_arm",
			new class_7179(
				class_7179.class_7183.field_37887,
				new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2083F, class_7187.method_41829(25.0F, 0.0F, -37.5F), class_7179.class_7181.field_37884),
				new class_7186(0.25F, class_7187.method_41829(-21.59341F, -12.60837F, -45.69252F), class_7179.class_7181.field_37884),
				new class_7186(0.2917F, class_7187.method_41829(-120.7755F, -5.21988F, -2.02064F), class_7179.class_7181.field_37884),
				new class_7186(0.375F, class_7187.method_41829(-98.27419F, -1.79323F, -1.15048F), class_7179.class_7181.field_37884),
				new class_7186(0.4167F, class_7187.method_41829(-93.27F, -1.79F, -1.15F), class_7179.class_7181.field_37884),
				new class_7186(0.5417F, class_7187.method_41829(-93.27419F, -1.79323F, -1.15048F), class_7179.class_7181.field_37884),
				new class_7186(0.5833F, class_7187.method_41829(-93.55693F, -22.3224F, 3.64383F), class_7179.class_7181.field_37884),
				new class_7186(0.7083F, class_7187.method_41829(-93.55693F, -22.3224F, 3.64383F), class_7179.class_7181.field_37884),
				new class_7186(1.1667F, class_7187.method_41829(-93.55693F, -22.3224F, 3.64383F), class_7179.class_7181.field_37884),
				new class_7186(1.2083F, class_7187.method_41829(-95.75F, -2.42F, 5.97F), class_7179.class_7181.field_37884),
				new class_7186(1.25F, class_7187.method_41829(-98.4029F, -17.39503F, 6.85104F), class_7179.class_7181.field_37884),
				new class_7186(1.2917F, class_7187.method_41829(-101.24523F, -29.87096F, 7.69993F), class_7179.class_7181.field_37884),
				new class_7186(1.5833F, class_7187.method_41829(-101.25F, -29.87F, 7.7F), class_7179.class_7181.field_37884),
				new class_7186(1.6667F, class_7187.method_41829(-88.17772F, -42.09094F, 10.96195F), class_7179.class_7181.field_37884),
				new class_7186(1.8333F, class_7187.method_41829(-88.17772F, -42.09094F, 10.96195F), class_7179.class_7181.field_37884),
				new class_7186(2.0417F, class_7187.method_41829(-88.17772F, -42.09094F, 10.96195F), class_7179.class_7181.field_37884),
				new class_7186(2.25F, class_7187.method_41829(0.0F, 0.0F, -20.0F), class_7179.class_7181.field_37884),
				new class_7186(2.3333F, class_7187.method_41829(2.47864F, -0.32621F, -12.50706F), class_7179.class_7181.field_37884),
				new class_7186(2.4583F, class_7187.method_41829(2.47864F, -0.32621F, -12.50706F), class_7179.class_7181.field_37884),
				new class_7186(2.5F, class_7187.method_41829(2.41492F, -0.64686F, -5.01363F), class_7179.class_7181.field_37884),
				new class_7186(2.5417F, class_7187.method_41829(2.41F, -0.65F, -5.01F), class_7179.class_7181.field_37884),
				new class_7186(2.9167F, class_7187.method_41829(2.41F, -0.65F, -5.01F), class_7179.class_7181.field_37884),
				new class_7186(2.9583F, class_7187.method_41829(2.41492F, -0.64686F, -5.01363F), class_7179.class_7181.field_37884),
				new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"left_arm",
			new class_7179(
				class_7179.class_7183.field_37886,
				new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2083F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.4167F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.2083F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.5833F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.6667F, class_7187.method_41823(-0.00677F, -0.76064F, 3.19059F), class_7179.class_7181.field_37884),
				new class_7186(1.8333F, class_7187.method_41823(-0.00677F, -0.76064F, 3.19059F), class_7179.class_7181.field_37884),
				new class_7186(2.0417F, class_7187.method_41823(-0.00677F, -0.76064F, 3.19059F), class_7179.class_7181.field_37884),
				new class_7186(2.25F, class_7187.method_41823(0.03F, -0.76F, 0.45F), class_7179.class_7181.field_37884),
				new class_7186(2.3333F, class_7187.method_41823(0.03F, -0.28229F, -0.07133F), class_7179.class_7181.field_37884),
				new class_7186(2.4583F, class_7187.method_41823(0.03F, -0.28229F, -0.07133F), class_7179.class_7181.field_37884),
				new class_7186(2.5F, class_7187.method_41823(0.03F, -0.28229F, -0.07133F), class_7179.class_7181.field_37884),
				new class_7186(2.5417F, class_7187.method_41823(0.03F, -1.28F, -0.07F), class_7179.class_7181.field_37884),
				new class_7186(2.9167F, class_7187.method_41823(0.03F, -1.28F, -0.07F), class_7179.class_7181.field_37884),
				new class_7186(2.9583F, class_7187.method_41823(0.03F, -0.28229F, -0.07133F), class_7179.class_7181.field_37884),
				new class_7186(3.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"right_leg",
			new class_7179(
				class_7179.class_7183.field_37887,
				new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2083F, class_7187.method_41829(7.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.1667F, class_7187.method_41829(7.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.25F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.3333F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.5F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.875F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"right_leg",
			new class_7179(
				class_7179.class_7183.field_37886,
				new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2083F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.1667F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.25F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.3333F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.5F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.875F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(3.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"left_leg",
			new class_7179(
				class_7179.class_7183.field_37887,
				new class_7186(0.125F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2083F, class_7187.method_41829(-10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.1667F, class_7187.method_41829(-10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.25F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"left_leg",
			new class_7179(
				class_7179.class_7183.field_37886,
				new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2083F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.1667F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.25F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(3.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"left_leg",
			new class_7179(
				class_7179.class_7183.field_37888,
				new class_7186(0.0F, class_7187.method_41822(1.0, 1.0, 1.0), class_7179.class_7181.field_37884),
				new class_7186(3.0F, class_7187.method_41822(1.0, 1.0, 1.0), class_7179.class_7181.field_37884)
			)
		)
		.method_41821();
	public static final class_7184 COPPER_GOLEM_CHEST_INTERACTION_NOITEM_GET = class_7184.class_7185.method_41818(3.0F)
		.method_41817()
		.method_41820(
			"body",
			new class_7179(
				class_7179.class_7183.field_37887,
				new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.1667F, class_7187.method_41829(18.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2917F, class_7187.method_41829(24.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.375F, class_7187.method_41829(15.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.4167F, class_7187.method_41829(12.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.5833F, class_7187.method_41829(12.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.75F, class_7187.method_41829(12.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.8333F, class_7187.method_41829(14.72765F, -31.63886F, -7.85085F), class_7179.class_7181.field_37884),
				new class_7186(0.9167F, class_7187.method_41829(14.72765F, -31.63886F, -7.85085F), class_7179.class_7181.field_37884),
				new class_7186(1.0417F, class_7187.method_41829(14.72765F, -31.63886F, -7.85085F), class_7179.class_7181.field_37884),
				new class_7186(1.125F, class_7187.method_41829(12.40525F, -4.4E-4F, 0.00829F), class_7179.class_7181.field_37884),
				new class_7186(1.2083F, class_7187.method_41829(12.40525F, -4.4E-4F, 0.00829F), class_7179.class_7181.field_37884),
				new class_7186(1.2917F, class_7187.method_41829(13.92716F, 26.80536F, 6.38918F), class_7179.class_7181.field_37884),
				new class_7186(1.625F, class_7187.method_41829(13.93F, 26.81F, 6.39F), class_7179.class_7181.field_37884),
				new class_7186(1.6667F, class_7187.method_41829(21.43F, 26.81F, 6.39F), class_7179.class_7181.field_37884),
				new class_7186(1.7917F, class_7187.method_41829(21.43F, 26.81F, 6.39F), class_7179.class_7181.field_37884),
				new class_7186(1.8333F, class_7187.method_41829(13.93F, 26.81F, 6.39F), class_7179.class_7181.field_37884),
				new class_7186(2.0417F, class_7187.method_41829(13.93F, 26.81F, 6.39F), class_7179.class_7181.field_37884),
				new class_7186(2.125F, class_7187.method_41829(12.40725F, 0.0F, 0.00783F), class_7179.class_7181.field_37884),
				new class_7186(2.1667F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.25F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.2917F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.375F, class_7187.method_41829(15.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.4167F, class_7187.method_41829(17.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.4583F, class_7187.method_41829(22.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.625F, class_7187.method_41829(24.14867F, -20.70481F, -9.00717F), class_7179.class_7181.field_37884),
				new class_7186(2.7083F, class_7187.method_41829(24.14867F, -20.70481F, -9.00717F), class_7179.class_7181.field_37884),
				new class_7186(2.75F, class_7187.method_41829(22.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.7917F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.9583F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"body",
			new class_7179(
				class_7179.class_7183.field_37886,
				new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2083F, class_7187.method_41823(0.0F, 0.6F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.4167F, class_7187.method_41823(0.0F, 0.5F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.625F, class_7187.method_41823(0.0F, 0.4F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.6667F, class_7187.method_41823(-0.01805F, 0.88303F, -0.09783F), class_7179.class_7181.field_37884),
				new class_7186(1.7917F, class_7187.method_41823(-0.01805F, 0.88303F, -0.09783F), class_7179.class_7181.field_37884),
				new class_7186(1.8333F, class_7187.method_41823(0.0F, 0.6F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.0417F, class_7187.method_41823(0.0F, 0.6F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.1667F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.25F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.2917F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.625F, class_7187.method_41823(0.0F, 0.46194F, -0.19134F), class_7179.class_7181.field_37884),
				new class_7186(2.7083F, class_7187.method_41823(0.0F, 0.46194F, -0.19134F), class_7179.class_7181.field_37884),
				new class_7186(2.7917F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.9583F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"head",
			new class_7179(
				class_7179.class_7183.field_37887,
				new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.1667F, class_7187.method_41829(-20.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2083F, class_7187.method_41829(-20.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.25F, class_7187.method_41829(-2.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2917F, class_7187.method_41829(-5.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.375F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.4167F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.5833F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.6667F, class_7187.method_41829(0.0F, -20.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.75F, class_7187.method_41829(0.0F, -20.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.8333F, class_7187.method_41829(0.0F, 10.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.0417F, class_7187.method_41829(0.0F, 10.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.1667F, class_7187.method_41829(0.0F, 10.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.2083F, class_7187.method_41829(0.0F, 27.5F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.2917F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.4167F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.4583F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.5833F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.625F, class_7187.method_41829(0.0F, -2.5F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.6667F, class_7187.method_41829(10.16381F, -16.71134F, -6.35306F), class_7179.class_7181.field_37884),
				new class_7186(1.8333F, class_7187.method_41829(10.16381F, -16.71134F, -6.35306F), class_7179.class_7181.field_37884),
				new class_7186(1.9167F, class_7187.method_41829(10.16381F, -16.71134F, -6.35306F), class_7179.class_7181.field_37884),
				new class_7186(1.9583F, class_7187.method_41829(10.16381F, -16.71134F, -6.35306F), class_7179.class_7181.field_37884),
				new class_7186(2.0F, class_7187.method_41829(5.16381F, -16.71134F, -6.35306F), class_7179.class_7181.field_37884),
				new class_7186(2.0417F, class_7187.method_41829(0.16381F, -16.71134F, -6.35306F), class_7179.class_7181.field_37884),
				new class_7186(2.0833F, class_7187.method_41829(0.15732F, -4.21139F, -6.31751F), class_7179.class_7181.field_37884),
				new class_7186(2.125F, class_7187.method_41829(0.07901F, 5.3943F, -3.15187F), class_7179.class_7181.field_37884),
				new class_7186(2.1667F, class_7187.method_41829(0.0F, 7.5F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.2917F, class_7187.method_41829(4.53867F, 7.47675F, 0.59181F), class_7179.class_7181.field_37884),
				new class_7186(2.3333F, class_7187.method_41829(-2.53852F, 9.99038F, -0.44067F), class_7179.class_7181.field_37884),
				new class_7186(2.4167F, class_7187.method_41829(-12.68664F, 9.76061F, -2.18558F), class_7179.class_7181.field_37884),
				new class_7186(2.625F, class_7187.method_41829(-15.19938F, 22.36971F, -3.52259F), class_7179.class_7181.field_37884),
				new class_7186(2.6667F, class_7187.method_41829(-3.02173F, 22.37156F, -2.41802F), class_7179.class_7181.field_37884),
				new class_7186(2.7083F, class_7187.method_41829(-0.52173F, 22.37156F, -2.41802F), class_7179.class_7181.field_37884),
				new class_7186(2.75F, class_7187.method_41829(-12.40598F, -0.4674F, -1.79838F), class_7179.class_7181.field_37884),
				new class_7186(2.8333F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.9583F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"head",
			new class_7179(
				class_7179.class_7183.field_37886,
				new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.1667F, class_7187.method_41823(0.0F, -0.15451F, 0.47553F), class_7179.class_7181.field_37884),
				new class_7186(0.25F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.4167F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.0417F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.1667F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.2917F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.4167F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.4583F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.5F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.5833F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.625F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.6667F, class_7187.method_41823(-0.22438F, 0.82319F, -1.27252F), class_7179.class_7181.field_37884),
				new class_7186(1.8333F, class_7187.method_41823(-0.22438F, 0.82319F, -1.27252F), class_7179.class_7181.field_37884),
				new class_7186(1.9167F, class_7187.method_41823(-0.22438F, 0.82319F, -1.27252F), class_7179.class_7181.field_37884),
				new class_7186(1.9583F, class_7187.method_41823(-0.52521F, 0.96725F, -0.32978F), class_7179.class_7181.field_37884),
				new class_7186(2.0F, class_7187.method_41823(-0.52521F, 0.96725F, -0.32978F), class_7179.class_7181.field_37884),
				new class_7186(2.0417F, class_7187.method_41823(-0.5345F, 1.16541F, -0.37206F), class_7179.class_7181.field_37884),
				new class_7186(2.0833F, class_7187.method_41823(-0.5345F, 1.16541F, -0.37206F), class_7179.class_7181.field_37884),
				new class_7186(2.1667F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.3333F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.625F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.8333F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.9583F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"right_arm",
			new class_7179(
				class_7179.class_7183.field_37887,
				new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.1667F, class_7187.method_41829(-7.38733F, 1.29876F, 9.91615F), class_7179.class_7181.field_37884),
				new class_7186(0.2917F, class_7187.method_41829(-7.38733F, 1.29876F, 9.91615F), class_7179.class_7181.field_37884),
				new class_7186(0.375F, class_7187.method_41829(10.0F, 0.0F, 32.5F), class_7179.class_7181.field_37884),
				new class_7186(0.4167F, class_7187.method_41829(-34.55418F, 11.73507F, 36.8361F), class_7179.class_7181.field_37884),
				new class_7186(0.4583F, class_7187.method_41829(-82.47403F, 17.82361F, 2.17224F), class_7179.class_7181.field_37884),
				new class_7186(0.5F, class_7187.method_41829(-85.08388F, 14.26971F, 1.99595F), class_7179.class_7181.field_37884),
				new class_7186(0.5417F, class_7187.method_41829(-85.16266F, 13.19102F, 2.43976F), class_7179.class_7181.field_37884),
				new class_7186(0.5833F, class_7187.method_41829(-92.79F, 0.73F, 1.39F), class_7179.class_7181.field_37884),
				new class_7186(0.75F, class_7187.method_41829(-92.79F, 0.73F, 1.39F), class_7179.class_7181.field_37884),
				new class_7186(0.8333F, class_7187.method_41829(-95.83405F, 33.18639F, -0.40081F), class_7179.class_7181.field_37884),
				new class_7186(1.25F, class_7187.method_41829(-95.83F, 33.19F, -0.4F), class_7179.class_7181.field_37884),
				new class_7186(1.2917F, class_7187.method_41829(-98.33F, 33.19F, -0.4F), class_7179.class_7181.field_37884),
				new class_7186(1.5417F, class_7187.method_41829(-56.46674F, 3.3853F, 14.45894F), class_7179.class_7181.field_37884),
				new class_7186(1.6667F, class_7187.method_41829(-56.46674F, 3.3853F, 14.45894F), class_7179.class_7181.field_37884),
				new class_7186(1.8333F, class_7187.method_41829(-56.46674F, 3.3853F, 14.45894F), class_7179.class_7181.field_37884),
				new class_7186(2.0F, class_7187.method_41829(-56.46674F, 3.3853F, 14.45894F), class_7179.class_7181.field_37884),
				new class_7186(2.0417F, class_7187.method_41829(-56.46674F, 3.3853F, 14.45894F), class_7179.class_7181.field_37884),
				new class_7186(2.1667F, class_7187.method_41829(-84.12204F, 8.95753F, 14.11779F), class_7179.class_7181.field_37884),
				new class_7186(2.2083F, class_7187.method_41829(-84.12204F, 8.95753F, 14.11779F), class_7179.class_7181.field_37884),
				new class_7186(2.25F, class_7187.method_41829(-93.6065F, 13.90544F, 15.98524F), class_7179.class_7181.field_37884),
				new class_7186(2.3333F, class_7187.method_41829(-124.48661F, 66.29146F, -7.28605F), class_7179.class_7181.field_37884),
				new class_7186(2.375F, class_7187.method_41829(-129.4866F, 66.29146F, -7.28605F), class_7179.class_7181.field_37884),
				new class_7186(2.4167F, class_7187.method_41829(-108.91607F, 1.79762F, 20.93924F), class_7179.class_7181.field_37884),
				new class_7186(2.5F, class_7187.method_41829(-102.18303F, 4.35881F, 17.40962F), class_7179.class_7181.field_37884),
				new class_7186(2.5417F, class_7187.method_41829(-98.33642F, -0.70114F, 4.09322F), class_7179.class_7181.field_37884),
				new class_7186(2.625F, class_7187.method_41829(-98.39385F, 6.71929F, 3.00137F), class_7179.class_7181.field_37884),
				new class_7186(2.6667F, class_7187.method_41829(-98.33981F, 1.77244F, 3.7307F), class_7179.class_7181.field_37884),
				new class_7186(2.7083F, class_7187.method_41829(-100.70987F, 3.48829F, 7.1138F), class_7179.class_7181.field_37884),
				new class_7186(2.75F, class_7187.method_41829(-97.95F, 6.92F, 13.88F), class_7179.class_7181.field_37884),
				new class_7186(2.7917F, class_7187.method_41829(-87.95F, 6.92F, 13.88F), class_7179.class_7181.field_37884),
				new class_7186(2.8333F, class_7187.method_41829(-97.95F, 6.92F, 13.88F), class_7179.class_7181.field_37884),
				new class_7186(2.875F, class_7187.method_41829(-102.95F, 6.92F, 13.88F), class_7179.class_7181.field_37884),
				new class_7186(2.9167F, class_7187.method_41829(-76.475F, 3.46F, 6.94F), class_7179.class_7181.field_37884),
				new class_7186(2.9583F, class_7187.method_41829(-26.475F, 3.46F, 6.94F), class_7179.class_7181.field_37884),
				new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"right_arm",
			new class_7179(
				class_7179.class_7183.field_37886,
				new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2917F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.375F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.5833F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.75F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.8333F, class_7187.method_41823(0.25358F, -0.20153F, 2.21248F), class_7179.class_7181.field_37884),
				new class_7186(1.25F, class_7187.method_41823(0.25F, -0.2F, 2.21F), class_7179.class_7181.field_37884),
				new class_7186(1.2917F, class_7187.method_41823(0.25F, -0.2F, 2.21F), class_7179.class_7181.field_37884),
				new class_7186(1.5417F, class_7187.method_41823(-0.26323F, -1.46323F, 0.66566F), class_7179.class_7181.field_37884),
				new class_7186(1.6667F, class_7187.method_41823(-0.26323F, -1.46323F, 0.66566F), class_7179.class_7181.field_37884),
				new class_7186(1.8333F, class_7187.method_41823(-0.26323F, -1.46323F, 0.66566F), class_7179.class_7181.field_37884),
				new class_7186(2.0F, class_7187.method_41823(-0.26323F, -1.46323F, 0.66566F), class_7179.class_7181.field_37884),
				new class_7186(2.0417F, class_7187.method_41823(-0.26323F, -1.46323F, 0.66566F), class_7179.class_7181.field_37884),
				new class_7186(2.25F, class_7187.method_41823(-0.51F, -0.38F, 0.8F), class_7179.class_7181.field_37884),
				new class_7186(2.3333F, class_7187.method_41823(-0.51F, -0.38F, 0.8F), class_7179.class_7181.field_37884),
				new class_7186(2.375F, class_7187.method_41823(-0.51F, -0.38F, 0.8F), class_7179.class_7181.field_37884),
				new class_7186(2.4167F, class_7187.method_41823(-2.14094F, 0.69619F, 1.23422F), class_7179.class_7181.field_37884),
				new class_7186(2.4583F, class_7187.method_41823(-0.97932F, 0.38244F, 0.12884F), class_7179.class_7181.field_37884),
				new class_7186(2.5417F, class_7187.method_41823(-1.55232F, 1.79904F, 0.37956F), class_7179.class_7181.field_37884),
				new class_7186(2.625F, class_7187.method_41823(-1.53125F, 1.64598F, 1.41168F), class_7179.class_7181.field_37884),
				new class_7186(2.6667F, class_7187.method_41823(-1.57256F, 1.05375F, 1.32469F), class_7179.class_7181.field_37884),
				new class_7186(2.75F, class_7187.method_41823(-1.33F, 0.16F, 1.02F), class_7179.class_7181.field_37884),
				new class_7186(2.7917F, class_7187.method_41823(-1.33F, 0.16F, 1.02F), class_7179.class_7181.field_37884),
				new class_7186(2.8333F, class_7187.method_41823(-1.33F, 0.16F, 1.02F), class_7179.class_7181.field_37884),
				new class_7186(2.875F, class_7187.method_41823(-1.33F, 0.16F, 1.02F), class_7179.class_7181.field_37884),
				new class_7186(2.9167F, class_7187.method_41823(-0.5748F, 0.38848F, 1.45646F), class_7179.class_7181.field_37884),
				new class_7186(2.9583F, class_7187.method_41823(-0.67F, 0.08F, 0.51F), class_7179.class_7181.field_37884),
				new class_7186(3.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"left_arm",
			new class_7179(
				class_7179.class_7183.field_37887,
				new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2083F, class_7187.method_41829(25.0F, 0.0F, -37.5F), class_7179.class_7181.field_37884),
				new class_7186(0.25F, class_7187.method_41829(-21.59341F, -12.60837F, -45.69252F), class_7179.class_7181.field_37884),
				new class_7186(0.2917F, class_7187.method_41829(-120.7755F, -5.21988F, -2.02064F), class_7179.class_7181.field_37884),
				new class_7186(0.375F, class_7187.method_41829(-98.27419F, -1.79323F, -1.15048F), class_7179.class_7181.field_37884),
				new class_7186(0.4167F, class_7187.method_41829(-93.27F, -1.79F, -1.15F), class_7179.class_7181.field_37884),
				new class_7186(0.5417F, class_7187.method_41829(-93.27419F, -1.79323F, -1.15048F), class_7179.class_7181.field_37884),
				new class_7186(0.5833F, class_7187.method_41829(-93.55693F, -22.3224F, 3.64383F), class_7179.class_7181.field_37884),
				new class_7186(0.7083F, class_7187.method_41829(-93.55693F, -22.3224F, 3.64383F), class_7179.class_7181.field_37884),
				new class_7186(1.1667F, class_7187.method_41829(-93.55693F, -22.3224F, 3.64383F), class_7179.class_7181.field_37884),
				new class_7186(1.2083F, class_7187.method_41829(-95.75F, -2.42F, 5.97F), class_7179.class_7181.field_37884),
				new class_7186(1.25F, class_7187.method_41829(-98.4029F, -17.39503F, 6.85104F), class_7179.class_7181.field_37884),
				new class_7186(1.2917F, class_7187.method_41829(-101.24523F, -29.87096F, 7.69993F), class_7179.class_7181.field_37884),
				new class_7186(1.5833F, class_7187.method_41829(-101.25F, -29.87F, 7.7F), class_7179.class_7181.field_37884),
				new class_7186(1.6667F, class_7187.method_41829(-88.17772F, -42.09094F, 10.96195F), class_7179.class_7181.field_37884),
				new class_7186(1.8333F, class_7187.method_41829(-88.17772F, -42.09094F, 10.96195F), class_7179.class_7181.field_37884),
				new class_7186(1.9583F, class_7187.method_41829(-88.17772F, -42.09094F, 10.96195F), class_7179.class_7181.field_37884),
				new class_7186(2.1667F, class_7187.method_41829(-88.17772F, -42.09094F, 10.96195F), class_7179.class_7181.field_37884),
				new class_7186(2.2083F, class_7187.method_41829(-88.58526F, -17.10045F, 11.7676F), class_7179.class_7181.field_37884),
				new class_7186(2.3333F, class_7187.method_41829(-88.59F, -17.1F, 11.77F), class_7179.class_7181.field_37884),
				new class_7186(2.4167F, class_7187.method_41829(-46.59531F, -16.13694F, -3.85578F), class_7179.class_7181.field_37884),
				new class_7186(2.5F, class_7187.method_41829(-24.5317F, -19.0214F, -13.70805F), class_7179.class_7181.field_37884),
				new class_7186(2.8333F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.9583F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"left_arm",
			new class_7179(
				class_7179.class_7183.field_37886,
				new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2083F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.4167F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.2083F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.5833F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.6667F, class_7187.method_41823(-0.00677F, -0.76064F, 3.19059F), class_7179.class_7181.field_37884),
				new class_7186(2.3333F, class_7187.method_41823(0.0512F, -0.76176F, 3.12882F), class_7179.class_7181.field_37884),
				new class_7186(2.8333F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.9583F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"right_leg",
			new class_7179(
				class_7179.class_7183.field_37887,
				new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2083F, class_7187.method_41829(7.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.2917F, class_7187.method_41829(7.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.7083F, class_7187.method_41829(7.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.7917F, class_7187.method_41829(5.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.8333F, class_7187.method_41829(5.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.875F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.9583F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"right_leg",
			new class_7179(
				class_7179.class_7183.field_37886,
				new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2083F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.2917F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.7083F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.7917F, class_7187.method_41823(0.0F, 0.09F, -0.11F), class_7179.class_7181.field_37884),
				new class_7186(2.8333F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.9583F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"left_leg",
			new class_7179(
				class_7179.class_7183.field_37887,
				new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2083F, class_7187.method_41829(-10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.0417F, class_7187.method_41829(-10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.25F, class_7187.method_41829(-10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.3333F, class_7187.method_41829(-10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.4167F, class_7187.method_41829(-10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.4583F, class_7187.method_41829(-10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.5F, class_7187.method_41829(-10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.625F, class_7187.method_41829(-10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.9583F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"left_leg",
			new class_7179(
				class_7179.class_7183.field_37886,
				new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2083F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.0417F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.25F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.3333F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.4167F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.4583F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.5F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.625F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.9583F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41821();
	public static final class_7184 COPPER_GOLEM_CHEST_INTERACTION_NOITEM_NOGET = class_7184.class_7185.method_41818(3.0F)
		.method_41817()
		.method_41820(
			"body",
			new class_7179(
				class_7179.class_7183.field_37887,
				new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.1667F, class_7187.method_41829(18.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2917F, class_7187.method_41829(24.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.375F, class_7187.method_41829(15.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.4167F, class_7187.method_41829(12.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.5833F, class_7187.method_41829(12.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.75F, class_7187.method_41829(12.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.8333F, class_7187.method_41829(14.72765F, -31.63886F, -7.85085F), class_7179.class_7181.field_37884),
				new class_7186(0.9167F, class_7187.method_41829(14.72765F, -31.63886F, -7.85085F), class_7179.class_7181.field_37884),
				new class_7186(1.0417F, class_7187.method_41829(14.72765F, -31.63886F, -7.85085F), class_7179.class_7181.field_37884),
				new class_7186(1.125F, class_7187.method_41829(12.40525F, -4.4E-4F, 0.00829F), class_7179.class_7181.field_37884),
				new class_7186(1.2083F, class_7187.method_41829(12.40525F, -4.4E-4F, 0.00829F), class_7179.class_7181.field_37884),
				new class_7186(1.2917F, class_7187.method_41829(13.92716F, 26.80536F, 6.38918F), class_7179.class_7181.field_37884),
				new class_7186(1.625F, class_7187.method_41829(13.93F, 26.81F, 6.39F), class_7179.class_7181.field_37884),
				new class_7186(1.7083F, class_7187.method_41829(12.40725F, 0.00444F, 0.00783F), class_7179.class_7181.field_37884),
				new class_7186(2.0417F, class_7187.method_41829(12.40725F, 0.00444F, 0.00783F), class_7179.class_7181.field_37884),
				new class_7186(2.125F, class_7187.method_41829(12.40725F, 0.0F, 0.00783F), class_7179.class_7181.field_37884),
				new class_7186(2.25F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.4583F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.5F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.6667F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.9583F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"body",
			new class_7179(
				class_7179.class_7183.field_37886,
				new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2083F, class_7187.method_41823(0.0F, 0.6F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.4167F, class_7187.method_41823(0.0F, 0.5F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.625F, class_7187.method_41823(0.0F, 0.4F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.7083F, class_7187.method_41823(0.0F, 0.34F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.0417F, class_7187.method_41823(0.0F, 0.34F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.25F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.4583F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.5F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.6667F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.9583F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"head",
			new class_7179(
				class_7179.class_7183.field_37887,
				new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.1667F, class_7187.method_41829(-20.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2083F, class_7187.method_41829(-20.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.25F, class_7187.method_41829(-2.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2917F, class_7187.method_41829(-5.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.375F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.4167F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.5833F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.6667F, class_7187.method_41829(0.0F, -20.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.75F, class_7187.method_41829(0.0F, -20.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.8333F, class_7187.method_41829(0.0F, 10.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.0417F, class_7187.method_41829(0.0F, 10.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.1667F, class_7187.method_41829(0.0F, 10.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.2083F, class_7187.method_41829(0.0F, 27.5F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.2917F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.4167F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.4583F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.5833F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.625F, class_7187.method_41829(0.0F, -2.5F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.7083F, class_7187.method_41829(0.57F, -1.25F, 0.07F), class_7179.class_7181.field_37884),
				new class_7186(1.75F, class_7187.method_41829(0.89798F, -18.12465F, -0.16276F), class_7179.class_7181.field_37884),
				new class_7186(1.7917F, class_7187.method_41829(1.21328F, -21.15422F, -0.2148F), class_7179.class_7181.field_37884),
				new class_7186(1.875F, class_7187.method_41829(1.21328F, -21.15422F, -0.2148F), class_7179.class_7181.field_37884),
				new class_7186(2.0F, class_7187.method_41829(1.21328F, -21.15422F, -0.2148F), class_7179.class_7181.field_37884),
				new class_7186(2.0417F, class_7187.method_41829(2.56546F, 0.76525F, 0.57246F), class_7179.class_7181.field_37884),
				new class_7186(2.2917F, class_7187.method_41829(4.53867F, 7.47675F, 0.59181F), class_7179.class_7181.field_37884),
				new class_7186(2.5F, class_7187.method_41829(4.53867F, 7.47675F, 0.59181F), class_7179.class_7181.field_37884),
				new class_7186(2.5417F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.9583F, class_7187.method_41829(0.0F, -360.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"head",
			new class_7179(
				class_7179.class_7183.field_37886,
				new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.1667F, class_7187.method_41823(0.0F, -0.15451F, 0.47553F), class_7179.class_7181.field_37884),
				new class_7186(0.25F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.4167F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.0417F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.1667F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.2917F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.4167F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.4583F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.5F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.5833F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.625F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.7083F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.5417F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.9583F, class_7187.method_41823(0.0F, -0.01F, -0.03F), class_7179.class_7181.field_37884),
				new class_7186(3.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"right_arm",
			new class_7179(
				class_7179.class_7183.field_37887,
				new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.1667F, class_7187.method_41829(-7.38733F, 1.29876F, 9.91615F), class_7179.class_7181.field_37884),
				new class_7186(0.2917F, class_7187.method_41829(-7.38733F, 1.29876F, 9.91615F), class_7179.class_7181.field_37884),
				new class_7186(0.375F, class_7187.method_41829(10.0F, 0.0F, 32.5F), class_7179.class_7181.field_37884),
				new class_7186(0.4167F, class_7187.method_41829(-34.55418F, 11.73507F, 36.8361F), class_7179.class_7181.field_37884),
				new class_7186(0.4583F, class_7187.method_41829(-82.47403F, 17.82361F, 2.17224F), class_7179.class_7181.field_37884),
				new class_7186(0.5F, class_7187.method_41829(-85.08388F, 14.26971F, 1.99595F), class_7179.class_7181.field_37884),
				new class_7186(0.5417F, class_7187.method_41829(-85.16266F, 13.19102F, 2.43976F), class_7179.class_7181.field_37884),
				new class_7186(0.5833F, class_7187.method_41829(-92.79F, 0.73F, 1.39F), class_7179.class_7181.field_37884),
				new class_7186(0.75F, class_7187.method_41829(-92.79F, 0.73F, 1.39F), class_7179.class_7181.field_37884),
				new class_7186(0.8333F, class_7187.method_41829(-95.83405F, 33.18639F, -0.40081F), class_7179.class_7181.field_37884),
				new class_7186(1.25F, class_7187.method_41829(-95.83F, 33.19F, -0.4F), class_7179.class_7181.field_37884),
				new class_7186(1.2917F, class_7187.method_41829(-98.33F, 33.19F, -0.4F), class_7179.class_7181.field_37884),
				new class_7186(1.5417F, class_7187.method_41829(-56.46674F, 3.3853F, 14.45894F), class_7179.class_7181.field_37884),
				new class_7186(1.6667F, class_7187.method_41829(-56.46674F, 3.3853F, 14.45894F), class_7179.class_7181.field_37884),
				new class_7186(1.8333F, class_7187.method_41829(-56.46674F, 3.3853F, 14.45894F), class_7179.class_7181.field_37884),
				new class_7186(2.0F, class_7187.method_41829(-56.46674F, 3.3853F, 14.45894F), class_7179.class_7181.field_37884),
				new class_7186(2.0417F, class_7187.method_41829(-56.46674F, 3.3853F, 14.45894F), class_7179.class_7181.field_37884),
				new class_7186(2.1667F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.5F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.5417F, class_7187.method_41829(3.9F, -4.38F, 3.36F), class_7179.class_7181.field_37884),
				new class_7186(2.9167F, class_7187.method_41829(3.9F, -4.38F, 3.36F), class_7179.class_7181.field_37884),
				new class_7186(2.9583F, class_7187.method_41829(3.90089F, -4.3843F, 3.35549F), class_7179.class_7181.field_37884),
				new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"right_arm",
			new class_7179(
				class_7179.class_7183.field_37886,
				new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2917F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.375F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.5833F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.75F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.8333F, class_7187.method_41823(0.25358F, -0.20153F, 2.21248F), class_7179.class_7181.field_37884),
				new class_7186(1.25F, class_7187.method_41823(0.25F, -0.2F, 2.21F), class_7179.class_7181.field_37884),
				new class_7186(1.2917F, class_7187.method_41823(0.25F, -0.2F, 2.21F), class_7179.class_7181.field_37884),
				new class_7186(1.5417F, class_7187.method_41823(-0.26323F, -1.46323F, 0.66566F), class_7179.class_7181.field_37884),
				new class_7186(1.6667F, class_7187.method_41823(-0.26323F, -1.46323F, 0.66566F), class_7179.class_7181.field_37884),
				new class_7186(1.8333F, class_7187.method_41823(-0.26323F, -1.46323F, 0.66566F), class_7179.class_7181.field_37884),
				new class_7186(2.0F, class_7187.method_41823(-0.26323F, -1.46323F, 0.66566F), class_7179.class_7181.field_37884),
				new class_7186(2.0417F, class_7187.method_41823(-0.26323F, -1.46323F, 0.66566F), class_7179.class_7181.field_37884),
				new class_7186(2.1667F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.5F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.5417F, class_7187.method_41823(-0.46F, -0.88F, -0.3F), class_7179.class_7181.field_37884),
				new class_7186(2.9167F, class_7187.method_41823(-0.46F, -0.88F, -0.3F), class_7179.class_7181.field_37884),
				new class_7186(2.9583F, class_7187.method_41823(-0.46F, 0.1159F, -0.30086F), class_7179.class_7181.field_37884),
				new class_7186(3.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"left_arm",
			new class_7179(
				class_7179.class_7183.field_37887,
				new class_7186(0.0F, class_7187.method_41829(-2.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2083F, class_7187.method_41829(25.0F, 0.0F, -37.5F), class_7179.class_7181.field_37884),
				new class_7186(0.25F, class_7187.method_41829(-21.59341F, -12.60837F, -45.69252F), class_7179.class_7181.field_37884),
				new class_7186(0.2917F, class_7187.method_41829(-120.7755F, -5.21988F, -2.02064F), class_7179.class_7181.field_37884),
				new class_7186(0.375F, class_7187.method_41829(-98.27419F, -1.79323F, -1.15048F), class_7179.class_7181.field_37884),
				new class_7186(0.4167F, class_7187.method_41829(-93.27F, -1.79F, -1.15F), class_7179.class_7181.field_37884),
				new class_7186(0.5417F, class_7187.method_41829(-93.27419F, -1.79323F, -1.15048F), class_7179.class_7181.field_37884),
				new class_7186(0.5833F, class_7187.method_41829(-93.55693F, -22.3224F, 3.64383F), class_7179.class_7181.field_37884),
				new class_7186(0.7083F, class_7187.method_41829(-93.55693F, -22.3224F, 3.64383F), class_7179.class_7181.field_37884),
				new class_7186(1.1667F, class_7187.method_41829(-93.55693F, -22.3224F, 3.64383F), class_7179.class_7181.field_37884),
				new class_7186(1.2083F, class_7187.method_41829(-95.75F, -2.42F, 5.97F), class_7179.class_7181.field_37884),
				new class_7186(1.25F, class_7187.method_41829(-98.4029F, -17.39503F, 6.85104F), class_7179.class_7181.field_37884),
				new class_7186(1.2917F, class_7187.method_41829(-101.24523F, -29.87096F, 7.69993F), class_7179.class_7181.field_37884),
				new class_7186(1.5833F, class_7187.method_41829(-101.25F, -29.87F, 7.7F), class_7179.class_7181.field_37884),
				new class_7186(1.6667F, class_7187.method_41829(-88.17772F, -42.09094F, 10.96195F), class_7179.class_7181.field_37884),
				new class_7186(1.8333F, class_7187.method_41829(-88.17772F, -42.09094F, 10.96195F), class_7179.class_7181.field_37884),
				new class_7186(2.0833F, class_7187.method_41829(-88.17772F, -42.09094F, 10.96195F), class_7179.class_7181.field_37884),
				new class_7186(2.1667F, class_7187.method_41829(-88.17772F, -42.09094F, 10.96195F), class_7179.class_7181.field_37884),
				new class_7186(2.2083F, class_7187.method_41829(-88.58526F, -17.10045F, 11.7676F), class_7179.class_7181.field_37884),
				new class_7186(2.3333F, class_7187.method_41829(-88.59F, -17.1F, 11.77F), class_7179.class_7181.field_37884),
				new class_7186(2.4167F, class_7187.method_41829(-46.59531F, -16.13694F, -3.85578F), class_7179.class_7181.field_37884),
				new class_7186(2.4583F, class_7187.method_41829(-24.5317F, -19.0214F, -13.70805F), class_7179.class_7181.field_37884),
				new class_7186(2.5F, class_7187.method_41829(-24.5317F, -19.0214F, -13.70805F), class_7179.class_7181.field_37884),
				new class_7186(2.5417F, class_7187.method_41829(2.41F, -0.65F, -5.01F), class_7179.class_7181.field_37884),
				new class_7186(2.9167F, class_7187.method_41829(2.41F, -0.65F, -5.01F), class_7179.class_7181.field_37884),
				new class_7186(2.9583F, class_7187.method_41829(2.41492F, -0.64686F, -5.01363F), class_7179.class_7181.field_37884),
				new class_7186(3.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"left_arm",
			new class_7179(
				class_7179.class_7183.field_37886,
				new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2083F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.4167F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.2083F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.5833F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(1.6667F, class_7187.method_41823(-0.00677F, -0.76064F, 3.19059F), class_7179.class_7181.field_37884),
				new class_7186(2.3333F, class_7187.method_41823(0.0512F, -0.76176F, 3.12882F), class_7179.class_7181.field_37884),
				new class_7186(2.4583F, class_7187.method_41823(0.03F, -0.51F, 2.09F), class_7179.class_7181.field_37884),
				new class_7186(2.5F, class_7187.method_41823(0.03F, -0.51F, 2.09F), class_7179.class_7181.field_37884),
				new class_7186(2.5417F, class_7187.method_41823(0.03F, -1.28F, -0.07F), class_7179.class_7181.field_37884),
				new class_7186(2.9167F, class_7187.method_41823(0.03F, -1.28F, -0.07F), class_7179.class_7181.field_37884),
				new class_7186(2.9583F, class_7187.method_41823(0.03F, -0.28229F, -0.07133F), class_7179.class_7181.field_37884),
				new class_7186(3.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"right_leg",
			new class_7179(
				class_7179.class_7183.field_37887,
				new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2083F, class_7187.method_41829(7.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.2917F, class_7187.method_41829(7.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.3333F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.9583F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"right_leg",
			new class_7179(
				class_7179.class_7183.field_37886,
				new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2083F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.2917F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.3333F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.9583F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"left_leg",
			new class_7179(
				class_7179.class_7183.field_37887,
				new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2083F, class_7187.method_41829(-10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.0417F, class_7187.method_41829(-10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.2917F, class_7187.method_41829(-10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.3333F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.9583F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41820(
			"left_leg",
			new class_7179(
				class_7179.class_7183.field_37886,
				new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.125F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(0.2083F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.0417F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.2917F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.3333F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
				new class_7186(2.9583F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			)
		)
		.method_41821();
}
