package com.blackgear.vanillabackport.client.level.layer;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1921;
import net.minecraft.class_1935;
import net.minecraft.class_2960;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_583;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.Predicate;

@Environment(EnvType.CLIENT)
public class SimpleEquipmentLayer<T extends class_1309, M extends class_583<T>> extends class_3887<T, M> {
    private final Function<T, Optional<class_2960>> textureSupplier;
    private final Predicate<T> shouldRender;
    private final class_583<T> model;
    private final @Nullable class_583<T> babyModel;

    public SimpleEquipmentLayer(
        class_3883<T, M> renderer,
        Function<T, Optional<class_2960>> textureSupplier,
        Predicate<T> shouldRender,
        class_583<T> model,
        @Nullable class_583<T> babyModel
    ) {
        super(renderer);
        this.textureSupplier = textureSupplier;
        this.shouldRender = shouldRender;
        this.model = model;
        this.babyModel = babyModel;
    }

    public static <T extends class_1309, M extends class_583<T>> SimpleEquipmentLayer<T, M> of(
        class_3883<T, M> renderer,
        Map<class_1935, class_2960> textureByItem,
        class_1304 slot,
        Predicate<T> shouldRender,
        class_583<T> model,
        @Nullable class_583<T> babyModel
    ) {
        return new SimpleEquipmentLayer<>(
            renderer,
            entity -> Optional.ofNullable(textureByItem.get(entity.method_6118(slot).method_7909())),
            shouldRender,
            model,
            babyModel
        );
    }
    
    public static <T extends class_1309, M extends class_583<T>> SimpleEquipmentLayer<T, M> of(
        class_3883<T, M> renderer,
        class_2960 texture,
        Predicate<T> shouldRender,
        class_583<T> model,
        @Nullable class_583<T> babyModel
    ) {
        return new SimpleEquipmentLayer<>(renderer, entity -> Optional.of(texture), shouldRender, model, babyModel);
    }

    @Override
    public void render(
        class_4587 pose,
        class_4597 buffer,
        int packedLight,
        T entity,
        float limbSwing,
        float limbSwingAmount,
        float partialTick,
        float ageInTicks,
        float netHeadYaw,
        float headPitch
    ) {
        if (!this.shouldRender.test(entity)) return;
        if (entity.method_6109() && this.babyModel == null) return;
        
        Optional<class_2960> texture = this.textureSupplier.apply(entity);
        if (texture.isEmpty()) return;
        
        class_583<T> model = entity.method_6109() ? this.babyModel : this.model;
        this.method_17165().method_17081(model);
        model.method_2816(entity, limbSwing, limbSwingAmount, partialTick);
        model.method_2819(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
        class_4588 vertices = buffer.getBuffer(class_1921.method_23578(texture.get()));
        model.method_60879(pose, vertices, packedLight, class_4608.field_21444);
    }
}