package com.blackgear.vanillabackport.client.level.renderer.item;

import com.blackgear.platform.client.v2.render.DynamicItemRenderer;
import com.blackgear.platform.core.util.event.ResultHolder;
import com.blackgear.vanillabackport.core.VanillaBackport;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1087;
import net.minecraft.class_1091;
import net.minecraft.class_1769;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1921;
import net.minecraft.class_325;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4696;
import net.minecraft.class_763;
import net.minecraft.class_7923;
import net.minecraft.class_811;
import net.minecraft.class_918;
import net.minecraft.world.item.*;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Environment(EnvType.CLIENT)
public class DyePaletteRenderer implements DynamicItemRenderer.Renderer {
    public static final DyePaletteRenderer INSTANCE = new DyePaletteRenderer();
    public static final class_1091 DYE_PALETTE = new class_1091(VanillaBackport.resource("dye_palette"), "inventory");
    public static final List<class_1792> DYES = List.of(
        class_1802.field_8446, class_1802.field_8851, class_1802.field_8298, class_1802.field_8226,
        class_1802.field_8099, class_1802.field_8264, class_1802.field_8492, class_1802.field_8192,
        class_1802.field_8131, class_1802.field_8408, class_1802.field_8632, class_1802.field_8273,
        class_1802.field_8345, class_1802.field_8296, class_1802.field_8669, class_1802.field_8330
    );
    private static final Map<class_1792, class_1091> DYE_MODELS = DYES.stream()
        .collect(Collectors.toUnmodifiableMap(
            item -> item,
            item -> new class_1091(VanillaBackport.resource(class_7923.field_41178.method_10221(item).method_12832()), "inventory")
        ));
    private static final Set<class_1091> ALL_MODELS = Stream.concat(
        DYE_MODELS.values().stream(),
        Stream.of(DYE_PALETTE)
    ).collect(Collectors.toUnmodifiableSet());
    
    @Override
    public void renderFirstPerson(class_1799 stack, class_811 context, boolean leftHand, class_4587 pose, class_4597 buffer, int light, int overlay, class_1087 model, class_763 shaper, class_325 colors) {
        if (stack.method_7909() instanceof class_1769 item) {
            boolean isPaletteEnabled = VanillaBackport.CLIENT_CONFIG.enableDyePalettes.get();
            boolean isModernRenderer = VanillaBackport.CLIENT_CONFIG.enableModernDyeTextures.get();
            
            class_1091 location = DYE_MODELS.get(item);
            class_1087 dye = isModernRenderer && location != null
                ? shaper.method_3303().method_4742(location)
                : model;
            
            dye.method_4709().method_3503(context).method_23075(leftHand, pose);
            pose.method_46416(-0.5F, -0.5F, -0.5F);
            
            class_1921 renderType = class_4696.method_23678(stack, true);
            class_4588 vertices = class_918.method_29711(buffer, renderType, true, stack.method_7958());
            
            if (isPaletteEnabled) {
                class_1087 palette = shaper.method_3303().method_4742(DYE_PALETTE);
                this.renderModelLists(palette, stack, light, overlay, pose, vertices, colors);
            }
            
            this.renderModelLists(dye, stack, light, overlay, pose, vertices, colors);
        }
    }
    
    @Override
    public ResultHolder<class_1087> renderThirdPerson(class_1799 stack, class_763 shaper) {
        return ResultHolder.pass();
    }
    
    @Override
    public boolean shouldUse() {
        return VanillaBackport.CLIENT_CONFIG.enableDyePalettes.get() || VanillaBackport.CLIENT_CONFIG.enableModernDyeTextures.get();
    }
    
    @Override
    public Set<class_1091> registerModels() {
        return ALL_MODELS;
    }
}