package com.blackgear.vanillabackport.client.level.model.entity;

import com.blackgear.vanillabackport.client.level.animation.CreakingAnimation;
import com.blackgear.vanillabackport.common.level.entities.mob.monster.creaking.Creaking;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_3532;
import net.minecraft.class_5597;
import net.minecraft.class_5603;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_630;

@Environment(EnvType.CLIENT)
public class CreakingModel<T extends Creaking> extends class_5597<T> {
    private final class_630 root;
    private final class_630 head;

    public CreakingModel(class_630 root) {
        this.root = root.method_32086("root");
        class_630 upperBody = this.root.method_32086("upper_body");
        this.head = upperBody.method_32086("head");
    }

    private static class_5609 createMesh() {
        class_5609 mesh = new class_5609();
        class_5610 base = mesh.method_32111();
        class_5610 root = base.method_32117("root", class_5606.method_32108(), class_5603.method_32090(0.0F, 24.0F, 0.0F));
        class_5610 upperBody = root.method_32117("upper_body", class_5606.method_32108(), class_5603.method_32090(-1.0F, -19.0F, 0.0F));
        upperBody.method_32117(
            "head",
            class_5606.method_32108()
                .method_32101(0, 0)
                .method_32097(-3.0F, -10.0F, -3.0F, 6.0F, 10.0F, 6.0F)
                .method_32101(28, 31)
                .method_32097(-3.0F, -13.0F, -3.0F, 6.0F, 3.0F, 6.0F)
                .method_32101(12, 40)
                .method_32097(3.0F, -13.0F, 0.0F, 9.0F, 14.0F, 0.0F)
                .method_32101(34, 12)
                .method_32097(-12.0F, -14.0F, 0.0F, 9.0F, 14.0F, 0.0F),
            class_5603.method_32090(-3.0F, -11.0F, 0.0F)
        );
        upperBody.method_32117(
            "body",
            class_5606.method_32108()
                .method_32101(0, 16)
                .method_32097(0.0F, -3.0F, -3.0F, 6.0F, 13.0F, 5.0F)
                .method_32101(24, 0)
                .method_32097(-6.0F, -4.0F, -3.0F, 6.0F, 7.0F, 5.0F),
            class_5603.method_32090(0.0F, -7.0F, 1.0F)
        );
        upperBody.method_32117(
            "right_arm",
            class_5606.method_32108()
                .method_32101(22, 13)
                .method_32097(-2.0F, -1.5F, -1.5F, 3.0F, 21.0F, 3.0F)
                .method_32101(46, 0)
                .method_32097(-2.0F, 19.5F, -1.5F, 3.0F, 4.0F, 3.0F),
            class_5603.method_32090(-7.0F, -9.5F, 1.5F)
        );
        upperBody.method_32117(
            "left_arm",
            class_5606.method_32108()
                .method_32101(30, 40)
                .method_32097(0.0F, -1.0F, -1.5F, 3.0F, 16.0F, 3.0F)
                .method_32101(52, 12)
                .method_32097(0.0F, -5.0F, -1.5F, 3.0F, 4.0F, 3.0F)
                .method_32101(52, 19)
                .method_32097(0.0F, 15.0F, -1.5F, 3.0F, 4.0F, 3.0F),
            class_5603.method_32090(6.0F, -9.0F, 0.5F)
        );
        root.method_32117(
            "left_leg",
            class_5606.method_32108()
                .method_32101(42, 40)
                .method_32097(-1.5F, 0.0F, -1.5F, 3.0F, 16.0F, 3.0F)
                .method_32101(45, 55)
                .method_32097(-1.5F, 15.7F, -4.5F, 5.0F, 0.0F, 9.0F),
            class_5603.method_32090(1.5F, -16.0F, 0.5F)
        );
        root.method_32117(
            "right_leg",
            class_5606.method_32108()
                .method_32101(0, 34)
                .method_32097(-3.0F, -1.5F, -1.5F, 3.0F, 19.0F, 3.0F)
                .method_32101(45, 46)
                .method_32097(-5.0F, 17.2F, -4.5F, 5.0F, 0.0F, 9.0F)
                .method_32101(12, 34)
                .method_32097(-3.0F, -4.5F, -1.5F, 3.0F, 3.0F, 3.0F),
            class_5603.method_32090(-1.0F, -17.5F, 0.5F)
        );
        return mesh;
    }

    public static class_5607 createBodyLayer() {
        class_5609 mesh = createMesh();
        return class_5607.method_32110(mesh, 64, 64);
    }

    @Override
    public class_630 method_32008() {
        return this.root;
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        this.method_32008().method_32088().forEach(class_630::method_41923);
        this.head.field_3654 = headPitch * class_3532.field_29847;
        this.head.field_3675 = netHeadYaw * class_3532.field_29847;

        if (entity.canMove()) {
            this.method_48741(CreakingAnimation.CREAKING_WALK, limbSwing, limbSwingAmount, 1.0F, 1.0F);
        }

        this.method_43781(entity.attackAnimationState, CreakingAnimation.CREAKING_ATTACK, ageInTicks);
        this.method_43781(entity.invulnerabilityAnimationState, CreakingAnimation.CREAKING_INVULNERABLE, ageInTicks);
        this.method_43781(entity.deathAnimationState, CreakingAnimation.CREAKING_DEATH, ageInTicks);
    }
}