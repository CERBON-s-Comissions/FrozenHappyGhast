package com.blackgear.vanillabackport.client.level.particle.particleoptions;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.netty.buffer.ByteBuf;
import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.minecraft.class_5699;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record GeyserParticleOptions(class_2396<GeyserParticleOptions> type, int waterBlocks) implements class_2394 {
    public static MapCodec<GeyserParticleOptions> codec(class_2396<GeyserParticleOptions> type) {
        return RecordCodecBuilder.mapCodec(instance -> instance.group(
            class_5699.field_33442.fieldOf("water_blocks").forGetter(GeyserParticleOptions::waterBlocks)
        ).apply(instance, waterBlocks -> new GeyserParticleOptions(type, waterBlocks)));
    }

    public static class_9139<? super ByteBuf, GeyserParticleOptions> streamCodec(class_2396<GeyserParticleOptions> type) {
        return class_9139.method_56434(class_9135.field_49675, options -> options.waterBlocks, waterBlocks -> new GeyserParticleOptions(type, waterBlocks));
    }

    @Override
    public class_2396<?> method_10295() {
        return this.type;
    }
}