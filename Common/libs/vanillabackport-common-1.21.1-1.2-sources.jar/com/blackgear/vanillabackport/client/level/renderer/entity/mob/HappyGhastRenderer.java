package com.blackgear.vanillabackport.client.level.renderer.entity.mob;

import com.blackgear.vanillabackport.client.level.layer.GhastEquipmentManager;
import com.blackgear.vanillabackport.client.level.layer.RopesLayer;
import com.blackgear.vanillabackport.client.level.layer.SimpleEquipmentLayer;
import com.blackgear.vanillabackport.client.level.model.entity.happy_ghast.HappyGhastHarnessModel;
import com.blackgear.vanillabackport.client.level.model.entity.happy_ghast.HappyGhastModel;
import com.blackgear.vanillabackport.client.registries.ModModelLayers;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.happy_ghast.HappyGhast;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1304;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_5617;
import net.minecraft.class_927;
import java.util.Optional;

@Environment(EnvType.CLIENT)
public class HappyGhastRenderer extends class_927<HappyGhast, HappyGhastModel<HappyGhast>> {
    private static final class_2960 GHAST_LOCATION = class_2960.method_60656("textures/entity/ghast/happy_ghast.png");
    private static final class_2960 GHAST_BABY_LOCATION = class_2960.method_60656("textures/entity/ghast/happy_ghast_baby.png");
    private static final class_2960 GHAST_ROPES = class_2960.method_60656("textures/entity/ghast/happy_ghast_ropes.png");

    public HappyGhastRenderer(class_5617.class_5618 context) {
        super(context, new HappyGhastModel<>(context.method_32167(ModModelLayers.HAPPY_GHAST)), 1.5F);
        this.method_4046(new SimpleEquipmentLayer<>(
            this,
            entity -> Optional.ofNullable(GhastEquipmentManager.getTexture(entity.method_6118(class_1304.field_6174).method_7909())),
            HappyGhast::isHarnessed,
            new HappyGhastHarnessModel<>(context.method_32167(ModModelLayers.HAPPY_GHAST_HARNESS)),
            null
        ));
        this.method_4046(new RopesLayer<>(this, context.method_32170(), GHAST_ROPES));
    }

    @Override
    public class_2960 getTextureLocation(HappyGhast entity) {
        return entity.method_6109() ? GHAST_BABY_LOCATION : GHAST_LOCATION;
    }

    @Override
    protected void scale(HappyGhast entity, class_4587 matrices, float partialTicks) {
        float scale = entity.method_6109() ? 0.95F : 4.0F;
        matrices.method_22905(scale, scale, scale);
    }
}