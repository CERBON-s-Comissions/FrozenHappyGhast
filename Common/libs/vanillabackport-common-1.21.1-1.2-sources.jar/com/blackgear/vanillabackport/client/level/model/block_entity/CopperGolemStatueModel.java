package com.blackgear.vanillabackport.client.level.model.block_entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_3879;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_630;

@Environment(EnvType.CLIENT)
public class CopperGolemStatueModel extends class_3879 {
    private final class_630 root;

    public CopperGolemStatueModel(class_630 root) {
        super(class_1921::method_23578);
        this.root = root;
    }

    @Override
    public void method_2828(class_4587 pose, class_4588 buffer, int light, int overlay, int color) {
        this.root.method_22699(pose, buffer, light, overlay, color);
    }
    
    public void setupAnim(class_2350 direction) {
        this.root.field_3656 = 0.0F;
        this.root.field_3675 = direction.method_10153().method_10144() * (float) (Math.PI / 180.0);
        this.root.field_3674 = (float) Math.PI;
    }
}