package com.blackgear.vanillabackport.client.level.renderer.item;

import com.blackgear.platform.client.v2.render.BuiltinItemRendererRegistry;
import com.blackgear.vanillabackport.common.level.blocks.CopperGolemStatueBlock;
import com.blackgear.vanillabackport.common.level.block_entities.CopperGolemStatueBlockEntity;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_824;
import net.minecraft.class_827;
import net.minecraft.class_9275;
import net.minecraft.class_9334;

@Environment(EnvType.CLIENT)
public class CopperGolemStatueItemRenderer implements BuiltinItemRendererRegistry.Renderer {
    private final CopperGolemStatueBlockEntity statue;
    
    public CopperGolemStatueItemRenderer(CopperGolemStatueBlock statue) {
        this.statue = new CopperGolemStatueBlockEntity(class_2338.field_10980, statue.method_9564());
    }
    
    @Override
    public void render(class_1799 stack, class_811 context, class_4587 pose, class_4597 buffer, int light, int overlay) {
        class_824 dispatcher = class_310.method_1551().method_31975();
        class_827<CopperGolemStatueBlockEntity> renderer = dispatcher.method_3550(this.statue);
        
        if (renderer != null) {
            if (context == class_811.field_4318) {
                pose.method_46416(0.0F, 0.5F, 1.0F);
            } else {
                pose.method_46416(0.0F, 1.5F, 1.0F);
            }
            
            pose.method_22907(class_7833.field_40716.rotationDegrees(180.0F));
            pose.method_22905(-1.0F, -1.0F, 1.0F);

            class_9275 properties = stack.method_57825(class_9334.field_49623, class_9275.field_49284);
            CopperGolemStatueBlock.Pose statuePose = properties.method_57418(CopperGolemStatueBlock.POSE);
            this.statue.method_31664(
                this.statue.method_11010().method_11657(
                    CopperGolemStatueBlock.POSE,
                    statuePose != null ? statuePose : CopperGolemStatueBlock.Pose.STANDING
                )
            );

            renderer.method_3569(this.statue, 0f, pose, buffer, light, overlay);
        }
    }
}