package com.blackgear.vanillabackport.client.level.particle.particleoptions;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.netty.buffer.ByteBuf;
import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.minecraft.class_5699;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record GeyserBaseParticleOptions(class_2396<GeyserBaseParticleOptions> type, int waterBlocks, float burstImpulseBase) implements class_2394 {
    public static MapCodec<GeyserBaseParticleOptions> codec(class_2396<GeyserBaseParticleOptions> type) {
        return RecordCodecBuilder.mapCodec(instance -> instance.group(
            class_5699.field_33442.fieldOf("water_blocks").forGetter(GeyserBaseParticleOptions::waterBlocks),
            Codec.FLOAT.fieldOf("burst_impulse_base").forGetter(GeyserBaseParticleOptions::burstImpulseBase)
        ).apply(instance, (waterBlocks, burstImpulseBase) -> new GeyserBaseParticleOptions(type, waterBlocks, burstImpulseBase)));
    }

    public static class_9139<? super ByteBuf, GeyserBaseParticleOptions> streamCodec(class_2396<GeyserBaseParticleOptions> type) {
        return class_9139.method_56435(
            class_9135.field_49675, options -> options.waterBlocks,
            class_9135.field_48552, options -> options.burstImpulseBase,
            (waterBlocks, burstImpulseBase) -> new GeyserBaseParticleOptions(type, waterBlocks, burstImpulseBase)
        );
    }

    @Override
    public class_2396<?> method_10295() {
        return this.type;
    }
}