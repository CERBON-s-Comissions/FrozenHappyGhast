package com.blackgear.vanillabackport.client.level.layer;

import com.blackgear.vanillabackport.core.VanillaBackport;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.mojang.serialization.Codec;
import com.mojang.serialization.JsonOps;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1792;
import net.minecraft.class_1935;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_3695;
import net.minecraft.class_4309;
import net.minecraft.class_7923;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Environment(EnvType.CLIENT)
public class GhastEquipmentManager extends class_4309 {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    public static final GhastEquipmentManager INSTANCE = new GhastEquipmentManager();
    
    private static final Map<class_1935, class_2960> DATADRIVEN_EQUIPMENT = new ConcurrentHashMap<>();
    private static final Map<class_1935, class_2960> HARDCODED_EQUIPMENT = new ConcurrentHashMap<>();
    
    public GhastEquipmentManager() {
        super(GSON, "equipment/ghast");
    }
    
    public static void register(class_1935 stack, class_2960 texture) {
        HARDCODED_EQUIPMENT.put(stack, texture);
    }
    
    @Nullable
    public static class_2960 getTexture(class_1935 item) {
        class_2960 texture = DATADRIVEN_EQUIPMENT.get(item);
        return texture != null ? texture : HARDCODED_EQUIPMENT.get(item);
    }
    
    @Override
    protected void apply(Map<class_2960, JsonElement> map, class_3300 manager, class_3695 profiler) {
        Map<class_1935, class_2960> entries = new HashMap<>();
        
        map.forEach((id, json) -> {
            class_1792 item = class_7923.field_41178.method_17966(id).orElse(null);
            if (item == null) {
                VanillaBackport.LOGGER.error("Failed to load ghast equipment entry {}: no such item", id);
                return;
            }
            
            Entry.CODEC.parse(JsonOps.INSTANCE, json)
                .resultOrPartial(error -> VanillaBackport.LOGGER.error("Failed to parse ghast equipment entry {}: {}", id, error))
                .ifPresent(entry -> entries.put(item, entry.resolveTexture()));
        });
        
        DATADRIVEN_EQUIPMENT.clear();
        DATADRIVEN_EQUIPMENT.putAll(entries);
    }
    
    public record Entry(class_2960 texture) {
        public static final Codec<Entry> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            class_2960.field_25139.fieldOf("texture").forGetter(Entry::texture)
        ).apply(instance, Entry::new));
        
        public class_2960 resolveTexture() {
            return this.texture.method_45134(path -> "textures/entity/" + path + ".png");
        }
    }
}