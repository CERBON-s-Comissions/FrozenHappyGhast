package com.blackgear.vanillabackport.client.level.layer;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_2680;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_583;
import net.minecraft.class_776;
import net.minecraft.class_7833;
import java.util.function.Consumer;
import java.util.function.Function;

@Environment(EnvType.CLIENT)
public class BlockDecorationLayer<S extends class_1297, M extends class_583<S>> extends class_3887<S, M> {
    private final class_776 dispatcher;
    private final Function<S, class_2680> blockModel;
    private final Consumer<class_4587> transform;
    
    public BlockDecorationLayer(class_3883<S, M> renderer, class_776 dispatcher, Function<S, class_2680> blockModel, Consumer<class_4587> transform) {
        super(renderer);
        this.dispatcher = dispatcher;
        this.blockModel = blockModel;
        this.transform = transform;
    }
    
    @Override
    public void method_4199(class_4587 stack, class_4597 buffer, int packedLight, S entity, float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        class_2680 shaper = this.blockModel.apply(entity);
        if (shaper != null) {
            stack.method_22903();
            this.transform.accept(stack);
            stack.method_22907(class_7833.field_40718.rotationDegrees(180.0F));
            stack.method_22905(1.0F, 1.0F, 1.0F);
            stack.method_46416(-0.5F, -1.45F, -0.5F);
            this.dispatcher.method_3353(shaper, stack, buffer, packedLight, class_4608.field_21444);
            stack.method_22909();
        }
    }
}
