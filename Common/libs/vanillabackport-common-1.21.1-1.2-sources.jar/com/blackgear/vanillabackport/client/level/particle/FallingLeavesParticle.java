package com.blackgear.vanillabackport.client.level.particle;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2400;
import net.minecraft.class_3999;
import net.minecraft.class_4002;
import net.minecraft.class_4003;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;
import net.minecraft.class_9381;
import net.minecraft.client.particle.*;

@Environment(EnvType.CLIENT)
public class FallingLeavesParticle extends class_4003 {
    private static final float ACCELERATION_SCALE = 0.0025F;
    private static final int INITIAL_LIFETIME = 300;
    private static final int CURVE_ENDPOINT_TIME = 300;
    private float rotSpeed = (float) Math.toRadians(this.field_3840.method_43056() ? -30.0 : 30.0);
    private final float spinAcceleration = (float) Math.toRadians(this.field_3840.method_43056() ? -5.0 : 5.0);
    private final float windBig;
    private final boolean swirl;
    private final boolean flowAway;
    private final double xaFlowScale;
    private final double zaFlowScale;
    private final double swirlPeriod;

    protected FallingLeavesParticle(class_638 level, double x, double y, double z, class_4002 sprites, float fallAcceleration, float windBig, boolean swirl, boolean flowAway, float scale, float startVelocity) {
        super(level, x, y, z);
        this.method_18141(sprites.method_18138(this.field_3840.method_43048(12), 12));
        this.windBig = windBig;
        this.swirl = swirl;
        this.flowAway = flowAway;
        this.field_3847 = INITIAL_LIFETIME;
        this.field_3844 = fallAcceleration * 1.2F * ACCELERATION_SCALE;
        float size = scale * (this.field_3840.method_43056() ? 0.05F : 0.075F);
        this.field_17867 = size;
        this.method_3080(size, size);
        this.field_28786 = 1.0F;
        this.field_3869 = -startVelocity;
        float particleRandom = this.field_3840.method_43057();
        this.xaFlowScale = Math.cos(Math.toRadians(particleRandom * 60.0F)) * this.windBig;
        this.zaFlowScale = Math.sin(Math.toRadians(particleRandom * 60.0F)) * this.windBig;
        this.swirlPeriod = Math.toRadians(1000.0F + particleRandom * 3000.0F);
    }

    @Override
    public class_3999 method_18122() {
        return class_3999.field_17828;
    }

    @Override
    public void method_3070() {
        this.field_3858 = this.field_3874;
        this.field_3838 = this.field_3854;
        this.field_3856 = this.field_3871;
        if (this.field_3847-- <= 0) {
            this.method_3085();
        }

        if (!this.field_3843) {
            float aliveTicks = INITIAL_LIFETIME - this.field_3847;
            float relativeAge = Math.min(aliveTicks / CURVE_ENDPOINT_TIME, 1.0F);
            double xa = 0.0;
            double za = 0.0;
            if (this.flowAway) {
                xa += this.xaFlowScale * Math.pow(relativeAge, 1.25);
                za += this.zaFlowScale * Math.pow(relativeAge, 1.25);
            }

            if (this.swirl) {
                xa += relativeAge * Math.cos(relativeAge * this.swirlPeriod) * this.windBig;
                za += relativeAge * Math.sin(relativeAge * this.swirlPeriod) * this.windBig;
            }

            this.field_3852 += xa * ACCELERATION_SCALE;
            this.field_3850 += za * ACCELERATION_SCALE;
            this.field_3869 = this.field_3869 - this.field_3844;
            this.rotSpeed = this.rotSpeed + this.spinAcceleration / 20.0F;
            this.field_3857 = this.field_3839;
            this.field_3839 = this.field_3839 + this.rotSpeed / 20.0F;
            this.method_3069(this.field_3852, this.field_3869, this.field_3850);
            if (this.field_3845 || this.field_3847 < INITIAL_LIFETIME - 1 && (this.field_3852 == 0.0 || this.field_3850 == 0.0)) {
                this.method_3085();
            }

            if (!this.field_3843) {
                this.field_3852 = this.field_3852 * this.field_28786;
                this.field_3869 = this.field_3869 * this.field_28786;
                this.field_3850 = this.field_3850 * this.field_28786;
            }
        }
    }

    @Environment(EnvType.CLIENT)
    public record PaleOakProvider(class_4002 sprites) implements class_707<class_2400> {
        @Override
        public class_703 createParticle(class_2400 type, class_638 level, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
            return new FallingLeavesParticle(level, x, y, z, this.sprites, 0.07F, 10.0F, true, false, 2.0F, 0.021F);
        }
    }
    
    @Environment(EnvType.CLIENT)
    public record PoplarProvider(class_4002 sprites) implements class_707<class_2400> {
        @Override
        public class_703 createParticle(class_2400 type, class_638 level, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
            return new FallingLeavesParticle(level, x, y, z, this.sprites, 0.07F, 10.0F, true, false, 2.0F, 0.021F);
        }
    }

    @Environment(EnvType.CLIENT)
    public record TintedLeavesProvider(class_4002 sprites) implements class_707<class_9381> {
        @Override
        public class_703 createParticle(class_9381 type, class_638 level, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
            class_703 particle = new FallingLeavesParticle(level, x, y, z, this.sprites, 0.07F, 10.0F, true, false, 2.0F, 0.021F);
            particle.method_3084(type.method_58259(), type.method_58263(), type.method_58264());
            return particle;
        }
    }
}