package com.blackgear.vanillabackport.client.level.gui.inventory;

import com.blackgear.vanillabackport.common.level.entities.mob.animal.nautilus.AbstractNautilus;
import com.blackgear.vanillabackport.common.level.inventory.NautilusInventoryMenu;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1304;
import net.minecraft.class_1661;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_465;
import net.minecraft.class_490;

@Environment(EnvType.CLIENT)
public class NautilusInventoryScreen extends class_465<NautilusInventoryMenu> {
	private static final class_2960 HORSE_INVENTORY_LOCATION = class_2960.method_60656("textures/gui/container/nautilus.png");
	private final AbstractNautilus nautilus;
	private float xMouse;
	private float yMouse;

	public NautilusInventoryScreen(NautilusInventoryMenu menu, class_1661 inventory, AbstractNautilus nautilus) {
		super(menu, inventory, nautilus.method_5476());
		this.nautilus = nautilus;
	}

	@Override
	protected void method_2389(class_332 guiGraphics, float partialTick, int mouseX, int mouseY) {
		int xOffset = (this.field_22789 - this.field_2792) / 2;
		int yOffset = (this.field_22790 - this.field_2779) / 2;
		guiGraphics.method_25302(HORSE_INVENTORY_LOCATION, xOffset, yOffset, 0, 0, this.field_2792, this.field_2779);
		if (this.nautilus.method_6765()) {
			guiGraphics.method_25302(HORSE_INVENTORY_LOCATION, xOffset + 7, yOffset + 35 - 18, 18, this.field_2779 + 54, 18, 18);
		}

		if (this.nautilus.method_56991(class_1304.field_48824)) {
			guiGraphics.method_25302(HORSE_INVENTORY_LOCATION, xOffset + 7, yOffset + 35, 0, this.field_2779 + 54, 18, 18);
		}

		class_490.method_2486(guiGraphics, xOffset + 26, yOffset + 18, xOffset + 78, yOffset + 70, 17, 0.25F, this.xMouse, this.yMouse, this.nautilus);
	}

	@Override
	public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
		this.xMouse = mouseX;
		this.yMouse = mouseY;
		super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
		this.method_2380(guiGraphics, mouseX, mouseY);
	}
}
