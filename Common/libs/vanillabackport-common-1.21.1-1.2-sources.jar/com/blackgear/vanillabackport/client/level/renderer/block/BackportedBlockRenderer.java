package com.blackgear.vanillabackport.client.level.renderer.block;

import com.blackgear.platform.client.v2.render.BlockRendererRegistry;
import com.blackgear.platform.core.util.config.ConfigBuilder;
import com.blackgear.platform.core.util.event.ResultHolder;
import com.blackgear.vanillabackport.core.VanillaBackport;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_1087;
import net.minecraft.class_1091;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_773;
import net.minecraft.class_7923;

public class BackportedBlockRenderer implements BlockRendererRegistry.Renderer {
  private final ConfigBuilder.ConfigValue<Boolean> configValue;
  private final Set<class_2248> blocks;

  public BackportedBlockRenderer(ConfigBuilder.ConfigValue<Boolean> configValue, Set<class_2248> blocks) {
    this.configValue = configValue;
    this.blocks = blocks;
  }

  @Override
  public ResultHolder<class_1087> render(class_2680 state, class_773 blockModelShaper) {
    class_2960 block = class_7923.field_41175.method_10221(state.method_26204());
    class_2960 backportBlock = VanillaBackport.resource(block.method_12832());
    class_1091 modelLocation = class_773.method_3336(backportBlock, state);
    return ResultHolder.submit(blockModelShaper.method_3333().method_4742(modelLocation));
  }

  @Override
  public Map<class_2248, class_2960> registerBlockStates() {
    HashMap<class_2248, class_2960> map = new HashMap<>();
    for (class_2248 block : blocks) {
      String path = class_7923.field_41175.method_10221(block).method_12832();
      map.put(block, VanillaBackport.resource(path));
    }
    return map;
  }

  @Override
  public boolean shouldUse() {
    return configValue.get();
  }
}
