package com.blackgear.vanillabackport.client.level.model.object;

import com.blackgear.vanillabackport.common.level.entities.decoration.Cushion;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1921;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_583;
import net.minecraft.class_630;
import net.minecraft.client.model.geom.builders.*;

@Environment(EnvType.CLIENT)
public class CushionModel extends class_583<Cushion> {
    protected final class_630 root;
    
    public CushionModel(class_630 root) {
        super(class_1921::method_23576);
        this.root = root;
    }
    
    public static class_5607 createBodyLayer() {
        class_5609 meshDefinition = new class_5609();
        class_5610 root = meshDefinition.method_32111();
        root.method_32117(
            "cushion",
            class_5606.method_32108().method_32101(0, 0).method_32098(-31.0F, -4.0F, -1.0F, 16.0F, 4.0F, 16.0F, new class_5605(-0.005F)),
            class_5603.method_32090(23.0F, 4.0F, -7.0F)
        );
        return class_5607.method_32110(meshDefinition, 64, 64);
    }
    
    @Override
    public void setupAnim(Cushion entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
    
    }
    
    @Override
    public void method_2828(class_4587 poseStack, class_4588 buffer, int packedLight, int packedOverlay, int color) {
        this.root.method_22699(poseStack, buffer, packedLight, packedOverlay, color);
    }
}