package com.blackgear.vanillabackport.client.level.model.entity.chicken;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1428;
import net.minecraft.class_558;
import net.minecraft.class_5603;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_630;

@Environment(EnvType.CLIENT)
public class ColdChickenModel<T extends class_1428> extends class_558<T> {
    public ColdChickenModel(class_630 root) {
        super(root);
    }

    public static class_5607 method_31988() {
        class_5609 mesh = new class_5609();
        class_5610 root = mesh.method_32111();
        root.method_32117(
            "head",
            class_5606.method_32108()
                .method_32101(0, 0)
                .method_32097(-2.0F, -6.0F, -2.0F, 4.0F, 6.0F, 3.0F),
            class_5603.method_32090(0.0F, 15.0F, -4.0F)
        );
        root.method_32117(
            "beak",
            class_5606.method_32108()
                .method_32101(14, 0)
                .method_32097(-2.0F, -4.0F, -4.0F, 4.0F, 2.0F, 2.0F),
            class_5603.method_32090(0.0F, 15.0F, -4.0F)
        );
        root.method_32117(
            "red_thing",
            class_5606.method_32108()
                .method_32101(14, 4)
                .method_32097(-1.0F, -2.0F, -3.0F, 2.0F, 2.0F, 2.0F),
            class_5603.method_32090(0.0F, 15.0F, -4.0F)
        );
        root.method_32117(
            "body",
            class_5606.method_32108()
                .method_32101(0, 9)
                .method_32097(-3.0F, -4.0F, -3.0F, 6.0F, 8.0F, 6.0F),
            class_5603.method_32091(0.0F, 16.0F, 0.0F, ((float) Math.PI / 2F), 0.0F, 0.0F)
        );

        class_5606 legShape = class_5606.method_32108()
            .method_32101(26, 0)
            .method_32097(-1.0F, 0.0F, -3.0F, 3.0F, 5.0F, 3.0F);

        root.method_32117(
            "right_leg",
            legShape,
            class_5603.method_32090(-2.0F, 19.0F, 1.0F)
        );
        root.method_32117(
            "left_leg",
            legShape,
            class_5603.method_32090(1.0F, 19.0F, 1.0F)
        );

        root.method_32117(
            "right_wing",
            class_5606.method_32108()
                .method_32101(24, 13)
                .method_32097(0.0F, 0.0F, -3.0F, 1.0F, 4.0F, 6.0F),
            class_5603.method_32090(-4.0F, 13.0F, 0.0F)
        );
        root.method_32117(
            "left_wing",
            class_5606.method_32108()
                .method_32101(24, 13)
                .method_32097(-1.0F, 0.0F, -3.0F, 1.0F, 4.0F, 6.0F),
            class_5603.method_32090(4.0F, 13.0F, 0.0F)
        );
        root.method_32117(
            "body",
            class_5606.method_32108()
                .method_32101(0, 9)
                .method_32097(-3.0F, -4.0F, -3.0F, 6.0F, 8.0F, 6.0F)
                .method_32101(38, 9)
                .method_32097(0.0F, 3.0F, -1.0F, 0.0F, 3.0F, 5.0F),
            class_5603.method_32091(0.0F, 16.0F, 0.0F, ((float) Math.PI / 2F), 0.0F, 0.0F)
        );
        root.method_32117(
            "head",
            class_5606.method_32108()
                .method_32101(0, 0)
                .method_32097(-2.0F, -6.0F, -2.0F, 4.0F, 6.0F, 3.0F)
                .method_32101(44, 0)
                .method_32097(-3.0F, -7.0F, -2.015F, 6.0F, 3.0F, 4.0F),
            class_5603.method_32090(0.0F, 15.0F, -4.0F)
        );

        return class_5607.method_32110(mesh, 64, 32);
    }
}