package com.blackgear.vanillabackport.client.level.model.entity.pig;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1452;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_587;
import net.minecraft.class_597;
import net.minecraft.class_630;
import net.minecraft.client.model.geom.builders.*;

@Environment(EnvType.CLIENT)
public class ColdPigModel<T extends class_1452> extends class_587<T> {
    public ColdPigModel(class_630 root) {
        super(root);
    }

    public static class_5607 createBodyLayer() {
        class_5609 mesh = class_597.method_32033(6, class_5605.field_27715);
        class_5610 root = mesh.method_32111();
        root.method_32117(
            "head",
            class_5606.method_32108()
                .method_32101(0, 0)
                .method_32097(-4.0F, -4.0F, -8.0F, 8.0F, 8.0F, 8.0F)
                .method_32101(16, 16)
                .method_32097(-2.0F, 0.0F, -9.0F, 4.0F, 3.0F, 1.0F),
            class_5603.method_32090(0.0F, 12.0F, -6.0F)
        );
        root.method_32117(
            "body",
            class_5606.method_32108()
                .method_32101(28, 8)
                .method_32097(-5.0F, -10.0F, -7.0F, 10.0F, 16.0F, 8.0F)
                .method_32101(28, 32)
                .method_32098(-5.0F, -10.0F, -7.0F, 10.0F, 16.0F, 8.0F, new class_5605(0.5F)),
            class_5603.method_32091(0.0F, 11.0F, 2.0F, ((float) Math.PI / 2F), 0.0F, 0.0F)
        );

        return class_5607.method_32110(mesh, 64, 64);
    }
}