package com.blackgear.vanillabackport.client.level.renderer.item;

import com.blackgear.platform.client.v2.render.BuiltinItemRendererRegistry;
import com.blackgear.vanillabackport.common.level.blocks.CopperChestBlock;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_811;
import net.minecraft.class_824;
import net.minecraft.class_827;
import com.blackgear.vanillabackport.common.level.block_entities.CopperChestBlockEntity;

public class CopperChestItemRenderer implements BuiltinItemRendererRegistry.Renderer {
    private final CopperChestBlockEntity chest;
    
    public CopperChestItemRenderer(CopperChestBlock chest) {
        this.chest = new CopperChestBlockEntity(class_2338.field_10980, chest.method_9564());
    }
    
    @Override
    public void render(class_1799 stack, class_811 context, class_4587 pose, class_4597 buffer, int light, int overlay) {
        class_824 dispatcher = class_310.method_1551().method_31975();
        class_827<CopperChestBlockEntity> renderer = dispatcher.method_3550(this.chest);
        if (renderer != null)
            renderer.method_3569(this.chest, 0.0F, pose, buffer, light, overlay);
    }
}