package com.blackgear.vanillabackport.client.level.particle;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2400;
import net.minecraft.class_3999;
import net.minecraft.class_4002;
import net.minecraft.class_4794;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;
import net.minecraft.client.particle.*;

@Environment(EnvType.CLIENT)
public class NoxiousGasParticle extends class_4794 {
    private final float fadeOutStartingPoint;

    public NoxiousGasParticle(
        class_638 level,
        double x,
        double y,
        double z,
        double xSpeed,
        double ySpeed,
        double zSpeed,
        float scale,
        class_4002 sprites
    ) {
        super(level, x, y, z, 0.1F, 0.1F, 0.1F, xSpeed, ySpeed, zSpeed, scale, sprites, 0.3F, 5, -0.02F, true);
        this.field_3861 = 1.0F;
        this.field_3842 = 1.0F;
        this.field_3859 = 1.0F;
        this.field_3847 = (int) (6.0 / (this.field_3840.method_43057() * 0.5 + 0.5) * scale);
        this.fadeOutStartingPoint = this.field_3847 / 2.0F;
    }

    @Override
    public void method_3070() {
        super.method_3070();
        if (this.field_3866 > this.fadeOutStartingPoint) {
            float framesSinceFadeOutStart = this.field_3866 - this.fadeOutStartingPoint;
            this.method_3083((this.field_3847 - framesSinceFadeOutStart) / this.field_3847);
        }
    }

    @Override
    public class_3999 method_18122() {
        return class_3999.field_17829;
    }

    @Environment(EnvType.CLIENT)
    public record Provider(class_4002 sprites) implements class_707<class_2400> {
        @Override
        public class_703 createParticle(
            class_2400 type,
            class_638 level,
            double x,
            double y,
            double z,
            double xSpeed,
            double ySpeed,
            double zSpeed
        ) {
            return new NoxiousGasParticle(level, x, y, z, xSpeed, ySpeed, zSpeed, 3.0F, this.sprites);
        }
    }
}
