package com.blackgear.vanillabackport.client.integrations.rendering;

import com.blackgear.vanillabackport.client.level.particle.*;
import com.blackgear.vanillabackport.client.registries.ModParticles;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_687;

import static com.blackgear.platform.client.GameRendering.*;

import com.blackgear.platform.client.GameRendering.ParticleFactoryEvent;

@Environment(EnvType.CLIENT)
public class ParticleRendering {
    public static void factories(ParticleFactoryEvent event) {
        event.register(ModParticles.PALE_OAK_LEAVES, FallingLeavesParticle.PaleOakProvider::new);
        event.register(ModParticles.TRAIL, TrailParticle.Provider::new);

        event.register(ModParticles.FIREFLY, FireflyParticle.Provider::new);
        event.register(ModParticles.TINTED_LEAVES, FallingLeavesParticle.TintedLeavesProvider::new);
        event.register(ModParticles.TINTED_NEEDLES, FallingLeavesParticle.TintedLeavesProvider::new);
        
        event.register(ModParticles.COPPER_FIRE_FLAME, class_687.class_688::new);
        
        event.register(ModParticles.SULFUR_BUBBLES, SulfurBubbleParticle.Provider::new);
        event.register(ModParticles.NOXIOUS_GAS, NoxiousGasParticle.Provider::new);
        event.register(ModParticles.NOXIOUS_GAS_CLOUD, new NoxiousGasCloudParticle.Provider());
        event.register(ModParticles.SULFUR_CUBE_GOO, SulfurCubeParticle.Provider::new);
        event.register(ModParticles.GEYSER, GeyserEruptionParticle.Provider::new);
        event.register(ModParticles.GEYSER_BASE, GeyserBaseParticle.Provider::new);
        event.register(ModParticles.GEYSER_POOF, GeyserBaseParticle.Provider::new);
        event.register(ModParticles.GEYSER_PLUME, GeyserPlumeParticle.Provider::new);
        
        event.register(ModParticles.RED_POPLAR_LEAVES, FallingLeavesParticle.PoplarProvider::new);
        event.register(ModParticles.ORANGE_POPLAR_LEAVES, FallingLeavesParticle.PoplarProvider::new);
        event.register(ModParticles.YELLOW_POPLAR_LEAVES, FallingLeavesParticle.PoplarProvider::new);
    }
}