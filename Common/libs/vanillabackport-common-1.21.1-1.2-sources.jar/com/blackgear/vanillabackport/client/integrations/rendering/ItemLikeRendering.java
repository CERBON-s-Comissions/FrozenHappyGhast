package com.blackgear.vanillabackport.client.integrations.rendering;

import com.blackgear.vanillabackport.client.level.renderer.block.BackportedBlockRenderer;
import com.blackgear.vanillabackport.client.level.renderer.block_entity.CopperChestRenderer;
import com.blackgear.vanillabackport.client.level.renderer.block_entity.CopperGolemStatueRenderer;
import com.blackgear.vanillabackport.client.level.renderer.block_entity.ShelfRenderer;
import com.blackgear.vanillabackport.client.level.renderer.item.*;
import com.blackgear.vanillabackport.common.level.blocks.CopperChestBlock;
import com.blackgear.vanillabackport.common.level.blocks.CopperGolemStatueBlock;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlockEntities;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import com.blackgear.vanillabackport.core.VanillaBackport;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1745;
import net.minecraft.class_1769;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1921;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_7923;
import java.util.Set;

import static com.blackgear.platform.client.GameRendering.*;

import com.blackgear.platform.client.GameRendering.BlockEntityRendererEvent;
import com.blackgear.platform.client.GameRendering.BlockRendererEvent;
import com.blackgear.platform.client.GameRendering.ItemLikeRenderingEvent;

@Environment(EnvType.CLIENT)
public class ItemLikeRendering {
    public static void itemLikeRendering(ItemLikeRenderingEvent event) {
        event.simple(BundleRenderer.INSTANCE, BundleRenderer.BUNDLES);
        event.dynamic(SpawnEggRenderer.INSTANCE, SpawnEggRenderer.SPAWN_EGGS);
        event.simple(SpearRenderer.INSTANCE, SpearRenderer.SPEARS);
        event.dynamic(StrawBedItemRenderer.INSTANCE, ModBlocks.STRAW_BED.get());
        
        class_7923.field_41178.method_10220().filter(item -> item instanceof class_1769).forEach(item -> event.dynamic(DyePaletteRenderer.INSTANCE, item));
        
        class_7923.field_41175.forEach(block -> {
            if (block instanceof CopperChestBlock chest) event.builtin(new CopperChestItemRenderer(chest), chest);
            if (block instanceof CopperGolemStatueBlock statue) event.builtin(new CopperGolemStatueItemRenderer(statue), statue);
        });

        Set<class_1792> hayBlocks = Set.of(class_1802.field_17528);
        event.simple(
            new BackportedItemRenderer(VanillaBackport.CLIENT_CONFIG.hasModernHayBaleTexture, hayBlocks),
            hayBlocks
        );

        Set<class_1792> redstoneTorches = Set.of(class_1802.field_8530);
        event.simple(
            new BackportedItemRenderer(VanillaBackport.CLIENT_CONFIG.hasModernRedstoneTorchModels, redstoneTorches),
            redstoneTorches
        );

        class_7923.field_41178.method_10220().filter(item -> item instanceof class_1745).forEach(item -> event.simple(BannerPatternRenderer.INSTANCE, item));
    }
    
    public static void blockEntityRendering(BlockEntityRendererEvent event) {
        event.register(ModBlockEntities.COPPER_CHEST.get(), CopperChestRenderer::new);
        event.register(ModBlockEntities.COPPER_GOLEM_STATUE.get(), CopperGolemStatueRenderer::new);
        event.register(ModBlockEntities.SHELF.get(), ShelfRenderer::new);
    }

    public static void blockRendering(BlockRendererEvent event) {
        Set<class_2248> redstoneTorchBlocks = Set.of(
            class_2246.field_10523, class_2246.field_10301,
            class_2246.field_10450, class_2246.field_10377
        );
        event.registerRenderer(
            new BackportedBlockRenderer(VanillaBackport.CLIENT_CONFIG.hasModernRedstoneTorchModels, redstoneTorchBlocks),
            redstoneTorchBlocks
        );

        Set<class_2248> hayBlocks = Set.of(class_2246.field_10359);
        event.registerRenderer(
            new BackportedBlockRenderer(VanillaBackport.CLIENT_CONFIG.hasModernHayBaleTexture, hayBlocks),
            hayBlocks
        );
    }

    public static void renderTypes(BlockRendererEvent event) {
        event.register(
            class_1921.method_23579(),
            ModBlocks.PALE_OAK_LEAVES.get(),
            ModBlocks.RED_POPLAR_LEAVES.get(),
            ModBlocks.ORANGE_POPLAR_LEAVES.get(),
            ModBlocks.YELLOW_POPLAR_LEAVES.get()
        );
        event.register(
            class_1921.method_23581(),
            ModBlocks.PALE_MOSS_CARPET.get(),
            ModBlocks.PALE_HANGING_MOSS.get(),
            ModBlocks.OPEN_EYEBLOSSOM.get(),
            ModBlocks.CLOSED_EYEBLOSSOM.get(),
            ModBlocks.POTTED_OPEN_EYEBLOSSOM.get(),
            ModBlocks.POTTED_CLOSED_EYEBLOSSOM.get(),
            ModBlocks.PALE_OAK_SAPLING.get(),
            ModBlocks.POTTED_PALE_OAK_SAPLING.get(),
            ModBlocks.RESIN_CLUMP.get(),
            ModBlocks.BUSH.get(),
            ModBlocks.FIREFLY_BUSH.get(),
            ModBlocks.WILDFLOWERS.get(),
            ModBlocks.LEAF_LITTER.get(),
            ModBlocks.CACTUS_FLOWER.get(),
            ModBlocks.SHORT_DRY_GRASS.get(),
            ModBlocks.TALL_DRY_GRASS.get(),
            ModBlocks.PALE_OAK_DOOR.get(),
            ModBlocks.PALE_OAK_TRAPDOOR.get(),
            ModBlocks.SULFUR_SPIKE.get(),
            ModBlocks.COPPER_TORCH.getFirst().get(),
            ModBlocks.COPPER_TORCH.getSecond().get(),
            ModBlocks.POPLAR_DOOR.get(),
            ModBlocks.POPLAR_TRAPDOOR.get(),
            ModBlocks.POPLAR_SAPLING.get(),
            ModBlocks.POTTED_POPLAR_SAPLING.get(),
            ModBlocks.RED_SHRUB.get(),
            ModBlocks.STRAW_BED.get()
        );
        
        ModBlocks.COPPER_LANTERN.forEach(holder -> event.register(class_1921.method_23581(), holder.get()));
        ModBlocks.COPPER_BARS.forEach(holder -> event.register(class_1921.method_23581(), holder.get()));
        ModBlocks.COPPER_CHAIN.forEach(holder -> event.register(class_1921.method_23581(), holder.get()));
    }
}