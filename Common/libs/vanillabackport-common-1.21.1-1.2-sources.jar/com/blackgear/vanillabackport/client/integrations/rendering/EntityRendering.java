package com.blackgear.vanillabackport.client.integrations.rendering;

import com.blackgear.platform.client.event.rendering.LivingEntityRendererCallback;
import com.blackgear.vanillabackport.client.api.modules.mob_rendering.RenderConditions;
import com.blackgear.vanillabackport.client.api.modules.mob_rendering.SpecialMobRenderer;
import com.blackgear.vanillabackport.client.level.layer.SheepWoolUndercoatLayer;
import com.blackgear.vanillabackport.client.level.layer.UndeadHorseArmorLayer;
import com.blackgear.vanillabackport.client.level.model.entity.CopperGolemModel;
import com.blackgear.vanillabackport.client.level.model.entity.CreakingModel;
import com.blackgear.vanillabackport.client.level.model.entity.chicken.ColdChickenModel;
import com.blackgear.vanillabackport.client.level.model.entity.cow.ColdCowModel;
import com.blackgear.vanillabackport.client.level.model.entity.cow.WarmCowModel;
import com.blackgear.vanillabackport.client.level.model.entity.happy_ghast.HappyGhastHarnessModel;
import com.blackgear.vanillabackport.client.level.model.entity.happy_ghast.HappyGhastModel;
import com.blackgear.vanillabackport.client.level.model.entity.nautilus.NautilusModel;
import com.blackgear.vanillabackport.client.level.model.entity.nautilus.ZombieNautilusCoralModel;
import com.blackgear.vanillabackport.client.level.model.entity.pig.ColdPigModel;
import com.blackgear.vanillabackport.client.level.model.entity.sulfur_cube.SmallSulfurCubeModel;
import com.blackgear.vanillabackport.client.level.model.entity.sulfur_cube.SulfurCubeModel;
import com.blackgear.vanillabackport.client.level.model.object.CushionModel;
import com.blackgear.vanillabackport.client.level.renderer.entity.CustomBoatRenderer;
import com.blackgear.vanillabackport.client.level.renderer.entity.mob.*;
import com.blackgear.vanillabackport.client.level.renderer.object.CushionRenderer;
import com.blackgear.vanillabackport.client.registries.ModModelLayers;
import com.blackgear.vanillabackport.common.registries.entities.ModEntityTypes;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_549;
import net.minecraft.class_554;
import net.minecraft.class_5605;
import net.minecraft.class_5607;
import net.minecraft.class_5617;
import net.minecraft.class_7751;
import net.minecraft.class_7752;
import net.minecraft.class_8136;
import net.minecraft.class_922;
import net.minecraft.class_941;
import net.minecraft.class_961;
import net.minecraft.client.model.*;
import net.minecraft.client.renderer.entity.*;

import static com.blackgear.platform.client.GameRendering.*;

import com.blackgear.platform.client.GameRendering.EntityRendererEvent;
import com.blackgear.platform.client.GameRendering.ModelLayerEvent;

@Environment(EnvType.CLIENT)
public class EntityRendering {
    public static void modelLayers(ModelLayerEvent event) {
        class_5607 outerArmorDefinition = class_5607.method_32110(class_8136.method_49032(new class_5605(1.0F)), 64, 32);
        class_5607 innerArmorDefinition = class_5607.method_32110(class_8136.method_49032(new class_5605(0.5F)), 64, 32);
        
        event.register(ModModelLayers.CREAKING, CreakingModel::createBodyLayer);
        event.register(ModModelLayers.CUSTOM_BOAT, class_554::method_31985);
        event.register(ModModelLayers.CUSTOM_CHEST_BOAT, class_7752::method_45708);
        
        event.register(ModModelLayers.COLD_PIG, ColdPigModel::createBodyLayer);
        event.register(ModModelLayers.COLD_CHICKEN, ColdChickenModel::method_31988);
        event.register(ModModelLayers.COLD_COW, ColdCowModel::method_31990);
        event.register(ModModelLayers.WARM_COW, WarmCowModel::method_31990);
        
        event.register(ModModelLayers.HAPPY_GHAST, () -> HappyGhastModel.createBodyLayer(class_5605.field_27715));
        event.register(ModModelLayers.HAPPY_GHAST_HARNESS, HappyGhastHarnessModel::createHarnessLayer);
        event.register(ModModelLayers.HAPPY_GHAST_ROPES, () -> HappyGhastModel.createBodyLayer(new class_5605(0.2F)));
        
        event.register(ModModelLayers.COPPER_GOLEM, CopperGolemModel::createBodyLayer);
        event.register(ModModelLayers.COPPER_GOLEM_RUNNING, CopperGolemModel::createRunningPoseBodyLayer);
        event.register(ModModelLayers.COPPER_GOLEM_SITTING, CopperGolemModel::createSittingPoseBodyLayer);
        event.register(ModModelLayers.COPPER_GOLEM_STAR, CopperGolemModel::createStarPoseBodyLayer);
        
        event.register(ModModelLayers.PARCHED, ParchedRenderer::createSingleModelDualBodyLayer);
        event.register(ModModelLayers.PARCHED_OUTER_ARMOR, () -> outerArmorDefinition);
        event.register(ModModelLayers.PARCHED_INNER_ARMOR, () -> innerArmorDefinition);
        event.register(ModModelLayers.CAMEL_HUSK, class_7751::method_45707);
        event.register(ModModelLayers.UNDEAD_HORSE_ARMOR, () -> class_5607.method_32110(class_549.method_32010(new class_5605(0.1F)), 64, 64));
        event.register(ModModelLayers.NAUTILUS, NautilusModel::createBodyLayer);
        event.register(ModModelLayers.NAUTILUS_BABY, NautilusModel::createBabyBodyLayer);
        event.register(ModModelLayers.NAUTILUS_SADDLE, NautilusModel::createSaddleLayer);
        event.register(ModModelLayers.NAUTILUS_ARMOR, NautilusModel::createBodyArmorLayer);
        event.register(ModModelLayers.ZOMBIE_NAUTILUS, NautilusModel::createBodyLayer);
        event.register(ModModelLayers.ZOMBIE_NAUTILUS_CORAL, ZombieNautilusCoralModel::createBodyLayer);
        
        event.register(ModModelLayers.SULFUR_CUBE, SulfurCubeModel::createOuterBodyLayer);
        event.register(ModModelLayers.SULFUR_CUBE_INNER, SulfurCubeModel::createInnerBodyLayer);
        event.register(ModModelLayers.SULFUR_CUBE_SMALL, SmallSulfurCubeModel::createOuterBodyLayer);
        event.register(ModModelLayers.SULFUR_CUBE_SMALL_INNER, SmallSulfurCubeModel::createInnerBodyLayer);
        
        event.register(ModModelLayers.CUSHION, CushionModel::createBodyLayer);
    }
    
    public static void renderers(EntityRendererEvent event) {
        event.register(ModEntityTypes.CREAKING.get(), CreakingRenderer::new);
        event.register(ModEntityTypes.CUSTOM_BOAT.get(), context -> new CustomBoatRenderer(context, false));
        event.register(ModEntityTypes.CUSTOM_CHEST_BOAT.get(), context -> new CustomBoatRenderer(context, true));
        
        event.register(ModEntityTypes.HAPPY_GHAST.get(), HappyGhastRenderer::new);
        
        event.register(ModEntityTypes.COPPER_GOLEM.get(), CopperGolemRenderer::new);
        event.register(ModEntityTypes.PARCHED.get(), ParchedRenderer::new);
        event.register(ModEntityTypes.CAMEL_HUSK.get(), CamelHuskRenderer::new);
        
        event.register(ModEntityTypes.CUSHION.get(), CushionRenderer::new);
        event.register(ModEntityTypes.NAUTILUS.get(), NautilusRenderer::new);
        event.register(ModEntityTypes.ZOMBIE_NAUTILUS.get(), ZombieNautilusRenderer::new);
        
        event.register(ModEntityTypes.SULFUR_CUBE.get(), SulfurCubeRenderer::new);
    }
    
    public static void renderLayers(class_1299<? extends class_1309> entity, class_922<?, ?> renderer, LivingEntityRendererCallback.LayerAppender appender, class_5617.class_5618 context) {
        SpecialMobRenderer.append(renderer, class_941.class, RenderConditions.SHEEP_UNDERCOAT, r -> new SheepWoolUndercoatLayer(r, context.method_32170()), appender::addLayer);
        SpecialMobRenderer.append(renderer, class_961.class, r -> new UndeadHorseArmorLayer(r, context.method_32170()), appender::addLayer);
    }
}