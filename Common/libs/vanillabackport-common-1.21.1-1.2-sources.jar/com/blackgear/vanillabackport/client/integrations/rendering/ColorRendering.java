package com.blackgear.vanillabackport.client.integrations.rendering;

import com.blackgear.vanillabackport.client.api.modules.leaf_litter.DryFoliageColor;
import com.blackgear.vanillabackport.client.api.modules.falling_leaves.LeafColors;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1163;
import net.minecraft.class_1933;

import static com.blackgear.platform.client.GameRendering.*;

import com.blackgear.platform.client.GameRendering.BlockColorEvent;
import com.blackgear.platform.client.GameRendering.ItemColorEvent;

@Environment(EnvType.CLIENT)
public class ColorRendering {
    public static void blockColors(BlockColorEvent event) {
        event.register((state, level, pos, tint) -> level != null && pos != null
                ? LeafColors.getAverageDryFoliageColor(pos)
                : DryFoliageColor.FOLIAGE_DRY_DEFAULT,
            ModBlocks.LEAF_LITTER.get());
        event.register((state, level, pos, tint) -> level != null && pos != null
                ? class_1163.method_4962(level, pos)
                : class_1933.method_49724(),
            ModBlocks.BUSH.get());
        event.register((state, level, pos, tint) -> tint != 0
                ? level != null && pos != null ? class_1163.method_4962(level, pos) : class_1933.method_49724()
                : -1,
            ModBlocks.WILDFLOWERS.get());
    }
    
    public static void itemColors(ItemColorEvent event) {
        event.register(event::getColor, ModBlocks.BUSH.get());
    }
}