package com.blackgear.vanillabackport.client.integrations;

import com.blackgear.platform.common.v2.creative_tabs.CreativeTabIntegrations.Event;
import com.blackgear.platform.common.v2.creative_tabs.VanillaTabs;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import com.blackgear.vanillabackport.common.registries.items.ModItems;
import com.blackgear.vanillabackport.core.ModChecker;
import com.blackgear.vanillabackport.core.VanillaBackport;
import java.util.function.Supplier;
import net.minecraft.class_1802;

public class VanillaTabIntegrations {
    public static void bootstrap(Event event) {
        registerBundlesOfBravery(event);
        registerTheGardenAwakens(event);
        registerSpringToLife(event);
        registerChaseTheSkies(event);
        registerHotAsLava(event);
        registerCopperAge(event);
        registerMountsOfMayhem(event);
        registerChaosCubed(event);
        registerWildernessBound(event);
    }
    
    private static void registerBundlesOfBravery(Event event) {
        event.register(VanillaTabs.TOOLS_AND_UTILITIES, (flags, output, operator) -> {
            output.addAfterIfAbsent(class_1802.field_8719, class_1802.field_27023);
            output.after(class_1802.field_27023).add(
                ModItems.WHITE_BUNDLE.get(),
                ModItems.LIGHT_GRAY_BUNDLE.get(),
                ModItems.GRAY_BUNDLE.get(),
                ModItems.BLACK_BUNDLE.get(),
                ModItems.BROWN_BUNDLE.get(),
                ModItems.RED_BUNDLE.get(),
                ModItems.ORANGE_BUNDLE.get(),
                ModItems.YELLOW_BUNDLE.get(),
                ModItems.LIME_BUNDLE.get(),
                ModItems.GREEN_BUNDLE.get(),
                ModItems.CYAN_BUNDLE.get(),
                ModItems.LIGHT_BLUE_BUNDLE.get(),
                ModItems.BLUE_BUNDLE.get(),
                ModItems.PURPLE_BUNDLE.get(),
                ModItems.MAGENTA_BUNDLE.get(),
                ModItems.PINK_BUNDLE.get());
        });
    }
    
    private static void registerTheGardenAwakens(Event event) {
        event.register(VanillaTabs.BUILDING_BLOCKS, (flags, output, operator) -> {
            output.after(class_1802.field_42701).add(
                ModBlocks.PALE_OAK_LOG.get(),
                ModBlocks.PALE_OAK_WOOD.get(),
                ModBlocks.STRIPPED_PALE_OAK_LOG.get(),
                ModBlocks.STRIPPED_PALE_OAK_WOOD.get(),
                ModBlocks.PALE_OAK_PLANKS.get(),
                ModBlocks.PALE_OAK_STAIRS.get(),
                ModBlocks.PALE_OAK_SLAB.get(),
                ModBlocks.PALE_OAK_FENCE.get(),
                ModBlocks.PALE_OAK_FENCE_GATE.get(),
                ModBlocks.PALE_OAK_DOOR.get(),
                ModBlocks.PALE_OAK_TRAPDOOR.get(),
                ModBlocks.PALE_OAK_PRESSURE_PLATE.get(),
                ModBlocks.PALE_OAK_BUTTON.get());
            output.after(class_1802.field_37521).add(
                ModBlocks.RESIN_BRICKS.get(),
                ModBlocks.RESIN_BRICK_STAIRS.get(),
                ModBlocks.RESIN_BRICK_SLAB.get(),
                ModBlocks.RESIN_BRICK_WALL.get(),
                ModBlocks.CHISELED_RESIN_BRICKS.get());
        });
        
        event.register(VanillaTabs.NATURAL_BLOCKS, (flags, output, operator) -> {
            output.after(class_1802.field_28653).add(
                ModBlocks.PALE_MOSS_BLOCK.get(),
                ModBlocks.PALE_MOSS_CARPET.get(),
                ModBlocks.PALE_HANGING_MOSS.get());
            output.after(class_1802.field_42692).add(ModBlocks.PALE_OAK_LOG.get());
            output.after(class_1802.field_42694).add(ModBlocks.PALE_OAK_LEAVES.get());
            output.after(class_1802.field_42688).add(ModBlocks.PALE_OAK_SAPLING.get());
            output.after(class_1802.field_42695).add(ModBlocks.CLOSED_EYEBLOSSOM.get(), ModBlocks.OPEN_EYEBLOSSOM.get());
            output.after(class_1802.field_21086).add(ModBlocks.RESIN_BLOCK.get());
        });
        
        event.register(VanillaTabs.FUNCTIONAL_BLOCKS, (flags, output, operator) -> {
            output.after(class_1802.field_42708).add(ModBlocks.PALE_OAK_SIGN.getFirst().get(), ModBlocks.PALE_OAK_HANGING_SIGN.getFirst().get());
        });
        
        event.register(VanillaTabs.TOOLS_AND_UTILITIES, (flags, output, operator) -> {
            output.after(class_1802.field_42707).add(ModItems.PALE_OAK_BOAT.get(), ModItems.PALE_OAK_CHEST_BOAT.get());
        });
        
        event.register(VanillaTabs.INGREDIENTS, (flags, output, operator) -> {
            output.after(class_1802.field_20414).add(ModBlocks.RESIN_CLUMP.get());
            output.after(class_1802.field_8729).add(ModItems.RESIN_BRICK.get());
        });
        
        event.register(VanillaTabs.SPAWN_EGGS, (flags, output, operator) -> {
            output.after(class_1802.field_8849).add(ModBlocks.CREAKING_HEART.get());
            output.after(class_1802.field_8433).add(ModItems.CREAKING_SPAWN_EGG.get());
        });
    }
    
    private static void registerSpringToLife(Event event) {
        event.register(VanillaTabs.NATURAL_BLOCKS, (flags, output, operator) -> {
            output.after(class_1802.field_8471).add(ModBlocks.SHORT_DRY_GRASS.get(), ModBlocks.BUSH.get());
            output.after(class_1802.field_42695).add(ModBlocks.CACTUS_FLOWER.get());
            output.after(class_1802.field_42696).add(ModBlocks.WILDFLOWERS.get(), ModBlocks.LEAF_LITTER.get());
            output.after(class_1802.field_28652).add(ModBlocks.FIREFLY_BUSH.get());
            output.after(class_1802.field_8561).add(ModBlocks.TALL_DRY_GRASS.get());
        });
        
        event.register(VanillaTabs.COMBAT, (flags, output, operator) -> {
            output.after(class_1802.field_8803).add(ModItems.BROWN_EGG.get(), ModItems.BLUE_EGG.get());
        });
        
        event.register(VanillaTabs.INGREDIENTS, (flags, output, operator) -> {
            output.after(class_1802.field_8803).add(ModItems.BROWN_EGG.get(), ModItems.BLUE_EGG.get());
        });
    }
    
    private static void registerChaseTheSkies(Event event) {
        event.register(VanillaTabs.NATURAL_BLOCKS, (flags, output, operator) -> {
            output.after(class_1802.field_43193).add(ModBlocks.DRIED_GHAST.get());
        });
        
        event.register(VanillaTabs.TOOLS_AND_UTILITIES, (flags, output, operator) -> {
            output.after(class_1802.field_8175).add(
                ModItems.WHITE_HARNESS.get(),
                ModItems.LIGHT_GRAY_HARNESS.get(),
                ModItems.GRAY_HARNESS.get(),
                ModItems.BLACK_HARNESS.get(),
                ModItems.BROWN_HARNESS.get(),
                ModItems.RED_HARNESS.get(),
                ModItems.ORANGE_HARNESS.get(),
                ModItems.YELLOW_HARNESS.get(),
                ModItems.LIME_HARNESS.get(),
                ModItems.GREEN_HARNESS.get(),
                ModItems.CYAN_HARNESS.get(),
                ModItems.LIGHT_BLUE_HARNESS.get(),
                ModItems.BLUE_HARNESS.get(),
                ModItems.PURPLE_HARNESS.get(),
                ModItems.MAGENTA_HARNESS.get(),
                ModItems.PINK_HARNESS.get());
            output.after(class_1802.field_44705).add(ModItems.MUSIC_DISC_TEARS.get());
        });
        
        event.register(VanillaTabs.SPAWN_EGGS, (flags, output, operator) -> {
            output.after(class_1802.field_8409).add(ModItems.HAPPY_GHAST_SPAWN_EGG.get());
        });
    }
    
    private static void registerHotAsLava(Event event) {
        event.register(VanillaTabs.TOOLS_AND_UTILITIES, (flags, output, operator) -> {
            output.after(ModItems.MUSIC_DISC_TEARS.get()).add(ModItems.MUSIC_DISC_LAVA_CHICKEN.get());
        });
    }
    
    private static void registerCopperAge(Event event) {
        event.register(VanillaTabs.BUILDING_BLOCKS, (flags, output, operator) -> {
            output.after(class_1802.field_27035).add(
                ModBlocks.COPPER_BARS.unaffected().get(),
                ModBlocks.COPPER_CHAIN.unaffected().get());
            
            output.after(class_1802.field_27037).add(
                ModBlocks.COPPER_BARS.weathered().get(),
                ModBlocks.COPPER_CHAIN.weathered().get());
            
            output.after(class_1802.field_27036).add(
                ModBlocks.COPPER_BARS.exposed().get(),
                ModBlocks.COPPER_CHAIN.exposed().get());
            
            output.after(class_1802.field_27038).add(
                ModBlocks.COPPER_BARS.oxidized().get(),
                ModBlocks.COPPER_CHAIN.oxidized().get());
            
            output.after(class_1802.field_27048).add(
                ModBlocks.COPPER_BARS.waxed().get(),
                ModBlocks.COPPER_CHAIN.waxed().get());
            
            output.after(class_1802.field_27050).add(
                ModBlocks.COPPER_BARS.waxedWeathered().get(),
                ModBlocks.COPPER_CHAIN.waxedWeathered().get());
            
            output.after(class_1802.field_27049).add(
                ModBlocks.COPPER_BARS.waxedExposed().get(),
                ModBlocks.COPPER_CHAIN.waxedExposed().get());
            
            output.after(class_1802.field_33406).add(
                ModBlocks.COPPER_BARS.waxedOxidized().get(),
                ModBlocks.COPPER_CHAIN.waxedOxidized().get());
        });
        
        event.register(VanillaTabs.FUNCTIONAL_BLOCKS, (flags, output, operator) -> {
            output.after(class_1802.field_22001).add(ModBlocks.COPPER_TORCH.getFirst().get());
            output.after(class_1802.field_22016).add(ModBlocks.COPPER_LANTERN.asList(), Supplier::get);
            output.after(class_1802.field_23983).add(ModBlocks.COPPER_CHAIN.asList(), Supplier::get);
            
            if (VanillaBackport.COMMON_CONFIG.hasWeatheringLightningRods.get() || !ModChecker.CAVERNS_AND_CHASMS) {
                output.after(class_1802.field_27051).add(
                    ModBlocks.WEATHERED_LIGHTNING_ROD.get(),
                    ModBlocks.EXPOSED_LIGHTNING_ROD.get(),
                    ModBlocks.OXIDIZED_LIGHTNING_ROD.get(),
                    ModBlocks.WAXED_LIGHTNING_ROD.get(),
                    ModBlocks.WAXED_WEATHERED_LIGHTNING_ROD.get(),
                    ModBlocks.WAXED_EXPOSED_LIGHTNING_ROD.get(),
                    ModBlocks.WAXED_OXIDIZED_LIGHTNING_ROD.get());
            }
            
            output.after(class_1802.field_40215).add(
                ModBlocks.OAK_SHELF.get(),
                ModBlocks.SPRUCE_SHELF.get(),
                ModBlocks.BIRCH_SHELF.get(),
                ModBlocks.JUNGLE_SHELF.get(),
                ModBlocks.ACACIA_SHELF.get(),
                ModBlocks.DARK_OAK_SHELF.get(),
                ModBlocks.MANGROVE_SHELF.get(),
                ModBlocks.CHERRY_SHELF.get(),
                ModBlocks.PALE_OAK_SHELF.get(),
                ModBlocks.BAMBOO_SHELF.get(),
                ModBlocks.CRIMSON_SHELF.get(),
                ModBlocks.WARPED_SHELF.get());
            output.after(class_1802.field_8106).add(
                ModBlocks.COPPER_CHEST.get(),
                ModBlocks.WEATHERED_COPPER_CHEST.get(),
                ModBlocks.EXPOSED_COPPER_CHEST.get(),
                ModBlocks.OXIDIZED_COPPER_CHEST.get(),
                ModBlocks.WAXED_COPPER_CHEST.get(),
                ModBlocks.WAXED_WEATHERED_COPPER_CHEST.get(),
                ModBlocks.WAXED_EXPOSED_COPPER_CHEST.get(),
                ModBlocks.WAXED_OXIDIZED_COPPER_CHEST.get());
            output.after(class_1802.field_8449).add(
                ModBlocks.COPPER_GOLEM_STATUE.get(),
                ModBlocks.WEATHERED_COPPER_GOLEM_STATUE.get(),
                ModBlocks.EXPOSED_COPPER_GOLEM_STATUE.get(),
                ModBlocks.OXIDIZED_COPPER_GOLEM_STATUE.get(),
                ModBlocks.WAXED_COPPER_GOLEM_STATUE.get(),
                ModBlocks.WAXED_WEATHERED_COPPER_GOLEM_STATUE.get(),
                ModBlocks.WAXED_EXPOSED_COPPER_GOLEM_STATUE.get(),
                ModBlocks.WAXED_OXIDIZED_COPPER_GOLEM_STATUE.get());
        });
        
        event.register(VanillaTabs.REDSTONE_BLOCKS, (flags, output, operator) -> {
            output.after(class_1802.field_40215).add(ModBlocks.OAK_SHELF.get());
        });
        
        if (VanillaBackport.COMMON_CONFIG.hasCopperToolSet.get()) {
            event.register(VanillaTabs.TOOLS_AND_UTILITIES, (flags, output, operator) -> {
                output.after(class_1802.field_8431)
                    .add(ModItems.COPPER_SHOVEL.get())
                    .add(ModItems.COPPER_PICKAXE.get())
                    .add(ModItems.COPPER_AXE.get())
                    .add(ModItems.COPPER_HOE.get());
            });
        
            event.register(VanillaTabs.COMBAT, (flags, output, operator) -> {
                output.after(class_1802.field_8528).add(ModItems.COPPER_SWORD.get());
                output.after(class_1802.field_8062).add(ModItems.COPPER_AXE.get());
                output.after(class_1802.field_8370).add(
                    ModItems.COPPER_HELMET.get(),
                    ModItems.COPPER_CHESTPLATE.get(),
                    ModItems.COPPER_LEGGINGS.get(),
                    ModItems.COPPER_BOOTS.get());
                output.after(class_1802.field_18138).add(ModItems.COPPER_HORSE_ARMOR.get());
            });
        }
        
        if (VanillaBackport.COMMON_CONFIG.hasCopperNuggets.get()) {
            event.register(VanillaTabs.INGREDIENTS, (flags, output, operator) -> {
                output.before(class_1802.field_8675).add(ModItems.COPPER_NUGGET.get());
            });
        }
        
        event.register(VanillaTabs.SPAWN_EGGS, (flags, output, operator) -> {
            output.after(class_1802.field_8661).add(ModItems.COPPER_GOLEM_SPAWN_EGG.get());
        });
    }
    
    private static void registerMountsOfMayhem(Event event) {
        event.register(VanillaTabs.COMBAT, (flags, output, operator) -> {
            if (VanillaBackport.COMMON_CONFIG.hasSpears.get()) {
                output.before(class_1802.field_8406).add(
                    ModItems.WOODEN_SPEAR.get(),
                    ModItems.STONE_SPEAR.get(),
                    ModItems.COPPER_SPEAR.get(),
                    ModItems.IRON_SPEAR.get(),
                    ModItems.GOLDEN_SPEAR.get(),
                    ModItems.DIAMOND_SPEAR.get(),
                    ModItems.NETHERITE_SPEAR.get());
            }
            
            output.after(class_1802.field_8807).add(ModItems.NETHERITE_HORSE_ARMOR.get());
            output.after(class_1802.field_47831).add(
                ModItems.IRON_NAUTILUS_ARMOR.get(),
                ModItems.GOLDEN_NAUTILUS_ARMOR.get(),
                ModItems.DIAMOND_NAUTILUS_ARMOR.get(),
                ModItems.NETHERITE_NAUTILUS_ARMOR.get());
                
            if (VanillaBackport.COMMON_CONFIG.hasCopperToolSet.get()) {
                output.before(ModItems.IRON_NAUTILUS_ARMOR.get()).add(ModItems.COPPER_NAUTILUS_ARMOR.get());
            }
        });
        
        event.register(VanillaTabs.SPAWN_EGGS, (flags, output, operator) -> {
            output.after(class_1802.field_40239).add(ModItems.CAMEL_HUSK_SPAWN_EGG.get());
            output.after(class_1802.field_8331).add(ModItems.NAUTILUS_SPAWN_EGG.get());
            output.after(class_1802.field_8193).add(ModItems.PARCHED_SPAWN_EGG.get());
            output.after(class_1802.field_8728).add(ModItems.ZOMBIE_NAUTILUS_SPAWN_EGG.get());
        });
    }
    
    private static void registerChaosCubed(Event event) {
        event.register(VanillaTabs.BUILDING_BLOCKS, (flags, output, operator) -> {
            output.after(class_1802.field_18887).add(
                ModBlocks.CINNABAR.get(),
                ModBlocks.CINNABAR_STAIRS.get(),
                ModBlocks.CINNABAR_SLAB.get(),
                ModBlocks.CINNABAR_WALL.get(),
                ModBlocks.CHISELED_CINNABAR.get(),
                ModBlocks.POLISHED_CINNABAR.get(),
                ModBlocks.POLISHED_CINNABAR_STAIRS.get(),
                ModBlocks.POLISHED_CINNABAR_SLAB.get(),
                ModBlocks.POLISHED_CINNABAR_WALL.get(),
                ModBlocks.CINNABAR_BRICKS.get(),
                ModBlocks.CINNABAR_BRICK_STAIRS.get(),
                ModBlocks.CINNABAR_BRICK_SLAB.get(),
                ModBlocks.CINNABAR_BRICK_WALL.get()
            ).add(
                ModBlocks.SULFUR.get(),
                ModBlocks.SULFUR_STAIRS.get(),
                ModBlocks.SULFUR_SLAB.get(),
                ModBlocks.SULFUR_WALL.get(),
                ModBlocks.CHISELED_SULFUR.get(),
                ModBlocks.POLISHED_SULFUR.get(),
                ModBlocks.POLISHED_SULFUR_STAIRS.get(),
                ModBlocks.POLISHED_SULFUR_SLAB.get(),
                ModBlocks.POLISHED_SULFUR_WALL.get(),
                ModBlocks.SULFUR_BRICKS.get(),
                ModBlocks.SULFUR_BRICK_STAIRS.get(),
                ModBlocks.SULFUR_BRICK_SLAB.get(),
                ModBlocks.SULFUR_BRICK_WALL.get());
        });
        
        event.register(VanillaTabs.NATURAL_BLOCKS, (flags, output, operator) -> {
            output.after(class_1802.field_20404)
                .add(ModBlocks.CINNABAR.get())
                .add(ModBlocks.SULFUR.get())
                .add(ModBlocks.SULFUR_SPIKE.get())
                .add(ModBlocks.POTENT_SULFUR.get());
        });
        
        event.register(VanillaTabs.TOOLS_AND_UTILITIES, (flags, output, operator) -> {
            output.after(class_1802.field_37533).add(ModItems.SULFUR_CUBE_BUCKET.get());
            output.after(ModItems.MUSIC_DISC_LAVA_CHICKEN.get()).add(ModItems.MUSIC_DISC_BOUNCE.get());
        });
        
        event.register(VanillaTabs.SPAWN_EGGS, (flags, output, operator) -> {
            output.after(class_1802.field_42710).add(ModItems.SULFUR_CUBE_SPAWN_EGG.get());
        });
    }
    
    private static void registerWildernessBound(Event event) {
        event.register(VanillaTabs.BUILDING_BLOCKS, (flags, output, operator) -> {
            output.after(ModBlocks.PALE_OAK_BUTTON.get()).add(
                ModBlocks.POPLAR_LOG.get(),
                ModBlocks.POPLAR_WOOD.get(),
                ModBlocks.STRIPPED_POPLAR_LOG.get(),
                ModBlocks.STRIPPED_POPLAR_WOOD.get(),
                ModBlocks.POPLAR_PLANKS.get(),
                ModBlocks.POPLAR_STAIRS.get(),
                ModBlocks.POPLAR_SLAB.get(),
                ModBlocks.POPLAR_FENCE.get(),
                ModBlocks.POPLAR_FENCE_GATE.get(),
                ModBlocks.POPLAR_DOOR.get(),
                ModBlocks.POPLAR_TRAPDOOR.get(),
                ModBlocks.POPLAR_PRESSURE_PLATE.get(),
                ModBlocks.POPLAR_BUTTON.get());
        });
        
        event.register(VanillaTabs.COLORED_BLOCKS, (flags, output, operator) -> {
            output.before(class_1802.field_8850).add(
                ModBlocks.WHITE_WOOL_STAIRS.get(),
                ModBlocks.LIGHT_GRAY_WOOL_STAIRS.get(),
                ModBlocks.GRAY_WOOL_STAIRS.get(),
                ModBlocks.BLACK_WOOL_STAIRS.get(),
                ModBlocks.BROWN_WOOL_STAIRS.get(),
                ModBlocks.RED_WOOL_STAIRS.get(),
                ModBlocks.ORANGE_WOOL_STAIRS.get(),
                ModBlocks.YELLOW_WOOL_STAIRS.get(),
                ModBlocks.LIME_WOOL_STAIRS.get(),
                ModBlocks.GREEN_WOOL_STAIRS.get(),
                ModBlocks.CYAN_WOOL_STAIRS.get(),
                ModBlocks.LIGHT_BLUE_WOOL_STAIRS.get(),
                ModBlocks.BLUE_WOOL_STAIRS.get(),
                ModBlocks.PURPLE_WOOL_STAIRS.get(),
                ModBlocks.MAGENTA_WOOL_STAIRS.get(),
                ModBlocks.PINK_WOOL_STAIRS.get()
            ).add(
                ModBlocks.WHITE_WOOL_SLAB.get(),
                ModBlocks.LIGHT_GRAY_WOOL_SLAB.get(),
                ModBlocks.GRAY_WOOL_SLAB.get(),
                ModBlocks.BLACK_WOOL_SLAB.get(),
                ModBlocks.BROWN_WOOL_SLAB.get(),
                ModBlocks.RED_WOOL_SLAB.get(),
                ModBlocks.ORANGE_WOOL_SLAB.get(),
                ModBlocks.YELLOW_WOOL_SLAB.get(),
                ModBlocks.LIME_WOOL_SLAB.get(),
                ModBlocks.GREEN_WOOL_SLAB.get(),
                ModBlocks.CYAN_WOOL_SLAB.get(),
                ModBlocks.LIGHT_BLUE_WOOL_SLAB.get(),
                ModBlocks.BLUE_WOOL_SLAB.get(),
                ModBlocks.PURPLE_WOOL_SLAB.get(),
                ModBlocks.MAGENTA_WOOL_SLAB.get(),
                ModBlocks.PINK_WOOL_SLAB.get());

            output.before(class_1802.field_8582).add(
                ModBlocks.WHITE_CONCRETE_STAIRS.get(),
                ModBlocks.LIGHT_GRAY_CONCRETE_STAIRS.get(),
                ModBlocks.GRAY_CONCRETE_STAIRS.get(),
                ModBlocks.BLACK_CONCRETE_STAIRS.get(),
                ModBlocks.BROWN_CONCRETE_STAIRS.get(),
                ModBlocks.RED_CONCRETE_STAIRS.get(),
                ModBlocks.ORANGE_CONCRETE_STAIRS.get(),
                ModBlocks.YELLOW_CONCRETE_STAIRS.get(),
                ModBlocks.LIME_CONCRETE_STAIRS.get(),
                ModBlocks.GREEN_CONCRETE_STAIRS.get(),
                ModBlocks.CYAN_CONCRETE_STAIRS.get(),
                ModBlocks.LIGHT_BLUE_CONCRETE_STAIRS.get(),
                ModBlocks.BLUE_CONCRETE_STAIRS.get(),
                ModBlocks.PURPLE_CONCRETE_STAIRS.get(),
                ModBlocks.MAGENTA_CONCRETE_STAIRS.get(),
                ModBlocks.PINK_CONCRETE_STAIRS.get())
            .add(
                ModBlocks.WHITE_CONCRETE_SLAB.get(),
                ModBlocks.LIGHT_GRAY_CONCRETE_SLAB.get(),
                ModBlocks.GRAY_CONCRETE_SLAB.get(),
                ModBlocks.BLACK_CONCRETE_SLAB.get(),
                ModBlocks.BROWN_CONCRETE_SLAB.get(),
                ModBlocks.RED_CONCRETE_SLAB.get(),
                ModBlocks.ORANGE_CONCRETE_SLAB.get(),
                ModBlocks.YELLOW_CONCRETE_SLAB.get(),
                ModBlocks.LIME_CONCRETE_SLAB.get(),
                ModBlocks.GREEN_CONCRETE_SLAB.get(),
                ModBlocks.CYAN_CONCRETE_SLAB.get(),
                ModBlocks.LIGHT_BLUE_CONCRETE_SLAB.get(),
                ModBlocks.BLUE_CONCRETE_SLAB.get(),
                ModBlocks.PURPLE_CONCRETE_SLAB.get(),
                ModBlocks.MAGENTA_CONCRETE_SLAB.get(),
                ModBlocks.PINK_CONCRETE_SLAB.get());
            
            output.before(class_1802.field_27024).add(
                ModItems.WHITE_CUSHION.get(),
                ModItems.LIGHT_GRAY_CUSHION.get(),
                ModItems.GRAY_CUSHION.get(),
                ModItems.BLACK_CUSHION.get(),
                ModItems.BROWN_CUSHION.get(),
                ModItems.RED_CUSHION.get(),
                ModItems.ORANGE_CUSHION.get(),
                ModItems.YELLOW_CUSHION.get(),
                ModItems.LIME_CUSHION.get(),
                ModItems.GREEN_CUSHION.get(),
                ModItems.CYAN_CUSHION.get(),
                ModItems.LIGHT_BLUE_CUSHION.get(),
                ModItems.BLUE_CUSHION.get(),
                ModItems.PURPLE_CUSHION.get(),
                ModItems.MAGENTA_CUSHION.get(),
                ModItems.PINK_CUSHION.get());
        });
        
        event.register(VanillaTabs.NATURAL_BLOCKS, (flags, output, operator) -> {
            output.after(ModBlocks.PALE_OAK_LOG.get()).add(ModBlocks.POPLAR_LOG.get());
            output.after(ModBlocks.PALE_OAK_LEAVES.get()).add(ModBlocks.RED_POPLAR_LEAVES.get(), ModBlocks.ORANGE_POPLAR_LEAVES.get(), ModBlocks.YELLOW_POPLAR_LEAVES.get());
            output.after(ModBlocks.PALE_OAK_SAPLING.get()).add(ModBlocks.POPLAR_SAPLING.get());
            output.after(class_1802.field_17517).add(ModBlocks.SHELF_MUSHROOM.get());
            output.after(ModBlocks.BUSH.get()).add(ModBlocks.RED_SHRUB.get());
        });
        
        event.register(VanillaTabs.FUNCTIONAL_BLOCKS, (flags, output, operator) -> {
            output.after(ModBlocks.PALE_OAK_SHELF.get()).add(ModBlocks.POPLAR_SHELF.get());
            output.after(ModBlocks.PALE_OAK_HANGING_SIGN.getFirst().get()).add(ModBlocks.POPLAR_SIGN.getFirst().get(), ModBlocks.POPLAR_HANGING_SIGN.getFirst().get());
            output.before(class_1802.field_27024).add(ModBlocks.STRAW_BED.get());
        });
        
        event.register(VanillaTabs.TOOLS_AND_UTILITIES, (flags, output, operator) -> {
            output.after(ModItems.PALE_OAK_CHEST_BOAT.get()).add(ModItems.POPLAR_BOAT.get(), ModItems.POPLAR_CHEST_BOAT.get());
        });
    }
}