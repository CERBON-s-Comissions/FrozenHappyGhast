package com.blackgear.vanillabackport.core.compat;

import com.blackgear.vanillabackport.core.ModChecker;
import dev.architectury.injectables.annotations.ExpectPlatform;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1428;
import net.minecraft.class_1430;
import net.minecraft.class_1452;
import net.minecraft.class_7102;

@Environment(EnvType.CLIENT)
public class ClientCompat {
    public static boolean shouldBypassBabyModel(class_1309 entity) {
        if (ModChecker.TINY_TAKEOVER && entity.method_6109()) {
            return entity.method_5864() == class_1299.field_6085 || entity.method_5864() == class_1299.field_6132 || entity.method_5864() == class_1299.field_6093;
        }
        
        return getNMLActiveRemodel(entity);
    }
    
    @ExpectPlatform
    public static boolean getNMLActiveRemodel(class_1309 entity) {
        throw new AssertionError();
    }
    
    @ExpectPlatform
    public static boolean hasQuarkCowTexture(class_1430 cow) {
        throw new AssertionError();
    }
    
    @ExpectPlatform
    public static boolean hasQuarkPigTexture(class_1452 pig) {
        throw new AssertionError();
    }
    
    @ExpectPlatform
    public static boolean hasQuarkChickenTexture(class_1428 chicken) {
        throw new AssertionError();
    }
    
    @ExpectPlatform
    public static boolean hasQuarkFrogTexture(class_7102 frog) {
        throw new AssertionError();
    }
}