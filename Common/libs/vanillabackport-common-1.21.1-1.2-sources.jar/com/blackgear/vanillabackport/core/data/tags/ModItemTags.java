package com.blackgear.vanillabackport.core.data.tags;

import com.blackgear.platform.common.data.TagRegistry;
import com.blackgear.vanillabackport.core.VanillaBackport;
import net.minecraft.class_1792;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public class ModItemTags {
    public static final TagRegistry<class_1792> TAGS = TagRegistry.create(class_7924.field_41197, VanillaBackport.NAMESPACE);

    public static final class_6862<class_1792> PALE_OAK_LOGS = TAGS.register("pale_oak_logs");
    public static final class_6862<class_1792> HAPPY_GHAST_TEMPT_ITEMS = TAGS.register("happy_ghast_tempt_items");
    public static final class_6862<class_1792> HAPPY_GHAST_FOOD = TAGS.register("happy_ghast_food");
    public static final class_6862<class_1792> HARNESSES = TAGS.register("harnesses");
    public static final class_6862<class_1792> BUNDLES = TAGS.register("bundles");
    public static final class_6862<class_1792> EGGS = TAGS.register("eggs");

    public static final class_6862<class_1792> SULFUR_CUBE_FOOD = TAGS.register("sulfur_cube_food");
    public static final class_6862<class_1792> DISABLES_WAYPOINT_TRACKING = TAGS.register("disables_waypoint_tracking");

    public static final class_6862<class_1792> SULFUR_CUBE_ARCHETYPE_REGULAR = TAGS.register("sulfur_cube_archetype/regular");
    public static final class_6862<class_1792> SULFUR_CUBE_ARCHETYPE_BOUNCY = TAGS.register("sulfur_cube_archetype/bouncy");
    public static final class_6862<class_1792> SULFUR_CUBE_ARCHETYPE_SLOW_BOUNCY = TAGS.register("sulfur_cube_archetype/slow_bouncy");
    public static final class_6862<class_1792> SULFUR_CUBE_ARCHETYPE_SLOW_FLAT = TAGS.register("sulfur_cube_archetype/slow_flat");
    public static final class_6862<class_1792> SULFUR_CUBE_ARCHETYPE_FAST_FLAT = TAGS.register("sulfur_cube_archetype/fast_flat");
    public static final class_6862<class_1792> SULFUR_CUBE_ARCHETYPE_LIGHT = TAGS.register("sulfur_cube_archetype/light");
    public static final class_6862<class_1792> SULFUR_CUBE_ARCHETYPE_FAST_SLIDING = TAGS.register("sulfur_cube_archetype/fast_sliding");
    public static final class_6862<class_1792> SULFUR_CUBE_ARCHETYPE_SLOW_SLIDING = TAGS.register("sulfur_cube_archetype/slow_sliding");
    public static final class_6862<class_1792> SULFUR_CUBE_ARCHETYPE_HIGH_RESISTANCE = TAGS.register("sulfur_cube_archetype/high_resistance");
    public static final class_6862<class_1792> SULFUR_CUBE_ARCHETYPE_STICKY = TAGS.register("sulfur_cube_archetype/sticky");
    public static final class_6862<class_1792> SULFUR_CUBE_ARCHETYPE_EXPLOSIVE = TAGS.register("sulfur_cube_archetype/explosive");
    public static final class_6862<class_1792> SULFUR_CUBE_ARCHETYPE_HOT = TAGS.register("sulfur_cube_archetype/hot");

    public static final class_6862<class_1792> SULFUR_CUBE_SWALLOWABLE = TAGS.register("sulfur_cube_swallowable");
    
    public static final class_6862<class_1792> COPPER = TAGS.register("copper");
    public static final class_6862<class_1792> COPPER_GOLEM_STATUES = TAGS.register("copper_golem_statues");
    public static final class_6862<class_1792> COPPER_CHESTS = TAGS.register("copper_chests");
    public static final class_6862<class_1792> SHEARABLE_FROM_COPPER_GOLEM = TAGS.register("shearable_from_copper_golem");
    
    public static final class_6862<class_1792> BARS = TAGS.register("bars");
    public static final class_6862<class_1792> CHAINS = TAGS.register("chains");
    public static final class_6862<class_1792> LANTERNS = TAGS.register("lanterns");
    public static final class_6862<class_1792> LIGHTNING_RODS = TAGS.register("lightning_rods");
    public static final class_6862<class_1792> WOODEN_SHELVES = TAGS.register("wooden_shelves");
    
    public static final class_6862<class_1792> SPEARS = TAGS.register("spears");
    public static final class_6862<class_1792> LUNGE_ENCHANTABLE = TAGS.register("lunge_enchantable");
    public static final class_6862<class_1792> CAMEL_HUSK_FOOD = TAGS.register("camel_husk_food");
    public static final class_6862<class_1792> ZOMBIE_HORSE_FOOD = TAGS.register("zombie_horse_food");
    
    public static final class_6862<class_1792> NAUTILUS_BUCKET_FOOD = TAGS.register("nautilus_bucket_food");
    public static final class_6862<class_1792> NAUTILUS_FOOD = TAGS.register("nautilus_food");
    public static final class_6862<class_1792> NAUTILUS_TAMING_ITEMS = TAGS.register("nautilus_taming_items");
    
    public static final class_6862<class_1792> MUSHROOMS = TAGS.register("mushrooms");
    public static final class_6862<class_1792> POPLAR_LOGS = TAGS.register("poplar_logs");
    public static final class_6862<class_1792> CUSHIONS = TAGS.register("cushions");
    public static final class_6862<class_1792> WOOL_STAIRS = TAGS.register("wool_stairs");
    public static final class_6862<class_1792> WOOL_SLABS = TAGS.register("wool_slabs");

    public static final class_6862<class_1792> CONCRETE_STAIRS = TAGS.register("concrete_stairs");
    public static final class_6862<class_1792> CONCRETE_SLABS = TAGS.register("concrete_slabs");
}