package com.blackgear.vanillabackport.core.data.tags;

import com.blackgear.platform.common.data.TagRegistry;
import com.blackgear.vanillabackport.core.VanillaBackport;
import net.minecraft.class_1959;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public class ModBiomeTags {
    public static final TagRegistry<class_1959> TAGS = TagRegistry.create(class_7924.field_41236, VanillaBackport.NAMESPACE);

    public static final class_6862<class_1959> SPAWNS_WARM_VARIANT_FARM_ANIMALS = TAGS.register("spawns_warm_variant_farm_animals");
    public static final class_6862<class_1959> SPAWNS_COLD_VARIANT_FARM_ANIMALS = TAGS.register("spawns_cold_variant_farm_animals");
    public static final class_6862<class_1959> SPAWNS_CORAL_VARIANT_ZOMBIE_NAUTILUS = TAGS.register("spawns_coral_variant_zombie_nautilus");
    public static final class_6862<class_1959> SPAWNS_NAUTILUS = TAGS.register("spawns_nautilus");
    public static final class_6862<class_1959> SPAWNS_NAUTILUS_FREQUENTLY = TAGS.register("spawns_nautilus_frequently");

    // Entity Placement Tags
    public static final class_6862<class_1959> SPAWNS_CAMELS = TAGS.register("spawns_camels");
    
    public static final class_6862<class_1959> SPAWNS_ZOMBIE_HORSES = TAGS.register("spawns_zombie_horses");

    // Feature Placement Tags
    public static final class_6862<class_1959> SPAWNS_BUSHES = TAGS.register("spawns_bushes");

    public static final class_6862<class_1959> SPAWNS_FIREFLY_BUSHES = TAGS.register("spawns_firefly_bushes");
    public static final class_6862<class_1959> SPAWNS_FIREFLY_BUSHES_SWAMP = TAGS.register("spawns_firefly_bushes_swamp");

    public static final class_6862<class_1959> SPAWNS_WILDFLOWERS = TAGS.register("spawns_wildflowers");
    public static final class_6862<class_1959> SPAWNS_NOISE_BASED_WILDFLOWERS = TAGS.register("spawns_noise_based_wildflowers");

    public static final class_6862<class_1959> SPAWNS_DRY_GRASS = TAGS.register("spawns_dry_grass");
    public static final class_6862<class_1959> SPAWNS_DRY_GRASS_RARELY = TAGS.register("spawns_dry_grass_rarely");

    public static final class_6862<class_1959> SPAWNS_FALLEN_OAK_TREES = TAGS.register("spawns_fallen_oak_trees");
    public static final class_6862<class_1959> SPAWNS_FALLEN_BIRCH_TREES = TAGS.register("spawns_fallen_birch_trees");
    public static final class_6862<class_1959> SPAWNS_FALLEN_BIRCH_TREES_RARELY = TAGS.register("spawns_fallen_birch_trees_rarely");
    public static final class_6862<class_1959> SPAWNS_FALLEN_SUPER_BIRCH_TREES = TAGS.register("spawns_fallen_super_birch_trees");
    public static final class_6862<class_1959> SPAWNS_FALLEN_JUNGLE_TREES = TAGS.register("spawns_fallen_jungle_trees");
    public static final class_6862<class_1959> SPAWNS_FALLEN_SPRUCE_TREES = TAGS.register("spawns_fallen_spruce_trees");
    public static final class_6862<class_1959> SPAWNS_FALLEN_SPRUCE_TREES_RARELY = TAGS.register("spawns_fallen_spruce_trees_rarely");

    public static final class_6862<class_1959> SPAWNS_LEAF_LITTER = TAGS.register("spawns_leaf_litter");
    public static final class_6862<class_1959> SPAWNS_LEAF_LITTER_PATCHES = TAGS.register("spawns_leaf_litter_patches");

    public static final class_6862<class_1959> HAS_DARK_LEAF_LITTER = TAGS.register("has_dark_leaf_litter");
    public static final class_6862<class_1959> HAS_PALE_LEAF_LITTER = TAGS.register("has_pale_leaf_litter");
    public static final class_6862<class_1959> HAS_RED_LEAF_LITTER = TAGS.register("has_red_leaf_litter");
    
    public static final class_6862<class_1959> HAS_ABANDONED_CAMP_BAMBOO_JUNGLE = TAGS.register("has_structure/abandoned_camp_bamboo_jungle");
    public static final class_6862<class_1959> HAS_ABANDONED_CAMP_BIRCH_FOREST = TAGS.register("has_structure/abandoned_camp_birch_forest");
    public static final class_6862<class_1959> HAS_ABANDONED_CAMP_CHERRY_GROVE = TAGS.register("has_structure/abandoned_camp_cherry_grove");
    public static final class_6862<class_1959> HAS_ABANDONED_CAMP_DAPPLED_FOREST = TAGS.register("has_structure/abandoned_camp_dappled_forest");
    public static final class_6862<class_1959> HAS_ABANDONED_CAMP_FLOWER_FOREST = TAGS.register("has_structure/abandoned_camp_flower_forest");
    public static final class_6862<class_1959> HAS_ABANDONED_CAMP_FOREST = TAGS.register("has_structure/abandoned_camp_forest");
    public static final class_6862<class_1959> HAS_ABANDONED_CAMP_MEADOW = TAGS.register("has_structure/abandoned_camp_meadow");
    public static final class_6862<class_1959> HAS_ABANDONED_CAMP_OLD_GROWTH_BIRCH_FOREST = TAGS.register("has_structure/abandoned_camp_old_growth_birch_forest");
    public static final class_6862<class_1959> HAS_ABANDONED_CAMP_OLD_GROWTH_PINE_TAIGA = TAGS.register("has_structure/abandoned_camp_old_growth_pine_taiga");
    public static final class_6862<class_1959> HAS_ABANDONED_CAMP_OLD_GROWTH_SPRUCE_TAIGA = TAGS.register("has_structure/abandoned_camp_old_growth_spruce_taiga");
    public static final class_6862<class_1959> HAS_ABANDONED_CAMP_PALE_GARDEN = TAGS.register("has_structure/abandoned_camp_pale_garden");
    public static final class_6862<class_1959> HAS_ABANDONED_CAMP_SAVANNA = TAGS.register("has_structure/abandoned_camp_savanna");
    public static final class_6862<class_1959> HAS_ABANDONED_CAMP_SNOWY_TAIGA = TAGS.register("has_structure/abandoned_camp_snowy_taiga");
    public static final class_6862<class_1959> HAS_ABANDONED_CAMP_SPARSE_JUNGLE = TAGS.register("has_structure/abandoned_camp_sparse_jungle");
    public static final class_6862<class_1959> HAS_ABANDONED_CAMP_SWAMP = TAGS.register("has_structure/abandoned_camp_swamp");
    public static final class_6862<class_1959> HAS_ABANDONED_CAMP_TAIGA = TAGS.register("has_structure/abandoned_camp_taiga");
    public static final class_6862<class_1959> HAS_ABANDONED_CAMP_WINDSWEPT_FOREST = TAGS.register("has_structure/abandoned_camp_windswept_forest");
    public static final class_6862<class_1959> HAS_ABANDONED_CAMP_WOODED_BADLANDS = TAGS.register("has_structure/abandoned_camp_wooded_badlands");
}