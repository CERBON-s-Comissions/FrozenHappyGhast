package com.blackgear.vanillabackport.core.data.tags.create;

import com.blackgear.platform.common.data.TagRegistry;
import net.minecraft.class_1299;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public class SableEntityTags {
    public static final TagRegistry<class_1299<?>> TAGS = TagRegistry.create(class_7924.field_41266, "sable");

    public static final class_6862<class_1299<?>> RETAIN_IN_SUB_LEVEL = TAGS.register("retain_in_sub_level");
}