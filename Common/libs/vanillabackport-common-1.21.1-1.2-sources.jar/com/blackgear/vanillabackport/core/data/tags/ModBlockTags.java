package com.blackgear.vanillabackport.core.data.tags;

import com.blackgear.platform.common.data.TagRegistry;
import com.blackgear.vanillabackport.core.VanillaBackport;
import net.minecraft.class_2248;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public class ModBlockTags {
    public static final TagRegistry<class_2248> TAGS = TagRegistry.create(class_7924.field_41254, VanillaBackport.NAMESPACE);

    public static final class_6862<class_2248> PALE_OAK_LOGS = TAGS.register("pale_oak_logs");
    public static final class_6862<class_2248> CREAKING_HEART_HOLDERS = TAGS.register("creaking_heart_holders");

    public static final class_6862<class_2248> HAPPY_GHAST_AVOIDS = TAGS.register("happy_ghast_avoids");

    public static final class_6862<class_2248> TRIGGERS_AMBIENT_DESERT_SAND_BLOCK_SOUNDS = TAGS.register("triggers_ambient_desert_sand_block_sounds");
    public static final class_6862<class_2248> TRIGGERS_AMBIENT_DESERT_DRY_VEGETATION_BLOCK_SOUNDS = TAGS.register("triggers_ambient_desert_dry_vegetation_block_sounds");
    public static final class_6862<class_2248> TRIGGERS_AMBIENT_DRIED_GHAST_BLOCK_SOUNDS = TAGS.register("triggers_ambient_dried_ghast_block_sounds");

    public static final class_6862<class_2248> ALLOWS_LEAF_LITTER = TAGS.register("allows_leaf_litter");
    public static final class_6862<class_2248> SUPPORTS_CACTUS = TAGS.register("supports_cactus");
    public static final class_6862<class_2248> SUPPORT_OVERRIDE_CACTUS_FLOWER = TAGS.register("support_override_cactus_flower");

    public static final class_6862<class_2248> SPAWN_FALLING_LEAVES = TAGS.register("spawn_falling_leaves");
    public static final class_6862<class_2248> SPAWN_FALLING_NEEDLES = TAGS.register("spawn_falling_needles");

    public static final class_6862<class_2248> CAMELS_SPAWNABLE_ON = TAGS.register("camel_spawnable_on");
    public static final class_6862<class_2248> INCORRECT_FOR_COPPER_TOOL = TAGS.register("incorrect_for_copper_tool");

    public static final class_6862<class_2248> CAUSES_PERIODIC_GEYSER_ERUPTIONS = TAGS.register("causes_periodic_geyser_eruptions");
    public static final class_6862<class_2248> CAUSES_CONTINUOUS_GEYSER_ERUPTIONS = TAGS.register("causes_continuous_geyser_eruptions");

    public static final class_6862<class_2248> SPELEOTHEMS = TAGS.register("speleothems");
    public static final class_6862<class_2248> SULFUR_SPIKE_REPLACEABLE = TAGS.register("sulfur_spike_replaceable");
    public static final class_6862<class_2248> SUPPRESSES_BOUNCE = TAGS.register("suppresses_bounce");
    
    public static final class_6862<class_2248> COPPER_GOLEM_STATUES = TAGS.register("copper_golem_statues");
    public static final class_6862<class_2248> COPPER_CHESTS = TAGS.register("copper_chests");
    public static final class_6862<class_2248> TRANSPORT_ITEM_SOURCE_BLOCKS = TAGS.register("transport_item_source_blocks");
    public static final class_6862<class_2248> TRANSPORT_ITEM_DESTINATION_BLOCKS = TAGS.register("transport_item_destination_blocks");
    public static final class_6862<class_2248> COPPER = TAGS.register("copper");
    
    public static final class_6862<class_2248> BARS = TAGS.register("bars");
    public static final class_6862<class_2248> CHAINS = TAGS.register("chains");
    public static final class_6862<class_2248> LANTERNS = TAGS.register("lanterns");
    public static final class_6862<class_2248> LIGHTNING_RODS = TAGS.register("lightning_rods");
    
    public static final class_6862<class_2248> WOODEN_SHELVES = TAGS.register("wooden_shelves");
    
    public static final class_6862<class_2248> WOOL_STAIRS = TAGS.register("wool_stairs");
    public static final class_6862<class_2248> WOOL_SLABS = TAGS.register("wool_slabs");

    public static final class_6862<class_2248> POPLAR_LOGS = TAGS.register("poplar_logs");
    public static final class_6862<class_2248> REQUIRED_FOR_POPLAR_LEAF_AMBIENCE = TAGS.register("required_for_poplar_leaf_ambience");
    public static final class_6862<class_2248> CUSHION_USES_COLLISION_SHAPE = TAGS.register("cushion_uses_collision_shape");

    public static final class_6862<class_2248> CONCRETE_STAIRS = TAGS.register("concrete_stairs");
    public static final class_6862<class_2248> CONCRETE_SLABS = TAGS.register("concrete_slabs");
}
