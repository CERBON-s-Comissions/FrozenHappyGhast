package com.blackgear.vanillabackport.core.data.tags;

import com.blackgear.platform.common.data.TagRegistry;
import com.blackgear.vanillabackport.core.VanillaBackport;
import net.minecraft.class_1299;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public class ModEntityTypeTags {
    public static final TagRegistry<class_1299<?>> TAGS = TagRegistry.create(class_7924.field_41266, VanillaBackport.NAMESPACE);

    public static final class_6862<class_1299<?>> FOLLOWABLE_FRIENDLY_MOBS = TAGS.register("followable_friendly_mobs");
    public static final class_6862<class_1299<?>> MONSTERS_THAT_SPAWN_ON_PEACEFUL = TAGS.register("monsters_that_spawn_on_peaceful");
    public static final class_6862<class_1299<?>> NOT_AFFECTED_BY_GEYSERS = TAGS.register("not_affected_by_geysers");
    public static final class_6862<class_1299<?>> ACCEPTS_IRON_GOLEM_GIFT = TAGS.register("accepts_iron_golem_gift");
    public static final class_6862<class_1299<?>> CAN_FLOAT_WHILE_RIDDEN = TAGS.register("can_float_while_ridden");
    public static final class_6862<class_1299<?>> NAUTILUS_HOSTILES = TAGS.register("nautilus_hostiles");
}