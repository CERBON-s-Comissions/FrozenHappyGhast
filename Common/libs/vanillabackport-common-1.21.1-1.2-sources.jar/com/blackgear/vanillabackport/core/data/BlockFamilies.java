package com.blackgear.vanillabackport.core.data;

import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import com.google.common.collect.Maps;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.stream.Stream;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_5794;
import net.minecraft.class_7923;

public class BlockFamilies {
    private static final Map<class_2248, class_5794> MAP = Maps.newHashMap();

    public static final class_5794 PALE_OAK_PLANKS = familyBuilder(ModBlocks.PALE_OAK_PLANKS.get())
        .method_33482(ModBlocks.PALE_OAK_BUTTON.get())
        .method_33490(ModBlocks.PALE_OAK_FENCE.get())
        .method_33491(ModBlocks.PALE_OAK_FENCE_GATE.get())
        .method_33494(ModBlocks.PALE_OAK_PRESSURE_PLATE.get())
        .method_33483(ModBlocks.PALE_OAK_SIGN.getFirst().get(), ModBlocks.PALE_OAK_SIGN.getSecond().get())
        .method_33492(ModBlocks.PALE_OAK_SLAB.get())
        .method_33493(ModBlocks.PALE_OAK_STAIRS.get())
        .method_33489(ModBlocks.PALE_OAK_DOOR.get())
        .method_33496(ModBlocks.PALE_OAK_TRAPDOOR.get())
        .method_33484("wooden")
        .method_33487("has_planks")
        .method_33481();

    public static final class_5794 RESIN_BRICKS = familyBuilder(ModBlocks.RESIN_BRICKS.get())
        .method_33497(ModBlocks.RESIN_BRICK_WALL.get())
        .method_33493(ModBlocks.RESIN_BRICK_STAIRS.get())
        .method_33492(ModBlocks.RESIN_BRICK_SLAB.get())
        .method_33486(ModBlocks.CHISELED_RESIN_BRICKS.get())
        .method_33481();

    public static final class_5794 SULFUR = familyBuilder(ModBlocks.SULFUR.get())
        .method_33497(ModBlocks.SULFUR_WALL.get())
        .method_33493(ModBlocks.SULFUR_STAIRS.get())
        .method_33492(ModBlocks.SULFUR_SLAB.get())
        .method_33486(ModBlocks.CHISELED_SULFUR.get())
        .method_33495(ModBlocks.POLISHED_SULFUR.get())
        .method_33481();

    public static final class_5794 POLISHED_SULFUR = familyBuilder(ModBlocks.POLISHED_SULFUR.get())
        .method_33497(ModBlocks.POLISHED_SULFUR_WALL.get())
        .method_33493(ModBlocks.POLISHED_SULFUR_STAIRS.get())
        .method_33492(ModBlocks.POLISHED_SULFUR_SLAB.get())
        .method_33481();

    public static final class_5794 SULFUR_BRICKS = familyBuilder(ModBlocks.SULFUR_BRICKS.get())
        .method_33497(ModBlocks.SULFUR_BRICK_WALL.get())
        .method_33493(ModBlocks.SULFUR_BRICK_STAIRS.get())
        .method_33492(ModBlocks.SULFUR_BRICK_SLAB.get())
        .method_33481();

    public static final class_5794 CINNABAR = familyBuilder(ModBlocks.CINNABAR.get())
        .method_33497(ModBlocks.CINNABAR_WALL.get())
        .method_33493(ModBlocks.CINNABAR_STAIRS.get())
        .method_33492(ModBlocks.CINNABAR_SLAB.get())
        .method_33486(ModBlocks.CHISELED_CINNABAR.get())
        .method_33495(ModBlocks.POLISHED_CINNABAR.get())
        .method_33481();

    public static final class_5794 POLISHED_CINNABAR = familyBuilder(ModBlocks.POLISHED_CINNABAR.get())
        .method_33497(ModBlocks.POLISHED_CINNABAR_WALL.get())
        .method_33493(ModBlocks.POLISHED_CINNABAR_STAIRS.get())
        .method_33492(ModBlocks.POLISHED_CINNABAR_SLAB.get())
        .method_33481();

    public static final class_5794 CINNABAR_BRICKS = familyBuilder(ModBlocks.CINNABAR_BRICKS.get())
        .method_33497(ModBlocks.CINNABAR_BRICK_WALL.get())
        .method_33493(ModBlocks.CINNABAR_BRICK_STAIRS.get())
        .method_33492(ModBlocks.CINNABAR_BRICK_SLAB.get())
        .method_33481();
    
    public static final class_5794 POPLAR_PLANKS = familyBuilder(ModBlocks.POPLAR_PLANKS.get())
        .method_33482(ModBlocks.POPLAR_BUTTON.get())
        .method_33490(ModBlocks.POPLAR_FENCE.get())
        .method_33491(ModBlocks.POPLAR_FENCE_GATE.get())
        .method_33494(ModBlocks.POPLAR_PRESSURE_PLATE.get())
        .method_33483(ModBlocks.POPLAR_SIGN.getFirst().get(), ModBlocks.POPLAR_SIGN.getSecond().get())
        .method_33492(ModBlocks.POPLAR_SLAB.get())
        .method_33493(ModBlocks.POPLAR_STAIRS.get())
        .method_33489(ModBlocks.POPLAR_DOOR.get())
        .method_33496(ModBlocks.POPLAR_TRAPDOOR.get())
        .method_33484("wooden")
        .method_33487("has_planks")
        .method_33481();
    
    public static final class_5794 BLACK_WOOL = familyBuilder(class_2246.field_10146)
        .method_33493(ModBlocks.BLACK_WOOL_STAIRS.get())
        .method_33492(ModBlocks.BLACK_WOOL_SLAB.get())
        .method_33481();
    
    public static final class_5794 BLUE_WOOL = familyBuilder(class_2246.field_10514)
        .method_33493(ModBlocks.BLUE_WOOL_STAIRS.get())
        .method_33492(ModBlocks.BLUE_WOOL_SLAB.get())
        .method_33481();
    
    public static final class_5794 BROWN_WOOL = familyBuilder(class_2246.field_10113)
        .method_33493(ModBlocks.BROWN_WOOL_STAIRS.get())
        .method_33492(ModBlocks.BROWN_WOOL_SLAB.get())
        .method_33481();
    
    public static final class_5794 CYAN_WOOL = familyBuilder(class_2246.field_10619)
        .method_33493(ModBlocks.CYAN_WOOL_STAIRS.get())
        .method_33492(ModBlocks.CYAN_WOOL_SLAB.get())
        .method_33481();
    
    public static final class_5794 GRAY_WOOL = familyBuilder(class_2246.field_10423)
        .method_33493(ModBlocks.GRAY_WOOL_STAIRS.get())
        .method_33492(ModBlocks.GRAY_WOOL_SLAB.get())
        .method_33481();
    
    public static final class_5794 GREEN_WOOL = familyBuilder(class_2246.field_10170)
        .method_33493(ModBlocks.GREEN_WOOL_STAIRS.get())
        .method_33492(ModBlocks.GREEN_WOOL_SLAB.get())
        .method_33481();
    
    public static final class_5794 LIGHT_BLUE_WOOL = familyBuilder(class_2246.field_10294)
        .method_33493(ModBlocks.LIGHT_BLUE_WOOL_STAIRS.get())
        .method_33492(ModBlocks.LIGHT_BLUE_WOOL_SLAB.get())
        .method_33481();
    
    public static final class_5794 LIGHT_GRAY_WOOL = familyBuilder(class_2246.field_10222)
        .method_33493(ModBlocks.LIGHT_GRAY_WOOL_STAIRS.get())
        .method_33492(ModBlocks.LIGHT_GRAY_WOOL_SLAB.get())
        .method_33481();
    
    public static final class_5794 LIME_WOOL = familyBuilder(class_2246.field_10028)
        .method_33493(ModBlocks.LIME_WOOL_STAIRS.get())
        .method_33492(ModBlocks.LIME_WOOL_SLAB.get())
        .method_33481();
    
    public static final class_5794 MAGENTA_WOOL = familyBuilder(class_2246.field_10215)
        .method_33493(ModBlocks.MAGENTA_WOOL_STAIRS.get())
        .method_33492(ModBlocks.MAGENTA_WOOL_SLAB.get())
        .method_33481();
    
    public static final class_5794 ORANGE_WOOL = familyBuilder(class_2246.field_10095)
        .method_33493(ModBlocks.ORANGE_WOOL_STAIRS.get())
        .method_33492(ModBlocks.ORANGE_WOOL_SLAB.get())
        .method_33481();
    
    public static final class_5794 PINK_WOOL = familyBuilder(class_2246.field_10459)
        .method_33493(ModBlocks.PINK_WOOL_STAIRS.get())
        .method_33492(ModBlocks.PINK_WOOL_SLAB.get())
        .method_33481();
    
    public static final class_5794 PURPLE_WOOL = familyBuilder(class_2246.field_10259)
        .method_33493(ModBlocks.PURPLE_WOOL_STAIRS.get())
        .method_33492(ModBlocks.PURPLE_WOOL_SLAB.get())
        .method_33481();
    
    public static final class_5794 RED_WOOL = familyBuilder(class_2246.field_10314)
        .method_33493(ModBlocks.RED_WOOL_STAIRS.get())
        .method_33492(ModBlocks.RED_WOOL_SLAB.get())
        .method_33481();
    
    public static final class_5794 YELLOW_WOOL = familyBuilder(class_2246.field_10490)
        .method_33493(ModBlocks.YELLOW_WOOL_STAIRS.get())
        .method_33492(ModBlocks.YELLOW_WOOL_SLAB.get())
        .method_33481();
    
    public static final class_5794 WHITE_WOOL = familyBuilder(class_2246.field_10446)
        .method_33493(ModBlocks.WHITE_WOOL_STAIRS.get())
        .method_33492(ModBlocks.WHITE_WOOL_SLAB.get())
        .method_33481();

    public static final class_5794 BLACK_CONCRETE = familyBuilder(class_2246.field_10458)
        .method_33492(ModBlocks.BLACK_CONCRETE_SLAB.get())
        .method_33493(ModBlocks.BLACK_CONCRETE_STAIRS.get())
        .method_33481();

    public static final class_5794 BLUE_CONCRETE = familyBuilder(class_2246.field_10011)
        .method_33492(ModBlocks.BLUE_CONCRETE_SLAB.get())
        .method_33493(ModBlocks.BLUE_CONCRETE_STAIRS.get())
        .method_33481();

    public static final class_5794 BROWN_CONCRETE = familyBuilder(class_2246.field_10439)
        .method_33492(ModBlocks.BROWN_CONCRETE_SLAB.get())
        .method_33493(ModBlocks.BROWN_CONCRETE_STAIRS.get())
        .method_33481();

    public static final class_5794 CYAN_CONCRETE = familyBuilder(class_2246.field_10308)
        .method_33492(ModBlocks.CYAN_CONCRETE_SLAB.get())
        .method_33493(ModBlocks.CYAN_CONCRETE_STAIRS.get())
        .method_33481();

    public static final class_5794 GRAY_CONCRETE = familyBuilder(class_2246.field_10038)
        .method_33492(ModBlocks.GRAY_CONCRETE_SLAB.get())
        .method_33493(ModBlocks.GRAY_CONCRETE_STAIRS.get())
        .method_33481();

    public static final class_5794 GREEN_CONCRETE = familyBuilder(class_2246.field_10367)
        .method_33492(ModBlocks.GREEN_CONCRETE_SLAB.get())
        .method_33493(ModBlocks.GREEN_CONCRETE_STAIRS.get())
        .method_33481();

    public static final class_5794 LIGHT_BLUE_CONCRETE = familyBuilder(class_2246.field_10242)
        .method_33492(ModBlocks.LIGHT_BLUE_CONCRETE_SLAB.get())
        .method_33493(ModBlocks.LIGHT_BLUE_CONCRETE_STAIRS.get())
        .method_33481();

    public static final class_5794 LIGHT_GRAY_CONCRETE = familyBuilder(class_2246.field_10172)
        .method_33492(ModBlocks.LIGHT_GRAY_CONCRETE_SLAB.get())
        .method_33493(ModBlocks.LIGHT_GRAY_CONCRETE_STAIRS.get())
        .method_33481();

    public static final class_5794 LIME_CONCRETE = familyBuilder(class_2246.field_10421)
        .method_33492(ModBlocks.LIME_CONCRETE_SLAB.get())
        .method_33493(ModBlocks.LIME_CONCRETE_STAIRS.get())
        .method_33481();

    public static final class_5794 MAGENTA_CONCRETE = familyBuilder(class_2246.field_10585)
        .method_33492(ModBlocks.MAGENTA_CONCRETE_SLAB.get())
        .method_33493(ModBlocks.MAGENTA_CONCRETE_STAIRS.get())
        .method_33481();

    public static final class_5794 ORANGE_CONCRETE = familyBuilder(class_2246.field_10210)
        .method_33492(ModBlocks.ORANGE_CONCRETE_SLAB.get())
        .method_33493(ModBlocks.ORANGE_CONCRETE_STAIRS.get())
        .method_33481();

    public static final class_5794 PINK_CONCRETE = familyBuilder(class_2246.field_10434)
        .method_33492(ModBlocks.PINK_CONCRETE_SLAB.get())
        .method_33493(ModBlocks.PINK_CONCRETE_STAIRS.get())
        .method_33481();

    public static final class_5794 PURPLE_CONCRETE = familyBuilder(class_2246.field_10206)
        .method_33492(ModBlocks.PURPLE_CONCRETE_SLAB.get())
        .method_33493(ModBlocks.PURPLE_CONCRETE_STAIRS.get())
        .method_33481();

    public static final class_5794 RED_CONCRETE = familyBuilder(class_2246.field_10058)
        .method_33492(ModBlocks.RED_CONCRETE_SLAB.get())
        .method_33493(ModBlocks.RED_CONCRETE_STAIRS.get())
        .method_33481();

    public static final class_5794 YELLOW_CONCRETE = familyBuilder(class_2246.field_10542)
        .method_33492(ModBlocks.YELLOW_CONCRETE_SLAB.get())
        .method_33493(ModBlocks.YELLOW_CONCRETE_STAIRS.get())
        .method_33481();

    public static final class_5794 WHITE_CONCRETE = familyBuilder(class_2246.field_10107)
        .method_33492(ModBlocks.WHITE_CONCRETE_SLAB.get())
        .method_33493(ModBlocks.WHITE_CONCRETE_STAIRS.get())
        .method_33481();

    private static class_5794.class_5795 familyBuilder(class_2248 block) {
        class_5794.class_5795 builder = new class_5794.class_5795(block);
        class_5794 family = MAP.put(block, builder.method_33481());
        if (family != null) {
            throw new IllegalStateException("Duplicate family definition for " + class_7923.field_41175.method_10221(block));
        } else {
            return builder;
        }
    }

    public static Stream<class_5794> getAllFamilies() {
        return MAP.values().stream();
    }

    @Nullable
    public static class_5794 getFamily(class_2248 base) {
        return MAP.get(base);
    }
}