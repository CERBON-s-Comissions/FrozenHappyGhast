package com.blackgear.vanillabackport.core.data.tags;

import com.blackgear.platform.common.data.TagRegistry;
import com.blackgear.vanillabackport.core.VanillaBackport;
import net.minecraft.class_6862;
import net.minecraft.class_7924;
import net.minecraft.class_8110;

public class ModDamageTypeTags {
    public static final TagRegistry<class_8110> TAGS = TagRegistry.create(class_7924.field_42534, VanillaBackport.NAMESPACE);

    public static final class_6862<class_8110> SULFUR_CUBE_WITH_BLOCK_IMMUNE_TO = TAGS.register("sulfur_cube_with_block_immune_to");
    public static final class_6862<class_8110> NO_KNOCKBACK = TAGS.register("no_knockback");
}