package com.blackgear.vanillabackport.core.data;

import net.minecraft.class_2960;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

public class ModBuiltInLootTables {
    // ENTITY LOOT
    public static final class_5321<class_52> CHICKEN_LAY = register("gameplay/chicken_lay");
    
    // CHEST LOOT
    public static final class_5321<class_52> ABANDONED_CAMP_BARREL = register("barrels/abandoned_camp_barrel");
    public static final class_5321<class_52> ABANDONED_CAMP_COMMON_CHEST = register("chests/abandoned_camp_common_chest");
    public static final class_5321<class_52> ABANDONED_CAMP_SECRET_CHEST = register("chests/abandoned_camp_secret_chest");
    
    private static class_5321<class_52> register(String location) {
        return class_5321.method_29179(class_7924.field_50079, class_2960.method_60656(location));
    }
}