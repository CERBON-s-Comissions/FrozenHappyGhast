package com.blackgear.vanillabackport.core.mixin.client.extension;

import com.blackgear.vanillabackport.client.api.modules.mob_rendering.LivingRendererAccess;
import net.minecraft.class_1309;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import net.minecraft.class_583;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_922.class)
public abstract class LivingEntityRendererMixin<T extends class_1309, M extends class_583<T>> implements LivingRendererAccess<T, M> {
    @Unique protected M defaultModel;

    @Inject(method = "<init>", at = @At("TAIL"))
    private void vb$init(class_5617.class_5618 context, M model, float shadowRadius, CallbackInfo ci) {
        this.defaultModel = model;
    }
    
    @Override
    public M getDefaultModel() {
        return this.defaultModel;
    }
    
    @Inject(method = "render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V", at = @At("HEAD"))
    private void vb$render(T entity, float entityYaw, float partialTicks, class_4587 poseStack, class_4597 buffer, int packedLight, CallbackInfo ci) {
        this.onRender(entity, entityYaw, partialTicks, poseStack, buffer, packedLight);
    }
}