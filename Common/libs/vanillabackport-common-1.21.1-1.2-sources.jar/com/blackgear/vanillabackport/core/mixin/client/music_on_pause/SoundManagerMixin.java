package com.blackgear.vanillabackport.core.mixin.client.music_on_pause;

import com.blackgear.vanillabackport.client.api.modules.music_on_pause.MusicTickAccess;
import net.minecraft.class_1140;
import net.minecraft.class_1144;
import net.minecraft.class_3419;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_1144.class)
public class SoundManagerMixin implements MusicTickAccess {
    @Shadow @Final private class_1140 soundEngine;
    
    @Override
    public void pauseAllExcept(class_3419... source) {
        ((MusicTickAccess) this.soundEngine).pauseAllExcept(source);
    }
}