package com.blackgear.vanillabackport.core.mixin.client.sound_extension;

import com.blackgear.vanillabackport.common.api.extensions.SoundExtensions;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_638;
import net.minecraft.class_6880;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_638.class)
public abstract class ClientLevelMixin implements SoundExtensions {
    @Shadow protected abstract void playSound(double x, double y, double z, class_3414 soundEvent, class_3419 source, float volume, float pitch, boolean distanceDelay, long seed);
    @Shadow @Final private class_310 minecraft;
    
    @Override
    public void playSeededSound(@Nullable class_1297 except, double x, double y, double z, class_6880<class_3414> sound, class_3419 source, float volume, float pitch, long seed) {
        if (except == this.minecraft.field_1724) {
            this.playSound(x, y, z, sound.comp_349(), source, volume, pitch, false, seed);
        }
    }
}