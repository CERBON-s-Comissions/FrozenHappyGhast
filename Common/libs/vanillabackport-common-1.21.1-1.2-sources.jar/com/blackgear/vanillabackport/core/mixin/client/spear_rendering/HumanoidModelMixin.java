package com.blackgear.vanillabackport.core.mixin.client.spear_rendering;

import com.blackgear.vanillabackport.common.api.extensions.entity.arms.ArmPoses;
import com.blackgear.vanillabackport.common.api.extensions.entity.spear.SpearSwingTracker;
import com.blackgear.vanillabackport.common.level.components.SwingAnimation;
import com.blackgear.vanillabackport.common.level.components.SwingAnimationType;
import com.blackgear.vanillabackport.common.level.items.spear.SpearAnimations;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_4592;
import net.minecraft.class_572;
import net.minecraft.class_630;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_572.class) @SuppressWarnings("unchecked")
public abstract class HumanoidModelMixin<T extends class_1309> extends class_4592<T> {
    @Shadow public class_572.class_573 rightArmPose;
    @Shadow public class_572.class_573 leftArmPose;
    
    @Shadow @Final public class_630 rightArm;
    @Shadow @Final public class_630 leftArm;
    @Shadow @Final public class_630 head;
    @Shadow @Final public class_630 body;
    
    @Inject(method = "poseRightArm", at = @At("HEAD"), cancellable = true)
    private void vb$poseRightArm(T entity, CallbackInfo ci) {
        if (this.rightArmPose == ArmPoses.SPEAR.get()) {
            SpearAnimations.thirdPersonHandUse(
                (class_572<T>)(Object)this,
                this.rightArm,
                this.head,
                class_1306.field_6183,
                entity.method_6068() == class_1306.field_6183 ? entity.method_6047() : entity.method_6079(),
                entity
            );
            ci.cancel();
        }
    }
    
    @Inject(method = "poseLeftArm", at = @At("HEAD"), cancellable = true)
    private void vb$poseLeftArm(T entity, CallbackInfo ci) {
        if (this.leftArmPose == ArmPoses.SPEAR.get()) {
            SpearAnimations.thirdPersonHandUse(
                (class_572<T>)(Object)this,
                this.leftArm,
                this.head,
                class_1306.field_6182,
                entity.method_6068() == class_1306.field_6182 ? entity.method_6047() : entity.method_6079(),
                entity
            );
            ci.cancel();
        }
    }
    
    @Inject(method = "setupAttackAnimation", at = @At("HEAD"), cancellable = true)
    private void vb$attackAnimation(T entity, float ageInTicks, CallbackInfo ci) {
        if (this.field_3447 <= 0.0F) return;
        if (entity instanceof SpearSwingTracker tracker && !tracker.vb$isAttackSwing()) return;
        
        class_1268 hand = entity.field_6266;
        if (hand == null) return;
        class_1799 heldItem = entity.method_5998(hand);
        
        SwingAnimation animation = SwingAnimation.get(heldItem);
        if (animation != null && animation.type() == SwingAnimationType.STAB) {
            class_1306 attackArm = (hand == class_1268.field_5808)
                ? entity.method_6068()
                : entity.method_6068().method_5928();
            
            SpearAnimations.thirdPersonAttackHand((class_572<T>)(Object)this, this.field_3447, attackArm);
            ci.cancel();
        }
    }
}