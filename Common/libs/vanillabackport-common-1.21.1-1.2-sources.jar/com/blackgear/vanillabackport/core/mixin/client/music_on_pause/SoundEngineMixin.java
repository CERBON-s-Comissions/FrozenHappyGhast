package com.blackgear.vanillabackport.core.mixin.client.music_on_pause;

import com.blackgear.vanillabackport.client.api.modules.music_on_pause.MusicTickAccess;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1113;
import net.minecraft.class_1140;
import net.minecraft.class_3419;
import net.minecraft.class_4235;

@Mixin(class_1140.class)
public abstract class SoundEngineMixin implements MusicTickAccess {
    @Shadow private boolean loaded;
    @Shadow @Final private Map<class_1113, class_4235.class_4236> instanceToChannel;
    @Shadow protected abstract float calculateVolume(class_1113 sound);
    
    @Unique private boolean vb$isReallyPaused = false;
    
    @Override
    public void pauseAllExcept(class_3419... sources) {
        if (this.loaded) {
            this.vb$isReallyPaused = true;
            List<class_3419> whitelist = List.of(sources);
            
            for (Map.Entry<class_1113, class_4235.class_4236> entry : this.instanceToChannel.entrySet()) {
                class_1113 sound = entry.getKey();
                if (!whitelist.contains(sound.method_4774())) {
                    entry.getValue().method_19735(channel -> {
                        channel.method_19653();
                        channel.method_19647(0.0F);
                    });
                }
            }
        }
    }
    
    @Inject(method = "resume", at = @At("HEAD"))
    private void vb$onResume(CallbackInfo ci) {
        if (this.vb$isReallyPaused) {
            this.vb$isReallyPaused = false;
            
            for (Map.Entry<class_1113, class_4235.class_4236> entry : this.instanceToChannel.entrySet()) {
                class_1113 sound = entry.getKey();
                if (sound.method_4774() != class_3419.field_15253) {
                    float volume = this.calculateVolume(sound);
                    entry.getValue().method_19735(channel -> {
                        channel.method_19647(volume);
                        channel.method_19654();
                    });
                }
            }
        }
    }
}