package com.blackgear.vanillabackport.core.mixin.client.spear_behavior;

import com.blackgear.platform.core.networking.PayloadDistributor;
import com.blackgear.vanillabackport.common.api.extensions.entity.spear.PlayerSpearHandler;
import com.blackgear.vanillabackport.common.api.extensions.entity.spear.ServerSpearHandler;
import com.blackgear.vanillabackport.common.api.extensions.entity.spear.SpearSwingTracker;
import com.blackgear.vanillabackport.common.level.components.AttackRange;
import com.blackgear.vanillabackport.common.level.components.PiercingWeapon;
import com.blackgear.vanillabackport.core.network.ServerboundUpdateSpearSwingPacket;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_239;
import net.minecraft.class_310;
import net.minecraft.class_636;
import net.minecraft.class_638;
import net.minecraft.class_746;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_310.class)
public abstract class MinecraftMixin {
    @Shadow @Nullable public class_636 gameMode;
    @Shadow @Nullable public class_239 hitResult;
    @Shadow @Nullable public class_746 player;
    @Shadow @Nullable public class_638 level;
    @Shadow protected int missTime;
    
    @Inject(
        method = "startAttack",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/item/ItemStack;isItemEnabled(Lnet/minecraft/world/flag/FeatureFlagSet;)Z"
        ),
        cancellable = true
    )
    private void vb$startAttack(CallbackInfoReturnable<Boolean> cir) {
        if (this.player == null || this.level == null || this.gameMode == null) return;
        class_1799 stack = this.player.method_5998(class_1268.field_5808);
        PiercingWeapon weapon = PiercingWeapon.get(stack);
        
        if (weapon != null) {
            if (((PlayerSpearHandler) this.player).vb$cannotAttackWithItem(stack, 0)) {
                cir.setReturnValue(false);
                return;
            }
            
            ((ServerSpearHandler) this.gameMode).piercingAttack(weapon);
            this.player.method_6104(class_1268.field_5808);
            
            cir.setReturnValue(true);
        }
    }
    
    @WrapOperation(
        method = "startAttack",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/multiplayer/MultiPlayerGameMode;attack(Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/entity/Entity;)V"
        )
    )
    private void vb$applyAttackRange(class_636 instance, class_1657 player, class_1297 target, Operation<Void> original) {
        if (this.player != null && this.hitResult != null) {
            class_1799 stack = this.player.method_5998(class_1268.field_5808);
            AttackRange range = AttackRange.get(stack);
            
            if (range == null || range.isInRange(this.player, this.hitResult.method_17784())) {
                original.call(instance, player, target);
            }
        } else {
            original.call(instance, player, target);
        }
    }
    
    @Inject(method = "continueAttack", at = @At("HEAD"), cancellable = true)
    private void vb$continueAttack(boolean down, CallbackInfo ci) {
        if (!down) {
            this.missTime = 0;
        }
        
        if (this.player != null) {
            class_1799 stack = this.player.method_5998(class_1268.field_5808);
            if (PiercingWeapon.get(stack) != null) {
                ci.cancel();
            }
        }
    }
    
    @Inject(method = "startAttack", at = @At("HEAD"))
    private void vb$onStartAttack(CallbackInfoReturnable<Boolean> cir) {
        if (this.player != null) {
            ((SpearSwingTracker) this.player).vb$setAttackSwing(true);
            PayloadDistributor.sendToServer(new ServerboundUpdateSpearSwingPacket(true));
        }
    }
    
    @Inject(method = "startUseItem", at = @At("HEAD"))
    private void vb$onStartUseItem(CallbackInfo ci) {
        if (this.player != null) {
            ((SpearSwingTracker) this.player).vb$setAttackSwing(false);
            PayloadDistributor.sendToServer(new ServerboundUpdateSpearSwingPacket(false));
        }
    }
}