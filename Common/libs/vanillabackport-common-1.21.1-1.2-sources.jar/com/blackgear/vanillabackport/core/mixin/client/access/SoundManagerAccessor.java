package com.blackgear.vanillabackport.core.mixin.client.access;

import net.minecraft.class_1140;
import net.minecraft.class_1144;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1144.class)
public interface SoundManagerAccessor {
    @Accessor
    class_1140 getSoundEngine();
}