package com.blackgear.vanillabackport.core.mixin.client.access;

import net.minecraft.class_1761;
import net.minecraft.class_481;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_481.class)
public interface CreativeModeInventoryScreenAccessor {
    @Accessor
    static class_1761 getSelectedTab() {
        throw new UnsupportedOperationException();
    }
}
