package com.blackgear.vanillabackport.core.mixin.client.access;

import net.minecraft.class_324;
import net.minecraft.class_756;
import net.minecraft.class_776;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_776.class)
public interface BlockRenderDispatcherAccessor {
    @Accessor class_324 getBlockColors();

    @Accessor class_756 getBlockEntityRenderer();
}