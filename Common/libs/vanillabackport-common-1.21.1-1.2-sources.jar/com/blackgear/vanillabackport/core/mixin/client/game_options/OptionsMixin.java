package com.blackgear.vanillabackport.core.mixin.client.game_options;

import com.blackgear.vanillabackport.client.api.modules.music_frequency.MusicFrequency;
import com.blackgear.vanillabackport.client.api.modules.music_frequency.MusicFrequencyAccess;
import com.blackgear.vanillabackport.client.api.modules.music_toast.MusicToastAccess;
import com.blackgear.vanillabackport.client.api.modules.music_toast.MusicToastDisplayState;
import com.blackgear.vanillabackport.client.api.modules.options.OptionsAccess;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Arrays;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_7172;
import net.minecraft.class_7919;

@Mixin(class_315.class)
public class OptionsMixin implements OptionsAccess {
    @Shadow protected class_310 minecraft;
    
    @Unique private class_7172<MusicFrequency> vb$musicFrequency;
    @Unique private class_7172<MusicToastDisplayState> vb$musicToast;
    
    @Override
    public class_7172<MusicFrequency> musicFrequency() {
        if (this.vb$musicFrequency == null) {
            this.vb$musicFrequency = new class_7172<>(
                "options.music_frequency",
                class_7172.method_42717(class_2561.method_43471("options.music_frequency.tooltip")),
                (caption, value) -> value.caption(),
                new class_7172.class_7173<>(Arrays.asList(MusicFrequency.values()), MusicFrequency.CODEC),
                MusicFrequency.DEFAULT,
                value -> {
                    if (this.minecraft != null && this.minecraft.method_1538() instanceof MusicFrequencyAccess access) {
                        access.setMinutesBetweenSongs(value);
                    }
                }
            );
        }
        return this.vb$musicFrequency;
    }
    
    @Override
    public class_7172<MusicToastDisplayState> musicToast() {
        if (this.vb$musicToast == null) {
            this.vb$musicToast = new class_7172<>(
                "options.musicToast",
                value -> class_7919.method_47407(value.tooltip()),
                (caption, value) -> value.text(),
                new class_7172.class_7173<>(Arrays.asList(MusicToastDisplayState.values()), MusicToastDisplayState.CODEC),
                MusicToastDisplayState.NEVER,
                value -> {
                    if (this.minecraft != null && this.minecraft.method_1566() instanceof MusicToastAccess access) {
                        access.setMusicToastDisplayState(value);
                    }
                }
            );
        }
        return this.vb$musicToast;
    }
    
    @Inject(method = "processOptions", at = @At("TAIL"))
    private void vb$processCustomOptions(class_315.class_5823 access, CallbackInfo ci) {
        access.method_42570("musicToast", this.musicToast());
        access.method_42570("musicFrequency", this.musicFrequency());
    }
}