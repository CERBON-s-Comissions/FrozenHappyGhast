package com.blackgear.vanillabackport.core.mixin.client.controllable_mount_effects;

import com.blackgear.vanillabackport.common.level.entities.mob.animal.happy_ghast.HappyGhast;
import net.minecraft.class_1297;
import net.minecraft.class_1922;
import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_4184.class)
public abstract class CameraMixin {
    @Shadow protected abstract void move(float zoom, float dy, float dx);
    @Shadow protected abstract float getMaxZoom(float maxZoom);

    @Inject(
        method = "setup",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/Camera;getMaxZoom(F)F"
        ),
        cancellable = true
    )
    private void onCameraSetup(class_1922 level, class_1297 entity, boolean detached, boolean thirdPersonReverse, float partialTick, CallbackInfo ci) {
        if (entity.method_5765() && entity.method_5854() instanceof HappyGhast) {
            this.move(-this.getMaxZoom(8.0F), 0.0F, 0.0F);
            ci.cancel();
        }
    }
}