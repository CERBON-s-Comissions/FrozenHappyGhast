package com.blackgear.vanillabackport.core.mixin.client.game_options;

import com.blackgear.vanillabackport.client.api.modules.options.OptionsAccess;
import net.minecraft.class_2561;
import net.minecraft.class_315;
import net.minecraft.class_437;
import net.minecraft.class_443;
import net.minecraft.class_4667;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_443.class)
public abstract class SoundOptionsScreenMixin extends class_4667 {
    public SoundOptionsScreenMixin(class_437 lastScreen, class_315 options, class_2561 title) {
        super(lastScreen, options, title);
    }
    
    @Inject(method = "addOptions", at = @At("TAIL"))
    private void a(CallbackInfo ci) {
        OptionsAccess access = (OptionsAccess) this.field_21336;
        this.field_51824.method_20408(access.musicFrequency(), access.musicToast());
    }
}