package com.blackgear.vanillabackport.core.mixin.client.music_toast;

import com.blackgear.vanillabackport.client.api.modules.music_toast.MusicToastAccess;
import com.blackgear.vanillabackport.client.api.modules.music_toast.MusicToastDisplayState;
import com.blackgear.vanillabackport.client.api.modules.music_toast.NowPlayingToast;
import com.blackgear.vanillabackport.client.api.modules.music_toast.ToastInstance;
import com.blackgear.vanillabackport.client.api.modules.options.OptionsAccess;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3419;
import net.minecraft.class_368;
import net.minecraft.class_374;
import net.minecraft.class_433;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_374.class)
public abstract class ToastComponentMixin implements MusicToastAccess {
    @Shadow @Final class_310 minecraft;
    
    @Unique private ToastInstance<NowPlayingToast> nowPlayingToast;
    
    @Inject(method = "render", at = @At("TAIL"))
    private void onRenderTail(class_332 graphics, CallbackInfo ci) {
        if (this.minecraft.field_1690.field_1842) return;
        
        if (this.minecraft.field_1690 instanceof OptionsAccess access && access.musicToast() != null) {
            MusicToastDisplayState state = access.musicToast().method_41753();
            
            if (this.nowPlayingToast == null && state != MusicToastDisplayState.NEVER) {
                this.initializeMusicToast(state);
            }
            
            if (this.nowPlayingToast != null) {
                this.nowPlayingToast.update();
                
                if (state.renderToast() && (this.minecraft.field_1755 == null || !(this.minecraft.field_1755 instanceof class_433))) {
                    this.nowPlayingToast.render(graphics, graphics.method_51421());
                }
            }
        }
    }
    
    @Override
    public void showNowPlayingToast() {
        if (this.nowPlayingToast == null && this.minecraft.field_1690 instanceof OptionsAccess access && access.musicToast() != null) {
            this.initializeMusicToast(access.musicToast().method_41753());
        }
        
        if (this.nowPlayingToast != null) {
            this.nowPlayingToast.resetToast();
            this.nowPlayingToast.getToast().showToast(this.minecraft.field_1690);
        }
    }
    
    @Override
    public void hideNowPlayingToast() {
        if (this.nowPlayingToast != null) {
            this.nowPlayingToast.getToast().setWantedVisibility(class_368.class_369.field_2209);
        }
    }
    
    @Override
    public void initializeMusicToast(MusicToastDisplayState state) {
        if (this.nowPlayingToast != null) return;
        
        class_374 component = (class_374) (Object) this;
        switch (state) {
            case PAUSE:
            case PAUSE_AND_TOAST:
                this.nowPlayingToast = new ToastInstance<>(component, new NowPlayingToast(), 0);
                break;
        }
    }
    
    @Override
    public void setMusicToastDisplayState(MusicToastDisplayState state) {
        class_374 component = (class_374) (Object) this;
        switch (state) {
            case PAUSE:
                this.nowPlayingToast = new ToastInstance<>(component, new NowPlayingToast(), 0);
                break;
            case PAUSE_AND_TOAST:
                this.nowPlayingToast = new ToastInstance<>(component, new NowPlayingToast(), 0);
                if (ToastInstance.getFinalSoundSourceVolume(this.minecraft.field_1690, class_3419.field_15253) > 0.0F) {
                    this.nowPlayingToast .getToast().showToast(this.minecraft.field_1690);
                }
                break;
            case NEVER:
                this.nowPlayingToast = null;
        }
    }
}