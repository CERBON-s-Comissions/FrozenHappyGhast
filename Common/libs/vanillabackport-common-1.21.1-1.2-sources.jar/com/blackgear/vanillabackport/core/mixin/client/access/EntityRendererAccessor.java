package com.blackgear.vanillabackport.core.mixin.client.access;

import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_897;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_897.class)
public interface EntityRendererAccessor {
    @Invoker <T extends class_1297> int callGetBlockLightLevel(T entity, class_2338 pos);
}