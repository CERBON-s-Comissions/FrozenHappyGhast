package com.blackgear.vanillabackport.core.mixin.client.end_flashes;

import com.blackgear.vanillabackport.client.api.modules.end_flashes.EndFlashRenderer;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_761.class)
public abstract class LevelRendererMixin {
    @Shadow @Final private class_310 minecraft;
    
    @Inject(method = "renderEndSky", at = @At("RETURN"))
    private void vb$renderEndFlash(class_4587 poseStack, CallbackInfo ci) {
        EndFlashRenderer.render(poseStack, this.minecraft);
    }
}