package com.blackgear.vanillabackport.core.mixin.client.end_flashes;

import com.blackgear.vanillabackport.client.api.modules.end_flashes.EndFlashGetter;
import com.blackgear.vanillabackport.client.api.modules.end_flashes.EndFlashRenderer;
import com.blackgear.vanillabackport.client.api.modules.end_flashes.EndFlashState;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.function.BooleanSupplier;
import java.util.function.Supplier;
import net.minecraft.class_1937;
import net.minecraft.class_2874;
import net.minecraft.class_310;
import net.minecraft.class_3695;
import net.minecraft.class_5269;
import net.minecraft.class_5294;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_634;
import net.minecraft.class_638;
import net.minecraft.class_6880;
import net.minecraft.class_761;

@Mixin(class_638.class)
public abstract class ClientLevelMixin extends class_1937 implements EndFlashGetter {
    @Shadow @Final private class_310 minecraft;
    @Shadow public abstract class_5294 effects();
    
    @Unique @Nullable private EndFlashState vb$endFlashState;
    
    protected ClientLevelMixin(class_5269 levelData, class_5321<class_1937> dimension, class_5455 registryAccess, class_6880<class_2874> dimensionTypeRegistration, Supplier<class_3695> profiler, boolean isClientSide, boolean isDebug, long biomeZoomSeed, int maxChainedNeighborUpdates) {
        super(levelData, dimension, registryAccess, dimensionTypeRegistration, profiler, isClientSide, isDebug, biomeZoomSeed, maxChainedNeighborUpdates);
    }
    
    @Inject(method = "<init>", at = @At("TAIL"))
    private void vb$setup(class_634 connection, class_638.class_5271 clientLevelData, class_5321<class_1937> dimension, class_6880<class_2874> dimensionType, int viewDistance, int serverSimulationDistance, Supplier<?> profiler, class_761 levelRenderer, boolean isDebug, long biomeZoomSeed, CallbackInfo ci) {
        this.vb$endFlashState = this.effects().method_29992() == class_5294.class_5401.field_25641 ? new EndFlashState() : null;
    }
    
    @Override
    public @Nullable EndFlashState endFlashState() {
        return this.vb$endFlashState;
    }
    
    @Inject(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/profiling/ProfilerFiller;push(Ljava/lang/String;)V", shift = At.Shift.BEFORE))
    private void vb$tick(BooleanSupplier hasTimeLeft, CallbackInfo ci) {
        EndFlashRenderer.tick(this.minecraft, (class_638) (Object) this, this.vb$endFlashState);
    }
}