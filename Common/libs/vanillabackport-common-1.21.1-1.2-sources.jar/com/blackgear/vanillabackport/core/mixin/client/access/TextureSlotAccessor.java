package com.blackgear.vanillabackport.core.mixin.client.access;

import net.minecraft.class_4945;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_4945.class)
public interface TextureSlotAccessor {
    @Invoker("create")
    static class_4945 create(String name) {
        throw new IllegalStateException("");
    }
}