package com.blackgear.vanillabackport.core.mixin.client.spear_rendering;

import com.blackgear.vanillabackport.common.api.extensions.entity.arms.ItemUseAnimations;
import com.blackgear.vanillabackport.common.api.extensions.entity.spear.PlayerSpearHandler;
import com.blackgear.vanillabackport.common.api.extensions.entity.spear.MobSpearHandler;
import com.blackgear.vanillabackport.common.api.extensions.entity.spear.SpearSwingTracker;
import com.blackgear.vanillabackport.common.level.components.SwingAnimation;
import com.blackgear.vanillabackport.common.level.items.spear.SpearAnimations;
import com.blackgear.vanillabackport.common.level.components.SwingAnimationType;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_742;
import net.minecraft.class_746;
import net.minecraft.class_759;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_759.class)
public abstract class ItemInHandRendererMixin {
    @Unique private boolean vb$performStabAnimation = false;
    
    @Inject(
        method = "renderArmWithItem",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/item/ItemStack;getUseAnimation()Lnet/minecraft/world/item/UseAnim;",
            ordinal = 0
        )
    )
    private void vb$spearChargeAnimation(
        class_742 player, float partialTicks, float pitch, class_1268 hand, float swingProgress,
        class_1799 stack, float equippedProgress, class_4587 poseStack, class_4597 buffer, int combinedLight,
        CallbackInfo ci,
        @Local(ordinal = 0) class_1306 arm,
        @Local(ordinal = 1) int invert
    ) {
        if (stack.method_7976() == ItemUseAnimations.REAL_SPEAR.get()) {
            poseStack.method_46416((float) invert * 0.56F, -0.52F, -0.72F);
            float timeHeld = (float) stack.method_7935(player) - ((float) player.method_6014() - partialTicks + 1.0F);
            SpearAnimations.firstPersonUse(((MobSpearHandler) player).vb$getTicksSinceLastKineticHitFeedback(partialTicks), poseStack, timeHeld, arm, stack);
        }
    }
    
    @Inject(
        method = "renderArmWithItem",
        at = @At(
            value = "INVOKE",
            target = "Lcom/mojang/blaze3d/vertex/PoseStack;translate(FFF)V",
            ordinal = 12,
            shift = At.Shift.BEFORE
        )
    )
    private void vb$detectStabAnimation(
        class_742 player,
        float partialTicks,
        float pitch,
        class_1268 hand,
        float swingProgress,
        class_1799 stack,
        float equippedProgress,
        class_4587 poseStack,
        class_4597 buffer,
        int combinedLight,
        CallbackInfo ci
    ) {
        SwingAnimation animation = SwingAnimation.get(stack);
        if (animation == null) return;
        
        boolean isAttack = ((SpearSwingTracker) player).vb$isAttackSwing();
        this.vb$performStabAnimation = isAttack && animation.type() == SwingAnimationType.STAB;
    }
    
    @WrapOperation(
        method = "renderArmWithItem",
        at = @At(
            value = "INVOKE",
            target = "Lcom/mojang/blaze3d/vertex/PoseStack;translate(FFF)V",
            ordinal = 12
        )
    )
    private void vb$spearSwingTranslation(class_4587 instance, float x, float y, float z, Operation<Void> original) {
        if (!this.vb$performStabAnimation) {
            original.call(instance, x, y, z);
        }
    }
    
    @Inject(
        method = "renderArmWithItem",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/renderer/ItemInHandRenderer;applyItemArmTransform(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/world/entity/HumanoidArm;F)V",
            ordinal = 8,
            shift = At.Shift.AFTER
        )
    )
    private void vb$spearStabAnimation(
        class_742 player, float partialTicks, float pitch, class_1268 hand, float swingProgress,
        class_1799 stack, float equippedProgress, class_4587 poseStack, class_4597 buffer, int combinedLight,
        CallbackInfo ci,
        @Local(ordinal = 1) int invert
    ) {
        if (this.vb$performStabAnimation) {
            SpearAnimations.firstPersonAttack(swingProgress, poseStack, invert);
        }
    }
    
    @WrapOperation(
        method = "renderArmWithItem",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/renderer/ItemInHandRenderer;applyItemArmAttackTransform(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/world/entity/HumanoidArm;F)V",
            ordinal = 1
        )
    )
    private void vb$spearAttackTransform(class_759 instance, class_4587 poseStack, class_1306 arm, float swingProgress, Operation<Void> original) {
        if (!this.vb$performStabAnimation) {
            original.call(instance, poseStack, arm, swingProgress);
        }
    }
    
    @Inject(
        method = "renderArmWithItem",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/renderer/ItemInHandRenderer;applyItemArmAttackTransform(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/world/entity/HumanoidArm;F)V",
            ordinal = 1,
            shift = At.Shift.AFTER
        )
    )
    private void vb$spearAttackState(
        class_742 player,
        float partialTicks,
        float pitch,
        class_1268 hand,
        float swingProgress,
        class_1799 stack,
        float equippedProgress,
        class_4587 poseStack,
        class_4597 buffer,
        int combinedLight,
        CallbackInfo ci
    ) {
        this.vb$performStabAnimation = false;
    }
    
    @WrapOperation(
        method = "tick",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/player/LocalPlayer;getAttackStrengthScale(F)F"
        )
    )
    private float vb$itemSwapScale(class_746 player, float partialTicks, Operation<Float> original) {
        return ((PlayerSpearHandler) player).vb$getItemSwapScale(partialTicks);
    }
}