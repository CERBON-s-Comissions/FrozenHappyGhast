package com.blackgear.vanillabackport.core.mixin.client.music_toast;

import com.blackgear.vanillabackport.client.api.modules.music_toast.MusicToastAccess;
import net.minecraft.class_1142;
import net.minecraft.class_310;
import net.minecraft.class_5195;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1142.class)
public abstract class MusicManagerMixin {
    @Shadow @Final private class_310 minecraft;
    
    @Inject(
        method = "startPlaying",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/sounds/SoundManager;play(Lnet/minecraft/client/resources/sounds/SoundInstance;)V"
        )
    )
    private void vb$updateVolume(class_5195 selector, CallbackInfo ci) {
        ((MusicToastAccess) this.minecraft.method_1566()).showNowPlayingToast();
    }
    
    @Inject(method = "stopPlaying()V", at = @At("TAIL"))
    private void vb$onStopPlaying(CallbackInfo ci) {
        ((MusicToastAccess) this.minecraft.method_1566()).hideNowPlayingToast();
    }
}