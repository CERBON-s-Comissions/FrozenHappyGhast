package com.blackgear.vanillabackport.core.mixin.client.spear_behavior;

import com.blackgear.vanillabackport.common.level.components.AttackRange;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1533;
import net.minecraft.class_1657;
import net.minecraft.class_1675;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_5134;
import net.minecraft.class_757;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_757.class)
public class GameRendererMixin {
    @Shadow @Final class_310 minecraft;
    
    @Inject(method = "pick(F)V", at = @At("HEAD"), cancellable = true)
    private void vb$onPick(float partialTicks, CallbackInfo ci) {
        class_1297 cameraEntity = this.minecraft.method_1560();
        if (cameraEntity != null && this.minecraft.field_1687 != null && this.minecraft.field_1724 != null) {
            class_1799 activeStack = this.minecraft.field_1724.method_6047();
            AttackRange attackRange = AttackRange.get(activeStack);
            
            if (attackRange != null) {
                ci.cancel();
                
                this.minecraft.method_16011().method_15396("pick");
                
                class_239 hitResult = vb$raycastHitResult(this.minecraft.field_1724, partialTicks, cameraEntity, attackRange);
                this.minecraft.field_1765 = hitResult;
                
                if (hitResult instanceof class_3966 entityHitResult) {
                    class_1297 entity = entityHitResult.method_17782();
                    if (entity instanceof class_1309 || entity instanceof class_1533) {
                        this.minecraft.field_1692 = entity;
                    } else {
                        this.minecraft.field_1692 = null;
                    }
                } else {
                    this.minecraft.field_1692 = null;
                }
                
                this.minecraft.method_16011().method_15407();
            }
        }
    }
    
    @Unique
    private class_239 vb$raycastHitResult(class_1657 player, float partialTicks, class_1297 cameraEntity, AttackRange itemAttackRange) {
        double blockReach = player.method_45325(class_5134.field_47758);
        class_239 hitResult = null;
        
        if (itemAttackRange != null) {
            hitResult = itemAttackRange.getClosestHit(cameraEntity, partialTicks, class_1297::method_5863);
            if (hitResult instanceof class_3965) {
                hitResult = vb$filterHitResult(hitResult, cameraEntity.method_5836(partialTicks), blockReach);
            }
        }
        
        if (hitResult == null || hitResult.method_17783() == class_239.class_240.field_1333) {
            double entityReach = player.method_45325(class_5134.field_47759);
            hitResult = vb$pick(cameraEntity, blockReach, entityReach, partialTicks);
        }
        
        return hitResult;
    }
    
    @Unique
    private static class_239 vb$pick(class_1297 cameraEntity, double blockReach, double entityReach, float partialTicks) {
        double maxDistance = Math.max(blockReach, entityReach);
        double maxDistanceSq = maxDistance * maxDistance;
        class_243 from = cameraEntity.method_5836(partialTicks);
        class_239 blockHitResult = cameraEntity.method_5745(maxDistance, partialTicks, false);
        double blockDistanceSq = blockHitResult.method_17784().method_1025(from);
        
        if (blockHitResult.method_17783() != class_239.class_240.field_1333) {
            maxDistanceSq = blockDistanceSq;
            maxDistance = Math.sqrt(blockDistanceSq);
        }
        
        class_243 direction = cameraEntity.method_5828(partialTicks);
        class_243 to = from.method_1031(direction.field_1352 * maxDistance, direction.field_1351 * maxDistance, direction.field_1350 * maxDistance);
        var box = cameraEntity.method_5829().method_18804(direction.method_1021(maxDistance)).method_1009(1.0, 1.0, 1.0);
        
        class_3966 entityHitResult = class_1675.method_18075(cameraEntity, from, to, box, class_1297::method_5863, maxDistanceSq);
        
        return entityHitResult != null && entityHitResult.method_17784().method_1025(from) < blockDistanceSq
            ? vb$filterHitResult(entityHitResult, from, entityReach)
            : vb$filterHitResult(blockHitResult, from, blockReach);
    }
    
    @Unique
    private static class_239 vb$filterHitResult(class_239 hitResult, class_243 from, double maxRange) {
        class_243 hitLocation = hitResult.method_17784();
        if (!hitLocation.method_24802(from, maxRange)) {
            class_243 location = hitResult.method_17784();
            class_2350 direction = class_2350.method_10142(location.field_1352 - from.field_1352, location.field_1351 - from.field_1351, location.field_1350 - from.field_1350);
            return class_3965.method_17778(location, direction, class_2338.method_49638(location));
        } else {
            return hitResult;
        }
    }
}
