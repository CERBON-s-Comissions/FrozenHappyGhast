package com.blackgear.vanillabackport.core.mixin.client.spear_rendering;

import com.blackgear.vanillabackport.common.api.extensions.entity.arms.ArmPoses;
import com.blackgear.vanillabackport.common.level.components.SwingAnimation;
import com.blackgear.vanillabackport.common.level.components.SwingAnimationType;
import com.blackgear.vanillabackport.common.level.items.spear.SpearAnimations;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_3881;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_572;
import net.minecraft.class_583;
import net.minecraft.class_811;
import net.minecraft.class_989;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_989.class)
public abstract class ItemInHandLayerMixin<T extends class_1309, M extends class_583<T> & class_3881> extends class_3887<T, M> {
    public ItemInHandLayerMixin(class_3883<T, M> renderer) {
        super(renderer);
    }

    @SuppressWarnings("unchecked")
    @Inject(
        method = "renderArmWithItem",
        at = @At(
            value = "INVOKE",
            target = "Lcom/mojang/blaze3d/vertex/PoseStack;translate(FFF)V",
            shift = At.Shift.AFTER
        )
    )
    private void vb$renderArm(
        class_1309 entity,
        class_1799 stack,
        class_811 displayContext,
        class_1306 arm,
        class_4587 pose,
        class_4597 buffer,
        int packedLight,
        CallbackInfo ci
    ) {
        class_583<T> model = this.method_17165();
        if (model instanceof class_572<?> parent) {
            var animation = SwingAnimation.get(stack);
            if (animation != null) {
                if (parent.field_3447 > 0.0F && entity.method_6068() == arm && animation.type() == SwingAnimationType.STAB) {
                    SpearAnimations.thirdPersonAttackItem((class_572<? super class_1309>) parent, entity, pose);
                }
                
                float ticksUsingItem = entity.method_6115() && entity.method_6058() == class_1268.field_5808 == (arm == entity.method_6068()) ? entity.method_6048() : 0.0F;
                if (ticksUsingItem != 0.0F) {
                    class_572.class_573 armPose = (arm == class_1306.field_6183 ? parent.field_3395 : parent.field_3399);
                    if (armPose == ArmPoses.SPEAR.get()) {
                        ArmPoses.SPEAR.animateUseItem((class_572<? super class_1309>) parent, entity, pose, ticksUsingItem, arm, stack);
                    }
                }
            }
        }
    }
}