package com.blackgear.vanillabackport.core.mixin.client.bundle_ui;

import com.blackgear.vanillabackport.client.api.modules.bundle_ui.BundleRenderHandler;
import net.minecraft.class_1735;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_465.class)
public abstract class AbstractContainerScreenMixin extends class_437 {
    @Shadow protected int imageWidth;
    
    protected AbstractContainerScreenMixin(class_2561 title) {
        super(title);
    }
    
    @Inject(method = "renderSlot", at = @At("HEAD"), cancellable = true)
    private void vb$renderBundleContents(class_332 guiGraphics, class_1735 slot, CallbackInfo ci) {
        if (BundleRenderHandler.renderBundleContents(guiGraphics, this.field_22793, slot, this.imageWidth)) {
            ci.cancel();
        }
    }
}