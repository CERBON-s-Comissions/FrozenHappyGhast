package com.blackgear.vanillabackport.core.mixin.client.access;

import net.minecraft.class_1113;
import net.minecraft.class_1142;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1142.class)
public interface MusicManagerAccessor {
    @Accessor
    class_1113 getCurrentMusic();
}
