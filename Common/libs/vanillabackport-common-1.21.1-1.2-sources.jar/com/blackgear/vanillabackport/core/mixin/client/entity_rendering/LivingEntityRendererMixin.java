package com.blackgear.vanillabackport.core.mixin.client.entity_rendering;

import com.blackgear.vanillabackport.client.api.modules.mob_rendering.DynamicMobRendererRegistry;
import com.blackgear.vanillabackport.client.api.modules.mob_rendering.SpecialMobRenderer;
import com.blackgear.vanillabackport.core.compat.ClientCompat;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import net.minecraft.class_583;
import net.minecraft.class_922;

@Mixin(value = class_922.class, priority = 500) @SuppressWarnings("unchecked")
public abstract class LivingEntityRendererMixin<T extends class_1309, M extends class_583<T>> {
    @Shadow protected M model;
    @Unique private SpecialMobRenderer<T, M> renderer;
    
    @Inject(method = "<init>", at = @At("TAIL"))
    private void vb$onInit(class_5617.class_5618 context, M model, float shadowRadius, CallbackInfo ci) {
        this.renderer = DynamicMobRendererRegistry.getRenderer((class_922<T, M>) (Object) this, context);
    }
    
    @WrapOperation(
        method = "getRenderType",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/renderer/entity/LivingEntityRenderer;getTextureLocation(Lnet/minecraft/world/entity/Entity;)Lnet/minecraft/resources/ResourceLocation;"
        ))
    private class_2960 vb$changeTexture(class_922<T, M> instance, class_1297 entity, Operation<class_2960> original) {
        class_2960 delegated = original.call(instance, entity);
        
        if (this.renderer != null && entity instanceof class_1309 living) {
            if (!ClientCompat.getNMLActiveRemodel(living)) {
                Optional<class_2960> texture = this.renderer.getTexture((T) living);
                if (texture.isPresent()) return texture.get();
            }
        }
        
        return delegated;
    }
    
    @WrapMethod(method = "render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V")
    private void vb$changeModel(T entity, float yaw, float partialTicks, class_4587 pose, class_4597 buffer, int light, Operation<Void> original) {
        if (this.renderer == null || ClientCompat.shouldBypassBabyModel(entity)) {
            original.call(entity, yaw, partialTicks, pose, buffer, light);
            return;
        }

        this.renderer.getModel(entity).ifPresentOrElse(modded -> {
            M vanilla = this.model;
            this.model = modded;
            try {
                original.call(entity, yaw, partialTicks, pose, buffer, light);
            } finally {
                this.model = vanilla;
            }
        }, () -> original.call(entity, yaw, partialTicks, pose, buffer, light));
    }
    
    @WrapOperation(
        method = "render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/renderer/entity/LivingEntityRenderer;scale(Lnet/minecraft/world/entity/LivingEntity;Lcom/mojang/blaze3d/vertex/PoseStack;F)V"
        ))
    private void vb$suppressScale(class_922<T, M> instance, T entity, class_4587 pose, float partialTicks, Operation<Void> original) {
        if (this.renderer == null || !this.renderer.suppressScale(entity)) {
            original.call(instance, entity, pose, partialTicks);
        }
    }
}