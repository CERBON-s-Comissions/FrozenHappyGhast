package com.blackgear.vanillabackport.core.mixin.client.music_on_pause;

import com.blackgear.vanillabackport.client.api.modules.music_on_pause.MusicTickAccess;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.class_1142;
import net.minecraft.class_1144;
import net.minecraft.class_310;
import net.minecraft.class_3419;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_310.class)
public class MinecraftMixin {
    @WrapOperation(method = "pauseGame", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/sounds/SoundManager;pause()V"))
    private void vb$dontPauseMusic(class_1144 instance, Operation<Void> original) {
        ((MusicTickAccess) instance).pauseAllExcept(class_3419.field_15253);
    }
    
    @WrapOperation(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/sounds/MusicManager;tick()V"))
    private void vb$forceMusicTick(class_1142 instance, Operation<Void> original) {
        instance.method_18669();
    }
}