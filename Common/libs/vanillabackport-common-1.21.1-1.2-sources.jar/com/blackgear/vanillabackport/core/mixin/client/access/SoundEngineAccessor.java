package com.blackgear.vanillabackport.core.mixin.client.access;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

import java.util.Map;
import net.minecraft.class_1113;
import net.minecraft.class_1140;
import net.minecraft.class_4235;

@Mixin(class_1140.class)
public interface SoundEngineAccessor {
    @Accessor Map<class_1113, class_4235.class_4236> getInstanceToChannel();
    @Accessor boolean isLoaded();
    @Invoker float callCalculateVolume(class_1113 instance);
}