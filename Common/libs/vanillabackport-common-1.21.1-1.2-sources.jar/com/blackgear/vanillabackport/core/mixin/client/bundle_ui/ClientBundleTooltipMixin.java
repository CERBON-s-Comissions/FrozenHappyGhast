package com.blackgear.vanillabackport.core.mixin.client.bundle_ui;

import com.blackgear.vanillabackport.client.api.modules.bundle_ui.BundleTooltipHandler;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5682;
import net.minecraft.class_5684;
import net.minecraft.class_9276;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_5682.class)
public abstract class ClientBundleTooltipMixin implements class_5684 {
    @Shadow @Final private class_9276 contents;
    @Unique private BundleTooltipHandler vb$handler;
    
    @Inject(method = "<init>", at = @At("TAIL"))
    private void vb$onInit(class_9276 contents, CallbackInfo ci) {
        this.vb$handler = new BundleTooltipHandler(this.contents);
        this.vb$handler.init(this.contents);
    }

    @Override
    public int method_32661() {
        return this.vb$handler.getHeight();
    }

    @Override
    public int method_32664(class_327 font) {
        return this.vb$handler.getWidth();
    }

    @Inject(method = "renderImage", at = @At("HEAD"), cancellable = true)
    private void vb$onRenderImage(class_327 font, int x, int y, class_332 graphics, CallbackInfo ci) {
        if (this.vb$handler.renderImage(font, x, y, graphics)) ci.cancel();
    }
}