package com.blackgear.vanillabackport.core.mixin.client.spear_rendering;

import com.blackgear.vanillabackport.common.level.components.SwingAnimation;
import com.blackgear.vanillabackport.common.level.components.SwingAnimationType;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.class_1543;
import net.minecraft.class_4896;
import net.minecraft.class_575;
import net.minecraft.class_630;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_575.class)
public abstract class IllagerModelMixin<T extends class_1543> {
    @WrapOperation(
        method = "setupAnim(Lnet/minecraft/world/entity/monster/AbstractIllager;FFFFF)V",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/model/AnimationUtils;animateZombieArms(Lnet/minecraft/client/model/geom/ModelPart;Lnet/minecraft/client/model/geom/ModelPart;ZFF)V"
        )
    )
    private void wrapAnimateArms(
        class_630 leftArm,
        class_630 rightArm,
        boolean isAggressive,
        float attackTime,
        float ageInTicks,
        Operation<Void> original,
        T entity
    ) {
        SwingAnimation animation = SwingAnimation.get(entity.method_6047());
        boolean animateAttack = animation != null && animation.type() == SwingAnimationType.STAB;
        if (!animateAttack) {
            original.call(leftArm, rightArm, isAggressive, attackTime, ageInTicks);
        } else {
            class_4896.method_32789(rightArm, leftArm, ageInTicks);
        }
    }
}