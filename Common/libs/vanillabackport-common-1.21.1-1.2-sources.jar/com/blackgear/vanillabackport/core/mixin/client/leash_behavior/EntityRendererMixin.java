package com.blackgear.vanillabackport.core.mixin.client.leash_behavior;

import com.blackgear.vanillabackport.common.api.modules.leash_behavior.LeashFeatureRenderer;
import com.blackgear.vanillabackport.common.api.modules.leash_behavior.LeashableCallback;
import com.blackgear.vanillabackport.core.ModChecker;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.class_1297;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4604;
import net.minecraft.class_5617;
import net.minecraft.class_897;
import net.minecraft.class_898;
import net.minecraft.class_9817;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_897.class)
public class EntityRendererMixin<T extends class_1297> {
    @Shadow @Final protected class_898 entityRenderDispatcher;
    @Unique private LeashFeatureRenderer<T> leashRenderer;

    @Inject(method = "<init>", at = @At("TAIL"))
    private void vb$init(class_5617.class_5618 context, CallbackInfo ci) {
        this.leashRenderer = new LeashFeatureRenderer<>(this.entityRenderDispatcher);
    }

    @Inject(method = "render", at = @At("HEAD"))
    private void renderAdditional(T entity, float entityYaw, float partialTick, class_4587 poseStack, class_4597 buffer, int packedLight, CallbackInfo ci) {
        if (!VanillaBackport.COMMON_CONFIG.hasModernLeashes.get()) return;
        if (!ModChecker.SABLE) this.leashRenderer.render(entity, partialTick, poseStack, buffer);
    }

    @Inject(method = "renderLeash", at = @At("HEAD"), cancellable = true)
    private <E extends class_1297 & class_9817> void vb$cancelVanillaLeash(E entity, float partialTick, class_4587 poseStack, class_4597 buffer, class_1297 leashHolder, CallbackInfo ci) {
        if (!VanillaBackport.COMMON_CONFIG.hasModernLeashes.get()) return;
        if (!ModChecker.SABLE && ((LeashableCallback) entity).vb$supportsQuadLeash()) ci.cancel();
    }
    
    @WrapOperation(
        method = "render",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/renderer/entity/EntityRenderer;renderLeash(Lnet/minecraft/world/entity/Entity;FLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;Lnet/minecraft/world/entity/Entity;)V"
        )
    )
    private void vb$wrapVanillaLeashRender(class_897<T> instance, T entity, float partialTick, class_4587 poseStack, class_4597 bufferSource, class_1297 leashHolder, Operation<Void> original) {
        if (!VanillaBackport.COMMON_CONFIG.hasModernLeashes.get()) return;
        if (!ModChecker.SABLE && ((LeashableCallback) entity).vb$supportsQuadLeash()) return;
        original.call(instance, entity, partialTick, poseStack, bufferSource, leashHolder);
    }

    @Inject(method = "shouldRender", at = @At("TAIL"), cancellable = true)
    private void vb$shouldRender(T entity, class_4604 camera, double camX, double camY, double camZ, CallbackInfoReturnable<Boolean> cir) {
        if (!VanillaBackport.COMMON_CONFIG.hasModernLeashes.get()) return;
        if (!ModChecker.SABLE) cir.setReturnValue(this.leashRenderer.shouldRender(entity, camera, cir.getReturnValue()));
    }
}