package com.blackgear.vanillabackport.core.mixin.client.spear_behavior;

import com.blackgear.vanillabackport.common.level.components.UseEffects;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.mojang.authlib.GameProfile;
import net.minecraft.class_638;
import net.minecraft.class_742;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_746.class)
public abstract class LocalPlayerMixin extends class_742 {
    public LocalPlayerMixin(class_638 clientLevel, GameProfile gameProfile) {
        super(clientLevel, gameProfile);
    }
    
    @ModifyExpressionValue(
        method = "aiStep",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/player/LocalPlayer;isSprinting()Z",
            ordinal = 0
        )
    )
    private boolean vb$preventSprinting(boolean isSprinting) {
        if (isSprinting && this.vb$isSlowDueToUsingItem()) {
            this.method_5728(false);
        }
        return isSprinting;
    }
    
    @ModifyExpressionValue(
        method = "aiStep",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/player/LocalPlayer;isUsingItem()Z",
            ordinal = 0
        )
    )
    private boolean vb$slowDownWhileUsingItem(boolean isUsing) {
        return isUsing && this.vb$isSlowDueToUsingItem();
    }
    
    @WrapOperation(
        method = "canStartSprinting",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/player/LocalPlayer;isUsingItem()Z"
        )
    )
    private boolean vb$canStartSprinting(class_746 instance, Operation<Boolean> original) {
        return this.vb$isSlowDueToUsingItem();
    }
    
    @Unique
    private boolean vb$isSlowDueToUsingItem() {
        return this.method_6115() && !UseEffects.get(this.field_6277).canSprint();
    }
}