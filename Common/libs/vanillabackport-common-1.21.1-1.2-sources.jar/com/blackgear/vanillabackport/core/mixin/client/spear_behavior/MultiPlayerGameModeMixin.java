package com.blackgear.vanillabackport.core.mixin.client.spear_behavior;

import com.blackgear.vanillabackport.common.api.extensions.entity.spear.ServerSpearHandler;
import com.blackgear.vanillabackport.common.api.extensions.entity.arms.PlayerActions;
import com.blackgear.vanillabackport.common.api.extensions.entity.spear.MobSpearHandler;
import com.blackgear.vanillabackport.common.level.components.PiercingWeapon;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2846;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_636.class)
public abstract class MultiPlayerGameModeMixin implements ServerSpearHandler {
    @Shadow protected abstract void ensureHasSentCarriedItem();
    @Shadow @Final private class_634 connection;
    @Shadow @Final private class_310 minecraft;
    
    @Override
    public void piercingAttack(PiercingWeapon piercingWeapon) {
        this.ensureHasSentCarriedItem();
        this.connection.method_52787(new class_2846(PlayerActions.STAB.get(), class_2338.field_10980, class_2350.field_11033));
        ((MobSpearHandler) this.minecraft.field_1724).vb$onAttack();
        ((MobSpearHandler) this.minecraft.field_1724).vb$postPiercingAttack();
        piercingWeapon.makeSound(this.minecraft.field_1724);
    }
}