package com.blackgear.vanillabackport.core.mixin.client.end_flashes;

import com.blackgear.vanillabackport.client.api.modules.end_flashes.EndFlashRenderer;
import net.minecraft.class_1011;
import net.minecraft.class_310;
import net.minecraft.class_5294;
import net.minecraft.class_638;
import net.minecraft.class_765;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = class_765.class, priority = 1100)
public class LightTextureMixin {
    @Shadow @Final private class_310 minecraft;
    @Shadow @Final private class_1011 lightPixels;
    
    @Unique private float vb$intensity;
    
    @Inject(method = "updateLightTexture", at = @At("HEAD"))
    private void vb$calculateLightIntensity(float partialTicks, CallbackInfo ci) {
        this.vb$intensity = EndFlashRenderer.calculateLightIntensity(this.minecraft, partialTicks);
    }
    
    @Inject(method = "updateLightTexture", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/texture/DynamicTexture;upload()V"))
    private void vb$applyEndFlashTint(float partialTicks, CallbackInfo ci) {
        class_638 level = this.minecraft.field_1687;
        if (level == null || level.method_28103().method_29992() != class_5294.class_5401.field_25641) {
            return;
        }
        
        EndFlashRenderer.applyLightTint(this.lightPixels, this.vb$intensity);
    }
}