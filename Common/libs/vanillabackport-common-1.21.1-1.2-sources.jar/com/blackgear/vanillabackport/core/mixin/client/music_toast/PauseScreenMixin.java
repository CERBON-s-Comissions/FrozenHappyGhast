package com.blackgear.vanillabackport.core.mixin.client.music_toast;

import com.blackgear.vanillabackport.client.api.modules.music_toast.NowPlayingToast;
import com.blackgear.vanillabackport.client.api.modules.music_toast.ToastInstance;
import com.blackgear.vanillabackport.client.api.modules.options.OptionsAccess;
import net.minecraft.class_2561;
import net.minecraft.class_315;
import net.minecraft.class_332;
import net.minecraft.class_3419;
import net.minecraft.class_433;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_433.class)
public class PauseScreenMixin extends class_437 {
    @Shadow @Final private boolean showPauseMenu;
    
    protected PauseScreenMixin(class_2561 title) {
        super(title);
    }
    
    @Inject(method = "render", at = @At(value = "TAIL"))
    private void vb$renderToast(class_332 graphics, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
        if (this.rendersNowPlayingToast()) {
            NowPlayingToast.tickMusicNotes();
            NowPlayingToast.renderToast(graphics, this.field_22793);
        }
    }
    
    @Unique
    private boolean rendersNowPlayingToast() {
        class_315 options = this.field_22787.field_1690;
        if (!(options instanceof OptionsAccess access)) return false;
        
        return access.musicToast().method_41753().renderInPauseScreen() && ToastInstance.getFinalSoundSourceVolume(options, class_3419.field_15253) > 0.0F && this.showPauseMenu;
    }
}