package com.blackgear.vanillabackport.core.mixin.client.controllable_mount_effects;

import com.blackgear.vanillabackport.client.level.sound.RidingEntitySoundInstance;
import com.blackgear.vanillabackport.client.registries.ModSoundEvents;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.happy_ghast.HappyGhast;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.nautilus.AbstractNautilus;
import com.mojang.authlib.GameProfile;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import net.minecraft.class_638;
import net.minecraft.class_742;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_746.class)
public abstract class LocalPlayerMixin extends class_742 {
    @Shadow @Final protected class_310 minecraft;

    public LocalPlayerMixin(class_638 clientLevel, GameProfile gameProfile) {
        super(clientLevel, gameProfile);
    }

    @Inject(method = "startRiding", at = @At("HEAD"), cancellable = true)
    private void onStartRiding(class_1297 vehicle, boolean force, CallbackInfoReturnable<Boolean> cir) {
        if (super.method_5873(vehicle, force)) {
            if (vehicle instanceof HappyGhast ghast) {
                this.minecraft.method_1483().method_4873(new RidingEntitySoundInstance(this,
                    ghast,
                    false,
                    ModSoundEvents.HAPPY_GHAST_RIDING.get(),
                    0.0F,
                    1.0F,
                    5.0F
                ));
                cir.setReturnValue(true);
            }
            
            if (vehicle instanceof AbstractNautilus nautilus) {
                this.minecraft.method_1483().method_4873(new RidingEntitySoundInstance(this,
                    nautilus,
                    true,
                    ModSoundEvents.NAUTILUS_RIDING.get(),
                    0.0F,
                    1.0F,
                    5.0F
                ));
                cir.setReturnValue(true);
            }
        }
    }
}