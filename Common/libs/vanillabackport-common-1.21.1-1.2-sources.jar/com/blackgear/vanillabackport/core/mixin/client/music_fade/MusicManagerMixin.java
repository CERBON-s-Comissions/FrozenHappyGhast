package com.blackgear.vanillabackport.core.mixin.client.music_fade;

import com.blackgear.vanillabackport.client.api.modules.music_fade.MusicFadeManager;
import net.minecraft.class_1113;
import net.minecraft.class_1142;
import net.minecraft.class_5195;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1142.class)
public abstract class MusicManagerMixin {
    @Shadow @Nullable private class_1113 currentMusic;
    @Shadow private int nextSongDelay;

    @Unique private MusicFadeManager vb$fadeManager;

    @Unique
    private MusicFadeManager vb$fadeManager() {
        if (this.vb$fadeManager == null) {
            this.vb$fadeManager = new MusicFadeManager((class_1142) (Object) this);
        }
        return this.vb$fadeManager;
    }

    @Inject(method = "tick", at = @At("HEAD"), cancellable = true)
    private void vb$onTick(CallbackInfo ci) {
        MusicFadeManager fade = this.vb$fadeManager();

        if (fade.tickFade(this.currentMusic)) {
            ci.cancel();
            return;
        }

        if (this.currentMusic == null && fade.isSilentBiome()) {
            this.nextSongDelay = Math.max(this.nextSongDelay, 100);
            ci.cancel();
        }
    }

    @Inject(method = "startPlaying", at = @At("TAIL"))
    private void vb$onStartPlaying(class_5195 selector, CallbackInfo ci) {
        this.vb$fadeManager().onStartPlaying();
    }
}