package com.blackgear.vanillabackport.core.mixin.client.music_frequency;

import com.blackgear.vanillabackport.client.api.modules.music_frequency.MusicFrequency;
import com.blackgear.vanillabackport.client.api.modules.music_frequency.MusicFrequencyAccess;
import com.blackgear.vanillabackport.client.api.modules.options.OptionsAccess;
import net.minecraft.class_1113;
import net.minecraft.class_1142;
import net.minecraft.class_310;
import net.minecraft.class_5195;
import net.minecraft.class_5819;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1142.class)
public abstract class MusicManagerMixin implements MusicFrequencyAccess {
    @Shadow @Final private class_310 minecraft;
    @Shadow @Final private class_5819 random;
    @Shadow private int nextSongDelay;
    @Shadow @Nullable private class_1113 currentMusic;
    @Unique private MusicFrequency gameMusicFrequency = MusicFrequency.DEFAULT;
    
    @Inject(method = "tick", at = @At("HEAD"))
    private void vb$ensureOptionsLoaded(CallbackInfo ci) {
        if (this.gameMusicFrequency == MusicFrequency.DEFAULT) {
            OptionsAccess access = (OptionsAccess) this.minecraft.field_1690;
            if (access.musicFrequency() != null) {
                this.gameMusicFrequency = access.musicFrequency().method_41753();
            }
        }
    }
    
    @Inject(
        method = "tick",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/sounds/SoundManager;isActive(Lnet/minecraft/client/resources/sounds/SoundInstance;)Z",
            shift = At.Shift.AFTER
        )
    )
    private void onSongFinishedDelay(CallbackInfo ci) {
        if (!this.minecraft.method_1483().method_4877(this.currentMusic)) {
            class_5195 situationalMusic = this.minecraft.method_1544();
            int customDelay = this.gameMusicFrequency.getNextSongDelay(situationalMusic, this.random);
            this.nextSongDelay = Math.min(this.nextSongDelay, customDelay);
        }
    }
    
    @Inject(method = "stopPlaying()V", at = @At("TAIL"))
    private void vb$b(CallbackInfo ci) {
        this.nextSongDelay = this.gameMusicFrequency.getNextSongDelay(this.minecraft.method_1544(), this.random) + 100;
    }
    
    @Override
    public void setMinutesBetweenSongs(MusicFrequency frequency) {
        this.gameMusicFrequency = frequency;
        this.nextSongDelay = this.gameMusicFrequency.getNextSongDelay(this.minecraft.method_1544(), this.random);
    }
}