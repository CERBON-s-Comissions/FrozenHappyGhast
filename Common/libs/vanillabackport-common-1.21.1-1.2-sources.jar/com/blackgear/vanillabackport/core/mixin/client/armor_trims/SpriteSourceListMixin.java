package com.blackgear.vanillabackport.core.mixin.client.armor_trims;

import org.slf4j.Logger;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_7947;
import net.minecraft.class_7948;
import net.minecraft.class_8066;

@Mixin(class_7947.class)
public abstract class SpriteSourceListMixin {
    @Shadow @Final private static Logger LOGGER;

    @Inject(
        method = "load",
        at = @At("RETURN")
    )
    private static void vb$handleArmorTrims(class_3300 manager, class_2960 location, CallbackInfoReturnable<class_7947> cir) {
        if (location.equals(class_2960.method_60656("armor_trims"))) {
            for (class_7948 source : ((SpriteSourceListMixin) (Object) cir.getReturnValue()).getSources()) {
                if (source instanceof PalettedPermutationsAccessor permutations && permutations.getPaletteKey().equals(class_2960.method_60656("trims/color_palettes/trim_palette"))) {
                    class_2960 resin = class_2960.method_60656("trims/color_palettes/resin");

                    if (manager.method_14486(class_2960.method_60655(resin.method_12836(), "textures/" + resin.method_12832() + ".png")).isPresent()) {
                        Map<String, class_2960> map = new HashMap<>(permutations.getPermutations());
                        map.put("resin", resin);
                        permutations.setPermutations(map);
                    } else {
                        LOGGER.warn("Resin palette texture not found at: {}", resin);
                    }
                }
            }
        }
    }

    @Accessor("sources")
    abstract List<class_7948> getSources();

    @Mixin(class_8066.class)
    private interface PalettedPermutationsAccessor {
        @Accessor List<class_2960> getTextures();
        @Accessor("textures") @Mutable void setTextures(List<class_2960> textures);

        @Accessor Map<String, class_2960> getPermutations();
        @Accessor("permutations") @Mutable void setPermutations(Map<String, class_2960> permutations);

        @Accessor class_2960 getPaletteKey();
    }
}