package com.blackgear.vanillabackport.common.triggers;

import com.blackgear.vanillabackport.common.registries.ModCriteriaTriggers;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;
import net.minecraft.class_175;
import net.minecraft.class_3222;
import net.minecraft.class_4558;
import net.minecraft.class_5258;
import net.minecraft.class_5699;

public class SpearMobsTrigger extends class_4558<SpearMobsTrigger.TriggerInstance> {
    @Override
    public Codec<TriggerInstance> method_54937() {
        return TriggerInstance.CODEC;
    }
    
    public void trigger(class_3222 player, int number) {
        this.method_22510(player, trigger -> trigger.matches(number));
    }
    
    public record TriggerInstance(Optional<class_5258> player, Optional<Integer> count) implements class_4558.class_8788 {
        public static final Codec<TriggerInstance> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            class_5258.field_47234.optionalFieldOf("player").forGetter(TriggerInstance::comp_2029),
            class_5699.field_33442.optionalFieldOf("count").forGetter(TriggerInstance::count)
        ).apply(instance, TriggerInstance::new));
        
        public static class_175<TriggerInstance> spearMobs(int requiredCounts) {
            return ModCriteriaTriggers.SPEAR_MOBS_TRIGGER.get().method_53699(new TriggerInstance(Optional.empty(), Optional.of(requiredCounts)));
        }
        
        public boolean matches(int requiredCount) {
            return this.count.isEmpty() || requiredCount >= this.count.get();
        }
    }
}