package com.blackgear.vanillabackport.common.registries.entities;

import com.blackgear.platform.core.CoreRegistry;
import com.blackgear.vanillabackport.core.VanillaBackport;
import net.minecraft.class_1320;
import net.minecraft.class_1329;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

public class ModAttributes {
    public static final CoreRegistry<class_1320> REGISTRIES = CoreRegistry.create(class_7923.field_41190, VanillaBackport.NAMESPACE);
    
    public static final class_6880<class_1320> WAYPOINT_TRANSMIT_RANGE = REGISTRIES.holder("waypoint_transmit_range",
        () -> new class_1329(
            "attribute.name.waypoint_transmit_range",
            0.0,
            0.0,
            6.0E7
        ).method_60493(class_1320.class_9764.field_51886));
    public static final class_6880<class_1320> WAYPOINT_RECEIVE_RANGE = REGISTRIES.holder("waypoint_receive_range",
        () -> new class_1329(
            "attribute.name.waypoint_receive_range",
            0.0,
            0.0,
            6.0E7
        ).method_60493(class_1320.class_9764.field_51886));
    
    public static final class_6880<class_1320> AIR_DRAG_MODIFIER = REGISTRIES.holder("air_drag_modifier",
        () -> new class_1329(
            "attribute.name.air_drag_modifier",
            1.0,
            0.0,
            2048.0
        ).method_26829(true));
    public static final class_6880<class_1320> BOUNCINESS = REGISTRIES.holder("bounciness",
        () -> new class_1329(
            "attribute.name.bounciness",
            0.0,
            0.0,
            1.0
        ).method_26829(true));
    public static final class_6880<class_1320> FRICTION_MODIFIER = REGISTRIES.holder("friction_modifier",
        () -> new class_1329(
            "attribute.name.friction_modifier",
            1.0,
            0.0,
            2048.0
        ).method_26829(true));
}