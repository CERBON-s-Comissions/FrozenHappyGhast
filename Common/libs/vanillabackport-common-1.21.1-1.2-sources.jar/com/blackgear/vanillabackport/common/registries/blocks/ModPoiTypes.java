package com.blackgear.vanillabackport.common.registries.blocks;

import com.blackgear.platform.core.CoreRegistry;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import java.util.Set;
import net.minecraft.class_2680;
import net.minecraft.class_4158;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

public class ModPoiTypes {
    public static final CoreRegistry<class_4158> REGISTRIES = CoreRegistry.create(class_7924.field_41212, VanillaBackport.NAMESPACE);
    
    public static final class_5321<class_4158> LIGHTNING_RODS = REGISTRIES.resource("lightning_rods",
        () -> new class_4158(getLightningRodBlocks(), 0, 1));
    
    private static Set<class_2680> getLightningRodBlocks() {
        return ImmutableList.of(
            ModBlocks.EXPOSED_LIGHTNING_ROD,
            ModBlocks.WEATHERED_LIGHTNING_ROD,
            ModBlocks.OXIDIZED_LIGHTNING_ROD,
            ModBlocks.WAXED_LIGHTNING_ROD,
            ModBlocks.WAXED_EXPOSED_LIGHTNING_ROD,
            ModBlocks.WAXED_WEATHERED_LIGHTNING_ROD,
            ModBlocks.WAXED_OXIDIZED_LIGHTNING_ROD
        ).stream().flatMap(block -> block.get().method_9595().method_11662().stream())
        .collect(ImmutableSet.toImmutableSet());
    }
}