package com.blackgear.vanillabackport.common.registries.worldgen;

import com.blackgear.platform.core.CoreRegistry;
import com.blackgear.vanillabackport.common.level.worldgen.tree.trunk.PoplarTrunkPlacer;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.blackgear.vanillabackport.core.mixin.common.access.TrunkPlacerTypeAccessor;
import com.mojang.serialization.MapCodec;
import java.util.function.Supplier;
import net.minecraft.class_5141;
import net.minecraft.class_5142;
import net.minecraft.class_7924;

public class ModTrunkPlacers {
    public static final CoreRegistry<class_5142<?>> REGISTRIES = CoreRegistry.create(class_7924.field_41233, VanillaBackport.NAMESPACE);
    
    public static final Supplier<class_5142<PoplarTrunkPlacer>> POPLAR_TRUNK_PLACER = register("poplar_trunk_placer", PoplarTrunkPlacer.CODEC);
    
    private static <P extends class_5141> Supplier<class_5142<P>> register(String name, MapCodec<P> codec) {
        return REGISTRIES.register(name, () -> TrunkPlacerTypeAccessor.createTrunkPlacerType(codec));
    }
}