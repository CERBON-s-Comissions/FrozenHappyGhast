package com.blackgear.vanillabackport.common.registries.entities;

import com.blackgear.vanillabackport.common.level.entities.boat.BoatRegistry;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import com.blackgear.vanillabackport.common.registries.items.ModItems;
import java.util.function.Supplier;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2960;

public class ModBoatTypes {
    public static final class_2960 PALE_OAK = register("pale_oak", () -> ModItems.PALE_OAK_BOAT.get(), () -> ModItems.PALE_OAK_CHEST_BOAT.get(), () -> ModBlocks.PALE_OAK_PLANKS.get());
    public static final class_2960 POPLAR = register("poplar", () -> ModItems.POPLAR_BOAT.get(), () -> ModItems.POPLAR_CHEST_BOAT.get(), () -> ModBlocks.POPLAR_PLANKS.get());
    
    public static class_2960 register(String name, Supplier<class_1792> boat, Supplier<class_1792> chestBoat, Supplier<class_2248> planks) {
        class_2960 location = class_2960.method_60656(name);
        BoatRegistry.register(location, boat, chestBoat, planks, false);
        return location;
    }
    
    public static void bootstrap() {}
}