package com.blackgear.vanillabackport.common.registries.entities;

import com.blackgear.platform.core.helper.EntityRegistry;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.happy_ghast.HappyGhast;
import com.blackgear.vanillabackport.common.level.entities.ai.sensor_types.AdultSensorAnyType;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.nautilus.NautilusAi;
import com.blackgear.vanillabackport.core.VanillaBackport;
import java.util.function.Supplier;
import net.minecraft.class_4149;
import net.minecraft.class_5760;

public class ModSensorTypes {
    public static final EntityRegistry REGISTRIES = EntityRegistry.create(VanillaBackport.NAMESPACE);

    public static final Supplier<class_4149<AdultSensorAnyType>> NEAREST_ADULT_ANY_TYPE = REGISTRIES.sensor("nearest_adult_any_type", AdultSensorAnyType::new);
    public static final Supplier<class_4149<class_5760>> HAPPY_GHAST_TEMPTATIONS = REGISTRIES.sensor("happy_ghast_temptations", () -> new class_5760(HappyGhast.IS_FOOD));
    public static final Supplier<class_4149<class_5760>> NAUTILUS_TEMPTATIONS = REGISTRIES.sensor("nautilus_temptations", () -> new class_5760(NautilusAi.getTemptations()));
}