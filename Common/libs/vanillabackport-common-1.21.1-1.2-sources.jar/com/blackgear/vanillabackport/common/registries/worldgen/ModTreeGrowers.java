package com.blackgear.vanillabackport.common.registries.worldgen;

import com.blackgear.vanillabackport.common.worldgen.features.TheGardenAwakensFeatures;
import com.blackgear.vanillabackport.common.worldgen.features.WildernessBoundFeatures;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import java.util.function.Supplier;
import net.minecraft.class_2975;
import net.minecraft.class_5321;
import net.minecraft.class_5819;
import net.minecraft.class_8813;

public class ModTreeGrowers {
    public static final Supplier<class_8813> PALE_OAK = () -> new class_8813("pale_oak",
        Optional.of(TheGardenAwakensFeatures.PALE_OAK_BONEMEAL),
        Optional.empty(),
        Optional.empty());
    public static final Supplier<class_8813> POPLAR = () -> new class_8813("poplar",Optional.empty(), Optional.empty(), Optional.empty()) {
        @Override
        public @Nullable class_5321<class_2975<?, ?>> method_54087(class_5819 random, boolean flowers) {
            int chance = random.method_43048(3);
            return switch (chance) {
                case 0 -> WildernessBoundFeatures.RED_POPLAR;
                case 1 -> WildernessBoundFeatures.ORANGE_POPLAR;
                default -> WildernessBoundFeatures.YELLOW_POPLAR;
            };
        }
    };
}