package com.blackgear.vanillabackport.common.registries.items;

import com.blackgear.platform.core.CoreRegistry;
import com.blackgear.vanillabackport.client.registries.ModSoundEvents;
import com.blackgear.vanillabackport.core.VanillaBackport;
import java.util.EnumMap;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.class_156;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

public class ModArmorMaterials {
    public static final CoreRegistry<class_1741> REGISTRIES = CoreRegistry.create(class_7923.field_48976, VanillaBackport.NAMESPACE);
    
    public static final class_6880<class_1741> COPPER = register("copper",
        class_156.method_654(new EnumMap<>(class_1738.class_8051.class), attributes -> {
            attributes.put(class_1738.class_8051.field_41937, 1);
            attributes.put(class_1738.class_8051.field_41936, 3);
            attributes.put(class_1738.class_8051.field_41935, 4);
            attributes.put(class_1738.class_8051.field_41934, 2);
            attributes.put(class_1738.class_8051.field_48838, 4);
        }),
        8,
        ModSoundEvents.ARMOR_EQUIP_COPPER,
        0.0F,
        0.0F,
        () -> class_1856.method_8091(class_1802.field_27022)
    );
    
    public static class_6880<class_1741> register(
        String name,
        EnumMap<class_1738.class_8051, Integer> defense,
        int enchantmentValue,
        class_6880<class_3414> equipSound,
        float toughness,
        float knockbackResistance,
        Supplier<class_1856> repairIngredient
    ) {
        List<class_1741.class_9196> layers = List.of(new class_1741.class_9196(class_2960.method_60656(name)));
        return register(name, defense, enchantmentValue, equipSound, toughness, knockbackResistance, repairIngredient, layers);
    }
    
    private static class_6880<class_1741> register(
        String name,
        EnumMap<class_1738.class_8051, Integer> defense,
        int enchantmentValue,
        class_6880<class_3414> equipSound,
        float toughness,
        float knockbackResistance,
        Supplier<class_1856> repairIngredient,
        List<class_1741.class_9196> layers
    ) {
        return REGISTRIES.holder(name,
            () -> new class_1741(defense, enchantmentValue, equipSound, repairIngredient, layers, toughness, knockbackResistance));
    }
}