package com.blackgear.vanillabackport.common.registries.items;

import com.blackgear.vanillabackport.core.data.tags.ModBlockTags;
import com.google.common.base.Suppliers;
import java.util.function.Supplier;
import net.minecraft.class_1802;
import net.minecraft.class_1832;
import net.minecraft.class_1856;
import net.minecraft.class_2248;
import net.minecraft.class_6862;

public enum ModToolMaterials implements class_1832 {
    COPPER(ModBlockTags.INCORRECT_FOR_COPPER_TOOL, 190, 5.0F, 1.0F, 13, () -> class_1856.method_8091(class_1802.field_27022));
    
    private final class_6862<class_2248> incorrectBlocksForDrops;
    private final int uses;
    private final float speed;
    private final float damage;
    private final int enchantmentValue;
    private final Supplier<class_1856> repairIngredient;
    
    ModToolMaterials(class_6862<class_2248> incorrectBlocksForDrops, int uses, float speed, float damage, int enchantmentValue, Supplier<class_1856> repairIngredient) {
        this.incorrectBlocksForDrops = incorrectBlocksForDrops;
        this.uses = uses;
        this.speed = speed;
        this.damage = damage;
        this.enchantmentValue = enchantmentValue;
        this.repairIngredient = Suppliers.memoize(repairIngredient::get);
    }
    
    @Override
    public int method_8025() {
        return this.uses;
    }
    
    @Override
    public float method_8027() {
        return this.speed;
    }
    
    @Override
    public float method_8028() {
        return this.damage;
    }
    
    @Override
    public class_6862<class_2248> method_58419() {
        return this.incorrectBlocksForDrops;
    }
    
    @Override
    public int method_8026() {
        return this.enchantmentValue;
    }
    
    @Override
    public class_1856 method_8023() {
        return this.repairIngredient.get();
    }
}
