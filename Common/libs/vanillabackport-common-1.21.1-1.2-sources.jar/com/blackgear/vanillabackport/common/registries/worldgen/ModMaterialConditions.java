package com.blackgear.vanillabackport.common.registries.worldgen;

import com.blackgear.platform.core.api.registrar.Registrar;
import com.blackgear.vanillabackport.common.level.worldgen.surface.SpatialNoiseThresholdConditionSource;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_6686;
import net.minecraft.class_7924;

public class ModMaterialConditions {
    public static final Registrar<MapCodec<? extends class_6686.class_6693>> REGISTRIES = Registrar.create(class_7924.field_41204, VanillaBackport.NAMESPACE);

    public static final MapCodec<SpatialNoiseThresholdConditionSource> SPATIAL_NOISE_THRESHOLD = REGISTRIES.register("spatial_noise_threshold", SpatialNoiseThresholdConditionSource.CODEC.comp_640());
}
