package com.blackgear.vanillabackport.common.registries.worldgen;

import com.blackgear.platform.core.api.registrar.bootstrap.NoiseRegistrar;
import com.blackgear.vanillabackport.core.VanillaBackport;
import net.minecraft.class_5216.class_5487;
import net.minecraft.class_5321;

public class ModNoises {
    public static final NoiseRegistrar REGISTRIES = NoiseRegistrar.create(VanillaBackport.NAMESPACE);

    public static final class_5321<class_5487> SULFUR_CAVE_GRADIENT = REGISTRIES.register("sulfur_cave_gradient", -5, 1.0, 0.0, 1.0);
    public static final class_5321<class_5487> SMALL_PATCH = REGISTRIES.register("small_patch", -3, 3.0);
}