package com.blackgear.vanillabackport.common.registries.items;

import com.blackgear.platform.core.CoreRegistry;
import com.blackgear.platform.core.api.RegistryKey;
import com.blackgear.vanillabackport.common.level.components.*;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.chicken.ChickenVariant;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.blackgear.vanillabackport.core.util.AdditionalCodecs;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_8110;
import net.minecraft.class_9135;
import net.minecraft.class_9331;
import net.minecraft.class_9791;

public class ModDataComponents {
    public static final CoreRegistry<class_9331<?>> REGISTRIES = CoreRegistry.create(class_7923.field_49658, VanillaBackport.NAMESPACE);

    public static final Supplier<class_9331<RegistryKey<ChickenVariant>>> CHICKEN_VARIANT = register("chicken/variant",
        builder ->
            builder.method_57881(class_2960.field_25139.xmap(RegistryKey::of, RegistryKey::location))
                .method_57882(class_2960.field_48267.method_56432(RegistryKey::of, RegistryKey::location)));
    
    public static final Supplier<class_9331<AttackRange>> ATTACK_RANGE = register("attack_range",
        builder -> builder.method_57881(AttackRange.CODEC)
            .method_57882(AttackRange.STREAM_CODEC)
            .method_59871());
    
    public static final Supplier<class_9331<KineticWeapon>> KINETIC_WEAPON = register("kinetic_weapon",
        builder -> builder.method_57881(KineticWeapon.CODEC)
            .method_57882(KineticWeapon.STREAM_CODEC)
            .method_59871());
    
    public static final Supplier<class_9331<PiercingWeapon>> PIERCING_WEAPON = register("piercing_weapon",
        builder -> builder.method_57881(PiercingWeapon.CODEC)
            .method_57882(PiercingWeapon.STREAM_CODEC)
            .method_59871());
    
    public static final Supplier<class_9331<UseEffects>> USE_EFFECTS = register("use_effects",
        builder -> builder.method_57881(UseEffects.CODEC)
            .method_57882(UseEffects.STREAM_CODEC));
    
    public static final Supplier<class_9331<class_9791<class_8110>>> DAMAGE_TYPE = register("damage_type",
        builder -> builder.method_57881(class_9791.method_60736(class_7924.field_42534, class_8110.field_51565))
            .method_57882(class_9791.method_60737(class_7924.field_42534, class_8110.field_51932))
            .method_59871());
    
    public static final Supplier<class_9331<Float>> MINIMUM_ATTACK_CHARGE = register("minimum_attack_range",
        builder -> builder.method_57881(AdditionalCodecs.floatRange(0.0F, 1.0F))
            .method_57882(class_9135.field_48552));
    
    public static final Supplier<class_9331<SwingAnimation>> SWING_ANIMATION = register("swing_animation",
        builder -> builder.method_57881(SwingAnimation.CODEC)
            .method_57882(SwingAnimation.STREAM_CODEC));
    
    public static <T> Supplier<class_9331<T>> register(String key, UnaryOperator<class_9331.class_9332<T>> operator) {
        return REGISTRIES.register(key, () -> operator.apply(class_9331.method_57873()).method_57880());
    }
}