package com.blackgear.vanillabackport.common.registries.items;

import com.blackgear.platform.core.api.registrar.bootstrap.BootstrapRegistrar;
import com.blackgear.vanillabackport.core.VanillaBackport;
import java.util.Map;
import net.minecraft.class_156;
import net.minecraft.class_1741;
import net.minecraft.class_1792;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import net.minecraft.class_8054;

public class ModTrimMaterials {
    public static final BootstrapRegistrar<class_8054> REGISTRIES = BootstrapRegistrar.create(class_7924.field_42083, VanillaBackport.NAMESPACE);
    
    public static final class_5321<class_8054> RESIN = register("resin", ModItems.RESIN_BRICK.get(), class_2583.field_24360.method_36139(16545810), 0.5F);

    private static class_5321<class_8054> register(String name, class_1792 ingredient, class_2583 style, float itemModelIndex) {
        return register(name, ingredient, style, itemModelIndex, Map.of());
    }

    private static class_5321<class_8054> register(
        String name,
        class_1792 ingredient,
        class_2583 style,
        float itemModelIndex,
        Map<class_6880<class_1741>, String> overrideArmorMaterials
    ) {
        return REGISTRIES.resource(
            name,
            (context, key) -> class_8054.method_48438(
                name,
                ingredient,
                itemModelIndex,
                class_2561.method_43471(class_156.method_646("trim_material", key)).method_27696(style),
                overrideArmorMaterials));
    }
}