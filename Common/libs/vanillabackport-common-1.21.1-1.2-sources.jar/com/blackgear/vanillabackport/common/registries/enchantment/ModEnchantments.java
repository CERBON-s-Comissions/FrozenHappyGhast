package com.blackgear.vanillabackport.common.registries.enchantment;

import com.blackgear.platform.core.api.registrar.bootstrap.BootstrapRegistrar;
import com.blackgear.vanillabackport.client.registries.ModSoundEvents;
import com.blackgear.vanillabackport.common.level.items.enchantment.effects.ApplyEntityImpulse;
import com.blackgear.vanillabackport.common.level.items.enchantment.effects.ApplyExhaustion;
import com.blackgear.vanillabackport.common.level.items.enchantment.effects.PlaySoundEffect;
import com.blackgear.vanillabackport.common.predicates.FoodPredicate;
import com.blackgear.vanillabackport.common.predicates.PlayerPredicate;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.blackgear.vanillabackport.core.data.tags.ModItemTags;
import net.minecraft.advancements.critereon.*;
import net.minecraft.class_1792;
import net.minecraft.class_1887;
import net.minecraft.class_1934;
import net.minecraft.class_2040;
import net.minecraft.class_2048;
import net.minecraft.class_207;
import net.minecraft.class_2096;
import net.minecraft.class_215;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_47;
import net.minecraft.class_5321;
import net.minecraft.class_5862;
import net.minecraft.class_7871;
import net.minecraft.class_7924;
import net.minecraft.class_8548;
import net.minecraft.class_8551;
import net.minecraft.class_9274;
import net.minecraft.class_9704;
import net.minecraft.class_9712;
import net.minecraft.class_9719;
import net.minecraft.class_9789;
import java.util.List;

public class ModEnchantments {
    public static final BootstrapRegistrar<class_1887> REGISTRIES = BootstrapRegistrar.create(class_7924.field_41265, VanillaBackport.NAMESPACE);
    
    public static final class_5321<class_1887> LUNGE = REGISTRIES.resource("lunge", (context, key) -> {
        class_7871<class_1792> items = context.method_46799(class_7924.field_41197);
        return class_1887.method_60030(
            class_1887.method_58442(
                items.method_46735(ModItemTags.LUNGE_ENCHANTABLE),
                5,
                3,
                class_1887.method_58441(5, 8),
                class_1887.method_58441(25, 8),
                2,
                class_9274.field_49219
            )
        )
        .method_60067(
            ModEnchantmentEffectComponents.POST_PIERCING_ATTACK.get(),
            class_9712.method_60216(
                new class_9719(new class_9704.class_9706(1.0F)),
                new ApplyExhaustion(class_9704.method_60194(4.0F)),
                new ApplyEntityImpulse(new class_243(0.0, 0.0, 1.0), new class_243(1.0, 0.0, 1.0), class_9704.method_60194(0.458F)),
                new PlaySoundEffect(List.of(ModSoundEvents.LUNGE_1, ModSoundEvents.LUNGE_2, ModSoundEvents.LUNGE_3), class_5862.method_33908(1.0F), class_5862.method_33908(1.0F))
            ),
            class_8548.method_51723(
                class_207.method_889(
                    class_215.method_917(class_47.class_50.field_935, class_2048.class_2049.method_8916().method_27971(class_2048.class_2049.method_8916()))
                ),
                class_215.method_917(
                    class_47.class_50.field_935, class_2048.class_2049.method_8916().method_8919(class_2040.class_2041.method_8897().method_59919(false))
                ),
                class_8551.method_51727(
                    class_207.method_889(
                        class_215.method_917(
                            class_47.class_50.field_935, class_2048.class_2049.method_8916().method_43094(PlayerPredicate.Builder.player().build())
                        )
                    ),
                    class_215.method_917(
                        class_47.class_50.field_935,
                        class_2048.class_2049.method_8916().method_43094(PlayerPredicate.Builder.player().setGameType(class_9789.method_60724(class_1934.field_9220)).build())
                    ),
                    class_215.method_917(
                        class_47.class_50.field_935,
                        class_2048.class_2049.method_8916().method_43094(PlayerPredicate.Builder.player().setFood(FoodPredicate.Builder.food().withLevel(class_2096.class_2100.method_9053(class_3532.method_15375(6.0F) + 1)).build()).build())
                    )
                )
            )
        ).method_60060(key);
    });
}