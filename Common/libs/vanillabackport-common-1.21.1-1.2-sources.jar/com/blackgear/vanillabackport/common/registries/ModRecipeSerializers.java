package com.blackgear.vanillabackport.common.registries;

import com.blackgear.platform.core.CoreRegistry;
import com.blackgear.vanillabackport.common.api.modules.bundle_ui.BundleColoring;
import com.blackgear.vanillabackport.core.VanillaBackport;
import java.util.function.Supplier;
import net.minecraft.class_1865;
import net.minecraft.class_1866;
import net.minecraft.class_7923;

public class ModRecipeSerializers {
    public static final CoreRegistry<class_1865<?>> REGISTRIES = CoreRegistry.create(class_7923.field_41189, VanillaBackport.NAMESPACE);

    public static final Supplier<class_1865<BundleColoring>> BUNDLE_COLORING = REGISTRIES.register("crafting_special_bundlecoloring",
        () -> new class_1866<>(BundleColoring::new)
    );
}