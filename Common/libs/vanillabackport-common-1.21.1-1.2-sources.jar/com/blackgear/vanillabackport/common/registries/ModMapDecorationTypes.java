package com.blackgear.vanillabackport.common.registries;

import com.blackgear.platform.core.CoreRegistry;
import com.blackgear.vanillabackport.core.VanillaBackport;
import net.minecraft.class_2960;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import net.minecraft.class_9428;

public class ModMapDecorationTypes {
    public static final CoreRegistry<class_9428> REGISTRIES = CoreRegistry.create(class_7924.field_50082, VanillaBackport.NAMESPACE);
    
    public static final class_6880<class_9428> ABANDONED_CAMP = register("abandoned_camp", "abandoned_camp", true, false);
    public static final class_6880<class_9428> ANCIENT_CITY = register("ancient_city", "ancient_city", true, false);
    public static final class_6880<class_9428> DESERT_PYRAMID = register("desert_pyramid", "desert_pyramid", true, false);
    public static final class_6880<class_9428> MINESHAFT = register("mineshaft", "mineshaft", true, false);
    public static final class_6880<class_9428> OCEAN_RUIN_WARM = register("ocean_ruin_warm", "warm_ocean_ruins", true, false);
    
    private static class_6880<class_9428> register(String name, String assetId, boolean showOnItemFrame, boolean trackCount) {
        return register(name, assetId, showOnItemFrame, -1, trackCount, false);
    }
    
    public static class_6880<class_9428> register(String name, String assetId, boolean showOnItemFrame, int mapColor, boolean explorationMapElement, boolean trackCount) {
        return REGISTRIES.holder(name, () -> new class_9428(class_2960.method_60656(assetId), showOnItemFrame, mapColor, explorationMapElement, trackCount));
    }
}