package com.blackgear.vanillabackport.common.registries.entities;

import com.blackgear.platform.core.helper.EntityRegistry;
import com.blackgear.vanillabackport.common.level.entities.ai.behavior.SpearStatus;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.mojang.serialization.Codec;
import java.util.Set;
import java.util.function.Supplier;
import net.minecraft.class_243;
import net.minecraft.class_4140;
import net.minecraft.class_4208;

public class ModMemoryModuleTypes {
    public static final EntityRegistry REGISTRIES = EntityRegistry.create(VanillaBackport.NAMESPACE);
    
    public static final Supplier<class_4140<Integer>> TRANSPORT_ITEMS_COOLDOWN_TICKS = REGISTRIES.memory("transport_items_cooldown_ticks");
    public static final Supplier<class_4140<Set<class_4208>>> VISITED_BLOCK_POSITIONS = REGISTRIES.memory("visited_block_positions", class_4208.field_25066.listOf().xmap(Sets::newHashSet, Lists::newArrayList));
    public static final Supplier<class_4140<Set<class_4208>>> UNREACHABLE_TRANSPORT_BLOCK_POSITIONS = REGISTRIES.memory("unreachable_transport_block_positions", class_4208.field_25066.listOf().xmap(Sets::newHashSet, Lists::newArrayList));
    
    public static final Supplier<class_4140<Integer>> CHARGE_COOLDOWN_TICKS = REGISTRIES.memory("charge_cooldown_ticks", Codec.INT);
    public static final Supplier<class_4140<Integer>> ATTACK_TARGET_COOLDOWN = REGISTRIES.memory("attack_target_cooldown", Codec.INT);
    
    public static final Supplier<class_4140<Integer>> SPEAR_FLEEING_TIME = REGISTRIES.memory("spear_fleeing_time");
    public static final Supplier<class_4140<class_243>> SPEAR_FLEEING_POSITION = REGISTRIES.memory("spear_fleeing_position");
    public static final Supplier<class_4140<class_243>> SPEAR_CHARGE_POSITION = REGISTRIES.memory("spear_charge_position");
    public static final Supplier<class_4140<Integer>> SPEAR_ENGAGE_TIME = REGISTRIES.memory("spear_engage_time");
    public static final Supplier<class_4140<SpearStatus>> SPEAR_STATUS = REGISTRIES.memory("spear_status");
}