package com.blackgear.vanillabackport.common.registries.worldgen;

import com.blackgear.platform.core.api.registrar.Registrar;
import com.blackgear.vanillabackport.common.level.worldgen.surface.NoiseGradientRuleSource;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_6686;
import net.minecraft.class_7924;

public class ModMaterialRules {
    public static final Registrar<MapCodec<? extends class_6686.class_6708>> REGISTRIES = Registrar.create(class_7924.field_41205, VanillaBackport.NAMESPACE);

    public static final MapCodec<NoiseGradientRuleSource> NOISE_GRADIENT = REGISTRIES.register("noise_gradient", NoiseGradientRuleSource.CODEC.comp_640());
}