package com.blackgear.vanillabackport.common.registries.items;

import com.blackgear.platform.core.api.registrar.bootstrap.BootstrapRegistrar;
import com.blackgear.vanillabackport.client.registries.ModSoundEvents;
import com.blackgear.vanillabackport.core.VanillaBackport;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_3414;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import net.minecraft.class_9793;

public class ModJukeboxSongs {
    public static final BootstrapRegistrar<class_9793> REGISTRIES = BootstrapRegistrar.create(class_7924.field_52176, VanillaBackport.NAMESPACE);
    
    public static final class_5321<class_9793> TEARS = register("tears", ModSoundEvents.MUSIC_DISC_TEARS, 175, 10);
    public static final class_5321<class_9793> LAVA_CHICKEN = register("lava_chicken", ModSoundEvents.MUSIC_DISC_LAVA_CHICKEN, 134, 9);
    public static final class_5321<class_9793> BOUNCE = register("bounce", ModSoundEvents.MUSIC_DISC_BOUNCE, 234, 8);

    private static class_5321<class_9793> register(String name, class_6880<class_3414> soundEvent, int lengthInSeconds, int comparatorOutput) {
        return REGISTRIES.resource(
            name,
            (context, key) -> new class_9793(
                soundEvent,
                class_2561.method_43471(class_156.method_646("jukebox_song", key)),
                (float) lengthInSeconds,
                comparatorOutput
            ));
    }
}