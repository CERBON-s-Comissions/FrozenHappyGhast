package com.blackgear.vanillabackport.common.registries.entities;

import com.blackgear.platform.core.helper.EntityRegistry;
import com.blackgear.vanillabackport.common.level.entities.boat.CustomBoat;
import com.blackgear.vanillabackport.common.level.entities.boat.CustomChestBoat;
import com.blackgear.vanillabackport.common.level.entities.decoration.Cushion;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.camel.CamelHusk;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.golem.copper_golem.CopperGolem;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.nautilus.Nautilus;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.nautilus.ZombieNautilus;
import com.blackgear.vanillabackport.common.level.entities.mob.monster.creaking.Creaking;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.happy_ghast.HappyGhast;
import com.blackgear.vanillabackport.common.level.entities.mob.monster.skeleton.Parched;
import com.blackgear.vanillabackport.common.level.entities.mob.monster.sulfur_cube.SulfurCube;
import com.blackgear.vanillabackport.core.VanillaBackport;
import java.util.function.Supplier;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_243;

public class ModEntityTypes {
    public static final EntityRegistry REGISTRIES = EntityRegistry.create(VanillaBackport.NAMESPACE);

    // The Garden Awakens
    
    public static final Supplier<class_1299<Creaking>> CREAKING = REGISTRIES.entity("creaking",
        class_1299.class_1300.method_5903(Creaking::new, class_1311.field_6302)
            .method_17687(0.9F, 2.7F)
            .method_55687(2.3F)
            .method_27299(8));
    
    public static final Supplier<class_1299<CustomBoat>> CUSTOM_BOAT = REGISTRIES.entity("custom_boat",
        class_1299.class_1300.<CustomBoat>method_5903(CustomBoat::new, class_1311.field_17715)
            .method_17687(1.375F, 0.5625F)
            .method_27299(10));
    public static final Supplier<class_1299<CustomChestBoat>> CUSTOM_CHEST_BOAT = REGISTRIES.entity("custom_chest_boat",
        class_1299.class_1300.<CustomChestBoat>method_5903(CustomChestBoat::new, class_1311.field_17715)
            .method_17687(1.375F, 0.5625F)
            .method_27299(10));
    
    // Chase the Skies
    
    public static final Supplier<class_1299<HappyGhast>> HAPPY_GHAST = REGISTRIES.entity("happy_ghast",
        class_1299.class_1300.method_5903(HappyGhast::new, class_1311.field_6294)
            .method_17687(4.0F, 4.0F)
            .method_55687(2.6F)
            .method_55690(new class_243(0.0, 4.0, 1.8), new class_243(-1.8, 4.0, 0.0), new class_243(0.0, 4.0, -1.8), new class_243(1.8, 4.0, 0.0))
            .method_55691(0.5F)
            .method_27299(10));
    
    // Copper Age
    
    public static final Supplier<class_1299<CopperGolem>> COPPER_GOLEM = REGISTRIES.entity("copper_golem",
        class_1299.class_1300.method_5903(CopperGolem::new, class_1311.field_17715)
            .method_17687(0.49F, 0.98F)
            .method_55687(0.8125F)
            .method_27299(10));
    
    // Mounts of Mayhem
    
    public static final Supplier<class_1299<Parched>> PARCHED = REGISTRIES.entity("parched",
        class_1299.class_1300.method_5903(Parched::new, class_1311.field_6302)
            .method_17687(0.6F, 1.99F)
            .method_55687(1.74F)
            .method_55691(-0.7F)
            .method_27299(8));
    public static final Supplier<class_1299<CamelHusk>> CAMEL_HUSK = REGISTRIES.entity("camel_husk",
        class_1299.class_1300.method_5903(CamelHusk::new, class_1311.field_6302)
            .method_17687(1.7F, 2.375F)
            .method_55687(2.275F)
            .method_27299(10));
    public static final Supplier<class_1299<Nautilus>> NAUTILUS = REGISTRIES.entity("nautilus",
        class_1299.class_1300.method_5903(Nautilus::new, class_1311.field_6300)
            .method_17687(0.875F, 0.95F)
            .method_55689(1.1375F)
            .method_55687(0.2751F)
            .method_27299(10));
    public static final Supplier<class_1299<ZombieNautilus>> ZOMBIE_NAUTILUS = REGISTRIES.entity("zombie_nautilus",
        class_1299.class_1300.method_5903(ZombieNautilus::new, class_1311.field_6302)
            .method_17687(0.875F, 0.95F)
            .method_55689(1.1375F)
            .method_55687(0.2751F)
            .method_27299(10));
    
    // Chaos Cubed
    
    public static final Supplier<class_1299<SulfurCube>> SULFUR_CUBE = REGISTRIES.entity("sulfur_cube",
        class_1299.class_1300.method_5903(SulfurCube::new, class_1311.field_6302)
            .method_17687(0.49F, 0.49F)
            .method_55687(0.175F)
            .method_58630(2.0F)
            .method_27299(10));
    
    // Miscellaneous
    
    public static final Supplier<class_1299<Cushion>> CUSHION = REGISTRIES.entity("cushion",
        class_1299.class_1300.method_5903(Cushion::new, class_1311.field_17715)
            .method_17687(1.0F, 0.25F)
            .method_27299(10)
            .method_27300(Integer.MAX_VALUE));
}