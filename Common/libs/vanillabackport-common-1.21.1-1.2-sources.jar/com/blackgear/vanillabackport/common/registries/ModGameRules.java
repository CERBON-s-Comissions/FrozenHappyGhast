package com.blackgear.vanillabackport.common.registries;

import com.blackgear.vanillabackport.common.api.modules.waypoints.ServerWaypointManager;
import com.blackgear.vanillabackport.core.mixin.common.access.BooleanValueAccessor;
import com.blackgear.vanillabackport.core.mixin.common.access.GameRulesAccessor;
import net.minecraft.class_1928;

public class ModGameRules {
    public static final class_1928.class_4313<class_1928.class_4310> RULE_LOCATOR_BAR = GameRulesAccessor.callRegister("locatorBar",
        class_1928.class_5198.field_24094,
        BooleanValueAccessor.callCreate(true, (server, value) -> server.method_3738().forEach(level -> {
            ServerWaypointManager manager = ServerWaypointManager.get(level);
            if (value.method_20753()) {
                level.method_18456().forEach(manager::updatePlayer);
            } else {
                manager.breakAllConnections();
            }
        }))
    );
    
    public static void bootstrap() {}
}