package com.blackgear.vanillabackport.common.registries.worldgen;

import com.blackgear.platform.core.CoreRegistry;
import com.blackgear.vanillabackport.common.level.worldgen.features.*;
import com.blackgear.vanillabackport.core.VanillaBackport;
import java.util.function.Supplier;
import net.minecraft.class_3031;
import net.minecraft.class_3111;
import net.minecraft.class_3179;
import net.minecraft.class_7924;

public class ModFeatures {
    public static final CoreRegistry<class_3031<?>> REGISTRIES = CoreRegistry.create(class_7924.field_41267, VanillaBackport.NAMESPACE);

    public static final Supplier<class_3031<FallenTreeConfiguration>> FALLEN_TREE = REGISTRIES.register("fallen_tree",
        () -> new FallenTreeFeature(FallenTreeConfiguration.CODEC));
    public static final Supplier<class_3031<LeafLitterConfiguration>> LEAF_LITTER = REGISTRIES.register("leaf_litter",
        () -> new LeafLitterFeature(LeafLitterConfiguration.CODEC));
    public static final Supplier<class_3031<class_3111>> CACTUS_FLOWER = REGISTRIES.register("cactus_flower",
        () -> new CactusFlowerFeature(class_3111.field_24893));
    public static final Supplier<class_3031<class_3179>> SEQUENCE = REGISTRIES.register("sequence",
        () -> new SequenceFeature(class_3179.field_24910));
    public static final Supplier<class_3031<TemplateFeatureConfiguration>> TEMPLATE = REGISTRIES.register("template",
        () -> new TemplateFeature(TemplateFeatureConfiguration.CODEC));
    public static final Supplier<class_3031<WeightedRandomFeatureConfiguration>> WEIGHTED_RANDOM_SELECTOR = REGISTRIES.register("weighted_random_selector",
        () -> new WeightedRandomSelectorFeature(WeightedRandomFeatureConfiguration.CODEC));
    public static final Supplier<class_3031<SpeleothemConfiguration>> SPELEOTHEM = REGISTRIES.register("speleothem",
        () -> new SpeleothemFeature(SpeleothemConfiguration.CODEC));
    public static final Supplier<class_3031<SpeleothemClusterConfiguration>> SPELEOTHEM_CLUSTER = REGISTRIES.register("speleothem_cluster",
        () -> new SpeleothemClusterFeature(SpeleothemClusterConfiguration.CODEC));
    public static final Supplier<class_3031<SulfurRootSystemConfiguration>> SULFUR_ROOT_SYSTEM = REGISTRIES.register("sulfur_root_system",
        () -> new SulfurRootSystemFeature(SulfurRootSystemConfiguration.CODEC));
}