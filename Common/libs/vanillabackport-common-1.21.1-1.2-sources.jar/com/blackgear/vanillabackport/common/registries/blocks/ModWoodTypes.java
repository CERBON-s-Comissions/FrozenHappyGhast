package com.blackgear.vanillabackport.common.registries.blocks;

import com.blackgear.platform.common.block.WoodTypeRegistry;
import net.minecraft.class_2960;
import net.minecraft.class_4719;
import net.minecraft.class_8177;

public class ModWoodTypes {
    public static final class_4719 PALE_OAK = register("pale_oak", ModBlockSetTypes.PALE_OAK);
    public static final class_4719 POPLAR = register("poplar", ModBlockSetTypes.POPLAR);

    private static class_4719 register(String name, class_8177 set) {
        return WoodTypeRegistry.create(class_2960.method_60656(name), set);
    }
}