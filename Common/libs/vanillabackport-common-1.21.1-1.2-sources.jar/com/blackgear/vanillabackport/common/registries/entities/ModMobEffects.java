package com.blackgear.vanillabackport.common.registries.entities;

import com.blackgear.platform.core.CoreRegistry;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.blackgear.vanillabackport.core.mixin.common.access.MobEffectAccessor;
import net.minecraft.class_1291;
import net.minecraft.class_4081;
import net.minecraft.class_6880;
import net.minecraft.class_7924;

public class ModMobEffects {
    public static final CoreRegistry<class_1291> REGISTRIES = CoreRegistry.create(class_7924.field_41208, VanillaBackport.NAMESPACE);
    
    public static final class_6880<class_1291> BREATH_OF_THE_NAUTILUS = REGISTRIES.holder("breath_of_the_nautilus",
        () -> MobEffectAccessor.createMobEffect(class_4081.field_18271, 65518));
}