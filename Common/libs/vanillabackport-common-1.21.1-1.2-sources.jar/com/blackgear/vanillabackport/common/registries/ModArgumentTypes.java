package com.blackgear.vanillabackport.common.registries;

import com.blackgear.platform.core.CoreRegistry;
import com.blackgear.vanillabackport.common.commands.arguments.HexColorArgument;
import com.blackgear.vanillabackport.common.commands.arguments.ColorArgument;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.blackgear.vanillabackport.core.mixin.common.access.ArgumentTypeInfosAccessor;
import com.mojang.brigadier.arguments.ArgumentType;
import java.util.function.Supplier;
import net.minecraft.class_2314;
import net.minecraft.class_2319;
import net.minecraft.class_7924;

public class ModArgumentTypes {
    public static final CoreRegistry<class_2314<?, ?>> REGISTRIES = CoreRegistry.create(class_7924.field_41262, VanillaBackport.NAMESPACE);

    static {
        register("team_color", ColorArgument.class, class_2319.method_41999(ColorArgument::new));
        register("hex_color", HexColorArgument.class, class_2319.method_41999(HexColorArgument::new));
    }
    
    public static <A extends ArgumentType<?>, T extends class_2314.class_7217<A>> Supplier<class_2314<A, T>> register(String name, Class<? extends A> type, class_2314<A, T> info) {
        ArgumentTypeInfosAccessor.getBY_CLASS().put(type, info);
        return REGISTRIES.register(name, () -> info);
    }
}