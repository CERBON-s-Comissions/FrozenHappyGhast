package com.blackgear.vanillabackport.common.registries.items;

import com.blackgear.platform.core.helper.ItemRegistry;
import com.blackgear.vanillabackport.client.registries.ModSoundEvents;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.chicken.ChickenVariants;
import com.blackgear.vanillabackport.common.level.items.CushionItem;
import com.blackgear.vanillabackport.common.level.items.NautilusArmorItem;
import com.blackgear.vanillabackport.common.level.items.CustomBoatItem;
import com.blackgear.vanillabackport.common.level.items.spear.SpearItem;
import com.blackgear.vanillabackport.common.level.items.SulfurCubeBucketItem;
import com.blackgear.vanillabackport.common.registries.entities.ModBoatTypes;
import com.blackgear.vanillabackport.common.registries.entities.ModEntityTypes;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.google.common.base.Suppliers;
import net.minecraft.class_1322;
import net.minecraft.class_1738;
import net.minecraft.class_1740;
import net.minecraft.class_1743;
import net.minecraft.class_1767;
import net.minecraft.class_1771;
import net.minecraft.class_1792;
import net.minecraft.class_1792.class_1793;
import net.minecraft.class_1794;
import net.minecraft.class_1810;
import net.minecraft.class_1814;
import net.minecraft.class_1821;
import net.minecraft.class_1829;
import net.minecraft.class_1834;
import net.minecraft.class_2960;
import net.minecraft.class_4059;
import net.minecraft.class_5134;
import net.minecraft.class_5537;
import net.minecraft.class_9274;
import net.minecraft.class_9276;
import net.minecraft.class_9285;
import net.minecraft.class_9334;
import net.minecraft.world.item.*;
import java.util.function.Supplier;

public class ModItems {
    public static final ItemRegistry REGISTRIES = ItemRegistry.create(VanillaBackport.NAMESPACE);
    
    // Bundles of Bravery
    
    public static final Supplier<class_1792> WHITE_BUNDLE = REGISTRIES.register("white_bundle",
        class_5537::new,
        new class_1793().method_7889(1).method_57349(class_9334.field_49650, class_9276.field_49289));
    public static final Supplier<class_1792> ORANGE_BUNDLE = REGISTRIES.register("orange_bundle",
        class_5537::new,
        new class_1793().method_7889(1).method_57349(class_9334.field_49650, class_9276.field_49289));
    public static final Supplier<class_1792> MAGENTA_BUNDLE = REGISTRIES.register("magenta_bundle",
        class_5537::new,
        new class_1793().method_7889(1).method_57349(class_9334.field_49650, class_9276.field_49289));
    public static final Supplier<class_1792> LIGHT_BLUE_BUNDLE = REGISTRIES.register("light_blue_bundle",
        class_5537::new,
        new class_1793().method_7889(1).method_57349(class_9334.field_49650, class_9276.field_49289));
    public static final Supplier<class_1792> YELLOW_BUNDLE = REGISTRIES.register("yellow_bundle",
        class_5537::new,
        new class_1793().method_7889(1).method_57349(class_9334.field_49650, class_9276.field_49289));
    public static final Supplier<class_1792> LIME_BUNDLE = REGISTRIES.register("lime_bundle",
        class_5537::new,
        new class_1793().method_7889(1).method_57349(class_9334.field_49650, class_9276.field_49289));
    public static final Supplier<class_1792> PINK_BUNDLE = REGISTRIES.register("pink_bundle",
        class_5537::new,
        new class_1793().method_7889(1).method_57349(class_9334.field_49650, class_9276.field_49289));
    public static final Supplier<class_1792> GRAY_BUNDLE = REGISTRIES.register("gray_bundle",
        class_5537::new,
        new class_1793().method_7889(1).method_57349(class_9334.field_49650, class_9276.field_49289));
    public static final Supplier<class_1792> LIGHT_GRAY_BUNDLE = REGISTRIES.register("light_gray_bundle",
        class_5537::new,
        new class_1793().method_7889(1).method_57349(class_9334.field_49650, class_9276.field_49289));
    public static final Supplier<class_1792> CYAN_BUNDLE = REGISTRIES.register("cyan_bundle",
        class_5537::new,
        new class_1793().method_7889(1).method_57349(class_9334.field_49650, class_9276.field_49289));
    public static final Supplier<class_1792> PURPLE_BUNDLE = REGISTRIES.register("purple_bundle",
        class_5537::new,
        new class_1793().method_7889(1).method_57349(class_9334.field_49650, class_9276.field_49289));
    public static final Supplier<class_1792> BLUE_BUNDLE = REGISTRIES.register("blue_bundle",
        class_5537::new,
        new class_1793().method_7889(1).method_57349(class_9334.field_49650, class_9276.field_49289));
    public static final Supplier<class_1792> BROWN_BUNDLE = REGISTRIES.register("brown_bundle",
        class_5537::new,
        new class_1793().method_7889(1).method_57349(class_9334.field_49650, class_9276.field_49289));
    public static final Supplier<class_1792> GREEN_BUNDLE = REGISTRIES.register("green_bundle",
        class_5537::new,
        new class_1793().method_7889(1).method_57349(class_9334.field_49650, class_9276.field_49289));
    public static final Supplier<class_1792> RED_BUNDLE = REGISTRIES.register("red_bundle",
        class_5537::new,
        new class_1793().method_7889(1).method_57349(class_9334.field_49650, class_9276.field_49289));
    public static final Supplier<class_1792> BLACK_BUNDLE = REGISTRIES.register("black_bundle",
        class_5537::new,
        new class_1793().method_7889(1).method_57349(class_9334.field_49650, class_9276.field_49289));
    
    // The Garden Awakens
    
    public static final Supplier<class_1792> PALE_OAK_BOAT = REGISTRIES.register("pale_oak_boat",
        () -> new CustomBoatItem(ModBoatTypes.PALE_OAK, false, new class_1793().method_7889(1)));
    public static final Supplier<class_1792> PALE_OAK_CHEST_BOAT = REGISTRIES.register("pale_oak_chest_boat",
        () -> new CustomBoatItem(ModBoatTypes.PALE_OAK, true, new class_1793().method_7889(1)));
    
    public static final Supplier<class_1792> CREAKING_SPAWN_EGG = REGISTRIES.register("creaking_spawn_egg",
        () -> ItemRegistry.createSpawnEgg(ModEntityTypes.CREAKING, 6250335, 16545810, new class_1793()));
    
    public static final Supplier<class_1792> RESIN_BRICK = REGISTRIES.register("resin_brick");

    // Spring to Life
    
    public static final Supplier<class_1792> BLUE_EGG = REGISTRIES.register("blue_egg",
        () -> new class_1771(new class_1793()
            .method_7889(16)
            .method_57349(ModDataComponents.CHICKEN_VARIANT.get(), ChickenVariants.COLD)));
    public static final Supplier<class_1792> BROWN_EGG = REGISTRIES.register("brown_egg",
        () -> new class_1771(new class_1793()
            .method_7889(16)
            .method_57349(ModDataComponents.CHICKEN_VARIANT.get(), ChickenVariants.WARM)));

    // Chase the Skies
    
    public static final Supplier<class_1792> WHITE_HARNESS = REGISTRIES.register("white_harness",
        new class_1793().method_7889(1));
    public static final Supplier<class_1792> ORANGE_HARNESS = REGISTRIES.register("orange_harness",
        new class_1793().method_7889(1));
    public static final Supplier<class_1792> MAGENTA_HARNESS = REGISTRIES.register("magenta_harness",
        new class_1793().method_7889(1));
    public static final Supplier<class_1792> LIGHT_BLUE_HARNESS = REGISTRIES.register("light_blue_harness",
        new class_1793().method_7889(1));
    public static final Supplier<class_1792> YELLOW_HARNESS = REGISTRIES.register("yellow_harness",
        new class_1793().method_7889(1));
    public static final Supplier<class_1792> LIME_HARNESS = REGISTRIES.register("lime_harness",
        new class_1793().method_7889(1));
    public static final Supplier<class_1792> PINK_HARNESS = REGISTRIES.register("pink_harness",
        new class_1793().method_7889(1));
    public static final Supplier<class_1792> GRAY_HARNESS = REGISTRIES.register("gray_harness",
        new class_1793().method_7889(1));
    public static final Supplier<class_1792> LIGHT_GRAY_HARNESS = REGISTRIES.register("light_gray_harness",
        new class_1793().method_7889(1));
    public static final Supplier<class_1792> CYAN_HARNESS = REGISTRIES.register("cyan_harness",
        new class_1793().method_7889(1));
    public static final Supplier<class_1792> PURPLE_HARNESS = REGISTRIES.register("purple_harness",
        new class_1793().method_7889(1));
    public static final Supplier<class_1792> BLUE_HARNESS = REGISTRIES.register("blue_harness",
        new class_1793().method_7889(1));
    public static final Supplier<class_1792> BROWN_HARNESS = REGISTRIES.register("brown_harness",
        new class_1793().method_7889(1));
    public static final Supplier<class_1792> GREEN_HARNESS = REGISTRIES.register("green_harness",
        new class_1793().method_7889(1));
    public static final Supplier<class_1792> RED_HARNESS = REGISTRIES.register("red_harness",
        new class_1793().method_7889(1));
    public static final Supplier<class_1792> BLACK_HARNESS = REGISTRIES.register("black_harness",
        new class_1793().method_7889(1));
    
    public static final Supplier<class_1792> MUSIC_DISC_TEARS = REGISTRIES.register("music_disc_tears",
        new class_1793()
            .method_7889(1)
            .method_7894(class_1814.field_8907)
            .method_60745(ModJukeboxSongs.TEARS));
    
    public static final Supplier<class_1792> HAPPY_GHAST_SPAWN_EGG = REGISTRIES.register("happy_ghast_spawn_egg",
        () -> ItemRegistry.createSpawnEgg(ModEntityTypes.HAPPY_GHAST, 16382457, 12369084, new class_1793()));
    
    // Hot as Lava
    
    public static final Supplier<class_1792> MUSIC_DISC_LAVA_CHICKEN = REGISTRIES.register("music_disc_lava_chicken",
        new class_1793()
            .method_7889(1)
            .method_7894(class_1814.field_8903)
            .method_60745(ModJukeboxSongs.LAVA_CHICKEN));

    // Copper Age
    
    public static final Supplier<class_1792> COPPER_SWORD = REGISTRIES.register("copper_sword",
        properties -> new class_1829(ModToolMaterials.COPPER, properties),
        new class_1793().method_57348(class_1829.method_57394(ModToolMaterials.COPPER, 3, -2.4F)));
    public static final Supplier<class_1792> COPPER_SHOVEL = REGISTRIES.register("copper_shovel",
        properties -> new class_1821(ModToolMaterials.COPPER, properties),
        new class_1793().method_57348(class_1821.method_57346(ModToolMaterials.COPPER, 1.5F, -3.0F)));
    public static final Supplier<class_1792> COPPER_PICKAXE = REGISTRIES.register("copper_pickaxe",
        properties -> new class_1810(ModToolMaterials.COPPER, properties),
        new class_1793().method_57348(class_1810.method_57346(ModToolMaterials.COPPER, 1.0F, -2.8F)));
    public static final Supplier<class_1792> COPPER_AXE = REGISTRIES.register("copper_axe",
        properties -> new class_1743(ModToolMaterials.COPPER, properties),
        new class_1793().method_57348(class_1743.method_57346(ModToolMaterials.COPPER, 7.0F, -3.2F)));
    public static final Supplier<class_1792> COPPER_HOE = REGISTRIES.register("copper_hoe",
        properties -> new class_1794(ModToolMaterials.COPPER, properties),
        new class_1793().method_57348(class_1794.method_57346(ModToolMaterials.COPPER, -1.0F, -2.0F)));
    
    public static final Supplier<class_1792> COPPER_HELMET = REGISTRIES.register("copper_helmet",
        properties -> new class_1738(ModArmorMaterials.COPPER, class_1738.class_8051.field_41934, properties),
        new class_1793().method_7895(class_1738.class_8051.field_41934.method_56690(11)));
    public static final Supplier<class_1792> COPPER_CHESTPLATE = REGISTRIES.register("copper_chestplate",
        properties -> new class_1738(ModArmorMaterials.COPPER, class_1738.class_8051.field_41935, properties),
        new class_1793().method_7895(class_1738.class_8051.field_41935.method_56690(11)));
    public static final Supplier<class_1792> COPPER_LEGGINGS = REGISTRIES.register("copper_leggings",
        properties -> new class_1738(ModArmorMaterials.COPPER, class_1738.class_8051.field_41936, properties),
        new class_1793().method_7895(class_1738.class_8051.field_41936.method_56690(11)));
    public static final Supplier<class_1792> COPPER_BOOTS = REGISTRIES.register("copper_boots",
        properties -> new class_1738(ModArmorMaterials.COPPER, class_1738.class_8051.field_41937, properties),
        new class_1793().method_7895(class_1738.class_8051.field_41937.method_56690(11)));
    
    public static final Supplier<class_1792> COPPER_NUGGET = REGISTRIES.register("copper_nugget");
    public static final Supplier<class_1792> COPPER_HORSE_ARMOR = REGISTRIES.register("copper_horse_armor",
        properties -> new class_4059(ModArmorMaterials.COPPER, class_4059.class_9076.field_47825, false, properties),
        new class_1793().method_7889(1));
    
    public static final Supplier<class_1792> COPPER_GOLEM_SPAWN_EGG = REGISTRIES.register("copper_golem_spawn_egg",
        () -> ItemRegistry.createSpawnEgg(ModEntityTypes.COPPER_GOLEM, 14052680, 8403233, new class_1793()));
    
    // Mounts of Mayhem
    
    public static final Supplier<class_1792> WOODEN_SPEAR = REGISTRIES.register("wooden_spear",
        properties -> new SpearItem(
            class_1834.field_8922,
            0.65F,
            0.7F,
            0.75F,
            5.0F,
            14.0F,
            10.0F,
            5.1F,
            15.0F,
            4.6F,
            properties));
    public static final Supplier<class_1792> STONE_SPEAR = REGISTRIES.register("stone_spear",
        properties -> new SpearItem(
            class_1834.field_8927,
            0.75F,
            0.82F,
            0.7F,
            4.5F,
            10.0F,
            9.0F,
            5.1F,
            13.75F,
            4.6F,
            properties));
    public static final Supplier<class_1792> COPPER_SPEAR = REGISTRIES.register("copper_spear",
        properties -> new SpearItem(
            ModToolMaterials.COPPER,
            0.85F,
            0.82F,
            0.65F,
            4.0F,
            9.0F,
            8.25F,
            5.1F,
            12.5F,
            4.6F,
            properties));
    public static final Supplier<class_1792> IRON_SPEAR = REGISTRIES.register("iron_spear",
        properties -> new SpearItem(
            class_1834.field_8923,
            0.95F,
            0.95F,
            0.6F,
            2.5F,
            8.0F,
            6.75F,
            5.1F,
            11.25F,
            4.6F,
            properties));
    public static final Supplier<class_1792> GOLDEN_SPEAR = REGISTRIES.register("golden_spear",
        properties -> new SpearItem(
            class_1834.field_8929,
            0.95F,
            0.7F,
            0.7F,
            3.5F,
            10.0F,
            8.5F,
            5.1F,
            13.75F,
            4.6F,
            properties));
    public static final Supplier<class_1792> DIAMOND_SPEAR = REGISTRIES.register("diamond_spear",
        properties -> new SpearItem(
            class_1834.field_8930,
            1.05F,
            1.075F,
            0.5F,
            3.0F,
            7.5F,
            6.5F,
            5.1F,
            10.0F,
            4.6F,
            properties));
    public static final Supplier<class_1792> NETHERITE_SPEAR = REGISTRIES.register("netherite_spear",
        properties -> new SpearItem(
            class_1834.field_22033,
            1.15F,
            1.2F,
            0.4F,
            2.5F,
            7.0F,
            5.5F,
            5.1F,
            8.75F,
            4.6F,
            properties.method_24359()));
    
    public static final Supplier<class_1792> NETHERITE_HORSE_ARMOR = REGISTRIES.register("netherite_horse_armor",
        properties -> new class_4059(class_1740.field_21977, class_4059.class_9076.field_47825, false, properties.method_7889(1).method_24359()) {
            @Override public class_9285 method_7844() {
                return Suppliers.memoize(() -> {
                    class_9285.class_9286 builder = class_9285.method_57480();
                    class_9274 slot = class_9274.method_59524(field_41933.method_48399());
                    class_2960 location = class_2960.method_60656("armor." + field_41933.method_48400());
                    builder.method_57487(class_5134.field_23724, new class_1322(location, 19, class_1322.class_1323.field_6328), slot);
                    builder.method_57487(class_5134.field_23725, new class_1322(location, field_7881.comp_349().comp_2303(), class_1322.class_1323.field_6328), slot);
                    float knockbackResistance = field_7881.comp_349().comp_2304();
                    if (knockbackResistance > 0.0F) {
                        builder.method_57487(class_5134.field_23718, new class_1322(location, knockbackResistance, class_1322.class_1323.field_6328), slot);
                    }
                    
                    return builder.method_57486();
                }).get();
            }
    });
    
    public static final Supplier<class_1792> COPPER_NAUTILUS_ARMOR = REGISTRIES.register("copper_nautilus_armor",
        properties -> new NautilusArmorItem(ModArmorMaterials.COPPER, properties.method_7889(1)));
    public static final Supplier<class_1792> IRON_NAUTILUS_ARMOR = REGISTRIES.register("iron_nautilus_armor",
        properties -> new NautilusArmorItem(class_1740.field_7892, properties.method_7889(1)));
    public static final Supplier<class_1792> GOLDEN_NAUTILUS_ARMOR = REGISTRIES.register("golden_nautilus_armor",
        properties -> new NautilusArmorItem(class_1740.field_7895, properties.method_7889(1)));
    public static final Supplier<class_1792> DIAMOND_NAUTILUS_ARMOR = REGISTRIES.register("diamond_nautilus_armor",
        properties -> new NautilusArmorItem(class_1740.field_7889, properties.method_7889(1)));
    public static final Supplier<class_1792> NETHERITE_NAUTILUS_ARMOR = REGISTRIES.register("netherite_nautilus_armor",
        properties -> new NautilusArmorItem(class_1740.field_21977, properties.method_7889(1).method_24359()) {
            @Override public class_9285 method_7844() {
                return Suppliers.memoize(() -> {
                    class_9285.class_9286 builder = class_9285.method_57480();
                    class_9274 slot = class_9274.method_59524(field_41933.method_48399());
                    class_2960 location = class_2960.method_60656("armor." + field_41933.method_48400());
                    builder.method_57487(class_5134.field_23724, new class_1322(location, 19, class_1322.class_1323.field_6328), slot);
                    builder.method_57487(class_5134.field_23725, new class_1322(location, field_7881.comp_349().comp_2303(), class_1322.class_1323.field_6328), slot);
                    float knockbackResistance = field_7881.comp_349().comp_2304();
                    if (knockbackResistance > 0.0F) {
                        builder.method_57487(class_5134.field_23718, new class_1322(location, knockbackResistance, class_1322.class_1323.field_6328), slot);
                    }
                    
                    return builder.method_57486();
                }).get();
            }
    });
    
    public static final Supplier<class_1792> PARCHED_SPAWN_EGG = REGISTRIES.register("parched_spawn_egg",
        () -> ItemRegistry.createSpawnEgg(ModEntityTypes.PARCHED, 7630438, 14533518, new class_1793()));
    public static final Supplier<class_1792> CAMEL_HUSK_SPAWN_EGG = REGISTRIES.register("camel_husk_spawn_egg",
        () -> ItemRegistry.createSpawnEgg(ModEntityTypes.CAMEL_HUSK, 6444612, 5523767, new class_1793()));
    public static final Supplier<class_1792> NAUTILUS_SPAWN_EGG = REGISTRIES.register("nautilus_spawn_egg",
        () -> ItemRegistry.createSpawnEgg(ModEntityTypes.NAUTILUS, 14800845, 14375489, new class_1793()));
    public static final Supplier<class_1792> ZOMBIE_NAUTILUS_SPAWN_EGG = REGISTRIES.register("zombie_nautilus_spawn_egg",
        () -> ItemRegistry.createSpawnEgg(ModEntityTypes.ZOMBIE_NAUTILUS, 14277311, 3622707, new class_1793()));
    
    // Chaos Cubed
    
    public static final Supplier<class_1792> SULFUR_CUBE_BUCKET = REGISTRIES.register("sulfur_cube_bucket",
        properties -> new SulfurCubeBucketItem<>(ModEntityTypes.SULFUR_CUBE, ModSoundEvents.BUCKET_EMPTY_SULFUR_CUBE.get(), properties),
        new class_1793().method_7889(1));
    
    public static final Supplier<class_1792> MUSIC_DISC_BOUNCE = REGISTRIES.register("music_disc_bounce",
        new class_1793()
            .method_7889(1)
            .method_7894(class_1814.field_8907)
            .method_60745(ModJukeboxSongs.BOUNCE));
    
    public static final Supplier<class_1792> SULFUR_CUBE_SPAWN_EGG = REGISTRIES.register("sulfur_cube_spawn_egg",
        () -> ItemRegistry.createSpawnEgg(ModEntityTypes.SULFUR_CUBE, 15528848, 13948048, new class_1793()));
    
    // Wilderness Bound
    
    public static final Supplier<class_1792> POPLAR_BOAT = REGISTRIES.register("poplar_boat",
        () -> new CustomBoatItem(ModBoatTypes.POPLAR, false, new class_1793().method_7889(1)));
    public static final Supplier<class_1792> POPLAR_CHEST_BOAT = REGISTRIES.register("poplar_chest_boat",
        () -> new CustomBoatItem(ModBoatTypes.POPLAR, true, new class_1793().method_7889(1)));
    
    public static final Supplier<class_1792> WHITE_CUSHION = REGISTRIES.register("white_cushion",
        properties -> new CushionItem(properties.method_7889(16), class_1767.field_7952));
    public static final Supplier<class_1792> ORANGE_CUSHION = REGISTRIES.register("orange_cushion",
        properties -> new CushionItem(properties.method_7889(16), class_1767.field_7946));
    public static final Supplier<class_1792> MAGENTA_CUSHION = REGISTRIES.register("magenta_cushion",
        properties -> new CushionItem(properties.method_7889(16), class_1767.field_7958));
    public static final Supplier<class_1792> LIGHT_BLUE_CUSHION = REGISTRIES.register("light_blue_cushion",
        properties -> new CushionItem(properties.method_7889(16), class_1767.field_7951));
    public static final Supplier<class_1792> YELLOW_CUSHION = REGISTRIES.register("yellow_cushion",
        properties -> new CushionItem(properties.method_7889(16), class_1767.field_7947));
    public static final Supplier<class_1792> LIME_CUSHION = REGISTRIES.register("lime_cushion",
        properties -> new CushionItem(properties.method_7889(16), class_1767.field_7961));
    public static final Supplier<class_1792> PINK_CUSHION = REGISTRIES.register("pink_cushion",
        properties -> new CushionItem(properties.method_7889(16), class_1767.field_7954));
    public static final Supplier<class_1792> GRAY_CUSHION = REGISTRIES.register("gray_cushion",
        properties -> new CushionItem(properties.method_7889(16), class_1767.field_7944));
    public static final Supplier<class_1792> LIGHT_GRAY_CUSHION = REGISTRIES.register("light_gray_cushion",
        properties -> new CushionItem(properties.method_7889(16), class_1767.field_7967));
    public static final Supplier<class_1792> CYAN_CUSHION = REGISTRIES.register("cyan_cushion",
        properties -> new CushionItem(properties.method_7889(16), class_1767.field_7955));
    public static final Supplier<class_1792> PURPLE_CUSHION = REGISTRIES.register("purple_cushion",
        properties -> new CushionItem(properties.method_7889(16), class_1767.field_7945));
    public static final Supplier<class_1792> BLUE_CUSHION = REGISTRIES.register("blue_cushion",
        properties -> new CushionItem(properties.method_7889(16), class_1767.field_7966));
    public static final Supplier<class_1792> BROWN_CUSHION = REGISTRIES.register("brown_cushion",
        properties -> new CushionItem(properties.method_7889(16), class_1767.field_7957));
    public static final Supplier<class_1792> GREEN_CUSHION = REGISTRIES.register("green_cushion",
        properties -> new CushionItem(properties.method_7889(16), class_1767.field_7942));
    public static final Supplier<class_1792> RED_CUSHION = REGISTRIES.register("red_cushion",
        properties -> new CushionItem(properties.method_7889(16), class_1767.field_7964));
    public static final Supplier<class_1792> BLACK_CUSHION = REGISTRIES.register("black_cushion",
        properties -> new CushionItem(properties.method_7889(16), class_1767.field_7963));
}