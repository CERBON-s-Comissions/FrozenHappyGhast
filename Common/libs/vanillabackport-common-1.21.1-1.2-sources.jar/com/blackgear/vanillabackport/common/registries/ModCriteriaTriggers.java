package com.blackgear.vanillabackport.common.registries;

import com.blackgear.platform.core.CoreRegistry;
import com.blackgear.vanillabackport.common.triggers.SpearMobsTrigger;
import com.blackgear.vanillabackport.core.VanillaBackport;
import java.util.function.Supplier;
import net.minecraft.class_179;
import net.minecraft.class_7924;

public class ModCriteriaTriggers {
    public static final CoreRegistry<class_179<?>> REGISTRIES = CoreRegistry.create(class_7924.field_47498, VanillaBackport.NAMESPACE);

    public static final Supplier<SpearMobsTrigger> SPEAR_MOBS_TRIGGER = REGISTRIES.register("spear_mobs", SpearMobsTrigger::new);
}