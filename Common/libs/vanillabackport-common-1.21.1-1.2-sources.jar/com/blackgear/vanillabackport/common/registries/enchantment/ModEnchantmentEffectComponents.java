package com.blackgear.vanillabackport.common.registries.enchantment;

import com.blackgear.platform.core.CoreRegistry;
import com.blackgear.vanillabackport.core.VanillaBackport;
import java.util.List;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;
import net.minecraft.class_173;
import net.minecraft.class_7923;
import net.minecraft.class_9331;
import net.minecraft.class_9698;
import net.minecraft.class_9721;

public class ModEnchantmentEffectComponents {
    public static final CoreRegistry<class_9331<?>> REGISTRIES = CoreRegistry.create(class_7923.field_51832, VanillaBackport.NAMESPACE);
    
    public static final Supplier<class_9331<List<class_9698<class_9721>>>> POST_PIERCING_ATTACK = register("post_piercing_attack",
        builder -> builder.method_57881(class_9698.method_60004(class_9721.field_51707, class_173.field_51801).listOf()));
    
    public static <T> Supplier<class_9331<T>> register(String key, UnaryOperator<class_9331.class_9332<T>> operator) {
        return REGISTRIES.register(key, () -> operator.apply(class_9331.method_57873()).method_57880());
    }
}