package com.blackgear.vanillabackport.common.registries;

import com.blackgear.platform.core.CoreRegistry;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.blackgear.vanillabackport.common.value_providers.TrapezoidInt;
import java.util.function.Supplier;
import net.minecraft.class_6018;
import net.minecraft.class_7924;

public class ModValueProviders {
    public static final CoreRegistry<class_6018<?>> REGISTRIES = CoreRegistry.create(class_7924.field_41196, VanillaBackport.NAMESPACE);

    public static final Supplier<class_6018<TrapezoidInt>> TRAPEZOID_INT = REGISTRIES.register("trapezoid", () -> () -> TrapezoidInt.CODEC);
}