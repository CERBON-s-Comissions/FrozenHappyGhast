package com.blackgear.vanillabackport.common.registries.enchantment;

import com.blackgear.platform.core.CoreRegistry;
import com.blackgear.vanillabackport.common.level.items.enchantment.effects.ApplyEntityImpulse;
import com.blackgear.vanillabackport.common.level.items.enchantment.effects.ApplyExhaustion;
import com.blackgear.vanillabackport.common.level.items.enchantment.effects.PlaySoundEffect;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_7924;
import net.minecraft.class_9722;

public class ModEnchantmentLocationBasedEffect {
    public static final CoreRegistry<MapCodec<? extends class_9722>> REGISTRIES = CoreRegistry.create(class_7924.field_51842, VanillaBackport.MOD_ID);
    
    static {
        REGISTRIES.register("apply_entity_impulse", () -> ApplyEntityImpulse.CODEC);
        REGISTRIES.register("apply_exhaustion", () -> ApplyExhaustion.CODEC);
        REGISTRIES.register("play_sound", () -> PlaySoundEffect.CODEC);
    }
}