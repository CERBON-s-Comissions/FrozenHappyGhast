package com.blackgear.vanillabackport.common.registries.blocks;

import com.blackgear.vanillabackport.common.level.blocks.CopperGolemStatueBlock;
import com.blackgear.vanillabackport.common.level.blocks.CreakingHeartState;
import com.blackgear.vanillabackport.common.level.blocks.PotentSulfurState;
import com.blackgear.vanillabackport.common.level.blocks.SideChainPart;
import net.minecraft.class_2746;
import net.minecraft.class_2754;
import net.minecraft.class_2758;

public class ModBlockStateProperties {
    public static final class_2746 TIP = class_2746.method_11825("tip");
    public static final class_2746 NATURAL = class_2746.method_11825("natural");
    public static final class_2754<CreakingHeartState> CREAKING_HEART_STATE = class_2754.method_11850("creaking_heart_state", CreakingHeartState.class);
    public static final class_2754<PotentSulfurState> POTENT_SULFUR_STATE = class_2754.method_11850("potent_sulfur_state", PotentSulfurState.class);
    public static final class_2758 HYDRATION_LEVEL = class_2758.method_11867("hydration", 0, 3);
    public static final class_2758 SEGMENT_AMOUNT = class_2758.method_11867("segment_amount", 1, 4);
    public static final class_2754<CopperGolemStatueBlock.Pose> COPPER_GOLEM_POSE = class_2754.method_11850("copper_golem_pose", CopperGolemStatueBlock.Pose.class);
    public static final class_2754<SideChainPart> SIDE_CHAIN_PART = class_2754.method_11850("side_chain", SideChainPart.class);
}