package com.blackgear.vanillabackport.common.registries.blocks;

import net.minecraft.class_8177;

public class ModBlockSetTypes {
    public static final class_8177 PALE_OAK = new class_8177("pale_oak");
    public static final class_8177 POPLAR = new class_8177("poplar");
}