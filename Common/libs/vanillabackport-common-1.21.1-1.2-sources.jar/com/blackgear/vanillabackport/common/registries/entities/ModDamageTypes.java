package com.blackgear.vanillabackport.common.registries.entities;

import com.blackgear.platform.core.api.registrar.bootstrap.BootstrapRegistrar;
import com.blackgear.vanillabackport.core.VanillaBackport;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.class_8107;
import net.minecraft.class_8110;

public class ModDamageTypes {
    public static final BootstrapRegistrar<class_8110> REGISTRIES = BootstrapRegistrar.create(class_7924.field_42534, VanillaBackport.NAMESPACE);

    public static final class_5321<class_8110> SULFUR_CUBE_HOT = REGISTRIES.register("sulfur_cube_hot",
        context -> new class_8110("sulfurCubeHot", 0.1F, class_8107.field_42278)
    );
}