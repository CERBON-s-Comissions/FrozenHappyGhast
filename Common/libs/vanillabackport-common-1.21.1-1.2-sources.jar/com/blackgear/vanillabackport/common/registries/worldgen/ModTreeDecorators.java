package com.blackgear.vanillabackport.common.registries.worldgen;

import com.blackgear.platform.core.CoreRegistry;
import com.blackgear.vanillabackport.common.level.worldgen.tree.decorators.*;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.blackgear.vanillabackport.core.mixin.common.access.TreeDecoratorTypeAccessor;
import com.mojang.serialization.MapCodec;
import java.util.function.Supplier;
import net.minecraft.class_4662;
import net.minecraft.class_4663;
import net.minecraft.class_7924;

public class ModTreeDecorators {
    public static final CoreRegistry<class_4663<?>> REGISTRIES = CoreRegistry.create(class_7924.field_41232, VanillaBackport.NAMESPACE);

    public static final Supplier<class_4663<PaleMossDecorator>> PALE_MOSS = register("pale_moss", PaleMossDecorator.CODEC);
    public static final Supplier<class_4663<CreakingHeartDecorator>> CREAKING_HEART = register("creaking_heart", CreakingHeartDecorator.CODEC);
    public static final Supplier<class_4663<AttachedToLogsDecorator>> ATTACHED_TO_LOGS = register("attached_to_logs", AttachedToLogsDecorator.CODEC);
    public static final Supplier<class_4663<PlaceOnGroundDecorator>> PLACE_ON_GROUND = register("place_on_ground", PlaceOnGroundDecorator.CODEC);
    public static final Supplier<class_4663<ShelfMushroomDecorator>> SHELF_MUSHROOM = register("shelf_mushroom", ShelfMushroomDecorator.CODEC);

    private static <P extends class_4662> Supplier<class_4663<P>> register(String name, MapCodec<P> codec) {
        return REGISTRIES.register(name, () -> TreeDecoratorTypeAccessor.createTreeDecorator(codec));
    }
}