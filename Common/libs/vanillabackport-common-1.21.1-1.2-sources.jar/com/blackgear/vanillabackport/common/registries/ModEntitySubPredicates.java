package com.blackgear.vanillabackport.common.registries;

import com.blackgear.platform.core.CoreRegistry;
import com.blackgear.vanillabackport.common.predicates.PlayerPredicate;
import com.blackgear.vanillabackport.common.value_providers.TrapezoidInt;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.mojang.serialization.MapCodec;
import java.util.function.Supplier;
import net.minecraft.class_7376;
import net.minecraft.class_7924;

public class ModEntitySubPredicates {
    public static final CoreRegistry<MapCodec<? extends class_7376>> REGISTRIES = CoreRegistry.create(class_7924.field_49913, VanillaBackport.MOD_ID);

    public static final Supplier<MapCodec<PlayerPredicate>> PLAYER_PREDICATE = REGISTRIES.register("player", () -> PlayerPredicate.CODEC);
}