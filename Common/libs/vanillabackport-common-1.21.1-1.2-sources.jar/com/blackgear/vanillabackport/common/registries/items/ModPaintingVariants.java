package com.blackgear.vanillabackport.common.registries.items;

import com.blackgear.platform.core.api.registrar.bootstrap.BootstrapRegistrar;
import com.blackgear.vanillabackport.core.VanillaBackport;
import net.minecraft.class_1535;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

public class ModPaintingVariants {
    public static final BootstrapRegistrar<class_1535> REGISTRIES = BootstrapRegistrar.create(class_7924.field_41209, VanillaBackport.NAMESPACE);
    
    public static final class_5321<class_1535> DENNIS = register("dennis", 3, 3);
    
    private static class_5321<class_1535> register(String name, int width, int height) {
        return REGISTRIES.resource(
            name,
            (context, key) -> new class_1535(width, height, key));
    }
}