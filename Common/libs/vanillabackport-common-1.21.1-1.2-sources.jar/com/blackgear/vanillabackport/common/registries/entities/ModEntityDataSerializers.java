package com.blackgear.vanillabackport.common.registries.entities;

import com.blackgear.platform.core.helper.DataSerializerRegistry;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.golem.copper_golem.CopperGolemState;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.blackgear.vanillabackport.core.util.WeatheredData;
import java.util.function.Supplier;
import net.minecraft.class_1767;
import net.minecraft.class_2941;
import net.minecraft.class_5955;

public class ModEntityDataSerializers {
    public static final DataSerializerRegistry SERIALIZERS = DataSerializerRegistry.create(VanillaBackport.NAMESPACE);
    
    public static final Supplier<class_2941<class_5955.class_5811>> WEATHERING_COPPER_STATE = SERIALIZERS.register("weathering_copper_state", WeatheredData.STREAM_CODEC);
    public static final Supplier<class_2941<CopperGolemState>> COPPER_GOLEM_STATE = SERIALIZERS.register("copper_golem_state", CopperGolemState.STREAM_CODEC);
    public static final Supplier<class_2941<class_1767>> DYE_COLOR = SERIALIZERS.register("dye_color", class_1767.field_49259);
}