package com.blackgear.vanillabackport.common.registries.blocks;

import com.blackgear.platform.core.helper.BlockRegistry;
import com.blackgear.vanillabackport.client.registries.ModParticles;
import com.blackgear.vanillabackport.client.registries.ModSoundEvents;
import com.blackgear.vanillabackport.client.registries.ModSoundTypes;
import com.blackgear.vanillabackport.common.level.blocks.*;
import com.blackgear.vanillabackport.common.level.blocks.properties.SharedBlockProperties;
import com.blackgear.vanillabackport.common.level.sounds.AmbientLeavesBlockSoundPlayer;
import com.blackgear.vanillabackport.common.registries.worldgen.ModTreeGrowers;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.blackgear.vanillabackport.core.data.tags.ModBlockTags;
import com.mojang.datafixers.util.Pair;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1822;
import net.minecraft.class_1827;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2269;
import net.minecraft.class_2323;
import net.minecraft.class_2349;
import net.minecraft.class_2350;
import net.minecraft.class_2354;
import net.minecraft.class_2362;
import net.minecraft.class_2389;
import net.minecraft.class_2400;
import net.minecraft.class_2440;
import net.minecraft.class_2465;
import net.minecraft.class_2473;
import net.minecraft.class_2482;
import net.minecraft.class_2498;
import net.minecraft.class_2508;
import net.minecraft.class_2510;
import net.minecraft.class_2533;
import net.minecraft.class_2544;
import net.minecraft.class_2551;
import net.minecraft.class_2766;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_3749;
import net.minecraft.class_4719;
import net.minecraft.class_4970;
import net.minecraft.class_4970.class_2251;
import net.minecraft.class_5172;
import net.minecraft.class_5554;
import net.minecraft.class_5955.class_5811;
import net.minecraft.class_7707;
import net.minecraft.class_7713;
import net.minecraft.class_7715;
import net.minecraft.class_8169;
import net.minecraft.world.item.*;
import net.minecraft.world.level.block.*;
import java.util.function.Supplier;

public class ModBlocks {
    public static final BlockRegistry REGISTRIES = BlockRegistry.create(VanillaBackport.NAMESPACE);
    
    // The Garden Awakens
    
    public static final Supplier<class_2248> CREAKING_HEART = REGISTRIES.register("creaking_heart",
        CreakingHeartBlock::new,
        class_2251.method_9637()
            .method_31710(class_3620.field_15987)
            .method_51368(class_2766.field_12653)
            .method_9632(10.0F)
            .method_9626(ModSoundTypes.CREAKING_HEART));
    
    public static final Supplier<class_2248> PALE_OAK_LOG = REGISTRIES.register("pale_oak_log",
        class_2465::new,
        SharedBlockProperties.logProperties(class_3620.field_16025, class_3620.field_16023, class_2498.field_11547));
    public static final Supplier<class_2248> STRIPPED_PALE_OAK_LOG = REGISTRIES.register("stripped_pale_oak_log",
        class_2465::new,
        SharedBlockProperties.logProperties(class_3620.field_16025, class_3620.field_16025, class_2498.field_11547));
    public static final Supplier<class_2248> PALE_OAK_WOOD = REGISTRIES.register("pale_oak_wood",
        class_2465::new,
        class_2251.method_9637()
            .method_31710(class_3620.field_16023)
            .method_51368(class_2766.field_12651)
            .method_9632(2.0F)
            .method_9626(class_2498.field_11547)
            .method_50013());
    public static final Supplier<class_2248> STRIPPED_PALE_OAK_WOOD = REGISTRIES.register("stripped_pale_oak_wood",
        class_2465::new,
        class_2251.method_9637()
            .method_31710(class_3620.field_16025)
            .method_51368(class_2766.field_12651)
            .method_9632(2.0F)
            .method_9626(class_2498.field_11547)
            .method_50013());
    
    public static final Supplier<class_2248> PALE_OAK_PLANKS = REGISTRIES.register("pale_oak_planks", SharedBlockProperties.PALE_OAK);
    public static final Supplier<class_2248> PALE_OAK_SLAB = REGISTRIES.register("pale_oak_slab", class_2482::new, SharedBlockProperties.PALE_OAK);
    public static final Supplier<class_2248> PALE_OAK_STAIRS = REGISTRIES.register("pale_oak_stairs", () -> new class_2510(PALE_OAK_PLANKS.get().method_9564(), SharedBlockProperties.PALE_OAK));
    
    public static final Pair<Supplier<class_2248>, Supplier<class_2248>> PALE_OAK_SIGN = sign("pale_oak",
        ModWoodTypes.PALE_OAK,
        class_3620.field_16025);
    public static final Pair<Supplier<class_2248>, Supplier<class_2248>> PALE_OAK_HANGING_SIGN = hangingSign("pale_oak",
        ModWoodTypes.PALE_OAK,
        class_3620.field_16025);
    public static final Supplier<class_2248> PALE_OAK_BUTTON = REGISTRIES.register("pale_oak_button",
        properties -> new class_2269(ModBlockSetTypes.PALE_OAK, 30, properties),
        SharedBlockProperties.buttonProperties());
    public static final Supplier<class_2248> PALE_OAK_PRESSURE_PLATE = REGISTRIES.register("pale_oak_pressure_plate",
        properties -> new class_2440(ModBlockSetTypes.PALE_OAK, properties),
        class_2251.method_9637()
            .method_31710(class_3620.field_16025)
            .method_51369()
            .method_51368(class_2766.field_12651)
            .method_9634()
            .method_9632(0.5F)
            .method_50013()
            .method_50012(class_3619.field_15971));
    public static final Supplier<class_2248> PALE_OAK_DOOR = REGISTRIES.register("pale_oak_door",
        properties -> new class_2323(ModBlockSetTypes.PALE_OAK, properties),
        class_2251.method_9637()
            .method_31710(class_3620.field_16025)
            .method_51368(class_2766.field_12651)
            .method_9632(3.0F)
            .method_22488()
            .method_50013()
            .method_50012(class_3619.field_15971));
    public static final Supplier<class_2248> PALE_OAK_FENCE = REGISTRIES.register("pale_oak_fence",
        class_2354::new,
        class_2251.method_9637()
            .method_31710(class_3620.field_16025)
            .method_51368(class_2766.field_12651)
            .method_9629(2.0F, 3.0F)
            .method_9626(class_2498.field_11547)
            .method_50013());
    public static final Supplier<class_2248> PALE_OAK_FENCE_GATE = REGISTRIES.register("pale_oak_fence_gate",
        properties -> new class_2349(ModWoodTypes.PALE_OAK, properties),
        class_2251.method_9637()
            .method_31710(class_3620.field_16025)
            .method_51369()
            .method_51368(class_2766.field_12651)
            .method_9629(2.0F, 3.0F)
            .method_50013());
    public static final Supplier<class_2248> PALE_OAK_TRAPDOOR = REGISTRIES.register("pale_oak_trapdoor",
        properties -> new class_2533(ModBlockSetTypes.PALE_OAK, properties),
        class_2251.method_9637()
            .method_31710(class_3620.field_16025)
            .method_51368(class_2766.field_12651)
            .method_9632(3.0F)
            .method_22488()
            .method_26235(REGISTRIES::never)
            .method_50013());
    
    public static final Supplier<class_2248> PALE_HANGING_MOSS = REGISTRIES.register("pale_hanging_moss",
        HangingMossBlock::new,
        class_2251.method_9637()
            .method_50013()
            .method_31710(class_3620.field_15993)
            .method_9634()
            .method_9626(class_2498.field_28696)
            .method_50012(class_3619.field_15971));
    public static final Supplier<class_2248> PALE_MOSS_BLOCK = REGISTRIES.register("pale_moss_block",
        PaleMossBlock::new,
        class_2251.method_9637()
            .method_50013()
            .method_31710(class_3620.field_15993)
            .method_9632(0.1F)
            .method_9626(class_2498.field_28697)
            .method_50012(class_3619.field_15971));
    public static final Supplier<class_2248> PALE_MOSS_CARPET = REGISTRIES.register("pale_moss_carpet",
        MossyCarpetBlock::new,
        class_2251.method_9637()
            .method_50013()
            .method_31710(class_3620.field_15993)
            .method_9632(0.1F)
            .method_9626(class_2498.field_28697)
            .method_50012(class_3619.field_15971)
            .method_22488());
    
    public static final Supplier<class_2248> PALE_OAK_LEAVES = REGISTRIES.register("pale_oak_leaves",
        properties -> new ParticleLeavesBlock(0.02F, ModParticles.PALE_OAK_LEAVES, properties),
        class_2251.method_9637()
            .method_31710(class_3620.field_16028)
            .method_9632(0.2F)
            .method_9640()
            .method_9626(class_2498.field_11535)
            .method_22488()
            .method_26235(REGISTRIES::ocelotOrParrot)
            .method_26243(REGISTRIES::never)
            .method_26245(REGISTRIES::never)
            .method_50013()
            .method_50012(class_3619.field_15971)
            .method_26236(REGISTRIES::never));
    
    public static final Supplier<class_2248> PALE_OAK_SAPLING = REGISTRIES.register("pale_oak_sapling",
        properties -> new class_2473(ModTreeGrowers.PALE_OAK.get(), properties),
        class_2251.method_9637()
            .method_31710(class_3620.field_15993)
            .method_9634()
            .method_9640()
            .method_9618()
            .method_9626(class_2498.field_11535)
            .method_50012(class_3619.field_15971));
    public static final Supplier<class_2248> POTTED_PALE_OAK_SAPLING = REGISTRIES.registerNoItem("potted_pale_oak_sapling",
        properties -> new class_2362(PALE_OAK_SAPLING.get(), properties),
        SharedBlockProperties.flowerPotProperties());
    
    public static final Supplier<class_2248> CLOSED_EYEBLOSSOM = REGISTRIES.register("closed_eyeblossom",
        properties -> new EyeblossomBlock(EyeblossomBlock.Type.CLOSED, properties),
        class_2251.method_9637()
            .method_31710(class_3620.field_15993)
            .method_9634()
            .method_9618()
            .method_9626(class_2498.field_11535)
            .method_49229(class_4970.class_2250.field_10657)
            .method_50012(class_3619.field_15971)
            .method_9640());
    public static final Supplier<class_2248> POTTED_CLOSED_EYEBLOSSOM = REGISTRIES.registerNoItem("potted_closed_eyeblossom",
        properties -> new EyeblossomPotBlock(CLOSED_EYEBLOSSOM.get(), properties),
        SharedBlockProperties.flowerPotProperties().method_9640());
    
    public static final Supplier<class_2248> OPEN_EYEBLOSSOM = REGISTRIES.register("open_eyeblossom",
        properties -> new EyeblossomBlock(EyeblossomBlock.Type.OPEN, properties),
        class_2251.method_9637()
            .method_31710(class_3620.field_15987)
            .method_9634()
            .method_9618()
            .method_9626(class_2498.field_11535)
            .method_49229(class_4970.class_2250.field_10657)
            .method_50012(class_3619.field_15971)
            .method_9640());
    public static final Supplier<class_2248> POTTED_OPEN_EYEBLOSSOM = REGISTRIES.registerNoItem("potted_open_eyeblossom",
        properties -> new EyeblossomPotBlock(OPEN_EYEBLOSSOM.get(), properties),
        SharedBlockProperties.flowerPotProperties().method_9640());
    
    public static final Supplier<class_2248> RESIN_BLOCK = REGISTRIES.register("resin_block",
        class_2251.method_9637()
            .method_31710(class_3620.field_15981)
            .method_51368(class_2766.field_12653)
            .method_9626(ModSoundTypes.RESIN));
    
    public static final Supplier<class_2248> RESIN_BRICKS = REGISTRIES.register("resin_bricks", SharedBlockProperties.RESIN_BRICKS);
    public static final Supplier<class_2248> CHISELED_RESIN_BRICKS = REGISTRIES.register("chiseled_resin_bricks", SharedBlockProperties.RESIN_BRICKS);
    public static final Supplier<class_2248> RESIN_BRICK_SLAB = REGISTRIES.register("resin_brick_slab", class_2482::new, SharedBlockProperties.RESIN_BRICKS);
    public static final Supplier<class_2248> RESIN_BRICK_STAIRS = REGISTRIES.register("resin_brick_stairs", () -> new class_2510(RESIN_BRICKS.get().method_9564(), SharedBlockProperties.RESIN_BRICKS));
    public static final Supplier<class_2248> RESIN_BRICK_WALL = REGISTRIES.register("resin_brick_wall", class_2544::new, SharedBlockProperties.RESIN_BRICKS);
    
    public static final Supplier<class_2248> RESIN_CLUMP = REGISTRIES.register("resin_clump",
        ResinClumpBlock::new,
        class_2251.method_9637()
            .method_31710(class_3620.field_15981)
            .method_51371()
            .method_9634()
            .method_9626(ModSoundTypes.RESIN)
            .method_50013()
            .method_50012(class_3619.field_15971));
    
    // Spring to Life
    
    public static final Supplier<class_2248> LEAF_LITTER = REGISTRIES.register("leaf_litter",
        LeafLitterBlock::new,
        class_2251.method_9637()
            .method_31710(class_3620.field_15977)
            .method_51371()
            .method_9634()
            .method_9626(ModSoundTypes.LEAF_LITTER)
            .method_50012(class_3619.field_15971));
    public static final Supplier<class_2248> WILDFLOWERS = REGISTRIES.register("wildflowers",
        class_8169::new,
        class_2251.method_9637()
            .method_31710(class_3620.field_16004)
            .method_9634()
            .method_9626(class_2498.field_42772)
            .method_50012(class_3619.field_15971));
    public static final Supplier<class_2248> BUSH = REGISTRIES.register("bush",
        ActualBushBlock::new,
        class_2251.method_9637()
            .method_31710(class_3620.field_16004)
            .method_51371()
            .method_9634()
            .method_9618()
            .method_9626(class_2498.field_11535)
            .method_50013()
            .method_50012(class_3619.field_15971));
    public static final Supplier<class_2248> FIREFLY_BUSH = REGISTRIES.register("firefly_bush",
        FireflyBushBlock::new,
        class_2251.method_9637()
            .method_31710(class_3620.field_16004)
            .method_50013()
            .method_9631(state -> 2)
            .method_9634()
            .method_9618()
            .method_9626(class_2498.field_17579)
            .method_50012(class_3619.field_15971));
    public static final Supplier<class_2248> CACTUS_FLOWER = REGISTRIES.register("cactus_flower",
        CactusFlowerBlock::new,
        class_2251.method_9637()
            .method_31710(class_3620.field_16030)
            .method_9634()
            .method_9618()
            .method_50013()
            .method_9626(ModSoundTypes.CACTUS_FLOWER)
            .method_50012(class_3619.field_15971));
    public static final Supplier<class_2248> SHORT_DRY_GRASS = REGISTRIES.register("short_dry_grass",
        ShortDryGrassBlock::new,
        class_2251.method_9637()
            .method_31710(class_3620.field_16010)
            .method_51371()
            .method_9634()
            .method_9618()
            .method_9626(class_2498.field_11535)
            .method_50013()
            .method_49229(class_4970.class_2250.field_10655)
            .method_50012(class_3619.field_15971));
    public static final Supplier<class_2248> TALL_DRY_GRASS = REGISTRIES.register("tall_dry_grass",
        TallDryGrassBlock::new,
        class_2251.method_9637()
            .method_31710(class_3620.field_16010)
            .method_51371()
            .method_9634()
            .method_9618()
            .method_9626(class_2498.field_11535)
            .method_50013()
            .method_49229(class_4970.class_2250.field_10655)
            .method_50012(class_3619.field_15971));
    
    // Chase the Skies
    
    public static final Supplier<class_2248> DRIED_GHAST = REGISTRIES.register("dried_ghast",
        DriedGhastBlock::new,
        class_2251.method_9637()
            .method_31710(class_3620.field_15978)
            .method_9618()
            .method_9626(ModSoundTypes.DRIED_GHAST)
            .method_22488()
            .method_9640());
    
    // Copper Age
    
    public static final Supplier<class_2248> COPPER_CHEST = REGISTRIES.register("copper_chest",
        () -> new WeatheringCopperChestBlock(
            class_5811.field_28704,
            ModSoundEvents.COPPER_CHEST_OPEN.get(),
            ModSoundEvents.COPPER_CHEST_CLOSE.get(),
            SharedBlockProperties.COPPER_CHEST.method_31710(class_2246.field_27119.method_26403())));
    public static final Supplier<class_2248> EXPOSED_COPPER_CHEST = REGISTRIES.register("exposed_copper_chest",
        () -> new WeatheringCopperChestBlock(
            class_5811.field_28705,
            ModSoundEvents.COPPER_CHEST_OPEN.get(),
            ModSoundEvents.COPPER_CHEST_CLOSE.get(),
            SharedBlockProperties.COPPER_CHEST.method_31710(class_3620.field_15988)));
    public static final Supplier<class_2248> WEATHERED_COPPER_CHEST = REGISTRIES.register("weathered_copper_chest",
        () -> new WeatheringCopperChestBlock(
            class_5811.field_28706,
            ModSoundEvents.COPPER_CHEST_WEATHERED_OPEN.get(),
            ModSoundEvents.COPPER_CHEST_WEATHERED_CLOSE.get(),
            SharedBlockProperties.COPPER_CHEST.method_31710(class_3620.field_25706)));
    public static final Supplier<class_2248> OXIDIZED_COPPER_CHEST = REGISTRIES.register("oxidized_copper_chest",
        () -> new WeatheringCopperChestBlock(
            class_5811.field_28707,
            ModSoundEvents.COPPER_CHEST_OXIDIZED_OPEN.get(),
            ModSoundEvents.COPPER_CHEST_OXIDIZED_CLOSE.get(),
            SharedBlockProperties.COPPER_CHEST.method_31710(class_3620.field_25705)));
    
    public static final Supplier<class_2248> WAXED_COPPER_CHEST = REGISTRIES.register("waxed_copper_chest",
        () -> new CopperChestBlock(
            class_5811.field_28704,
            ModSoundEvents.COPPER_CHEST_OPEN.get(),
            ModSoundEvents.COPPER_CHEST_CLOSE.get(),
            SharedBlockProperties.COPPER_CHEST.method_31710(class_2246.field_27119.method_26403())));
    public static final Supplier<class_2248> WAXED_EXPOSED_COPPER_CHEST = REGISTRIES.register("waxed_exposed_copper_chest",
        () -> new CopperChestBlock(
            class_5811.field_28705,
            ModSoundEvents.COPPER_CHEST_OPEN.get(),
            ModSoundEvents.COPPER_CHEST_CLOSE.get(),
            SharedBlockProperties.COPPER_CHEST.method_31710(class_3620.field_15988)));
    public static final Supplier<class_2248> WAXED_WEATHERED_COPPER_CHEST = REGISTRIES.register("waxed_weathered_copper_chest",
        () -> new CopperChestBlock(
            class_5811.field_28706,
            ModSoundEvents.COPPER_CHEST_WEATHERED_OPEN.get(),
            ModSoundEvents.COPPER_CHEST_WEATHERED_CLOSE.get(),
            SharedBlockProperties.COPPER_CHEST.method_31710(class_3620.field_25706)));
    public static final Supplier<class_2248> WAXED_OXIDIZED_COPPER_CHEST = REGISTRIES.register("waxed_oxidized_copper_chest",
        () -> new CopperChestBlock(
            class_5811.field_28707,
            ModSoundEvents.COPPER_CHEST_OXIDIZED_OPEN.get(),
            ModSoundEvents.COPPER_CHEST_OXIDIZED_CLOSE.get(),
            SharedBlockProperties.COPPER_CHEST.method_31710(class_3620.field_25705)));
    
    public static final Supplier<class_2248> ACACIA_SHELF = REGISTRIES.register("acacia_shelf",
        ShelfBlock::new,
        SharedBlockProperties.SHELF
            .method_31710(class_2246.field_10218.method_26403())
            .method_50013());
    public static final Supplier<class_2248> BAMBOO_SHELF = REGISTRIES.register("bamboo_shelf",
        ShelfBlock::new,
        SharedBlockProperties.SHELF
            .method_31710(class_2246.field_40294.method_26403())
            .method_50013());
    public static final Supplier<class_2248> BIRCH_SHELF = REGISTRIES.register("birch_shelf",
        ShelfBlock::new,
        SharedBlockProperties.SHELF
            .method_31710(class_2246.field_10148.method_26403())
            .method_50013());
    public static final Supplier<class_2248> CHERRY_SHELF = REGISTRIES.register("cherry_shelf",
        ShelfBlock::new,
        SharedBlockProperties.SHELF
            .method_31710(class_2246.field_42751.method_26403())
            .method_50013());
    public static final Supplier<class_2248> CRIMSON_SHELF = REGISTRIES.register("crimson_shelf",
        ShelfBlock::new,
        SharedBlockProperties.SHELF
            .method_31710(class_2246.field_22126.method_26403()));
    public static final Supplier<class_2248> DARK_OAK_SHELF = REGISTRIES.register("dark_oak_shelf",
        ShelfBlock::new,
        SharedBlockProperties.SHELF
            .method_31710(class_2246.field_10075.method_26403())
            .method_50013());
    public static final Supplier<class_2248> JUNGLE_SHELF = REGISTRIES.register("jungle_shelf",
        ShelfBlock::new,
        SharedBlockProperties.SHELF
            .method_31710(class_2246.field_10334.method_26403())
            .method_50013());
    public static final Supplier<class_2248> MANGROVE_SHELF = REGISTRIES.register("mangrove_shelf",
        ShelfBlock::new,
        SharedBlockProperties.SHELF
            .method_31710(class_2246.field_37577.method_26403())
            .method_50013());
    public static final Supplier<class_2248> OAK_SHELF = REGISTRIES.register("oak_shelf",
        ShelfBlock::new,
        SharedBlockProperties.SHELF
            .method_31710(class_2246.field_10161.method_26403())
            .method_50013());
    public static final Supplier<class_2248> PALE_OAK_SHELF = REGISTRIES.register("pale_oak_shelf",
        ShelfBlock::new,
        SharedBlockProperties.SHELF
            .method_31710(class_3620.field_16025)
            .method_50013());
    public static final Supplier<class_2248> SPRUCE_SHELF = REGISTRIES.register("spruce_shelf",
        ShelfBlock::new,
        SharedBlockProperties.SHELF
            .method_31710(class_2246.field_9975.method_26403())
            .method_50013());
    public static final Supplier<class_2248> WARPED_SHELF = REGISTRIES.register("warped_shelf",
        ShelfBlock::new,
        SharedBlockProperties.SHELF
            .method_31710(class_2246.field_22127.method_26403()));
    
    public static final Supplier<class_2248> EXPOSED_LIGHTNING_ROD = REGISTRIES.register("exposed_lightning_rod",
        properties -> new WeatheringLightningRodBlock(class_5811.field_28705, properties),
        class_2251.method_9630(class_2246.field_27171).method_31710(class_3620.field_15988));
    public static final Supplier<class_2248> WEATHERED_LIGHTNING_ROD = REGISTRIES.register("weathered_lightning_rod",
        properties -> new WeatheringLightningRodBlock(class_5811.field_28706, properties),
        class_2251.method_9630(class_2246.field_27171).method_31710(class_3620.field_25706));
    public static final Supplier<class_2248> OXIDIZED_LIGHTNING_ROD = REGISTRIES.register("oxidized_lightning_rod",
        properties -> new WeatheringLightningRodBlock(class_5811.field_28707, properties),
        class_2251.method_9630(class_2246.field_27171).method_31710(class_3620.field_25705));
    
    public static final Supplier<class_2248> WAXED_LIGHTNING_ROD = REGISTRIES.register("waxed_lightning_rod",
        class_5554::new,
        class_2251.method_9630(class_2246.field_27171));
    public static final Supplier<class_2248> WAXED_EXPOSED_LIGHTNING_ROD = REGISTRIES.register("waxed_exposed_lightning_rod",
        class_5554::new,
        class_2251.method_9630(class_2246.field_27171).method_31710(class_3620.field_15988));
    public static final Supplier<class_2248> WAXED_WEATHERED_LIGHTNING_ROD = REGISTRIES.register("waxed_weathered_lightning_rod",
        class_5554::new,
        class_2251.method_9630(class_2246.field_27171).method_31710(class_3620.field_25706));
    public static final Supplier<class_2248> WAXED_OXIDIZED_LIGHTNING_ROD = REGISTRIES.register("waxed_oxidized_lightning_rod",
        class_5554::new,
        class_2251.method_9630(class_2246.field_27171).method_31710(class_3620.field_25705));
    
    public static final Supplier<class_2248> COPPER_GOLEM_STATUE = REGISTRIES.register("copper_golem_statue",
        () -> new WeatheringCopperGolemStatueBlock(
            class_5811.field_28704,
            SharedBlockProperties.COPPER_GOLEM_STATUE.method_31710(class_2246.field_27119.method_26403())));
    public static final Supplier<class_2248> EXPOSED_COPPER_GOLEM_STATUE = REGISTRIES.register("exposed_copper_golem_statue",
        () -> new WeatheringCopperGolemStatueBlock(
            class_5811.field_28705,
            SharedBlockProperties.COPPER_GOLEM_STATUE.method_31710(class_3620.field_15988)));
    public static final Supplier<class_2248> WEATHERED_COPPER_GOLEM_STATUE = REGISTRIES.register("weathered_copper_golem_statue",
        () -> new WeatheringCopperGolemStatueBlock(
            class_5811.field_28706,
            SharedBlockProperties.COPPER_GOLEM_STATUE.method_31710(class_3620.field_25706)));
    public static final Supplier<class_2248> OXIDIZED_COPPER_GOLEM_STATUE = REGISTRIES.register("oxidized_copper_golem_statue",
        () -> new WeatheringCopperGolemStatueBlock(
            class_5811.field_28707,
            SharedBlockProperties.COPPER_GOLEM_STATUE.method_31710(class_3620.field_25705)));
    
    public static final Supplier<class_2248> WAXED_COPPER_GOLEM_STATUE = REGISTRIES.register("waxed_copper_golem_statue",
        () -> new CopperGolemStatueBlock(
            class_5811.field_28704,
            SharedBlockProperties.COPPER_GOLEM_STATUE.method_31710(class_2246.field_27119.method_26403())));
    public static final Supplier<class_2248> WAXED_EXPOSED_COPPER_GOLEM_STATUE = REGISTRIES.register("waxed_exposed_copper_golem_statue",
        () -> new CopperGolemStatueBlock(
            class_5811.field_28705,
            SharedBlockProperties.COPPER_GOLEM_STATUE.method_31710(class_3620.field_15988)));
    public static final Supplier<class_2248> WAXED_WEATHERED_COPPER_GOLEM_STATUE = REGISTRIES.register("waxed_weathered_copper_golem_statue",
        () -> new CopperGolemStatueBlock(
            class_5811.field_28706,
            SharedBlockProperties.COPPER_GOLEM_STATUE.method_31710(class_3620.field_25706)));
    public static final Supplier<class_2248> WAXED_OXIDIZED_COPPER_GOLEM_STATUE = REGISTRIES.register("waxed_oxidized_copper_golem_statue",
        () -> new CopperGolemStatueBlock(
            class_5811.field_28707,
            SharedBlockProperties.COPPER_GOLEM_STATUE.method_31710(class_3620.field_25705)));
    
    public static final Pair<Supplier<class_2248>, Supplier<class_2248>> COPPER_TORCH = torch("copper", ModParticles.COPPER_FIRE_FLAME);
    public static final WeatheringCopperBlocks COPPER_LANTERN = WeatheringCopperBlocks.create("copper_lantern",
        REGISTRIES::register,
        class_3749::new,
        WeatheringLanternBlock::new,
        properties -> class_2251.method_9637()
            .method_31710(class_3620.field_16005)
            .method_51369()
            .method_9632(3.5F)
            .method_9626(class_2498.field_17734)
            .method_9631(state -> 15)
            .method_22488()
            .method_50012(class_3619.field_15971));
    public static final WeatheringCopperBlocks COPPER_BARS = WeatheringCopperBlocks.create("copper_bars",
        REGISTRIES::register,
        class_2389::new,
        WeatheringCopperBarsBlock::new,
        properties -> class_2251.method_9637()
            .method_29292()
            .method_9629(5.0F, 6.0F)
            .method_9626(class_2498.field_27204)
            .method_22488());
    public static final WeatheringCopperBlocks COPPER_CHAIN = WeatheringCopperBlocks.create("copper_chain",
        REGISTRIES::register,
        class_5172::new,
        WeatheringCopperChainBlock::new,
        properties -> class_2251.method_9637()
            .method_51369()
            .method_29292()
            .method_9629(5.0F, 6.0F)
            .method_9626(class_2498.field_24119)
            .method_22488());
    
    // Chaos Cubed
    
    public static final Supplier<class_2248> CINNABAR = REGISTRIES.register("cinnabar", SharedBlockProperties.CINNABAR);
    public static final Supplier<class_2248> CINNABAR_SLAB = REGISTRIES.register("cinnabar_slab", class_2482::new, SharedBlockProperties.CINNABAR);
    public static final Supplier<class_2248> CINNABAR_STAIRS = REGISTRIES.register("cinnabar_stairs", () -> new class_2510(CINNABAR.get().method_9564(), SharedBlockProperties.CINNABAR));
    public static final Supplier<class_2248> CINNABAR_WALL = REGISTRIES.register("cinnabar_wall", class_2544::new, SharedBlockProperties.CINNABAR);
    public static final Supplier<class_2248> POLISHED_CINNABAR = REGISTRIES.register("polished_cinnabar", SharedBlockProperties.CINNABAR);
    public static final Supplier<class_2248> POLISHED_CINNABAR_SLAB = REGISTRIES.register("polished_cinnabar_slab", class_2482::new, SharedBlockProperties.CINNABAR);
    public static final Supplier<class_2248> POLISHED_CINNABAR_STAIRS = REGISTRIES.register("polished_cinnabar_stairs", () -> new class_2510(POLISHED_CINNABAR.get().method_9564(), SharedBlockProperties.CINNABAR));
    public static final Supplier<class_2248> POLISHED_CINNABAR_WALL = REGISTRIES.register("polished_cinnabar_wall", class_2544::new, SharedBlockProperties.CINNABAR);
    public static final Supplier<class_2248> CINNABAR_BRICKS = REGISTRIES.register("cinnabar_bricks", SharedBlockProperties.CINNABAR);
    public static final Supplier<class_2248> CINNABAR_BRICK_SLAB = REGISTRIES.register("cinnabar_brick_slab", class_2482::new, SharedBlockProperties.CINNABAR);
    public static final Supplier<class_2248> CINNABAR_BRICK_STAIRS = REGISTRIES.register("cinnabar_brick_stairs", () -> new class_2510(CINNABAR_BRICKS.get().method_9564(), SharedBlockProperties.CINNABAR));
    public static final Supplier<class_2248> CINNABAR_BRICK_WALL = REGISTRIES.register("cinnabar_brick_wall", class_2544::new, SharedBlockProperties.CINNABAR);
    public static final Supplier<class_2248> CHISELED_CINNABAR = REGISTRIES.register("chiseled_cinnabar", SharedBlockProperties.CINNABAR);

    public static final Supplier<class_2248> SULFUR = REGISTRIES.register("sulfur", SharedBlockProperties.SULFUR);
    public static final Supplier<class_2248> SULFUR_SLAB = REGISTRIES.register("sulfur_slab", class_2482::new, SharedBlockProperties.SULFUR);
    public static final Supplier<class_2248> SULFUR_STAIRS = REGISTRIES.register("sulfur_stairs", () -> new class_2510(SULFUR.get().method_9564(), SharedBlockProperties.SULFUR));
    public static final Supplier<class_2248> SULFUR_WALL = REGISTRIES.register("sulfur_wall", class_2544::new, SharedBlockProperties.SULFUR);
    public static final Supplier<class_2248> POLISHED_SULFUR = REGISTRIES.register("polished_sulfur", SharedBlockProperties.SULFUR);
    public static final Supplier<class_2248> POLISHED_SULFUR_SLAB = REGISTRIES.register("polished_sulfur_slab", class_2482::new, SharedBlockProperties.SULFUR);
    public static final Supplier<class_2248> POLISHED_SULFUR_STAIRS = REGISTRIES.register("polished_sulfur_stairs", () -> new class_2510(POLISHED_SULFUR.get().method_9564(), SharedBlockProperties.SULFUR));
    public static final Supplier<class_2248> POLISHED_SULFUR_WALL = REGISTRIES.register("polished_sulfur_wall", class_2544::new, SharedBlockProperties.SULFUR);
    public static final Supplier<class_2248> SULFUR_BRICKS = REGISTRIES.register("sulfur_bricks", SharedBlockProperties.SULFUR);
    public static final Supplier<class_2248> SULFUR_BRICK_SLAB = REGISTRIES.register("sulfur_brick_slab", class_2482::new, SharedBlockProperties.SULFUR);
    public static final Supplier<class_2248> SULFUR_BRICK_STAIRS = REGISTRIES.register("sulfur_brick_stairs", () -> new class_2510(SULFUR_BRICKS.get().method_9564(), SharedBlockProperties.SULFUR));
    public static final Supplier<class_2248> SULFUR_BRICK_WALL = REGISTRIES.register("sulfur_brick_wall", class_2544::new, SharedBlockProperties.SULFUR);
    public static final Supplier<class_2248> CHISELED_SULFUR = REGISTRIES.register("chiseled_sulfur", SharedBlockProperties.SULFUR);

    public static final Supplier<class_2248> POTENT_SULFUR = REGISTRIES.register("potent_sulfur", PotentSulfurBlock::new, SharedBlockProperties.SULFUR.method_9626(ModSoundTypes.POTENT_SULFUR));
    public static final Supplier<class_2248> SULFUR_SPIKE = REGISTRIES.register("sulfur_spike",
        () -> new SpeleothemBlock(
            SULFUR.get().method_9564(),
            class_2251.method_9637()
                .method_31710(class_3620.field_16010)
                .method_51369()
                .method_51368(class_2766.field_12653)
                .method_22488()
                .method_9626(class_2498.field_28061)
                .method_9640()
                .method_9629(1.5F, 3.0F)
                .method_9624()
                .method_49229(class_4970.class_2250.field_10657)
                .method_50012(class_3619.field_15971)
                .method_26236(REGISTRIES::never)
                .method_22488()));
    
    // Wilderness Bound
    
    public static final Supplier<class_2248> POPLAR_LOG = REGISTRIES.register("poplar_log",
        class_2465::new,
        SharedBlockProperties.logProperties(class_3620.field_15993, class_3620.field_16017, class_2498.field_11547));
    public static final Supplier<class_2248> STRIPPED_POPLAR_LOG = REGISTRIES.register("stripped_poplar_log",
        class_2465::new,
        SharedBlockProperties.logProperties(class_3620.field_15993, class_3620.field_15993, class_2498.field_11547));
    public static final Supplier<class_2248> POPLAR_WOOD = REGISTRIES.register("poplar_wood",
        class_2465::new,
        class_2251.method_9637()
            .method_31710(class_3620.field_16017)
            .method_51368(class_2766.field_12651)
            .method_9632(2.0F)
            .method_9626(class_2498.field_11547)
            .method_50013());
    public static final Supplier<class_2248> STRIPPED_POPLAR_WOOD = REGISTRIES.register("stripped_poplar_wood",
        class_2465::new,
        class_2251.method_9637()
            .method_31710(class_3620.field_15993)
            .method_51368(class_2766.field_12651)
            .method_9632(2.0F)
            .method_9626(class_2498.field_11547)
            .method_50013());
    
    public static final Supplier<class_2248> POPLAR_PLANKS = REGISTRIES.register("poplar_planks", SharedBlockProperties.POPLAR);
    public static final Supplier<class_2248> POPLAR_SLAB = REGISTRIES.register("poplar_slab", class_2482::new, SharedBlockProperties.POPLAR);
    public static final Supplier<class_2248> POPLAR_STAIRS = REGISTRIES.register("poplar_stairs", () -> new class_2510(POPLAR_PLANKS.get().method_9564(), SharedBlockProperties.POPLAR));
    
    public static final Pair<Supplier<class_2248>, Supplier<class_2248>> POPLAR_SIGN = sign("poplar",
        ModWoodTypes.POPLAR,
        class_3620.field_15993);
    public static final Pair<Supplier<class_2248>, Supplier<class_2248>> POPLAR_HANGING_SIGN = hangingSign("poplar",
        ModWoodTypes.POPLAR,
        class_3620.field_15993);
    public static final Supplier<class_2248> POPLAR_BUTTON = REGISTRIES.register("poplar_button",
        properties -> new class_2269(ModBlockSetTypes.POPLAR, 30, properties),
        SharedBlockProperties.buttonProperties());
    public static final Supplier<class_2248> POPLAR_PRESSURE_PLATE = REGISTRIES.register("poplar_pressure_plate",
        properties -> new class_2440(ModBlockSetTypes.POPLAR, properties),
        class_2251.method_9637()
            .method_31710(class_3620.field_15993)
            .method_51369()
            .method_51368(class_2766.field_12651)
            .method_9634()
            .method_9632(0.5F)
            .method_50013()
            .method_50012(class_3619.field_15971));
    public static final Supplier<class_2248> POPLAR_DOOR = REGISTRIES.register("poplar_door",
        properties -> new class_2323(ModBlockSetTypes.POPLAR, properties),
        class_2251.method_9637()
            .method_31710(class_3620.field_15993)
            .method_51368(class_2766.field_12651)
            .method_9632(3.0F)
            .method_22488()
            .method_50013()
            .method_50012(class_3619.field_15971));
    public static final Supplier<class_2248> POPLAR_FENCE = REGISTRIES.register("poplar_fence",
        class_2354::new,
        class_2251.method_9637()
            .method_31710(class_3620.field_15993)
            .method_51368(class_2766.field_12651)
            .method_9629(2.0F, 3.0F)
            .method_9626(class_2498.field_11547)
            .method_50013());
    public static final Supplier<class_2248> POPLAR_FENCE_GATE = REGISTRIES.register("poplar_fence_gate",
        properties -> new class_2349(ModWoodTypes.POPLAR, properties),
        class_2251.method_9637()
            .method_31710(class_3620.field_15993)
            .method_51369()
            .method_51368(class_2766.field_12651)
            .method_9629(2.0F, 3.0F)
            .method_50013());
    public static final Supplier<class_2248> POPLAR_TRAPDOOR = REGISTRIES.register("poplar_trapdoor",
        properties -> new class_2533(ModBlockSetTypes.POPLAR, properties),
        class_2251.method_9637()
            .method_31710(class_3620.field_15993)
            .method_51368(class_2766.field_12651)
            .method_9632(3.0F)
            .method_22488()
            .method_26235(REGISTRIES::never)
            .method_50013());
    
    public static final Supplier<class_2248> POPLAR_SHELF = REGISTRIES.register("poplar_shelf",
        ShelfBlock::new,
        SharedBlockProperties.SHELF.method_31710(class_3620.field_15993));
    
    public static final Supplier<class_2248> RED_POPLAR_LEAVES = REGISTRIES.register("red_poplar_leaves",
        properties -> new AtmosphericLeavesBlock(0.01F, ModParticles.RED_POPLAR_LEAVES, properties, AmbientLeavesBlockSoundPlayer.of(ModSoundEvents.POPLAR_LEAVES_AMBIENT, ModBlockTags.REQUIRED_FOR_POPLAR_LEAF_AMBIENCE)),
        SharedBlockProperties.leavesProperties(ModSoundTypes.POPLAR_LEAVES).method_31710(class_3620.field_16020));
    public static final Supplier<class_2248> ORANGE_POPLAR_LEAVES = REGISTRIES.register("orange_poplar_leaves",
        properties -> new AtmosphericLeavesBlock(0.01F, ModParticles.ORANGE_POPLAR_LEAVES, properties, AmbientLeavesBlockSoundPlayer.of(ModSoundEvents.POPLAR_LEAVES_AMBIENT, ModBlockTags.REQUIRED_FOR_POPLAR_LEAF_AMBIENCE)),
        SharedBlockProperties.leavesProperties(ModSoundTypes.POPLAR_LEAVES).method_31710(class_3620.field_15987));
    public static final Supplier<class_2248> YELLOW_POPLAR_LEAVES = REGISTRIES.register("yellow_poplar_leaves",
        properties -> new AtmosphericLeavesBlock(0.01F, ModParticles.YELLOW_POPLAR_LEAVES, properties, AmbientLeavesBlockSoundPlayer.of(ModSoundEvents.POPLAR_LEAVES_AMBIENT, ModBlockTags.REQUIRED_FOR_POPLAR_LEAF_AMBIENCE)),
        SharedBlockProperties.leavesProperties(ModSoundTypes.POPLAR_LEAVES).method_31710(class_3620.field_16010));
    
    public static final Supplier<class_2248> POPLAR_SAPLING = REGISTRIES.register("poplar_sapling",
        properties -> new class_2473(ModTreeGrowers.POPLAR.get(), properties),
        class_2251.method_9637()
            .method_31710(class_3620.field_16005)
            .method_9634()
            .method_9640()
            .method_9618()
            .method_9626(class_2498.field_11535)
            .method_50012(class_3619.field_15971));
    public static final Supplier<class_2248> POTTED_POPLAR_SAPLING = REGISTRIES.registerNoItem("potted_poplar_sapling",
        properties -> new class_2362(POPLAR_SAPLING.get(), properties),
        SharedBlockProperties.flowerPotProperties());
    
    public static final Supplier<class_2248> RED_SHRUB = REGISTRIES.register("red_shrub",
        ActualBushBlock::new,
        class_2251.method_9637()
            .method_31710(class_3620.field_25702)
            .method_51371()
            .method_9634()
            .method_9618()
            .method_9626(ModSoundTypes.RED_SHRUB)
            .method_50013()
            .method_50012(class_3619.field_15971));
    public static final Supplier<class_2248> SHELF_MUSHROOM = REGISTRIES.register("shelf_mushroom",
        ShelfMushroomBlock::new,
        class_2251.method_9637()
            .method_31710(class_3620.field_16013)
            .method_9626(ModSoundTypes.SHELF_MUSHROOM)
            .method_22488()
            .method_50012(class_3619.field_15971));
    
    public static final Supplier<class_2248> STRAW_BED = REGISTRIES.register("straw_bed",
        StrawBedBlock::new,
        class_2251.method_9637()
            .method_31710(class_3620.field_16010)
            .method_9626(ModSoundTypes.STRAW_BED)
            .method_9632(0.2F)
            .method_22488()
            .method_50013()
            .method_50012(class_3619.field_15971),
        class_1747::new,
        new class_1792.class_1793().method_7889(16)
    );
    
    public static final Supplier<class_2248> WHITE_WOOL_STAIRS = REGISTRIES.register("white_wool_stairs",
        properties -> new class_2510(class_2246.field_10446.method_9564(), properties),
        class_2251.method_9630(class_2246.field_10446));
    public static final Supplier<class_2248> ORANGE_WOOL_STAIRS = REGISTRIES.register("orange_wool_stairs",
        properties -> new class_2510(class_2246.field_10095.method_9564(), properties),
        class_2251.method_9630(class_2246.field_10095));
    public static final Supplier<class_2248> MAGENTA_WOOL_STAIRS = REGISTRIES.register("magenta_wool_stairs",
        properties -> new class_2510(class_2246.field_10215.method_9564(), properties),
        class_2251.method_9630(class_2246.field_10215));
    public static final Supplier<class_2248> LIGHT_BLUE_WOOL_STAIRS = REGISTRIES.register("light_blue_wool_stairs",
        properties -> new class_2510(class_2246.field_10294.method_9564(), properties),
        class_2251.method_9630(class_2246.field_10294));
    public static final Supplier<class_2248> YELLOW_WOOL_STAIRS = REGISTRIES.register("yellow_wool_stairs",
        properties -> new class_2510(class_2246.field_10490.method_9564(), properties),
        class_2251.method_9630(class_2246.field_10490));
    public static final Supplier<class_2248> LIME_WOOL_STAIRS = REGISTRIES.register("lime_wool_stairs",
        properties -> new class_2510(class_2246.field_10028.method_9564(), properties),
        class_2251.method_9630(class_2246.field_10028));
    public static final Supplier<class_2248> PINK_WOOL_STAIRS = REGISTRIES.register("pink_wool_stairs",
        properties -> new class_2510(class_2246.field_10459.method_9564(), properties),
        class_2251.method_9630(class_2246.field_10459));
    public static final Supplier<class_2248> GRAY_WOOL_STAIRS = REGISTRIES.register("gray_wool_stairs",
        properties -> new class_2510(class_2246.field_10423.method_9564(), properties),
        class_2251.method_9630(class_2246.field_10423));
    public static final Supplier<class_2248> LIGHT_GRAY_WOOL_STAIRS = REGISTRIES.register("light_gray_wool_stairs",
        properties -> new class_2510(class_2246.field_10222.method_9564(), properties),
        class_2251.method_9630(class_2246.field_10222));
    public static final Supplier<class_2248> CYAN_WOOL_STAIRS = REGISTRIES.register("cyan_wool_stairs",
        properties -> new class_2510(class_2246.field_10619.method_9564(), properties),
        class_2251.method_9630(class_2246.field_10619));
    public static final Supplier<class_2248> PURPLE_WOOL_STAIRS = REGISTRIES.register("purple_wool_stairs",
        properties -> new class_2510(class_2246.field_10259.method_9564(), properties),
        class_2251.method_9630(class_2246.field_10259));
    public static final Supplier<class_2248> BLUE_WOOL_STAIRS = REGISTRIES.register("blue_wool_stairs",
        properties -> new class_2510(class_2246.field_10514.method_9564(), properties),
        class_2251.method_9630(class_2246.field_10514));
    public static final Supplier<class_2248> BROWN_WOOL_STAIRS = REGISTRIES.register("brown_wool_stairs",
        properties -> new class_2510(class_2246.field_10113.method_9564(), properties),
        class_2251.method_9630(class_2246.field_10113));
    public static final Supplier<class_2248> GREEN_WOOL_STAIRS = REGISTRIES.register("green_wool_stairs",
        properties -> new class_2510(class_2246.field_10170.method_9564(), properties),
        class_2251.method_9630(class_2246.field_10170));
    public static final Supplier<class_2248> RED_WOOL_STAIRS = REGISTRIES.register("red_wool_stairs",
        properties -> new class_2510(class_2246.field_10314.method_9564(), properties),
        class_2251.method_9630(class_2246.field_10314));
    public static final Supplier<class_2248> BLACK_WOOL_STAIRS = REGISTRIES.register("black_wool_stairs",
        properties -> new class_2510(class_2246.field_10146.method_9564(), properties),
        class_2251.method_9630(class_2246.field_10146));
    
    public static final Supplier<class_2248> WHITE_WOOL_SLAB = REGISTRIES.register("white_wool_slab",
        class_2482::new, class_2251.method_9630(class_2246.field_10446));
    public static final Supplier<class_2248> ORANGE_WOOL_SLAB = REGISTRIES.register("orange_wool_slab",
        class_2482::new, class_2251.method_9630(class_2246.field_10095));
    public static final Supplier<class_2248> MAGENTA_WOOL_SLAB = REGISTRIES.register("magenta_wool_slab",
        class_2482::new, class_2251.method_9630(class_2246.field_10215));
    public static final Supplier<class_2248> LIGHT_BLUE_WOOL_SLAB = REGISTRIES.register("light_blue_wool_slab",
        class_2482::new, class_2251.method_9630(class_2246.field_10294));
    public static final Supplier<class_2248> YELLOW_WOOL_SLAB = REGISTRIES.register("yellow_wool_slab",
        class_2482::new, class_2251.method_9630(class_2246.field_10490));
    public static final Supplier<class_2248> LIME_WOOL_SLAB = REGISTRIES.register("lime_wool_slab",
        class_2482::new, class_2251.method_9630(class_2246.field_10028));
    public static final Supplier<class_2248> PINK_WOOL_SLAB = REGISTRIES.register("pink_wool_slab",
        class_2482::new, class_2251.method_9630(class_2246.field_10459));
    public static final Supplier<class_2248> GRAY_WOOL_SLAB = REGISTRIES.register("gray_wool_slab",
        class_2482::new, class_2251.method_9630(class_2246.field_10423));
    public static final Supplier<class_2248> LIGHT_GRAY_WOOL_SLAB = REGISTRIES.register("light_gray_wool_slab",
        class_2482::new, class_2251.method_9630(class_2246.field_10222));
    public static final Supplier<class_2248> CYAN_WOOL_SLAB = REGISTRIES.register("cyan_wool_slab",
        class_2482::new, class_2251.method_9630(class_2246.field_10619));
    public static final Supplier<class_2248> PURPLE_WOOL_SLAB = REGISTRIES.register("purple_wool_slab",
        class_2482::new, class_2251.method_9630(class_2246.field_10259));
    public static final Supplier<class_2248> BLUE_WOOL_SLAB = REGISTRIES.register("blue_wool_slab",
        class_2482::new, class_2251.method_9630(class_2246.field_10514));
    public static final Supplier<class_2248> BROWN_WOOL_SLAB = REGISTRIES.register("brown_wool_slab",
        class_2482::new, class_2251.method_9630(class_2246.field_10113));
    public static final Supplier<class_2248> GREEN_WOOL_SLAB = REGISTRIES.register("green_wool_slab",
        class_2482::new, class_2251.method_9630(class_2246.field_10170));
    public static final Supplier<class_2248> RED_WOOL_SLAB = REGISTRIES.register("red_wool_slab",
        class_2482::new, class_2251.method_9630(class_2246.field_10314));
    public static final Supplier<class_2248> BLACK_WOOL_SLAB = REGISTRIES.register("black_wool_slab",
        class_2482::new, class_2251.method_9630(class_2246.field_10146));

    public static final Supplier<class_2248> BLACK_CONCRETE_STAIRS = REGISTRIES.register("black_concrete_stairs",
        properties -> new class_2510(class_2246.field_10458.method_9564(), properties),
        class_2251.method_9630(class_2246.field_10458));
    public static final Supplier<class_2248> BLUE_CONCRETE_STAIRS = REGISTRIES.register("blue_concrete_stairs",
        properties -> new class_2510(class_2246.field_10011.method_9564(), properties),
        class_2251.method_9630(class_2246.field_10011));
    public static final Supplier<class_2248> BROWN_CONCRETE_STAIRS = REGISTRIES.register("brown_concrete_stairs",
        properties -> new class_2510(class_2246.field_10439.method_9564(), properties),
        class_2251.method_9630(class_2246.field_10439));
    public static final Supplier<class_2248> CYAN_CONCRETE_STAIRS = REGISTRIES.register("cyan_concrete_stairs",
        properties -> new class_2510(class_2246.field_10308.method_9564(), properties),
        class_2251.method_9630(class_2246.field_10308));
    public static final Supplier<class_2248> GRAY_CONCRETE_STAIRS = REGISTRIES.register("gray_concrete_stairs",
        properties -> new class_2510(class_2246.field_10038.method_9564(), properties),
        class_2251.method_9630(class_2246.field_10038));
    public static final Supplier<class_2248> GREEN_CONCRETE_STAIRS = REGISTRIES.register("green_concrete_stairs",
        properties -> new class_2510(class_2246.field_10367.method_9564(), properties),
        class_2251.method_9630(class_2246.field_10367));
    public static final Supplier<class_2248> LIGHT_BLUE_CONCRETE_STAIRS = REGISTRIES.register("light_blue_concrete_stairs",
        properties -> new class_2510(class_2246.field_10242.method_9564(), properties),
        class_2251.method_9630(class_2246.field_10242));
    public static final Supplier<class_2248> LIGHT_GRAY_CONCRETE_STAIRS = REGISTRIES.register("light_gray_concrete_stairs",
        properties -> new class_2510(class_2246.field_10172.method_9564(), properties),
        class_2251.method_9630(class_2246.field_10172));
    public static final Supplier<class_2248> LIME_CONCRETE_STAIRS = REGISTRIES.register("lime_concrete_stairs",
        properties -> new class_2510(class_2246.field_10421.method_9564(), properties),
        class_2251.method_9630(class_2246.field_10421));
    public static final Supplier<class_2248> MAGENTA_CONCRETE_STAIRS = REGISTRIES.register("magenta_concrete_stairs",
        properties -> new class_2510(class_2246.field_10585.method_9564(), properties),
        class_2251.method_9630(class_2246.field_10585));
    public static final Supplier<class_2248> ORANGE_CONCRETE_STAIRS = REGISTRIES.register("orange_concrete_stairs",
        properties -> new class_2510(class_2246.field_10210.method_9564(), properties),
        class_2251.method_9630(class_2246.field_10210));
    public static final Supplier<class_2248> PINK_CONCRETE_STAIRS = REGISTRIES.register("pink_concrete_stairs",
        properties -> new class_2510(class_2246.field_10434.method_9564(), properties),
        class_2251.method_9630(class_2246.field_10434));
    public static final Supplier<class_2248> PURPLE_CONCRETE_STAIRS = REGISTRIES.register("purple_concrete_stairs",
        properties -> new class_2510(class_2246.field_10206.method_9564(), properties),
        class_2251.method_9630(class_2246.field_10206));
    public static final Supplier<class_2248> RED_CONCRETE_STAIRS = REGISTRIES.register("red_concrete_stairs",
        properties -> new class_2510(class_2246.field_10058.method_9564(), properties),
        class_2251.method_9630(class_2246.field_10058));
    public static final Supplier<class_2248> YELLOW_CONCRETE_STAIRS = REGISTRIES.register("yellow_concrete_stairs",
        properties -> new class_2510(class_2246.field_10542.method_9564(), properties),
        class_2251.method_9630(class_2246.field_10542));
    public static final Supplier<class_2248> WHITE_CONCRETE_STAIRS = REGISTRIES.register("white_concrete_stairs",
        properties -> new class_2510(class_2246.field_10107.method_9564(), properties),
        class_2251.method_9630(class_2246.field_10107));

    public static final Supplier<class_2248> BLACK_CONCRETE_SLAB = REGISTRIES.register("black_concrete_slab",
        class_2482::new, class_2251.method_9630(class_2246.field_10458));
    public static final Supplier<class_2248> BLUE_CONCRETE_SLAB = REGISTRIES.register("blue_concrete_slab",
        class_2482::new, class_2251.method_9630(class_2246.field_10011));
    public static final Supplier<class_2248> BROWN_CONCRETE_SLAB = REGISTRIES.register("brown_concrete_slab",
        class_2482::new, class_2251.method_9630(class_2246.field_10439));
    public static final Supplier<class_2248> CYAN_CONCRETE_SLAB = REGISTRIES.register("cyan_concrete_slab",
        class_2482::new, class_2251.method_9630(class_2246.field_10308));
    public static final Supplier<class_2248> GRAY_CONCRETE_SLAB = REGISTRIES.register("gray_concrete_slab",
        class_2482::new, class_2251.method_9630(class_2246.field_10038));
    public static final Supplier<class_2248> GREEN_CONCRETE_SLAB = REGISTRIES.register("green_concrete_slab",
        class_2482::new, class_2251.method_9630(class_2246.field_10367));
    public static final Supplier<class_2248> LIGHT_BLUE_CONCRETE_SLAB = REGISTRIES.register("light_blue_concrete_slab",
        class_2482::new, class_2251.method_9630(class_2246.field_10242));
    public static final Supplier<class_2248> LIGHT_GRAY_CONCRETE_SLAB = REGISTRIES.register("light_gray_concrete_slab",
        class_2482::new, class_2251.method_9630(class_2246.field_10172));
    public static final Supplier<class_2248> LIME_CONCRETE_SLAB = REGISTRIES.register("lime_concrete_slab",
        class_2482::new, class_2251.method_9630(class_2246.field_10421));
    public static final Supplier<class_2248> MAGENTA_CONCRETE_SLAB = REGISTRIES.register("magenta_concrete_slab",
        class_2482::new, class_2251.method_9630(class_2246.field_10585));
    public static final Supplier<class_2248> ORANGE_CONCRETE_SLAB = REGISTRIES.register("orange_concrete_slab",
        class_2482::new, class_2251.method_9630(class_2246.field_10210));
    public static final Supplier<class_2248> PINK_CONCRETE_SLAB = REGISTRIES.register("pink_concrete_slab",
        class_2482::new, class_2251.method_9630(class_2246.field_10434));
    public static final Supplier<class_2248> PURPLE_CONCRETE_SLAB = REGISTRIES.register("purple_concrete_slab",
        class_2482::new, class_2251.method_9630(class_2246.field_10206));
    public static final Supplier<class_2248> RED_CONCRETE_SLAB = REGISTRIES.register("red_concrete_slab",
        class_2482::new, class_2251.method_9630(class_2246.field_10058));
    public static final Supplier<class_2248> YELLOW_CONCRETE_SLAB = REGISTRIES.register("yellow_concrete_slab",
        class_2482::new, class_2251.method_9630(class_2246.field_10542));
    public static final Supplier<class_2248> WHITE_CONCRETE_SLAB = REGISTRIES.register("white_concrete_slab",
        class_2482::new, class_2251.method_9630(class_2246.field_10107));
    
    // Helper
    
    public static Pair<Supplier<class_2248>, Supplier<class_2248>> sign(String name, class_4719 woodType, class_3620 color) {
        class_2251 properties = class_2251.method_9637()
            .method_31710(color)
            .method_51369()
            .method_51368(class_2766.field_12651)
            .method_9634()
            .method_9632(1.0F)
            .method_50013();
        Supplier<class_2248> standing = REGISTRIES.registerNoItem(name + "_sign", () -> new class_2508(woodType, properties));
        Supplier<class_2248> wall = REGISTRIES.registerNoItem(name + "_wall_sign", () -> new class_2551(woodType, properties.method_16228(standing.get())));
        REGISTRIES.registerItem(name + "_sign", () -> new class_1822(new class_1792.class_1793().method_7889(16), standing.get(), wall.get()));
        return new Pair<>(standing, wall);
    }
    
    public static Pair<Supplier<class_2248>, Supplier<class_2248>> hangingSign(String name, class_4719 woodType, class_3620 color) {
        class_2251 properties = class_2251.method_9637()
            .method_31710(color)
            .method_51369()
            .method_51368(class_2766.field_12651)
            .method_9634()
            .method_9632(1.0F)
            .method_50013();

        Supplier<class_2248> ceiling = REGISTRIES.registerNoItem(name + "_hanging_sign", () -> new class_7713(woodType, properties));
        Supplier<class_2248> wall = REGISTRIES.registerNoItem(name + "_wall_hanging_sign", () -> new class_7715(woodType, properties.method_16228(ceiling.get())));
        REGISTRIES.registerItem(name + "_hanging_sign", () -> new class_7707(ceiling.get(), wall.get(), new class_1792.class_1793().method_7889(16)));
        return new Pair<>(ceiling, wall);
    }
    
    public static Pair<Supplier<class_2248>, Supplier<class_2248>> torch(String name, Supplier<class_2400> particle) {
        class_2251 properties = class_2251.method_9637()
            .method_9634()
            .method_9618()
            .method_9631(state -> 14)
            .method_9626(class_2498.field_11547).method_50012(class_3619.field_15971);
        
        Supplier<class_2248> torch = REGISTRIES.registerNoItem(name + "_torch", () -> new LazyTorchBlock(particle, properties));
        Supplier<class_2248> wall_torch = REGISTRIES.registerNoItem(name + "_wall_torch", () -> new LazyWallTorchBlock(particle, properties.method_16228(torch.get())));
        REGISTRIES.registerItem(name + "_torch", () -> new class_1827(torch.get(), wall_torch.get(), new class_1792.class_1793(), class_2350.field_11033));
        return new Pair<>(torch, wall_torch);
    }
}