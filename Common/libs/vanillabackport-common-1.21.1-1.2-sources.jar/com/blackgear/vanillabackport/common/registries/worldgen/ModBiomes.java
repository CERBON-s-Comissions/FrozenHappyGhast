package com.blackgear.vanillabackport.common.registries.worldgen;

import com.blackgear.platform.core.api.registrar.bootstrap.BootstrapRegistrar;
import com.blackgear.vanillabackport.common.worldgen.biomes.ChaosCubedBiomes;
import com.blackgear.vanillabackport.common.worldgen.biomes.TheGardenAwakensBiomes;
import com.blackgear.vanillabackport.common.worldgen.biomes.WildernessBoundBiomes;
import com.blackgear.vanillabackport.core.VanillaBackport;
import java.util.function.BiFunction;
import net.minecraft.class_1959;
import net.minecraft.class_2922;
import net.minecraft.class_5321;
import net.minecraft.class_6796;
import net.minecraft.class_7871;
import net.minecraft.class_7924;

public class ModBiomes {
    public static final BootstrapRegistrar<class_1959> REGISTRIES = BootstrapRegistrar.create(class_7924.field_41236, VanillaBackport.NAMESPACE);

    public static final class_5321<class_1959> PALE_GARDEN = register("pale_garden", TheGardenAwakensBiomes::paleGarden);
    public static final class_5321<class_1959> SULFUR_CAVES = register("sulfur_caves", ChaosCubedBiomes::sulfurCaves);
    public static final class_5321<class_1959> DAPPLED_FOREST = register("dappled_forest", WildernessBoundBiomes::dappledForest);
    
    private static class_5321<class_1959> register(String key, BiFunction<class_7871<class_6796>, class_7871<class_2922<?>>, class_1959> factory) {
        return REGISTRIES.register(key, context -> factory.apply(context.method_46799(class_7924.field_41245), context.method_46799(class_7924.field_41238)));
    }
}