package com.blackgear.vanillabackport.common.registries.enchantment;

import com.blackgear.vanillabackport.core.mixin.common.access.EnchantmentAccessor;
import com.blackgear.vanillabackport.core.mixin.common.access.EnchantmentHelperAccessor;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1887;
import net.minecraft.class_3218;
import net.minecraft.class_9699;

public class EnchantmentUtils {
    public static void doPostPiercingAttackEffects(class_3218 server, class_1309 user) {
        EnchantmentHelperAccessor.callRunIterationOnItem(user.method_59958(), class_1304.field_6173, user,
            (enchantment, level, item) -> {
                if (!user.method_5799()) {
                    doPostPiercingAttack(enchantment.comp_349(), server, level, item, user);
                }
            });
    }
    
    private static void doPostPiercingAttack(class_1887 enchantment, class_3218 server, int level, class_9699 item, class_1297 user) {
        EnchantmentAccessor.callApplyEffects(
            enchantment.method_60034(ModEnchantmentEffectComponents.POST_PIERCING_ATTACK.get()),
            EnchantmentAccessor.callEntityContext(server, level, user, user.method_19538()),
            e -> e.method_60220(server, level, item, user, user.method_19538())
        );
    }
}