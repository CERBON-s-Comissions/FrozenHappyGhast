package com.blackgear.vanillabackport.common.registries.worldgen;

import com.blackgear.platform.core.CoreRegistry;
import com.blackgear.vanillabackport.common.level.worldgen.tree.foliage.PoplarFoliagePlacer;
import com.blackgear.vanillabackport.common.level.worldgen.tree.trunk.PoplarTrunkPlacer;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.blackgear.vanillabackport.core.mixin.common.access.FoliagePlacerTypeAccessor;
import com.mojang.serialization.MapCodec;
import java.util.function.Supplier;
import net.minecraft.class_4647;
import net.minecraft.class_4648;
import net.minecraft.class_7924;

public class ModFoliagePlacers {
    public static final CoreRegistry<class_4648<?>> REGISTRIES = CoreRegistry.create(class_7924.field_41271, VanillaBackport.NAMESPACE);
    
    public static final Supplier<class_4648<PoplarFoliagePlacer>> POPLAR_FOLIAGE_PLACER = register("poplar_foliage_placer", PoplarFoliagePlacer.CODEC);
    
    private static <P extends class_4647> Supplier<class_4648<P>> register(String name, MapCodec<P> codec) {
        return REGISTRIES.register(name, () -> FoliagePlacerTypeAccessor.createFoliagePlacerType(codec));
    }
}