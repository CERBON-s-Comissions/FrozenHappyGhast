package com.blackgear.vanillabackport.common;

import com.blackgear.platform.common.data.LootModifier;
import com.blackgear.platform.common.events.CommandRegistrar;
import com.blackgear.platform.common.integration.BlockIntegration;
import com.blackgear.platform.common.integration.MobIntegration;
import com.blackgear.platform.common.integration.TradeIntegration;
import com.blackgear.platform.common.v2.recipe.DynamicRecipeManager;
import com.blackgear.platform.common.worldgen.modifier.BiomeManager;
import com.blackgear.platform.common.worldgen.placement.BiomePlacement;
import com.blackgear.platform.core.ParallelDispatch;
import com.blackgear.platform.core.events.ResourceReloadManager;
import com.blackgear.vanillabackport.client.registries.ModSoundEvents;
import com.blackgear.vanillabackport.common.api.SpawnEquipmentRegistry;
import com.blackgear.vanillabackport.common.commands.WaypointCommand;
import com.blackgear.vanillabackport.common.integrations.BlockIntegrations;
import com.blackgear.vanillabackport.common.integrations.LootIntegrations;
import com.blackgear.vanillabackport.common.integrations.MobIntegrations;
import com.blackgear.vanillabackport.common.integrations.TradeIntegrations;
import com.blackgear.vanillabackport.common.integrations.worldgen.BiomeGeneration;
import com.blackgear.vanillabackport.common.api.modules.sound_variant.WolfSoundVariant;
import com.blackgear.vanillabackport.common.api.modules.sound_variant.WolfSoundVariants;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.cat.CatDataVariant;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.cat.CatDataVariants;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.chicken.ChickenVariant;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.chicken.ChickenVariants;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.cow.CowVariant;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.cow.CowVariants;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.frog.FrogDataVariant;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.frog.FrogDataVariants;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.nautilus.ZombieNautilusVariant;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.nautilus.ZombieNautilusVariants;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.pig.PigVariant;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.pig.PigVariants;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.wolf.WolfDataVariant;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.wolf.WolfDataVariants;
import com.blackgear.vanillabackport.common.level.entities.mob.monster.sulfur_cube.SulfurCubeArchetype;
import com.blackgear.vanillabackport.common.level.entities.mob.monster.sulfur_cube.SulfurCubeArchetypes;
import com.blackgear.vanillabackport.common.level.recipes.VanillaDynamicRecipes;
import com.blackgear.vanillabackport.common.registries.entities.ModEntityTypes;
import com.blackgear.vanillabackport.common.integrations.worldgen.WorldGeneration;
import com.blackgear.vanillabackport.common.registries.items.ModItems;
import com.blackgear.vanillabackport.core.VanillaBackport;
import net.minecraft.class_1304;
import net.minecraft.class_1453;

public class CommonSetup {
    public static void setup() {
        ResourceReloadManager.registerServer(event -> {
            event.register(VanillaBackport.resource("wolf_sound_variant"), WolfSoundVariants.REGISTRIES, WolfSoundVariant.CODEC);
            event.register(VanillaBackport.resource("cow_variant"), CowVariants.REGISTRIES, CowVariant.CODEC);
            event.register(VanillaBackport.resource("chicken_variant"), ChickenVariants.REGISTRIES, ChickenVariant.CODEC);
            event.register(VanillaBackport.resource("pig_variant"), PigVariants.REGISTRIES, PigVariant.CODEC);
            event.register(VanillaBackport.resource("wolf_variants"), WolfDataVariants.REGISTRIES, WolfDataVariant.CODEC);
            event.register(VanillaBackport.resource("frog_variants"), FrogDataVariants.REGISTRIES, FrogDataVariant.CODEC);
            event.register(VanillaBackport.resource("cat_variants"), CatDataVariants.REGISTRIES, CatDataVariant.CODEC);
            event.register(VanillaBackport.resource("zombie_nautilus_variant"), ZombieNautilusVariants.REGISTRIES, ZombieNautilusVariant.CODEC);
            event.register(VanillaBackport.resource("sulfur_cube_archetype"), SulfurCubeArchetypes.REGISTRIES, SulfurCubeArchetype.CODEC);
        });
        
        DynamicRecipeManager.register(new VanillaDynamicRecipes(), VanillaBackport.MOD_ID);
        MobIntegration.registerIntegrations(MobIntegrations::bootstrap);
        CommandRegistrar.EVENT.register((dispatcher, context, selection) -> WaypointCommand.register(dispatcher, context));
    }

    public static void asyncSetup(ParallelDispatch dispatch) {
        dispatch.enqueueWork(() -> {
            BiomeManager.add(WorldGeneration::bootstrap);
            BiomePlacement.registerBiomePlacements(BiomeGeneration::bootstrap);
            BlockIntegration.registerIntegrations(BlockIntegrations::bootstrap);
            TradeIntegration.registerVillagerTrades(TradeIntegrations::bootstrap);
            class_1453.field_6822.put(ModEntityTypes.CREAKING.get(), ModSoundEvents.PARROT_IMITATE_CREAKING.get());
            class_1453.field_6822.put(ModEntityTypes.PARCHED.get(), ModSoundEvents.PARROT_IMITATE_PARCHED.get());
            class_1453.field_6822.put(ModEntityTypes.CAMEL_HUSK.get(), ModSoundEvents.PARROT_IMITATE_CAMEL_HUSK.get());
            class_1453.field_6822.put(ModEntityTypes.ZOMBIE_NAUTILUS.get(), ModSoundEvents.PARROT_IMITATE_ZOMBIE_NAUTILUS.get());
            
            if (VanillaBackport.COMMON_CONFIG.hasCopperToolSet.get()) {
                SpawnEquipmentRegistry.register(class_1304.field_6169, 1, 0.4F, ModItems.COPPER_HELMET);
                SpawnEquipmentRegistry.register(class_1304.field_6174, 1, 0.4F, ModItems.COPPER_CHESTPLATE);
                SpawnEquipmentRegistry.register(class_1304.field_6172, 1, 0.4F, ModItems.COPPER_LEGGINGS);
                SpawnEquipmentRegistry.register(class_1304.field_6166, 1, 0.4F, ModItems.COPPER_BOOTS);
            }
        });
        
        LootModifier.modify(LootIntegrations.INSTANCE);
    }
}