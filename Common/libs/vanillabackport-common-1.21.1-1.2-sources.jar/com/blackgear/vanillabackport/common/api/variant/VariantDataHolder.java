package com.blackgear.vanillabackport.common.api.variant;

import net.minecraft.class_1297;
import net.minecraft.class_1309;

/**
 * added for retro-compatibility with MC Earth Mobs Addon, highly recommended for the dev to migrate!
 */
@Deprecated(forRemoval = true, since = "1.3") @SuppressWarnings("unchecked")
public interface VariantDataHolder<T> extends com.blackgear.vanillabackport.common.api.modules.mob_variant.VariantDataHolder<T> {
    static <T> VariantDataHolder<T> getHolder(class_1309 entity) {
        return entity instanceof VariantDataHolder<?> ? (VariantDataHolder<T>) entity : null;
    }
    
    static <T> VariantDataHolder<T> getHolder(class_1297 entity) {
        return entity instanceof VariantDataHolder<?> ? (VariantDataHolder<T>) entity : null;
    }
}