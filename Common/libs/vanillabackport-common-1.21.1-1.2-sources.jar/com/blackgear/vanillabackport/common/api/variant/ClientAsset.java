package com.blackgear.vanillabackport.common.api.variant;

import net.minecraft.class_2960;

/**
 * added for retro-compatibility with MC Earth Mobs Addon, highly recommended for the dev to migrate!
 */
@Deprecated(forRemoval = true, since = "1.3")
public class ClientAsset extends com.blackgear.vanillabackport.common.api.modules.mob_variant.ClientAsset {
    public ClientAsset(class_2960 id, class_2960 path) {
        super(id, path);
    }
}
