package com.blackgear.vanillabackport.common.api.extensions.entity.spear;

import com.blackgear.vanillabackport.common.level.components.AttackRange;
import java.util.function.Predicate;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_243;

public interface MobSpearHandler {
    AttackRange vb$getAttackRangeWith(class_1799 weapon);

    boolean vb$wasRecentlyStabbed(class_1297 target, int allowedTime);

    void vb$rememberStabbedEntity(class_1297 target);

    default int vb$stabbedEntities(Predicate<class_1297> filter) {
        return 0;
    }

    boolean vb$stabAttack(class_1304 weaponSlot, class_1297 target, float baseDamage, boolean dealsDamage, boolean dealsKnockback, boolean dismounts);

    void vb$causeExtraKnockback(class_1297 target, float knockback, class_243 oldMovement);

    default void vb$onAttack() {}

    void vb$postPiercingAttack();

    float vb$getTicksSinceLastKineticHitFeedback(float partial);
}