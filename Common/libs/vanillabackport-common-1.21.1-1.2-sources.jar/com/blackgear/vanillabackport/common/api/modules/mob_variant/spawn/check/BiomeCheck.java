package com.blackgear.vanillabackport.common.api.modules.mob_variant.spawn.check;

import com.blackgear.vanillabackport.common.api.modules.mob_variant.spawn.SpawnCondition;
import com.blackgear.vanillabackport.common.api.modules.mob_variant.spawn.SpawnContext;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_1959;
import net.minecraft.class_6885;
import net.minecraft.class_6895;
import net.minecraft.class_7924;

public record BiomeCheck(class_6885<class_1959> requiredBiomes) implements SpawnCondition {
    public static final MapCodec<BiomeCheck> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
        class_6895.method_40340(class_7924.field_41236).fieldOf("biomes").forGetter(BiomeCheck::requiredBiomes)
    ).apply(instance, BiomeCheck::new));
    
    @Override
    public boolean test(SpawnContext context) {
        return this.requiredBiomes.method_40241(context.biome());
    }

    @Override
    public MapCodec<? extends SpawnCondition> codec() {
        return CODEC;
    }
}