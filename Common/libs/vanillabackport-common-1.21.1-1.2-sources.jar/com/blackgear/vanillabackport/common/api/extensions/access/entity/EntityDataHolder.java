package com.blackgear.vanillabackport.common.api.extensions.access.entity;

import net.minecraft.class_2487;

public interface EntityDataHolder {
    default void vb$addAdditionalSaveData(class_2487 tag) { /* NO-OP */ }
    
    default void vb$readAdditionalSaveData(class_2487 tag) { /* NO-OP */ }
}