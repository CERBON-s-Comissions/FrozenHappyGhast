package com.blackgear.vanillabackport.common.api.experiment.minecart_behavior;

import com.blackgear.vanillabackport.core.mixin.common.access.AbstractMinecartAccessor;
import com.blackgear.vanillabackport.core.mixin.common.access.EntityAccessor;
import com.blackgear.vanillabackport.core.util.AdditionalCodecs;
import com.blackgear.vanillabackport.core.util.Utilities.*;
import com.blackgear.vanillabackport.core.util.WorldUtilities.*;
import com.mojang.datafixers.util.Pair;
import io.netty.buffer.ByteBuf;
import org.jetbrains.annotations.Nullable;

import java.util.LinkedList;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1301;
import net.minecraft.class_1313;
import net.minecraft.class_1439;
import net.minecraft.class_1657;
import net.minecraft.class_1688;
import net.minecraft.class_1695;
import net.minecraft.class_2241;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2442;
import net.minecraft.class_2680;
import net.minecraft.class_2768;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3532;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public class NewMinecartBehavior extends MinecartBehavior {
    private @Nullable StepPartialTicks cacheIndexAlpha;
    private int cachedLerpDelay;
    private float cachedPartialTick;
    private int lerpDelay = 0;
    public final List<MinecartStep> lerpSteps = new LinkedList<>();
    public final List<MinecartStep> currentLerpSteps = new LinkedList<>();
    public double currentLerpStepsTotalWeight = 0.0;
    public MinecartStep oldLerp = MinecartStep.ZERO;
    
    public NewMinecartBehavior(class_1688 minecart) {
        super(minecart);
    }
    
    @Override
    public void tick() {
        if (this.level() instanceof class_3218 serverLevel) {
            class_2338 var5 = this.getCurrentBlockPosOrRailBelow();
            class_2680 state = this.level().method_8320(var5);
            if (((EntityAccessor) this.minecart).isFirstTick()) {
                ((AbstractMinecartAccessor) this.minecart).setOnRails(class_2241.method_9476(state));
                this.adjustToRails(var5, state, true);
            }
            
            ((EntityAccessor) this.minecart).callApplyGravity();
            this.moveAlongTrack(serverLevel);
        } else {
            this.lerpClientPositionAndRotation();
            boolean onRails = class_2241.method_9476(this.level().method_8320(this.getCurrentBlockPosOrRailBelow()));
            ((AbstractMinecartAccessor) this.minecart).setOnRails(onRails);
        }
    }
    
    private void lerpClientPositionAndRotation() {
        if (--this.lerpDelay <= 0) {
            this.setOldLerpValues();
            this.currentLerpSteps.clear();
            if (!this.lerpSteps.isEmpty()) {
                this.currentLerpSteps.addAll(this.lerpSteps);
                this.lerpSteps.clear();
                this.currentLerpStepsTotalWeight = 0.0;
                
                for (NewMinecartBehavior.MinecartStep minecartStep : this.currentLerpSteps) {
                    this.currentLerpStepsTotalWeight = this.currentLerpStepsTotalWeight + minecartStep.weight;
                }
                
                this.lerpDelay = this.currentLerpStepsTotalWeight == 0.0 ? 0 : 3;
            }
        }
        
        if (this.cartHasPosRotLerp()) {
            this.setPos(this.getCartLerpPosition(1.0F));
            this.setDeltaMovement(this.getCartLerpMovements(1.0F));
            this.setXRot(this.getCartLerpXRot(1.0F));
            this.setYRot(this.getCartLerpYRot(1.0F));
        }
    }
    
    public void setOldLerpValues() {
        this.oldLerp = new NewMinecartBehavior.MinecartStep(this.position(), this.getDeltaMovement(), this.getYRot(), this.getXRot(), 0.0F);
    }
    
    public boolean cartHasPosRotLerp() {
        return !this.currentLerpSteps.isEmpty();
    }
    
    public float getCartLerpXRot(final float partialTicks) {
        NewMinecartBehavior.StepPartialTicks currentStepPartialTicks = this.getCurrentLerpStep(partialTicks);
        return class_3532.method_17821(currentStepPartialTicks.partialTicksInStep, currentStepPartialTicks.previousStep.xRot, currentStepPartialTicks.currentStep.xRot);
    }
    
    public float getCartLerpYRot(final float partialTicks) {
        NewMinecartBehavior.StepPartialTicks currentStepPartialTicks = this.getCurrentLerpStep(partialTicks);
        return class_3532.method_17821(currentStepPartialTicks.partialTicksInStep, currentStepPartialTicks.previousStep.yRot, currentStepPartialTicks.currentStep.yRot);
    }
    
    public class_243 getCartLerpPosition(final float partialTicks) {
        NewMinecartBehavior.StepPartialTicks currentStepPartialTicks = this.getCurrentLerpStep(partialTicks);
        return MthUtils.lerp(currentStepPartialTicks.partialTicksInStep, currentStepPartialTicks.previousStep.position, currentStepPartialTicks.currentStep.position);
    }
    
    public class_243 getCartLerpMovements(final float partialTicks) {
        NewMinecartBehavior.StepPartialTicks currentStepPartialTicks = this.getCurrentLerpStep(partialTicks);
        return MthUtils.lerp(currentStepPartialTicks.partialTicksInStep, currentStepPartialTicks.previousStep.movement, currentStepPartialTicks.currentStep.movement);
    }
    
    private NewMinecartBehavior.StepPartialTicks getCurrentLerpStep(final float partialTick) {
        if (partialTick != this.cachedPartialTick || this.lerpDelay != this.cachedLerpDelay || this.cacheIndexAlpha == null) {
            float alpha = (3 - this.lerpDelay + partialTick) / 3.0F;
            float countUp = 0.0F;
            float indexedPartialTick = 1.0F;
            boolean foundIndex = false;
            
            int index;
            for (index = 0; index < this.currentLerpSteps.size(); index++) {
                float weight = this.currentLerpSteps.get(index).weight;
                if (!(weight <= 0.0F)) {
                    countUp += weight;
                    if (countUp >= this.currentLerpStepsTotalWeight * alpha) {
                        float current = countUp - weight;
                        indexedPartialTick = (float) ((alpha * this.currentLerpStepsTotalWeight - current) / weight);
                        foundIndex = true;
                        break;
                    }
                }
            }
            
            if (!foundIndex) {
                index = this.currentLerpSteps.size() - 1;
            }
            
            MinecartStep currentStep = this.currentLerpSteps.get(index);
            MinecartStep previousStep = index > 0 ? this.currentLerpSteps.get(index - 1) : this.oldLerp;
            this.cacheIndexAlpha = new StepPartialTicks(indexedPartialTick, currentStep, previousStep);
            this.cachedLerpDelay = this.lerpDelay;
            this.cachedPartialTick = partialTick;
        }
        
        return this.cacheIndexAlpha;
    }
    
    public void adjustToRails(final class_2338 targetBlockPos, final class_2680 currentState, final boolean instant) {
        if (class_2241.method_9476(currentState)) {
            class_2768 shape = currentState.method_11654(((class_2241)currentState.method_26204()).method_9474());
            Pair<class_2382, class_2382> exits = AbstractMinecartAccessor.callExits(shape);
            class_243 exit0 = VectorUtils.create(exits.getFirst()).method_1021(0.5);
            class_243 exit1 = VectorUtils.create(exits.getSecond()).method_1021(0.5);
            class_243 horizontalOutDirection = VectorUtils.horizontal(exit0);
            class_243 horizontalInDirection = VectorUtils.horizontal(exit1);
            if (this.getDeltaMovement().method_1033() > 1.0E-5F && this.getDeltaMovement().method_1026(horizontalOutDirection) < this.getDeltaMovement().method_1026(horizontalInDirection)
                || this.isDecending(horizontalInDirection, shape)) {
                class_243 swap = horizontalOutDirection;
                horizontalOutDirection = horizontalInDirection;
                horizontalInDirection = swap;
            }
            
            float yRot = 180.0F - (float)(Math.atan2(horizontalOutDirection.field_1350, horizontalOutDirection.field_1352) * 180.0 / Math.PI);
            yRot += this.isFlipped() ? 180.0F : 0.0F;
            class_243 previousPosition = this.position();
            boolean inCorner = exit0.method_10216() != exit1.method_10216() && exit0.method_10215() != exit1.method_10215();
            class_243 targetPosition;
            if (inCorner) {
                class_243 from0to1 = exit1.method_1020(exit0);
                class_243 from0toPos = previousPosition.method_1020(class_243.method_24955(targetBlockPos)).method_1020(exit0);
                class_243 travelVectorFrom0 = from0to1.method_1021(from0to1.method_1026(from0toPos) / from0to1.method_1026(from0to1));
                targetPosition = class_243.method_24955(targetBlockPos).method_1019(exit0).method_1019(travelVectorFrom0);
                yRot = 180.0F - (float)(Math.atan2(travelVectorFrom0.field_1350, travelVectorFrom0.field_1352) * 180.0 / Math.PI);
                yRot += this.isFlipped() ? 180.0F : 0.0F;
            } else {
                boolean zSnap = exit0.method_1020(exit1).field_1352 != 0.0;
                boolean xSnap = exit0.method_1020(exit1).field_1350 != 0.0;
                targetPosition = new class_243(
                    xSnap ? class_243.method_24953(targetBlockPos).field_1352 : previousPosition.field_1352, targetBlockPos.method_10264(), zSnap ? class_243.method_24953(targetBlockPos).field_1350 : previousPosition.field_1350
                );
            }
            
            class_243 diffFromBlock = targetPosition.method_1020(previousPosition);
            this.setPos(previousPosition.method_1019(diffFromBlock));
            float xRot = 0.0F;
            boolean inHill = exit0.method_10214() != exit1.method_10214();
            if (inHill) {
                class_243 inPosition = class_243.method_24955(targetBlockPos).method_1019(horizontalInDirection);
                double horizontalDistanceFromIn = inPosition.method_1022(this.position());
                this.setPos(this.position().method_1031(0.0, horizontalDistanceFromIn + 0.1, 0.0));
                xRot = this.isFlipped() ? 45.0F : -45.0F;
            } else {
                this.setPos(this.position().method_1031(0.0, 0.1, 0.0));
            }
            
            this.setRotation(yRot, xRot);
            double adjustDistance = previousPosition.method_1022(this.position());
            if (adjustDistance > 0.0) {
                this.lerpSteps
                    .add(
                        new MinecartStep(this.position(), this.getDeltaMovement(), this.getYRot(), this.getXRot(), instant ? 0.0F : (float)adjustDistance)
                    );
            }
        }
    }
    
    private void setRotation(float yRot, float xRot) {
        double yRotDiff = Math.abs(yRot - this.getYRot());
        if (yRotDiff >= 175.0 && yRotDiff <= 185.0) {
            this.setFlipped(!this.isFlipped());
            yRot -= 180.0F;
            xRot *= -1.0F;
        }
        
        xRot = Math.clamp(xRot, -45.0F, 45.0F);
        this.setXRot(xRot % 360.0F);
        this.setYRot(yRot % 360.0F);
    }
    
    @Override
    public void moveAlongTrack(class_3218 level) {
        for (TrackIteration trackIteration = new TrackIteration();
             trackIteration.shouldIterate() && this.minecart.method_5805();
             trackIteration.firstIteration = false
        ) {
            class_243 initialStepDeltaMovement = this.getDeltaMovement();
            class_2338 currentPos = this.getCurrentBlockPosOrRailBelow();
            class_2680 currentState = this.level().method_8320(currentPos);
            boolean onRails = class_2241.method_9476(currentState);
            if (this.minecart.method_52172() != onRails) {
                ((AbstractMinecartAccessor) this.minecart).setOnRails(onRails);
                this.adjustToRails(currentPos, currentState, false);
            }
            
            if (onRails) {
                this.minecart.method_38785();
                this.minecart.method_22862();
                if (currentState.method_27852(class_2246.field_10546)) {
                    this.minecart.method_7506(currentPos.method_10263(), currentPos.method_10264(), currentPos.method_10260(), currentState.method_11654(class_2442.field_11364));
                }
                
                class_2768 shape = currentState.method_11654(((class_2241) currentState.method_26204()).method_9474());
                class_243 newDeltaMovement = this.calculateTrackSpeed(level, VectorUtils.horizontal(initialStepDeltaMovement), trackIteration, currentPos, currentState, shape);
                if (trackIteration.firstIteration) {
                    trackIteration.movementLeft = newDeltaMovement.method_37267();
                } else {
                    trackIteration.movementLeft = trackIteration.movementLeft + (newDeltaMovement.method_37267() - initialStepDeltaMovement.method_37267());
                }
                
                this.setDeltaMovement(newDeltaMovement);
                trackIteration.movementLeft = this.stepAlongTrack(currentPos, shape, trackIteration.movementLeft);
            } else {
                this.comeOffTrack(level);
                trackIteration.movementLeft = 0.0;
            }
            
            class_243 stepPosition = this.position();
            class_243 stepDelta = stepPosition.method_1020(EntityUtils.oldPosition(this.minecart));
            double stepLength = stepDelta.method_1033();
            if (stepLength > class_3532.field_29849) {
                if (!(stepDelta.method_37268() > class_3532.field_29849)) {
                    if (!this.minecart.method_52172()) {
                        this.setXRot(this.minecart.method_24828() ? 0.0F : class_3532.method_17821(0.2F, this.getXRot(), 0.0F));
                    }
                } else {
                    float yRot = 180.0F - (float)(Math.atan2(stepDelta.field_1350, stepDelta.field_1352) * class_3532.field_29848);
                    float xRot = this.minecart.method_24828() && !this.minecart.method_52172()
                        ? 0.0F
                        : 90.0F - (float) (Math.atan2(stepDelta.method_37267(), stepDelta.field_1351) * class_3532.field_29848);
                    yRot += this.isFlipped() ? 180.0F : 0.0F;
                    xRot *= this.isFlipped() ? -1.0F : 1.0F;
                    this.setRotation(yRot, xRot);
                }
                
                this.lerpSteps
                    .add(
                        new MinecartStep(
                            stepPosition, this.getDeltaMovement(), this.getYRot(), this.getXRot(), (float)Math.min(stepLength, this.getMaxSpeed(level))
                        )
                    );
            } else if (initialStepDeltaMovement.method_37268() > 0.0) {
                this.lerpSteps.add(new MinecartStep(stepPosition, this.getDeltaMovement(), this.getYRot(), this.getXRot(), 1.0F));
            }
            
            if (stepLength > class_3532.field_29849 || trackIteration.firstIteration) {
                ((EntityAccessor) this.minecart).callCheckInsideBlocks();
                ((EntityAccessor) this.minecart).callCheckInsideBlocks();
            }
        }
    }
    
    private class_243 calculateTrackSpeed(
        class_3218 level,
        class_243 deltaMovement,
        TrackIteration trackIteration,
        class_2338 currentPos,
        class_2680 currentState,
        class_2768 shape
    ) {
        class_243 newDeltaMovement = deltaMovement;
        if (!trackIteration.hasGainedSlopeSpeed) {
            class_243 slopedDeltaMovement = this.calculateSlopeSpeed(deltaMovement, shape);
            if (slopedDeltaMovement.method_37268() != deltaMovement.method_37268()) {
                trackIteration.hasGainedSlopeSpeed = true;
                newDeltaMovement = slopedDeltaMovement;
            }
        }
        
        if (trackIteration.firstIteration) {
            class_243 playerInputMovement = this.calculatePlayerInputSpeed(newDeltaMovement);
            if (playerInputMovement.method_37268() != newDeltaMovement.method_37268()) {
                trackIteration.hasHalted = true;
                newDeltaMovement = playerInputMovement;
            }
        }
        
        if (!trackIteration.hasHalted) {
            class_243 haltedDeltaMovement = this.calculateHaltTrackSpeed(newDeltaMovement, currentState);
            if (haltedDeltaMovement.method_37268() != newDeltaMovement.method_37268()) {
                trackIteration.hasHalted = true;
                newDeltaMovement = haltedDeltaMovement;
            }
        }
        
        if (trackIteration.firstIteration) {
            newDeltaMovement = this.applyNaturalSlowdown(newDeltaMovement);
            if (newDeltaMovement.method_1027() > 0.0) {
                double speed = Math.min(newDeltaMovement.method_1033(), this.getMaxSpeed(level));
                newDeltaMovement = newDeltaMovement.method_1029().method_1021(speed);
            }
        }
        
        if (!trackIteration.hasBoosted) {
            class_243 boostedDeltaMovement = this.calculateBoostTrackSpeed(newDeltaMovement, currentPos, currentState);
            if (boostedDeltaMovement.method_37268() != newDeltaMovement.method_37268()) {
                trackIteration.hasBoosted = true;
                newDeltaMovement = boostedDeltaMovement;
            }
        }
        
        return newDeltaMovement;
    }
    
    private class_243 calculateSlopeSpeed(class_243 deltaMovement, class_2768 shape) {
        double slideSpeed = Math.max(0.0078125, deltaMovement.method_37267() * 0.02);
        if (this.minecart.method_5799()) {
            slideSpeed *= 0.2;
        }
        return switch (shape) {
            case field_12667 -> deltaMovement.method_1031(-slideSpeed, 0.0, 0.0);
            case field_12666 -> deltaMovement.method_1031(slideSpeed, 0.0, 0.0);
            case field_12670 -> deltaMovement.method_1031(0.0, 0.0, slideSpeed);
            case field_12668 -> deltaMovement.method_1031(0.0, 0.0, -slideSpeed);
            default -> deltaMovement;
        };
    }
    
    private class_243 calculatePlayerInputSpeed(class_243 deltaMovement) {
        if (this.minecart.method_31483() instanceof class_3222 player) {
            class_243 moveIntent = player.method_18798();
            if (moveIntent.method_1027() > 0.0) {
                class_243 riderMovement = moveIntent.method_1029();
                double ownDist = deltaMovement.method_37268();
                if (riderMovement.method_1027() > 0.0 && ownDist < 0.01) {
                    return deltaMovement.method_1019(new class_243(riderMovement.field_1352, 0.0, riderMovement.field_1350).method_1029().method_1021(0.001));
                }
            }
        }
        
        return deltaMovement;
    }
    
    private class_243 calculateHaltTrackSpeed(class_243 deltaMovement, class_2680 state) {
        if (state.method_27852(class_2246.field_10425) && !state.method_11654(class_2442.field_11364)) {
            return deltaMovement.method_1033() < 0.03 ? class_243.field_1353 : deltaMovement.method_1021(0.5);
        } else {
            return deltaMovement;
        }
    }
    
    private class_243 calculateBoostTrackSpeed(class_243 deltaMovement, class_2338 pos, class_2680 state) {
        if (state.method_27852(class_2246.field_10425) && state.method_11654(class_2442.field_11364)) {
            if (deltaMovement.method_1033() > 0.01) {
                return deltaMovement.method_1029().method_1021(deltaMovement.method_1033() + 0.06);
            } else {
                class_243 powerDirection = this.getRedstoneDirection(pos);
                return powerDirection.method_1027() <= 0.0 ? deltaMovement : powerDirection.method_1021(deltaMovement.method_1033() + 0.2);
            }
        } else {
            return deltaMovement;
        }
    }
    
    @Override
    public double stepAlongTrack(class_2338 pos, class_2768 shape, double movementLeft) {
        if (movementLeft < class_3532.field_29849) {
            return 0.0;
        } else {
            class_243 oldPosition = this.position();
            Pair<class_2382, class_2382> exits = AbstractMinecartAccessor.callExits(shape);
            class_2382 exit0 = exits.getFirst();
            class_2382 exit1 = exits.getSecond();
            class_243 movement = VectorUtils.horizontal(this.getDeltaMovement());
            if (movement.method_1033() < class_3532.field_29849) {
                this.setDeltaMovement(class_243.field_1353);
                return 0;
            } else {
                boolean inHill = exit0.method_10264() != exit1.method_10264();
                class_243 horizontalInDirection = VectorUtils.horizontal(VectorUtils.create(exit1).method_1021(0.5));
                class_243 horizontalOutDirection = VectorUtils.horizontal(VectorUtils.create(exit0).method_1021(0.5));
                if (movement.method_1026(horizontalOutDirection) < movement.method_1026(horizontalInDirection)) {
                    horizontalOutDirection = horizontalInDirection;
                }
                
                class_243 outPosition = class_243.method_24955(pos).method_1019(horizontalOutDirection).method_1031(0.0, 0.1, 0.0).method_1019(horizontalOutDirection.method_1029().method_1021(class_3532.field_29849));
                if (inHill && !this.isDecending(movement, shape)) {
                    outPosition = outPosition.method_1031(0.0, 1.0, 0.0);
                }
                
                class_243 towardsOut = outPosition.method_1020(this.position()).method_1029();
                movement = towardsOut.method_1021(movement.method_1033() / towardsOut.method_37267());
                class_243 newPosition = oldPosition.method_1019(movement.method_1029().method_1021(movementLeft * (inHill ? class_3532.field_15724 : 1.0F)));
                if (oldPosition.method_1025(outPosition) <= oldPosition.method_1025(newPosition)) {
                    movementLeft = outPosition.method_1020(newPosition).method_37267();
                    newPosition = outPosition;
                } else {
                    movementLeft = 0.0;
                }
                
                this.minecart.method_5784(class_1313.field_6308, newPosition.method_1020(oldPosition));
                class_2680 newBlockState = this.level().method_8320(class_2338.method_49638(newPosition));
                if (inHill) {
                    if (class_2241.method_9476(newBlockState)) {
                        class_2768 newRailShape = newBlockState.method_11654(((class_2241) newBlockState.method_26204()).method_9474());
                        if (this.restAtVShape(shape, newRailShape)) {
                            return 0.0;
                        }
                    }
                    
                    double horizontalDistanceFromOut = VectorUtils.horizontal(outPosition).method_1022(VectorUtils.horizontal(this.position()));
                    double projectYPos = outPosition.field_1351 + (this.isDecending(movement, shape) ? horizontalDistanceFromOut : -horizontalDistanceFromOut);
                    if (this.position().field_1351 < projectYPos) {
                        this.setPos(this.position().field_1352, projectYPos, this.position().field_1350);
                    }
                }
                
                if (this.position().method_1022(oldPosition) < class_3532.field_29849 && newPosition.method_1022(oldPosition) > class_3532.field_29849) {
                    this.setDeltaMovement(class_243.field_1353);
                    return 0.0;
                } else {
                    this.setDeltaMovement(movement);
                    return movementLeft;
                }
            }
        }
    }
    
    private boolean restAtVShape(class_2768 currentRailShape, class_2768 newRailShape) {
        if (this.getDeltaMovement().method_1027() < 0.005
            && newRailShape.method_11897()
            && this.isDecending(this.getDeltaMovement(), currentRailShape)
            && !this.isDecending(this.getDeltaMovement(), newRailShape)) {
            this.setDeltaMovement(class_243.field_1353);
            return true;
        } else {
            return false;
        }
    }
    
    @Override
    public double getMaxSpeed(class_3218 level) {
        return 8 * (this.minecart.method_5799() ? 0.5 : 1.0) / 20.0; //TODO: add gamerule
    }
    
    private boolean isDecending(class_243 movement, class_2768 shape) {
        return switch (shape) {
            case field_12667 -> movement.field_1352 < 0.0;
            case field_12666 -> movement.field_1352 > 0.0;
            case field_12670 -> movement.field_1350 > 0.0;
            case field_12668 -> movement.field_1350 < 0.0;
            default -> false;
        };
    }
    
    @Override
    public double getSlowdownFactor() {
        return this.minecart.method_5782() ? 0.997 : 0.975;
    }
    
    @Override
    public boolean pushAndPickupEntities() {
        boolean pickedUp = this.pickupEntities(this.minecart.method_5829().method_1009(0.2, 0.0, 0.2));
        if (!this.minecart.field_5976 && !this.minecart.field_5992) {
            return false;
        } else {
            boolean pushed = this.pushEntities(this.minecart.method_5829().method_1014(MthUtils.EPSILON));
            return pickedUp && !pushed;
        }
    }
    
    public boolean pickupEntities(class_238 hitbox) {
        if (this.minecart instanceof class_1695 && !this.minecart.method_5782()) {
            List<class_1297> entities = this.level().method_8333(this.minecart, hitbox, class_1301.method_5911(this.minecart));
            if (!entities.isEmpty()) {
                for (class_1297 entity : entities) {
                    if (!(entity instanceof class_1657)
                        && !(entity instanceof class_1439)
                        && !(entity instanceof class_1688)
                        && !this.minecart.method_5782()
                        && !entity.method_5765()) {
                        boolean pickedUp = entity.method_5804(this.minecart);
                        if (pickedUp) {
                            return true;
                        }
                    }
                }
            }
        }
        
        return false;
    }
    
    public boolean pushEntities(class_238 hitbox) {
        boolean pushed = false;
        if (this.minecart instanceof class_1695) {
            List<class_1297> entities = this.level().method_8333(this.minecart, hitbox, class_1301.method_5911(this.minecart));
            if (!entities.isEmpty()) {
                for (class_1297 entity : entities) {
                    if (entity instanceof class_1657 || entity instanceof class_1439 || entity instanceof class_1688 || this.minecart.method_5782() || entity.method_5765()) {
                        entity.method_5697(this.minecart);
                        pushed = true;
                    }
                }
            }
        } else {
            for (class_1297 entity : this.level().method_8335(this.minecart, hitbox)) {
                if (!this.minecart.method_5626(entity) && entity.method_5810() && entity instanceof class_1688) {
                    entity.method_5697(this.minecart);
                    pushed = true;
                }
            }
        }
        
        return pushed;
    }
    
    public record MinecartStep(class_243 position, class_243 movement, float yRot, float xRot, float weight) {
        public static final class_9139<ByteBuf, NewMinecartBehavior.MinecartStep> STREAM_CODEC = class_9139.method_56906(
            AdditionalCodecs.VEC3_STREAM_CODEC, MinecartStep::position,
            AdditionalCodecs.VEC3_STREAM_CODEC, MinecartStep::movement,
            AdditionalCodecs.ROTATION_BYTE, MinecartStep::yRot,
            AdditionalCodecs.ROTATION_BYTE, MinecartStep::xRot,
            class_9135.field_48552, MinecartStep::weight,
            MinecartStep::new
        );
        
        public static final MinecartStep ZERO = new MinecartStep(class_243.field_1353, class_243.field_1353, 0.0F, 0.0F, 0.0F);
    }
    
    private record StepPartialTicks(float partialTicksInStep, MinecartStep currentStep, MinecartStep previousStep) { /* NO-OP */}
    
    private static class TrackIteration {
        public double movementLeft = 0.0;
        public boolean firstIteration = true;
        public boolean hasGainedSlopeSpeed = false;
        public boolean hasHalted = false;
        public boolean hasBoosted = false;
        
        public boolean shouldIterate() {
            return this.firstIteration || this.movementLeft > class_3532.field_29849;
        }
    }
}