package com.blackgear.vanillabackport.common.api.modules.bundle_ui;

import com.blackgear.vanillabackport.core.VanillaBackport;
import org.apache.commons.lang3.math.Fraction;

import java.util.Optional;
import java.util.function.Consumer;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_5253;
import net.minecraft.class_5536;
import net.minecraft.class_5630;
import net.minecraft.class_9276;
import net.minecraft.class_9334;

public class BundleItemHandler {
    private static final int FULL_BAR_COLOR = class_5253.class_5254.method_59554(1.0F, 1.0F, 0.33F, 0.33F);
    private static final int BAR_COLOR = class_5253.class_5254.method_59554(1.0F, 0.44F, 0.53F, 1.0F);
    
    public static boolean overrideStackedOnOther(class_1799 stack, class_1735 slot, class_5536 action, class_1657 player, Consumer<class_1297> insertSound, Consumer<class_1297> removeSound) {
        class_9276 contents = stack.method_57824(class_9334.field_49650);
        if (contents == null) return false;
        
        class_1799 itemInSlot = slot.method_7677();
        class_9276.class_9277 mutable = new class_9276.class_9277(contents);
        boolean handled = false;
        
        class_5536 insertAction = VanillaBackport.COMMON_CONFIG.invertBundleControls.get() ? class_5536.field_27014 : class_5536.field_27013;
        
        if (action == insertAction && !itemInSlot.method_7960()) {
            if (mutable.method_57431(slot, player) > 0) {
                insertSound.accept(player);
            } else {
                BundleFeatures.playInsertFailSound(player);
            }
            
            handled = true;
        } else if (action == class_5536.field_27014 && itemInSlot.method_7960()) {
            class_1799 removed = mutable.method_57430();
            if (removed != null) {
                class_1799 insert = slot.method_32756(removed);
                if (insert.method_7947() > 0) {
                    mutable.method_57432(insert);
                } else {
                    removeSound.accept(player);
                }
            }
            
            handled = true;
        }
        
        if (handled) {
            stack.method_57379(class_9334.field_49650, mutable.method_57435());
            broadcastChangesOnContainerMenu(player);
        }
        
        return handled;
    }
    
    public static boolean overrideOtherStackedOnMe(class_1799 stack, class_1799 other, class_1735 slot, class_5536 action, class_1657 player, class_5630 access, Consumer<class_1297> insertSound, Consumer<class_1297> removeSound) {
        class_5536 insertAction = VanillaBackport.COMMON_CONFIG.invertBundleControls.get() ? class_5536.field_27014 : class_5536.field_27013;
        
        if (action == class_5536.field_27013 && other.method_7960()) {
            BundleFeatures.toggleSelectedItem(stack, -1);
            return false;
        }
        
        class_9276 contents = stack.method_57824(class_9334.field_49650);
        if (contents == null) return false;
        
        class_9276.class_9277 mutable = new class_9276.class_9277(contents);
        boolean handled = false;
        
        if (action == insertAction && !other.method_7960()) {
            if (slot.method_32754(player) && mutable.method_57432(other) > 0) {
                insertSound.accept(player);
            } else {
                BundleFeatures.playInsertFailSound(player);
            }
            
            handled = true;
        } else if (action == class_5536.field_27014 && other.method_7960()) {
            if (slot.method_32754(player)) {
                class_1799 removed = mutable.method_57430();
                if (removed != null) {
                    removeSound.accept(player);
                    access.method_32332(removed);
                }
            }
            
            handled = true;
        }
        
        if (handled) {
            stack.method_57379(class_9334.field_49650, mutable.method_57435());
            broadcastChangesOnContainerMenu(player);
            
            return true;
        }
        
        BundleFeatures.toggleSelectedItem(stack, -1);
        return false;
    }
    
    public static boolean dropContents(class_1799 stack, class_1657 player) {
        class_9276 contents = stack.method_57824(class_9334.field_49650);
        if (contents != null && !contents.method_57429()) {
            Optional<class_1799> removed = BundleFeatures.removeOneItemFromBundle(stack, player, contents);
            if (removed.isPresent()) {
                player.method_7328(removed.get(), true);
                return true;
            }
        }
        
        return false;
    }
    
    public static int getBarColor(class_1799 stack) {
        class_9276 contents = stack.method_57825(class_9334.field_49650, class_9276.field_49289);
        return contents.method_57428().compareTo(Fraction.ONE) >= 0 ? FULL_BAR_COLOR : BAR_COLOR;
    }
    
    public static void broadcastChangesOnContainerMenu(class_1657 player) {
        if (player.field_7512 != null) {
            try {
                player.field_7512.method_7609(player.method_31548());
            } catch (IndexOutOfBoundsException ignored) {}
        }
    }
}