package com.blackgear.vanillabackport.common.api.modules.ender_pearl_persistance;

import java.util.Set;
import net.minecraft.class_1684;

public interface EnderPearlAccess {
    void registerEnderPearl(class_1684 pearl);
    
    void deregisterEnderPearl(class_1684 pearl);
    
    Set<class_1684> getEnderPearls();
}