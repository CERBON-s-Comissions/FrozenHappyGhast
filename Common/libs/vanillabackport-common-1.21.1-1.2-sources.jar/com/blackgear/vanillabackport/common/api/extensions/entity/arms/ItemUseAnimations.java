package com.blackgear.vanillabackport.common.api.extensions.entity.arms;

import net.minecraft.class_1839;

public enum ItemUseAnimations {
    REAL_SPEAR;

    public class_1839 get() {
        return class_1839.valueOf(this.name());
    }
}