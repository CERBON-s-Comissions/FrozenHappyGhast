package com.blackgear.vanillabackport.common.api.modules.leash_behavior;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_243;

@Environment(EnvType.CLIENT)
public class LeashState {
    public class_243 offset = class_243.field_1353;
    public class_243 start = class_243.field_1353;
    public class_243 end = class_243.field_1353;
    public int startBlockLight = 0;
    public int endBlockLight = 0;
    public int startSkyLight = 15;
    public int endSkyLight = 15;
    public boolean slack = true;
}