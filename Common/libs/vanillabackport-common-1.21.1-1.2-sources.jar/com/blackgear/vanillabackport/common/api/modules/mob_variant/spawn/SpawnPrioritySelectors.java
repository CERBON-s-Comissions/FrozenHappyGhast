package com.blackgear.vanillabackport.common.api.modules.mob_variant.spawn;

import com.mojang.serialization.Codec;
import io.netty.buffer.ByteBuf;
import java.util.List;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record SpawnPrioritySelectors(List<PriorityProvider.Selector<SpawnContext, SpawnCondition>> selectors) {
    public static final SpawnPrioritySelectors EMPTY = new SpawnPrioritySelectors(List.of());
    public static final Codec<SpawnPrioritySelectors> CODEC = PriorityProvider.Selector.codec(SpawnCondition.CODEC)
        .listOf()
        .xmap(SpawnPrioritySelectors::new, SpawnPrioritySelectors::selectors);
    public static final class_9139<ByteBuf, SpawnPrioritySelectors> STREAM_CODEC = class_9135.method_56368(CODEC);

    public static SpawnPrioritySelectors single(SpawnCondition condition, int priority) {
        return new SpawnPrioritySelectors(PriorityProvider.single(condition, priority));
    }

    public static SpawnPrioritySelectors fallback(int priority) {
        return new SpawnPrioritySelectors(PriorityProvider.alwaysTrue(priority));
    }
}