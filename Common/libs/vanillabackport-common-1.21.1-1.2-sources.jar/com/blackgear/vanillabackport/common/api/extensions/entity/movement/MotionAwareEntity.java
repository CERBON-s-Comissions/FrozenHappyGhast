package com.blackgear.vanillabackport.common.api.extensions.entity.movement;

import com.blackgear.vanillabackport.core.mixin.common.access.EntityAccessor;
import net.minecraft.class_1297;
import net.minecraft.class_243;

public interface MotionAwareEntity {
    default class_243 getHeadLookAngle() {
        class_1297 self = (class_1297) this;
        return ((EntityAccessor) self).callCalculateViewVector(self.method_36455(), self.method_5791());
    }

    class_243 getKnownSpeed();

    void computeSpeed();
}