package com.blackgear.vanillabackport.common.api.modules.leash_behavior;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.Function;
import java.util.function.Predicate;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1492;
import net.minecraft.class_1496;
import net.minecraft.class_156;
import net.minecraft.class_1657;
import net.minecraft.class_1690;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_5712;
import net.minecraft.class_7689;
import net.minecraft.class_8153;
import net.minecraft.class_9817;

public final class LeashPhysics {
    public static final double LEASH_TOO_FAR_DIST = 12.0;
    public static final double LEASH_ELASTIC_DIST = 6.0;
    public static final class_243 AXIS_SPECIFIC_ELASTICITY = new class_243(0.8, 0.2, 0.8);
    private static final double TORSIONAL_ELASTICITY = 10.0;
    private static final double STIFFNESS = 0.11;

    private static final List<class_243> ENTITY_ATTACHMENT_POINT = ImmutableList.of(new class_243(0.0, 0.5, 0.5));
    private static final List<class_243> LEASHER_ATTACHMENT_POINT = ImmutableList.of(new class_243(0.0, 0.5, 0.0));
    private static final List<class_243> SHARED_QUAD_ATTACHMENT_POINTS = ImmutableList.of(
        new class_243(-0.5, 0.5,  0.5), new class_243(-0.5, 0.5, -0.5),
        new class_243( 0.5, 0.5, -0.5), new class_243( 0.5, 0.5,  0.5)
    );

    public static final Map<Predicate<class_1297>, Function<class_1297, class_243[]>> QUAD_LEASH_OFFSETS = class_156.method_656(() -> {
        ImmutableMap.Builder<Predicate<class_1297>, Function<class_1297, class_243[]>> offsets = new ImmutableMap.Builder<>();
        offsets.put(entity -> entity instanceof class_1690, entity -> createQuadOffsets(entity, 0.0, 0.64, 0.382, 0.88));
        offsets.put(entity -> entity instanceof class_7689, entity -> createQuadOffsets(entity, 0.02, 0.48, 0.25, 0.82));
        offsets.put(entity -> entity instanceof class_1492, entity -> createQuadOffsets(entity, 0.04, 0.41, 0.18, 0.73));
        offsets.put(entity -> entity instanceof class_1496, entity -> createQuadOffsets(entity, 0.04, 0.52, 0.23, 0.87));
        offsets.put(entity -> entity instanceof class_8153, entity -> createQuadOffsets(entity, -0.01, 0.63, 0.38, 1.15));
        return offsets.build();
    });

    public static double distanceBetween(class_1297 target, class_1297 holder) {
        return holder.method_5829().method_1005().method_1022(target.method_5829().method_1005());
    }

    public static boolean canAttachLeash(class_9817 leashable, class_1297 holder) {
        if (leashable == holder) return false;
        class_1297 entity = (class_1297) leashable;
        return distanceBetween(entity, holder) <= ((LeashableCallback) entity).vb$leashSnapDistance() && leashable.method_5931();
    }

    public static float angularFriction(class_1297 entity) {
        if (entity.method_24828()) {
            return entity.method_37908()
                .method_8320(entity.method_23314())
                .method_26204().method_9499() * 0.91F;
        } else {
            return entity.method_52535() ? 0.8F : 0.91F;
        }
    }

    public static class_243 getHolderMovement(class_1297 holder) {
        return holder instanceof class_1308 mob && mob.method_5987() ? class_243.field_1353 : holder.method_60478();
    }

    public static <E extends class_1297 & class_9817> boolean checkElasticInteractions(
        E entity,
        class_1297 holder,
        class_9817.class_9818 data
    ) {
        if (entity.method_5642() instanceof class_1657) return false;

        boolean quadConnection = ((LeashableCallback) holder).vb$supportsQuadLeashAsHolder() && ((LeashableCallback) entity).vb$supportsQuadLeash();
        List<Wrench> wrenches = computeElasticInteraction(
            entity,
            holder,
            quadConnection ? SHARED_QUAD_ATTACHMENT_POINTS : ENTITY_ATTACHMENT_POINT,
            quadConnection ? SHARED_QUAD_ATTACHMENT_POINTS : LEASHER_ATTACHMENT_POINT
        );

        if (wrenches.isEmpty()) {
            return false;
        } else {
            Wrench result = Wrench.accumulate(wrenches).scale(quadConnection ? 0.25 : 1.0);
            LeashDataExtension leashData = Objects.requireNonNull((LeashDataExtension) (Object) data);
            leashData.setAngularMomentum(leashData.angularMomentum() + TORSIONAL_ELASTICITY * result.torque());
            class_243 offset = getHolderMovement(holder).method_1020(entity.method_60478());
            entity.method_45319(result.force().method_18806(AXIS_SPECIFIC_ELASTICITY).method_1019(offset.method_1021(STIFFNESS)));
            return true;
        }
    }

    private static <E extends class_1297 & class_9817> List<Wrench> computeElasticInteraction(
        E entity,
        class_1297 holder,
        List<class_243> entityAttachmentPoints,
        List<class_243> leasherAttachmentPoints
    ) {
        double slackDistance = ((LeashableCallback) entity).vb$leashElasticDistance();
        class_243 currentMovement = getHolderMovement(entity);
        float entityYRot = entity.method_36454() * class_3532.field_29847;
        class_243 entityDimensions = new class_243(entity.method_17681(), entity.method_17682(), entity.method_17681());
        float holderYRot = holder.method_36454() * class_3532.field_29847;
        class_243 holderDimensions = new class_243(holder.method_17681(), holder.method_17682(), holder.method_17681());
        List<Wrench> wrenches = new ArrayList<>();

        for (int i = 0; i < entityAttachmentPoints.size(); i++) {
            class_243 entityAttachVector = entityAttachmentPoints.get(i).method_18806(entityDimensions).method_1024(-entityYRot);
            class_243 entityAttachPos = entity.method_19538().method_1019(entityAttachVector);
            class_243 holderAttachVector = leasherAttachmentPoints.get(i).method_18806(holderDimensions).method_1024(-holderYRot);
            class_243 holderAttachPos = holder.method_19538().method_1019(holderAttachVector);
            computeDampenedSpringInteraction(holderAttachPos, entityAttachPos, slackDistance, currentMovement, entityAttachVector).ifPresent(wrenches::add);
        }

        return wrenches;
    }

    private static Optional<Wrench> computeDampenedSpringInteraction(
        class_243 pivot,
        class_243 pos,
        double slack,
        class_243 motion,
        class_243 lever
    ) {
        double distance = pos.method_1022(pivot);
        if (distance < slack) {
            return Optional.empty();
        } else {
            class_243 displacement = pivot.method_1020(pos).method_1029().method_1021(distance - slack);
            double torque = Wrench.torqueFromForce(lever, displacement);
            if (motion.method_1026(displacement) >= 0.0) {
                displacement = displacement.method_1021(0.3F);
            }

            return Optional.of(new Wrench(displacement, torque));
        }
    }

    public static class_243[] createQuadOffsets(class_1297 entity, double frontOffset, double backOffset, double leftRight, double height) {
        float width = entity.method_17681();
        double frontOffsetScaled = frontOffset * width;
        double frontBackScaled = backOffset * width;
        double leftRightScaled = leftRight * width;
        double heightScaled = height * entity.method_17682();
        return new class_243[]{
            new class_243(-leftRightScaled, heightScaled, frontBackScaled + frontOffsetScaled),
            new class_243(-leftRightScaled, heightScaled, -frontBackScaled + frontOffsetScaled),
            new class_243(leftRightScaled, heightScaled, -frontBackScaled + frontOffsetScaled),
            new class_243(leftRightScaled, heightScaled, frontBackScaled + frontOffsetScaled)
        };
    }

    public static List<class_9817> leashableLeashedTo(class_1297 entity) {
        return leashableInArea(entity, leashable -> leashable.method_60952() == entity);
    }

    public static List<class_9817> leashableInArea(class_1297 entity, Predicate<class_9817> test) {
        return leashableInArea(entity.method_37908(), entity.method_5829().method_1005(), test);
    }

    public static List<class_9817> leashableInArea(class_1937 level, class_243 pos, Predicate<class_9817> test) {
        class_238 scanArea = class_238.method_30048(pos, 32.0, 32.0, 32.0);
        return level.method_8390(class_1297.class, scanArea, entity -> entity instanceof class_9817 leashable && test.test(leashable))
            .stream()
            .map(class_9817.class::cast)
            .toList();
    }

    public static void resetAngularMomentum(class_9817 leashable) {
        class_9817.class_9818 data = leashable.method_60955();
        if (data != null) {
            ((LeashDataExtension)(Object) data).setAngularMomentum(0.0);
        }
    }

    public static boolean dropAllLeashConnections(class_1297 entity, @Nullable class_1657 player) {
        List<class_9817> leashables = leashableLeashedTo(entity);
        boolean dropped = !leashables.isEmpty();
        if (entity instanceof class_9817 self && self.method_60953()) {
            self.method_5932(true, true);
            dropped = true;
        }

        for (class_9817 leashable : leashables) {
            leashable.method_5932(true, true);
        }

        if (dropped) {
            entity.method_32875(class_5712.field_28730, player);
            return true;
        } else {
            return false;
        }
    }

    public record Wrench(class_243 force, double torque) {
        public static final Wrench ZERO = new Wrench(class_243.field_1353, 0.0);

        public static double torqueFromForce(class_243 lever, class_243 force) {
            return lever.field_1350 * force.field_1352 - lever.field_1352 * force.field_1350;
        }

        public static Wrench accumulate(List<Wrench> wrenches) {
            if (wrenches.isEmpty()) {
                return ZERO;
            } else {
                double x = 0, y = 0, z = 0, t = 0;
                for (Wrench w : wrenches) {
                    x += w.force.field_1352;
                    y += w.force.field_1351;
                    z += w.force.field_1350;
                    t += w.torque;
                }

                return new Wrench(new class_243(x, y, z), t);
            }
        }

        public Wrench scale(double f) {
            return new Wrench(force.method_1021(f), torque * f);
        }
    }
}