package com.blackgear.vanillabackport.common.api.experiment.minecart_behavior;

import com.blackgear.vanillabackport.common.api.modules.leash_behavior.InterpolationHandler;
import com.blackgear.vanillabackport.core.mixin.common.access.AbstractMinecartAccessor;
import net.minecraft.class_1313;
import net.minecraft.class_1688;
import net.minecraft.class_1937;
import net.minecraft.class_2241;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2442;
import net.minecraft.class_2680;
import net.minecraft.class_2768;
import net.minecraft.class_3218;
import net.minecraft.class_3481;
import net.minecraft.class_3532;

public abstract class MinecartBehavior {
    protected final class_1688 minecart;
    private boolean flipped;
    
    protected MinecartBehavior(final class_1688 minecart) {
        this.minecart = minecart;
    }
    
    public InterpolationHandler getInterpolation() {
        return null;
    }
    
    public void lerpMotion(final class_243 movement) {
        this.setDeltaMovement(movement);
    }
    
    public abstract void tick();
    
    public class_1937 level() {
        return this.minecart.method_37908();
    }
    
    public abstract void moveAlongTrack(class_3218 level);
    
    public abstract double stepAlongTrack(final class_2338 pos, final class_2768 shape, final double movementLeft);
    
    public abstract boolean pushAndPickupEntities();
    
    public class_243 getDeltaMovement() {
        return this.minecart.method_18798();
    }
    
    public void setDeltaMovement(final class_243 deltaMovement) {
        this.minecart.method_18799(deltaMovement);
    }
    
    public void setDeltaMovement(final double x, final double y, final double z) {
        this.minecart.method_18800(x, y, z);
    }
    
    public class_243 position() {
        return this.minecart.method_19538();
    }
    
    public double getX() {
        return this.minecart.method_23317();
    }
    
    public double getY() {
        return this.minecart.method_23318();
    }
    
    public double getZ() {
        return this.minecart.method_23321();
    }
    
    public void setPos(final class_243 pos) {
        this.minecart.method_33574(pos);
    }
    
    public void setPos(final double x, final double y, final double z) {
        this.minecart.method_5814(x, y, z);
    }
    
    public float getXRot() {
        return this.minecart.method_36455();
    }
    
    public void setXRot(final float rot) {
        this.minecart.method_36457(rot);
    }
    
    public float getYRot() {
        return this.minecart.method_36454();
    }
    
    public void setYRot(final float rot) {
        this.minecart.method_36456(rot);
    }
    
    public class_2350 getMotionDirection() {
        return this.minecart.method_5735();
    }
    
    public class_243 getKnownMovement(final class_243 knownMovement) {
        return knownMovement;
    }
    
    public abstract double getMaxSpeed(class_3218 level);
    
    public abstract double getSlowdownFactor();
    
    // HELPER METHODS
    
    public boolean isFlipped() {
        return this.flipped;
    }
    
    public void setFlipped(final boolean flipped) {
        this.flipped = flipped;
    }
    
    public class_243 getRedstoneDirection(class_2338 pos) {
        class_2680 state = this.minecart.method_37908().method_8320(pos);
        if (state.method_27852(class_2246.field_10425) && state.method_11654(class_2442.field_11364)) {
            class_2768 shape = state.method_11654(((class_2241) state.method_26204()).method_9474());
            if (shape == class_2768.field_12674) {
                if (((AbstractMinecartAccessor) this.minecart).callIsRedstoneConductor(pos.method_10067())) {
                    return new class_243(1.0, 0.0, 0.0);
                }
                
                if (((AbstractMinecartAccessor) this.minecart).callIsRedstoneConductor(pos.method_10078())) {
                    return new class_243(-1.0, 0.0, 0.0);
                }
            } else if (shape == class_2768.field_12665) {
                if (((AbstractMinecartAccessor) this.minecart).callIsRedstoneConductor(pos.method_10095())) {
                    return new class_243(0.0, 0.0, 1.0);
                }
                
                if (((AbstractMinecartAccessor) this.minecart).callIsRedstoneConductor(pos.method_10072())) {
                    return new class_243(0.0, 0.0, -1.0);
                }
            }
        }
        
        return class_243.field_1353;
    }
    
    protected class_243 applyNaturalSlowdown(class_243 movement) {
        double slowdownFactor = this.getSlowdownFactor();
        class_243 newMovement = movement.method_18805(slowdownFactor, 0.0F, slowdownFactor);
        if (this.minecart.method_5799()) {
            newMovement = newMovement.method_1021(0.95F);
        }
        
        return newMovement;
    }
    
    public class_2338 getCurrentBlockPosOrRailBelow() {
        int xt = class_3532.method_15357(this.getX());
        int yt = class_3532.method_15357(this.getY());
        int zt = class_3532.method_15357(this.getZ());
        if (useExperimentalMovement(this.level())) {
            double y = this.getY() - 0.1 - class_3532.field_29849;
            if (this.level().method_8320(class_2338.method_49637(xt, y, zt)).method_26164(class_3481.field_15463)) {
                yt = class_3532.method_15357(y);
            }
        } else if (this.level().method_8320(new class_2338(xt, yt - 1, zt)).method_26164(class_3481.field_15463)) {
            yt--;
        }
        
        return new class_2338(xt, yt, zt);
    }
    
    protected void comeOffTrack(class_3218 level) {
        double maxSpeed = this.getMaxSpeed(level);
        class_243 movement = this.getDeltaMovement();
        this.setDeltaMovement(class_3532.method_15350(movement.field_1352, -maxSpeed, maxSpeed), movement.field_1351, class_3532.method_15350(movement.field_1350, -maxSpeed, maxSpeed));
        if (this.minecart.method_24828()) {
            this.setDeltaMovement(this.getDeltaMovement().method_1021(0.5));
        }
        
        this.minecart.method_5784(class_1313.field_6308, this.getDeltaMovement());
        if (!this.minecart.method_24828()) {
            this.setDeltaMovement(this.getDeltaMovement().method_1021(0.95F));
        }
    }
    
    public static boolean useExperimentalMovement(final class_1937 level) {
//        return level.enabledFeatures().contains(FeatureFlags.MINECART_IMPROVEMENTS);
        return true;
    }
}