package com.blackgear.vanillabackport.common.api.extensions.block;

import java.util.List;
import java.util.Optional;
import net.minecraft.class_1937;
import net.minecraft.class_2256;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_4538;

public interface SpreadableBonemealableBlock extends class_2256 {
    static boolean hasSpreadableNeighbourPos(class_4538 level, class_2338 pos, class_2680 state) {
        return getSpreadableNeighbourPos(class_2350.class_2353.field_11062.method_29716().toList(), level, pos, state).isPresent();
    }

    static Optional<class_2338> findSpreadableNeighbourPos(class_1937 level, class_2338 pos, class_2680 state) {
        return getSpreadableNeighbourPos(class_2350.class_2353.field_11062.method_43342(level.field_9229), level, pos, state);
    }

    private static Optional<class_2338> getSpreadableNeighbourPos(List<class_2350> directions, class_4538 level, class_2338 pos, class_2680 state) {
        for (class_2350 direction : directions) {
            class_2338 offset = pos.method_10093(direction);
            if (level.method_22347(offset) && state.method_26184(level, offset)) {
                return Optional.of(offset);
            }
        }

        return Optional.empty();
    }
}