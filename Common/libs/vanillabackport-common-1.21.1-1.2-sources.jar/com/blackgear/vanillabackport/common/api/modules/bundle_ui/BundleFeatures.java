package com.blackgear.vanillabackport.common.api.modules.bundle_ui;

import com.blackgear.vanillabackport.client.registries.ModSoundEvents;
import com.blackgear.vanillabackport.common.registries.items.ModItems;
import com.blackgear.vanillabackport.core.VanillaBackport;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_3417;
import net.minecraft.class_9276;
import net.minecraft.class_9334;
import net.minecraft.world.item.*;
import java.util.EnumMap;
import java.util.Map;
import java.util.Optional;

public class BundleFeatures {
    public static final Map<class_1767, class_1792> BUNDLES_BY_DYE = new EnumMap<>(class_1767.class);

    static {
        register(class_1767.field_7952, ModItems.WHITE_BUNDLE.get());
        register(class_1767.field_7946, ModItems.ORANGE_BUNDLE.get());
        register(class_1767.field_7958, ModItems.MAGENTA_BUNDLE.get());
        register(class_1767.field_7951, ModItems.LIGHT_BLUE_BUNDLE.get());
        register(class_1767.field_7947, ModItems.YELLOW_BUNDLE.get());
        register(class_1767.field_7961, ModItems.LIME_BUNDLE.get());
        register(class_1767.field_7954, ModItems.PINK_BUNDLE.get());
        register(class_1767.field_7944, ModItems.GRAY_BUNDLE.get());
        register(class_1767.field_7967, ModItems.LIGHT_GRAY_BUNDLE.get());
        register(class_1767.field_7955, ModItems.CYAN_BUNDLE.get());
        register(class_1767.field_7945, ModItems.PURPLE_BUNDLE.get());
        register(class_1767.field_7966, ModItems.BLUE_BUNDLE.get());
        register(class_1767.field_7957, ModItems.BROWN_BUNDLE.get());
        register(class_1767.field_7942, ModItems.GREEN_BUNDLE.get());
        register(class_1767.field_7964, ModItems.RED_BUNDLE.get());
        register(class_1767.field_7963, ModItems.BLACK_BUNDLE.get());
    }

    public static void register(class_1767 dyeColor, class_1792 item) {
        BUNDLES_BY_DYE.put(dyeColor, item);
    }

    public static boolean onBundleUpdate() {
        return VanillaBackport.COMMON_CONFIG.hasModernBundles.get();
    }

    public static boolean canItemBeInBundle(class_1799 stack) {
        return !stack.method_7960() && stack.method_7909().method_31568();
    }

    public static void toggleSelectedItem(class_1799 stack, int index) {
        class_9276 contents = stack.method_57824(class_9334.field_49650);
        if (contents != null) {
            class_9276.class_9277 mutable = new class_9276.class_9277(contents);
            ((ModernBundle.Mutable) mutable).toggleSelectedItem(index);
            stack.method_57379(class_9334.field_49650, mutable.method_57435());
        }
    }

    public static int getSelectedItem(class_1799 stack) {
        class_9276 contents = stack.method_57825(class_9334.field_49650, class_9276.field_49289);
        return ((ModernBundle) (Object) contents).getSelectedItem();
    }

    public static class_1799 getSelectedItemStack(class_1799 stack) {
        class_9276 contents = stack.method_57824(class_9334.field_49650);
        if (contents == null) return class_1799.field_8037;
        
        ModernBundle bundle = (ModernBundle) (Object) contents;
        int selectedIndex = bundle.getSelectedItem();
        
        return selectedIndex != -1 ? contents.method_57422(selectedIndex) : class_1799.field_8037;
    }

    public static int getNumberOfItemsToShow(class_1799 stack) {
        class_9276 contents = stack.method_57825(class_9334.field_49650, class_9276.field_49289);
        return ((ModernBundle) (Object) contents).getNumberOfItemsToShow();
    }

    public static Optional<class_1799> removeOneItemFromBundle(class_1799 stack, class_1657 player, class_9276 contents) {
        class_9276.class_9277 mutable = new class_9276.class_9277(contents);
        class_1799 itemStack = mutable.method_57430();
        
        if (itemStack == null) return Optional.empty();

        playRemoveOneSound(player);
        stack.method_57379(class_9334.field_49650, mutable.method_57435());
        return Optional.of(itemStack);
    }

    public static class_1792 getByColor(class_1767 dyeColor) {
        return BUNDLES_BY_DYE.getOrDefault(dyeColor, class_1802.field_27023);
    }

    public static void playRemoveOneSound(class_1297 entity) {
        entity.method_5783(class_3417.field_34377, 0.8F, 0.8F + entity.method_37908().method_8409().method_43057() * 0.4F);
    }

    public static void playInsertFailSound(class_1297 entity) {
        entity.method_5783(ModSoundEvents.BUNDLE_INSERT_FAIL.get(), 1.0F, 1.0F);
    }
}