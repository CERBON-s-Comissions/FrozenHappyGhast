package com.blackgear.vanillabackport.common.api.modules.mob_variant;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_2960;

public class ClientAsset {
    public static final Codec<ClientAsset> CODEC = class_2960.field_25139.xmap(ClientAsset::new, ClientAsset::id);
    public static final MapCodec<ClientAsset> DEFAULT_FIELD_CODEC = CODEC.fieldOf("asset_id");
    private final class_2960 id;
    private final class_2960 path;
    
    public ClientAsset(class_2960 id, class_2960 path) {
        this.id = id;
        this.path = path;
    }
    
    public class_2960 id() {
        return id;
    }
    
    public class_2960 path() {
        return path;
    }
    
    public ClientAsset(class_2960 path) {
        this(path, path.method_45134(string -> "textures/" + string + ".png"));
    }
}