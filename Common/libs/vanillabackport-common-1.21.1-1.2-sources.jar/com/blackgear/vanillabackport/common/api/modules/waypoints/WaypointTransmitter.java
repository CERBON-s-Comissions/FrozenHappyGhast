package com.blackgear.vanillabackport.common.api.modules.waypoints;

import com.blackgear.platform.core.networking.PayloadDistributor;
import com.blackgear.vanillabackport.common.registries.entities.ModAttributes;
import com.blackgear.vanillabackport.core.network.ClientboundTrackedWaypointPacket;
import com.blackgear.vanillabackport.core.util.Utilities.VectorUtils;
import java.util.Optional;
import net.minecraft.class_1309;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_3532;

public interface WaypointTransmitter extends Waypoint {
    WaypointTransmitter DEFAULT = new WaypointTransmitter() {
        @Override public boolean isTransmittingWaypoint() { return false; }
        @Override public Optional<Connection> makeWaypointConnectionWith(class_3222 player) { return Optional.empty(); }
        @Override public Icon waypointIcon() { return Icon.NULL; }
    };
    
    static WaypointTransmitter of(Object o) {
        return o instanceof WaypointTransmitter transmitter ? transmitter : DEFAULT;
    }
    
    boolean isTransmittingWaypoint();
    
    Optional<Connection> makeWaypointConnectionWith(class_3222 player);
    
    Icon waypointIcon();
    
    static boolean doesSourceIgnoreReceiver(class_1309 source, class_3222 receiver) {
        if (receiver.method_7325()) {
            return false;
        } else if (!source.method_7325() && !source.method_5821(receiver)) {
            double broadcastRange = Math.min(source.method_45325(ModAttributes.WAYPOINT_TRANSMIT_RANGE), receiver.method_45325(ModAttributes.WAYPOINT_RECEIVE_RANGE));
            return source.method_5739(receiver) >= broadcastRange;
        } else {
            return true;
        }
    }
    
    static boolean isChunkVisible(class_1923 pos, class_3222 receiver) {
        return receiver.method_52372().method_52364(pos.field_9181, pos.field_9180);
    }
    
    static boolean isReallyFar(class_1309 source, class_3222 receiver) {
        return source.method_5739(receiver) > 332.0F;
    }
    
    interface BlockConnection extends Connection {
        int distanceManhattan();
        
        @Override
        default boolean isBroken() {
            return this.distanceManhattan() > 1;
        }
    }
    
    interface ChunkConnection extends Connection {
        int distanceChessboard();
        
        @Override
        default boolean isBroken() {
            return this.distanceChessboard() > 1;
        }
    }
    
    interface Connection {
        void connect();
        
        void disconnect();
        
        void update();
        
        boolean isBroken();
    }
    
    class EntityAzimuthConnection implements Connection {
        private final class_1309 source;
        private final Icon icon;
        private final class_3222 receiver;
        private float lastAngle;
        
        public EntityAzimuthConnection(class_1309 source, Icon icon, class_3222 receiver) {
            this.source = source;
            this.icon = icon;
            this.receiver = receiver;
            class_243 direction = VectorUtils.rotateClockwise90(receiver.method_19538().method_1020(source.method_19538()));
            this.lastAngle = (float) class_3532.method_15349(direction.method_10215(), direction.method_10216());
        }
        
        @Override
        public boolean isBroken() {
            return WaypointTransmitter.doesSourceIgnoreReceiver(this.source, this.receiver)
                || WaypointTransmitter.isChunkVisible(this.source.method_31476(), this.receiver)
                || !WaypointTransmitter.isReallyFar(this.source, this.receiver);
        }
        
        @Override
        public void connect() {
            PayloadDistributor.sendToPlayer(this.receiver, ClientboundTrackedWaypointPacket.addWaypointAzimuth(this.source.method_5667(), this.icon, this.lastAngle));
        }
        
        @Override
        public void disconnect() {
            PayloadDistributor.sendToPlayer(this.receiver, ClientboundTrackedWaypointPacket.removeWaypoint(this.source.method_5667()));
        }
        
        @Override
        public void update() {
            class_243 direction = VectorUtils.rotateClockwise90(this.receiver.method_19538().method_1020(this.source.method_19538()));
            float currentAngle = (float) class_3532.method_15349(direction.method_10215(), direction.method_10216());
            if (class_3532.method_15379(currentAngle - this.lastAngle) > 0.008726646F) {
                PayloadDistributor.sendToPlayer(this.receiver, ClientboundTrackedWaypointPacket.updateWaypointAzimuth(this.source.method_5667(), this.icon, currentAngle));
                this.lastAngle = currentAngle;
            }
        }
    }
    
    class EntityBlockConnection implements BlockConnection {
        private final class_1309 source;
        private final Icon icon;
        private final class_3222 receiver;
        private class_2338 lastPosition;
        
        public EntityBlockConnection(class_1309 source, Icon icon, class_3222 receiver) {
            this.source = source;
            this.icon = icon;
            this.receiver = receiver;
            this.lastPosition = source.method_24515();
        }
        
        @Override
        public void connect() {
            PayloadDistributor.sendToPlayer(this.receiver, ClientboundTrackedWaypointPacket.addWaypointPosition(this.source.method_5667(), this.icon, this.lastPosition));
        }
        
        @Override
        public void disconnect() {
            PayloadDistributor.sendToPlayer(this.receiver, ClientboundTrackedWaypointPacket.removeWaypoint(this.source.method_5667()));
        }
        
        @Override
        public void update() {
            class_2338 currentPosition = this.source.method_24515();
            if (currentPosition.method_19455(this.lastPosition) > 0) {
                PayloadDistributor.sendToPlayer(this.receiver, ClientboundTrackedWaypointPacket.updateWaypointPosition(this.source.method_5667(), this.icon, currentPosition));
                this.lastPosition = currentPosition;
            }
        }
        
        @Override
        public int distanceManhattan() {
            return this.lastPosition.method_19455(this.source.method_24515());
        }
        
        @Override
        public boolean isBroken() {
            return BlockConnection.super.isBroken()
                || WaypointTransmitter.doesSourceIgnoreReceiver(this.source, this.receiver);
        }
    }
    
    class EntityChunkConnection implements ChunkConnection {
        private final class_1309 source;
        private final Icon icon;
        private final class_3222 receiver;
        private class_1923 lastPosition;
        
        public EntityChunkConnection(class_1309 source, Icon icon, class_3222 receiver) {
            this.source = source;
            this.icon = icon;
            this.receiver = receiver;
            this.lastPosition = source.method_31476();
        }
        
        @Override
        public int distanceChessboard() {
            return this.lastPosition.method_24022(this.source.method_31476());
        }
        
        @Override
        public void connect() {
            PayloadDistributor.sendToPlayer(this.receiver, ClientboundTrackedWaypointPacket.addWaypointChunk(this.source.method_5667(), this.icon, this.lastPosition));
        }
        
        @Override
        public void disconnect() {
            PayloadDistributor.sendToPlayer(this.receiver, ClientboundTrackedWaypointPacket.removeWaypoint(this.source.method_5667()));
        }
        
        @Override
        public void update() {
            class_1923 currentPosition = this.source.method_31476();
            if (currentPosition.method_24022(this.lastPosition) > 0) {
                PayloadDistributor.sendToPlayer(this.receiver, ClientboundTrackedWaypointPacket.updateWaypointChunk(this.source.method_5667(), this.icon, currentPosition));
                this.lastPosition = currentPosition;
            }
        }
        
        @Override
        public boolean isBroken() {
            return ChunkConnection.super.isBroken()
                || WaypointTransmitter.doesSourceIgnoreReceiver(this.source, this.receiver)
                || WaypointTransmitter.isChunkVisible(this.lastPosition, this.receiver);
        }
    }
}