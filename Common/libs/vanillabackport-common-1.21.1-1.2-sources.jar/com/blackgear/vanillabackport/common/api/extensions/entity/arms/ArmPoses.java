package com.blackgear.vanillabackport.common.api.extensions.entity.arms;

import com.blackgear.vanillabackport.common.level.items.spear.SpearAnimations;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_572;

public enum ArmPoses {
    SPEAR(false, true) {
        @Override
        public <T extends class_1309> void animateUseItem(class_572<T> model, T entity, class_4587 pose, float ticksUsingItem, class_1306 arm, class_1799 actualItem) {
            SpearAnimations.thirdPersonUseItem(model, entity, pose, ticksUsingItem, arm, actualItem);
        }
    };

    private final boolean twoHanded;
    private final boolean affectsOffhandPose;

    ArmPoses(boolean twoHanded, boolean affectsOffhandPose) {
        this.twoHanded = twoHanded;
        this.affectsOffhandPose = affectsOffhandPose;
    }

    public boolean isTwoHanded() {
        return this.twoHanded;
    }

    public boolean affectsOffhandPose() {
        return this.affectsOffhandPose;
    }

    public <T extends class_1309> void animateUseItem(
        class_572<T> model,
        T entity,
        class_4587 pose,
        float ticksUsingItem,
        class_1306 arm,
        class_1799 actualItem
    ) {}

    public class_572.class_573 get() {
        return class_572.class_573.valueOf(this.name());
    }
}