package com.blackgear.vanillabackport.common.api.extensions.access.entity;

import net.minecraft.class_1266;
import net.minecraft.class_1315;
import net.minecraft.class_3730;
import net.minecraft.class_5425;
import org.jetbrains.annotations.Nullable;

public interface MobBehaviorAccess {
    default class_1315 vb$finalizeSpawn(class_5425 level, class_1266 difficultyInstance, class_3730 reason, @Nullable class_1315 data) {
        return data;
    }
}