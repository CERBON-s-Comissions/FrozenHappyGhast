package com.blackgear.vanillabackport.common.api.modules.leash_behavior;

import com.blackgear.vanillabackport.core.mixin.client.access.EntityRendererAccessor;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1921;
import net.minecraft.class_1944;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4604;
import net.minecraft.class_765;
import net.minecraft.class_898;
import net.minecraft.class_9817;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;

@Environment(EnvType.CLIENT)
public class LeashFeatureRenderer<T extends class_1297> {
    private static final int LEASH_RENDER_STEPS = 24;
    private static final float LEASH_WIDTH = 0.05F;

    private final class_898 dispatcher;
    @Nullable private List<LeashState> leashStates;

    public LeashFeatureRenderer(class_898 dispatcher) {
        this.dispatcher = dispatcher;
    }

    public boolean shouldRender(T entity, class_4604 camera, boolean isVisible, boolean fallback) {
        if (!isVisible) {
            class_238 boundingBox = entity.method_5830().method_1014(0.5);
            if (boundingBox.method_1013() || boundingBox.method_995() == 0.0) {
                boundingBox = new class_238(entity.method_23317() - 2.0, entity.method_23318() - 2.0, entity.method_23321() - 2.0, entity.method_23317() + 2.0, entity.method_23318() + 2.0, entity.method_23321() + 2.0);
            }

            if (camera.method_23093(boundingBox)) {
                return true;
            } else if (entity instanceof class_9817 leashable) {
                class_1297 leashHolder = leashable.method_60952();
                if (leashHolder != null) {
                    class_238 leasherBox = leashHolder.method_5830();
                    return camera.method_23093(leasherBox) || camera.method_23093(boundingBox.method_991(leasherBox));
                }
            }
        }

        return fallback;
    }

    public boolean shouldRender(T entity, class_4604 camera, boolean isVisible) {
        return this.shouldRender(entity, camera, isVisible, isVisible);
    }

    public void render(T entity, float partialTick, class_4587 poseStack, class_4597 buffer) {
        this.setupLeashRendering(entity, partialTick);

        if (this.leashStates != null) {
            for (LeashState leashState : this.leashStates) {
                this.renderLeash(poseStack, buffer, leashState);
            }
        }
    }

    private void renderLeash(class_4587 stack, class_4597 buffer, LeashState state) {
        float dx = (float) (state.end.field_1352 - state.start.field_1352);
        float dy = (float) (state.end.field_1351 - state.start.field_1351);
        float dz = (float) (state.end.field_1350 - state.start.field_1350);
        float offsetFactor = class_3532.method_48119(dx * dx + dz * dz) * LEASH_WIDTH / 2.0F;
        float dxOff = dz * offsetFactor;
        float dzOff = dx * offsetFactor;
        stack.method_22903();
        
        Vector3f scale = new Vector3f();
        stack.method_23760().method_23761().getScale(scale);
        if (scale.x() > 0.001F && scale.y() > 0.001F && scale.z() > 0.001F) {
            stack.method_22905(1.0F / scale.x(), 1.0F / scale.y(), 1.0F / scale.z());
        }
        
        stack.method_22904(state.offset.field_1352, state.offset.field_1351, state.offset.field_1350);
        class_4588 builder = buffer.getBuffer(class_1921.method_23587());
        Matrix4f matrices = stack.method_23760().method_23761();

        for (int segment = 0; segment <= LEASH_RENDER_STEPS; segment++) {
            addVertexPair(builder, matrices, dx, dy, dz, LEASH_WIDTH, dxOff, dzOff, segment, false, state);
        }

        for (int segment = LEASH_RENDER_STEPS; segment >= 0; segment--) {
            addVertexPair(builder, matrices, dx, dy, dz, LEASH_WIDTH, dxOff, dzOff, segment, true, state);
        }

        stack.method_22909();
    }

    private static void addVertexPair(
        class_4588 builder,
        Matrix4f pose,
        float dx, float dy, float dz,
        float fudge,
        float dxOff, float dzOff,
        int segment,
        boolean backwards,
        LeashState state
    ) {
        float progress = segment / 24.0f;
        int block = (int) class_3532.method_16439(progress, state.startBlockLight, state.endBlockLight);
        int sky = (int) class_3532.method_16439(progress, state.startSkyLight, state.endSkyLight);
        int lightCoords = class_765.method_23687(block, sky);
        float colorModifier = segment % 2 == (backwards ? 1 : 0) ? 0.7F : 1.0F;
        float r = 0.5F * colorModifier;
        float g = 0.4F * colorModifier;
        float b = 0.3F * colorModifier;

        float y = dy * progress;
        if (state.slack) {
            y = dy > 0.0F ? dy * progress * progress : dy - dy * (1.0F - progress) * (1.0F - progress);
        }

        float x = dx * progress;
        float z = dz * progress;
        builder.method_22918(pose, x - dxOff, y + fudge, z + dzOff).method_22915(r, g, b, 1.0f).method_60803(lightCoords);
        builder.method_22918(pose, x + dxOff, y + 0.05F - fudge, z - dzOff).method_22915(r, g, b, 1.0f).method_60803(lightCoords);
    }

    private void setupLeashRendering(T entity, float partialTicks) {
        if (entity instanceof class_9817 leashable && leashable.method_60952() != null) {
            class_1297 roper = leashable.method_60952();
            float entityYRot = entity.method_60951(partialTicks) * class_3532.field_29847;
            class_2338 entityEyePos = class_2338.method_49638(entity.method_5836(partialTicks));
            class_2338 roperEyePos = class_2338.method_49638(roper.method_5836(partialTicks));
            int startBlockLight = this.getBlockLightLevel(entity, entityEyePos);
            int endBlockLight = this.getBlockLightLevel(roper, roperEyePos);
            int startSkyLight = entity.method_37908().method_8314(class_1944.field_9284, entityEyePos);
            int endSkyLight = entity.method_37908().method_8314(class_1944.field_9284, roperEyePos);
            boolean quadConnection = ((LeashableCallback) roper).vb$supportsQuadLeashAsHolder() && ((LeashableCallback) entity).vb$supportsQuadLeash();
            int leashCount = quadConnection ? 4 : 1;

            if (this.leashStates == null || this.leashStates.size() != leashCount) {
                this.leashStates = new ArrayList<>(leashCount);
                for (int i = 0; i < leashCount; i++) this.leashStates.add(new LeashState());
            }

            if (quadConnection) {
                float roperYRot = roper.method_60951(partialTicks) * class_3532.field_29847;
                class_243 holderPos = roper.method_30950(partialTicks);
                class_243[] leashableAttachmentPoints = ((LeashableCallback) entity).vb$getQuadLeashOffsets();
                class_243[] roperAttachmentPoints = ((LeashableCallback) roper).vb$getQuadLeashHolderOffsets();

                for (int i = 0; i < leashCount; i++) {
                    LeashState leashState = this.leashStates.get(i);
                    leashState.offset = leashableAttachmentPoints[i].method_1024(-entityYRot);
                    leashState.start = entity.method_30950(partialTicks).method_1019(leashState.offset);
                    leashState.end = holderPos.method_1019(roperAttachmentPoints[i].method_1024(-roperYRot));
                    leashState.startBlockLight = startBlockLight;
                    leashState.endBlockLight = endBlockLight;
                    leashState.startSkyLight = startSkyLight;
                    leashState.endSkyLight = endSkyLight;
                    leashState.slack = false;
                }
            } else {
                class_243 rotatedAttachOffset = entity.method_45321(partialTicks).method_1024(-entityYRot);
                LeashState leashState = this.leashStates.getFirst();
                leashState.offset = rotatedAttachOffset;
                leashState.start = entity.method_30950(partialTicks).method_1019(rotatedAttachOffset);
                leashState.end = roper.method_30951(partialTicks);
                leashState.startBlockLight = startBlockLight;
                leashState.endBlockLight = endBlockLight;
                leashState.startSkyLight = startSkyLight;
                leashState.endSkyLight = endSkyLight;
            }
        } else {
            this.leashStates = null;
        }
    }

    private int getBlockLightLevel(class_1297 entity, class_2338 pos) {
        return ((EntityRendererAccessor) this.dispatcher.method_3953(entity)).callGetBlockLightLevel(entity, pos);
    }
}