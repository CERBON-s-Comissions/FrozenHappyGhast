package com.blackgear.vanillabackport.common.api.modules.mob_variant;

import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_5819;
import net.minecraft.class_7988;

@SuppressWarnings("unchecked")
public interface VariantDataHolder<T> {
    static <T> Optional<VariantDataHolder<T>> getHolder(class_1297 entity) {
        return entity instanceof VariantDataHolder<?> ? Optional.of((VariantDataHolder<T>) entity) : Optional.empty();
    }
    
    void setVariantData(T variant);
    
    Optional<T> getVariantData();
    
    static <T, V> void trySetOffspringVariant(class_1309 child, class_1309 father, class_1309 mother) {
        Optional<T> fatherData = VariantDataHolder.<T>getHolder(father).flatMap(VariantDataHolder::getVariantData);
        Optional<T> motherData = VariantDataHolder.<T>getHolder(mother).flatMap(VariantDataHolder::getVariantData);
        
        class_5819 random = child.method_59922();
        Optional<T> heritableData;
        if (fatherData.isPresent() && motherData.isPresent()) {
            heritableData = random.method_43056() ? fatherData : motherData;
        } else if (fatherData.isPresent()) {
            heritableData = random.method_43056() ? fatherData : Optional.empty();
        } else if (motherData.isPresent()) {
            heritableData = random.method_43056() ? motherData : Optional.empty();
        } else {
            heritableData = Optional.empty();
        }
        
        if (heritableData.isPresent()) {
            VariantDataHolder.<T>getHolder(child).ifPresent(h -> h.setVariantData(heritableData.get()));
            return;
        }
        
        if (father instanceof class_7988<?> && mother instanceof class_7988<?>) {
            V variant = random.method_43056() ? ((class_7988<V>) father).method_47827() : ((class_7988<V>) mother).method_47827();
            if (child instanceof class_7988<?>) ((class_7988<V>) child).method_47826(variant);
        }
    }
}