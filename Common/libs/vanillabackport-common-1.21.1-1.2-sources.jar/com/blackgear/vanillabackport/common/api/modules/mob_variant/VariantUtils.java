package com.blackgear.vanillabackport.common.api.modules.mob_variant;

import com.blackgear.platform.common.data.entity.SyncedDataHolder;
import com.blackgear.platform.common.data.entity.SyncedDataKey;
import com.blackgear.platform.core.BuiltInCoreRegistry;
import com.blackgear.platform.core.api.RegistryKey;
import com.blackgear.vanillabackport.common.api.modules.mob_variant.spawn.PriorityProvider;
import com.blackgear.vanillabackport.common.api.modules.mob_variant.spawn.SpawnContext;
import com.blackgear.vanillabackport.common.api.modules.sound_variant.SoundVariantHolder;
import com.blackgear.vanillabackport.core.VanillaBackport;
import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_5425;
import net.minecraft.class_5819;

public class VariantUtils {
    public static final String VARIANT_KEY = "variant";
    public static final String SOUND_VARIANT_KEY = "sound_variant";
    
    public static <T> void setVariant(class_1297 holder, T variant, BuiltInCoreRegistry<T> registry, SyncedDataKey<RegistryKey<T>> key) {
       SyncedDataHolder.get(holder).set(key, registry.getRegistryKey(variant));
    }
    
    public static <T> T getVariant(class_1297 holder, BuiltInCoreRegistry<T> registry, SyncedDataKey<RegistryKey<T>> key) {
        return registry.get(SyncedDataHolder.get(holder).get(key));
    }
    
    public static <T> Optional<T> getOrDefault(BuiltInCoreRegistry<T> registry, class_2960 id) {
        return Optional.ofNullable(registry.get(id));
    }
    
    public static <T> Optional<T> getOrDefault(BuiltInCoreRegistry<T> registry, String id) {
        class_2960 location = class_2960.method_12829(id);
        return location == null ? Optional.empty() : getOrDefault(registry, location);
    }

    public static <T> T getDefault(BuiltInCoreRegistry<T> registry, RegistryKey<T> key) {
        return registry.getOrThrow(key);
    }

    public static <T> T getVariant(BuiltInCoreRegistry<T> registry, String id) {
        return registry.get(class_2960.method_12829(id));
    }
    
    public static <T> class_2960 getKey(BuiltInCoreRegistry<T> registry, T value) {
        return registry.getKey(value);
    }
    
    public static <T> String getID(BuiltInCoreRegistry<T> registry, T value) {
        return registry.getKey(value).toString();
    }

    public static <T> String getDefaultID(BuiltInCoreRegistry<T> registry, RegistryKey<T> value) {
        return getID(registry, getDefault(registry, value));
    }

    public static <T> boolean matches(BuiltInCoreRegistry<T> registry, T variant, RegistryKey<T> value) {
        return variant == registry.get(value);
    }

    public static <T> void addVariantSaveData(VariantDataHolder<T> entity, class_2487 tag, BuiltInCoreRegistry<T> registry) {
        entity.getVariantData().ifPresent(variant -> {
            class_2960 key = registry.getKey(variant);
            if (key != null) tag.method_10582(VARIANT_KEY, key.toString());
        });
    }

    public static <T> void addSoundVariantSaveData(SoundVariantHolder<T> holder, class_2487 tag, BuiltInCoreRegistry<T> registry) {
        tag.method_10582(SOUND_VARIANT_KEY, registry.getKey(holder.vb$getSoundVariant()).toString());
    }
    
    public static <T> void readVariantSaveData(VariantDataHolder<T> entity, class_2487 tag, BuiltInCoreRegistry<T> registry) {
        if (tag.method_10545(VARIANT_KEY)) {
            T variant = registry.get(class_2960.method_12829(tag.method_10558(VARIANT_KEY)));
            if (variant != null) entity.setVariantData(variant);
        }
    }
    
    public static <T> void readSoundVariantSaveData(SoundVariantHolder<T> holder, class_2487 tag, BuiltInCoreRegistry<T> registry) {
        if (tag.method_10545(SOUND_VARIANT_KEY)) {
            T variant = registry.get(class_2960.method_12829(tag.method_10558(SOUND_VARIANT_KEY)));
            if (variant != null) holder.vb$setSoundVariant(variant);
        }
    }

    public static <T extends PriorityProvider<SpawnContext, ?>> Optional<T> selectVariantToSpawn(SpawnContext context, BuiltInCoreRegistry<T> registry, VariantSpawner spawner) {
        if (!spawner.apply()) return Optional.empty();
        
        class_5425 level = context.level();
        class_5819 random = level.method_8409();
        
        if (random.method_43057() >= VanillaBackport.COMMON_CONFIG.mobVariantSpawnChance.get()) {
            return Optional.empty();
        }
        
        return PriorityProvider.pick(registry.values().stream(), entry -> entry, random, context);
    }

    public static <T extends PriorityProvider<SpawnContext, ?>> Optional<T> selectVariantToSpawn(SpawnContext context, BuiltInCoreRegistry<T> registry) {
        return selectVariantToSpawn(context, registry, VariantSpawner.DEFAULT);
    }
}