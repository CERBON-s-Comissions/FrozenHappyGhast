package com.blackgear.vanillabackport.common.api.modules.waypoints;

import com.blackgear.vanillabackport.core.VanillaBackport;
import com.blackgear.vanillabackport.core.mixin.common.access.LevelAccessor;
import com.blackgear.vanillabackport.core.util.Utilities.BufferUtils;
import com.blackgear.vanillabackport.core.util.Utilities.VectorUtils;
import com.mojang.datafixers.util.Either;
import io.netty.buffer.ByteBuf;
import org.apache.commons.lang3.function.TriFunction;

import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2540;
import net.minecraft.class_3532;
import net.minecraft.class_4844;
import net.minecraft.class_8703;
import net.minecraft.class_9139;

public abstract class TrackedWaypoint implements Waypoint {
    public static final class_9139<ByteBuf, TrackedWaypoint> STREAM_CODEC = class_9139.method_56438(TrackedWaypoint::write, TrackedWaypoint::read);
    protected final Either<UUID, String> identifier;
    private final Icon icon;
    private final Type type;
    
    protected TrackedWaypoint(Either<UUID, String> identifier, Icon icon, Type type) {
        this.identifier = identifier;
        this.icon = icon;
        this.type = type;
    }
    
    public Either<UUID, String> id() {
        return this.identifier;
    }
    
    public abstract void update(TrackedWaypoint other);
    
    private void write(ByteBuf buf) {
        class_2540 byteBuf = new class_2540(buf);
        BufferUtils.writeEither(byteBuf, this.identifier, class_4844.field_48453, class_2540::method_10814);
        Icon.STREAM_CODEC.encode(byteBuf, this.icon);
        byteBuf.method_10817(this.type);
        this.writeContents(buf);
    }
    
    protected abstract void writeContents(ByteBuf buf);
    
    private static TrackedWaypoint read(ByteBuf buf) {
        class_2540 byteBuf = new class_2540(buf);
        Either<UUID, String> identifier = BufferUtils.readEither(byteBuf, class_4844.field_48453, class_2540::method_19772);
        Icon icon = Icon.STREAM_CODEC.decode(byteBuf);
        Type type = byteBuf.method_10818(Type.class);
        return type.constructor.apply(identifier, icon, byteBuf);
    }
    
    public static TrackedWaypoint setPosition(UUID identifier, Icon icon, class_2382 position) {
        return new Vec3iWaypoint(identifier, icon, position);
    }
    
    public static TrackedWaypoint setChunk(UUID identifier, Icon icon, class_1923 chunk) {
        return new ChunkWaypoint(identifier, icon, chunk);
    }
    
    public static TrackedWaypoint setAzimuth(UUID identifier, Icon icon, float angle) {
        return new AzimuthWaypoint(identifier, icon, angle);
    }
    
    public static TrackedWaypoint empty(UUID identifier) {
        return new EmptyWaypoint(identifier);
    }
    
    public abstract double yawAngleToCamera(class_1937 level, Camera camera);
    
    public abstract PitchDirection pitchDirectionToCamera(class_1937 level, Projector projector);
    
    public abstract double distanceSquared(class_1297 fromEntity);
    
    public Icon icon() {
        return this.icon;
    }
    
    public interface Camera {
        float vb$yaw();
        
        class_243 vb$position();
    }
    
    public enum PitchDirection {
        NONE, UP, DOWN
    }
    
    public interface Projector {
        class_243 vb$projectPointToScreen(class_243 point);
        
        double vb$projectHorizonToScreen();
    }
    
    public enum Type {
        EMPTY(EmptyWaypoint::new),
        VEC3I(Vec3iWaypoint::new),
        CHUNK(ChunkWaypoint::new),
        AZIMUTH(AzimuthWaypoint::new);
        
        private final TriFunction<Either<UUID, String>, Icon, class_2540, TrackedWaypoint> constructor;
        
        Type(TriFunction<Either<UUID, String>, Icon, class_2540, TrackedWaypoint> constructor) {
            this.constructor = constructor;
        }
    }
    
    private static class AzimuthWaypoint extends TrackedWaypoint {
        private float angle;
        
        public AzimuthWaypoint(UUID identifier, Icon icon, float angle) {
            super(Either.left(identifier), icon, Type.AZIMUTH);
            this.angle = angle;
        }
        
        public AzimuthWaypoint(Either<UUID, String> identifier, Icon icon, class_2540 buf) {
            super(identifier, icon, Type.AZIMUTH);
            this.angle = buf.readFloat();
        }
        
        @Override
        public void update(TrackedWaypoint other) {
            if (other instanceof AzimuthWaypoint waypoint) {
                this.angle = waypoint.angle;
            } else {
                VanillaBackport.LOGGER.warn("Unsupported Waypoint update operation: {}", other.getClass());
            }
        }
        
        @Override
        protected void writeContents(ByteBuf buf) {
            buf.writeFloat(this.angle);
        }
        
        @Override
        public double yawAngleToCamera(class_1937 level, Camera camera) {
            return class_3532.method_15381(camera.vb$yaw(), this.angle * class_3532.field_29848);
        }
        
        @Override
        public PitchDirection pitchDirectionToCamera(class_1937 level, Projector projector) {
            double horizon = projector.vb$projectHorizonToScreen();
            if (horizon < -1.0) {
                return PitchDirection.DOWN;
            } else {
                return horizon > 1.0 ? PitchDirection.UP : PitchDirection.NONE;
            }
        }
        
        @Override
        public double distanceSquared(class_1297 fromEntity) {
            return Double.POSITIVE_INFINITY;
        }
    }
    
    private static class ChunkWaypoint extends TrackedWaypoint {
        private class_1923 chunkPos;
        
        public ChunkWaypoint(UUID identifier, Icon icon, class_1923 chunkPos) {
            super(Either.left(identifier), icon, Type.CHUNK);
            this.chunkPos = chunkPos;
        }
        
        public ChunkWaypoint(Either<UUID, String> identifier, Icon icon, class_2540 buf) {
            super(identifier, icon, Type.CHUNK);
            this.chunkPos = new class_1923(buf.method_10816(), buf.method_10816());
        }
        
        @Override
        public void update(TrackedWaypoint other) {
            if (other instanceof ChunkWaypoint waypoint) {
                this.chunkPos = waypoint.chunkPos;
            } else {
                VanillaBackport.LOGGER.warn("Unsupported Waypoint update operation: {}", other.getClass());
            }
        }
        
        @Override
        protected void writeContents(ByteBuf buf) {
            class_8703.method_53017(buf, this.chunkPos.field_9181);
            class_8703.method_53017(buf, this.chunkPos.field_9180);
        }
        
        private class_243 position(double positionY) {
            return class_243.method_24953(this.chunkPos.method_33943((int) positionY));
        }
        
        @Override
        public double yawAngleToCamera(class_1937 level, Camera camera) {
            class_243 cameraPosition = camera.vb$position();
            class_243 direction = VectorUtils.rotateClockwise90(cameraPosition.method_1020(this.position(cameraPosition.method_10214())));
            float waypointAngle = (float) class_3532.method_15349(direction.method_10215(), direction.method_10216()) * class_3532.field_29848;
            return class_3532.method_15381(camera.vb$yaw(), waypointAngle);
        }
        
        @Override
        public PitchDirection pitchDirectionToCamera(class_1937 level, Projector projector) {
            double onScreenHorizon = projector.vb$projectHorizonToScreen();
            if (onScreenHorizon < -1.0) {
                return PitchDirection.DOWN;
            } else {
                return onScreenHorizon > 1.0 ? PitchDirection.UP : PitchDirection.NONE;
            }
        }
        
        @Override
        public double distanceSquared(class_1297 fromEntity) {
            return fromEntity.method_5707(class_243.method_24953(this.chunkPos.method_33943(fromEntity.method_31478())));
        }
    }
    
    private static class EmptyWaypoint extends TrackedWaypoint {
        private EmptyWaypoint(Either<UUID, String> identifier, Icon icon, class_2540 buf) {
            super(identifier, icon, Type.EMPTY);
        }
        
        private EmptyWaypoint(UUID identifier) {
            super(Either.left(identifier), Icon.NULL, Type.EMPTY);
        }
        
        @Override
        public void update(TrackedWaypoint other) {
        }
        
        @Override
        protected void writeContents(ByteBuf buf) {
        }
        
        @Override
        public double yawAngleToCamera(class_1937 level, Camera camera) {
            return Double.NaN;
        }
        
        @Override
        public PitchDirection pitchDirectionToCamera(class_1937 level, Projector projector) {
            return PitchDirection.NONE;
        }
        
        @Override
        public double distanceSquared(class_1297 fromEntity) {
            return Double.POSITIVE_INFINITY;
        }
    }
    
    public static class Vec3iWaypoint extends TrackedWaypoint {
        private class_2382 vector;
        
        public Vec3iWaypoint(UUID identifier, Icon icon, class_2382 vector) {
            super(Either.left(identifier), icon, Type.VEC3I);
            this.vector = vector;
        }
        
        public Vec3iWaypoint(Either<UUID, String> identifier, Icon icon, class_2540 byteBuf) {
            super(identifier, icon, Type.VEC3I);
            this.vector = new class_2382(byteBuf.method_10816(), byteBuf.method_10816(), byteBuf.method_10816());
        }
        
        @Override
        public void update(TrackedWaypoint other) {
            if (other instanceof Vec3iWaypoint waypoint) {
                this.vector = waypoint.vector;
            } else {
                VanillaBackport.LOGGER.warn("Unsupported Waypoint update operation: {}", other.getClass());
            }
        }
        
        @Override
        protected void writeContents(ByteBuf buf) {
            class_8703.method_53017(buf, this.vector.method_10263());
            class_8703.method_53017(buf, this.vector.method_10264());
            class_8703.method_53017(buf, this.vector.method_10260());
        }
        
        private class_243 position(class_1937 level) {
            return this.identifier.left()
                .map(uuid -> ((LevelAccessor) level).callGetEntities().method_31808(uuid))
                .map(entity -> entity.method_24515().method_19455(this.vector) > 3 ? null : entity.method_33571())
                .orElseGet(() -> class_243.method_24953(this.vector));
        }
        
        @Override
        public double yawAngleToCamera(class_1937 level, Camera camera) {
            class_243 direction = VectorUtils.rotateClockwise90(camera.vb$position().method_1020(this.position(level)));
            float waypointAngle = (float) class_3532.method_15349(direction.method_10215(), direction.method_10216()) * class_3532.field_29848;
            return class_3532.method_15381(camera.vb$yaw(), waypointAngle);
        }
        
        @Override
        public PitchDirection pitchDirectionToCamera(class_1937 level, Projector projector) {
            class_243 pointOnScreen = projector.vb$projectPointToScreen(this.position(level));
            boolean isBehindCamera = pointOnScreen.field_1350 > 1.0;
            double yInFrontOfCamera = isBehindCamera ? -pointOnScreen.field_1351 : pointOnScreen.field_1351;
            if (yInFrontOfCamera < -1.0) {
                return PitchDirection.DOWN;
            } else if (yInFrontOfCamera > 1.0) {
                return PitchDirection.UP;
            } else {
                if (isBehindCamera) {
                    if (pointOnScreen.field_1351 > 0.0) {
                        return PitchDirection.UP;
                    }
                    
                    if (pointOnScreen.field_1351 < 0.0) {
                        return PitchDirection.DOWN;
                    }
                }
                
                return PitchDirection.NONE;
            }
        }
        
        @Override
        public double distanceSquared(class_1297 fromEntity) {
            return fromEntity.method_5707(class_243.method_24953(this.vector));
        }
    }
}