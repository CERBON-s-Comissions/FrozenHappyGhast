package com.blackgear.vanillabackport.common.api.extensions.entity.arms;

import net.minecraft.class_2846;

public enum PlayerActions {
    STAB;

    public class_2846.class_2847 get() {
        return class_2846.class_2847.valueOf(this.name());
    }
}