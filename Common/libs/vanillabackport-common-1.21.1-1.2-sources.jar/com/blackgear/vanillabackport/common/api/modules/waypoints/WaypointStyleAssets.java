package com.blackgear.vanillabackport.common.api.modules.waypoints;

import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;

public interface WaypointStyleAssets {
    class_5321<? extends class_2378<WaypointStyleAsset>> ROOT_ID = class_5321.method_29180(class_2960.method_60656("waypoint_style_asset"));
    class_5321<WaypointStyleAsset> DEFAULT = create("default");
    class_5321<WaypointStyleAsset> BOWTIE = create("bowtie");
    
    class_5321<WaypointStyleAsset> LODESTONE = create("lodestone");
    class_5321<WaypointStyleAsset> DEATH = create("death");
    
    class_5321<WaypointStyleAsset> NORTH = create("north");
    class_5321<WaypointStyleAsset> SOUTH = create("south");
    class_5321<WaypointStyleAsset> WEST = create("west");
    class_5321<WaypointStyleAsset> EAST = create("east");
    class_5321<WaypointStyleAsset> CORNER = create("corner");
    
    static class_5321<WaypointStyleAsset> create(String name) {
        return class_5321.method_29179(ROOT_ID, class_2960.method_60656(name));
    }
}