package com.blackgear.vanillabackport.common.api;

import com.blackgear.vanillabackport.core.util.Utilities;
import java.util.*;
import java.util.function.Supplier;
import net.minecraft.class_1304;
import net.minecraft.class_1308;
import net.minecraft.class_1792;

public class SpawnEquipmentRegistry {
    private static final Map<class_1304, Map<Integer, TierConfig>> TIERS = new EnumMap<>(class_1304.class);
    
    public static void register(class_1304 slot, int tier, float chance, Supplier<class_1792> itemSupplier) {
        TIERS.computeIfAbsent(slot, k -> new HashMap<>())
             .computeIfAbsent(tier, k -> new TierConfig(chance, new ArrayList<>()))
             .items().add(itemSupplier);
    }
    
    public static class_1792 tryGetCustomEquipment(class_1308 mob, class_1304 slot, int tier) {
        Map<Integer, TierConfig> tiers = TIERS.get(slot);
        if (tiers == null) return null;
        
        TierConfig config = tiers.get(tier);
        if (config == null || config.items().isEmpty()) return null;
        
        long seed = mob.method_5667().getLeastSignificantBits();
        float hash = Utilities.HashUtils.toFloat(seed);
        
        if (hash < config.chance()) {
            List<Supplier<class_1792>> items = config.items();
            int itemIndex = items.size() == 1 ? 0 : Math.abs((int) Utilities.HashUtils.toLong(seed ^ 0x9E3779B97F4A7C15L)) % items.size();
            return items.get(itemIndex).get();
        }
        
        return null;
    }
    
    public record TierConfig(float chance, List<Supplier<class_1792>> items) {}
}