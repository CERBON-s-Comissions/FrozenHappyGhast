package com.blackgear.vanillabackport.common.api.modules.bundle_ui;

import com.blackgear.vanillabackport.common.registries.ModRecipeSerializers;
import com.blackgear.vanillabackport.core.VanillaBackport;
import net.minecraft.class_1769;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1852;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_7225;
import net.minecraft.class_7710;
import net.minecraft.class_9694;
import net.minecraft.world.item.*;

public class BundleColoring extends class_1852 {
    public BundleColoring(class_7710 category) {
        super(category);
    }

    @Override
    public boolean matches(class_9694 input, class_1937 level) {
        if (!VanillaBackport.COMMON_CONFIG.hasDyeableBundleRecipe.get()) return false;
        
        int bundles = 0;
        int dyes = 0;

        for (int slot = 0; slot < input.method_59983(); slot++) {
            class_1799 stack = input.method_59984(slot);
            if (!stack.method_7960()) {
                if (isBundle(stack.method_7909())) {
                    bundles++;
                } else if (stack.method_7909() instanceof class_1769) {
                    dyes++;
                } else {
                    return false;
                }

                if (dyes > 1 || bundles > 1) {
                    return false;
                }
            }
        }

        return bundles == 1 && dyes == 1;
    }

    @Override
    public class_1799 assemble(class_9694 input, class_7225.class_7874 registries) {
        class_1799 bundle = class_1799.field_8037;
        class_1769 dye = null;

        for (int slot = 0; slot < input.method_59983(); slot++) {
            class_1799 stack = input.method_59984(slot);
            if (!stack.method_7960()) {
                class_1792 item = stack.method_7909();
                if (isBundle(item)) {
                    bundle = stack;
                } else if (item instanceof class_1769 dyeItem) {
                    dye = dyeItem;
                }
            }
        }
        
        if (bundle.method_7960() || dye == null) return class_1799.field_8037;
        
        class_1792 result = BundleFeatures.getByColor(dye.method_7802());
        return bundle.method_56701(result, 1);
    }

    @Override
    public boolean method_8113(int width, int height) {
        return width * height >= 2;
    }

    @Override
    public class_1865<?> method_8119() {
        return ModRecipeSerializers.BUNDLE_COLORING.get();
    }

    private static boolean isBundle(class_1792 item) {
        return item == class_1802.field_27023 || BundleFeatures.BUNDLES_BY_DYE.containsValue(item);
    }
}