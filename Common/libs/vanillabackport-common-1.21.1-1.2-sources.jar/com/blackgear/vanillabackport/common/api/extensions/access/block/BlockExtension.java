package com.blackgear.vanillabackport.common.api.extensions.access.block;

import net.minecraft.class_1676;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3965;
import net.minecraft.class_5819;

public interface BlockExtension {
    BlockExtension DEFAULT = new BlockExtension() {};
    
    static BlockExtension of(Object block) {
        return block instanceof BlockExtension extension ? extension : DEFAULT;
    }
    
    default void vb$animateTick(class_2680 state, class_1937 level, class_2338 pos, class_5819 random) { /* NO-OP */ }
    
    default void vb$randomTick(class_2680 state, class_3218 level, class_2338 pos, class_5819 random) { /* NO-OP */ }
    
    default boolean vb$isRandomlyTicking(class_2680 state) {
        return false;
    }
    
    default void vb$onProjectileHit(class_1937 level, class_2680 state, class_3965 hit, class_1676 projectile) { /* NO-OP */ }
}