package com.blackgear.vanillabackport.common.api.modules.mob_variant.spawn.check;

import com.blackgear.vanillabackport.common.api.modules.mob_variant.spawn.SpawnCondition;
import com.blackgear.vanillabackport.common.api.modules.mob_variant.spawn.SpawnContext;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_3195;
import net.minecraft.class_3449;
import net.minecraft.class_5138;
import net.minecraft.class_6880;
import net.minecraft.class_6885;
import net.minecraft.class_6895;
import net.minecraft.class_7924;
import net.minecraft.core.*;
import java.util.List;
import java.util.function.Predicate;

public record StructureCheck(class_6885<class_3195> requiredStructures) implements SpawnCondition {
    public static final MapCodec<StructureCheck> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
        class_6895.method_40340(class_7924.field_41246).fieldOf("structures").forGetter(StructureCheck::requiredStructures)
    ).apply(instance, StructureCheck::new));

    @Override
    public boolean test(SpawnContext context) {
        return this.getStructureWithPieceAt(context, this.requiredStructures::method_40241).method_16657();
    }

    private class_3449 getStructureWithPieceAt(SpawnContext context, Predicate<class_6880<class_3195>> predicate) {
        class_5138 manager = context.level().method_8410().method_27056();
        class_2338 pos = context.pos();
        class_2378<class_3195> registry = manager.method_41036().method_30530(class_7924.field_41246);

        List<class_3449> starts = manager.method_41035(new class_1923(pos), structure -> registry.method_40265(registry.method_10206(structure)).map(predicate::test).orElse(false));

        for (class_3449 start : starts) {
            if (manager.method_41033(pos, start)) {
                return start;
            }
        }

        return class_3449.field_16713;
    }

    @Override
    public MapCodec<? extends SpawnCondition> codec() {
        return CODEC;
    }
}