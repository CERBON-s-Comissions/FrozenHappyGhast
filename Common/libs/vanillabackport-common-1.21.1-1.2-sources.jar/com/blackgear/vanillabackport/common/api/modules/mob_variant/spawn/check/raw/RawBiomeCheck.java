package com.blackgear.vanillabackport.common.api.modules.mob_variant.spawn.check.raw;

import com.blackgear.vanillabackport.common.api.modules.mob_variant.spawn.SpawnCondition;
import com.blackgear.vanillabackport.common.api.modules.mob_variant.spawn.SpawnContext;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_1959;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public record RawBiomeCheck(class_6862<class_1959> requiredBiomes) implements SpawnCondition {
    public static final MapCodec<RawBiomeCheck> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
        class_6862.method_40090(class_7924.field_41236).fieldOf("biomes").forGetter(RawBiomeCheck::requiredBiomes)
    ).apply(instance, RawBiomeCheck::new));

    @Override
    public boolean test(SpawnContext context) {
        return context.biome().method_40220(this.requiredBiomes);
    }

    @Override
    public MapCodec<? extends SpawnCondition> codec() {
        return CODEC;
    }
}