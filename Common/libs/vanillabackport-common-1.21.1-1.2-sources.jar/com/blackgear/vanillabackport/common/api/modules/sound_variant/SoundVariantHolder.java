package com.blackgear.vanillabackport.common.api.modules.sound_variant;

import com.blackgear.platform.core.BuiltInCoreRegistry;
import net.minecraft.class_1309;

public interface SoundVariantHolder<T> {
    @SuppressWarnings("unchecked")
    static <T> SoundVariantHolder<T> of(class_1309 entity) {
        if (entity instanceof SoundVariantHolder<?> holder) {
            return (SoundVariantHolder<T>) holder;
        }

        return null;
    }

    T vb$getSoundVariant();

    void vb$setSoundVariant(T variant);
    
    static <T> void trySetOffspringVariant(class_1309 child, class_1309 father, BuiltInCoreRegistry<T> registry) {
        SoundVariantHolder.of(child).vb$setSoundVariant(registry.getRandomElement(father.method_59922()));
    }
}