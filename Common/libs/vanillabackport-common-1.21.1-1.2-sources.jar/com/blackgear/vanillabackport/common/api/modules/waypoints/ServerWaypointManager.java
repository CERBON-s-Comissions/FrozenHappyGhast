package com.blackgear.vanillabackport.common.api.modules.waypoints;

import com.blackgear.platform.common.v2.entity.EntityAttributeEvents;
import com.blackgear.vanillabackport.common.api.modules.waypoints.WaypointTransmitter.Connection;
import com.blackgear.vanillabackport.common.registries.ModGameRules;
import com.google.common.collect.*;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5321;

public class ServerWaypointManager implements WaypointManager<WaypointTransmitter> {
    private static final Map<class_5321<class_1937>, ServerWaypointManager> MANAGERS = new ConcurrentHashMap<>();
    private final Set<WaypointTransmitter> waypoints = new HashSet<>();
    private final Set<class_3222> players = new HashSet<>();
    private final Table<class_3222, WaypointTransmitter, Connection> connections = HashBasedTable.create();
    
    public static ServerWaypointManager get(class_3218 level) {
        return MANAGERS.computeIfAbsent(level.method_27983(), key -> new ServerWaypointManager());
    }
    
    public static void bootstrap() {
        EntityAttributeEvents.ON_LIVING_ATTRIBUTE_UPDATE.register(WaypointUtils::onEntityAttributeUpdate);
        EntityAttributeEvents.UPDATE_PLAYER_ATTRIBUTE.register(WaypointUtils::onPlayerAttributeUpdate);
    }
    
    public static void clearAll() {
        MANAGERS.values().forEach(ServerWaypointManager::breakAllConnections);
        MANAGERS.clear();
    }
    
    @Override
    public void trackWaypoint(WaypointTransmitter waypoint) {
        this.waypoints.add(waypoint);
        
        for (class_3222 player : this.players) {
            this.createConnection(player, waypoint);
        }
    }
    
    @Override
    public void updateWaypoint(WaypointTransmitter waypoint) {
        if (this.waypoints.contains(waypoint)) {
            Map<class_3222, Connection> playerConnection = Tables.transpose(this.connections).row(waypoint);
            Sets.SetView<class_3222> potentialPlayers = Sets.difference(this.players, playerConnection.keySet());
            
            for (var waypointConnection : ImmutableSet.copyOf(playerConnection.entrySet())) {
                this.updateConnection(waypointConnection.getKey(), waypoint, waypointConnection.getValue());
            }
            
            for (class_3222 player : potentialPlayers) {
                this.createConnection(player, waypoint);
            }
        }
    }
    
    @Override
    public void untrackWaypoint(WaypointTransmitter waypoint) {
        this.connections.column(waypoint).forEach((player, connection) -> connection.disconnect());
        Tables.transpose(this.connections).row(waypoint).clear();
        this.waypoints.remove(waypoint);
    }
    
    public void addPlayer(class_3222 player) {
        this.players.add(player);
        
        for (WaypointTransmitter waypoint : this.waypoints) {
            this.createConnection(player, waypoint);
        }
        
        if (WaypointTransmitter.of(player).isTransmittingWaypoint()) {
            this.trackWaypoint(WaypointTransmitter.of(player));
        }
    }
    
    public void updatePlayer(class_3222 player) {
        Map<WaypointTransmitter, Connection> waypointConnections = this.connections.row(player);
        Sets.SetView<WaypointTransmitter> potentialWaypoints = Sets.difference(this.waypoints, waypointConnections.keySet());
        
        for (var waypointConnection : ImmutableSet.copyOf(waypointConnections.entrySet())) {
            this.updateConnection(player, waypointConnection.getKey(), waypointConnection.getValue());
        }
        
        for (WaypointTransmitter waypoint : potentialWaypoints) {
            this.createConnection(player, waypoint);
        }
    }
    
    public void removePlayer(class_3222 player) {
        this.connections.row(player).values().removeIf(connection -> {
            connection.disconnect();
            return true;
        });
        this.untrackWaypoint(WaypointTransmitter.of(player));
        this.players.remove(player);
    }
    
    public void breakAllConnections() {
        this.connections.values().forEach(Connection::disconnect);
        this.connections.clear();
    }
    
    public void remakeConnections(WaypointTransmitter waypoint) {
        for (class_3222 player : this.players) {
            this.createConnection(player, waypoint);
        }
    }
    
    public Set<WaypointTransmitter> transmitters() {
        return this.waypoints;
    }
    
    private static boolean isLocatorBarEnabledFor(class_3222 player) {
        return player.method_37908().method_8503().method_3767().method_8355(ModGameRules.RULE_LOCATOR_BAR);
    }
    
    private void createConnection(class_3222 player, WaypointTransmitter waypoint) {
        if (WaypointTransmitter.of(player) != waypoint) {
            if (isLocatorBarEnabledFor(player)) {
                waypoint.makeWaypointConnectionWith(player).ifPresentOrElse(connection -> {
                    this.connections.put(player, waypoint, connection);
                    connection.connect();
                }, () -> {
                    Connection connection = this.connections.remove(player, waypoint);
                    if (connection != null) connection.disconnect();
                });
            }
        }
    }
    
    private void updateConnection(class_3222 player, WaypointTransmitter waypoint, Connection connection) {
        if (WaypointTransmitter.of(player) != waypoint) {
            if (isLocatorBarEnabledFor(player)) {
                if (!connection.isBroken()) {
                    connection.update();
                } else {
                    waypoint.makeWaypointConnectionWith(player).ifPresentOrElse(newConnection -> {
                        newConnection.connect();
                        this.connections.put(player, waypoint, newConnection);
                    }, () -> {
                        connection.disconnect();
                        this.connections.remove(player, waypoint);
                    });
                }
            }
        }
    }
}