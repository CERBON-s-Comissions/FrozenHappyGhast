package com.blackgear.vanillabackport.common.api.modules.waypoints;

import com.blackgear.vanillabackport.core.util.AdditionalCodecs;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.netty.buffer.ByteBuf;
import java.util.Optional;
import net.minecraft.class_1309;
import net.minecraft.class_5321;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public interface Waypoint {
    class Icon {
        public static final Codec<Icon> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            class_5321.method_39154(WaypointStyleAssets.ROOT_ID).fieldOf("style").forGetter(icon -> icon.style),
            AdditionalCodecs.RGB_COLOR_CODEC.optionalFieldOf("color").forGetter(icon -> icon.color)
        ).apply(instance, Icon::new));
        public static final class_9139<ByteBuf, Icon> STREAM_CODEC = class_9139.method_56435(
            class_5321.method_56038(WaypointStyleAssets.ROOT_ID), icon -> icon.style,
            class_9135.method_56382(AdditionalCodecs.RGB_COLOR), icon -> icon.color,
            Icon::new
        );
        public static final Icon NULL = new Icon();
        public class_5321<WaypointStyleAsset> style = WaypointStyleAssets.DEFAULT;
        public Optional<Integer> color = Optional.empty();
        
        public Icon() { /* NO-OP */ }
        
        public Icon(class_5321<WaypointStyleAsset> style, Optional<Integer> color) {
            this.style = style;
            this.color = color;
        }
        
        public boolean hasData() {
            return this.style != WaypointStyleAssets.DEFAULT || this.color.isPresent();
        }
        
        public Icon cloneAndAssignStyle(class_1309 entity) {
            class_5321<WaypointStyleAsset> overrideStyle = this.getOverrideStyle();
            Optional<Integer> colorOverride = this.color.or(() -> Optional.ofNullable(entity.method_5781()).map(team -> team.method_1202().method_532()).map(color -> color == 0 ? -13619152 : color));
            return overrideStyle == this.style && colorOverride.isEmpty() ? this : new Icon(overrideStyle, colorOverride);
        }
        
        private class_5321<WaypointStyleAsset> getOverrideStyle() {
            return this.style != WaypointStyleAssets.DEFAULT ? this.style : WaypointStyleAssets.DEFAULT;
        }
    }
}