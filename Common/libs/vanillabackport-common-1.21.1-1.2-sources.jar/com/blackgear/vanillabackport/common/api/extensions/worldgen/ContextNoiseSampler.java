package com.blackgear.vanillabackport.common.api.extensions.worldgen;

import java.util.function.DoubleSupplier;
import net.minecraft.class_5216;
import net.minecraft.class_5321;

public interface ContextNoiseSampler {
    DoubleSupplier getNoiseSampler3D(class_5321<class_5216.class_5487> noise);
}