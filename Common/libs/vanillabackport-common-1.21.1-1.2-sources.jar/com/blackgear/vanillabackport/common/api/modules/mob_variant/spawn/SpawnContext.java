package com.blackgear.vanillabackport.common.api.modules.mob_variant.spawn;

import net.minecraft.class_1959;
import net.minecraft.class_2338;
import net.minecraft.class_5425;
import net.minecraft.class_6880;

public record SpawnContext(class_2338 pos, class_5425 level, class_6880<class_1959> biome) {
    public static SpawnContext create(class_5425 level, class_2338 pos) {
        class_6880<class_1959> biome = level.method_23753(pos);
        return new SpawnContext(pos, level, biome);
    }
}