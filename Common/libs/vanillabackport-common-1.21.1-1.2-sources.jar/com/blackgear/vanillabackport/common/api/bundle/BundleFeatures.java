package com.blackgear.vanillabackport.common.api.bundle;

import net.minecraft.class_1767;
import net.minecraft.class_1792;

/**
 * added for retro-compatibility with Dye the World, highly recommended for the dev to migrate!
 */
@Deprecated(forRemoval = true)
public class BundleFeatures {
    public static void register(class_1767 dyeColor, class_1792 item) {
        com.blackgear.vanillabackport.common.api.modules.bundle_ui.BundleFeatures.register(dyeColor, item);
    }
}