package com.blackgear.vanillabackport.common.api.extensions.entity.mounts;

import com.blackgear.vanillabackport.common.level.entities.mob.animal.nautilus.AbstractNautilus;
import net.minecraft.class_1263;
import net.minecraft.class_1657;

public interface MountInventoryHandler {
    MountInventoryHandler DEFAULT = new MountInventoryHandler() { };
    
    static MountInventoryHandler of(class_1657 player) {
        return player instanceof MountInventoryHandler handler ? handler : DEFAULT;
    }
    
    default void openNautilusInventory(AbstractNautilus nautilus, class_1263 container) { /* NO-OP */ }
}