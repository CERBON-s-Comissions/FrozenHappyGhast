package com.blackgear.vanillabackport.common.api.modules.waypoints;

import com.blackgear.vanillabackport.common.registries.entities.ModAttributes;
import com.blackgear.vanillabackport.core.data.tags.ModItemTags;
import net.minecraft.class_1294;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_6880;

public class WaypointUtils {
    private static final class_1322 WAYPOINT_TRANSMIT_RANGE_CROUCH_MODIFIER = new class_1322(class_2960.method_60656("waypoint_transmit_range_crouch"), -1.0, class_1322.class_1323.field_6331);
    private static final class_1322 WAYPOINT_TRANSMIT_RANGE_HIDE_MODIFIER = new class_1322(class_2960.method_60656("waypoint_transmit_range_hide"), -1.0, class_1322.class_1323.field_6331);

    public static void onEntityAttributeUpdate(class_1309 entity, class_6880<class_1320> attribute) {
        if (entity.method_37908() instanceof class_3218 level) {
            ServerWaypointManager manager = ServerWaypointManager.get(level);
            
            if (entity instanceof class_3222 player && attribute.method_55838(ModAttributes.WAYPOINT_RECEIVE_RANGE)) {
                if (entity.method_6127().method_26852(attribute) > 0.0) {
                    manager.addPlayer(player);
                } else {
                    manager.removePlayer(player);
                }
            }
            
            if (attribute.method_55838(ModAttributes.WAYPOINT_TRANSMIT_RANGE)) {
                if (entity.method_6127().method_26852(attribute) > 0.0) {
                    manager.trackWaypoint(WaypointTransmitter.of(entity));
                } else {
                    manager.untrackWaypoint(WaypointTransmitter.of(entity));
                }
            }
        }
    }
    
    public static void onPlayerAttributeUpdate(class_3222 player) {
        class_1324 attribute = player.method_5996(ModAttributes.WAYPOINT_TRANSMIT_RANGE);
        if (attribute != null) {
            if (player.method_6118(class_1304.field_6169).method_31573(ModItemTags.DISABLES_WAYPOINT_TRACKING)) {
                attribute.method_55696(WAYPOINT_TRANSMIT_RANGE_CROUCH_MODIFIER);
            } else if (player.method_18276()) {
                attribute.method_55696(WAYPOINT_TRANSMIT_RANGE_CROUCH_MODIFIER);
            } else {
                attribute.method_6202(WAYPOINT_TRANSMIT_RANGE_CROUCH_MODIFIER);
            }
        }
    }
    
    public static void onEntityTick(class_1309 entity) {
        if (entity.method_37908().method_8608()) return;
        class_1324 attribute = entity.method_5996(ModAttributes.WAYPOINT_TRANSMIT_RANGE);
        if (attribute == null) return;
        
        boolean hasInvisibility = entity.method_6059(class_1294.field_5905);
        boolean hasModifier = attribute.method_6196(WAYPOINT_TRANSMIT_RANGE_HIDE_MODIFIER.comp_2447());
        
        if (hasInvisibility && !hasModifier) {
            attribute.method_26835(WAYPOINT_TRANSMIT_RANGE_HIDE_MODIFIER);
        } else if (!hasInvisibility && hasModifier) {
            attribute.method_6202(WAYPOINT_TRANSMIT_RANGE_HIDE_MODIFIER);
        }
    }
    
    public static boolean isReceivingWaypoints(class_3222 player) {
        return player.method_45325(ModAttributes.WAYPOINT_RECEIVE_RANGE) > 0.0;
    }
}