package com.blackgear.vanillabackport.common.api.extensions;

import net.minecraft.class_1297;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_6880;
import org.jetbrains.annotations.Nullable;

public interface SoundExtensions {
    default void playSound(
        @Nullable class_1297 except,
        double x,
        double y,
        double z,
        class_6880<class_3414> sound,
        class_3419 source,
        float volume,
        float pitch
    ) {}
    
    default void playSeededSound(
        @Nullable class_1297 except,
        double x,
        double y,
        double z,
        class_6880<class_3414> sound,
        class_3419 source,
        float volume,
        float pitch,
        long seed
    ) {}
}