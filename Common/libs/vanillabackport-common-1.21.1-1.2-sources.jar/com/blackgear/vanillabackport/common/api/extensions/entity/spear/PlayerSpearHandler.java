package com.blackgear.vanillabackport.common.api.extensions.entity.spear;

import net.minecraft.class_1799;

public interface PlayerSpearHandler {
    boolean vb$cannotAttackWithItem(class_1799 stack, int tolerance);

    float vb$getItemSwapScale(float scale);
}