package com.blackgear.vanillabackport.common.api.modules.ender_pearl_persistance;

import java.util.Comparator;
import net.minecraft.class_1684;
import net.minecraft.class_1923;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3230;

public class EnderPearlLoaderModule {
    public static final class_3230<class_1923> ENDER_PEARL = class_3230.method_20628("ender_pearl", Comparator.comparingLong(class_1923::method_8324), 40);

    public static long registerAndUpdateEnderPearlTicket(class_3222 player, class_1684 pearl) {
        if (pearl.method_37908() instanceof class_3218 level) {
            class_1923 pos = pearl.method_31476();
            ((EnderPearlAccess) player).registerEnderPearl(pearl);
            level.method_14197();
            return placeEnderPearlTicket(level, pos) - 1L;
        } else {
            return 0L;
        }
    }
    
    public static long placeEnderPearlTicket(class_3218 level, class_1923 chunk) {
        level.method_14178().method_17297(ENDER_PEARL, chunk, 2, chunk);
        return ENDER_PEARL.method_20629();
    }
}