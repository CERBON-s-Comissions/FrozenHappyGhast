package com.blackgear.vanillabackport.common.api.modules.sound_variant;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_3414;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

public record WolfSoundVariant(
    class_6880<class_3414> ambientSound,
    class_6880<class_3414> deathSound,
    class_6880<class_3414> growlSound,
    class_6880<class_3414> hurtSound,
    class_6880<class_3414> pantSound,
    class_6880<class_3414> whineSound
) {
    public WolfSoundVariant(class_3414 ambientSound, class_3414 deathSound, class_3414 growlSound, class_3414 hurtSound, class_3414 pantSound, class_3414 whineSound) {
        this(class_6880.method_40223(ambientSound), class_6880.method_40223(deathSound), class_6880.method_40223(growlSound), class_6880.method_40223(hurtSound), class_6880.method_40223(pantSound), class_6880.method_40223(whineSound));
    }

    public static final Codec<WolfSoundVariant> CODEC = RecordCodecBuilder.create(instance -> instance.group(
        class_7923.field_41172.method_40294().fieldOf("ambient_sound").forGetter(WolfSoundVariant::ambientSound),
        class_7923.field_41172.method_40294().fieldOf("death_sound").forGetter(WolfSoundVariant::deathSound),
        class_7923.field_41172.method_40294().fieldOf("growl_sound").forGetter(WolfSoundVariant::growlSound),
        class_7923.field_41172.method_40294().fieldOf("hurt_sound").forGetter(WolfSoundVariant::hurtSound),
        class_7923.field_41172.method_40294().fieldOf("pant_sound").forGetter(WolfSoundVariant::pantSound),
        class_7923.field_41172.method_40294().fieldOf("whine_sound").forGetter(WolfSoundVariant::whineSound)
    ).apply(instance, WolfSoundVariant::new));
}