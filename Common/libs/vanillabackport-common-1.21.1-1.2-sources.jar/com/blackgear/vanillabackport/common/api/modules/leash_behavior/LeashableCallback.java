package com.blackgear.vanillabackport.common.api.modules.leash_behavior;

import java.util.function.Predicate;
import net.minecraft.class_1297;
import net.minecraft.class_1314;
import net.minecraft.class_243;
import net.minecraft.class_9817;

public interface LeashableCallback {
    default double vb$leashSnapDistance() { return LeashPhysics.LEASH_TOO_FAR_DIST; }

    default double vb$leashElasticDistance() { return LeashPhysics.LEASH_ELASTIC_DIST; }

    default boolean vb$supportsQuadLeash() {
        class_1297 entity = (class_1297) this;
        for (Predicate<class_1297> filter : LeashPhysics.QUAD_LEASH_OFFSETS.keySet()) {
            if (filter.test(entity)) {
                return true;
            }
        }

        return false;
    }

    default class_243[] vb$getQuadLeashOffsets() {
        class_1297 entity = (class_1297) this;
        for (Predicate<class_1297> filter : LeashPhysics.QUAD_LEASH_OFFSETS.keySet()) {
            if (filter.test(entity)) {
                return LeashPhysics.QUAD_LEASH_OFFSETS.get(filter).apply(entity);
            }
        }

        return LeashPhysics.createQuadOffsets((class_1297) this, 0.0, 0.5, 0.5, 0.5);
    }

    default void vb$onElasticLeashPull() {
        ((class_1297) this).method_45318();
    }

    default boolean vb$supportsQuadLeashAsHolder() { return false; }

    default class_243[] vb$getQuadLeashHolderOffsets() {
        return LeashPhysics.createQuadOffsets((class_1297) this, 0.0, 0.5, 0.5, 0.0);
    }

    default void vb$whenLeashedTo(class_1297 leashHolder) {
        class_1297 entity = (class_1297) this;
        if (entity instanceof class_1314 mob) {
            mob.method_18408(leashHolder.method_24515(), (int) this.vb$leashElasticDistance() - 1);
        }

        if (entity instanceof class_9817 leashable) {
            ((LeashableCallback) leashHolder).vb$notifyLeashHolder(leashable);
        }
    }

    default void vb$notifyLeashHolder(class_9817 leashee) {}
}