package com.blackgear.vanillabackport.common.api.modules.sound_variant;

import com.blackgear.vanillabackport.core.VanillaBackport;
import net.minecraft.class_1493;
import net.minecraft.class_3414;

public class WolfSoundVariantsModule {
    public static <T extends class_1493 & SoundVariantHolder<WolfSoundVariant>> class_3414 getAmbientSound(T wolf) {
        if (!VanillaBackport.COMMON_CONFIG.hasWolfSoundVariants.get()) return null;

        if (wolf.method_29511()) {
            return wolf.vb$getSoundVariant().growlSound().comp_349();
        } else if (wolf.method_59922().method_43048(3) == 0) {
            return wolf.method_6181() && wolf.method_6032() < 20.0F
                ? wolf.vb$getSoundVariant().whineSound().comp_349()
                : wolf.vb$getSoundVariant().pantSound().comp_349();
        } else {
            return wolf.vb$getSoundVariant().ambientSound().comp_349();
        }
    }

    public static <T extends class_1493 & SoundVariantHolder<WolfSoundVariant>> class_3414 getHurtSound(T wolf) {
        if (!VanillaBackport.COMMON_CONFIG.hasWolfSoundVariants.get()) return null;

        return wolf.vb$getSoundVariant().hurtSound().comp_349();
    }

    public static <T extends class_1493 & SoundVariantHolder<WolfSoundVariant>> class_3414 getDeathSound(T wolf) {
        if (!VanillaBackport.COMMON_CONFIG.hasWolfSoundVariants.get()) return null;

        return wolf.vb$getSoundVariant().deathSound().comp_349();
    }
}