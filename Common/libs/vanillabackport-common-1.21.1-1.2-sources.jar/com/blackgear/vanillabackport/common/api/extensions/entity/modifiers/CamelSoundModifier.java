package com.blackgear.vanillabackport.common.api.extensions.entity.modifiers;

import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_7689;
import org.jetbrains.annotations.Nullable;

public interface CamelSoundModifier {
    static @Nullable CamelSoundModifier of(class_7689 camel) {
        return camel instanceof CamelSoundModifier extension ? extension : null;
    }
    
    default class_3414 getDashingSound() {
        return class_3417.field_40073;
    }
    
    default class_3414 getDashReadySound() {
        return class_3417.field_40074;
    }
    
    default class_3414 getStandUpSound() {
        return class_3417.field_40080;
    }
    
    default class_3414 getSitDownSound() {
        return class_3417.field_40079;
    }
}