package com.blackgear.vanillabackport.common.level.worldgen.features;

import com.mojang.serialization.Codec;
import java.util.function.Predicate;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2794;
import net.minecraft.class_2902;
import net.minecraft.class_3031;
import net.minecraft.class_3486;
import net.minecraft.class_5281;
import net.minecraft.class_5819;
import net.minecraft.class_5821;

public class SulfurRootSystemFeature extends class_3031<SulfurRootSystemConfiguration> {
    public SulfurRootSystemFeature(Codec<SulfurRootSystemConfiguration> codec) {
        super(codec);
    }

    public boolean method_13151(class_5821<SulfurRootSystemConfiguration> context) {
        class_5281 level = context.method_33652();
        class_2338 origin = context.method_33655();
        if (!level.method_8320(origin).method_26215()) {
            return false;
        } else {
            class_5819 random = context.method_33654();
            class_2338 pos = context.method_33655();
            SulfurRootSystemConfiguration config = context.method_33656();
            class_2338.class_2339 workingPos = pos.method_25503();
            if (placeDirtAndTree(level, context.method_33653(), config, random, workingPos, pos)) {
                placeRoots(level, config, random, pos, workingPos);
            }

            return true;
        }
    }

    private static boolean spaceForTree(class_5281 level, SulfurRootSystemConfiguration config, class_2338 pos) {
        class_2338.class_2339 columnUpPos = pos.method_25503();

        for(int i = 1; i <= config.requiredVerticalSpaceForTree(); i++) {
            columnUpPos.method_10098(class_2350.field_11036);
            class_2680 state = level.method_8320(columnUpPos);
            if (!isAllowedTreeSpace(state, i, config.allowedVerticalWaterForTree())) {
                return false;
            }
        }

        if (config.levelTestDistance() > 0) {
            class_2338.class_2339 cornerPos = pos.method_25503();

            for (int i = 0; i < 4; i++) {
                cornerPos.method_10104(class_2350.method_10139(i), config.levelTestDistance());
                class_2680 below = level.method_8320(cornerPos.method_10087(config.maxLevelDeviation()));
                class_2680 above = level.method_8320(cornerPos.method_10086(config.maxLevelDeviation()));
                if (below.method_26215() || !above.method_26215()) return false;
                cornerPos.method_10101(pos);
            }
        }

        return true;
    }

    private static boolean isAllowedTreeSpace(class_2680 state, int blocksAboveOrigin, int allowedVerticalWaterHeight) {
        if (state.method_26215()) {
            return true;
        } else {
            int blocksAboveGround = blocksAboveOrigin + 1;
            return blocksAboveGround <= allowedVerticalWaterHeight && state.method_26227().method_15767(class_3486.field_15517);
        }
    }

    private static boolean placeDirtAndTree(
        class_5281 level,
        class_2794 generator,
        SulfurRootSystemConfiguration config,
        class_5819 random,
        class_2338.class_2339 workingPos,
        class_2338 pos
    ) {
        for (int y = 0; y < config.rootColumnMaxHeight(); y++) {
            workingPos.method_10098(class_2350.field_11036);
            if (level.method_8624(class_2902.class_2903.field_13202, workingPos.method_10263(), workingPos.method_10260()) < workingPos.method_10264()) {
                return false;
            }

            if (config.allowedTreePosition().test(level, workingPos) && spaceForTree(level, config, workingPos)) {
                class_2338 belowPos = workingPos.method_10074();
                if (level.method_8316(belowPos).method_15767(class_3486.field_15518) || !level.method_8320(belowPos).method_51367()) {
                    return false;
                }

                if (config.feature().comp_349().method_39644(level, generator, random, workingPos)) {
                    placeDirt(pos, pos.method_10264() + y, level, config, random);
                    return true;
                }
            }
        }

        return false;
    }

    private static void placeDirt(class_2338 origin, int targetHeight, class_5281 level, SulfurRootSystemConfiguration config, class_5819 random) {
        int originX = origin.method_10263();
        int originZ = origin.method_10260();
        class_2338.class_2339 workingPos = origin.method_25503();

        for(int y = origin.method_10264(); y < targetHeight; y++) {
            placeRootedDirt(level, config, random, originX, originZ, workingPos.method_10103(originX, y, originZ));
        }
    }

    private static void placeRootedDirt(
        class_5281 level,
        SulfurRootSystemConfiguration config,
        class_5819 random,
        int originX,
        int originZ,
        class_2338.class_2339 workingPos
    ) {
        int rootRadius = config.rootRadius();
        Predicate<class_2680> stateTest = state -> state.method_26164(config.rootReplaceable());

        for (int i = 0; i < config.rootPlacementAttempts(); i++) {
            workingPos.method_25504(workingPos, random.method_43048(rootRadius) - random.method_43048(rootRadius), 0, random.method_43048(rootRadius) - random.method_43048(rootRadius));
            if (stateTest.test(level.method_8320(workingPos))) {
                level.method_8652(workingPos, config.rootStateProvider().method_23455(random, workingPos), 2);
            }

            workingPos.method_33097(originX);
            workingPos.method_33099(originZ);
        }
    }

    private static void placeRoots(class_5281 level, SulfurRootSystemConfiguration config, class_5819 random, class_2338 pos, class_2338.class_2339 workingPos) {
        int rootRadius = config.hangingRootRadius();
        int verticalSpan = config.hangingRootsVerticalSpan();

        for (int i = 0; i < config.hangingRootPlacementAttempts(); i++) {
            workingPos.method_25504(pos, random.method_43048(rootRadius) - random.method_43048(rootRadius), random.method_43048(verticalSpan) - random.method_43048(verticalSpan), random.method_43048(rootRadius) - random.method_43048(rootRadius));
            if (level.method_22347(workingPos)) {
                class_2680 targetState = config.hangingRootStateProvider().method_23455(random, workingPos);
                if (targetState.method_26184(level, workingPos) && level.method_8320(workingPos.method_10084()).method_26206(level, workingPos, class_2350.field_11033)) {
                    level.method_8652(workingPos, targetState, 2);
                }
            }
        }
    }
}
