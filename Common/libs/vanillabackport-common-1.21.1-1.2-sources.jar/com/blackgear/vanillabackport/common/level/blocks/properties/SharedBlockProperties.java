package com.blackgear.vanillabackport.common.level.blocks.properties;

import com.blackgear.vanillabackport.client.registries.ModSoundTypes;
import net.minecraft.class_1299;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2465;
import net.minecraft.class_2498;
import net.minecraft.class_2680;
import net.minecraft.class_2766;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_4970.class_2251;

public class SharedBlockProperties {
    
    // The Garden Awakens
    
    public static final class_2251 PALE_OAK = class_2251.method_9637()
        .method_31710(class_3620.field_16025)
        .method_51368(class_2766.field_12651)
        .method_9629(2.0F, 3.0F)
        .method_9626(class_2498.field_11547)
        .method_50013();
    
    public static final class_2251 RESIN_BRICKS = class_2251.method_9637()
        .method_31710(class_3620.field_15981)
        .method_51368(class_2766.field_12653)
        .method_29292()
        .method_9626(ModSoundTypes.RESIN_BRICKS)
        .method_9629(1.5F, 6.0F);
    
    // Copper Age
    
    public static final class_2251 COPPER_CHEST = class_2251.method_9637()
        .method_9629(3.0F, 6.0F)
        .method_9626(class_2498.field_27204)
        .method_29292();
    
    public static final class_2251 COPPER_GOLEM_STATUE = class_2251.method_9637()
        .method_9629(3.0F, 6.0F)
        .method_9626(ModSoundTypes.COPPER_GOLEM_STATUE)
        .method_50012(class_3619.field_15971)
        .method_22488();
    
    public static final class_2251 SHELF = class_2251.method_9637()
        .method_51368(class_2766.field_12651)
        .method_9626(ModSoundTypes.WOODEN_SHELF)
        .method_9629(2.0F, 3.0F);
    
    // Chaos Cubed
    
    public static final class_2251 SULFUR = class_2251.method_9637()
        .method_9626(ModSoundTypes.SULFUR)
        .method_31710(class_3620.field_16010)
        .method_51368(class_2766.field_12653)
        .method_29292()
        .method_9629(1.5F, 6.0F);

    public static final class_2251 CINNABAR = class_2251.method_9637()
        .method_9626(ModSoundTypes.CINNABAR)
        .method_31710(class_3620.field_16020)
        .method_51368(class_2766.field_12653)
        .method_29292()
        .method_9629(1.5F, 6.0F);
    
    // Wilderness Bound
    
    public static final class_2251 POPLAR = class_2251.method_9637()
        .method_31710(class_3620.field_15993)
        .method_51368(class_2766.field_12651)
        .method_9629(2.0F, 3.0F)
        .method_9626(class_2498.field_11547)
        .method_50013();
    
    // Shared Properties
    
    public static class_2251 logProperties(class_3620 topColor, class_3620 sideColor, class_2498 sound) {
        return class_2251.method_9637()
            .method_51520(state -> state.method_11654(class_2465.field_11459) == class_2350.class_2351.field_11052 ? topColor : sideColor)
            .method_51368(class_2766.field_12651)
            .method_9632(2.0F)
            .method_9626(sound)
            .method_50013();
    }
    
    public static class_2251 buttonProperties() {
        return class_2251.method_9637().method_9634().method_9632(0.5F).method_50012(class_3619.field_15971);
    }
    
    public static class_2251 flowerPotProperties() {
        return class_2251.method_9637()
            .method_9618()
            .method_22488()
            .method_50012(class_3619.field_15971);
    }
    
    public static class_2251 leavesProperties(class_2498 sound) {
        return class_2251.method_9637()
            .method_31710(class_3620.field_15987)
            .method_9632(0.2F)
            .method_9640()
            .method_9626(sound)
            .method_22488()
            .method_26235(SharedBlockProperties::ocelotOrParrot)
            .method_26243(SharedBlockProperties::never)
            .method_26245(SharedBlockProperties::never)
            .method_50013()
            .method_50012(class_3619.field_15971)
            .method_26236(SharedBlockProperties::never);
    }
    
    private static Boolean never(class_2680 state, class_1922 level, class_2338 pos, class_1299<?> type) {
        return false;
    }
    
    private static Boolean always(class_2680 state, class_1922 level, class_2338 pos, class_1299<?> type) {
        return true;
    }
    
    private static Boolean ocelotOrParrot(class_2680 state, class_1922 level, class_2338 pos, class_1299<?> type) {
        return type == class_1299.field_6081 || type == class_1299.field_6104;
    }
    
    private static boolean always(class_2680 state, class_1922 level, class_2338 pos) {
        return true;
    }
    
    private static boolean never(class_2680 state, class_1922 level, class_2338 pos) {
        return false;
    }
}