package com.blackgear.vanillabackport.common.level.entities.mob.monster.sulfur_cube;

import com.blackgear.platform.core.BuiltInCoreRegistry;
import com.blackgear.platform.core.api.RegistryKey;
import com.blackgear.vanillabackport.client.registries.ModSoundEvents;
import com.blackgear.vanillabackport.common.level.entities.mob.monster.sulfur_cube.SulfurCubeArchetype.AttributeEntry;
import com.blackgear.vanillabackport.common.level.entities.mob.monster.sulfur_cube.SulfurCubeArchetype.ContactDamage;
import com.blackgear.vanillabackport.common.level.entities.mob.monster.sulfur_cube.SulfurCubeArchetype.ExplosionData;
import com.blackgear.vanillabackport.common.level.entities.mob.monster.sulfur_cube.SulfurCubeArchetype.KnockbackModifiers;
import com.blackgear.vanillabackport.common.level.entities.mob.monster.sulfur_cube.SulfurCubeArchetype.SoundSettings;
import com.blackgear.vanillabackport.common.registries.entities.ModAttributes;
import com.blackgear.vanillabackport.common.registries.entities.ModDamageTypes;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.blackgear.vanillabackport.core.data.tags.ModItemTags;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import net.minecraft.class_1320;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_5134;
import net.minecraft.class_5321;
import net.minecraft.class_5862;
import net.minecraft.class_5863;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_8110;

import static com.blackgear.vanillabackport.common.level.entities.mob.monster.sulfur_cube.SulfurCubeArchetype.*;

public class SulfurCubeArchetypes {
    public static final BuiltInCoreRegistry<SulfurCubeArchetype> REGISTRIES = BuiltInCoreRegistry.create(class_2960.method_60656("sulfur_cube_archetypes"), VanillaBackport.NAMESPACE);

    public static final RegistryKey<SulfurCubeArchetype> REGULAR = register("regular",
        ModItemTags.SULFUR_CUBE_ARCHETYPE_REGULAR,
        archetype(1.0F, 0.5F, 0.3F, 0.1F),
        true,
        Optional.empty(),
        Optional.empty(),
        knockbackHitScale(0.4125F, 0.09F),
        soundSettings(ModSoundEvents.SULFUR_CUBE_REGULAR_HIT, ModSoundEvents.SULFUR_CUBE_REGULAR_PUSH, 0.2F, 0.5F));
    public static final RegistryKey<SulfurCubeArchetype> BOUNCY = register("bouncy",
        ModItemTags.SULFUR_CUBE_ARCHETYPE_BOUNCY,
        archetype(2.0F, 0.9F, 0.3F, 0.01F),
        true,
        Optional.empty(),
        Optional.empty(),
        knockbackHitScale(0.4125F, 0.105F),
        soundSettings(ModSoundEvents.SULFUR_CUBE_BOUNCY_HIT, ModSoundEvents.SULFUR_CUBE_BOUNCY_PUSH, 0.3F, 0.7F));
    public static final RegistryKey<SulfurCubeArchetype> SLOW_BOUNCY = register("slow_bouncy",
        ModItemTags.SULFUR_CUBE_ARCHETYPE_SLOW_BOUNCY,
        archetype(-0.4F, 0.6F, 0.3F, 0.05F),
        false,
        Optional.empty(),
        Optional.empty(),
        knockbackHitScale(0.4125F, 0.24F),
        soundSettings(ModSoundEvents.SULFUR_CUBE_SLOW_BOUNCY_HIT, ModSoundEvents.SULFUR_CUBE_SLOW_BOUNCY_PUSH, 0.05F, 0.5F));
    public static final RegistryKey<SulfurCubeArchetype> SLOW_FLAT = register("slow_flat",
        ModItemTags.SULFUR_CUBE_ARCHETYPE_SLOW_FLAT,
        archetype(-0.5F, 0.4F, 0.4F, 0.1F),
        false,
        Optional.empty(),
        Optional.empty(),
        knockbackHitScale(0.4125F, 0.105F),
        soundSettings(ModSoundEvents.SULFUR_CUBE_SLOW_FLAT_HIT, ModSoundEvents.SULFUR_CUBE_SLOW_FLAT_PUSH, 0.03F, 0.9F));
    public static final RegistryKey<SulfurCubeArchetype> FAST_FLAT = register("fast_flat",
        ModItemTags.SULFUR_CUBE_ARCHETYPE_FAST_FLAT,
        archetype(1.0F, 0.5F, 0.2F, 0.01F),
        false,
        Optional.empty(),
        Optional.empty(),
        knockbackHitScale(0.9125F, 0.09F),
        soundSettings(ModSoundEvents.SULFUR_CUBE_FAST_FLAT_HIT, ModSoundEvents.SULFUR_CUBE_FAST_FLAT_PUSH, 0.03F, 0.9F));
    public static final RegistryKey<SulfurCubeArchetype> LIGHT = register("light",
        ModItemTags.SULFUR_CUBE_ARCHETYPE_LIGHT,
        archetype(1.0F, 1.0F, 0.3F, 1.8F),
        true,
        Optional.empty(),
        Optional.empty(),
        knockbackHitScale(0.4125F, 0.18F),
        soundSettings(ModSoundEvents.SULFUR_CUBE_LIGHT_HIT, ModSoundEvents.SULFUR_CUBE_LIGHT_PUSH, 0.2F, 0.7F));
    public static final RegistryKey<SulfurCubeArchetype> FAST_SLIDING = register("fast_sliding",
        ModItemTags.SULFUR_CUBE_ARCHETYPE_FAST_SLIDING,
        archetype(-0.5F, 0.1F, 0.05F, 0.01F),
        false,
        Optional.empty(),
        Optional.empty(),
        knockbackHitScale(0.6625F, 0.09F),
        soundSettings(ModSoundEvents.SULFUR_CUBE_FAST_SLIDING_HIT, ModSoundEvents.SULFUR_CUBE_FAST_SLIDING_PUSH, 0.05F, 1.0F));
    public static final RegistryKey<SulfurCubeArchetype> SLOW_SLIDING = register("slow_sliding",
        ModItemTags.SULFUR_CUBE_ARCHETYPE_SLOW_SLIDING,
        archetype(-0.8F, 0.1F, 0.05F, 0.01F),
        false,
        Optional.empty(),
        Optional.empty(),
        knockbackHitScale(0.4125F, 0.09F),
        soundSettings(ModSoundEvents.SULFUR_CUBE_SLOW_SLIDING_HIT, ModSoundEvents.SULFUR_CUBE_SLOW_SLIDING_PUSH, 0.02F, 1.0F));
    public static final RegistryKey<SulfurCubeArchetype> STICKY = register("sticky",
        ModItemTags.SULFUR_CUBE_ARCHETYPE_STICKY,
        archetype(2.0F, 0.0F, 2.0F, 0.01F),
        false,
        Optional.empty(),
        Optional.empty(),
        knockbackHitScale(0.4125F, 0.09F),
        soundSettings(ModSoundEvents.SULFUR_CUBE_STICKY_HIT, ModSoundEvents.SULFUR_CUBE_STICKY_PUSH, 0.05F, 0.5F));
    public static final RegistryKey<SulfurCubeArchetype> HIGH_RESISTANCE = register("high_resistance",
        ModItemTags.SULFUR_CUBE_ARCHETYPE_HIGH_RESISTANCE,
        archetype(-0.7F, 0.2F, 1.0F, 0.01F),
        false,
        Optional.empty(),
        Optional.empty(),
        knockbackHitScale(0.4125F, 0.09F),
        soundSettings(ModSoundEvents.SULFUR_CUBE_HIGH_RESISTANCE_HIT, ModSoundEvents.SULFUR_CUBE_HIGH_RESISTANCE_PUSH, 0.03F, 0.7F));
    public static final RegistryKey<SulfurCubeArchetype> EXPLOSIVE = register("explosive",
        ModItemTags.SULFUR_CUBE_ARCHETYPE_EXPLOSIVE,
        archetype(1.0F, 0.5F, 0.3F, 0.3F),
        true,
        Optional.of(new ExplosionData(3, false, 120)),
        Optional.empty(),
        knockbackHitScale(0.4125F, 0.09F),
        soundSettings(ModSoundEvents.SULFUR_CUBE_EXPLOSIVE_HIT, ModSoundEvents.SULFUR_CUBE_EXPLOSIVE_PUSH, 0.1F,0.7F));
    public static final RegistryKey<SulfurCubeArchetype> HOT = register("hot",
        ModItemTags.SULFUR_CUBE_ARCHETYPE_HOT,
        archetype(1.0F, 0.5F, 0.3F, 0.1F),
        true,
        Optional.empty(),
        Optional.of(contactDamage(ModDamageTypes.SULFUR_CUBE_HOT, class_5862.method_33908(1.0F), false)),
        knockbackHitScale(0.4125F, 0.09F),
        soundSettings(ModSoundEvents.SULFUR_CUBE_HOT_HIT, ModSoundEvents.SULFUR_CUBE_HOT_PUSH, 0.2F,0.7F));

    private static Function<RegistryKey<SulfurCubeArchetype>, AttributeEntry> add(class_6880<class_1320> attribute, double amount) {
        return key -> AttributeEntry.add(attribute, amount, key);
    }

    private static Function<RegistryKey<SulfurCubeArchetype>, AttributeEntry> multiply(class_6880<class_1320> attribute, double amount) {
        return key -> AttributeEntry.multiply(attribute, amount, key);
    }

    private static List<Function<RegistryKey<SulfurCubeArchetype>, AttributeEntry>> archetype(
        float speed,
        float bounce,
        float friction,
        float drag
    ) {
        return List.of(
            add(class_5134.field_23718, -speed),
            add(class_5134.field_51580, -speed),
            add(ModAttributes.BOUNCINESS, bounce),
            multiply(ModAttributes.FRICTION_MODIFIER, friction),
            multiply(ModAttributes.AIR_DRAG_MODIFIER, drag)
        );
    }

    private static ContactDamage contactDamage(class_5321<class_8110> damageType, class_5863 amount, boolean attributeToSource) {
        return new ContactDamage(damageType, amount, attributeToSource);
    }

    private static KnockbackModifiers knockbackHitScale(float horizontalPower, float verticalPower) {
        return new KnockbackModifiers(horizontalPower, verticalPower);
    }

    private static SoundSettings soundSettings(class_6880<class_3414> hitSound, class_6880<class_3414> pushSound, float threshold, float cooldown) {
        return new SoundSettings(hitSound, pushSound, threshold, cooldown);
    }

    private static RegistryKey<SulfurCubeArchetype> register(
        String name,
        class_6862<class_1792> blocks,
        List<Function<RegistryKey<SulfurCubeArchetype>, AttributeEntry>> modifiers,
        boolean floats,
        Optional<ExplosionData> maxFuse,
        Optional<ContactDamage> contactDamage,
        KnockbackModifiers knockbackModifiers,
        SoundSettings soundSettings
    ) {
        return REGISTRIES.registerKey(
            name,
            key ->
            new SulfurCubeArchetype(
                blocks,
                modifiers.stream().map(archetype -> archetype.apply(key)).toList(),
                floats,
                maxFuse,
                contactDamage,
                knockbackModifiers,
                soundSettings
            )
        );
    }
}