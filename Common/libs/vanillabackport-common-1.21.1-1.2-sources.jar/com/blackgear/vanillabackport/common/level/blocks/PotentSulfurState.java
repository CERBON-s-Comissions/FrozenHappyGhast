package com.blackgear.vanillabackport.common.level.blocks;

import net.minecraft.class_3542;

public enum PotentSulfurState implements class_3542 {
    DRY("dry"),
    WET("wet"),
    DORMANT("dormant"),
    ERUPTING("erupting"),
    CONTINUOUS("continuous");

    private final String name;

    PotentSulfurState(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return this.name;
    }

    @Override
    public String method_15434() {
        return this.name;
    }
}