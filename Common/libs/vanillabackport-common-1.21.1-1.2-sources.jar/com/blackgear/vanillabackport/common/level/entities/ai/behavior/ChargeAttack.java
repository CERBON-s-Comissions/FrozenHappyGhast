package com.blackgear.vanillabackport.common.level.entities.ai.behavior;

import com.blackgear.vanillabackport.common.registries.entities.ModMemoryModuleTypes;
import com.google.common.collect.ImmutableMap;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1282;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1321;
import net.minecraft.class_1429;
import net.minecraft.class_1890;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3532;
import net.minecraft.class_4051;
import net.minecraft.class_4095;
import net.minecraft.class_4097;
import net.minecraft.class_4140;
import net.minecraft.class_4141;
import net.minecraft.class_5134;
import net.minecraft.class_5575;

public class ChargeAttack extends class_4097<class_1429> {
    private final int timeBetweenAttacks;
    private final class_4051 chargeTargeting;
    private final float speed;
    private final float knockbackForce;
    private final double maxTargetDetectionDistance;
    private final double maxChargeDistance;
    private final class_3414 chargeSound;
    private class_243 chargeVelocityVector;
    private class_243 startPosition;
    
    public ChargeAttack(
        int timeBetweenAttacks,
        class_4051 chargeTargeting,
        float speed,
        float knockbackForce,
        double maxTargetDetectionDistance,
        double maxChargeDistance,
        class_3414 chargeSound
    ) {
        super(ImmutableMap.of(
            ModMemoryModuleTypes.CHARGE_COOLDOWN_TICKS.get(), class_4141.field_18457,
            class_4140.field_22355, class_4141.field_18456
        ));
        this.timeBetweenAttacks = timeBetweenAttacks;
        this.chargeTargeting = chargeTargeting;
        this.speed = speed;
        this.knockbackForce = knockbackForce;
        this.maxTargetDetectionDistance = maxTargetDetectionDistance;
        this.maxChargeDistance = maxChargeDistance;
        this.chargeSound = chargeSound;
        this.chargeVelocityVector = class_243.field_1353;
        this.startPosition = class_243.field_1353;
    }
    
    @Override
    protected boolean checkExtraStartConditions(class_3218 level, class_1429 owner) {
        return owner.method_18868().method_18896(class_4140.field_22355);
    }
    
    @Override
    protected boolean canStillUse(class_3218 level, class_1429 entity, long gameTime) {
        class_4095<?> brain = entity.method_18868();
        Optional<class_1309> attackCandidate = brain.method_18904(class_4140.field_22355);
        if (attackCandidate.isEmpty()) {
            return false;
        } else {
            class_1309 attackTarget = attackCandidate.get();
            if (entity instanceof class_1321 tamable && tamable.method_6181()) {
                return false;
            } else if (entity.method_19538().method_1020(this.startPosition).method_1027() >= this.maxChargeDistance * this.maxChargeDistance) {
                return false;
            } else if (attackTarget.method_19538().method_1020(entity.method_19538()).method_1027() >= this.maxTargetDetectionDistance * this.maxTargetDetectionDistance) {
                return false;
            } else {
                return entity.method_6057(attackTarget) && !brain.method_18896(ModMemoryModuleTypes.CHARGE_COOLDOWN_TICKS.get());
            }
        }
    }
    
    @Override
    protected void start(class_3218 level, class_1429 entity, long gameTime) {
        class_4095<?> brain = entity.method_18868();
        this.startPosition = entity.method_19538();
        class_1309 attackCandidate = brain.method_18904(class_4140.field_22355).get();
        class_243 direction = attackCandidate.method_19538().method_1020(entity.method_19538()).method_1029();
        this.chargeVelocityVector = direction.method_1021(this.speed);
        if (this.canStillUse(level, entity, gameTime)) {
            entity.method_43077(this.chargeSound);
        }
    }
    
    @Override
    protected void tick(class_3218 level, class_1429 entity, long gameTime) {
        class_4095<?> brain = entity.method_18868();
        class_1309 attackTarget = brain.method_18904(class_4140.field_22355).orElseThrow();
        entity.method_5951(attackTarget, 360.0F, 360.0F);
        entity.method_18799(this.chargeVelocityVector);
        List<class_1309> collidingEntities = new ArrayList<>(1);
        level.method_47575(class_5575.method_31795(class_1309.class), entity.method_5829(), target -> this.chargeTargeting.method_18419(entity, target), collidingEntities, 1);
        if (!collidingEntities.isEmpty()) {
            class_1309 closestAttackTarget = collidingEntities.get(0);
            if (entity.method_5626(closestAttackTarget)) {
                return;
            }
            
            this.dealDamageToTarget(level, entity, closestAttackTarget);
            this.dealKnockback(level, entity, closestAttackTarget);
            this.stop(level, entity, gameTime);
        }
    }
    
    private void dealDamageToTarget(class_3218 level, class_1429 entity, class_1309 target) {
        class_1282 source = level.method_48963().method_48812(entity);
        float damage = (float) entity.method_45325(class_5134.field_23721);
        if (target.method_5643(source, damage)) {
            class_1890.method_60107(level, target, source);
        }
    }
    
    private void dealKnockback(class_3218 level, class_1429 entity, class_1309 target) {
        int movementSpeedLevel = entity.method_6059(class_1294.field_5904) ? entity.method_6112(class_1294.field_5904).method_5578() + 1 : 0;
        int movementSlowdownLevel = entity.method_6059(class_1294.field_5909) ? entity.method_6112(class_1294.field_5909).method_5578() + 1 : 0;
        float speedBoostPower = 0.25F * (movementSpeedLevel - movementSlowdownLevel);
        float speedFactor = class_3532.method_15363(this.speed * (float) entity.method_45325(class_5134.field_23719), 0.2F, 2.0F) + speedBoostPower;
        float knockback = speedFactor * this.knockbackForce;
        if (knockback > 0.0F) {
            target.method_6005(knockback, class_3532.method_15374(entity.method_36454() * class_3532.field_29847), -class_3532.method_15362(entity.method_36454() * class_3532.field_29847));
            entity.method_18799(entity.method_18798().method_18805(0.6, 4.0, 0.6));
        }
    }
    
    @Override
    protected void stop(class_3218 level, class_1429 entity, long gameTime) {
        entity.method_18868().method_18878(ModMemoryModuleTypes.CHARGE_COOLDOWN_TICKS.get(), this.timeBetweenAttacks);
        entity.method_18868().method_18875(class_4140.field_22355);
    }
}