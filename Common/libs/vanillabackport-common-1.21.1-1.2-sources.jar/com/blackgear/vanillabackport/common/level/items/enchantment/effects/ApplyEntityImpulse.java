package com.blackgear.vanillabackport.common.level.items.enchantment.effects;

import com.blackgear.vanillabackport.core.mixin.common.access.PlayerAccessor;
import com.blackgear.vanillabackport.core.util.Utilities.VectorUtils;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_9699;
import net.minecraft.class_9704;
import net.minecraft.class_9721;

public record ApplyEntityImpulse(class_243 direction, class_243 coordinateScale, class_9704 magnitude) implements class_9721 {
	public static final MapCodec<ApplyEntityImpulse> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
		class_243.field_38277.fieldOf("direction").forGetter(ApplyEntityImpulse::direction),
		class_243.field_38277.fieldOf("coordinate_scale").forGetter(ApplyEntityImpulse::coordinateScale),
		class_9704.field_51690.fieldOf("magnitude").forGetter(ApplyEntityImpulse::magnitude)
	).apply(instance, ApplyEntityImpulse::new));
	
	@Override
	public void method_60220(class_3218 level, int enchantmentLevel, class_9699 item, class_1297 entity, class_243 origin) {
		class_243 look = entity.method_5720();
		class_243 direction = VectorUtils.addLocalCoordinates(look, this.direction).method_18806(this.coordinateScale).method_1021(this.magnitude.method_60188(enchantmentLevel));
		entity.method_45319(direction);
		entity.field_6037 = true;
		entity.field_6007 = true;
		if (entity instanceof class_1657 player) {
			PlayerAccessor accessor = (PlayerAccessor) player;
			accessor.setCurrentImpulseContextResetGraceTime(Math.max(accessor.getCurrentImpulseContextResetGraceTime(), 10));
		}
	}
	
	@Override
	public MapCodec<? extends class_9721> method_60219() {
		return CODEC;
	}
}