package com.blackgear.vanillabackport.common.level.blocks;

import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import com.blackgear.vanillabackport.core.util.WorldUtilities.EnvironmentUtils;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2362;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3419;
import net.minecraft.class_5819;

public class EyeblossomPotBlock extends class_2362 {
    public EyeblossomPotBlock(class_2248 content, class_2251 properties) {
        super(content, properties);
    }

    @Override
    public void method_9514(class_2680 state, class_3218 level, class_2338 pos, class_5819 random) {
        if (this.method_9542(state) && level.method_8597().comp_645()) {
            boolean isOpen = this.method_16231() == ModBlocks.OPEN_EYEBLOSSOM.get();
            boolean shouldBeOpen = EnvironmentUtils.isNaturalNight(level);
            if (isOpen != shouldBeOpen) {
                level.method_8652(pos, this.opposite(state), 3);
                EyeblossomBlock.Type type = EyeblossomBlock.Type.fromBoolean(isOpen).transform();
                type.spawnTransformParticle(level, pos, random);
                level.method_8396(null, pos, type.longSwitchSound(), class_3419.field_15245, 1.0F, 1.0F);
            }
        }

        super.method_9514(state, level, pos, random);
    }

    @Override
    public boolean method_9542(class_2680 state) {
        return state.method_27852(ModBlocks.POTTED_OPEN_EYEBLOSSOM.get()) || state.method_27852(ModBlocks.POTTED_CLOSED_EYEBLOSSOM.get());
    }

    private class_2680 opposite(class_2680 state) {
        if (state.method_27852(ModBlocks.POTTED_OPEN_EYEBLOSSOM.get())) {
            return ModBlocks.POTTED_CLOSED_EYEBLOSSOM.get().method_9564();
        } else {
            return state.method_27852(ModBlocks.POTTED_CLOSED_EYEBLOSSOM.get()) ? ModBlocks.POTTED_OPEN_EYEBLOSSOM.get().method_9564() : state;
        }
    }
}