package com.blackgear.vanillabackport.common.level.components;

import com.blackgear.vanillabackport.common.registries.items.ModDataComponents;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.netty.buffer.ByteBuf;
import net.minecraft.class_1799;
import net.minecraft.class_5699;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

public record SwingAnimation(SwingAnimationType type, int duration) {
    public static final SwingAnimation DEFAULT = new SwingAnimation(SwingAnimationType.WHACK, 6);

    public static final Codec<SwingAnimation> CODEC = RecordCodecBuilder.create(instance -> instance.group(
        SwingAnimationType.CODEC.optionalFieldOf("type", DEFAULT.type).forGetter(SwingAnimation::type),
        class_5699.field_33442.optionalFieldOf("duration", DEFAULT.duration).forGetter(SwingAnimation::duration)
    ).apply(instance, SwingAnimation::new));

    public static final class_9139<ByteBuf, SwingAnimation> STREAM_CODEC = class_9139.method_56435(
        SwingAnimationType.STREAM_CODEC, SwingAnimation::type,
        class_9135.field_48550, SwingAnimation::duration,
        SwingAnimation::new
    );
    
    public static SwingAnimation get(class_1799 stack) {
        if (stack == null || stack.method_7960()) return DEFAULT;
        
        var component = stack.method_57824(ModDataComponents.SWING_ANIMATION.get());
        if (component == null) return SwingAnimation.DEFAULT;
        if (component instanceof SwingAnimation animation) return animation;
        
        return parseForeign(component);
    }
    
    @Deprecated(forRemoval = true)
    @SuppressWarnings("DeprecatedIsStillUsed")
    private static @NotNull SwingAnimation parseForeign(Object component) {
        try {
            Class<?> clazz = component.getClass();
            int duration = (int) clazz.getMethod("duration").invoke(component);
            Object rawType = clazz.getMethod("type").invoke(component);
            SwingAnimationType mappedType = SwingAnimationType.WHACK;
            
            if (rawType != null) {
                String typeName = rawType.toString().toLowerCase();
                for (SwingAnimationType type : SwingAnimationType.values()) {
                    if (type.method_15434().equalsIgnoreCase(typeName) || type.name().equalsIgnoreCase(typeName)) {
                        mappedType = type;
                        break;
                    }
                }
            }
            
            return new SwingAnimation(mappedType, duration);
        } catch (Exception e) {
            return SwingAnimation.DEFAULT;
        }
    }
}