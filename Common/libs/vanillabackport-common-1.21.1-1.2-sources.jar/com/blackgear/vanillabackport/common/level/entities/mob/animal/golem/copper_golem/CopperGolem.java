package com.blackgear.vanillabackport.common.level.entities.mob.animal.golem.copper_golem;

import com.blackgear.vanillabackport.client.registries.ModSoundEvents;
import com.blackgear.vanillabackport.common.level.blocks.CopperGolemStatueBlock;
import com.blackgear.vanillabackport.common.level.block_entities.CopperGolemStatueBlockEntity;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.golem.copper_golem.container.ContainerManager;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.golem.copper_golem.container.ContainerUser;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import com.blackgear.vanillabackport.common.registries.entities.ModEntityDataSerializers;
import com.blackgear.vanillabackport.common.registries.entities.ModMemoryModuleTypes;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.blackgear.vanillabackport.core.data.tags.ModItemTags;
import com.blackgear.vanillabackport.core.util.WeatheredData;
import com.mojang.serialization.Dynamic;
import net.minecraft.class_1266;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1308;
import net.minecraft.class_1315;
import net.minecraft.class_1408;
import net.minecraft.class_1427;
import net.minecraft.class_1538;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1928;
import net.minecraft.class_1937;
import net.minecraft.class_2281;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_2745;
import net.minecraft.class_2940;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3489;
import net.minecraft.class_3695;
import net.minecraft.class_3730;
import net.minecraft.class_4095;
import net.minecraft.class_4215;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.class_5147;
import net.minecraft.class_5425;
import net.minecraft.class_5561;
import net.minecraft.class_5712;
import net.minecraft.class_5819;
import net.minecraft.class_5955.class_5811;
import net.minecraft.class_7;
import net.minecraft.class_7094;
import net.minecraft.world.entity.*;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

public class CopperGolem extends class_1427 implements ContainerUser, class_5147 {
    private static final class_2940<class_5811> DATA_WEATHER_STATE = class_2945.method_12791(CopperGolem.class, ModEntityDataSerializers.WEATHERING_COPPER_STATE.get());
    private static final class_2940<CopperGolemState> COPPER_GOLEM_STATE = class_2945.method_12791(CopperGolem.class, ModEntityDataSerializers.COPPER_GOLEM_STATE.get());
    @Nullable private class_2338 openedChestPos;
    @Nullable private UUID lastLightningBoltUUID;
    private long nextWeatheringTick = -1L;
    private int idleAnimationStartTick = 0;
    private final class_7094 idleAnimationState = new class_7094();
    private final class_7094 interactionGetItemAnimationState = new class_7094();
    private final class_7094 interactionGetNoItemAnimationState = new class_7094();
    private final class_7094 interactionDropItemAnimationState = new class_7094();
    private final class_7094 interactionDropNoItemAnimationState = new class_7094();
    public static final class_1304 EQUIPMENT_SLOT_ANTENNA = class_1304.field_6169;
    
    public CopperGolem(class_1299<? extends class_1427> type, class_1937 level) {
        super(type, level);
        this.method_5971();
        this.setState(CopperGolemState.IDLE);
        this.method_5941(class_7.field_9, 16.0F);
        this.method_5941(class_7.field_5, 16.0F);
        this.method_5941(class_7.field_3, -1.0F);
        this.method_18868().method_18878(ModMemoryModuleTypes.TRANSPORT_ITEMS_COOLDOWN_TICKS.get(), this.method_59922().method_43051(60, 100));
    }
    
    @Override
    protected class_1408 method_5965(class_1937 level) {
        CopperGolemPathNavigation navigation = new CopperGolemPathNavigation(this, level);
        navigation.method_6363(true);
        navigation.method_35139(true);
        return navigation;
    }
    
    public static class_5132.class_5133 createAttributes() {
        return class_1308.method_26828()
            .method_26868(class_5134.field_23719, 0.2F)
            .method_26868(class_5134.field_47761, 1.0)
            .method_26868(class_5134.field_23716, 12.0);
    }
    
    public CopperGolemState getState() {
        return this.field_6011.method_12789(COPPER_GOLEM_STATE);
    }
    
    public void setState(CopperGolemState state) {
        this.field_6011.method_12778(COPPER_GOLEM_STATE, state);
    }

    public class_5811 getWeatherState() {
        return this.field_6011.method_12789(DATA_WEATHER_STATE);
    }

    public void setWeatherState(class_5811 state) {
        this.field_6011.method_12778(DATA_WEATHER_STATE, state);
    }
    
    public void setOpenedChestPos(class_2338 openedChestPos) {
        this.openedChestPos = openedChestPos;
    }
    
    public void clearOpenedChestPos() {
        this.openedChestPos = null;
    }
    
    public class_7094 getIdleAnimationState() {
        return this.idleAnimationState;
    }
    
    public class_7094 getInteractionGetItemAnimationState() {
        return this.interactionGetItemAnimationState;
    }
    
    public class_7094 getInteractionGetNoItemAnimationState() {
        return this.interactionGetNoItemAnimationState;
    }
    
    public class_7094 getInteractionDropItemAnimationState() {
        return this.interactionDropItemAnimationState;
    }
    
    public class_7094 getInteractionDropNoItemAnimationState() {
        return this.interactionDropNoItemAnimationState;
    }
    
    @Override
    protected class_4095.class_5303<CopperGolem> method_28306() {
        return CopperGolemAi.brainProvider();
    }
    
    @Override
    protected class_4095<?> method_18867(Dynamic<?> dynamic) {
        return CopperGolemAi.makeBrain(this.method_28306().method_28335(dynamic));
    }
    
    @Override @SuppressWarnings("unchecked")
    public class_4095<CopperGolem> method_18868() {
        return (class_4095<CopperGolem>) super.method_18868();
    }
    
    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        super.method_5693(builder);
        builder.method_56912(DATA_WEATHER_STATE, class_5811.field_28704);
        builder.method_56912(COPPER_GOLEM_STATE, CopperGolemState.IDLE);
    }
    
    @Override
    public void method_5652(class_2487 compound) {
        super.method_5652(compound);
        compound.method_10544("next_weather_age", this.nextWeatheringTick);
        compound.method_10582("weather_state", this.getWeatherState().method_15434());
    }
    
    @Override
    public void method_5749(class_2487 compound) {
        super.method_5749(compound);
        this.nextWeatheringTick = compound.method_10545("next_weather_age") ? compound.method_10537("next_weather_age") : -1L;
        this.setWeatherState(WeatheredData.fromName(compound.method_10558("weather_state")));
    }
    
    @Override
    protected void method_5958() {
        class_3218 level = (class_3218) this.method_37908();
        class_3695 profiler = level.method_16107();
        profiler.method_15396("copperGolemBrain");
        this.method_18868().method_19542(level, this);
        profiler.method_15405("copperGolemActivityUpdate");
        CopperGolemAi.updateActivity(this);
        profiler.method_15407();
        super.method_5958();
    }
    
    @Override
    public void method_5773() {
        super.method_5773();
        if (this.method_37908().method_8608()) {
            if (!this.method_5987()) {
                this.setupAnimationStates();
            }
        } else {
            this.updateWeathering((class_3218) this.method_37908(), this.method_37908().method_8409(), this.method_37908().method_8510());
        }
    }
    
    @Override
    protected class_1269 method_5992(class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        class_1937 level = this.method_37908();
        if (stack.method_7960()) {
            class_1799 equippedItem = this.method_6047();
            if (!equippedItem.method_7960()) {
                class_4215.method_19949(this, equippedItem, player.method_19538());
                this.method_6122(class_1268.field_5808, class_1799.field_8037);
                return class_1269.method_29236(level.field_9236);
            }
        }
        
        if (stack.method_31574(class_1802.field_8868) && this.method_27072()) {
            if (level instanceof class_3218) {
                this.method_6636(class_3419.field_15248);
                this.method_32875(class_5712.field_28730, player);
                stack.method_7970(1, player, method_56079(hand));
            }
            
            return class_1269.method_29236(level.field_9236);
        } else if (level.field_9236) {
            return class_1269.field_5811;
        } else if (stack.method_31574(class_1802.field_20414) && this.nextWeatheringTick != -2L) {
            class_2338 pos = this.method_24515();
            level.method_8444(null, 3003, pos, 0);
            level.method_8396(null, pos, class_3417.field_29543, class_3419.field_15245, 1.0F, 1.0F);
            this.nextWeatheringTick = -2L;
            stack.method_57008(1, player);
            return class_1269.field_5812;
        } else if (stack.method_31573(class_3489.field_42612) && this.nextWeatheringTick == -2L) {
            level.method_43129(null, this, class_3417.field_29541, this.method_5634(), 1.0F, 1.0F);
            level.method_8444(null, 3004, this.method_24515(), 0);
            this.nextWeatheringTick = -1L;
            stack.method_7970(1, player, method_56079(hand));
            return class_1269.field_5812;
        } else {
            if (stack.method_31573(class_3489.field_42612)) {
                class_5811 weatherState = this.getWeatherState();
                if (weatherState != class_5811.field_28704) {
                    level.method_43129(null, this, class_3417.field_29541, this.method_5634(), 1.0F, 1.0F);
                    level.method_8444(null, 3005, this.method_24515(), 0);
                    this.nextWeatheringTick = -1L;
                    this.field_6011.method_49743(DATA_WEATHER_STATE, WeatheredData.previous(weatherState), true);
                    stack.method_7970(1, player, method_56079(hand));
                    return class_1269.field_5812;
                }
            }
            
            return super.method_5992(player, hand);
        }
    }
    
    private void updateWeathering(class_3218 level, class_5819 random, long gameTime) {
        if (this.nextWeatheringTick != -2L) {
            if (this.nextWeatheringTick == -1L) {
                this.nextWeatheringTick = gameTime + random.method_39332(VanillaBackport.COMMON_CONFIG.golemWeatheringTickFrom.get(), VanillaBackport.COMMON_CONFIG.golemWeatheringTickTo.get());
            } else {
                class_5811 weatherState = this.getWeatherState();
                boolean isFullyOxidized = weatherState.equals(class_5811.field_28707);
                if (gameTime >= this.nextWeatheringTick && !isFullyOxidized) {
                    class_5811 newState = WeatheredData.next(weatherState);
                    boolean isNewStateFullyOxidized = newState.equals(class_5811.field_28707);
                    this.setWeatherState(newState);
                    this.nextWeatheringTick = isNewStateFullyOxidized
                        ? 0L
                        : this.nextWeatheringTick + random.method_39332(VanillaBackport.COMMON_CONFIG.golemWeatheringTickFrom.get(), VanillaBackport.COMMON_CONFIG.golemWeatheringTickTo.get());
                }
                
                if (isFullyOxidized && this.canTurnToStatue(level)) {
                    this.turnToStatue(level);
                }
            }
        }
    }
    
    private boolean canTurnToStatue(class_1937 level) {
        return level.method_8320(this.method_24515()).method_26215() && level.method_8409().method_43057() <= 0.0058F;
    }
    
    private void turnToStatue(class_3218 level) {
        class_2338 pos = this.method_24515();
        
        level.method_8501(
            pos,
            ModBlocks.OXIDIZED_COPPER_GOLEM_STATUE.get()
                .method_9564()
                .method_11657(CopperGolemStatueBlock.POSE, CopperGolemStatueBlock.Pose.values()[this.field_5974.method_43051(0, CopperGolemStatueBlock.Pose.values().length)])
                .method_11657(CopperGolemStatueBlock.FACING, class_2350.method_10150(this.method_36454()))
        );
        
        if (level.method_8321(pos) instanceof CopperGolemStatueBlockEntity golem) {
            golem.createStatue(this);
            this.method_60973();
            this.method_31472();
            this.method_43077(ModSoundEvents.COPPER_GOLEM_BECOME_STATUE.get());
            if (this.method_60953()) {
                this.method_5932(true, level.method_8450().method_8355(class_1928.field_19393));
            }
        }
    }
    
    private void setupAnimationStates() {
        switch (this.getState()) {
            case IDLE:
                this.interactionGetNoItemAnimationState.method_41325();
                this.interactionGetItemAnimationState.method_41325();
                this.interactionDropItemAnimationState.method_41325();
                this.interactionDropNoItemAnimationState.method_41325();
                if (this.idleAnimationStartTick == this.field_6012) {
                    this.idleAnimationState.method_41322(this.field_6012);
                } else if (this.idleAnimationStartTick == 0) {
                    this.idleAnimationStartTick = this.field_6012 + this.field_5974.method_43051(200, 240);
                }
                
                if (this.field_6012 == this.idleAnimationStartTick + 10.0F) {
                    this.playHeadSpinSound();
                    this.idleAnimationStartTick = 0;
                }
                break;
            case GETTING_ITEM:
                this.idleAnimationState.method_41325();
                this.idleAnimationStartTick = 0;
                this.interactionGetNoItemAnimationState.method_41325();
                this.interactionDropItemAnimationState.method_41325();
                this.interactionDropNoItemAnimationState.method_41325();
                this.interactionGetItemAnimationState.method_41324(this.field_6012);
                break;
            case GETTING_NO_ITEM:
                this.idleAnimationState.method_41325();
                this.idleAnimationStartTick = 0;
                this.interactionGetItemAnimationState.method_41325();
                this.interactionDropNoItemAnimationState.method_41325();
                this.interactionDropItemAnimationState.method_41325();
                this.interactionGetNoItemAnimationState.method_41324(this.field_6012);
                break;
            case DROPPING_ITEM:
                this.idleAnimationState.method_41325();
                this.idleAnimationStartTick = 0;
                this.interactionGetItemAnimationState.method_41325();
                this.interactionGetNoItemAnimationState.method_41325();
                this.interactionDropNoItemAnimationState.method_41325();
                this.interactionDropItemAnimationState.method_41324(this.field_6012);
                break;
            case DROPPING_NO_ITEM:
                this.idleAnimationState.method_41325();
                this.idleAnimationStartTick = 0;
                this.interactionGetItemAnimationState.method_41325();
                this.interactionGetNoItemAnimationState.method_41325();
                this.interactionDropItemAnimationState.method_41325();
                this.interactionDropNoItemAnimationState.method_41324(this.field_6012);
        }
    }

    public void spawn(class_5811 state) {
        this.setWeatherState(state);
        this.playSpawnSound();
    }

    @Override @Nullable
    public class_1315 method_5943(class_5425 level, class_1266 difficulty, class_3730 spawnType, @Nullable class_1315 spawnGroupData) {
        this.playSpawnSound();
        return super.method_5943(level, difficulty, spawnType, spawnGroupData);
    }
    
    public void playSpawnSound() {
        this.method_43077(ModSoundEvents.COPPER_GOLEM_SPAWN.get());
    }
    
    private void playHeadSpinSound() {
        if (!this.method_5701()) {
            this.method_37908().method_8486(this.method_23317(), this.method_23318(), this.method_23321(), this.getSpinHeadSound(), this.method_5634(), 1.0F, 1.0F, false);
        }
    }
    
    @Override @Nullable
    protected class_3414 method_6011(class_1282 source) {
        return CopperGolemOxidationLevels.getOxidationLevel(this.getWeatherState()).hurtSound();
    }
    
    @Override @Nullable
    protected class_3414 method_6002() {
        return CopperGolemOxidationLevels.getOxidationLevel(this.getWeatherState()).deathSound();
    }
    
    @Override
    protected void method_5712(class_2338 pos, class_2680 state) {
        this.method_43077(CopperGolemOxidationLevels.getOxidationLevel(this.getWeatherState()).stepSound());
    }
    
    private class_3414 getSpinHeadSound() {
        return CopperGolemOxidationLevels.getOxidationLevel(this.getWeatherState()).spinHeadSound();
    }
    
    @Override
    protected class_243 method_29919() {
        return new class_243(0.0, 0.75F * this.method_5751(), 0.0);
    }
    
    @Override
    public boolean hasContainerOpen(class_5561 container, class_2338 blockPos) {
        if (this.openedChestPos == null) {
            return false;
        } else {
            class_2680 blockState = this.method_37908().method_8320(this.openedChestPos);
            return this.openedChestPos.equals(blockPos)
                || blockState.method_26204() instanceof class_2281
                && blockState.method_11654(class_2281.field_10770) != class_2745.field_12569
                && ContainerManager.getConnectedBlockPos(this.openedChestPos, blockState).equals(blockPos);
        }
    }

    @Override
    public double getContainerInteractionRange() {
        return 3.0;
    }

    @Override
    public void method_6636(class_3419 source) {
        this.method_37908().method_43129(null, this, ModSoundEvents.COPPER_GOLEM_SHEAR.get(), source, 1.0F, 1.0F);
        class_1799 itemStack = this.method_6118(EQUIPMENT_SLOT_ANTENNA);
        this.method_5673(EQUIPMENT_SLOT_ANTENNA, class_1799.field_8037);
        this.method_5699(itemStack, 1.5F);
    }
    
    @Override
    public boolean method_27072() {
        return this.method_5805() && this.method_6118(EQUIPMENT_SLOT_ANTENNA).method_31573(ModItemTags.SHEARABLE_FROM_COPPER_GOLEM);
    }
    
    @Override
    protected void method_16078() {
        super.method_16078();
        this.method_60973();
    }
    
    @Override
    protected void method_6074(class_1282 source, float damage) {
        super.method_6074(source, damage);
        this.setState(CopperGolemState.IDLE);
    }
    
    @Override
    public void method_5800(class_3218 level, class_1538 lightning) {
        super.method_5800(level, lightning);
        UUID lightningBoltUUID = lightning.method_5667();
        if (!lightningBoltUUID.equals(this.lastLightningBoltUUID)) {
            this.lastLightningBoltUUID = lightningBoltUUID;
            class_5811 weatherState = this.getWeatherState();
            if (weatherState != class_5811.field_28704) {
                this.nextWeatheringTick = -1L;
                this.field_6011.method_49743(DATA_WEATHER_STATE, WeatheredData.previous(weatherState), true);
            }
        }
    }
}