package com.blackgear.vanillabackport.common.level.entities.ai.behavior;

import com.blackgear.vanillabackport.common.api.extensions.entity.mounts.ControllableMob;
import com.blackgear.vanillabackport.common.registries.entities.ModMemoryModuleTypes;
import com.blackgear.vanillabackport.common.registries.items.ModDataComponents;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1314;
import net.minecraft.class_3218;
import net.minecraft.class_4097;
import net.minecraft.class_4102;
import net.minecraft.class_4140;
import net.minecraft.class_4141;

public class SpearApproach extends class_4097<class_1314> {
    private final double speedModifierWhenRepositioning;
    private final float approachDistanceSq;

    public SpearApproach(double speedModifierWhenRepositioning, float approachDistance) {
        super(Map.of(ModMemoryModuleTypes.SPEAR_STATUS.get(), class_4141.field_18457));
        this.speedModifierWhenRepositioning = speedModifierWhenRepositioning;
        this.approachDistanceSq = approachDistance * approachDistance;
    }

    private boolean ableToAttack(class_1314 mob) {
        return this.getTarget(mob) != null && mob.method_6047().method_57826(ModDataComponents.KINETIC_WEAPON.get());
    }

    @Override
    protected boolean checkExtraStartConditions(class_3218 level, class_1314 mob) {
        return this.ableToAttack(mob) && !mob.method_6115();
    }

    @Override
    protected void start(class_3218 level, class_1314 mob, long gameTime) {
        mob.method_19540(true);
        mob.method_18868().method_18878(ModMemoryModuleTypes.SPEAR_STATUS.get(), SpearStatus.APPROACH);
        super.method_18920(level, mob, gameTime);
    }

    @Nullable
    private class_1309 getTarget(class_1314 mob) {
        return mob.method_18868().method_18904(class_4140.field_22355).orElse(null);
    }

    @Override
    protected boolean canStillUse(class_3218 level, class_1314 mob, long gameTime) {
        return this.ableToAttack(mob) && this.farEnough(mob);
    }

    private boolean farEnough(class_1314 mob) {
        class_1309 target = this.getTarget(mob);
        double targetDistSqr = mob.method_5649(target.method_23317(), target.method_23318(), target.method_23321());
        return targetDistSqr > this.approachDistanceSq;
    }

    @Override
    protected void tick(class_3218 level, class_1314 mob, long gameTime) {
        class_1309 target = this.getTarget(mob);
        class_1297 mount = mob.method_5668();
        float speedModifier = ControllableMob.of(mount).chargeSpeedModifier();

        mob.method_18868().method_18878(class_4140.field_18446, new class_4102(target, true));
        mob.method_5942().method_6335(target, speedModifier * this.speedModifierWhenRepositioning);
    }

    @Override
    protected void stop(class_3218 level, class_1314 mob, long gameTime) {
        mob.method_5942().method_6340();
        mob.method_18868().method_18878(ModMemoryModuleTypes.SPEAR_STATUS.get(), SpearStatus.CHARGING);
    }

    @Override
    protected boolean method_18915(long gameTime) {
        return false;
    }
}