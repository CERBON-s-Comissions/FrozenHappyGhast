package com.blackgear.vanillabackport.common.level.recipes;

import com.blackgear.platform.common.v2.recipe.DynamicRecipeProvider;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import com.blackgear.vanillabackport.common.registries.items.ModItems;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.blackgear.vanillabackport.core.data.tags.ModItemTags;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_2246;
import net.minecraft.class_2447;
import net.minecraft.class_2450;
import net.minecraft.class_2454;
import net.minecraft.class_2960;
import net.minecraft.class_3489;
import net.minecraft.class_5797;
import net.minecraft.class_7225;
import net.minecraft.class_7800;
import net.minecraft.class_8790;
import net.minecraft.data.recipes.*;
import java.util.function.Consumer;
import java.util.function.Function;

public class VanillaDynamicRecipes extends DynamicRecipeProvider {
    @Override
    public void buildRecipes(class_8790 output, class_7225.class_7874 provider, Function<String, class_2960> path) {
        buildBundlesOfBraveryRecipes(output, path);
        buildSpringToLifeRecipes(output, path);
        buildChaseTheSkiesRecipes(output, path);
        buildCopperAgeRecipes(output);
        buildMountsOfMayhemRecipes(output, path);
        buildWildernessBoundRecipes(output, path);
    }
    
    private static void buildBundlesOfBraveryRecipes(class_8790 output, Function<String, class_2960> path) {
        configurableRecipe(output, path, "bundle",
            class_2447.method_10437(class_7800.field_40638, class_1802.field_27023)
                .method_10434('-', class_1802.field_8276)
                .method_10434('#', class_1802.field_8745)
                .method_10439("-")
                .method_10439("#")
                .method_10429("has_string", has(class_1802.field_8276)),
            VanillaBackport.COMMON_CONFIG.bundleRecipe.get());
    }
    
    private static void buildSpringToLifeRecipes(class_8790 output, Function<String, class_2960> path) {
        class_2450.method_10447(class_7800.field_40640, class_1802.field_8741)
            .method_10454(class_2246.field_46282)
            .method_10454(class_1802.field_8479)
            .method_10446(ModItemTags.EGGS)
            .method_10442("has_carved_pumpkin", has(class_2246.field_10147))
            .method_10442("has_pumpkin", has(class_2246.field_46282))
            .method_17972(output, path.apply("pumpkin_pie"));
        
        class_2447.method_10437(class_7800.field_40640, class_2246.field_10183)
            .method_10434('A', class_1802.field_8103)
            .method_10434('B', class_1802.field_8479)
            .method_10434('C', class_1802.field_8861)
            .method_10433('E', ModItemTags.EGGS)
            .method_10439("AAA")
            .method_10439("BEB")
            .method_10439("CCC")
            .method_10429("has_egg", has(ModItemTags.EGGS))
            .method_17972(output, path.apply("cake"));
        
        configurableRecipe(output, path, "lodestone",
            class_2447.method_10437(class_7800.field_40635, class_2246.field_23261)
                .method_10434('S', class_1802.field_8525)
                .method_10434('#', class_1802.field_8620)
                .method_10439("SSS")
                .method_10439("S#S")
                .method_10439("SSS")
                .method_10429("has_iron_ingot", has(class_1802.field_8620))
                .method_10429("has_lodestone", has(class_1802.field_23256)),
            VanillaBackport.COMMON_CONFIG.lodestoneRecipe.get());
    }
    
    private static void buildChaseTheSkiesRecipes(class_8790 output, Function<String, class_2960> path) {
        configurableRecipe(output, path, "lead",
            class_2447.method_10436(class_7800.field_40638, class_1802.field_8719, 2)
                .method_10434('~', class_1802.field_8276)
                .method_10439("~~ ")
                .method_10439("~~ ")
                .method_10439("  ~")
                .method_10429("has_string", has(class_1802.field_8276)),
            VanillaBackport.COMMON_CONFIG.leadRecipe.get());
        
        configurableRecipe(output, path, "saddle",
            class_2447.method_10437(class_7800.field_40639, class_1802.field_8175)
                .method_10434('X', class_1802.field_8745)
                .method_10434('#', class_1802.field_8620)
                .method_10439(" X ")
                .method_10439("X#X")
                .method_10429("has_leather", has(class_1802.field_8745)),
            VanillaBackport.COMMON_CONFIG.saddleRecipe.get());
    }
    
    private static void buildCopperAgeRecipes(class_8790 output) {
        if (VanillaBackport.COMMON_CONFIG.hasCopperNuggets.get()) {
            nineBlockStorageRecipesWithCustomPacking(output, class_7800.field_40642, ModItems.COPPER_NUGGET.get(), class_7800.field_40642, class_1802.field_27022, "copper_ingot_from_nuggets", "copper_ingot");
            
            class_2454.method_17802(
                    class_1856.method_8091(
                        ModItems.COPPER_PICKAXE.get(),
                        ModItems.COPPER_SHOVEL.get(),
                        ModItems.COPPER_AXE.get(),
                        ModItems.COPPER_HOE.get(),
                        ModItems.COPPER_SWORD.get(),
                        ModItems.COPPER_SPEAR.get(),
                        ModItems.COPPER_HELMET.get(),
                        ModItems.COPPER_CHESTPLATE.get(),
                        ModItems.COPPER_LEGGINGS.get(),
                        ModItems.COPPER_BOOTS.get(),
                        ModItems.COPPER_HORSE_ARMOR.get(),
                        ModItems.COPPER_NAUTILUS_ARMOR.get()
                    ),
                    class_7800.field_40642,
                    ModItems.COPPER_NUGGET.get(),
                    0.1F,
                    200
                )
                .method_10469("has_copper_pickaxe", has(ModItems.COPPER_PICKAXE.get()))
                .method_10469("has_copper_shovel", has(ModItems.COPPER_SHOVEL.get()))
                .method_10469("has_copper_axe", has(ModItems.COPPER_AXE.get()))
                .method_10469("has_copper_hoe", has(ModItems.COPPER_HOE.get()))
                .method_10469("has_copper_sword", has(ModItems.COPPER_SWORD.get()))
                .method_10469("has_copper_spear", has(ModItems.COPPER_SPEAR.get()))
                .method_10469("has_copper_helmet", has(ModItems.COPPER_HELMET.get()))
                .method_10469("has_copper_chestplate", has(ModItems.COPPER_CHESTPLATE.get()))
                .method_10469("has_copper_leggings", has(ModItems.COPPER_LEGGINGS.get()))
                .method_10469("has_copper_boots", has(ModItems.COPPER_BOOTS.get()))
                .method_10469("has_copper_horse_armor", has(ModItems.COPPER_HORSE_ARMOR.get()))
                .method_10469("has_copper_nautilus_armor", has(ModItems.COPPER_NAUTILUS_ARMOR.get()))
                .method_36443(output, getSmeltingRecipeName(ModItems.COPPER_NUGGET.get()));
            class_2454.method_10473(
                    class_1856.method_8091(
                        ModItems.COPPER_PICKAXE.get(),
                        ModItems.COPPER_SHOVEL.get(),
                        ModItems.COPPER_AXE.get(),
                        ModItems.COPPER_HOE.get(),
                        ModItems.COPPER_SWORD.get(),
                        ModItems.COPPER_SPEAR.get(),
                        ModItems.COPPER_HELMET.get(),
                        ModItems.COPPER_CHESTPLATE.get(),
                        ModItems.COPPER_LEGGINGS.get(),
                        ModItems.COPPER_BOOTS.get(),
                        ModItems.COPPER_HORSE_ARMOR.get(),
                        ModItems.COPPER_NAUTILUS_ARMOR.get()
                    ),
                    class_7800.field_40642,
                    ModItems.COPPER_NUGGET.get(),
                    0.1F,
                    100
                )
                .method_10469("has_copper_pickaxe", has(ModItems.COPPER_PICKAXE.get()))
                .method_10469("has_copper_shovel", has(ModItems.COPPER_SHOVEL.get()))
                .method_10469("has_copper_axe", has(ModItems.COPPER_AXE.get()))
                .method_10469("has_copper_hoe", has(ModItems.COPPER_HOE.get()))
                .method_10469("has_copper_sword", has(ModItems.COPPER_SWORD.get()))
                .method_10469("has_copper_spear", has(ModItems.COPPER_SPEAR.get()))
                .method_10469("has_copper_helmet", has(ModItems.COPPER_HELMET.get()))
                .method_10469("has_copper_chestplate", has(ModItems.COPPER_CHESTPLATE.get()))
                .method_10469("has_copper_leggings", has(ModItems.COPPER_LEGGINGS.get()))
                .method_10469("has_copper_boots", has(ModItems.COPPER_BOOTS.get()))
                .method_10469("has_copper_horse_armor", has(ModItems.COPPER_HORSE_ARMOR.get()))
                .method_10469("has_copper_nautilus_armor", has(ModItems.COPPER_NAUTILUS_ARMOR.get()))
                .method_36443(output, getBlastingRecipeName(ModItems.COPPER_NUGGET.get()));
        }
        
        if (VanillaBackport.COMMON_CONFIG.hasCopperToolSet.get()) {
            class_2447.method_10437(class_7800.field_40639, ModItems.COPPER_HELMET.get())
                .method_10434('X', class_1802.field_27022)
                .method_10439("XXX")
                .method_10439("X X")
                .method_10429("has_copper_ingot", has(class_1802.field_27022))
                .method_10431(output);
            class_2447.method_10437(class_7800.field_40639, ModItems.COPPER_CHESTPLATE.get())
                .method_10434('X', class_1802.field_27022)
                .method_10439("X X")
                .method_10439("XXX")
                .method_10439("XXX")
                .method_10429("has_copper_ingot", has(class_1802.field_27022))
                .method_10431(output);
            class_2447.method_10437(class_7800.field_40639, ModItems.COPPER_LEGGINGS.get())
                .method_10434('X', class_1802.field_27022)
                .method_10439("XXX")
                .method_10439("X X")
                .method_10439("X X")
                .method_10429("has_copper_ingot", has(class_1802.field_27022))
                .method_10431(output);
            class_2447.method_10437(class_7800.field_40639, ModItems.COPPER_BOOTS.get())
                .method_10434('X', class_1802.field_27022)
                .method_10439("X X")
                .method_10439("X X")
                .method_10429("has_copper_ingot", has(class_1802.field_27022))
                .method_10431(output);
            
            class_2447.method_10437(class_7800.field_40638, ModItems.COPPER_AXE.get())
                .method_10434('#', class_1802.field_8600)
                .method_10434('X', class_1802.field_27022)
                .method_10439("XX")
                .method_10439("X#")
                .method_10439(" #")
                .method_10429("has_copper_ingot", has(class_1802.field_27022))
                .method_10431(output);
            class_2447.method_10437(class_7800.field_40638, ModItems.COPPER_HOE.get())
                .method_10434('#', class_1802.field_8600)
                .method_10434('X', class_1802.field_27022)
                .method_10439("XX")
                .method_10439(" #")
                .method_10439(" #")
                .method_10429("has_copper_ingot", has(class_1802.field_27022))
                .method_10431(output);
            class_2447.method_10437(class_7800.field_40638, ModItems.COPPER_PICKAXE.get())
                .method_10434('#', class_1802.field_8600)
                .method_10434('X', class_1802.field_27022)
                .method_10439("XXX")
                .method_10439(" # ")
                .method_10439(" # ")
                .method_10429("has_copper_ingot", has(class_1802.field_27022))
                .method_10431(output);
            class_2447.method_10437(class_7800.field_40638, ModItems.COPPER_SHOVEL.get())
                .method_10434('#', class_1802.field_8600)
                .method_10434('X', class_1802.field_27022)
                .method_10439("X")
                .method_10439("#")
                .method_10439("#")
                .method_10429("has_copper_ingot", has(class_1802.field_27022))
                .method_10431(output);
            class_2447.method_10437(class_7800.field_40639, ModItems.COPPER_SWORD.get())
                .method_10434('#', class_1802.field_8600)
                .method_10434('X', class_1802.field_27022)
                .method_10439("X")
                .method_10439("X")
                .method_10439("#")
                .method_10429("has_copper_ingot", has(class_1802.field_27022))
                .method_10431(output);
        }
        
        class_2447.method_10436(class_7800.field_40636, class_2246.field_47048, 1)
            .method_10434('#', class_1802.field_27022)
            .method_10439("##")
            .method_10439("##")
            .method_10429(getHasName(class_1802.field_27022), has(class_1802.field_27022))
            .method_17972(output, class_2960.method_60656("copper_trapdoor"));
    }
    
    private static void buildMountsOfMayhemRecipes(class_8790 output, Function<String, class_2960> path) {
        if (VanillaBackport.COMMON_CONFIG.hasSpears.get()) {
            class_2447.method_10437(class_7800.field_40639, ModItems.DIAMOND_SPEAR.get())
                .method_10434('#', class_1802.field_8600)
                .method_10434('X', class_1802.field_8477)
                .method_10439("  X")
                .method_10439(" # ")
                .method_10439("#  ")
                .method_10429("has_diamond", has(class_1802.field_8477))
                .method_10431(output);
            class_2447.method_10437(class_7800.field_40639, ModItems.GOLDEN_SPEAR.get())
                .method_10434('#', class_1802.field_8600)
                .method_10434('X', class_1802.field_8695)
                .method_10439("  X")
                .method_10439(" # ")
                .method_10439("#  ")
                .method_10429("has_gold_ingot", has(class_1802.field_8695))
                .method_10431(output);
            class_2447.method_10437(class_7800.field_40639, ModItems.IRON_SPEAR.get())
                .method_10434('#', class_1802.field_8600)
                .method_10434('X', class_1802.field_8620)
                .method_10439("  X")
                .method_10439(" # ")
                .method_10439("#  ")
                .method_10429("has_iron_ingot", has(class_1802.field_8620))
                .method_10431(output);
            class_2447.method_10437(class_7800.field_40639, ModItems.STONE_SPEAR.get())
                .method_10434('#', class_1802.field_8600)
                .method_10433('X', class_3489.field_23802)
                .method_10439("  X")
                .method_10439(" # ")
                .method_10439("#  ")
                .method_10429("has_cobblestone", has(class_3489.field_23802))
                .method_10431(output);
            class_2447.method_10437(class_7800.field_40639, ModItems.WOODEN_SPEAR.get())
                .method_10434('#', class_1802.field_8600)
                .method_10433('X', class_3489.field_15537)
                .method_10439("  X")
                .method_10439(" # ")
                .method_10439("#  ")
                .method_10429("has_stick", has(class_1802.field_8600))
                .method_10431(output);
            
            if (VanillaBackport.COMMON_CONFIG.hasCopperToolSet.get()) {
                class_2447.method_10437(class_7800.field_40639, ModItems.COPPER_SPEAR.get())
                    .method_10434('#', class_1802.field_8600)
                    .method_10434('X', class_1802.field_27022)
                    .method_10439("  X")
                    .method_10439(" # ")
                    .method_10439("#  ")
                    .method_10429("has_copper_ingot", has(class_1802.field_27022))
                    .method_10431(output);
            }
        }
        
        class_2454.method_17802(
                class_1856.method_8091(
                    ModItems.IRON_SPEAR.get(),
                    ModItems.IRON_NAUTILUS_ARMOR.get()
                ),
                class_7800.field_40642,
                class_1802.field_8675,
                0.1F,
                200
            )
            .method_10469("has_iron_spear", has(ModItems.IRON_SPEAR.get()))
            .method_10469("has_iron_nautilus_armor", has(ModItems.IRON_NAUTILUS_ARMOR.get()))
            .method_17972(output, path.apply(getSmeltingRecipeName(class_1802.field_8675)));
        
        class_2454.method_17802(
                class_1856.method_8091(
                    ModItems.GOLDEN_SPEAR.get(),
                    ModItems.GOLDEN_NAUTILUS_ARMOR.get()
                ),
                class_7800.field_40642,
                class_1802.field_8397,
                0.1F,
                200
            )
            .method_10469("has_golden_spear", has(ModItems.GOLDEN_SPEAR.get()))
            .method_10469("has_golden_nautilus_armor", has(ModItems.GOLDEN_NAUTILUS_ARMOR.get()))
            .method_17972(output, path.apply(getSmeltingRecipeName(class_1802.field_8397)));
        
        class_2454.method_10473(
                class_1856.method_8091(
                    ModItems.GOLDEN_SPEAR.get(),
                    ModItems.GOLDEN_NAUTILUS_ARMOR.get()
                ),
                class_7800.field_40642,
                class_1802.field_8397,
                0.1F,
                200
            )
            .method_10469("has_golden_spear", has(ModItems.GOLDEN_SPEAR.get()))
            .method_10469("has_golden_nautilus_armor", has(ModItems.GOLDEN_NAUTILUS_ARMOR.get()))
            .method_17972(output, path.apply(getBlastingRecipeName(class_1802.field_8397)));
        
        class_2454.method_10473(
                class_1856.method_8091(
                    ModItems.IRON_SPEAR.get(),
                    ModItems.IRON_NAUTILUS_ARMOR.get()
                ),
                class_7800.field_40642,
                class_1802.field_8675,
                0.1F,
                200
            )
            .method_10469("has_iron_spear", has(ModItems.IRON_SPEAR.get()))
            .method_10469("has_iron_nautilus_armor", has(ModItems.IRON_NAUTILUS_ARMOR.get()))
            .method_17972(output, path.apply(getBlastingRecipeName(class_1802.field_8675)));
    }
    
    private static void buildWildernessBoundRecipes(class_8790 output, Function<String, class_2960> path) {
        class_2450.method_10447(class_7800.field_40640, class_1802.field_8208)
            .method_10446(ModItemTags.MUSHROOMS)
            .method_10446(ModItemTags.MUSHROOMS)
            .method_10454(class_1802.field_8428)
            .method_10452("mushroom_stew")
            .method_10442("has_mushroom_stew", has(class_1802.field_8208))
            .method_10442("has_bowl", has(class_1802.field_8428))
            .method_10442("has_mushrooms", has(ModItemTags.MUSHROOMS))
            .method_17972(output, path.apply("mushroom_stew"));
        
        class_2450.method_10447(class_7800.field_40640, class_1802.field_8308)
            .method_10454(class_1802.field_8512)
            .method_10454(class_1802.field_8752)
            .method_10454(class_1802.field_8428)
            .method_10454(class_1802.field_8179)
            .method_10454(ModBlocks.SHELF_MUSHROOM.get())
            .method_10452("rabbit_stew")
            .method_10442("has_cooked_rabbit", has(class_1802.field_8752))
            .method_17972(output, path.apply(getConversionRecipeName(class_1802.field_8308, ModBlocks.SHELF_MUSHROOM.get())));
    }
    
    protected static void configurableRecipe(class_8790 output, Function<String, class_2960> path, String name, class_5797 builder, RecipeStrategy toggle) {
        switch (toggle) {
            case APPEND -> builder.method_17972(output, path.apply(name));
            case REPLACE -> builder.method_17972(output, class_2960.method_60656(name));
            case IGNORE -> {}
        }
    }
}