package com.blackgear.vanillabackport.common.level.entities.mob.animal.golem.copper_golem.container;

import com.blackgear.platform.core.Environment;
import java.util.List;
import net.minecraft.class_1263;
import net.minecraft.class_1309;
import net.minecraft.class_2586;
import net.minecraft.class_3218;

public class DefaultContainerAdapter implements ContainerAdapter {
    @Override
    public boolean supports(class_2586 blockEntity) {
        return blockEntity instanceof class_1263;
    }
    
    @Override
    public void startOpen(class_2586 blockEntity, ContainerUser user) {
        if (ContainerManager.isValid(blockEntity, user) && blockEntity.method_10997() instanceof class_3218 server) {
            ((class_1263) blockEntity).method_5435(Environment.getOrCreateFakePlayer(server));
        }
    }
    
    @Override
    public void stopOpen(class_2586 blockEntity, ContainerUser user) {
        if (ContainerManager.isValid(blockEntity, user) && blockEntity.method_10997() instanceof class_3218 server) {
            ((class_1263) blockEntity).method_5432(Environment.getOrCreateFakePlayer(server));
        }
    }
    
    @Override
    public List<class_1309> getEntitiesWithContainerOpen(class_2586 blockEntity) {
        return ContainerManager.getEntitiesWithContainerOpen(
            blockEntity,
            ContainerManager.DEFAULT_RANGE,
            (entity, pos) -> entity instanceof ContainerUser user && user.hasContainerOpen(null, pos)
        );
    }
}