package com.blackgear.vanillabackport.common.level.blocks;

import com.blackgear.vanillabackport.common.level.block_entities.CopperChestBlockEntity;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlockEntities;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import com.blackgear.vanillabackport.core.data.tags.ModBlockTags;
import com.google.common.base.Suppliers;
import java.util.Map;
import java.util.Optional;
import java.util.function.Supplier;
import net.minecraft.class_1263;
import net.minecraft.class_1264;
import net.minecraft.class_1750;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2281;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2745;
import net.minecraft.class_3414;
import net.minecraft.class_5953;
import net.minecraft.class_5955.class_5811;

public class CopperChestBlock extends class_2281 {
    private static final Supplier<Map<class_2248, Supplier<class_2248>>> COPPER_TO_COPPER_CHEST_MAPPING = Suppliers.memoize(() -> Map.of(
        class_2246.field_27119, ModBlocks.COPPER_CHEST,
        class_2246.field_27118, ModBlocks.EXPOSED_COPPER_CHEST,
        class_2246.field_27117, ModBlocks.WEATHERED_COPPER_CHEST,
        class_2246.field_27116, ModBlocks.OXIDIZED_COPPER_CHEST,
        class_2246.field_27133, ModBlocks.COPPER_CHEST,
        class_2246.field_27135, ModBlocks.EXPOSED_COPPER_CHEST,
        class_2246.field_27134, ModBlocks.WEATHERED_COPPER_CHEST,
        class_2246.field_33407, ModBlocks.OXIDIZED_COPPER_CHEST
    ));
    private final class_5811 weatherState;
    private final class_3414 openSound;
    private final class_3414 closeSound;
    
    public CopperChestBlock(class_5811 weatherState, class_3414 openSound, class_3414 closeSound, class_2251 properties) {
        super(properties, () -> ModBlockEntities.COPPER_CHEST.get());
        this.weatherState = weatherState;
        this.openSound = openSound;
        this.closeSound = closeSound;
    }
    
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new CopperChestBlockEntity(pos, state);
    }
    
    public boolean chestCanConnectTo(class_2680 blockState) {
        return blockState.method_26164(ModBlockTags.COPPER_CHESTS) && blockState.method_28498(class_2281.field_10770);
    }
    
    @Override
    public class_2680 method_9605(class_1750 context) {
        class_2680 state = super.method_9605(context);
        return getLeastOxidizedChestOfConnectedBlocks(state, context.method_8045(), context.method_8037());
    }
    
    private static class_2680 getLeastOxidizedChestOfConnectedBlocks(class_2680 state, class_1937 level, class_2338 pos) {
        class_2680 connectedState = level.method_8320(pos.method_10093(method_9758(state)));
        if (state.method_11654(class_2281.field_10770) != class_2745.field_12569
            && state.method_26204() instanceof CopperChestBlock copperChest
            && connectedState.method_26204() instanceof CopperChestBlock connectedCopperChest) {
            class_2680 updatedBlockState = state;
            class_2680 connectedPredicatedBlockState = connectedState;
            if (copperChest.isWaxed() != connectedCopperChest.isWaxed()) {
                updatedBlockState = unwaxBlock(copperChest, state).orElse(state);
                connectedPredicatedBlockState = unwaxBlock(connectedCopperChest, connectedState).orElse(connectedState);
            }
            
            class_2248 leastOxidizedBlock = copperChest.weatherState.ordinal() <= connectedCopperChest.weatherState.ordinal()
                ? updatedBlockState.method_26204()
                : connectedPredicatedBlockState.method_26204();
            return leastOxidizedBlock.method_34725(updatedBlockState);
        } else {
            return state;
        }
    }
    
    @Override
    public class_2680 method_9559(
        class_2680 state,
        class_2350 direction,
        class_2680 neighborState,
        class_1936 level,
        class_2338 pos,
        class_2338 neighborPos
    ) {
        class_2680 blockState = super.method_9559(state, direction, neighborState, level, pos, neighborPos);
        
        if (this.chestCanConnectTo(neighborState) && direction.method_10166().method_10179()) {
            class_2745 neighbourType = neighborState.method_11654(field_10770);
            if (state.method_11654(field_10770) == class_2745.field_12569
                && neighbourType != class_2745.field_12569
                && state.method_11654(field_10768) == neighborState.method_11654(field_10768)
                && method_9758(neighborState) == direction.method_10153()) {
                blockState = state.method_11657(field_10770, neighbourType.method_11824());
            }
        }
        
        if (this.chestCanConnectTo(neighborState)) {
            class_2745 chestType = state.method_11654(class_2281.field_10770);
            if (!chestType.equals(class_2745.field_12569) && method_9758(state) == direction) {
                return neighborState.method_26204().method_34725(state);
            }
        }
        
        return blockState;
    }
    
    private static Optional<class_2680> unwaxBlock(CopperChestBlock copperChest, class_2680 state) {
        return !copperChest.isWaxed()
            ? Optional.of(state)
            : Optional.ofNullable(class_5953.field_29561.get().get(state.method_26204())).map(block -> block.method_34725(state));
    }
    
    public class_5811 getState() {
        return this.weatherState;
    }
    
    public static class_2680 getFromCopperBlock(class_2248 copperBlock, class_2350 facing, class_1937 level, class_2338 pos) {
        CopperChestBlock block = (CopperChestBlock) COPPER_TO_COPPER_CHEST_MAPPING.get().getOrDefault(copperBlock, ModBlocks.COPPER_CHEST).get();
        class_2745 chestType = block.getChestType(level, pos, facing);
        class_2680 state = block.method_9564().method_11657(field_10768, facing).method_11657(field_10770, chestType);
        return getLeastOxidizedChestOfConnectedBlocks(state, level, pos);
    }
    
    public boolean isWaxed() {
        return true;
    }
    
    private class_2745 getChestType(class_1937 level, class_2338 pos, class_2350 facing) {
        if (facing == this.candidatePartnerFacing(level, pos, facing.method_10170())) {
            return class_2745.field_12574;
        } else {
            return facing == this.candidatePartnerFacing(level, pos, facing.method_10160())
                ? class_2745.field_12571
                : class_2745.field_12569;
        }
    }
    
    @Override
    public void method_9536(class_2680 oldState, class_1937 level, class_2338 pos, class_2680 newState, boolean movedByPiston) {
        if (!oldState.method_27852(newState.method_26204()) && oldState.method_31709() && !newState.method_26164(ModBlockTags.COPPER_CHESTS)) {
            if (level.method_8321(pos) instanceof class_1263 container) {
                class_1264.method_5451(level, pos, container);
                level.method_8455(pos, oldState.method_26204());
            }
            
            level.method_8544(pos);
        }
    }
    
    private class_2350 candidatePartnerFacing(class_1937 level, class_2338 pos, class_2350 direction) {
        class_2680 state = level.method_8320(pos.method_10093(direction));
        return this.chestCanConnectTo(state) && state.method_11654(field_10770) == class_2745.field_12569 ? state.method_11654(field_10768) : null;
    }
    
    public class_3414 getOpenChestSound() {
        return this.openSound;
    }
    
    public class_3414 getCloseChestSound() {
        return this.closeSound;
    }
}