package com.blackgear.vanillabackport.common.level.blocks;

import com.blackgear.vanillabackport.core.data.tags.ModBlockTags;
import net.minecraft.class_10;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1540;
import net.minecraft.class_1676;
import net.minecraft.class_1685;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2753;
import net.minecraft.class_2754;
import net.minecraft.class_3218;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5688;
import net.minecraft.class_5691;
import net.minecraft.class_5819;
import net.minecraft.world.level.block.state.properties.*;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import java.util.function.BiPredicate;
import java.util.function.Predicate;

public class SpeleothemBlock extends class_2248 implements class_5688, class_3737 {
    public static final class_2753 TIP_DIRECTION = class_2741.field_28062;
    public static final class_2754<class_5691> THICKNESS = class_2741.field_28063;
    public static final class_2746 WATERLOGGED = class_2741.field_12508;
    private static final class_265 TIP_MERGE_SHAPE = class_2248.method_9541(5.0, 0.0, 5.0, 11.0, 16.0, 11.0);
    private static final class_265 TIP_SHAPE_UP = class_2248.method_9541(5.0, 0.0, 5.0, 11.0, 11.0, 11.0);
    private static final class_265 TIP_SHAPE_DOWN = class_2248.method_9541(5.0, 5.0, 5.0, 11.0, 16.0, 11.0);
    private static final class_265 FRUSTUM_SHAPE = class_2248.method_9541(4.0, 0.0, 4.0, 12.0, 16.0, 12.0);
    private static final class_265 MIDDLE_SHAPE = class_2248.method_9541(3.0, 0.0, 3.0, 13.0, 16.0, 13.0);
    private static final class_265 BASE_SHAPE = class_2248.method_9541(2.0, 0.0, 2.0, 14.0, 16.0, 14.0);
    protected final class_2680 blockToGrowOn;

    public SpeleothemBlock(class_2680 blockToGrowOn, class_2251 properties) {
        super(properties);
        this.blockToGrowOn = blockToGrowOn;
        this.method_9590(
            this.field_10647.method_11664()
                .method_11657(TIP_DIRECTION, class_2350.field_11036)
                .method_11657(THICKNESS, class_5691.field_28065)
                .method_11657(WATERLOGGED, false)
        );
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(TIP_DIRECTION, THICKNESS, WATERLOGGED);
    }

    @Override
    public boolean method_9558(class_2680 state, class_4538 level, class_2338 pos) {
        return this.isValidSpeleothemPlacement(level, pos, state.method_11654(TIP_DIRECTION));
    }

    @Override
    protected class_2680 method_9559(
        class_2680 state,
        class_2350 direction,
        class_2680 neighborState,
        class_1936 level,
        class_2338 pos,
        class_2338 neighborPos
    ) {
        if (state.method_11654(WATERLOGGED)) {
            level.method_39281(pos, class_3612.field_15910, class_3612.field_15910.method_15789(level));
        }

        if (direction != class_2350.field_11036 && direction != class_2350.field_11033) {
            return state;
        } else {
            class_2350 tipDirection = state.method_11654(TIP_DIRECTION);
            if (tipDirection == class_2350.field_11033 && level.method_8397().method_8674(pos, this)) {
                return state;
            } else if (direction == tipDirection.method_10153() && !this.method_9558(state, level, pos)) {
                if (tipDirection == class_2350.field_11033) {
                    level.method_39279(pos, this, 2);
                } else {
                    level.method_39279(pos, this, 1);
                }

                return state;
            } else {
                boolean merge = state.method_11654(THICKNESS) == class_5691.field_28064;
                class_5691 thickness = this.calculateSpeleothemThickness(level, pos, tipDirection, merge);
                return state.method_11657(THICKNESS, thickness);
            }
        }
    }

    @Override @Nullable
    public class_2680 method_9605(class_1750 context) {
        class_1936 level = context.method_8045();
        class_2338 pos = context.method_8037();
        class_2350 defaultTipDirection = context.method_32760().method_10153();
        class_2350 tipDirection = calculateTipDirection(level, pos, defaultTipDirection);
        if (tipDirection == null) {
            return null;
        } else {
            boolean merge = !context.method_8046();
            class_5691 thickness = this.calculateSpeleothemThickness(level, pos, tipDirection, merge);
            return this.method_9564()
                .method_11657(TIP_DIRECTION, tipDirection)
                .method_11657(THICKNESS, thickness)
                .method_11657(WATERLOGGED, level.method_8316(pos).method_15772() == class_3612.field_15910);
        }
    }

    @Nullable
    private class_2350 calculateTipDirection(class_4538 level, class_2338 pos, class_2350 tipDirection) {
        if (this.isValidSpeleothemPlacement(level, pos, tipDirection)) {
            return tipDirection;
        } else {
            if (!this.isValidSpeleothemPlacement(level, pos, tipDirection.method_10153())) {
                return null;
            }

            return tipDirection.method_10153();
        }
    }

    private class_5691 calculateSpeleothemThickness(class_4538 level, class_2338 pos, class_2350 tipDirection, boolean merge) {
        class_2350 direction = tipDirection.method_10153();
        class_2680 inFrontState = level.method_8320(pos.method_10093(tipDirection));
        if (isSpeleothemWithDirection(inFrontState, direction)) {
            return !merge && inFrontState.method_11654(THICKNESS) != class_5691.field_28064 ? class_5691.field_28065 : class_5691.field_28064;
        } else if (!isSpeleothemWithDirection(inFrontState, tipDirection)) {
            return class_5691.field_28065;
        } else {
            class_5691 inFrontThickness = inFrontState.method_11654(THICKNESS);
            if (inFrontThickness != class_5691.field_28065 && inFrontThickness != class_5691.field_28064) {
                class_2680 behindState = level.method_8320(pos.method_10093(direction));
                return !isSpeleothemWithDirection(behindState, tipDirection) ? class_5691.field_28068 : class_5691.field_28067;
            } else {
                return class_5691.field_28066;
            }
        }
    }

    private boolean isValidSpeleothemPlacement(class_4538 level, class_2338 pos, class_2350 tipDirection) {
        class_2338 behindPos = pos.method_10093(tipDirection.method_10153());
        class_2680 behindState = level.method_8320(behindPos);
        return behindState.method_26206(level, behindPos, tipDirection) || isSpeleothemWithDirection(behindState, tipDirection) && behindState.method_27852(this);
    }

    private static boolean isSpeleothemWithDirection(class_2680 state, class_2350 dir) {
        return state.method_26164(ModBlockTags.SPELEOTHEMS) && state.method_11654(TIP_DIRECTION) == dir;
    }

    @Override
    protected void method_19286(class_1937 level, class_2680 state, class_3965 hit, class_1676 projectile) {
        if (!level.method_8608()) {
            class_2338 blockPos = hit.method_17777();
            if (
                projectile.method_36971(level, blockPos) &&
                projectile instanceof class_1685 &&
                projectile.method_18798().method_1033() > 0.6
            ) {
                level.method_22352(blockPos, true);
            }
        }
    }

    @Override
    protected void method_9588(class_2680 state, class_3218 level, class_2338 pos, class_5819 random) {
        if (isStalagmite(state) && !this.method_9558(state, level, pos)) {
            level.method_22352(pos, true);
        } else {
            spawnFallingStalactite(state, level, pos);
        }
    }

    private static void spawnFallingStalactite(class_2680 state, class_3218 level, class_2338 pos) {
        class_2338.class_2339 fallPos = pos.method_25503();
        class_2680 fallState = state;

        while (isStalactite(fallState)) {
            class_1540 fallingBlockEntity = class_1540.method_40005(level, fallPos, fallState);
            if (isTip(fallState, true)) {
                int size = Math.max(1 + pos.method_10264() - fallPos.method_10264(), 6);
                float damagePerFallDistance = (float) size;
                fallingBlockEntity.method_6965(damagePerFallDistance, 40);
                break;
            }

            fallPos.method_10098(class_2350.field_11033);
            fallState = level.method_8320(fallPos);
        }
    }

    private static boolean isStalagmite(class_2680 state) {
        return isSpeleothemWithDirection(state, class_2350.field_11036);
    }

    private static boolean isStalactite(class_2680 state) {
        return isSpeleothemWithDirection(state, class_2350.field_11033);
    }

    private static boolean isTip(class_2680 state, boolean merge) {
        if (!state.method_26164(ModBlockTags.SPELEOTHEMS)) {
            return false;
        } else {
            class_5691 thickness = state.method_11654(THICKNESS);
            return thickness == class_5691.field_28065 || merge && thickness == class_5691.field_28064;
        }
    }

    @Override
    public void method_10129(class_1937 level, class_2338 pos, class_1540 fallingBlock) {
        if (!fallingBlock.method_5701()) level.method_20290(1045, pos, 0);
    }

    @Override
    public class_1282 method_32898(class_1297 entity) {
        return entity.method_48923().method_48814(entity);
    }

    @Override
    protected class_3610 method_9545(class_2680 state) {
        return state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
    }

    @Override
    protected class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        class_265 shape = switch (state.method_11654(THICKNESS)) {
            case field_28064 -> TIP_MERGE_SHAPE;
            case field_28065 -> state.method_11654(TIP_DIRECTION) == class_2350.field_11033 ? TIP_SHAPE_DOWN : TIP_SHAPE_UP;
            case field_28066 -> FRUSTUM_SHAPE;
            case field_28067 -> MIDDLE_SHAPE;
            case field_28068 -> BASE_SHAPE;
        };
        class_243 offset = state.method_26226(level, pos);
        return shape.method_1096(offset.field_1352, 0.0, offset.field_1350);
    }

    @Override
    protected boolean method_37403(class_2680 state, class_1922 level, class_2338 pos) {
        return false;
    }

    @Override
    protected float method_32913() {
        return 0.125F;
    }

    @Override
    protected boolean method_9516(class_2680 state, class_10 type) {
        return false;
    }

    @Override
    protected void method_9514(class_2680 state, class_3218 level, class_2338 pos, class_5819 random) {
        if (random.method_43057() < 0.011377778F && isStalactiteStartPos(state, level, pos)) {
            this.tryGrowStalactiteOrStalagmiteIfPossible(state, level, pos, random);
        }
    }

    private static boolean isStalactiteStartPos(class_2680 state, class_4538 level, class_2338 pos) {
        return isStalactite(state) && !level.method_8320(pos.method_10084()).method_27852(class_2246.field_28048);
    }

    public void tryGrowStalactiteOrStalagmiteIfPossible(class_2680 state, class_3218 level, class_2338 pos, class_5819 random) {
        if (this.canGrow(level, pos)) {
            class_2338 stalactiteTipPos = findTip(state, level, pos, 7, false);
            if (stalactiteTipPos != null) {
                class_2680 stalactiteTipState = level.method_8320(stalactiteTipPos);
                if (isFreeHangingStalactite(stalactiteTipState) && this.canTipGrow(stalactiteTipState, level, stalactiteTipPos)) {
                    if (random.method_43056()) {
                        this.grow(level, stalactiteTipPos, class_2350.field_11033);
                    } else {
                        this.growStalagmiteBelow(level, stalactiteTipPos);
                    }
                }
            }
        }
    }

    protected boolean canGrow(class_4538 level, class_2338 pos) {
        return level.method_8320(pos.method_10084()).method_27852(this.blockToGrowOn.method_26204());
    }

    @Nullable
    private static class_2338 findTip(class_2680 speleothemState, class_1936 level, class_2338 speleothemPos, int maxSearchLength, boolean merge) {
        if (isTip(speleothemState, merge)) {
            return speleothemPos;
        } else {
            class_2350 searchDirection = speleothemState.method_11654(TIP_DIRECTION);
            BiPredicate<class_2338, class_2680> pathPredicate = (pos, state) -> state.method_27852(speleothemState.method_26204()) && state.method_11654(TIP_DIRECTION) == searchDirection;
            return findBlockVertical(
                level,
                speleothemPos,
                searchDirection.method_10171(),
                pathPredicate,
                speleothem -> isTip(speleothem, merge),
                maxSearchLength
            ).orElse(null);
        }
    }

    private static Optional<class_2338> findBlockVertical(
        class_1936 level,
        class_2338 pos,
        class_2350.class_2352 axis,
        BiPredicate<class_2338, class_2680> pathPredicate,
        Predicate<class_2680> targetPredicate,
        int maxSteps
    ) {
        class_2350 direction = class_2350.method_10156(axis, class_2350.class_2351.field_11052);
        class_2338.class_2339 mutablePos = pos.method_25503();

        for(int i = 1; i < maxSteps; ++i) {
            mutablePos.method_10098(direction);
            class_2680 state = level.method_8320(mutablePos);
            if (targetPredicate.test(state)) {
                return Optional.of(mutablePos.method_10062());
            }

            if (level.method_31601(mutablePos.method_10264()) || !pathPredicate.test(mutablePos, state)) {
                return Optional.empty();
            }
        }

        return Optional.empty();
    }

    private boolean canTipGrow(class_2680 state, class_3218 level, class_2338 pos) {
        class_2350 growDirection = state.method_11654(TIP_DIRECTION);
        class_2338 growPos = pos.method_10093(growDirection);
        class_2680 stateAtGrowPos = level.method_8320(growPos);
        if (!stateAtGrowPos.method_26227().method_15769()) {
            return false;
        } else {
            return stateAtGrowPos.method_26215() || this.isUnmergedTipWithDirection(stateAtGrowPos, growDirection.method_10153());
        }
    }

    private boolean isUnmergedTipWithDirection(class_2680 state, class_2350 dir) {
        return isTip(state, false) && state.method_11654(TIP_DIRECTION) == dir && state.method_27852(this);
    }

    private void grow(class_3218 server, class_2338 pos, class_2350 direction) {
        class_2338 targetPos = pos.method_10093(direction);
        class_2680 existingStateAtTargetPos = server.method_8320(targetPos);
        if (this.isUnmergedTipWithDirection(existingStateAtTargetPos, direction.method_10153())) {
            this.createMergedTips(existingStateAtTargetPos, server, targetPos);
        } else if (existingStateAtTargetPos.method_26215() || existingStateAtTargetPos.method_27852(class_2246.field_10382)) {
            this.createSpeleothem(server, targetPos, direction, class_5691.field_28065);
        }
    }

    private void createSpeleothem(class_1936 level, class_2338 pos, class_2350 direction, class_5691 thickness) {
        class_2680 state = this.method_9564()
            .method_11657(TIP_DIRECTION, direction)
            .method_11657(THICKNESS, thickness)
            .method_11657(WATERLOGGED, level.method_8316(pos).method_15772() == class_3612.field_15910);
        level.method_8652(pos, state, 3);
    }

    private void createMergedTips(class_2680 state, class_1936 level, class_2338 tipPos) {
        class_2338 stalactitePos;
        class_2338 stalagmitePos;
        if (state.method_11654(TIP_DIRECTION) == class_2350.field_11036) {
            stalagmitePos = tipPos;
            stalactitePos = tipPos.method_10084();
        } else {
            stalactitePos = tipPos;
            stalagmitePos = tipPos.method_10074();
        }

        createSpeleothem(level, stalactitePos, class_2350.field_11033, class_5691.field_28064);
        createSpeleothem(level, stalagmitePos, class_2350.field_11036, class_5691.field_28064);
    }

    private void growStalagmiteBelow(class_3218 level, class_2338 posAboveStalagmite) {
        class_2338.class_2339 pos = posAboveStalagmite.method_25503();

        for(int i = 0; i < 10; ++i) {
            pos.method_10098(class_2350.field_11033);
            class_2680 state = level.method_8320(pos);
            if (!state.method_26227().method_15769()) {
                return;
            }

            if (this.isUnmergedTipWithDirection(state, class_2350.field_11036) && this.canTipGrow(state, level, pos)) {
                this.grow(level, pos, class_2350.field_11036);
                return;
            }

            if (this.isValidSpeleothemPlacement(level, pos, class_2350.field_11036) && !level.method_22351(pos.method_10074())) {
                this.grow(level, pos.method_10074(), class_2350.field_11036);
                return;
            }

            if (!this.blocksStalagmiteScan(level, pos, state)) {
                return;
            }
        }
    }

    private boolean blocksStalagmiteScan(class_1922 level, class_2338 pos, class_2680 state) {
        return false;
    }

    public static boolean isFreeHangingStalactite(class_2680 state) {
        return isStalactite(state) && state.method_11654(THICKNESS) == class_5691.field_28065 && !state.method_11654(WATERLOGGED);
    }
}