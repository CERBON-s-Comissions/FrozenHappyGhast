package com.blackgear.vanillabackport.common.level.blocks;

import com.blackgear.vanillabackport.core.VanillaBackport;
import java.util.function.Supplier;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2394;
import net.minecraft.class_2397;
import net.minecraft.class_2680;
import net.minecraft.class_5819;
import net.minecraft.class_5945;

public class ParticleLeavesBlock extends class_2397 {
    private final Supplier<? extends class_2394> particle;
    private final float leafParticleChance;

    public ParticleLeavesBlock(float leafParticleChance, Supplier<? extends class_2394> particle, class_2251 properties) {
        super(properties);
        this.leafParticleChance = leafParticleChance;
        this.particle = particle;
    }

    @Override
    public void method_9496(class_2680 state, class_1937 level, class_2338 pos, class_5819 random) {
        super.method_9496(state, level, pos, random);
        if (level.field_9236 && !VanillaBackport.CLIENT_CONFIG.hasFallingLeaves.get()) return;

        if (random.method_43057() < this.leafParticleChance) {
            class_2338 below = pos.method_10074();
            class_2680 belowState = level.method_8320(below);
            if (!method_9501(belowState.method_26220(level, below), class_2350.field_11036)) {
                class_5945.method_49099(level, pos, random, this.particle.get());
            }
        }
    }
}