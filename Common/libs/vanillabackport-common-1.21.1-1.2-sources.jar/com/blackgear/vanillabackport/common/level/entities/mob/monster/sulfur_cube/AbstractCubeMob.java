package com.blackgear.vanillabackport.common.level.entities.mob.monster.sulfur_cube;

import com.blackgear.vanillabackport.common.api.extensions.entity.movement.TravelAwareEntity;
import net.minecraft.class_1266;
import net.minecraft.class_1282;
import net.minecraft.class_1294;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1315;
import net.minecraft.class_1335;
import net.minecraft.class_1352;
import net.minecraft.class_1439;
import net.minecraft.class_1657;
import net.minecraft.class_1890;
import net.minecraft.class_1937;
import net.minecraft.class_2394;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_3730;
import net.minecraft.class_4048;
import net.minecraft.class_4050;
import net.minecraft.class_5134;
import net.minecraft.class_5425;
import net.minecraft.class_5819;
import net.minecraft.world.entity.*;
import org.jetbrains.annotations.Nullable;

import java.util.EnumSet;

public abstract class AbstractCubeMob extends class_1296 implements TravelAwareEntity {
    protected static final class_2940<Integer> ID_SIZE = class_2945.method_12791(AbstractCubeMob.class, class_2943.field_13327);
    public float targetSquish;
    public float squish;
    public float oSquish;
    private boolean wasOnGround = false;

    protected AbstractCubeMob(class_1299<? extends class_1296> entityType, class_1937 level) {
        super(entityType, level);
        this.method_46396();
        this.field_6207 = new CubeMobMoveControl<>(this);
    }

    @Override
    protected void method_5959() {
        this.field_6201.method_6277(1, new CubeMobFloatGoal(this));
        this.field_6201.method_6277(4, new CubeMobRandomDirectionGoal(this));
        this.field_6201.method_6277(5, new CubeMobKeepOnJumpingGoal(this));
        this.addBehaviourGoals();
        this.addTargetingGoals();
    }

    protected abstract void addBehaviourGoals();

    protected abstract void addTargetingGoals();

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        super.method_5693(builder);
        builder.method_56912(ID_SIZE, 1);
    }

    public void setSize(int size, boolean updateHealth) {
        int actualSize = class_3532.method_15340(size, 1, 127);
        this.field_6011.method_12778(ID_SIZE, actualSize);
        this.method_23311();
        this.method_18382();
        this.setCubeMobHealth(actualSize);
        this.method_5996(class_5134.field_23719).method_6192(0.2F + 0.1F * actualSize);
        if (updateHealth) this.method_6033(this.method_6063());
    }

    protected void setCubeMobHealth(int actualSize) {
        this.method_5996(class_5134.field_23716).method_6192(actualSize * actualSize);
    }

    public int getSize() {
        return this.field_6011.method_12789(ID_SIZE);
    }

    @Override
    public void method_5652(class_2487 compound) {
        super.method_5652(compound);
        compound.method_10569("Size", this.getSize() - 1);
        compound.method_10556("wasOnGround", this.wasOnGround);
    }

    @Override
    public void method_5749(class_2487 compound) {
        this.setSize(compound.method_10550("Size") + 1, false);
        super.method_5749(compound);
        this.wasOnGround = compound.method_10577("wasOnGround");
    }

    public boolean isTiny() {
        return this.getSize() <= 1;
    }

    @Nullable
    protected abstract class_2394 getParticleType();

    @Override
    public void method_5773() {
        this.oSquish = this.squish;
        this.squish = this.squish + (this.targetSquish - this.squish) * 0.5F;
        super.method_5773();
        if (this.method_24828() && !this.wasOnGround) {
            float size = this.method_18377(this.method_18376()).comp_2185() * 2.0F;
            float radius = size / 2.0F;

            for (int i = 0; i < size * 16.0F; i++) {
                float direction = this.field_5974.method_43057() * (float) (Math.PI * 2);
                float offset = this.field_5974.method_43057() * 0.5F + 0.5F;
                float x = class_3532.method_15374(direction) * radius * offset;
                float z = class_3532.method_15362(direction) * radius * offset;
                class_2394 particle = this.getParticleType();
                if (particle != null) {
                    this.method_37908().method_8406(particle, this.method_23317() + x, this.method_23318(), this.method_23321() + z, 0.0, 0.0, 0.0);
                }
            }

            this.method_5783(this.getSquishSound(), this.method_6107(), ((this.field_5974.method_43057() - this.field_5974.method_43057()) * 0.2F + 1.0F) / 0.8F);
            this.targetSquish = -0.5F;
        } else if (!this.method_24828() && this.wasOnGround) {
            this.targetSquish = 1.0F;
        }

        this.wasOnGround = this.method_24828();
        this.decreaseSquish();
    }

    protected void decreaseSquish() {
        this.targetSquish *= 0.6F;
    }

    protected int getJumpDelay() {
        return this.field_5974.method_43048(20) + 10;
    }

    @Override
    public void method_18382() {
        double oldX = this.method_23317();
        double oldY = this.method_23318();
        double oldZ = this.method_23321();
        super.method_18382();
        this.method_5814(oldX, oldY, oldZ);
    }

    @Override
    public void method_5674(class_2940<?> key) {
        if (ID_SIZE.equals(key)) {
            this.method_18382();
            this.method_36456(this.field_6241);
            this.field_6283 = this.field_6241;
            if (this.method_5799() && this.field_5974.method_43048(20) == 0) {
                this.method_5746();
            }
        }

        super.method_5674(key);
    }

    @Override @SuppressWarnings("unchecked")
    public class_1299<? extends AbstractCubeMob> method_5864() {
        return (class_1299<? extends AbstractCubeMob>) super.method_5864();
    }

    @Override
    public void method_5650(class_5529 reason) {
        int size = this.getSize();
        if (!this.method_37908().method_8608() && size > 1 && this.method_29504()) {
            float width = this.method_18377(this.method_18376()).comp_2185();
            float xzSpawnOffset = width / 2.0F;
            int halfSize = size / 2;
            int count = this.getSplitCount();

            for (int i = 0; i < count; i++) {
                float x = (i % 2.0F - 0.5F) * xzSpawnOffset;
                float z = (i / 2.0F - 0.5F) * xzSpawnOffset;
                AbstractCubeMob cube = this.method_5864().method_5883(this.method_37908());
                if (cube != null) {
                    if (this.method_5947()) cube.method_5971();

                    cube.method_5665(this.method_5797());
                    cube.method_5977(this.method_5987());
                    cube.method_5684(this.method_5655());
                    this.setUpSplitCube(cube, halfSize, x, z);
                    this.method_37908().method_8649(cube);
                }
            }
        }

        super.method_5650(reason);
    }

    protected void setUpSplitCube(AbstractCubeMob cube, int halfSize, float x, float z) {
        cube.setSize(halfSize, true);
        cube.method_5808(this.method_23317() + x, this.method_23318() + 0.5, this.method_23321() + z, this.field_5974.method_43057() * 360.0F, 0.0F);
    }

    protected int getSplitCount() {
        return 2 + this.field_5974.method_43048(3);
    }

    @Override
    public void method_5697(class_1297 entity) {
        super.method_5697(entity);
        if (entity instanceof class_1439 target && this.isDealsDamage()) {
            this.dealDamage(target);
        }
    }

    @Override
    public void method_5694(class_1657 player) {
        if (this.isDealsDamage()) {
            this.dealDamage(player);
        }
    }

    protected void dealDamage(class_1309 target) {
        if (this.method_37908() instanceof class_3218 level && this.method_5805() && this.method_42150(target) && this.method_6057(target)) {
            class_1282 damageSource = this.method_48923().method_48812(this);
            if (target.method_5643(damageSource, this.getAttackDamage())) {
                this.method_5783(class_3417.field_14863, 1.0F, (this.field_5974.method_43057() - this.field_5974.method_43057()) / 0.2F + 1.0F);
                class_1890.method_60107(level, target, damageSource);
            }
        }
    }

    @Override
    protected class_243 method_52533(class_1297 entity, class_4048 dimensions, float scale) {
        return new class_243(0.0, dimensions.comp_2186() - 0.015625 * this.getSize() * scale, 0.0);
    }

    protected boolean isDealsDamage() {
        return !this.isTiny() && this.method_6034();
    }

    protected float getAttackDamage() {
        return (float) this.method_45325(class_5134.field_23721);
    }

    @Override
    protected class_4048 method_55694(class_4050 pose) {
        return this.method_5864().method_18386().method_18383(this.getSize());
    }

    @Override
    public void method_6043() {
        class_243 movement = this.method_18798();
        this.method_18800(movement.field_1352, this.method_6106(), movement.field_1350);
        this.field_6007 = true;
    }

    @Override
    public class_3419 method_5634() {
        return class_3419.field_15251;
    }

    @Override
    protected float method_6107() {
        return 0.4F * this.getSize();
    }

    @Override
    public int method_5978() {
        return 0;
    }

    protected boolean doPlayJumpSound() {
        return this.getSize() > 0;
    }

    public float getSoundPitch() {
        float pitchAdjuster = this.isTiny() ? 1.4F : 0.8F;
        return ((this.field_5974.method_43057() - this.field_5974.method_43057()) * 0.2F + 1.0F) * pitchAdjuster;
    }

    protected abstract class_3414 getJumpSound();

    @Override @Nullable protected abstract class_3414 method_6011(class_1282 damageSource);

    @Override @Nullable protected abstract class_3414 method_6002();

    protected abstract class_3414 getSquishSound();

    @Override @Nullable
    public class_1296 method_5613(class_3218 level, class_1296 otherParent) {
        return null;
    }

    @Override
    public class_1315 method_5943(class_5425 level, class_1266 difficulty, class_3730 spawnType, @Nullable class_1315 spawnGroupData) {
        this.setSpawnSize(level, difficulty);
        return super.method_5943(level, difficulty, spawnType, spawnGroupData);
    }

    protected void setSpawnSize(class_5425 level, class_1266 difficulty) {
        class_5819 random = level.method_8409();
        int sizeScale = random.method_43048(3);
        if (sizeScale < 2 && random.method_43057() < 0.5F * difficulty.method_5458()) {
            sizeScale++;
        }

        int size = 1 << sizeScale;
        this.setSize(size, true);
    }

    private static class CubeMobFloatGoal extends class_1352 {
        private final AbstractCubeMob cube;

        public CubeMobFloatGoal(AbstractCubeMob cube) {
            this.cube = cube;
            this.method_6265(EnumSet.of(class_4134.field_18407, class_4134.field_18405));
            cube.method_5942().method_6354(true);
        }

        @Override
        public boolean method_6264() {
            return (this.cube.method_5799() || this.cube.method_5771()) && this.cube.method_5962() instanceof CubeMobMoveControl;
        }

        @Override
        public boolean method_38846() {
            return true;
        }

        @Override
        public void method_6268() {
            if (this.cube.method_59922().method_43057() < 0.8F) {
                this.cube.method_5993().method_6233();
            }

            if (this.cube.method_5962() instanceof CubeMobMoveControl<?> control) {
                control.setWantedMovement(1.2);
            }
        }
    }

    private static class CubeMobKeepOnJumpingGoal extends class_1352 {
        private final AbstractCubeMob cube;

        public CubeMobKeepOnJumpingGoal(AbstractCubeMob cube) {
            this.cube = cube;
            this.method_6265(EnumSet.of(class_4134.field_18407, class_4134.field_18405));
        }

        @Override
        public boolean method_6264() {
            return !this.cube.method_5765();
        }

        @Override
        public void method_6268() {
            if (this.cube.method_5962() instanceof CubeMobMoveControl<?> control) {
                control.setWantedMovement(1.0);
            }
        }
    }

    protected static class CubeMobMoveControl<T extends AbstractCubeMob> extends class_1335 {
        private float yRot;
        private int jumpDelay;
        private boolean isAggressive;
        protected final T cube;

        public CubeMobMoveControl(T cube) {
            super(cube);
            this.cube = cube;
            this.yRot = 180.0F * cube.method_36454() / (float) Math.PI;
        }

        public void setDirection(float yRot, boolean isAggressive) {
            this.yRot = yRot;
            this.isAggressive = isAggressive;
        }

        public void setWantedMovement(double speedModifier) {
            this.field_6372 = speedModifier;
            this.field_6374 = class_1336.field_6378;
        }

        @Override
        public void method_6240() {
            this.cube.method_36456(this.method_6238(this.cube.method_36454(), this.yRot, 90.0F));
            this.cube.field_6241 = this.cube.method_36454();
            this.cube.field_6283 = this.cube.method_36454();
            if (this.field_6374 != class_1336.field_6378) {
                this.cube.method_5930(0.0F);
            } else {
                this.field_6374 = class_1336.field_6377;
                if (this.cube.method_24828()) {
                    this.cube.method_6125((float)(this.field_6372 * this.cube.method_45325(class_5134.field_23719)));
                    if (this.jumpDelay-- <= 0) {
                        this.jumpDelay = this.cube.getJumpDelay();
                        if (this.isAggressive) {
                            this.jumpDelay /= 3;
                        }

                        this.cube.method_5993().method_6233();
                        if (this.cube.doPlayJumpSound()) {
                            this.cube.method_5783(this.cube.getJumpSound(), this.cube.method_6107(), this.cube.getSoundPitch());
                        }
                    } else {
                        this.cube.field_6212 = 0.0F;
                        this.cube.field_6250 = 0.0F;
                        this.cube.method_6125(0.0F);
                    }
                } else {
                    this.cube.method_6125((float)(this.field_6372 * this.cube.method_45325(class_5134.field_23719)));
                }
            }
        }
    }

    private static class CubeMobRandomDirectionGoal extends class_1352 {
        private final AbstractCubeMob cube;
        private float chosenDegrees;
        private int nextRandomizeTime;

        public CubeMobRandomDirectionGoal(AbstractCubeMob cube) {
            this.cube = cube;
            this.method_6265(EnumSet.of(class_4134.field_18406));
        }

        @Override
        public boolean method_6264() {
            return this.cube.method_5968() == null
                && (this.cube.method_24828() || this.cube.method_5799() || this.cube.method_5771() || this.cube.method_6059(class_1294.field_5902))
                && this.cube.method_5962() instanceof CubeMobMoveControl;
        }

        @Override
        public void method_6268() {
            if (--this.nextRandomizeTime <= 0) {
                this.nextRandomizeTime = this.method_38847(40 + this.cube.method_59922().method_43048(60));
                this.chosenDegrees = this.cube.method_59922().method_43048(360);
            }

            if (this.cube.method_5962() instanceof CubeMobMoveControl<?> control) {
                control.setDirection(this.chosenDegrees, false);
            }
        }
    }
}