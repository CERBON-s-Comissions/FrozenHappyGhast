package com.blackgear.vanillabackport.common.level.block_entities;

import com.blackgear.vanillabackport.client.level.particle.particleoptions.GeyserParticleOptions;
import com.blackgear.vanillabackport.client.registries.ModParticles;
import com.blackgear.vanillabackport.common.level.blocks.PotentSulfurState;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlockEntities;
import com.blackgear.vanillabackport.core.data.tags.ModEntityTypeTags;
import com.blackgear.vanillabackport.core.util.Utilities.CollisionUtils;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1301;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_3612;
import net.minecraft.class_3726;
import net.minecraft.class_3959;
import net.minecraft.class_5558;
import net.minecraft.class_5712;
import net.minecraft.class_5819;
import net.minecraft.class_6677;
import net.minecraft.class_7225;

import static com.blackgear.vanillabackport.common.level.blocks.PotentSulfurBlock.STATE;

public class PotentSulfurBlockEntity extends class_2586 {
    public static final long GEYSER_SALT = -904011478L;
    private static final Predicate<class_1297> EFFECT_PREDICATE = class_1301.field_6155.and(class_1301.field_6154);
    public int waitingCountdown = -1;
    public long eruptionTick = -1L;

    public static final class_5558<PotentSulfurBlockEntity> SERVER_NAUSEA_EFFECT_TICKER = (level, pos, state, sulfur) -> {
        if (level.method_8510() % 10L == 0L) {
            class_2338 source = findNoxiousGasSourceBlock(level, pos);
            if (source != null) {
                for (class_1309 entity : getNearbyLivingEntities(level, source)) {
                    if (canBeReachedByNoxiousGas(level, source, entity.method_33571())) {
                        applyNauseaEffect(entity);
                    }
                }
            }
        }
    };

    public static final class_5558<PotentSulfurBlockEntity> CLIENT_NOXIOUS_GAS_TICKER = (level, pos, state, sulfur) -> {
        if (level.method_8510() % 20L == 0L) {
            class_2338 source = findNoxiousGasSourceBlock(level, pos);
            if (source != null) {
                spawnNoxiousGasCloudParticle(level, class_243.method_24953(source));
            }
        }
    };

    public static final Function<class_3414, class_5558<PotentSulfurBlockEntity>> CLIENT_GEYSER_PLUME_TICKER = sound -> (level, pos, state, sulfur) -> {
        class_2338 source = findNoxiousGasSourceBlock(level, pos);
        if (source != null) {
            long eruptionTime = level.method_8510() - sulfur.eruptionTick;
            if (eruptionTime % 20L == 0L) {
                spawnGeyserParticle(level, pos, source);
            }

            if (eruptionTime % 40L == 0L) {
                level.method_8486(source.method_10263() + 0.5, source.method_10264() + 0.5, source.method_10260() + 0.5, sound, class_3419.field_15245, 1.0F, 1.0F, false);
            }
        }
    };

    public static final class_5558<PotentSulfurBlockEntity> SERVER_WAITING_COUNTDOWN_TICKER = (level, pos, state, sulfur) -> {
        if (level.method_8510() % 20L == 0L) {
            class_2338 source = findNoxiousGasSourceBlock(level, pos);
            if (source != null) {
                if (sulfur.waitingCountdown <= 0) {
                    int waterBlocks = source.method_10264() - pos.method_10264() - 1;
                    class_5819 geyserPositional = geyserPositional((class_3218) level, pos);
                    if (state.method_11654(STATE) == PotentSulfurState.DORMANT) {
                        sulfur.waitingCountdown = 10 * (waterBlocks - 1) + geyserPositional.method_39332(15, 30);
                    } else {
                        geyserPositional.method_43054();
                        sulfur.waitingCountdown = waterBlocks - 1 + geyserPositional.method_39332(1, 2);
                    }
                }

                if (sulfur.waitingCountdown > 0) {
                    sulfur.waitingCountdown--;
                }

                if (sulfur.waitingCountdown == 0) {
                    PotentSulfurState stateToSet = state.method_11654(STATE) == PotentSulfurState.DORMANT
                        ? PotentSulfurState.ERUPTING
                        : PotentSulfurState.DORMANT;
                    level.method_8652(pos, state.method_11657(STATE, stateToSet), class_2248.field_31036);
                    if (stateToSet == PotentSulfurState.DORMANT) {
                        level.method_43276(class_5712.field_28175, pos, class_5712.class_7397.method_43287(state));
                    }
                }
            }
        }
    };
    
    public static final class_5558<PotentSulfurBlockEntity> SERVER_LAUNCH_ENTITY_TICKER = (level, pos, state, sulfur) -> {
        class_2338 source = findNoxiousGasSourceBlock(level, pos);
        if (source != null) {
            int waterBlocks = source.method_10264() - pos.method_10264() - 1;
            int geyserForceHeight = getUnobstructedBlockCount(level, pos.method_10084(), waterBlocks);
            class_238 aabb = new class_238(pos.method_10084()).method_1012(0.0, geyserForceHeight - 1, 0.0);
            
            for (class_1297 target : level.method_8390(class_1297.class, aabb, EFFECT_PREDICATE)) {
                class_1297 entityToBeLaunched = target.method_5765() ? target.method_5668() : target;
                class_243 velocity = entityToBeLaunched.method_18798();
                entityToBeLaunched.method_45318();
                if (!(entityToBeLaunched instanceof class_1657 player && player.method_31549().field_7479)
                    && !entityToBeLaunched.method_5765()
                    && !entityToBeLaunched.method_5864().method_20210(ModEntityTypeTags.NOT_AFFECTED_BY_GEYSERS)
                    && velocity.field_1351 < 0.3F + waterBlocks * 0.1) {
                    entityToBeLaunched.method_45319(new class_243(0.0, 0.2F, 0.0));
                    entityToBeLaunched.field_6037 = true;
                }
            }
        }
    };
    
    public static class_5558<PotentSulfurBlockEntity> sequence(class_5558<PotentSulfurBlockEntity> first, class_5558<PotentSulfurBlockEntity> second) {
        return (level, pos, state, sulfur) -> {
            first.tick(level, pos, state, sulfur);
            second.tick(level, pos, state, sulfur);
        };
    }

    public PotentSulfurBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.POTENT_SULFUR.get(), pos, state);
    }

    @Override
    protected void method_11007(class_2487 tag, class_7225.class_7874 registries) {
        super.method_11007(tag, registries);
        tag.method_10569("countdown", this.waitingCountdown);
    }

    @Override
    protected void method_11014(class_2487 tag, class_7225.class_7874 registries) {
        super.method_11014(tag, registries);
        this.waitingCountdown = tag.method_10550("countdown");
    }

    @Override
    public void method_31662(class_1937 level) {
        super.method_31662(level);
        if (this.eruptionTick == -1L) {
            this.eruptionTick = level.method_8510();
        }
    }

    public void resetCountdown() {
        this.waitingCountdown = -1;
    }

    private static void applyNauseaEffect(class_1309 entity) {
        entity.method_6092(new class_1293(class_1294.field_5916, 80, 0, true, true));
    }

    private static List<class_1309> getNearbyLivingEntities(class_1937 level, class_2338 pos) {
        class_238 aabb = new class_238(pos).method_1009(2.5, 0.0, 2.5);
        return level.method_8390(class_1309.class, aabb, EFFECT_PREDICATE);
    }

    public static class_5819 geyserPositional(class_3218 level, class_2338 pos) {
        return new class_6677(level.method_8412() ^ GEYSER_SALT).method_38421().method_38419(pos);
    }

    private static void spawnGeyserParticle(class_1937 level, class_2338 sulfur, class_2338 source) {
        int waterBlocks = source.method_10264() - sulfur.method_10264() - 1;
        level.method_8406(new GeyserParticleOptions(ModParticles.GEYSER.get(), waterBlocks), source.method_10263() + 0.5, source.method_10264(), source.method_10260() + 0.5, 0.0, 0.0, 0.0);
    }

    private static void spawnNoxiousGasCloudParticle(class_1937 level, class_243 pos) {
        level.method_8406(ModParticles.NOXIOUS_GAS_CLOUD.get(), pos.field_1352, pos.field_1351, pos.field_1350, 0.0, 0.0, 0.0);
    }

    private static int getUnobstructedBlockCount(class_1937 level, class_2338 pos, int waterBlocks) {
        int geyserForceHeight = 6 * waterBlocks;
        class_3726 context = CollisionUtils.positionContext(pos.method_10074().method_10264());

        for (int i = 0; i < geyserForceHeight; i++) {
            class_2338 currentPos = pos.method_10086(i);
            class_2680 state = level.method_8320(currentPos);
            if (!isGeyserPassableBlock(state, level, currentPos, context)) {
                return i;
            }
        }

        return geyserForceHeight;
    }

    private static boolean isGeyserPassableBlock(class_2680 state, class_1937 level, class_2338 pos, class_3726 context) {
        return state.method_26215() || state.method_27852(class_2246.field_10382) || state.method_26194(level, pos, context).method_1110();
    }

    @Nullable
    private static class_2338 findNoxiousGasSourceBlock(class_1937 level, class_2338 origin) {
        int maxY = origin.method_10264() + 4 + 1;
        class_3726 context = CollisionUtils.positionContext(origin.method_10264());
        class_2338.class_2339 pos = origin.method_10086(1).method_25503();

        while (pos.method_10264() <= maxY) {
            class_2680 state = level.method_8320(pos);
            boolean isWaterLogged = level.method_8316(pos).method_33659(class_3612.field_15910);
            if (!isWaterLogged || !state.method_27852(class_2246.field_10382) && !isGeyserPassableBlock(state, level, pos, context)) {
                if (state.method_26215() || isGeyserPassableBlock(state, level, pos, context)) {
                    return pos.method_10062();
                }
                break;
            }

            pos.method_10098(class_2350.field_11036);
        }

        return null;
    }

    public static boolean canBeReachedByNoxiousGas(class_1937 level, class_2338 origin, class_243 pos) {
        class_2338 blockPos = class_2338.method_49638(pos);
        class_3726 context = CollisionUtils.positionContext(blockPos.method_10074().method_10264());
        if (!isGeyserPassableBlock(level.method_8320(blockPos), level, blockPos, context)) {
            return false;
        } else if (pos.method_1025(class_243.method_24953(origin)) > 9.0) {
            return false;
        } else {
            class_243 belowSource = class_243.method_24953(origin.method_10074());
            class_243 belowPos = pos.method_38499(class_2350.class_2351.field_11052, pos.field_1351 - 1.0);
            return isWater(level, belowPos) && haveLineOfSight(level, belowSource, belowPos);
        }
    }

    private static boolean isWater(class_1937 level, class_243 pos) {
        return level.method_8316(class_2338.method_49638(pos)).method_33659(class_3612.field_15910);
    }

    private static boolean haveLineOfSight(class_1937 level, class_243 from, class_243 to) {
        class_239 hitResult = level.method_17742(new class_3959(from, to, class_3959.class_3960.field_23142, class_3959.class_242.field_1348, class_3726.method_16194()));
        return hitResult.method_17783() != class_239.class_240.field_1332;
    }
}