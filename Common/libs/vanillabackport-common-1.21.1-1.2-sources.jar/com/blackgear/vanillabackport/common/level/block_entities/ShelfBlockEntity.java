package com.blackgear.vanillabackport.common.level.block_entities;

import com.blackgear.vanillabackport.common.registries.blocks.ModBlockEntities;
import net.minecraft.class_1262;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_5712;
import net.minecraft.class_6880;
import net.minecraft.class_7225;
import net.minecraft.class_9288;
import net.minecraft.class_9323;
import net.minecraft.class_9334;
import org.jetbrains.annotations.Nullable;

public class ShelfBlockEntity extends class_2586 implements ListBackedContainer {
    private static final String ALIGN_ITEMS_TO_BOTTOM_TAG = "align_items_to_bottom";
    private final class_2371<class_1799> items = class_2371.method_10213(3, class_1799.field_8037);
    private boolean alignItemsToBottom;
    
    public ShelfBlockEntity(class_2338 pos, class_2680 blockState) {
        super(ModBlockEntities.SHELF.get(), pos, blockState);
    }
    
    @Override
    protected void method_11014(class_2487 tag, class_7225.class_7874 registries) {
        super.method_11014(tag, registries);
        this.items.clear();
        class_1262.method_5429(tag, this.items, registries);
        this.alignItemsToBottom = tag.method_10577(ALIGN_ITEMS_TO_BOTTOM_TAG);
    }
    
    @Override
    protected void method_11007(class_2487 tag, class_7225.class_7874 registries) {
        super.method_11007(tag, registries);
        class_1262.method_5426(tag, this.items, registries);
        tag.method_10556(ALIGN_ITEMS_TO_BOTTOM_TAG, this.alignItemsToBottom);
    }
    
    @Override
    public @Nullable class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }
    
    @Override
    public class_2487 method_16887(class_7225.class_7874 registries) {
        class_2487 tag = new class_2487();
        class_1262.method_5426(tag, this.items, registries);
        tag.method_10556(ALIGN_ITEMS_TO_BOTTOM_TAG, this.alignItemsToBottom);
        return tag;
    }
    
    @Override
    public class_2371<class_1799> getItems() {
        return this.items;
    }
    
    @Override
    public boolean method_5443(class_1657 player) {
        return class_1263.method_49105(this, player);
    }
    
    public class_1799 swapItemNoUpdate(int slot, class_1799 stack) {
        class_1799 retrievedItem = this.method_5441(slot);
        this.setItemNoUpdate(slot, stack);
        return retrievedItem;
    }

    public void setChanged(@Nullable class_6880.class_6883<class_5712> event) {
        super.method_5431();
        if (this.field_11863 != null) {
            if (event != null) {
                this.field_11863.method_43276(event, this.field_11867, class_5712.class_7397.method_43287(this.method_11010()));
            }
        
            this.field_11863.method_8413(this.method_11016(), this.method_11010(), this.method_11010(), 3);
        }
    }
    
    @Override
    public void method_5431() {
        this.setChanged(class_5712.field_28174);
    }

    @Override
    protected void method_57568(class_9473 components) {
        super.method_57568(components);
        components.method_58695(class_9334.field_49622, class_9288.field_49334).method_57492(this.items);
    }

    @Override
    protected void method_57567(class_9323.class_9324 components) {
        super.method_57567(components);
        components.method_57840(class_9334.field_49622, class_9288.method_57493(this.items));
    }

    @Override
    public void method_57569(class_2487 tag) {
        tag.method_10551("Items");
    }

    public boolean getAlignItemsToBottom() {
        return this.alignItemsToBottom;
    }
}