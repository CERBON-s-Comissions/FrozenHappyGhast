package com.blackgear.vanillabackport.common.level.blocks;

import com.blackgear.vanillabackport.client.registries.ModSoundEvents;
import com.blackgear.vanillabackport.common.level.block_entities.CreakingHeartBlockEntity;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlockEntities;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlockStateProperties;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.blackgear.vanillabackport.core.data.tags.ModBlockTags;
import com.blackgear.vanillabackport.core.util.Utilities.DirectionUtils;
import com.blackgear.vanillabackport.core.util.WorldUtilities.EnvironmentUtils;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_1264;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1927;
import net.minecraft.class_1927.class_4179;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2464;
import net.minecraft.class_2465;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2754;
import net.minecraft.class_3218;
import net.minecraft.class_3419;
import net.minecraft.class_4538;
import net.minecraft.class_5558;
import net.minecraft.class_5819;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.Nullable;

import java.util.function.BiConsumer;

import static com.blackgear.vanillabackport.core.util.Utilities.*;
import static com.blackgear.vanillabackport.core.util.WorldUtilities.*;

public class CreakingHeartBlock extends class_2237 {
    public static final class_2754<class_2350.class_2351> AXIS = class_2741.field_12496;
    public static final class_2754<CreakingHeartState> STATE = ModBlockStateProperties.CREAKING_HEART_STATE;
    public static final class_2746 NATURAL = ModBlockStateProperties.NATURAL;

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return method_54094(CreakingHeartBlock::new);
    }

    public CreakingHeartBlock(class_2251 properties) {
        super(properties);
        this.method_9590(this.method_9564()
            .method_11657(AXIS, class_2350.class_2351.field_11052)
            .method_11657(STATE, CreakingHeartState.UPROOTED)
            .method_11657(NATURAL, false));
    }
    
    @Override
    public @Nullable class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new CreakingHeartBlockEntity(pos, state);
    }
    
    @Override
    public @Nullable <T extends class_2586> class_5558<T> method_31645(class_1937 level, class_2680 state, class_2591<T> blockEntityType) {
        if (level.method_8608()) {
            return null;
        } else {
            return state.method_11654(STATE) != CreakingHeartState.UPROOTED
                ? method_31618(blockEntityType, ModBlockEntities.CREAKING_HEART.get(), CreakingHeartBlockEntity::serverTick)
                : null;
        }
    }
    
    @Override
    public void method_9496(class_2680 state, class_1937 level, class_2338 pos, class_5819 random) {
        if (VanillaBackport.COMMON_CONFIG.doCreakingHeartsWorkOnDay.get() || EnvironmentUtils.isNaturalNight(level)) {
            if (state.method_11654(STATE) != CreakingHeartState.UPROOTED) {
                if (random.method_43048(16) == 0 && isSurroundedByLogs(level, pos)) {
                    level.method_8486(pos.method_10263(), pos.method_10264(), pos.method_10260(), ModSoundEvents.CREAKING_HEART_IDLE.get(), class_3419.field_15245, 1.0F, 1.0F, false);
                }
            }
        }
    }
    
    @Override
    public class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 level, class_2338 pos, class_2338 neighborPos) {
        level.method_39279(pos, this, 1);
        return super.method_9559(state, direction, neighborState, level, pos, neighborPos);
    }
    
    @Override
    public void method_9588(class_2680 state, class_3218 level, class_2338 pos, class_5819 random) {
        class_2680 newState = updateState(state, level, pos);
        if (newState != state) {
            level.method_8501(pos, newState);
        }
    }
    
    private static class_2680 updateState(class_2680 state, class_1937 level, class_2338 pos) {
        boolean hasLogs = hasRequiredLogs(state, level, pos);
        boolean disabled = state.method_11654(STATE) == CreakingHeartState.UPROOTED;
        return hasLogs && disabled
            ? state.method_11657(STATE, VanillaBackport.COMMON_CONFIG.doCreakingHeartsWorkOnDay.get() || EnvironmentUtils.isNaturalNight(level) ? CreakingHeartState.AWAKE : CreakingHeartState.DORMANT)
            : state;
    }
    
    public static boolean hasRequiredLogs(class_2680 state, class_4538 level, class_2338 pos) {
        class_2350.class_2351 axis = state.method_11654(AXIS);
        
        for (class_2350 dir : DirectionUtils.getDirections(axis)) {
            class_2680 neighbour = level.method_8320(pos.method_10093(dir));
            boolean canRotate = neighbour.method_28498(AXIS) && neighbour.method_11654(AXIS) == axis;
            if (!neighbour.method_26164(ModBlockTags.CREAKING_HEART_HOLDERS) || !canRotate) return false;
        }
        
        return true;
    }
    
    private static boolean isSurroundedByLogs(class_1936 level, class_2338 pos) {
        for (class_2350 dir : class_2350.values()) {
            class_2338 neighbourPos = pos.method_10093(dir);
            class_2680 neighbourState = level.method_8320(neighbourPos);
            if (!neighbourState.method_26164(ModBlockTags.CREAKING_HEART_HOLDERS)) {
                return false;
            }
        }
        
        return true;
    }
    
    @Override
    public @Nullable class_2680 method_9605(class_1750 context) {
        return updateState(this.method_9564().method_11657(AXIS, context.method_8038().method_10166()), context.method_8045(), context.method_8037());
    }
    
    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return class_2465.method_36377(state, rotation);
    }
    
    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(AXIS, STATE, NATURAL);
    }
    
    @Override
    protected void method_9536(class_2680 state, class_1937 level, class_2338 pos, class_2680 newState, boolean movedByPiston) {
        class_1264.method_54291(state, newState, level, pos);
        if (!state.method_27852(newState.method_26204())) {
            super.method_9536(state, level, pos, newState, movedByPiston);
            level.method_8455(pos, state.method_26204());
        }
    }
    
    @Override
    protected void method_55124(class_2680 state, class_1937 level, class_2338 pos, class_1927 explosion, BiConsumer<class_1799, class_2338> dropConsumer) {
        boolean shouldAffectBlocklikeEntities = explosion.method_55111() == class_4179.field_18687 || explosion.method_55111() == class_4179.field_40879;
        if (level.method_8321(pos) instanceof CreakingHeartBlockEntity heart && !level.method_8608() && shouldAffectBlocklikeEntities) {
            heart.removeProtector(explosion.field_9193);
            if (explosion.method_8347() instanceof class_1657 player) {
                this.tryAwardExperience(player, state, level, pos);
            }
        }
        
        super.method_55124(state, level, pos, explosion, dropConsumer);
    }
    
    @Override
    public class_2680 method_9576(class_1937 level, class_2338 pos, class_2680 state, class_1657 player) {
        if (level.method_8321(pos) instanceof CreakingHeartBlockEntity heart) {
            heart.removeProtector(player.method_48923().method_48802(player));
            this.tryAwardExperience(player, state, level, pos);
        }
        
        return super.method_9576(level, pos, state, player);
    }
    
    private void tryAwardExperience(class_1657 player, class_2680 state, class_1937 level, class_2338 pos) {
        if (!player.method_31549().field_7477 && !player.method_7325() && state.method_11654(NATURAL) && level instanceof class_3218 server) {
            this.method_9583(server, pos, level.method_8409().method_39332(20, 24));
        }
    }
    
    @Override
    public boolean method_9498(class_2680 state) {
        return true;
    }
    
    @Override
    public int method_9572(class_2680 state, class_1937 level, class_2338 pos) {
        if (state.method_11654(STATE) == CreakingHeartState.UPROOTED) {
            return 0;
        } else {
            return level.method_8321(pos) instanceof CreakingHeartBlockEntity heart ? heart.getAnalogOutputSignal() : 0;
        }
    }
    
    @Override
    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }
}