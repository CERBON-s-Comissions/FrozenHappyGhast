package com.blackgear.vanillabackport.common.level.entities.mob.animal.nautilus;

import com.blackgear.vanillabackport.client.registries.ModSoundEvents;
import com.blackgear.vanillabackport.common.api.modules.mob_variant.VariantDataHolder;
import com.blackgear.vanillabackport.common.api.modules.mob_variant.VariantSpawner;
import com.blackgear.vanillabackport.common.api.modules.mob_variant.VariantUtils;
import com.blackgear.vanillabackport.common.api.modules.mob_variant.spawn.SpawnContext;
import com.mojang.serialization.Dynamic;
import net.minecraft.class_1266;
import net.minecraft.class_1282;
import net.minecraft.class_1296;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1315;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3695;
import net.minecraft.class_3730;
import net.minecraft.class_4095;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.class_5425;
import net.minecraft.world.entity.*;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

public class ZombieNautilus extends AbstractNautilus implements VariantDataHolder<ZombieNautilusVariant> {
    private static final class_2940<String> DATA_VARIANT_ID = class_2945.method_12791(ZombieNautilus.class, class_2943.field_13326);
    
    public ZombieNautilus(class_1299<? extends AbstractNautilus> entityType, class_1937 level) {
        super(entityType, level);
    }
    
    public static class_5132.class_5133 createAttributes() {
        return AbstractNautilus.createAttributes().method_26868(class_5134.field_23719, 1.1F);
    }
    
    @Override
    public @Nullable class_1296 method_5613(class_3218 level, class_1296 otherParent) {
        return null;
    }
    
    @Override
    protected class_4095<?> method_18867(Dynamic<?> dynamic) {
        return ZombieNautilusAi.makeBrain(this.method_28306().method_28335(dynamic));
    }
    
    @Override
    protected class_4095.class_5303<ZombieNautilus> method_28306() {
        return ZombieNautilusAi.brainProvider();
    }
    
    @Override @SuppressWarnings("unchecked")
    public class_4095<ZombieNautilus> method_18868() {
        return (class_4095<ZombieNautilus>) super.method_18868();
    }
    
    
    @Override
    protected void method_5958() {
        class_3695 profiler = this.method_37908().method_16107();
        profiler.method_15396("zombieNautilusBrain");
        this.method_18868().method_19542((class_3218) this.method_37908(), this);
        profiler.method_15405("zombieNautilusActivityUpdate");
        ZombieNautilusAi.updateActivity(this);
        profiler.method_15407();
        super.method_5958();
    }
    
    
    @Override
    protected class_3414 method_5994() {
        return this.method_5869() ? ModSoundEvents.ZOMBIE_NAUTILUS_AMBIENT.get() : ModSoundEvents.ZOMBIE_NAUTILUS_AMBIENT_ON_LAND.get();
    }
    
    @Override
    protected class_3414 method_6011(class_1282 source) {
        return this.method_5869() ? ModSoundEvents.ZOMBIE_NAUTILUS_HURT.get() : ModSoundEvents.ZOMBIE_NAUTILUS_HURT_ON_LAND.get();
    }
    
    @Override
    protected class_3414 method_6002() {
        return this.method_5869() ? ModSoundEvents.ZOMBIE_NAUTILUS_DEATH.get() : ModSoundEvents.ZOMBIE_NAUTILUS_DEATH_ON_LAND.get();
    }
    
    @Override
    protected class_3414 getDashSound() {
        return this.method_5869() ? ModSoundEvents.ZOMBIE_NAUTILUS_DASH.get() : ModSoundEvents.ZOMBIE_NAUTILUS_DASH_ON_LAND.get();
    }
    
    @Override
    protected class_3414 getDashReadySound() {
        return this.method_5869() ? ModSoundEvents.ZOMBIE_NAUTILUS_DASH_READY.get() : ModSoundEvents.ZOMBIE_NAUTILUS_DASH_READY_ON_LAND.get();
    }
    
    @Override
    protected void playEatingSound() {
        this.method_43077(ModSoundEvents.ZOMBIE_NAUTILUS_EAT.get());
    }
    
    @Override
    protected class_3414 method_5737() {
        return ModSoundEvents.ZOMBIE_NAUTILUS_SWIM.get();
    }
    
    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        super.method_5693(builder);
        builder.method_56912(DATA_VARIANT_ID, "minecraft:temperate");
    }
    
    @Override
    public void setVariantData(ZombieNautilusVariant variant) {
        this.field_6011.method_12778(DATA_VARIANT_ID, VariantUtils.getID(ZombieNautilusVariants.REGISTRIES, variant));
    }
    
    @Override
    public Optional<ZombieNautilusVariant> getVariantData() {
        return VariantUtils.getOrDefault(ZombieNautilusVariants.REGISTRIES, this.field_6011.method_12789(DATA_VARIANT_ID));
    }
    
    @Override
    public void method_5749(class_2487 compound) {
        super.method_5749(compound);
        VariantUtils.readVariantSaveData(this, compound, ZombieNautilusVariants.REGISTRIES);
    }
    
    @Override
    public void method_5652(class_2487 compound) {
        super.method_5652(compound);
        VariantUtils.addVariantSaveData(this, compound, ZombieNautilusVariants.REGISTRIES);
    }
    
    @Override
    public @Nullable class_1315 method_5943(class_5425 level, class_1266 difficulty, class_3730 reason, @Nullable class_1315 spawnData) {
        VariantUtils.selectVariantToSpawn(SpawnContext.create(level, this.method_24515()), ZombieNautilusVariants.REGISTRIES, VariantSpawner.DEFAULT)
            .ifPresent(this::setVariantData);
        return super.method_5943(level, difficulty, reason, spawnData);
    }
    
    @Override
    public boolean method_5931() {
        return !this.isAggravated() && !this.isMobControlled();
    }
    
    @Override
    public void method_7217(boolean baby) {
    }
    
    @Override
    public void method_6007() {
        super.method_6007();
        if (this.method_5805() && this.method_5972()) {
            class_1304 equipmentSlot = class_1304.field_48824;
            class_1799 itemStack = this.method_6118(equipmentSlot);
            if (!itemStack.method_7960()) {
                if (itemStack.method_7963()) {
                    class_1792 item = itemStack.method_7909();
                    itemStack.method_7974(itemStack.method_7919() + this.field_5974.method_43048(2));
                    if (itemStack.method_7919() >= itemStack.method_7936()) {
                        this.method_20235(item, equipmentSlot);
                        this.method_5673(equipmentSlot, class_1799.field_8037);
                    }
                }
                
            } else {
                this.method_5639(8.0F);
            }
        }
    }
}