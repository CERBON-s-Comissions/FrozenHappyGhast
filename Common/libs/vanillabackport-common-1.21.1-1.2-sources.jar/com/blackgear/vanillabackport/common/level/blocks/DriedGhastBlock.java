package com.blackgear.vanillabackport.common.level.blocks;

import com.blackgear.vanillabackport.client.registries.ModSoundEvents;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.happy_ghast.HappyGhast;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlockStateProperties;
import com.blackgear.vanillabackport.common.registries.entities.ModEntityTypes;
import com.blackgear.vanillabackport.core.data.tags.ModBlockTags;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_10;
import net.minecraft.class_1309;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2758;
import net.minecraft.class_3218;
import net.minecraft.class_3419;
import net.minecraft.class_3486;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_5712;
import net.minecraft.class_5819;
import org.jetbrains.annotations.Nullable;

public class DriedGhastBlock extends class_2383 implements class_3737 {
    public static final MapCodec<DriedGhastBlock> CODEC = method_54094(DriedGhastBlock::new);
    public static final int MAX_HYDRATION_LEVEL = 3;
    public static final class_2758 HYDRATION_LEVEL = ModBlockStateProperties.HYDRATION_LEVEL;
    public static final class_2746 WATERLOGGED = class_2741.field_12508;
    public static final int HYDRATION_TICK_DELAY = 5000;
    private static final class_265 SHAPE = class_2248.method_9541(3.0, 0.0, 3.0, 13.0, 10.0, 13.0);

    @Override
    public MapCodec<DriedGhastBlock> method_53969() {
        return field_46280;
    }

    public DriedGhastBlock(class_2251 properties) {
        super(properties);
        this.method_9590(
            this.method_9595()
                .method_11664()
                .method_11657(field_11177, class_2350.field_11043)
                .method_11657(HYDRATION_LEVEL, 0)
                .method_11657(WATERLOGGED, false)
        );
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(field_11177, HYDRATION_LEVEL, WATERLOGGED);
    }

    @Override
    public class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 level, class_2338 pos, class_2338 neighborPos) {
        if (state.method_11654(WATERLOGGED)) {
            level.method_39281(pos, class_3612.field_15910, class_3612.field_15910.method_15789(level));
        }

        return super.method_9559(state, direction, neighborState, level, pos, neighborPos);
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    public int getHydrationLevel(class_2680 state) {
        return state.method_11654(HYDRATION_LEVEL);
    }

    private boolean isReadyToSpawn(class_2680 state) {
        return this.getHydrationLevel(state) == MAX_HYDRATION_LEVEL;
    }

    @Override
    public void method_9588(class_2680 state, class_3218 level, class_2338 pos, class_5819 random) {
        if (state.method_11654(WATERLOGGED)) {
            this.tickWaterlogged(state, level, pos, random);
        } else {
            int hydrationLevel = this.getHydrationLevel(state);
            if (hydrationLevel > 0) {
                level.method_8652(pos, state.method_11657(HYDRATION_LEVEL, hydrationLevel - 1), 2);
                level.method_43276(class_5712.field_28733, pos, class_5712.class_7397.method_43287(state));
            }
        }
    }

    private void tickWaterlogged(class_2680 state, class_3218 level, class_2338 pos, class_5819 random) {
        if (!this.isReadyToSpawn(state)) {
            level.method_8396(null, pos, ModSoundEvents.DRIED_GHAST_TRANSITION.get(), class_3419.field_15245, 1.0F, 1.0F);
            level.method_8652(pos, state.method_11657(HYDRATION_LEVEL, this.getHydrationLevel(state) + 1), 2);
            level.method_43276(class_5712.field_28733, pos, class_5712.class_7397.method_43287(state));
        } else {
            this.spawnGhastling(level, pos, state);
        }
    }

    private void spawnGhastling(class_3218 level, class_2338 pos, class_2680 state) {
        level.method_8650(pos, false);
        HappyGhast ghast = ModEntityTypes.HAPPY_GHAST.get().method_5883(level);
        if (ghast != null) {
            class_243 center = class_243.method_24955(pos);
            ghast.method_7217(true);
            float yRot = getYRot(state.method_11654(field_11177));
            ghast.method_5847(yRot);
            ghast.method_23327(center.method_10216(), center.method_10214(), center.method_10215());
            ghast.method_36456(yRot);
            ghast.method_36457(0.0F);
            ghast.method_22862();
            ghast.method_5814(ghast.method_19538().method_10216(), ghast.method_19538().method_10214(), ghast.method_19538().method_10215());
            level.method_8649(ghast);
            level.method_43129(null, ghast, ModSoundEvents.GHASTLING_SPAWN.get(), class_3419.field_15245, 1.0F, 1.0F);
        }
    }

    public static float getYRot(class_2350 direction) {
        return switch (direction) {
            case field_11043 -> 180.0F;
            case field_11035 -> 0.0F;
            case field_11039 -> 90.0F;
            case field_11034 -> -90.0F;
            default -> throw new IllegalStateException("No y-Rot for vertical axis: " + direction);
        };
    }

    @Override
    public void method_9496(class_2680 state, class_1937 level, class_2338 pos, class_5819 random) {
        double x = pos.method_10263() + 0.5;
        double y = pos.method_10264() + 0.5;
        double z = pos.method_10260() + 0.5;
        if (!state.method_11654(WATERLOGGED)) {
            if (random.method_43048(40) == 0 && level.method_8320(pos.method_10074()).method_26164(ModBlockTags.TRIGGERS_AMBIENT_DRIED_GHAST_BLOCK_SOUNDS)) {
                level.method_8486(x, y, z, ModSoundEvents.DRIED_GHAST_AMBIENT.get(), class_3419.field_15256, 1.0F, 1.0F, false);
            }

            if (random.method_43048(6) == 0) {
                level.method_8406(class_2398.field_11251, x, y, z, 0.0, 0.02, 0.0);
            }
        } else {
            if (random.method_43048(40) == 0) {
                level.method_8486(x, y, z, ModSoundEvents.DRIED_GHAST_AMBIENT_WATER.get(), class_3419.field_15256, 1.0F, 1.0F, false);
            }

            if (random.method_43048(6) == 0) {
                level.method_8406(
                    class_2398.field_11211,
                    x + (random.method_43057() * 2.0F - 1.0F) / 3.0F, y + 0.4, z + (random.method_43057() * 2.0F - 1.0F) / 3.0F,
                    0.0, random.method_43057(), 0.0
                );
            }
        }
    }

    @Override
    public void method_9514(class_2680 state, class_3218 level, class_2338 pos, class_5819 random) {
        if ((state.method_11654(WATERLOGGED) || state.method_11654(HYDRATION_LEVEL) > 0) && !level.method_14196().method_8674(pos, this)) {
            level.method_39279(pos, this, HYDRATION_TICK_DELAY);
        }
    }

    @Override
    public @Nullable class_2680 method_9605(class_1750 context) {
        class_3610 state = context.method_8045().method_8316(context.method_8037());
        boolean isWaterlogged = state.method_15767(class_3486.field_15517) && state.method_15761() == 8;
        return super.method_9605(context)
            .method_11657(WATERLOGGED, isWaterlogged)
            .method_11657(field_11177, context.method_8042().method_10153());
    }

    @Override
    public class_3610 method_9545(class_2680 state) {
        return state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
    }

    @Override
    public boolean method_10311(class_1936 level, class_2338 pos, class_2680 state, class_3610 fluidState) {
        if (state.method_11654(class_2741.field_12508) || fluidState.method_15772() != class_3612.field_15910) {
            return false;
        }

        if (!level.method_8608()) {
            level.method_8652(pos, state.method_11657(class_2741.field_12508, true), 3);
            level.method_39281(pos, fluidState.method_15772(), fluidState.method_15772().method_15789(level));
            level.method_8396(null, pos, ModSoundEvents.DRIED_GHAST_PLACE_IN_WATER.get(), class_3419.field_15245, 1.0F, 1.0F);
        }

        return true;
    }

    @Override
    public void method_9567(class_1937 level, class_2338 pos, class_2680 state, @Nullable class_1309 placer, class_1799 stack) {
        super.method_9567(level, pos, state, placer, stack);
        level.method_8396(null, pos, state.method_11654(WATERLOGGED) ? ModSoundEvents.DRIED_GHAST_PLACE_IN_WATER.get() : ModSoundEvents.DRIED_GHAST_PLACE.get(), class_3419.field_15245, 1.0F, 1.0F);
    }

    @Override
    protected boolean method_9516(class_2680 state, class_10 pathComputationType) {
        return false;
    }
}