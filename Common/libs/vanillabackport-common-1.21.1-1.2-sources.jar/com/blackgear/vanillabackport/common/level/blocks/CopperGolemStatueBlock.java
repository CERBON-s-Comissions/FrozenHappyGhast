package com.blackgear.vanillabackport.common.level.blocks;

import com.blackgear.vanillabackport.client.registries.ModSoundEvents;
import com.blackgear.vanillabackport.common.level.block_entities.CopperGolemStatueBlockEntity;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlockStateProperties;
import com.blackgear.vanillabackport.core.data.tags.ModBlockTags;
import com.blackgear.vanillabackport.core.util.WeatheredData;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_10;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2754;
import net.minecraft.class_3419;
import net.minecraft.class_3486;
import net.minecraft.class_3489;
import net.minecraft.class_3542;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5712;
import net.minecraft.class_5955.class_5811;
import net.minecraft.class_7995;
import net.minecraft.class_9062;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.Nullable;

import java.util.function.IntFunction;

public class CopperGolemStatueBlock extends class_2237 implements class_3737 {
    public static final MapCodec<CopperGolemStatueBlock> field_46280 = RecordCodecBuilder.mapCodec(instance -> instance.group(
        WeatheredData.CODEC.fieldOf("weathering_state").forGetter(CopperGolemStatueBlock::getWeatheringState),
        method_54096()
    ).apply(instance, CopperGolemStatueBlock::new));

    public static final class_2754<class_2350> FACING = class_2741.field_12481;
    public static final class_2754<Pose> POSE = ModBlockStateProperties.COPPER_GOLEM_POSE;
    public static final class_2746 WATERLOGGED = class_2741.field_12508;
    private static final class_265 SHAPE = class_2248.method_9541(3.0, 0.0, 3.0, 13.0, 14.0, 13.0);
    private final class_5811 weatheringState;

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    public CopperGolemStatueBlock(class_5811 weatheringState, class_2251 properties) {
        super(properties);
        this.weatheringState = weatheringState;
        this.method_9590(this.method_9564()
            .method_11657(FACING, class_2350.field_11043)
            .method_11657(POSE, Pose.STANDING)
            .method_11657(WATERLOGGED, false));
    }
    
    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        builder.method_11667(FACING, POSE, WATERLOGGED);
    }
    
    @Override
    public @Nullable class_2680 method_9605(class_1750 context) {
        class_3610 replaceFluidState = context.method_8045().method_8316(context.method_8037());
        return this.method_9564()
            .method_11657(FACING, context.method_8042().method_10153())
            .method_11657(WATERLOGGED, replaceFluidState.method_39360(class_3612.field_15910));
    }
    
    @Override
    protected class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(FACING, rotation.method_10503(state.method_11654(FACING)));
    }
    
    @Override
    protected class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(FACING)));
    }
    
    @Override
    protected class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return SHAPE;
    }
    
    public class_5811 getWeatheringState() {
        return this.weatheringState;
    }
    
    @Override
    protected class_9062 method_55765(
        class_1799 stack,
        class_2680 state,
        class_1937 level,
        class_2338 pos,
        class_1657 player,
        class_1268 hand,
        class_3965 hitResult
    ) {
        if (stack.method_31573(class_3489.field_42612)) {
            return class_9062.field_47731;
        } else {
            this.updatePose(level, state, pos, player);
            return class_9062.field_47728;
        }
    }
    
    protected void updatePose(class_1937 level, class_2680 state, class_2338 pos, class_1657 player) {
        level.method_45447(null, pos, ModSoundEvents.COPPER_GOLEM_BECOME_STATUE.get(), class_3419.field_15245);
        level.method_8652(pos, state.method_11657(POSE, state.method_11654(POSE).getNextPose()), class_2248.field_31036);
        level.method_33596(player, class_5712.field_28733, pos);
    }
    
    @Override
    protected boolean method_9516(class_2680 state, class_10 type) {
        return type == class_10.field_48 && state.method_26227().method_15767(class_3486.field_15517);
    }
    
    @Override
    public @Nullable class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new CopperGolemStatueBlockEntity(pos, state);
    }
    
    @Override
    protected boolean method_9498(class_2680 state) {
        return true;
    }
    
    @Override
    protected int method_9572(class_2680 state, class_1937 level, class_2338 pos) {
        return state.method_11654(POSE).ordinal();
    }
    
    @Override
    public class_1799 method_9574(class_4538 level, class_2338 pos, class_2680 state) {
        return level.method_8321(pos) instanceof CopperGolemStatueBlockEntity golem
            ? golem.getItem(this.method_8389().method_7854(), state.method_11654(POSE))
            : super.method_9574(level, pos, state);
    }
    
    @Override
    protected class_3610 method_9545(class_2680 state) {
        return state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
    }
    
    @Override
    protected class_2680 method_9559(
        class_2680 state,
        class_2350 direction,
        class_2680 neighborState,
        class_1936 level,
        class_2338 pos,
        class_2338 neighborPos
    ) {
        if (state.method_11654(WATERLOGGED)) {
            level.method_39281(pos, class_3612.field_15910, class_3612.field_15910.method_15789(level));
        }
        
        return super.method_9559(state, direction, neighborState, level, pos, neighborPos);
    }
    
    @Override
    protected void method_9536(class_2680 oldState, class_1937 level, class_2338 pos, class_2680 newState, boolean movedByPiston) {
        if (oldState.method_31709() && !oldState.method_27852(newState.method_26204()) && !newState.method_26164(ModBlockTags.COPPER_GOLEM_STATUES)) {
            level.method_8544(pos);
        }
    }
    
    public enum Pose implements class_3542 {
        STANDING("standing"),
        SITTING("sitting"),
        RUNNING("running"),
        STAR("star");
        
        public static final IntFunction<Pose> BY_ID = class_7995.method_47914(Enum::ordinal, values(), class_7995.class_7996.field_41664);
        public static final Codec<Pose> CODEC = class_3542.method_28140(Pose::values);
        private final String name;
        
        Pose(String name) {
            this.name = name;
        }
        
        @Override
        public String method_15434() {
            return this.name;
        }
        
        public Pose getNextPose() {
            return BY_ID.apply(this.ordinal() + 1);
        }
    }
}