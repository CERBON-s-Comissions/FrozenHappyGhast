package com.blackgear.vanillabackport.common.level.blocks;

import com.blackgear.vanillabackport.common.registries.blocks.ModBlockStateProperties;
import com.blackgear.vanillabackport.core.util.BlockShaper;
import java.util.Map;
import java.util.function.Function;
import net.minecraft.class_1750;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2753;
import net.minecraft.class_2758;

public interface SegmentableBlock {
    int MIN_SEGMENT = 1;
    int MAX_SEGMENT = 4;
    class_2758 AMOUNT = ModBlockStateProperties.SEGMENT_AMOUNT;
    
    default Function<class_2680, class_265> getShapeCalculator(class_2753 facing, class_2758 amount) {
        Map<class_2350, class_265> shapes = BlockShaper.rotateHorizontal(class_2248.method_9541(0.0, 0.0, 0.0, 8.0, this.getShapeHeight(), 8.0));
        return state -> {
            class_265 shape = class_259.method_1073();
            class_2350 direction = state.method_11654(facing);
            int count = state.method_11654(amount);
            
            for (int i = 0; i < count; i++) {
                shape = class_259.method_1084(shape, shapes.get(direction));
                direction = direction.method_10160();
            }
            
            return shape.method_52620();
        };
    }
    
    default class_2758 getSegmentAmountProperty() {
        return AMOUNT;
    }
    
    default double getShapeHeight() {
        return 1.0;
    }
    
    default boolean canBeReplaced(class_2680 state, class_1750 context, class_2758 segment) {
        return !context.method_8046() && context.method_8041().method_31574(state.method_26204().method_8389()) && state.method_11654(segment) < MAX_SEGMENT;
    }
    
    default class_2680 getStateForPlacement(class_1750 context, class_2248 block, class_2758 segment, class_2753 facing) {
        class_2680 state = context.method_8045().method_8320(context.method_8037());
        return state.method_27852(block)
            ? state.method_11657(segment, Math.min(MAX_SEGMENT, state.method_11654(segment) + MIN_SEGMENT))
            : block.method_9564().method_11657(facing, context.method_8042().method_10153());
    }
}