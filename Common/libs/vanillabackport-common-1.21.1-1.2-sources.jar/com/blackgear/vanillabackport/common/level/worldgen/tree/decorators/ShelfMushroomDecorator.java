package com.blackgear.vanillabackport.common.level.worldgen.tree.decorators;

import com.blackgear.vanillabackport.common.level.blocks.ShelfMushroomBlock;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import com.blackgear.vanillabackport.common.registries.worldgen.ModTreeDecorators;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import java.util.List;
import java.util.function.Predicate;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_4662;
import net.minecraft.class_4663;
import net.minecraft.class_4970;
import net.minecraft.class_5819;

public class ShelfMushroomDecorator extends class_4662 {
    public static final MapCodec<ShelfMushroomDecorator> CODEC = Codec.floatRange(0.0F, 1.0F)
        .fieldOf("probability")
        .xmap(ShelfMushroomDecorator::new, decorator -> decorator.placementProbability);
    private final float placementProbability;
    
    public ShelfMushroomDecorator(float probability) {
        this.placementProbability = probability;
    }
    
    @Override
    protected class_4663<?> method_28893() {
        return ModTreeDecorators.SHELF_MUSHROOM.get();
    }
    
    @Override
    public void method_23469(class_7402 context) {
        class_5819 random = context.method_43320();
        if (!(random.method_43057() >= this.placementProbability)) {
            List<class_2338> logs = context.method_43321();
            if (!logs.isEmpty()) {
                if (isFallenLog(logs)) {
                    placeOnFallenLog(context, logs, random);
                } else {
                    placeOnStandingTree(context, logs, random);
                }
            }
        }
    }
    
    private static void placeOnStandingTree(class_4662.class_7402 context, List<class_2338> logs, class_5819 random) {
        class_2350[] directions = pickTwoPerpendicularDirections(random);
        int treeBaseY = logs.getFirst().method_10264();
        
        for (class_2338 logPos : logs) {
            if (isWithinDecoratableHeight(logPos, treeBaseY)) {
                for (class_2350 facing : directions) {
                    if (!(random.method_43057() > 0.25F) && tryPlaceMushroomOnStandingTree(context, logPos, facing, random)) {
                        break;
                    }
                }
            }
        }
    }
    
    private static void placeOnFallenLog(class_4662.class_7402 context, List<class_2338> logs, class_5819 random) {
        class_2350[] directions = perpendicularToFallenLog(logs);
        
        for (class_2338 logPos : logs) {
            for (class_2350 facing : directions) {
                if (!(random.method_43057() > 0.25F)) {
                    tryPlaceMushroomOnFallenTree(context, logPos, facing, random);
                }
            }
        }
    }
    
    private static boolean tryPlaceMushroomOnStandingTree(
        final class_4662.class_7402 context, class_2338 logPos, class_2350 facing, class_5819 random
    ) {
        class_2338 mushroomPos = mushroomPosFor(logPos, facing);
        if (!isBlockReplaceableWithShelfMushroom(context, mushroomPos)) {
            return false;
        } else if (hasShelfMushroomAt(context, mushroomPos.method_10074())) {
            return false;
        } else {
            placeMushroom(context, mushroomPos, facing, random);
            return true;
        }
    }
    
    private static void tryPlaceMushroomOnFallenTree(class_4662.class_7402 context, class_2338 logPos, class_2350 facing, class_5819 random) {
        class_2338 mushroomPos = mushroomPosFor(logPos, facing);
        if (isBlockReplaceableWithShelfMushroom(context, mushroomPos)) {
            if (!hasHorizontallyAdjacentShelfMushroom(context, mushroomPos) && !hasHorizontallyAdjacentShelfMushroom(context, logPos)) {
                placeMushroom(context, mushroomPos, facing, random);
            }
        }
    }
    
    private static boolean isFallenLog(List<class_2338> logs) {
        return logs.getFirst().method_10264() == logs.getLast().method_10264();
    }
    
    private static class_2350[] pickTwoPerpendicularDirections(class_5819 random) {
        class_2350 first = class_2350.class_2353.field_11062.method_10183(random);
        return new class_2350[]{first, first.method_10170()};
    }
    
    private static class_2350[] perpendicularToFallenLog(List<class_2338> logs) {
        class_2338 first = logs.getFirst();
        class_2338 last = logs.getLast();
        class_2350.class_2351 logAxis = first.method_10263() != last.method_10263() ? class_2350.class_2351.field_11048 : class_2350.class_2351.field_11051;
        return logAxis == class_2350.class_2351.field_11048 ? new class_2350[]{class_2350.field_11043, class_2350.field_11035} : new class_2350[]{class_2350.field_11034, class_2350.field_11039};
    }
    
    private static boolean isWithinDecoratableHeight(class_2338 pos, int treeBaseY) {
        int dy = pos.method_10264() - treeBaseY;
        return dy >= 1 && dy <= 4;
    }
    
    private static class_2338 mushroomPosFor(class_2338 logPos, class_2350 facing) {
        return logPos.method_10069(facing.method_10148(), 0, facing.method_10165());
    }
    
    private static void placeMushroom(class_4662.class_7402 context, class_2338 pos, class_2350 facing, class_5819 random) {
        context.method_43318(
            pos, ModBlocks.SHELF_MUSHROOM.get().method_9564().method_11657(ShelfMushroomBlock.AGE, random.method_43048(2)).method_11657(ShelfMushroomBlock.field_11177, facing)
        );
    }
    
    private static boolean hasShelfMushroomAt(class_4662.class_7402 context, class_2338 pos) {
        return checkBlock(context, pos, state -> state.method_27852(ModBlocks.SHELF_MUSHROOM.get()));
    }
    
    private static boolean hasHorizontallyAdjacentShelfMushroom(class_4662.class_7402 context, class_2338 pos) {
        for (class_2350 dir : class_2350.class_2353.field_11062) {
            if (hasShelfMushroomAt(context, pos.method_10093(dir))) {
                return true;
            }
        }
        
        return false;
    }
    
    public static boolean isBlockReplaceableWithShelfMushroom(class_4662.class_7402 context, class_2338 pos) {
        return isReplaceable(context, pos) && !isWaterOrWaterNearby(context, pos);
    }
    
    private static boolean checkBlock(class_4662.class_7402 context, class_2338 pos, Predicate<class_2680> predicate) {
        return context.method_43316().method_16358(pos, predicate);
    }
    
    public static boolean isReplaceable(class_4662.class_7402 context, class_2338 pos) {
        return checkBlock(context, pos, class_4970.class_4971::method_45474);
    }
    
    public static boolean isWaterOrWaterNearby(class_4662.class_7402 context, class_2338 pos) {
        return checkBlock(context, pos, state -> state.method_27852(class_2246.field_10382))
            || checkBlock(context, pos.method_10078(), state -> state.method_27852(class_2246.field_10382))
            || checkBlock(context, pos.method_10067(), state -> state.method_27852(class_2246.field_10382))
            || checkBlock(context, pos.method_10095(), state -> state.method_27852(class_2246.field_10382))
            || checkBlock(context, pos.method_10072(), state -> state.method_27852(class_2246.field_10382));
    }
}
