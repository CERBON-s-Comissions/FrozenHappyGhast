package com.blackgear.vanillabackport.common.level.entities.mob.animal.golem.copper_golem.container;

import java.util.List;
import net.minecraft.class_1309;
import net.minecraft.class_2586;

public interface ContainerAdapter {
    boolean supports(class_2586 blockEntity);
    
    void startOpen(class_2586 blockEntity, ContainerUser user);
    
    void stopOpen(class_2586 blockEntity, ContainerUser user);
    
    List<class_1309> getEntitiesWithContainerOpen(class_2586 blockEntity);
}