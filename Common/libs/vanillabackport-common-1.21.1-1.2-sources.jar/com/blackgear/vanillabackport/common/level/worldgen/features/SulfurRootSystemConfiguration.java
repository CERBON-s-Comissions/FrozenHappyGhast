package com.blackgear.vanillabackport.common.level.worldgen.features;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_2248;
import net.minecraft.class_3037;
import net.minecraft.class_4651;
import net.minecraft.class_6646;
import net.minecraft.class_6796;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7924;

public record SulfurRootSystemConfiguration(
    class_6880<class_6796> feature,
    int requiredVerticalSpaceForTree,
    int levelTestDistance,
    int maxLevelDeviation,
    int rootRadius,
    class_6862<class_2248> rootReplaceable,
    class_4651 rootStateProvider,
    int rootPlacementAttempts,
    int rootColumnMaxHeight,
    int hangingRootRadius,
    int hangingRootsVerticalSpan,
    class_4651 hangingRootStateProvider,
    int hangingRootPlacementAttempts,
    int allowedVerticalWaterForTree,
    class_6646 allowedTreePosition
) implements class_3037 {
    public static final Codec<SulfurRootSystemConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group(
        class_6796.field_35730.fieldOf("feature").forGetter(SulfurRootSystemConfiguration::feature),
        Codec.intRange(1, 64).fieldOf("required_vertical_space_for_tree").forGetter(SulfurRootSystemConfiguration::requiredVerticalSpaceForTree),
        Codec.intRange(0, 16).fieldOf("level_test_distance").forGetter(SulfurRootSystemConfiguration::levelTestDistance),
        Codec.intRange(0, 64).fieldOf("max_level_deviation").forGetter(SulfurRootSystemConfiguration::maxLevelDeviation),
        Codec.intRange(1, 64).fieldOf("root_radius").forGetter(SulfurRootSystemConfiguration::rootRadius),
        class_6862.method_40093(class_7924.field_41254).fieldOf("root_replaceable").forGetter(SulfurRootSystemConfiguration::rootReplaceable),
        class_4651.field_24937.fieldOf("root_state_provider").forGetter(SulfurRootSystemConfiguration::rootStateProvider),
        Codec.intRange(1, 256).fieldOf("root_placement_attempts").forGetter(SulfurRootSystemConfiguration::rootPlacementAttempts),
        Codec.intRange(1, 4096).fieldOf("root_column_max_height").forGetter(SulfurRootSystemConfiguration::rootColumnMaxHeight),
        Codec.intRange(1, 64).fieldOf("hanging_root_radius").forGetter(SulfurRootSystemConfiguration::hangingRootRadius),
        Codec.intRange(0, 16).fieldOf("hanging_roots_vertical_span").forGetter(SulfurRootSystemConfiguration::hangingRootsVerticalSpan),
        class_4651.field_24937.fieldOf("hanging_root_state_provider").forGetter(SulfurRootSystemConfiguration::hangingRootStateProvider),
        Codec.intRange(1, 256).fieldOf("hanging_root_placement_attempts").forGetter(SulfurRootSystemConfiguration::hangingRootPlacementAttempts),
        Codec.intRange(1, 64).fieldOf("allowed_vertical_water_for_tree").forGetter(SulfurRootSystemConfiguration::allowedVerticalWaterForTree),
        class_6646.field_35054.fieldOf("allowed_tree_position").forGetter(SulfurRootSystemConfiguration::allowedTreePosition)
    ).apply(instance, SulfurRootSystemConfiguration::new));
}
