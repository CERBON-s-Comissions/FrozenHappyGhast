package com.blackgear.vanillabackport.common.level.blocks;

import com.blackgear.vanillabackport.common.level.entities.mob.animal.golem.copper_golem.container.ContainerManager;
import net.minecraft.class_2338;
import net.minecraft.class_2595;
import net.minecraft.class_2680;
import net.minecraft.class_2745;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_5819;
import net.minecraft.class_5955;

public class WeatheringCopperChestBlock extends CopperChestBlock implements class_5955 {
    public WeatheringCopperChestBlock(class_5811 weatherState, class_3414 openSound, class_3414 closeSound, class_2251 properties) {
        super(weatherState, openSound, closeSound, properties);
    }
    
    @Override
    public boolean method_9542(class_2680 state) {
        return class_5955.method_34737(state.method_26204()).isPresent();
    }
    
    @Override
    public void method_9514(class_2680 state, class_3218 level, class_2338 pos, class_5819 random) {
        if (state.method_11654(field_10770) != class_2745.field_12571
            && level.method_8321(pos) instanceof class_2595 chest
            && ContainerManager.getEntitiesWithContainerOpen(chest).isEmpty()) {
            this.method_54764(state, level, pos, random);
        }
    }
    
    @Override
    public class_5811 method_33622() {
        return this.getState();
    }
    
    @Override
    public boolean isWaxed() {
        return false;
    }
}