package com.blackgear.vanillabackport.common.level.components;

import com.blackgear.vanillabackport.common.registries.items.ModDataComponents;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.netty.buffer.ByteBuf;
import net.minecraft.class_1799;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record UseEffects(
    boolean canSprint,
    boolean interactVibrations,
    float speedMultiplier
) {
    public static final UseEffects DEFAULT = new UseEffects(false, true, 0.2F);
    public static final Codec<UseEffects> CODEC = RecordCodecBuilder.create(instance -> instance.group(
        Codec.BOOL.optionalFieldOf("can_sprint", DEFAULT.canSprint).forGetter(UseEffects::canSprint),
        Codec.BOOL.optionalFieldOf("interact_vibrations", DEFAULT.interactVibrations).forGetter(UseEffects::interactVibrations),
        Codec.floatRange(0.0F, 1.0F).optionalFieldOf("speed_multiplier", DEFAULT.speedMultiplier).forGetter(UseEffects::speedMultiplier)
    ).apply(instance, UseEffects::new));
    public static final class_9139<ByteBuf, UseEffects> STREAM_CODEC = class_9139.method_56436(
        class_9135.field_48547, UseEffects::canSprint,
        class_9135.field_48547, UseEffects::interactVibrations,
        class_9135.field_48552, UseEffects::speedMultiplier,
        UseEffects::new
    );
    
    public static UseEffects get(class_1799 stack) {
        Object component = stack.method_57824(ModDataComponents.USE_EFFECTS.get());
        
        if (component == null) return DEFAULT;
        if (component instanceof UseEffects effects) return effects;
        
        try {
            Class<?> clazz = component.getClass();
            
            boolean canSprint = (boolean) clazz.getMethod("canSprint").invoke(component);
            boolean interactVibrations = (boolean) clazz.getMethod("interactVibrations").invoke(component);
            float speedMultiplier = (float) clazz.getMethod("speedMultiplier").invoke(component);
            
            return new UseEffects(canSprint, interactVibrations, speedMultiplier);
        } catch (Exception e) {
            return DEFAULT;
        }
    }
}