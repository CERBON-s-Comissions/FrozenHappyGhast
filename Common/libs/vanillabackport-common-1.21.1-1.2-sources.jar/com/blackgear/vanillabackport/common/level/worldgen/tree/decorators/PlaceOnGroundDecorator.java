package com.blackgear.vanillabackport.common.level.worldgen.tree.decorators;

import com.blackgear.vanillabackport.common.registries.worldgen.ModTreeDecorators;
import com.google.common.collect.Lists;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import net.minecraft.class_1922;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2902;
import net.minecraft.class_3341;
import net.minecraft.class_4651;
import net.minecraft.class_4662;
import net.minecraft.class_4663;
import net.minecraft.class_5699;
import net.minecraft.class_5819;

public class PlaceOnGroundDecorator extends class_4662 {
    public static final MapCodec<PlaceOnGroundDecorator> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
        class_5699.field_33442.fieldOf("tries").orElse(128).forGetter(decorator -> decorator.tries),
        class_5699.field_33441.fieldOf("radius").orElse(2).forGetter(decorator -> decorator.radius),
        class_5699.field_33441.fieldOf("height").orElse(1).forGetter(decorator -> decorator.height),
        class_4651.field_24937.fieldOf("block_state_provider").forGetter(decorator -> decorator.blockStateProvider)
    ).apply(instance, PlaceOnGroundDecorator::new));
    private final int tries;
    private final int radius;
    private final int height;
    private final class_4651 blockStateProvider;

    public PlaceOnGroundDecorator(int tries, int radius, int height, class_4651 blockStateProvider) {
        this.tries = tries;
        this.radius = radius;
        this.height = height;
        this.blockStateProvider = blockStateProvider;
    }

    @Override
    protected class_4663<?> method_28893() {
        return ModTreeDecorators.PLACE_ON_GROUND.get();
    }

    @Override
    public void method_23469(class_4662.class_7402 context) {
        List<class_2338> blockPositions = Lists.newArrayList();
        List<class_2338> roots = context.method_43323();
        List<class_2338> logs = context.method_43321();
        if (roots.isEmpty()) {
            blockPositions.addAll(logs);
        } else if (!logs.isEmpty() && roots.get(0).method_10264() == logs.get(0).method_10264()) {
            blockPositions.addAll(logs);
            blockPositions.addAll(roots);
        } else {
            blockPositions.addAll(roots);
        }

        if (!blockPositions.isEmpty()) {
            class_2338 blockPos = blockPositions.get(0);
            int minY = blockPos.method_10264();
            int minX = blockPos.method_10263();
            int maxX = blockPos.method_10263();
            int minZ = blockPos.method_10260();
            int maxZ = blockPos.method_10260();

            for (class_2338 position : blockPositions) {
                if (position.method_10264() == minY) {
                    minX = Math.min(minX, position.method_10263());
                    maxX = Math.max(maxX, position.method_10263());
                    minZ = Math.min(minZ, position.method_10260());
                    maxZ = Math.max(maxZ, position.method_10260());
                }
            }

            class_5819 random = context.method_43320();
            class_3341 bb = new class_3341(minX, minY, minZ, maxX, minY, maxZ).method_59718(this.radius, this.height, this.radius);
            class_2338.class_2339 pos = new class_2338.class_2339();

            for (int i = 0; i < this.tries; i++) {
                pos.method_10103(
                    random.method_39332(bb.method_35415(), bb.method_35418()),
                    random.method_39332(bb.method_35416(), bb.method_35419()),
                    random.method_39332(bb.method_35417(), bb.method_35420())
                );
                this.attemptToPlaceBlockAbove(context, pos);
            }
        }
    }

    private void attemptToPlaceBlockAbove(class_4662.class_7402 context, class_2338 pos) {
        class_2338 abovePos = pos.method_10084();
        if (context.method_43316().method_16358(abovePos, state -> state.method_26215() || state.method_27852(class_2246.field_10597))
            && context.method_43316().method_16358(pos, state -> state.method_26216((class_1922) context.method_43316(), pos))
            && context.method_43316().method_8598(class_2902.class_2903.field_13203, pos).method_10264() <= abovePos.method_10264()) {
            context.method_43318(abovePos, this.blockStateProvider.method_23455(context.method_43320(), abovePos));
        }
    }
}