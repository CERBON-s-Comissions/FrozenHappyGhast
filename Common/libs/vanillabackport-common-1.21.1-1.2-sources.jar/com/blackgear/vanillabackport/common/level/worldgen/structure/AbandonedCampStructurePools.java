package com.blackgear.vanillabackport.common.level.worldgen.structure;

import com.blackgear.vanillabackport.common.worldgen.placements.TheGardenAwakensPlacements;
import com.blackgear.vanillabackport.common.worldgen.placements.WildernessBoundPlacements;
import com.google.common.collect.ImmutableList;
import com.mojang.datafixers.util.Pair;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.function.Function;
import net.minecraft.class_3784;
import net.minecraft.class_3785;
import net.minecraft.class_5321;
import net.minecraft.class_5468;
import net.minecraft.class_6796;
import net.minecraft.class_6818;
import net.minecraft.class_6880;
import net.minecraft.class_7871;
import net.minecraft.class_7891;
import net.minecraft.class_7924;

public class AbandonedCampStructurePools {
    public static final AbandonedCampStructure BAMBOO_JUNGLE = new AbandonedCampStructure(class_5468.method_46844("abandoned_camp/camp/bamboo_jungle"), class_5468.method_46844("abandoned_camp/tent/bamboo_jungle"), "bamboo_jungle");
    public static final AbandonedCampStructure BIRCH_FOREST = new AbandonedCampStructure(class_5468.method_46844("abandoned_camp/camp/birch_forest"), class_5468.method_46844("abandoned_camp/tent/birch_forest"), "birch_forest");
    public static final AbandonedCampStructure CHERRY_GROVE = new AbandonedCampStructure(class_5468.method_46844("abandoned_camp/camp/cherry_grove"), class_5468.method_46844("abandoned_camp/tent/cherry_grove"), "cherry_grove");
    public static final AbandonedCampStructure DAPPLED_FOREST = new AbandonedCampStructure(class_5468.method_46844("abandoned_camp/camp/dappled_forest"), class_5468.method_46844("abandoned_camp/tent/dappled_forest"), "dappled_forest");
    public static final AbandonedCampStructure FLOWER_FOREST = new AbandonedCampStructure(class_5468.method_46844("abandoned_camp/camp/flower_forest"), class_5468.method_46844("abandoned_camp/tent/flower_forest"), "flower_forest");
    public static final AbandonedCampStructure FOREST = new AbandonedCampStructure(class_5468.method_46844("abandoned_camp/camp/forest"), class_5468.method_46844("abandoned_camp/tent/forest"), "forest");
    public static final AbandonedCampStructure MEADOW = new AbandonedCampStructure(class_5468.method_46844("abandoned_camp/camp/meadow"), class_5468.method_46844("abandoned_camp/tent/meadow"), "meadow");
    public static final AbandonedCampStructure OLD_GROWTH_BIRCH_FOREST = new AbandonedCampStructure(class_5468.method_46844("abandoned_camp/camp/old_growth_birch_forest"), class_5468.method_46844("abandoned_camp/tent/old_growth_birch_forest"), "old_growth_birch_forest");
    public static final AbandonedCampStructure OLD_GROWTH_PINE_TAIGA = new AbandonedCampStructure(class_5468.method_46844("abandoned_camp/camp/old_growth_pine_taiga"), class_5468.method_46844("abandoned_camp/tent/old_growth_pine_taiga"), "old_growth_pine_taiga");
    public static final AbandonedCampStructure OLD_GROWTH_SPRUCE_TAIGA = new AbandonedCampStructure(class_5468.method_46844("abandoned_camp/camp/old_growth_spruce_taiga"), class_5468.method_46844("abandoned_camp/tent/old_growth_spruce_taiga"), "old_growth_spruce_taiga");
    public static final AbandonedCampStructure PALE_GARDEN = new AbandonedCampStructure(class_5468.method_46844("abandoned_camp/camp/pale_garden"), class_5468.method_46844("abandoned_camp/tent/pale_garden"), "pale_garden");
    public static final AbandonedCampStructure SAVANNA = new AbandonedCampStructure(class_5468.method_46844("abandoned_camp/camp/savanna"), class_5468.method_46844("abandoned_camp/tent/savanna"), "savanna");
    public static final AbandonedCampStructure SNOWY_TAIGA = new AbandonedCampStructure(class_5468.method_46844("abandoned_camp/camp/snowy_taiga"), class_5468.method_46844("abandoned_camp/tent/snowy_taiga"), "snowy_taiga");
    public static final AbandonedCampStructure SPARSE_JUNGLE = new AbandonedCampStructure(class_5468.method_46844("abandoned_camp/camp/sparse_jungle"), class_5468.method_46844("abandoned_camp/tent/sparse_jungle"), "sparse_jungle");
    public static final AbandonedCampStructure SWAMP = new AbandonedCampStructure(class_5468.method_46844("abandoned_camp/camp/swamp"), class_5468.method_46844("abandoned_camp/tent/swamp"), "swamp");
    public static final AbandonedCampStructure TAIGA = new AbandonedCampStructure(class_5468.method_46844("abandoned_camp/camp/taiga"), class_5468.method_46844("abandoned_camp/tent/taiga"), "taiga");
    public static final AbandonedCampStructure WINDSWEPT_FOREST = new AbandonedCampStructure(class_5468.method_46844("abandoned_camp/camp/windswept_forest"), class_5468.method_46844("abandoned_camp/tent/windswept_forest"), "windswept_forest");
    public static final AbandonedCampStructure WOODED_BADLANDS = new AbandonedCampStructure(class_5468.method_46844("abandoned_camp/camp/wooded_badlands"), class_5468.method_46844("abandoned_camp/tent/wooded_badlands"), "wooded_badlands");
    private static final List<AbandonedCampStructure> BIOME_VARIANTS = List.of(
        SAVANNA,
        FLOWER_FOREST,
        BIRCH_FOREST,
        FOREST,
        SNOWY_TAIGA,
        BAMBOO_JUNGLE,
        SPARSE_JUNGLE,
        CHERRY_GROVE,
        MEADOW,
        OLD_GROWTH_BIRCH_FOREST,
        OLD_GROWTH_SPRUCE_TAIGA,
        OLD_GROWTH_PINE_TAIGA,
        SWAMP,
        TAIGA,
        WINDSWEPT_FOREST,
        DAPPLED_FOREST,
        WOODED_BADLANDS,
        PALE_GARDEN
    );
    private static final List<String> DEFAULT_CAMP_TYPES = List.of("chest", "barrel", "special");
    
    public static void bootstrap(class_7891<class_3785> context) {
        class_7871<class_3785> pools = context.method_46799(class_7924.field_41249);
        class_6880<class_3785> empty = pools.method_46747(class_5468.field_26254);
        bootstrapTrees(context, empty);
        bootstrapCampsitePools(context, empty);
    }
    
    private static void bootstrapTrees(class_7891<class_3785> context, class_6880<class_3785> empty) {
        registerTrees(context, empty, ImmutableList.of(
            Pair.of("acacia", class_6818.field_36093),
            Pair.of("birch", class_6818.field_36092),
            Pair.of("fancy_oak", class_6818.field_36101),
            Pair.of("oak", class_6818.field_36090),
            Pair.of("spruce", class_6818.field_36094),
            Pair.of("thick_spruce", class_6818.field_36103),
            Pair.of("yellow_poplar", WildernessBoundPlacements.YELLOW_POPLAR),
            Pair.of("orange_poplar", WildernessBoundPlacements.ORANGE_POPLAR),
            Pair.of("red_poplar", WildernessBoundPlacements.RED_POPLAR),
            Pair.of("super_birch_bees", class_6818.field_36106),
            Pair.of("spruce_on_snow", class_6818.field_36098),
            Pair.of("fancy_oak_bees", class_6818.field_36113),
            Pair.of("birch_bees", class_6818.field_36111),
            Pair.of("pale_oak", TheGardenAwakensPlacements.PALE_OAK_CHECKED),
            Pair.of("bamboo", WildernessBoundPlacements.BAMBOO_IN_STRUCTURE),
            Pair.of("jungle", class_6818.field_36100),
            Pair.of("pine", class_6818.field_36099),
            Pair.of("mega_pine", class_6818.field_36104),
            Pair.of("mega_jungle", class_6818.field_36102),
            Pair.of("cherry", class_6818.field_42963),
            Pair.of("cherry_bees", class_6818.field_42962)
        ));
    }
    
    private static void registerTrees(class_7891<class_3785> context, class_6880<class_3785> empty, Collection<Pair<String, class_5321<class_6796>>> list) {
        class_7871<class_6796> placedFeatures = context.method_46799(class_7924.field_41245);
        
        for (Pair<String, class_5321<class_6796>> pair : list) {
            class_5468.method_30600(
                context,
                "abandoned_camp/trees/" + pair.getFirst(),
                new class_3785(
                    empty, ImmutableList.of(Pair.of(class_3784.method_30421(placedFeatures.method_46747(pair.getSecond())), 1)), class_3785.class_3786.field_16687
                )
            );
        }
    }
    
    private static void bootstrapCampsitePools(class_7891<class_3785> context, class_6880<class_3785> empty) {
        for (AbandonedCampStructure biomeVariant : BIOME_VARIANTS) {
            registerTentPool(context, empty, biomeVariant);
            registerCampsitePool(context, empty, biomeVariant);
        }
    }
    
    private static void registerTentPool(class_7891<class_3785> context, class_6880<class_3785> empty, AbandonedCampStructure biomeVariant) {
        List<Pair<Function<class_3785.class_3786, ? extends class_3784>, Integer>> tentStructures = new ArrayList<>();
        
        for (int numOfTentVariants = 1; numOfTentVariants <= 10; numOfTentVariants++) {
            tentStructures.add(
                Pair.of(class_3784.method_30425(getBiomeSpecificStructureName(biomeVariant, "abandoned_camp/tent/%s/tent_%s_%d", numOfTentVariants)), 1)
            );
        }
        
        class_5468.method_30600(
            context,
            biomeVariant.tentStructureDirectory.method_29177().method_12832(),
            new class_3785(empty, tentStructures, class_3785.class_3786.field_16687)
        );
    }
    
    private static void registerCampsitePool(class_7891<class_3785> context, class_6880<class_3785> empty, AbandonedCampStructure biomeVariant) {
        List<Pair<Function<class_3785.class_3786, ? extends class_3784>, Integer>> campsiteStructures = new ArrayList<>();
        
        for (String defaultCampSiteTypes : DEFAULT_CAMP_TYPES) {
            for (int numOfDefaultCampVariants = 1; numOfDefaultCampVariants <= 15; numOfDefaultCampVariants++) {
                campsiteStructures.add(Pair.of(class_3784.method_30425(getDefaultCampsiteStructureName(defaultCampSiteTypes, numOfDefaultCampVariants)), 1));
            }
        }
        
        for (int numOfBiomeCampVariants = 1; numOfBiomeCampVariants <= 4; numOfBiomeCampVariants++) {
            campsiteStructures.add(
                Pair.of(class_3784.method_30425(getBiomeSpecificStructureName(biomeVariant, "abandoned_camp/camp/%s/campsite_%s_%d", numOfBiomeCampVariants)), 1)
            );
        }
        
        class_5468.method_30600(context, biomeVariant.campStructureDirectory.method_29177().method_12832(), new class_3785(empty, campsiteStructures, class_3785.class_3786.field_16687));
    }
    
    private static String getBiomeSpecificStructureName(AbandonedCampStructure biomeVariant, String identifierTemplate, int numOfTentVariants) {
        return String.format(Locale.ROOT, identifierTemplate, biomeVariant.name, biomeVariant.name, numOfTentVariants);
    }
    
    private static String getDefaultCampsiteStructureName(String defaultCampSiteTypes, int numOfDefaultCampVariants) {
        return String.format(Locale.ROOT, "abandoned_camp/camp/default/campsite_default_%s_%d", defaultCampSiteTypes, numOfDefaultCampVariants);
    }
    
    public record AbandonedCampStructure(class_5321<class_3785> campStructureDirectory, class_5321<class_3785> tentStructureDirectory, String name) {}
}