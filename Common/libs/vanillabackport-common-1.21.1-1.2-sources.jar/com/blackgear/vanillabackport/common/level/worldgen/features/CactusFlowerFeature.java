package com.blackgear.vanillabackport.common.level.worldgen.features;

import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.mojang.serialization.Codec;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2902;
import net.minecraft.class_3031;
import net.minecraft.class_3111;
import net.minecraft.class_5281;
import net.minecraft.class_5819;
import net.minecraft.class_5821;

public class CactusFlowerFeature extends class_3031<class_3111> {
    public CactusFlowerFeature(Codec<class_3111> codec) {
        super(codec);
    }
    
    @Override
    public boolean method_13151(class_5821<class_3111> context) {
        class_5281 level = context.method_33652();
        class_2338 origin = context.method_33655();
        class_5819 random = context.method_33654();
        
        class_2680 flower = ModBlocks.CACTUS_FLOWER.get().method_9564();
        class_2338.class_2339 pos = new class_2338.class_2339();
        
        double spawnChance = VanillaBackport.COMMON_CONFIG.cactusFlowerSpawnChance.get();
        boolean placedAny = false;
        
        for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
                if (random.method_43057() >= spawnChance) continue;
                
                int worldX = origin.method_10263() + x;
                int worldZ = origin.method_10260() + z;
                
                int surfaceY = level.method_8624(class_2902.class_2903.field_13197, worldX, worldZ) - 1;
                pos.method_10103(worldX, surfaceY, worldZ);
                
                if (!level.method_8320(pos).method_27852(class_2246.field_10029)) continue;
                
                pos.method_10098(class_2350.field_11036);
                
                if (level.method_8320(pos).method_26215() && flower.method_26184(level, pos)) {
                    level.method_8652(pos, flower, class_2248.field_31028);
                    placedAny = true;
                }
            }
        }
        
        return placedAny;
    }
}