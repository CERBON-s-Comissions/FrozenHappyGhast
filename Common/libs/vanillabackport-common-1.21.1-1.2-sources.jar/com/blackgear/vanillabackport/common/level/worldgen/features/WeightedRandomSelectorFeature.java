package com.blackgear.vanillabackport.common.level.worldgen.features;

import com.mojang.serialization.Codec;
import java.util.Optional;
import net.minecraft.class_2338;
import net.minecraft.class_2794;
import net.minecraft.class_3031;
import net.minecraft.class_5281;
import net.minecraft.class_5819;
import net.minecraft.class_5821;
import net.minecraft.class_6796;
import net.minecraft.class_6880;

public class WeightedRandomSelectorFeature extends class_3031<WeightedRandomFeatureConfiguration> {
    public WeightedRandomSelectorFeature(Codec<WeightedRandomFeatureConfiguration> codec) {
        super(codec);
    }

    @Override
    public boolean method_13151(class_5821<WeightedRandomFeatureConfiguration> context) {
        WeightedRandomFeatureConfiguration config = context.method_33656();
        class_5819 random = context.method_33654();
        class_5281 level = context.method_33652();
        class_2794 generator = context.method_33653();
        class_2338 origin = context.method_33655();
        Optional<class_6880<class_6796>> feature = config.features().method_34973(random);
        return feature.map(holder -> holder.comp_349().method_39644(level, generator, random, origin)).orElse(false);
    }
}
