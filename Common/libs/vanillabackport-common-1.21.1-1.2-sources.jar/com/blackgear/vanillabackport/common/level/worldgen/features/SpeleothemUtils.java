package com.blackgear.vanillabackport.common.level.worldgen.features;

import java.util.function.Consumer;
import net.minecraft.class_1936;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_5689;
import net.minecraft.class_5691;
import net.minecraft.class_5726;
import net.minecraft.class_6862;

public class SpeleothemUtils {
    protected static boolean isEmptyOrWater(class_1936 level, class_2338 pos) {
        return level.method_16358(pos, class_5726::method_33014);
    }

    protected static void buildBaseToTipColumn(
        class_2350 direction,
        int height,
        boolean mergeTip,
        Consumer<class_2680> blockSetter,
        class_2248 pointedBlock
    ) {
        if (height >= 3) {
            blockSetter.accept(createPointedBlock(direction, class_5691.field_28068, pointedBlock));

            for(int i = 0; i < height - 3; ++i) {
                blockSetter.accept(createPointedBlock(direction, class_5691.field_28067, pointedBlock));
            }
        }

        if (height >= 2) {
            blockSetter.accept(createPointedBlock(direction, class_5691.field_28066, pointedBlock));
        }

        if (height >= 1) {
            blockSetter.accept(createPointedBlock(direction, mergeTip ? class_5691.field_28064 : class_5691.field_28065, pointedBlock));
        }
    }

    protected static void growSpeleothem(
        class_1936 level,
        class_2338 startPos,
        class_2350 direction,
        int height,
        boolean mergeTip,
        class_2248 baseBlock,
        class_2248 pointedBlock,
        class_6862<class_2248> replaceableBlocks
    ) {
        if (isBase(level.method_8320(startPos.method_10093(direction.method_10153())), baseBlock, replaceableBlocks)) {
            class_2338.class_2339 pos = startPos.method_25503();
            buildBaseToTipColumn(direction, height, mergeTip, state -> {
                if (state.method_27852(pointedBlock)) {
                    state = state.method_11657(class_5689.field_28052, level.method_22351(pos));
                }

                level.method_8652(pos, state, 2);
                pos.method_10098(direction);
            }, pointedBlock);
        }
    }

    protected static boolean placeBaseBlockIfPossible(
        class_1936 level,
        class_2338 pos,
        class_2248 baseBlock,
        class_6862<class_2248> replaceableBlocks
    ) {
        class_2680 state = level.method_8320(pos);
        if (state.method_26164(replaceableBlocks)) {
            level.method_8652(pos, baseBlock.method_9564(), 2);
            return true;
        } else {
            return false;
        }
    }

    private static class_2680 createPointedBlock(class_2350 direction, class_5691 thickness, class_2248 pointedBlock) {
        return pointedBlock.method_9564()
            .method_11657(class_5689.field_28050, direction)
            .method_11657(class_5689.field_28051, thickness);
    }

    public static boolean isBase(class_2680 state, class_2248 baseBlock, class_6862<class_2248> replaceableBlocks) {
        return state.method_27852(baseBlock) || state.method_26164(replaceableBlocks);
    }

    public static boolean isEmptyOrWater(class_2680 state) {
        return state.method_26215() || state.method_27852(class_2246.field_10382);
    }

    public static boolean isNeitherEmptyNorWater(class_2680 state) {
        return !state.method_26215() && !state.method_27852(class_2246.field_10382);
    }
}
