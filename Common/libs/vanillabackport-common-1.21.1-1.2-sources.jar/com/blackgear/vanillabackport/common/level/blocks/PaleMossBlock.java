package com.blackgear.vanillabackport.common.level.blocks;

import com.blackgear.vanillabackport.common.worldgen.features.TheGardenAwakensFeatures;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2256;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import net.minecraft.class_7924;

public class PaleMossBlock extends class_2248 implements class_2256 {
    public PaleMossBlock(class_2251 properties) {
        super(properties);
    }

    @Override
    protected MapCodec<? extends class_2248> method_53969() {
        return method_54094(PaleMossBlock::new);
    }

    @Override
    public boolean method_9651(class_4538 level, class_2338 pos, class_2680 state) {
        return level.method_8320(pos.method_10084()).method_26215();
    }

    @Override
    public boolean method_9650(class_1937 level, class_5819 random, class_2338 pos, class_2680 state) {
        return true;
    }

    @Override
    public void method_9652(class_3218 level, class_5819 random, class_2338 pos, class_2680 state) {
        level.method_30349()
            .method_33310(class_7924.field_41239)
            .flatMap(registry -> registry.method_40264(TheGardenAwakensFeatures.PALE_MOSS_PATCH_BONEMEAL))
            .ifPresent(reference -> reference.comp_349().method_12862(level, level.method_14178().method_12129(), random, pos.method_10084()));
    }
}