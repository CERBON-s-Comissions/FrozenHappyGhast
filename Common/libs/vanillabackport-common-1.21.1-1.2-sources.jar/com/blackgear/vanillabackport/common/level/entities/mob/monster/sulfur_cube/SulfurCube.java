package com.blackgear.vanillabackport.common.level.entities.mob.monster.sulfur_cube;

import com.blackgear.vanillabackport.client.registries.ModParticles;
import com.blackgear.vanillabackport.client.registries.ModSoundEvents;
import com.blackgear.vanillabackport.common.api.extensions.entity.movement.MotionAwareEntity;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.happy_ghast.TemptGoal;
import com.blackgear.vanillabackport.common.level.entities.mob.monster.sulfur_cube.SulfurCubeArchetype.AttributeEntry;
import com.blackgear.vanillabackport.common.level.entities.mob.monster.sulfur_cube.SulfurCubeArchetype.ContactDamage;
import com.blackgear.vanillabackport.common.level.entities.mob.monster.sulfur_cube.SulfurCubeArchetype.ExplosionData;
import com.blackgear.vanillabackport.common.level.entities.mob.monster.sulfur_cube.SulfurCubeArchetype.KnockbackModifiers;
import com.blackgear.vanillabackport.common.registries.entities.ModEntityTypes;
import com.blackgear.vanillabackport.common.registries.items.ModItems;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.blackgear.vanillabackport.core.data.tags.ModDamageTypeTags;
import com.blackgear.vanillabackport.core.data.tags.ModItemTags;
import com.blackgear.vanillabackport.core.mixin.common.access.LivingEntityAccessor;
import com.blackgear.vanillabackport.core.util.Utilities.*;
import com.blackgear.vanillabackport.core.util.WorldUtilities.*;
import net.minecraft.class_1266;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1324;
import net.minecraft.class_1333;
import net.minecraft.class_1352;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1665;
import net.minecraft.class_1671;
import net.minecraft.class_1676;
import net.minecraft.class_1686;
import net.minecraft.class_174;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1922;
import net.minecraft.class_1927;
import net.minecraft.class_1928;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2394;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_3486;
import net.minecraft.class_3489;
import net.minecraft.class_3532;
import net.minecraft.class_3610;
import net.minecraft.class_3730;
import net.minecraft.class_4135;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.class_5147;
import net.minecraft.class_5328;
import net.minecraft.class_5362;
import net.minecraft.class_5425;
import net.minecraft.class_5712;
import net.minecraft.class_5761;
import net.minecraft.class_5819;
import net.minecraft.class_7924;
import net.minecraft.class_8103;
import net.minecraft.class_9279;
import net.minecraft.class_9334;
import net.minecraft.class_9817;
import net.minecraft.world.entity.*;
import net.minecraft.world.level.*;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static com.blackgear.vanillabackport.common.level.entities.mob.monster.sulfur_cube.SulfurCubeArchetype.*;

public class SulfurCube extends AbstractCubeMob implements class_5761, class_5147 {
    private static final class_2940<Boolean> FROM_BUCKET = class_2945.method_12791(SulfurCube.class, class_2943.field_13323);
    private static final class_2940<Integer> MAX_FUSE = class_2945.method_12791(SulfurCube.class, class_2943.field_13327);
    private static final Predicate<class_1542> ALLOWED_ITEMS = item -> !item.method_6977() && item.method_5805() && isSwallowableItem(item.method_6983());
    private int pickupTimer = 0;
    private int pushSoundCooldown = 0;
    private boolean floatsInLiquids = false;
    private Optional<ExplosionData> explosionData = Optional.empty();
    private KnockbackModifiers knockbackModifier = DEFAULT_KNOCKBACK_MODIFIERS;
    private SulfurCubeArchetype.SoundSettings soundSettings = SulfurCubeArchetype.DEFAULT_SOUND_SETTINGS;
    private int fuse = -1;
    private final List<ContactDamage> contactDamages = new ArrayList<>();

    @Nullable private class_1282 pendingKnockbackSource = null;
    private float pendingKnockbackDamage = 0f;

    private static final class_5362 USED_PORTAL_DAMAGE_CALCULATOR = new class_5362() {
        @Override
        public boolean method_29554(class_1927 explosion, class_1922 reader, class_2338 pos, class_2680 state, float power) {
            return !state.method_27852(class_2246.field_10316) && super.method_29554(explosion, reader, pos, state, power);
        }

        @Override
        public Optional<Float> method_29555(class_1927 explosion, class_1922 reader, class_2338 pos, class_2680 state, class_3610 fluid) {
            return state.method_27852(class_2246.field_10316) ? Optional.empty() : super.method_29555(explosion, reader, pos, state, fluid);
        }
    };

    public SulfurCube(class_1299<? extends AbstractCubeMob> entityType, class_1937 level) {
        super(entityType, level);
        this.field_6206 = new SulfurCubeLookControl();
        this.field_6207 = new SulfurCubeMoveControl<>(this);
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        super.method_5693(builder);
        builder.method_56912(FROM_BUCKET, false);
        builder.method_56912(MAX_FUSE, -1);
    }

    @Override
    protected void addBehaviourGoals() {
        this.field_6201.method_6277(
            2,
            new SulfurCubeTemptGoal(
                this,
                1.0,
                stack -> this.method_6109() ? stack.method_31573(ModItemTags.SULFUR_CUBE_FOOD) : isSwallowableItem(stack),
                false,
                1.0
            ).setTemptRange(8)
        );
        this.field_6201.method_6277(3, new SulfurCubeSearchForItemsGoal(this));
    }

    @Override
    public boolean method_6453() {
        return this.field_6011.method_12789(FROM_BUCKET);
    }

    @Override
    public void method_6454(boolean fromBucket) {
        this.field_6011.method_12778(FROM_BUCKET, fromBucket);
    }

    public int getFuse() {
        return this.fuse;
    }

    public void setFuse(int fuse) {
        this.fuse = fuse;
    }

    public boolean isPrimed() {
        return this.getFuse() >= 0;
    }

    @Override
    public void method_5674(class_2940<?> key) {
        if (MAX_FUSE.equals(key)) {
            this.setFuse(this.field_6011.method_12789(MAX_FUSE));
        }

        super.method_5674(key);
    }

    @Override
    public class_3414 method_35171() {
        return ModSoundEvents.BUCKET_FILL_SULFUR_CUBE.get();
    }

    @Override
    public void method_6455(class_1799 stack) {
        class_5761.method_35167(this, stack);
        class_9279.method_57452(class_9334.field_49610, stack, tag -> {
            tag.method_10569("age", this.method_5618());
            class_1799 absorbedBlock = this.getContainedBlock();
            if (!absorbedBlock.method_7960()) {
                tag.method_10566("absorbed_block", absorbedBlock.method_57358(this.method_37908().method_30349()));
            }

            if (this.method_5947()) {
                tag.method_10556("PersistenceRequired", this.method_5947());
            }
        });
    }

    @Override
    public boolean method_6094() {
        return this.hasBodyItem() || super.method_6094();
    }

    @Override
    public void postTravelInFluid() {
        if (this.hasBodyItem() && this.floatsInLiquids) {
            float vibeAmount = 0.2F * class_3532.method_15374(this.field_6012 * 0.4F);
            double immersion = this.method_5861(this.method_5799() ? class_3486.field_15517 : class_3486.field_15518) - this.method_29241() + vibeAmount;
            if (immersion > 0.0) {
                this.method_18799(this.method_18798().method_1031(0.0, Math.min(1.0, immersion) * 0.04F, 0.0));
            }
        }
    }

    @Override
    public double method_29241() {
        return this.method_17682() * 0.2;
    }

    @Override
    public void method_35170(class_2487 tag) {
        class_5761.method_35168(this, tag);
        this.method_5614(tag.method_10550("age"));
        if (tag.method_10573("absorbed_block", class_2520.field_33260)) {
            class_1799 absorbedBlock = class_1799.method_57360(this.method_37908().method_30349(), tag.method_10562("absorbed_block")).orElse(class_1799.field_8037);
            if (!absorbedBlock.method_7960()) {
                this.equipItem(absorbedBlock);
            }
        }

        if (tag.method_10545("PersistenceRequired")) {
            this.method_5971();
        }
    }

    @Override
    public class_1799 method_6452() {
        return new class_1799(ModItems.SULFUR_CUBE_BUCKET.get());
    }

    @Override
    protected void addTargetingGoals() { /* NO-OP */ }

    @Override
    public float method_5718() {
        return 1.0F;
    }

    @Override
    protected boolean isDealsDamage() {
        return false;
    }

    @SuppressWarnings("unused")
    public static boolean checkSulfurCubeSpawnRules(class_1299<SulfurCube> type, class_1936 level, class_3730 spawnType, class_2338 pos, class_5819 random) {
        return true;
    }

    @Override
    public boolean method_17326() {
        return super.method_17326() || this.hasBodyItem() || this.method_6453();
    }

    @Override
    public boolean method_5931() {
        return this.hasBodyItem();
    }
    
    @Override
    public boolean method_5643(class_1282 source, float damage) {
        this.pendingKnockbackSource = source;
        this.pendingKnockbackDamage = damage;
        
        if (!this.method_37908().method_8608() && this.hasBodyItem()) {
            if (this.canExplode() && !this.isPrimed()) {
                class_1297 attacker = source.method_5526();
                if (source.method_48789(class_8103.field_42246) || (attacker instanceof class_1665 arrow && arrow.method_5809())) {
                    this.primeTime(false);
                } else if (source.method_48789(class_8103.field_42249)) {
                    this.primeTime(true);
                }
            }
            
            if (source.method_48789(ModDamageTypeTags.SULFUR_CUBE_WITH_BLOCK_IMMUNE_TO)) {
                if (!source.method_48789(ModDamageTypeTags.NO_KNOCKBACK)) {
                    this.dealDefaultKnockback(source, damage, true);
                }
                return true;
            }
        }
        
        return super.method_5643(source, damage);
    }
    
    public void dealDefaultKnockback(class_1282 source, float damage, boolean blocked) {
        double xd = 0.0;
        double zd = 0.0;
        
        if (source.method_5526() instanceof class_1676 projectile) {
            if (projectile instanceof class_1671 || projectile instanceof class_1686) {
                xd = projectile.method_23317() - this.method_23317();
                zd = projectile.method_23321() - this.method_23321();
            } else {
                class_243 delta = projectile.method_18798();
                xd = -delta.field_1352;
                zd = -delta.field_1350;
            }
        } else if (source.method_5510() != null) {
            class_243 pos = source.method_5510();
            xd = pos.method_10216() - this.method_23317();
            zd = pos.method_10215() - this.method_23321();
        }
        
        this.method_6005(0.4F, xd, zd);
        if (!blocked) {
            this.method_48761(xd, zd);
        }
    }

    public boolean hasBodyItem() {
        return !this.method_6118(class_1304.field_6174).method_7960();
    }

    public boolean canExplode() {
        return this.explosionData.isPresent() && this.method_5805() && !this.isPrimed();
    }

    public class_1799 getContainedBlock() {
        return this.method_6118(class_1304.field_6174);
    }

    public List<SulfurCubeArchetype> matchingArchetypes(class_1799 stack) {
        return SulfurCubeArchetypes.REGISTRIES.values()
            .stream()
            .filter(archetype -> stack.method_31573(archetype.items()))
            .collect(Collectors.toCollection(ArrayList::new));
    }

    @Override
    public void method_5773() {
        this.tickFuse();
        this.primeWhenOnPoweredPosition();
        super.method_5773();
    }

    private void tickFuse() {
        if (this.fuse > 0) {
            this.fuse--;
        }

        if (this.explosionData.isPresent()) {
            if (this.fuse == 0) {
                this.method_5932(true, true);
                this.field_6272 = true;
                if (this.method_37908() instanceof class_3218 level) {
                    if (VanillaBackport.COMMON_CONFIG.doSulfurCubesExplode.get()) {
                        class_1937.class_7867 interaction = level.method_8450().method_8355(class_1928.field_19388)
                            ? class_1937.class_7867.field_40891 : class_1937.class_7867.field_40888;
                        level.method_55117(
                            this,
                            level.method_48963().method_48819(this, this),
                            this.method_51848() > 0 ? USED_PORTAL_DAMAGE_CALCULATOR : null,
                            this.method_23317(),
                            this.method_23323(0.0625),
                            this.method_23321(),
                            this.explosionData.get().power(),
                            this.explosionData.get().causesFire(),
                            interaction
                        );
                    }

                    this.method_60699(class_5529.field_26998);
                }

                this.method_31472();
            }
        }
    }

    private void primeWhenOnPoweredPosition() {
        if (this.method_37908() instanceof class_3218 level && this.canExplode()) {
            class_2338 here = class_2338.method_49638(this.method_19538());
            if (BlockUtils.getBestOwnOrNeighbourSignal(level, here) != 0) {
                this.primeTime(false);
            }
        }
    }

    private void primeTime(boolean imminent) {
        if (this.explosionData.isPresent()
            && this.method_5805()
            && this.method_37908() instanceof class_3218
            && VanillaBackport.COMMON_CONFIG.doSulfurCubesExplode.get()
            && !this.isPrimed()) {
            int fuse = this.explosionData.get().fuse();
            int fuseTime = imminent ? this.method_59922().method_43048(fuse / 4) + fuse / 8 : fuse;
            this.method_5684(true);
            this.setFuse(fuseTime);
            this.field_6011.method_12778(MAX_FUSE, fuseTime);
            this.method_43077(class_3417.field_15079);
            this.method_32876(class_5712.field_28727);
        }
    }

    @Override
    protected void method_5958() {
        super.method_5958();
        if (this.pickupTimer > 0) {
            this.pickupTimer--;
        }

        if (this.pushSoundCooldown > 0) {
            this.pushSoundCooldown--;
        }
    }

    @Override @Nullable
    public Map<class_1304, class_1799> method_30129() {
        class_1799 previous = ((LivingEntityAccessor) this).getLastArmorItemStacks().get(class_1304.field_6174.method_5927());
        class_1799 current = this.method_6118(class_1304.field_6174);
        if (this.method_45324(previous, current)) {
            if (!current.method_7960()) {
                this.field_6201.method_35115().forEach(class_4135::method_6270);
                this.method_47825(goal -> true);
                this.method_6125(0.0F);
            } else {
                this.method_5959();
            }

            for (SulfurCubeArchetype archetype : this.matchingArchetypes(previous)) {
                for (AttributeEntry entry : archetype.attributeModifiers()) {
                    class_1324 attribute = this.method_5996(entry.attribute());
                    if (attribute != null) {
                        attribute.method_6202(entry.modifier());
                    }
                }
            }

            this.floatsInLiquids = false;
            this.explosionData = Optional.empty();
            this.contactDamages.clear();
            this.knockbackModifier = DEFAULT_KNOCKBACK_MODIFIERS;
            this.soundSettings = SulfurCubeArchetype.DEFAULT_SOUND_SETTINGS;

            for (SulfurCubeArchetype archetype : this.matchingArchetypes(current)) {
                if (archetype.buoyant()) {
                    this.floatsInLiquids = true;
                }

                if (archetype.explosion().isPresent()) {
                    this.explosionData = archetype.explosion();
                }

                if (VanillaBackport.COMMON_CONFIG.doSulfurCubesDealDamage.get() && archetype.contactDamage().isPresent()) {
                    this.contactDamages.add(archetype.contactDamage().get());
                }

                this.knockbackModifier = archetype.knockbackModifiers();
                this.soundSettings = archetype.soundSettings();

                for (AttributeEntry entry : archetype.attributeModifiers()) {
                    class_1324 attribute = this.method_5996(entry.attribute());
                    if (attribute != null) {
                        attribute.method_55696(entry.modifier());
                    }
                }
            }
        }

        return super.method_30129();
    }

    @Override
    public float method_49476() {
        return this.hasBodyItem() ? 0.0F : super.method_49476();
    }

    @Override
    public boolean omnidirectionalAirMover() {
        return this.hasBodyItem();
    }

    @Override
    public boolean method_32316() {
        return !this.hasBodyItem() && super.method_32316();
    }

    public float getFuseRemainingTicks(float partialTicks) {
        return this.isPrimed() ? this.getFuse() - partialTicks + 1.0F : 0.0F;
    }

    @Override
    protected class_1269 method_5992(class_1657 player, class_1268 hand) {
        class_1799 heldItem = player.method_5998(hand);
        if (this.method_6109()) {
            if (this.isFood(heldItem)) {
                if (!player.method_31549().field_7477) heldItem.method_7934(1);
                this.method_5620(method_41321(-this.field_5950), true);
                this.method_43077(ModSoundEvents.SULFUR_CUBE_SMALL_EAT.get());
                return class_1269.field_5812;
            } else {
                return super.method_5992(player, hand);
            }
        } else if (this.isPrimed()) {
            return class_1269.field_5811;
        } else if (this.canExplode() && heldItem.method_31573(class_3489.field_41662)) {
            if (!VanillaBackport.COMMON_CONFIG.doSulfurCubesExplode.get()) {
                player.method_7353(class_2561.method_43471("entity.minecraft.sulfur_cube.explosion_disabled"), true);
                return class_1269.field_5811;
            } else {
                this.primeTime(false);
                if (!heldItem.method_7963()) {
                    heldItem.method_7934(1);
                } else {
                    heldItem.method_7970(1, player, method_56079(hand));
                }

                player.method_7259(class_3468.field_15372.method_14956(heldItem.method_7909()));
                return class_1269.field_5812;
            }
        } else {
            if (heldItem.method_31574(class_1802.field_8868) && this.method_27072()) {
                if (this.method_37908() instanceof class_3218) {
                    class_1799 itemStackToShear = this.method_6118(class_1304.field_6174);
                    this.method_6636(class_3419.field_15248);
                    this.method_32875(class_5712.field_28730, player);
                    heldItem.method_7970(1, player, method_56079(hand));
//                    CriteriaTriggers.PLAYER_SHEARED_EQUIPMENT.trigger((ServerPlayer) player, itemStackToShear, this); TODO
                }

                return class_1269.field_5812;
            } else if (isSwallowableItem(heldItem)) {
                boolean itWorked = this.equipItem(heldItem);
                if (itWorked) {
                    heldItem.method_57008(1, player);
                    this.method_32876(class_5712.field_28725);
                }

                return itWorked ? class_1269.field_5812 : class_1269.field_5811;
            } else {
                return method_35169(player, hand, this).orElse(super.method_5992(player, hand));
            }
        }
    }

    private boolean equipItem(class_1799 heldItem) {
        if (this.method_6109()) {
            return false;
        } else {
            if (this.hasBodyItem()) {
                class_1792 swallowedItem = this.method_6118(class_1304.field_6174).method_7909();
                if (heldItem.method_31574(swallowedItem)) {
                    return false;
                }

                this.method_5699(this.method_6118(class_1304.field_6174), this.method_17682() * 1.5F);
            }

            this.method_24834(class_1304.field_6174, heldItem.method_46651(1));
            this.method_43077(this.getAbsorbSound());
            return true;
        }
    }

    private void applyContactDamage(class_1297 entity) {
        if (this.method_37908() instanceof class_3218 level) {
            for (ContactDamage damage : this.contactDamages) {
                level.method_30349().method_30530(class_7924.field_42534)
                    .method_40264(damage.damageType())
                    .ifPresent(source -> entity.method_5643(new class_1282(source, damage.attributeToSource() ? this : null), damage.amount().method_33920(this.method_59922())));
            }
        }
    }
    
    private static <T extends class_1309 & class_5761> Optional<class_1269> method_35169(class_1657 player, class_1268 hand, T pickupEntity) {
        class_1799 itemStack = player.method_5998(hand);
        if (itemStack.method_7909() == class_1802.field_8550 && pickupEntity.method_5805()) {
            if (pickupEntity instanceof SulfurCube cube) cube.method_5971(); // Prevents bucketed Sulfur Cubes to despawn
            pickupEntity.method_5783(pickupEntity.method_35171(), 1.0F, 1.0F);
            class_1799 bucket = pickupEntity.method_6452();
            pickupEntity.method_6455(bucket);
            class_1799 result = class_5328.method_30270(itemStack, player, bucket, false);
            player.method_6122(hand, result);
            class_1937 level = pickupEntity.method_37908();
            if (!level.field_9236 && player instanceof class_3222 serverPlayer) {
                class_174.field_1208.method_8932(serverPlayer, bucket);
            }

            if (pickupEntity instanceof class_9817 leashable) {
                leashable.method_5932(true, true);
            }

            pickupEntity.method_31472();
            return Optional.of(class_1269.method_29236(level.field_9236));
        } else {
            return Optional.empty();
        }
    }
    
    @Override
    public boolean method_5947() {
        return super.method_5947() || this.method_16914();
    }
    
    @Override
    public class_3419 method_5634() {
        return class_3419.field_15254;
    }

    @Override
    protected class_3414 method_6011(class_1282 damageSource) {
        return this.isTiny() ? ModSoundEvents.SULFUR_CUBE_SMALL_HURT.get() : ModSoundEvents.SULFUR_CUBE_HURT.get();
    }

    @Override
    protected class_3414 method_6002() {
        return this.isTiny() ? ModSoundEvents.SULFUR_CUBE_SMALL_DEATH.get() : ModSoundEvents.SULFUR_CUBE_DEATH.get();
    }

    @Override
    protected class_3414 getSquishSound() {
        if (this.isTiny()) {
            return ModSoundEvents.SULFUR_CUBE_SMALL_SQUISH.get();
        } else {
            return this.hasBodyItem() ? ModSoundEvents.SULFUR_CUBE_BOUNCE.get() : ModSoundEvents.SULFUR_CUBE_SQUISH.get();
        }
    }

    @Override
    protected class_3414 getJumpSound() {
        return this.isTiny() ? ModSoundEvents.SULFUR_CUBE_SMALL_JUMP.get() : ModSoundEvents.SULFUR_CUBE_JUMP.get();
    }

    private class_3414 getAbsorbSound() {
        return ModSoundEvents.SULFUR_CUBE_ABSORB.get();
    }

    private class_3414 getEjectSound() {
        return ModSoundEvents.SULFUR_CUBE_EJECT.get();
    }

    @Override
    protected void method_5712(class_2338 pos, class_2680 state) {
        if (!this.hasBodyItem()) super.method_5712(pos, state);
    }

    @Override
    protected class_2394 getParticleType() {
        return ModParticles.SULFUR_CUBE_GOO.get();
    }

    public static class_5132.class_5133 createSulfurCubeAttributes() {
        return class_1308.method_26828();
    }

    @Override
    public void method_6636(class_3419 source) {
        class_1799 itemStackToShear = this.method_6118(class_1304.field_6174);
        this.method_5673(class_1304.field_6174, class_1799.field_8037);
        this.method_5699(itemStackToShear, this.method_17682() * 1.5F);
        this.method_43077(this.getEjectSound());
        this.pickupTimer = 100;
    }

    @Override
    public boolean method_27072() {
        return this.hasBodyItem();
    }

    @Override
    public boolean method_5936() {
        return !this.hasBodyItem();
    }

    private static boolean isSwallowableItem(class_1799 stack) {
        return stack.method_31573(ModItemTags.SULFUR_CUBE_SWALLOWABLE);
    }

    @Override
    public boolean method_5939(class_1799 stack) {
        class_1799 heldItem = this.method_6118(class_1304.field_6174);
        return heldItem.method_7960() && isSwallowableItem(stack) && !this.method_6109();
    }

    @Override
    protected void method_5949(class_1542 item) {
        class_1799 itemStack = item.method_6983();
        if (this.method_5939(itemStack) && this.pickupTimer <= 0) {
            this.method_29499(item);
            this.method_5673(class_1304.field_6174, itemStack.method_7971(1));
            this.method_43077(this.getAbsorbSound());
            this.method_25939(class_1304.field_6174);
            this.method_6103(item, 1);
        }
    }

    @Override
    protected int method_6110() {
        return this.method_6109() ? 0 : 1 + this.field_5974.method_43048(2);
    }

    @Override
    protected int getSplitCount() {
        return this.isPrimed() ? 0 : 2;
    }

    @Override
    protected void setSpawnSize(class_5425 level, class_1266 difficulty) {
        this.setSize(this.method_6109() ? 1 : 2, true);
    }

    @Override
    public void setSize(int size, boolean updateHealth) {
        super.setSize(size, updateHealth);
        if (updateHealth && size == 1 && !this.method_6109()) {
            this.method_7217(true);
        }
    }

    @Override
    protected void setUpSplitCube(AbstractCubeMob cube, int halfSize, float x, float z) {
        super.setUpSplitCube(cube, halfSize, x, z);
        cube.method_7217(true);
    }

    @Override
    public @Nullable class_1296 method_5613(class_3218 level, class_1296 otherParent) {
        SulfurCube cube = ModEntityTypes.SULFUR_CUBE.get().method_5883(level);
        if (cube != null) cube.setSize(1, true);
        return cube;
    }

    private boolean isFood(class_1799 heldItem) {
        return heldItem.method_31573(ModItemTags.SULFUR_CUBE_FOOD);
    }

    @Override
    protected void method_5619() {
        super.method_5619();
        if (!this.method_6109()) {
            this.setSize(2, true);
        }
    }

    @Override
    public void method_5652(class_2487 compound) {
        super.method_5652(compound);
        compound.method_10569("pickup_timer", this.pickupTimer);
        compound.method_10556("from_bucket", this.method_6453());
        compound.method_10569("fuse", this.getFuse());
    }

    @Override
    public void method_5749(class_2487 compound) {
        this.pickupTimer = compound.method_10550("pickup_timer");
        this.method_6454(compound.method_10577("from_bucket"));
        this.setFuse(compound.method_10545("fuse") ? compound.method_10550("fuse") : -1);
        this.field_6011.method_12778(MAX_FUSE, this.getFuse());
        super.method_5749(compound);
    }

    @Override
    protected void method_6087(class_1297 entity) {
        super.method_6087(entity);
        this.applyContactDamage(entity);
    }

    @Override
    public void method_5694(class_1657 player) {
        super.method_5694(player);
        this.playerPush(player);
    }

    private void playerPush(class_1657 player) {
        if (this.hasBodyItem()) {
            class_1297 pusher = player.method_5765() ? player.method_5668() : player;
            class_243 cubeToPusher = this.method_19538().method_1020(pusher.method_19538());
            double pusherFeetPosition = pusher.method_23318();
            double sulfurCubeBottomPosition = this.method_23318();
            double sulfurCubeTopPosition = sulfurCubeBottomPosition + this.method_17682();
            double pusherTopPosition = pusherFeetPosition + pusher.method_17682();
            if (cubeToPusher.method_37267() < 1.3F && pusherFeetPosition <= sulfurCubeTopPosition && pusherTopPosition > sulfurCubeBottomPosition) {
                double knockback = Math.max(0.0, 1.0 - this.method_45325(class_5134.field_23718));
                class_243 pushDirection = VectorUtils.horizontal(cubeToPusher).method_1029().method_1021(knockback);
                float pushSpeedScale = player.method_5765() ? 0.16F : 0.3F;
                double playerSpeed = ((MotionAwareEntity) player).getKnownSpeed().method_1033() * 2.0 * pushSpeedScale;
                playerSpeed = class_3532.method_15350(playerSpeed, 0.0, 0.5);
                class_243 pushVelocity = new class_243(pushDirection.field_1352, this.method_24828() ? knockback * 0.3F : 0.0, pushDirection.field_1350).method_1021(playerSpeed);
                this.field_6007 = true;
                float pushSoundThreshold = this.soundSettings.pushSoundImpulseThreshold();
                if (pushVelocity.method_1027() > pushSoundThreshold * pushSoundThreshold && this.pushSoundCooldown <= 0) {
                    this.pushSoundCooldown = (int)(this.soundSettings.pushSoundCooldown() * 20.0F);
                    this.method_43077(this.soundSettings.pushSound().comp_349());
                }

                this.method_45319(pushVelocity);
                this.applyContactDamage(player);
            }
        }
    }

    private class_241 applyHorizontalHitAngleScale(float horizontalAngleScale, class_241 originalAngle, class_243 attackerPosition, class_243 attackerAimDirection, class_243 targetCenter) {
        class_243 attackerToTarget = targetCenter.method_1020(attackerPosition).method_1029();
        float angleDiff = (float) Math.atan2(
            attackerAimDirection.field_1352 * attackerToTarget.field_1350 - attackerAimDirection.field_1350 * attackerToTarget.field_1352,
            attackerAimDirection.field_1352 * attackerToTarget.field_1352 + attackerAimDirection.field_1350 * attackerToTarget.field_1350
        );
        return VectorUtils.rotate(originalAngle, angleDiff * horizontalAngleScale);
    }

    private class_241 applyVerticalHitAnglePowerTransfer(
        float verticalHitAngleScale,
        float horizontalPower,
        float verticalPower,
        class_243 attackerPosition,
        class_243 attackerAimDirection,
        class_243 targetCenteredPosition,
        float targetHeight
    ) {
        float targetHalfHeight = 0.5F * targetHeight;
        class_243 targetTopPos = targetCenteredPosition.method_1031(0.0, targetHalfHeight, 0.0);
        class_243 targetBottomPos = targetCenteredPosition.method_1031(0.0, -targetHalfHeight, 0.0);
        class_243 attackerToTargetTop = targetTopPos.method_1020(attackerPosition).method_1029();
        class_243 attackerToTargetBottom = targetBottomPos.method_1020(attackerPosition).method_1029();
        float verticalHitAngleFactor = (float) class_3532.method_32854(attackerAimDirection.field_1351, attackerToTargetTop.field_1351, attackerToTargetBottom.field_1351, -1.0, 1.0);
        float transferredPowerRatio = Math.abs(verticalHitAngleFactor * verticalHitAngleScale);
        if (verticalHitAngleFactor < 0.0F) {
            transferredPowerRatio = -transferredPowerRatio;
        }

        float px = horizontalPower * (1.0F - transferredPowerRatio);
        float py = verticalPower * (1.0F + transferredPowerRatio);
        return new class_241(px, py);
    }

    private class_241 applyVerticalPositionAnglePowerRotation(
        float verticalPositionAngleScale,
        float horizontalPower,
        float verticalPower,
        float originalHorizontalPower,
        float originalVerticalPower,
        class_243 attackerFeetPosition,
        class_243 targetFeetPosition
    ) {
        class_243 attackerFeetToTargetFeet = targetFeetPosition.method_1020(attackerFeetPosition);
        float verticalPositionAngle = (float) Math.atan2(-attackerFeetToTargetFeet.field_1351, attackerFeetToTargetFeet.method_37267());
        class_241 powerBeforeRotation = new class_241(horizontalPower, verticalPower);
        class_241 rotatedPower = VectorUtils.rotate(powerBeforeRotation, -verticalPositionAngle * verticalPositionAngleScale);
        float horizontalRatio = originalHorizontalPower > 0.0F ? class_3532.method_15379(rotatedPower.field_1343) / originalHorizontalPower : 0.0F;
        float verticalRatio = originalVerticalPower > 0.0F ? class_3532.method_15379(rotatedPower.field_1342) / originalVerticalPower : 0.0F;
        float maxRatio = Math.max(horizontalRatio, verticalRatio);
        if (maxRatio > 1.0F) {
            rotatedPower = rotatedPower.method_35582(1.0F / maxRatio);
        }

        return rotatedPower;
    }

    @Override
    public void method_6005(double power, double xd, double zd) {
        class_1297 attacker = this.pendingKnockbackSource != null ? this.pendingKnockbackSource.method_5529() : null;
        float damage = this.pendingKnockbackDamage;

        if (attacker != null && this.hasBodyItem()) {
            float horizontalPower = this.knockbackModifier.horizontalPower();
            float verticalPower = this.knockbackModifier.verticalPower();
            class_241 originalAngle = new class_241((float) xd, (float) zd);
            class_241 newAngle = this.applyHorizontalHitAngleScale(1.6F, originalAngle, attacker.method_33571(), attacker.method_5720().method_1029(), this.method_5829().method_1005());
            class_241 newPower = this.applyVerticalHitAnglePowerTransfer(0.5F, horizontalPower, verticalPower, attacker.method_33571(), attacker.method_5720().method_1029(), this.method_5829().method_1005(), this.method_17682());
            newPower = this.applyVerticalPositionAnglePowerRotation(0.8F, newPower.field_1343, newPower.field_1342, horizontalPower, verticalPower, attacker.method_19538(), this.method_19538());
            horizontalPower = newPower.field_1343;
            verticalPower = newPower.field_1342;
            xd = newAngle.field_1343;
            zd = newAngle.field_1342;
            float powerMultiplier = class_3532.method_15355(damage);
            horizontalPower *= powerMultiplier;
            verticalPower *= powerMultiplier;
            float knockbackResistance = (float) (1.0 - this.method_45325(class_5134.field_23718));
            horizontalPower *= knockbackResistance;
            verticalPower *= knockbackResistance;
            this.field_6007 = true;
            class_243 deltaMovement = this.method_18798();
            horizontalPower *= 0.4F;
            horizontalPower = class_3532.method_15363(horizontalPower, -128.0F, 128.0F);
            verticalPower = class_3532.method_15363(verticalPower, -128.0F, 128.0F);
            class_243 horizontalKnockback = new class_243(xd, 0.0, zd).method_1029().method_1021(horizontalPower);
            this.method_18800(deltaMovement.field_1352 - horizontalKnockback.field_1352, deltaMovement.field_1351 + verticalPower * 1.2, deltaMovement.field_1350 - horizontalKnockback.field_1350);
            this.method_43077(this.soundSettings.hitSound().comp_349());
        } else {
            super.method_6005(power, xd, zd);
        }
    }

    @Override
    protected class_243 method_29919() {
        return new class_243(0.0, this.method_17682() / 2.0F, 0.0);
    }

    @Override @SuppressWarnings("DataFlowIssue")
    protected void setCubeMobHealth(int actualSize) {
        this.method_5996(class_5134.field_23716).method_6192(4 * actualSize);
    }

    private class SulfurCubeLookControl extends class_1333 {
        public SulfurCubeLookControl() {
            super(SulfurCube.this);
        }

        @Override
        public void method_6231() {
            SulfurCube cube = SulfurCube.this;
            if (!cube.hasBodyItem()) {
                super.method_6231();
            } else {
                float closeAngle = MthUtils.wrapDegrees90(cube.method_36454());
                cube.method_36456(cube.method_36454() - closeAngle);
                cube.method_5847(cube.method_36454());
            }
        }
    }

    private static class SulfurCubeMoveControl<T extends SulfurCube> extends CubeMobMoveControl<T> {
        public SulfurCubeMoveControl(T cube) {
            super(cube);
        }

        @Override
        public void method_6240() {
            if (!this.cube.hasBodyItem()) {
                super.method_6240();
            }
        }
    }

    private static class SulfurCubeSearchForItemsGoal extends class_1352 {
        private final SulfurCube cube;
        @Nullable private class_1542 targetItem;

        private SulfurCubeSearchForItemsGoal(SulfurCube cube) {
            this.method_6265(EnumSet.of(class_4134.field_18406));
            this.cube = cube;
        }

        @Override
        public boolean method_6264() {
            if (!this.cube.method_6109() && this.cube.pickupTimer <= 0) {
                this.targetItem = EntityUtils.getNearestEntity(
                    this.cube.method_37908().method_8390(class_1542.class, this.cube.method_5829().method_1014(8.0), SulfurCube.ALLOWED_ITEMS),
                    this.cube.method_23317(),
                    this.cube.method_23318(),
                    this.cube.method_23321()
                );
                return this.targetItem != null;
            } else {
                return false;
            }
        }

        @Override
        public void method_6268() {
            this.cube.method_5951(this.targetItem, 10.0F, 10.0F);
            if (this.cube.method_5962() instanceof CubeMobMoveControl<?> control) {
                control.setDirection(this.cube.method_36454(), true);
            }
        }
    }

    private static class SulfurCubeTemptGoal extends TemptGoal.ForNonPathfinders {
        public SulfurCubeTemptGoal(class_1308 mob, double speedModifier, Predicate<class_1799> items, boolean canScare, double stopDistance) {
            super(mob, speedModifier, items, canScare, stopDistance);
            this.method_6265(EnumSet.of(class_4134.field_18406));
        }

        @Override
        protected void stopNavigation() {
            if (this.mob.method_5962() instanceof CubeMobMoveControl<?> control) {
                control.setWantedMovement(0.0);
            }
        }

        @Override
        protected void navigateTowards(class_1657 player) {
            this.mob.method_5951(player, 10.0F, 10.0F);
            if (this.mob.method_5962() instanceof CubeMobMoveControl<?> control) {
                control.setDirection(this.mob.method_36454(), true);
            }
        }
    }
}