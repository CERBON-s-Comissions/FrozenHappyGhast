package com.blackgear.vanillabackport.common.level.blocks;

import com.blackgear.vanillabackport.client.registries.ModParticles;
import com.blackgear.vanillabackport.client.registries.ModSoundEvents;
import com.blackgear.vanillabackport.common.level.block_entities.PotentSulfurBlockEntity;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlockEntities;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlockStateProperties;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.blackgear.vanillabackport.core.data.tags.ModBlockTags;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_1750;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2754;
import net.minecraft.class_3419;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_4538;
import net.minecraft.class_5558;
import net.minecraft.class_5712;
import net.minecraft.class_5819;
import org.jetbrains.annotations.Nullable;

import static com.blackgear.vanillabackport.common.level.block_entities.PotentSulfurBlockEntity.*;

public class PotentSulfurBlock extends class_2237 {
    public static final MapCodec<PotentSulfurBlock> CODEC = method_54094(PotentSulfurBlock::new);
    public static final class_2754<PotentSulfurState> STATE = ModBlockStateProperties.POTENT_SULFUR_STATE;

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    public PotentSulfurBlock(class_2251 properties) {
        super(properties);
        this.method_9590(this.method_9564().method_11657(STATE, PotentSulfurState.DRY));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(STATE);
    }

    @Override @Nullable
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new PotentSulfurBlockEntity(pos, state);
    }

    @Override
    protected class_2680 method_9559(
        class_2680 state,
        class_2350 direction,
        class_2680 neighborState,
        class_1936 level,
        class_2338 pos,
        class_2338 neighborPos
    ) {
        return validBlockState(state, level, pos);
    }

    @Override
    public @Nullable class_2680 method_9605(class_1750 context) {
        return validBlockState(this.method_9564(), context.method_8045(), context.method_8037());
    }

    private static class_2680 validBlockState(class_2680 state, class_4538 level, class_2338 pos) {
        if (!level.method_8316(pos.method_10084()).method_33659(class_3612.field_15910)) {
            return state.method_11657(STATE, PotentSulfurState.DRY);
        } else {
            class_2680 belowState = level.method_8320(pos.method_10074());
            if (belowState.method_26164(ModBlockTags.CAUSES_CONTINUOUS_GEYSER_ERUPTIONS) && isSourceIfFluid(belowState)) {
                return state.method_11657(STATE, PotentSulfurState.CONTINUOUS);
            } else if (belowState.method_26164(ModBlockTags.CAUSES_PERIODIC_GEYSER_ERUPTIONS) && isSourceIfFluid(belowState)) {
                boolean isGeyser = state.method_11654(STATE) == PotentSulfurState.ERUPTING || state.method_11654(STATE) == PotentSulfurState.DORMANT;
                if (!isGeyser && level.method_8321(pos) instanceof PotentSulfurBlockEntity potentSulfur) {
                    potentSulfur.resetCountdown();
                }

                return state.method_11654(STATE) == PotentSulfurState.ERUPTING ? state : state.method_11657(STATE, PotentSulfurState.DORMANT);
            } else {
                return state.method_11657(STATE, PotentSulfurState.WET);
            }
        }
    }

    private static boolean isSourceIfFluid(class_2680 belowState) {
        class_3610 fluidState = belowState.method_26227();
        return fluidState.method_15769() || fluidState.method_15771();
    }

    @Override
    protected void method_9615(class_2680 state, class_1937 level, class_2338 pos, class_2680 oldState, boolean movedByPiston) {
        super.method_9615(state, level, pos, oldState, movedByPiston);
        if (state.method_11654(STATE) == PotentSulfurState.ERUPTING || state.method_11654(STATE) == PotentSulfurState.CONTINUOUS) {
            level.method_8427(pos, this, 0, 0);
            level.method_8396(null, pos, state.method_11654(STATE) == PotentSulfurState.CONTINUOUS ? ModSoundEvents.GEYSER_CONTINUOUS_START.get() : ModSoundEvents.GEYSER_ERUPTION_START.get(), class_3419.field_15245, 1.0F, 1.0F);
            level.method_43276(class_5712.field_28174, pos, class_5712.class_7397.method_43287(state));
        }
    }

    @Override
    public void method_9496(class_2680 state, class_1937 level, class_2338 pos, class_5819 random) {
        if (state.method_11654(STATE) != PotentSulfurState.DRY) {
            if (level.method_8316(pos.method_10084()).method_33659(class_3612.field_15910)) {
                spawnBubbleParticlesAt(level, random, pos.method_10263(), pos.method_10264() + 1, pos.method_10260());
                spawnBubbleParticlesAt(level, random, pos.method_10263(), pos.method_10264() + 1, pos.method_10260());
                if (random.method_43048(10) == 0) {
                    level.method_8486(pos.method_10263(), pos.method_10264(), pos.method_10260(), ModSoundEvents.NOXIOUS_GAS.get(), class_3419.field_15256, 1.0F, 1.0F, false);
                }
            }
        }
    }

    private static void spawnBubbleParticlesAt(class_1937 level, class_5819 random, double x, double y, double z) {
        level.method_8494(ModParticles.SULFUR_BUBBLES.get(), x + random.method_43057(), y + random.method_43057(), z + random.method_43057(), 0.0, 0.0, 0.0);
    }

    @Override
    public boolean method_9592(class_2680 state, class_1937 level, class_2338 pos, int id, int param) {
        if (level.method_8321(pos) instanceof PotentSulfurBlockEntity potentSulfur) {
            potentSulfur.eruptionTick = level.method_8510();
        }

        return true;
    }

    @Override @Nullable
    public <T extends class_2586> class_5558<T> method_31645(class_1937 level, class_2680 state, class_2591<T> type) {
        boolean client = level.method_8608();

        if (!VanillaBackport.COMMON_CONFIG.doGeysersErupt.get()) {
            return method_31618(type, ModBlockEntities.POTENT_SULFUR.get(), state.method_11654(STATE) == PotentSulfurState.DRY
                ? null
                : client ? CLIENT_NOXIOUS_GAS_TICKER : SERVER_NAUSEA_EFFECT_TICKER);
        }

        return method_31618(
            type,
            ModBlockEntities.POTENT_SULFUR.get(),
            switch (state.method_11654(STATE)) {
                case DRY -> null;
                case WET -> client ? CLIENT_NOXIOUS_GAS_TICKER : SERVER_NAUSEA_EFFECT_TICKER;
                case DORMANT -> client ? CLIENT_NOXIOUS_GAS_TICKER : sequence(SERVER_WAITING_COUNTDOWN_TICKER, SERVER_NAUSEA_EFFECT_TICKER);
                case ERUPTING -> client ? CLIENT_GEYSER_PLUME_TICKER.apply(ModSoundEvents.GEYSER_ERUPTION_ACTIVE.get()) : sequence(SERVER_LAUNCH_ENTITY_TICKER, SERVER_WAITING_COUNTDOWN_TICKER);
                case CONTINUOUS -> client ? CLIENT_GEYSER_PLUME_TICKER.apply(ModSoundEvents.GEYSER_CONTINUOUS_ACTIVE.get()) : SERVER_LAUNCH_ENTITY_TICKER;
            }
        );
    }

    @Override
    protected class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }
}