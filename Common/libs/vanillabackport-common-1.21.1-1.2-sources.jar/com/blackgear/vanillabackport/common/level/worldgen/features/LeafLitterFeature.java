package com.blackgear.vanillabackport.common.level.worldgen.features;

import com.blackgear.vanillabackport.core.data.tags.ModBlockTags;
import com.mojang.serialization.Codec;
import net.minecraft.class_1923;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2902;
import net.minecraft.class_3031;
import net.minecraft.class_3341;
import net.minecraft.class_3481;
import net.minecraft.class_5281;
import net.minecraft.class_5819;
import net.minecraft.class_5821;
import org.jetbrains.annotations.Nullable;

public class LeafLitterFeature extends class_3031<LeafLitterConfiguration> {
    private static final int MIN_TRUNK_HEIGHT = 2;

    public LeafLitterFeature(Codec<LeafLitterConfiguration> codec) {
        super(codec);
    }
    
    @Override
    public boolean method_13151(class_5821<LeafLitterConfiguration> context) {
        class_5281 level = context.method_33652();
        class_2338 origin = context.method_33655();
        class_5819 random = context.method_33654();
        
        class_1923 chunkPos = new class_1923(origin);
        int minX = chunkPos.method_8326();
        int minZ = chunkPos.method_8328();
        
        boolean placedAny = false;
        
        for (int dx = 0; dx < 16; dx++) {
            for (int dz = 0; dz < 16; dz++) {
                int x = minX + dx;
                int z = minZ + dz;
                
                class_2338 treeBase = findTreeBase(level, x, z);
                if (treeBase != null) {
                    placedAny |= placeLeafLitterAround(level, random, treeBase, context.method_33656());
                }
            }
        }
        
        return placedAny;
    }
    
    @Nullable
    private class_2338 findTreeBase(class_5281 level, int x, int z) {
        int top = level.method_8624(class_2902.class_2903.field_13203, x, z) - 1;
        int bottom = level.method_31607();
        
        class_2338.class_2339 pos = new class_2338.class_2339(x, top, z);
        int consecutiveLogs = 0;

        for (int y = top; y > bottom; y--) {
            pos.method_33098(y);

            if (!isVerticalLog(level.method_8320(pos))) {
                return null;
            }

            consecutiveLogs++;

            if (level.method_8320(pos.method_10074()).method_26164(class_3481.field_29822)) {
                if (consecutiveLogs < MIN_TRUNK_HEIGHT) return null;
                
                if (!hasLeafCanopyAbove(level, x, z, top)) {
                    return null;
                }
                
                return pos.method_10062();
            }
        }
        
        return null;
    }
    
    private static boolean isVerticalLog(class_2680 state) {
        return state.method_26164(class_3481.field_15475) && state.method_28500(class_2741.field_12496)
            .map(axis -> axis == class_2350.class_2351.field_11052)
            .orElse(true);
    }
    
    private static boolean hasLeafCanopyAbove(class_5281 level, int x, int z, int trunkTopY) {
        int leafTop = level.method_8624(class_2902.class_2903.field_13197, x, z) - 1;

        if (leafTop <= trunkTopY) {
            return false;
        }

        class_2680 leafState = level.method_8320(new class_2338(x, leafTop, z));
        return leafState.method_26164(class_3481.field_15503) && leafState.method_26164(ModBlockTags.ALLOWS_LEAF_LITTER);
    }
    
    private boolean placeLeafLitterAround(class_5281 level, class_5819 random, class_2338 base, LeafLitterConfiguration config) {
        class_3341 bb = new class_3341(base.method_10263(), base.method_10264(), base.method_10260(), base.method_10263(), base.method_10264(), base.method_10260())
            .method_59718(config.radius(), config.height(), config.radius());
        
        class_2338.class_2339 pos = new class_2338.class_2339();
        boolean placedAny = false;
        
        for (int i = 0; i < config.tries(); i++) {
            pos.method_10103(
                random.method_39332(bb.method_35415(), bb.method_35418()),
                random.method_39332(bb.method_35416(), bb.method_35419()),
                random.method_39332(bb.method_35417(), bb.method_35420())
            );
            
            if (!level.method_37368(pos)) continue;
            
            if (tryPlaceLeafLitter(level, random, pos, config)) {
                placedAny = true;
            }
        }
        
        return placedAny;
    }
    
    private boolean tryPlaceLeafLitter(class_5281 level, class_5819 random, class_2338 pos, LeafLitterConfiguration config) {
        if (!level.method_8320(pos).method_26215()) return false;
        
        class_2338 below = pos.method_10074();
        if (!level.method_8320(below).method_26206(level, below, class_2350.field_11036)) return false;
        
        if (level.method_8598(class_2902.class_2903.field_13203, pos).method_10264() > pos.method_10264()) {
            return false;
        }
        
        class_2680 litterState = config.blockStateProvider().method_23455(random, pos);
        
        if (!litterState.method_26184(level, pos)) return false;
        
        level.method_8652(pos, litterState, class_2248.field_31028);
        return true;
    }
}