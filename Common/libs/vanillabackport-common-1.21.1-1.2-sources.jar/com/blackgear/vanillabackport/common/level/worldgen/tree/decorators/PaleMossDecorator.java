package com.blackgear.vanillabackport.common.level.worldgen.tree.decorators;

import com.blackgear.vanillabackport.common.level.blocks.HangingMossBlock;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import com.blackgear.vanillabackport.common.registries.worldgen.ModTreeDecorators;
import com.blackgear.vanillabackport.common.worldgen.features.TheGardenAwakensFeatures;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_156;
import net.minecraft.class_2338;
import net.minecraft.class_2382;
import net.minecraft.class_4662;
import net.minecraft.class_4663;
import net.minecraft.class_5281;
import net.minecraft.class_5819;
import net.minecraft.class_7924;

public class PaleMossDecorator extends class_4662 {
    public static final MapCodec<PaleMossDecorator> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
        Codec.floatRange(0.0F, 1.0F).fieldOf("leaves_probability").forGetter(decorator -> decorator.leavesProbability),
        Codec.floatRange(0.0F, 1.0F).fieldOf("trunk_probability").forGetter(decorator -> decorator.trunkProbability),
        Codec.floatRange(0.0F, 1.0F).fieldOf("ground_probability").forGetter(decorator -> decorator.groundProbability)
    ).apply(instance, PaleMossDecorator::new));

    private final float leavesProbability;
    private final float trunkProbability;
    private final float groundProbability;
    
    @Override
    protected class_4663<?> method_28893() {
        return ModTreeDecorators.PALE_MOSS.get();
    }

    public PaleMossDecorator(float leavesProbability, float trunkProbability, float groundProbability) {
        this.leavesProbability = leavesProbability;
        this.trunkProbability = trunkProbability;
        this.groundProbability = groundProbability;
    }

    @Override
    public void method_23469(class_7402 context) {
        class_5819 random = context.method_43320();
        class_5281 level = (class_5281) context.method_43316();
        List<class_2338> logs = class_156.method_43027(context.method_43321(), random);
        if (!logs.isEmpty()) {
            class_2338 position = Collections.min(logs, Comparator.comparingInt(class_2382::method_10264));
            if (random.method_43057() < this.groundProbability) {
                level.method_30349()
                    .method_46759(class_7924.field_41239)
                    .flatMap(registry -> registry.method_46746(TheGardenAwakensFeatures.PALE_MOSS_PATCH))
                    .ifPresent(feature -> feature.comp_349().method_12862(level, level.method_8410().method_14178().method_12129(), random, position.method_10084()));
            }

            context.method_43321().forEach(pos -> {
                if (random.method_43057() < this.trunkProbability) {
                    class_2338 down = pos.method_10074();
                    if (context.method_43317(down)) {
                        addMossHanger(down, context);
                    }
                }
            });
            context.method_43322().forEach(pos -> {
                if (random.method_43057() < this.leavesProbability) {
                    class_2338 down = pos.method_10074();
                    if (context.method_43317(down)) {
                        addMossHanger(down, context);
                    }
                }
            });
        }
    }

    private static void addMossHanger(class_2338 pos, class_7402 context) {
        while (context.method_43317(pos.method_10074()) && context.method_43320().method_43057() >= 0.5F) {
            context.method_43318(pos, ModBlocks.PALE_HANGING_MOSS.get().method_9564().method_11657(HangingMossBlock.TIP, false));
            pos = pos.method_10074();
        }

        context.method_43318(pos, ModBlocks.PALE_HANGING_MOSS.get().method_9564().method_11657(HangingMossBlock.TIP, true));
    }
}