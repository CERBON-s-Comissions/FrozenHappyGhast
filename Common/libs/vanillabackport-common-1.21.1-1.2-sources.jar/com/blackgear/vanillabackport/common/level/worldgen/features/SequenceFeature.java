package com.blackgear.vanillabackport.common.level.worldgen.features;

import com.mojang.serialization.Codec;
import net.minecraft.class_3031;
import net.minecraft.class_3179;
import net.minecraft.class_5821;
import net.minecraft.class_6796;
import net.minecraft.class_6880;

public class SequenceFeature extends class_3031<class_3179> {
    public SequenceFeature(Codec<class_3179> codec) {
        super(codec);
    }

    @Override
    public boolean method_13151(class_5821<class_3179> context) {
        for (class_6880<class_6796> feature : context.method_33656().field_13827) {
            if (!feature.comp_349().method_39644(context.method_33652(), context.method_33653(), context.method_33654(), context.method_33655())) {
                return false;
            }
        }

        return true;
    }
}
