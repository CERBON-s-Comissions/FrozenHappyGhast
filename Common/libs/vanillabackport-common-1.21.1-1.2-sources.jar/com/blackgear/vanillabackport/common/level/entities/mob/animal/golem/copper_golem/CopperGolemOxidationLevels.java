package com.blackgear.vanillabackport.common.level.entities.mob.animal.golem.copper_golem;

import com.blackgear.vanillabackport.client.registries.ModSoundEvents;
import java.util.Map;
import net.minecraft.class_2960;
import net.minecraft.class_5955.class_5811;

public class CopperGolemOxidationLevels {
    private static final CopperGolemOxidationLevel UNAFFECTED = new CopperGolemOxidationLevel(
        ModSoundEvents.COPPER_GOLEM_SPIN.get(),
        ModSoundEvents.COPPER_GOLEM_HURT.get(),
        ModSoundEvents.COPPER_GOLEM_DEATH.get(),
        ModSoundEvents.COPPER_GOLEM_STEP.get(),
        class_2960.method_60656("textures/entity/copper_golem/copper_golem.png"),
        class_2960.method_60656("textures/entity/copper_golem/copper_golem_eyes.png")
    );
    private static final CopperGolemOxidationLevel EXPOSED = new CopperGolemOxidationLevel(
        ModSoundEvents.COPPER_GOLEM_SPIN.get(),
        ModSoundEvents.COPPER_GOLEM_HURT.get(),
        ModSoundEvents.COPPER_GOLEM_DEATH.get(),
        ModSoundEvents.COPPER_GOLEM_STEP.get(),
        class_2960.method_60656("textures/entity/copper_golem/exposed_copper_golem.png"),
        class_2960.method_60656("textures/entity/copper_golem/exposed_copper_golem_eyes.png")
    );
    private static final CopperGolemOxidationLevel WEATHERED = new CopperGolemOxidationLevel(
        ModSoundEvents.COPPER_GOLEM_WEATHERED_SPIN.get(),
        ModSoundEvents.COPPER_GOLEM_WEATHERED_HURT.get(),
        ModSoundEvents.COPPER_GOLEM_WEATHERED_DEATH.get(),
        ModSoundEvents.COPPER_GOLEM_WEATHERED_STEP.get(),
        class_2960.method_60656("textures/entity/copper_golem/weathered_copper_golem.png"),
        class_2960.method_60656("textures/entity/copper_golem/weathered_copper_golem_eyes.png")
    );
    private static final CopperGolemOxidationLevel OXIDIZED = new CopperGolemOxidationLevel(
        ModSoundEvents.COPPER_GOLEM_OXIDIZED_SPIN.get(),
        ModSoundEvents.COPPER_GOLEM_OXIDIZED_HURT.get(),
        ModSoundEvents.COPPER_GOLEM_OXIDIZED_DEATH.get(),
        ModSoundEvents.COPPER_GOLEM_OXIDIZED_STEP.get(),
        class_2960.method_60656("textures/entity/copper_golem/oxidized_copper_golem.png"),
        class_2960.method_60656("textures/entity/copper_golem/oxidized_copper_golem_eyes.png")
    );

    private static final Map<class_5811, CopperGolemOxidationLevel> WEATHERED_STATES = Map.of(
        class_5811.field_28704, UNAFFECTED,
        class_5811.field_28705, EXPOSED,
        class_5811.field_28706, WEATHERED,
        class_5811.field_28707, OXIDIZED
    );

    public static CopperGolemOxidationLevel getOxidationLevel(class_5811 state) {
        return WEATHERED_STATES.get(state);
    }
}
