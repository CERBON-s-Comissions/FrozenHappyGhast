package com.blackgear.vanillabackport.common.level.blocks;

import com.blackgear.vanillabackport.client.level.sound.AmbientDesertBlockSoundsPlayer;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import com.blackgear.vanillabackport.core.util.BlockShaper;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2256;
import net.minecraft.class_2311;
import net.minecraft.class_2338;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3726;
import net.minecraft.class_4538;
import net.minecraft.class_5819;

public class ShortDryGrassBlock extends class_2311 implements class_2256 {
    private static final class_265 SHAPE = BlockShaper.column(12.0, 0.0, 10.0);
    
    public ShortDryGrassBlock(class_2251 properties) {
        super(properties);
    }
    
    @Override
    protected class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return field_10910;
    }
    
    @Override
    public void method_9496(class_2680 state, class_1937 level, class_2338 pos, class_5819 random) {
        AmbientDesertBlockSoundsPlayer.playAmbientDryGrassSounds(level, pos, random);
    }

    @Override
    public boolean method_9651(class_4538 level, class_2338 pos, class_2680 state) {
        return true;
    }

    @Override
    public boolean method_9650(class_1937 level, class_5819 random, class_2338 pos, class_2680 state) {
        return true;
    }

    @Override
    public void method_9652(class_3218 level, class_5819 random, class_2338 pos, class_2680 state) {
        level.method_8501(pos, ModBlocks.TALL_DRY_GRASS.get().method_9564());
    }
}