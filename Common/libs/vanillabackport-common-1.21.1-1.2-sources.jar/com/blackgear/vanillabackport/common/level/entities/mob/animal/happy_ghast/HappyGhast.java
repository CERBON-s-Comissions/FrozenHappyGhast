package com.blackgear.vanillabackport.common.level.entities.mob.animal.happy_ghast;

import com.blackgear.vanillabackport.client.registries.ModSoundEvents;
import com.blackgear.vanillabackport.common.api.extensions.entity.movement.PositionAwareEntity;
import com.blackgear.vanillabackport.common.api.modules.leash_behavior.LeashPhysics;
import com.blackgear.vanillabackport.common.api.modules.leash_behavior.LeashableCallback;
import com.blackgear.vanillabackport.common.registries.entities.ModEntityTypes;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.blackgear.vanillabackport.core.data.tags.ModBlockTags;
import com.blackgear.vanillabackport.core.data.tags.ModItemTags;
import com.blackgear.vanillabackport.core.mixin.common.access.LivingEntityAccessor;
import com.blackgear.vanillabackport.core.util.Utilities.*;
import com.blackgear.vanillabackport.core.util.WorldUtilities.*;
import com.mojang.serialization.Dynamic;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1313;
import net.minecraft.class_1330;
import net.minecraft.class_1331;
import net.minecraft.class_1333;
import net.minecraft.class_1335;
import net.minecraft.class_1347;
import net.minecraft.class_1352;
import net.minecraft.class_1407;
import net.minecraft.class_1408;
import net.minecraft.class_1429;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_1959;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_2777;
import net.minecraft.class_2902;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_3486;
import net.minecraft.class_3532;
import net.minecraft.class_3610;
import net.minecraft.class_3695;
import net.minecraft.class_4095;
import net.minecraft.class_4538;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.class_5819;
import net.minecraft.class_6026;
import net.minecraft.class_9817;
import net.minecraft.world.entity.*;
import org.jetbrains.annotations.Nullable;

import java.util.EnumSet;
import java.util.function.BooleanSupplier;

public class HappyGhast extends class_1429 implements class_6026, LeashableCallback, PositionAwareEntity {
    private static final class_2940<Boolean> IS_LEASH_HOLDER = class_2945.method_12791(HappyGhast.class, class_2943.field_13323);
    private static final class_2940<Boolean> STAYS_STILL = class_2945.method_12791(HappyGhast.class, class_2943.field_13323);
    public static final class_1856 IS_FOOD = class_1856.method_8106(ModItemTags.HAPPY_GHAST_FOOD);
    private boolean requiresPrecisePosition;
    private int serverStillTimeout;
    private int leashHolderTime = 0;

    public HappyGhast(class_1299<? extends class_1429> entityType, class_1937 level) {
        super(entityType, level);
        this.field_6207 = new GhastMoveControl(this, true, this::isOnStillTimeout);
        this.field_6206 = new HappyGhastLookControl();
    }

    private void setServerStillTimeout(int timeout) {
        if (this.serverStillTimeout <= 0 && timeout > 0 && this.method_37908() instanceof class_3218 level) {
            this.method_43391(this.method_23317(), this.method_23318(), this.method_23321());
            level.method_14178().field_17254.method_18702(this, new class_2777(this));
        }

        this.serverStillTimeout = timeout;
        this.syncStayStillFlag();
    }

    private class_1408 createBabyNavigation(class_1937 level) {
        return new BabyFlyingPathNavigation(this, level);
    }

    @Override
    protected void method_5959() {
        this.field_6201.method_6277(3, new GhastFloatGoal(this));
        this.field_6201
            .method_6277(
                4,
                new TemptGoal.ForNonPathfinders(
                    this,
                    1.0,
                    stack -> !this.isHarnessed() && !this.method_6109() ? stack.method_31573(ModItemTags.HAPPY_GHAST_TEMPT_ITEMS) : IS_FOOD.method_8093(stack),
                    false,
                    7.0
                ).setTemptRange(16)
            );
        this.field_6201.method_6277(5, new RandomFloatAroundGoal(this, 16));
    }

    private void adultGhastSetup() {
        this.field_6207 = new GhastMoveControl(this, true, this::isOnStillTimeout);
        this.field_6206 = new HappyGhastLookControl();
        this.field_6189 = this.method_5965(this.method_37908());

        if (this.method_37908() instanceof class_3218 server) {
            this.method_47825(goal -> true);
            this.method_5959();
            this.method_18868().method_18900(server, this);
            this.field_18321.method_49709();
        }
    }

    private void babyGhastSetup() {
        this.field_6207 = new class_1331(this, 180, true);
        this.field_6206 = new class_1333(this);
        this.field_6189 = this.createBabyNavigation(this.method_37908());
        this.setServerStillTimeout(0);
        this.method_47825(goal -> true);
    }

    @Override
    protected void method_5619() {
        if (this.method_6109()) {
            this.babyGhastSetup();
        } else {
            this.adultGhastSetup();
        }

        super.method_5619();
    }

    public static class_5132.class_5133 createAttributes() {
        return class_1429.method_26827()
            .method_26868(class_5134.field_23716, 20.0)
            .method_26868(class_5134.field_23720, 0.05)
            .method_26868(class_5134.field_23719, 0.05)
            .method_26868(class_5134.field_23717, 16.0);
    }

    @Override
    protected float method_56077(float scale) {
        return Math.min(scale, 1.0F);
    }

    @Override
    public boolean getRequiresPrecisePosition() {
        return this.requiresPrecisePosition;
    }

    @Override
    public void setRequiresPrecisePosition(boolean requiresPrecisePosition) {
        this.requiresPrecisePosition = requiresPrecisePosition;
    }

    @Override
    protected void method_5623(double y, boolean onGround, class_2680 state, class_2338 pos) {
    }

    @Override
    public void method_6091(class_243 travelVector) {
        if (this.isOnStillTimeout()) {
            this.method_18799(class_243.field_1353);
            return;
        }

        float speed = (float) this.method_45325(class_5134.field_23720) * 5.0F / 3.0F;
        if (this.method_5787()) {
            if (this.method_5799()) {
                this.method_5724(speed, travelVector);
                this.method_5784(class_1313.field_6308, this.method_18798());
                this.method_18799(this.method_18798().method_1021(0.8F));
            } else if (this.method_5771()) {
                this.method_5724(speed, travelVector);
                this.method_5784(class_1313.field_6308, this.method_18798());
                this.method_18799(this.method_18798().method_1021(0.5F));
            } else {
                this.method_5724(speed, travelVector);
                this.method_5784(class_1313.field_6308, this.method_18798());
                this.method_18799(this.method_18798().method_1021(0.91F));
            }
        }

        this.method_29242(false);
    }

    @Override
    public boolean method_6101() {
        return false;
    }

    @Override
    public float method_6144(class_2338 pos, class_4538 level) {
        if (!level.method_22347(pos)) {
            return 0.0F;
        } else {
            return level.method_22347(pos.method_10074()) && !level.method_22347(pos.method_10087(2)) ? 10.0F : 5.0F;
        }
    }

    @Override
    public boolean method_6094() {
        return this.method_6109() || super.method_6094();
    }

    @Override
    protected boolean method_43689() {
        return false;
    }

    @Override
    protected void method_5712(class_2338 pos, class_2680 state) {
    }

    @Override
    public float method_6017() {
        return 1.0F;
    }
    
    @Override
    public int method_5970() {
        int interval = super.method_5970();
        return this.method_5782() ? interval * 6 : interval;
    }

    @Override
    protected @Nullable class_3414 method_5994() {
        return this.method_6109() ? ModSoundEvents.GHASTLING_AMBIENT.get() : ModSoundEvents.HAPPY_GHAST_AMBIENT.get();
    }

    @Override
    protected @Nullable class_3414 method_6011(class_1282 source) {
        return this.method_6109() ? ModSoundEvents.GHASTLING_HURT.get() : ModSoundEvents.HAPPY_GHAST_HURT.get();
    }

    @Override
    protected @Nullable class_3414 method_6002() {
        return this.method_6109() ? ModSoundEvents.GHASTLING_DEATH.get() : ModSoundEvents.HAPPY_GHAST_DEATH.get();
    }
    
    @Override
    protected float method_6107() {
        return this.method_6109() ? 1.0F : 4.0F;
    }
    
    @Override
    public int method_5945() {
        return 1;
    }

    @Override @Nullable
    public class_1296 method_5613(class_3218 level, class_1296 mate) {
        return ModEntityTypes.HAPPY_GHAST.get().method_5883(level);
    }

    @Override
    public boolean method_6482() {
        return false;
    }

    @Override
    public float method_17825() {
        return this.method_6109() ? 0.2375F : 1.0F;
    }

    @Override
    public boolean method_6481(class_1799 stack) {
        return IS_FOOD.method_8093(stack);
    }

    public void equipHarness() {
        this.method_37908().method_43129(null, this, ModSoundEvents.HARNESS_EQUIP.get(), class_3419.field_15254, 0.5F, 1.0F);
    }

    public boolean canBeHarnessed() {
        return this.method_5805() && !this.method_6109();
    }

    public boolean isHarnessed() {
        return this.method_6118(class_1304.field_6174).method_31573(ModItemTags.HARNESSES);
    }

    @Override
    public class_1269 method_5992(class_1657 player, class_1268 hand) {
        if (this.method_6109()) {
            return super.method_5992(player, hand);
        } else {
            class_1799 stack = player.method_5998(hand);
            if (!stack.method_7960()) {
                class_1269 result = stack.method_7920(player, this, hand);
                if (result.method_23665()) {
                    return result;
                }
            }

            if (!stack.method_31574(class_1802.field_8868) || this.method_5782() || !this.isHarnessed() && !player.method_7337()) {
                if (this.isHarnessed()) {
                    if (!this.method_37908().method_8608()) player.method_5804(this);

                    return class_1269.method_29236(this.method_37908().method_8608());
                } else {
                    return super.method_5992(player, hand);
                }
            } else {
                stack.method_7970(1, player, method_56079(hand));
                this.method_43077(ModSoundEvents.HARNESS_UNEQUIP.get());
                class_1799 harness = this.method_6118(class_1304.field_6174);
                this.method_5673(class_1304.field_6174, class_1799.field_8037);
                this.method_5699(harness, this.method_17682() + 0.5F);
                return class_1269.field_5812;
            }
        }
    }

    @Override
    public class_238 method_5830() {
        class_238 box = super.method_5830();
        float height = this.method_17682();
        return box.method_35575(box.field_1322 - height / 2.0F);
    }

    @Override
    protected void method_5627(class_1297 passenger) {
        if (!this.method_5782()) {
            this.method_37908().method_43128(null, this.method_23317(), this.method_23318(), this.method_23321(), ModSoundEvents.HARNESS_GOGGLES_DOWN.get(), this.method_5634(), 1.0F, 1.0F);
        }

        super.method_5627(passenger);
        if (!this.method_37908().field_9236) {
            if (!this.scanPlayerAboveGhast()) {
                this.setServerStillTimeout(0);
            } else if (this.serverStillTimeout > 10) {
                this.setServerStillTimeout(10);
            }
        }
    }

    @Override
    protected void method_5793(class_1297 passenger) {
        super.method_5793(passenger);
        if (!this.method_37908().field_9236) {
            this.setServerStillTimeout(10);
        }

        if (!this.method_5782()) {
            this.method_35055();
            this.method_37908().method_43128(null, this.method_23317(), this.method_23318(), this.method_23321(), ModSoundEvents.HARNESS_GOGGLES_UP.get(), this.method_5634(), 1.0F, 1.0F);
        }
    }

    @Override
    protected boolean method_5818(class_1297 passenger) {
        return this.method_5685().size() < 4;
    }

    @Override @Nullable
    public class_1309 method_5642() {
        return this.isHarnessed() && !this.isOnStillTimeout() && this.method_31483() instanceof class_1657 player
            ? player
            : super.method_5642();
    }

    @Override
    protected class_243 method_49482(class_1657 player, class_243 travelVector) {
        float forward = player.field_6212;
        float strafe = 0.0F;
        float upward = 0.0F;
        if (player.field_6250 != 0.0F) {
            float xOffset = class_3532.method_15362(player.method_36455() * class_3532.field_29847);
            float zOffset = -class_3532.method_15374(player.method_36455() * class_3532.field_29847);
            if (player.field_6250 < 0.0F) {
                xOffset *= -0.5F;
                zOffset *= -0.5F;
            }

            upward = zOffset;
            strafe = xOffset;
        }

        if (((LivingEntityAccessor) player).isJumping()) {
            upward += 0.5F;
        }

        return new class_243(forward, upward, strafe).method_1021(((double) 3.9F * this.method_45325(class_5134.field_23720)) * VanillaBackport.COMMON_CONFIG.happyGhastSpeedModifier.get());
    }

    protected class_241 getRiddenRotation(class_1309 controller) {
        return new class_241(controller.method_36455() * 0.5F, controller.method_36454());
    }

    @Override
    protected void method_49481(class_1657 controller, class_243 riddenInput) {
        super.method_49481(controller, riddenInput);
        class_241 rotation = this.getRiddenRotation(controller);
        float yRot = this.method_36454();
        float diff = class_3532.method_15393(rotation.field_1342 - yRot);
        yRot += diff * 0.08F;
        this.method_5710(yRot, rotation.field_1343);
        this.field_5982 = this.field_6283 = this.field_6241 = yRot;
    }

    @Override
    protected class_4095.class_5303<HappyGhast> method_28306() {
        return HappyGhastAi.brainProvider();
    }

    @Override
    protected class_4095<?> method_18867(Dynamic<?> dynamic) {
        return HappyGhastAi.makeBrain(this.method_28306().method_28335(dynamic));
    }

    @Override @SuppressWarnings("unchecked")
    public class_4095<HappyGhast> method_18868() {
        return (class_4095<HappyGhast>) super.method_18868();
    }

    @Override
    protected void method_5958() {
        if (this.method_6109()) {
            class_3695 profiler = this.method_37908().method_16107();
            profiler.method_15396("happyGhastBrain");
            this.method_18868().method_19542((class_3218) this.method_37908(), this);
            profiler.method_15405("HappyGhastActivityUpdate");
            HappyGhastAi.updateActivity(this);
            profiler.method_15407();
        }

        this.checkRestriction();
        super.method_5958();
    }

    @Override
    public void method_5773() {
        super.method_5773();
        if (!this.method_37908().method_8608()) {
            if (this.leashHolderTime > 0) {
                this.leashHolderTime--;
            }

            this.setLeashHolder(this.leashHolderTime > 0);
            if (this.serverStillTimeout > 0) {
                if (this.field_6012 > 60) {
                    this.serverStillTimeout--;
                }

                this.setServerStillTimeout(this.serverStillTimeout);
            }

            if (this.scanPlayerAboveGhast()) {
                this.setServerStillTimeout(10);
            }
        }
    }

    @Override
    public void method_6007() {
        if (!this.method_37908().field_9236) {
            this.setRequiresPrecisePosition(this.isOnStillTimeout());
        }

        super.method_6007();
        this.continuousHeal();
    }

    private int getHappyGhastRestrictionRadius() {
        return !this.method_6109() && !this.isHarnessed() ? 64 : 32;
    }

    private void checkRestriction() {
        if (!this.method_60953() && !this.method_5782()) {
            int radius = this.getHappyGhastRestrictionRadius();
            if (!this.method_18410() || !this.method_18412().method_19771(this.method_24515(), radius + 16) || radius != this.method_18413()) {
                this.method_18408(this.method_24515(), radius);
            }
        }
    }

    private void continuousHeal() {
        if (this.method_37908() instanceof class_3218 server && this.method_5805() && this.field_6213 == 0 && this.method_6063() != this.method_6032()) {
            boolean isFastHealing = server.method_8597().comp_645() && (EnvironmentUtils.isInClouds(this) || EnvironmentUtils.precipitationAt(this.method_37908(), this.method_24515()) != class_1959.class_1963.field_9384);
            if (this.field_6012 % (isFastHealing ? 20 : 600) == 0) {
                this.method_6025(1.0F);
            }
        }
    }
    
    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        super.method_5693(builder);
        builder.method_56912(IS_LEASH_HOLDER, false);
        builder.method_56912(STAYS_STILL, false);
    }

    private void setLeashHolder(boolean holder) {
        this.field_6011.method_12778(IS_LEASH_HOLDER, holder);
    }

    public boolean isLeashHolder() {
        return this.field_6011.method_12789(IS_LEASH_HOLDER);
    }

    private void syncStayStillFlag() {
        this.field_6011.method_12778(STAYS_STILL, this.serverStillTimeout > 0);
    }

    public boolean staysStill() {
        return this.field_6011.method_12789(STAYS_STILL);
    }

    @Override
    public boolean vb$supportsQuadLeashAsHolder() {
        return true;
    }

    @Override
    public class_243[] vb$getQuadLeashHolderOffsets() {
        return LeashPhysics.createQuadOffsets(this, -0.03125, 0.4375, 0.46875, 0.03125);
    }

    @Override
    protected class_243 method_29919() {
        return class_243.field_1353;
    }

    @Override
    public double vb$leashElasticDistance() {
        return 10.0;
    }

    @Override
    public double vb$leashSnapDistance() {
        return 16.0;
    }

    @Override
    public void vb$onElasticLeashPull() {
        LeashableCallback.super.vb$onElasticLeashPull();
        this.method_5962().field_6374 = class_1335.class_1336.field_6377;
    }

    @Override
    public void vb$notifyLeashHolder(class_9817 leashee) {
        class_1297 entity = (class_1297) leashee;
        if (((LeashableCallback) entity).vb$supportsQuadLeash()) {
            this.leashHolderTime = 5;
        }
    }

    @Override
    public void method_5652(class_2487 compound) {
        super.method_5652(compound);
        compound.method_10569("still_timeout", this.serverStillTimeout);
    }

    @Override
    public void method_5749(class_2487 compound) {
        super.method_5749(compound);
        this.setServerStillTimeout(compound.method_10550("still_timeout"));
    }

    public boolean isOnStillTimeout() {
        return this.staysStill() || this.serverStillTimeout > 0;
    }

    private boolean scanPlayerAboveGhast() {
        class_238 happyGhastBb = this.method_5829();
        class_238 ghastDetectionBox = new class_238(happyGhastBb.field_1323 - 1.0, happyGhastBb.field_1325 - class_3532.field_29849, happyGhastBb.field_1321 - 1.0, happyGhastBb.field_1320 + 1.0, happyGhastBb.field_1325 + happyGhastBb.method_17940() / 2.0, happyGhastBb.field_1324 + 1.0);

        for (class_1657 player : this.method_37908().method_18456()) {
            if (!player.method_7325()) {
                class_1297 rootVehicle = player.method_5668();
                if (!(rootVehicle instanceof HappyGhast) && ghastDetectionBox.method_1006(rootVehicle.method_19538())) {
                    return true;
                }
            }
        }

        return false;
    }

    @Override
    protected class_1330 method_5963() {
        return new GhastBodyRotationControl(this);
    }

    @Override
    public boolean method_30948() {
        if (!this.method_6109() && this.method_5805()) {
            return this.method_5782() || this.isOnStillTimeout();
        } else {
            return false;
        }
    }
    
    static class BabyFlyingPathNavigation extends class_1407 {
        public BabyFlyingPathNavigation(class_1308 mob, class_1937 level) {
            super(mob, level);
            this.method_6332(false);
            this.method_6354(true);
        }

        @Override
        protected boolean method_6341(class_243 posVec31, class_243 posVec32) {
            return method_43394(this.field_6684, posVec31, posVec32, false);
        }
    }

    static class GhastBodyRotationControl extends class_1330 {
        private final HappyGhast ghast;

        public GhastBodyRotationControl(HappyGhast ghast) {
            super(ghast);
            this.ghast = ghast;
        }

        @Override
        public void method_6224() {
            if (this.ghast.method_5782()) {
                this.ghast.field_6283 = this.ghast.field_6241 = this.ghast.method_36454();
            }

            super.method_6224();
        }
    }

    static class GhastFloatGoal extends class_1347 {
        private final HappyGhast ghast;

        public GhastFloatGoal(HappyGhast ghast) {
            super(ghast);
            this.ghast = ghast;
        }

        @Override
        public boolean method_6264() {
            return !this.ghast.isOnStillTimeout() && super.method_6264();
        }
    }

    class HappyGhastLookControl extends class_1333 {
        HappyGhastLookControl() {
            super(HappyGhast.this);
        }

        @Override
        public void method_6231() {
            if (HappyGhast.this.isOnStillTimeout()) {
                float closeAngle = MthUtils.wrapDegrees90(HappyGhast.this.method_36454());
                HappyGhast.this.method_36456(HappyGhast.this.method_36454() - closeAngle);
                HappyGhast.this.method_5847(HappyGhast.this.method_36454());
            } else if (this.field_35103 > 0) {
                this.field_35103--;
                double x = this.field_6364 - HappyGhast.this.method_23317();
                double z = this.field_6362 - HappyGhast.this.method_23321();
                HappyGhast.this.method_36456(-((float) class_3532.method_15349(x, z)) * class_3532.field_29848);
                HappyGhast.this.field_6283 = HappyGhast.this.method_36454();
                HappyGhast.this.field_6241 = HappyGhast.this.field_6283;
            } else {
                if (HappyGhast.this.method_5782() && HappyGhast.this.method_5642() instanceof class_1657) {
                    return;
                }

                class_243 movement = this.field_6361.method_18798();
                this.field_6361.method_36456(-((float) class_3532.method_15349(movement.field_1352, movement.field_1350)) * class_3532.field_29848);
                this.field_6361.field_6283 = this.field_6361.method_36454();
            }
        }
    }

    static class GhastMoveControl extends class_1335 {
        private final HappyGhast ghast;
        private int floatDuration;
        private final boolean careful;
        private final BooleanSupplier shouldBeStopped;

        public GhastMoveControl(HappyGhast ghast, boolean careful, BooleanSupplier shouldBeStopped) {
            super(ghast);
            this.ghast = ghast;
            this.careful = careful;
            this.shouldBeStopped = shouldBeStopped;
        }

        @Override
        public void method_6240() {
            if (this.shouldBeStopped.getAsBoolean()) {
                this.field_6374 = class_1336.field_6377;
                EntityUtils.stopInPlace(this.ghast);
            }

            if (this.field_6374 == class_1336.field_6378) {
                if (this.floatDuration-- <= 0) {
                    this.floatDuration += this.ghast.method_59922().method_43048(5) + 2;
                    class_243 target = new class_243(this.field_6370 - this.ghast.method_23317(), this.field_6369 - this.ghast.method_23318(), this.field_6367 - this.ghast.method_23321());
                    if (this.canReach(target)) {
                        this.ghast.method_18799(this.ghast.method_18798().method_1019(target.method_1029().method_1021(this.ghast.method_45325(class_5134.field_23720) * 5.0 / 3.0)));
                    } else {
                        this.field_6374 = class_1336.field_6377;
                    }
                }
            }
        }

        private boolean canReach(class_243 target) {
            class_238 entityBox = this.ghast.method_5829();
            class_238 targetBox = entityBox.method_997(target);

            if (this.careful) {
                for (class_2338 position : PositionUtils.betweenClosed(targetBox.method_1014(1.0))) {
                    if (!this.blockTraversalPossible(this.ghast.method_37908(), null, null, position, false, false)) {
                        return false;
                    }
                }
            }

            boolean inWater = this.ghast.method_5799();
            boolean inLava = this.ghast.method_5771();
            class_243 start = this.ghast.method_19538();
            class_243 end = start.method_1019(target);

            return PositionUtils.forEachBlockIntersectedBetween(
                start,
                end,
                targetBox,
                (pos, step) -> CollisionUtils.intersects(entityBox, pos) || this.blockTraversalPossible(this.ghast.method_37908(), start, end, pos, inWater, inLava)
            );
        }

        private boolean blockTraversalPossible(
            class_1922 level,
            @Nullable class_243 start,
            @Nullable class_243 end,
            class_2338 pos,
            boolean canPathThroughWater,
            boolean canPathThroughLava
        ) {
            class_2680 state = level.method_8320(pos);
            if (state.method_26215()) {
                return true;
            } else {
                boolean preciseBlockCollisions = start != null && end != null;
                boolean pathNoCollisions = preciseBlockCollisions
                    ? !CollisionUtils.collidedWithShapeMovingFrom(this.ghast, start, end, state.method_26220(level, pos).method_1096(pos.method_10263(), pos.method_10264(), pos.method_10260()).method_1090())
                    : state.method_26220(level, pos).method_1110();
                if (!this.careful) {
                    return pathNoCollisions;
                } else if (state.method_26164(ModBlockTags.HAPPY_GHAST_AVOIDS)) {
                    return false;
                } else {
                    class_3610 fluidState = level.method_8316(pos);
                    if (!fluidState.method_15769() && (!preciseBlockCollisions || CollisionUtils.collidedWithFluid(this.ghast, fluidState, pos, start, end))) {
                        if (fluidState.method_15767(class_3486.field_15517)) {
                            return canPathThroughWater;
                        }

                        if (fluidState.method_15767(class_3486.field_15518)) {
                            return canPathThroughLava;
                        }
                    }

                    return pathNoCollisions;
                }
            }
        }
    }

    static class RandomFloatAroundGoal extends class_1352 {
        private final HappyGhast ghast;
        private final int distanceToBlocks;

        public RandomFloatAroundGoal(HappyGhast ghast, int distanceToBlocks) {
            this.ghast = ghast;
            this.distanceToBlocks = distanceToBlocks;
            this.method_6265(EnumSet.of(class_4134.field_18405));
        }

        @Override
        public boolean method_6264() {
            class_1335 control = this.ghast.method_5962();
            if (!control.method_6241()) {
                return true;
            } else {
                double x = control.method_6236() - this.ghast.method_23317();
                double y = control.method_6235() - this.ghast.method_23318();
                double z = control.method_6237() - this.ghast.method_23321();
                double distance = x * x + y * y + z * z;
                return distance < 1.0 || distance > 3600.0;
            }
        }

        @Override
        public boolean method_6266() {
            return false;
        }

        @Override
        public void method_6269() {
            class_243 target = getSuitableFlyToPosition(this.ghast, this.distanceToBlocks);
            this.ghast.method_5962().method_6239(target.method_10216(), target.method_10214(), target.method_10215(), 1.0);
        }

        public static class_243 getSuitableFlyToPosition(class_1308 mob, int distanceToBlocks) {
            class_1937 level = mob.method_37908();
            class_5819 random = mob.method_59922();
            class_243 origin = mob.method_19538();
            class_243 target = null;

            for (int attempt = 0; attempt < 64; attempt++) {
                target = chooseRandomPositionWithRestriction(mob, origin, random);
                if (target != null && isGoodTarget(level, target, distanceToBlocks)) {
                    return target;
                }
            }

            if (target == null) {
                target = chooseRandomPosition(origin, random);
            }

            class_2338 pos = class_2338.method_49638(target);
            int floor = level.method_8624(class_2902.class_2903.field_13197, pos.method_10263(), pos.method_10260());
            if (floor < pos.method_10264() && floor > level.method_31607()) {
                target = new class_243(target.method_10216(), mob.method_23318() - Math.abs(mob.method_23318() - target.method_10214()), target.method_10215());
            }

            return target;
        }

        private static boolean isGoodTarget(class_1937 level, class_243 target, int distanceToBlocks) {
            if (distanceToBlocks <= 0) {
                return true;
            } else {
                class_2338 pos = class_2338.method_49638(target);
                if (level.method_8320(pos).method_26215()) {
                    for (class_2350 direction : class_2350.values()) {
                        for (int distance = 1; distance < distanceToBlocks; distance++) {
                            class_2338 neighbor = pos.method_10079(direction, distance);
                            if (!level.method_8320(neighbor).method_26215()) {
                                return true;
                            }
                        }
                    }
                }

                return false;
            }
        }

        private static class_243 chooseRandomPosition(class_243 origin, class_5819 random) {
            double x = origin.method_10216() + (random.method_43057() * 2.0F - 1.0F) * 16.0F;
            double y = origin.method_10214() + (random.method_43057() * 2.0F - 1.0F) * 16.0F;
            double z = origin.method_10215() + (random.method_43057() * 2.0F - 1.0F) * 16.0F;
            return new class_243(x, y, z);
        }

        @Nullable
        private static class_243 chooseRandomPositionWithRestriction(class_1308 mob, class_243 origin, class_5819 random) {
            class_243 target = chooseRandomPosition(origin, random);
            return mob.method_18410() && !mob.method_18407(class_2338.method_49638(target)) ? null : target;
        }
    }
}