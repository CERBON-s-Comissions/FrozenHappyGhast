package com.blackgear.vanillabackport.common.level.entities.ai.behavior;

import com.blackgear.vanillabackport.common.api.extensions.entity.mounts.ControllableMob;
import com.blackgear.vanillabackport.common.registries.entities.ModMemoryModuleTypes;
import com.blackgear.vanillabackport.common.registries.items.ModDataComponents;
import com.blackgear.vanillabackport.core.util.WorldUtilities.PathfindingUtils;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import net.minecraft.class_1309;
import net.minecraft.class_1314;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_4097;
import net.minecraft.class_4102;
import net.minecraft.class_4140;
import net.minecraft.class_4141;

public class SpearRetreat extends class_4097<class_1314> {
    private final double speedModifierWhenRepositioning;

    public SpearRetreat(double speedModifierWhenRepositioning) {
        super(Map.of(ModMemoryModuleTypes.SPEAR_STATUS.get(), class_4141.field_18456), 100);
        this.speedModifierWhenRepositioning = speedModifierWhenRepositioning;
    }

    @Nullable
    private class_1309 getTarget(class_1314 mob) {
        return mob.method_18868().method_18904(class_4140.field_22355).orElse(null);
    }

    private boolean ableToAttack(class_1314 mob) {
        return this.getTarget(mob) != null && mob.method_6047().method_57826(ModDataComponents.KINETIC_WEAPON.get());
    }

    @Override
    protected boolean checkExtraStartConditions(class_3218 level, class_1314 mob) {
        if (this.ableToAttack(mob) && !mob.method_6115()) {
            if (mob.method_18868().method_18904(ModMemoryModuleTypes.SPEAR_STATUS.get()).orElse(SpearStatus.APPROACH) != SpearStatus.RETREAT) {
                return false;
            } else {
                class_1309 target = this.getTarget(mob);
                double targetDistSqr = mob.method_5649(target.method_23317(), target.method_23318(), target.method_23321());
                int mountDistance = mob.method_5765() ? 2 : 0;
                double distance = Math.sqrt(targetDistSqr);
                class_243 awayPos = PathfindingUtils.getPosAway(mob, Math.max(0.0, 9 + mountDistance - distance), Math.max(1.0, 11 + mountDistance - distance), 7, target.method_19538());
                if (awayPos == null) {
                    return false;
                } else {
                    mob.method_18868().method_18878(ModMemoryModuleTypes.SPEAR_FLEEING_POSITION.get(), awayPos);
                    return true;
                }
            }
        } else {
            return false;
        }
    }

    @Override
    protected void start(class_3218 level, class_1314 mob, long gameTime) {
        mob.method_19540(true);
        mob.method_18868().method_18878(ModMemoryModuleTypes.SPEAR_FLEEING_TIME.get(), 0);
        super.method_18920(level, mob, gameTime);
    }

    @Override
    protected boolean canStillUse(class_3218 level, class_1314 mob, long gameTime) {
        return mob.method_18868().method_18904(ModMemoryModuleTypes.SPEAR_FLEEING_TIME.get()).orElse(100) < 100
            && mob.method_18868().method_18904(ModMemoryModuleTypes.SPEAR_FLEEING_POSITION.get()).isPresent()
            && !mob.method_5942().method_6357()
            && this.ableToAttack(mob);
    }

    @Override
    protected void tick(class_3218 level, class_1314 mob, long gameTime) {
        class_1309 target = this.getTarget(mob);
        float speedModifier = ControllableMob.of(mob.method_5668()).chargeSpeedModifier();
        mob.method_18868().method_18878(class_4140.field_18446, new class_4102(target, true));
        mob.method_18868().method_18878(ModMemoryModuleTypes.SPEAR_FLEEING_TIME.get(), mob.method_18868().method_18904(ModMemoryModuleTypes.SPEAR_FLEEING_TIME.get()).orElse(0) + 1);
        mob.method_18868().method_18904(ModMemoryModuleTypes.SPEAR_FLEEING_POSITION.get()).ifPresent(pos -> mob.method_5942().method_6337(pos.field_1352, pos.field_1351, pos.field_1350, speedModifier * this.speedModifierWhenRepositioning));
    }

    @Override
    protected void stop(class_3218 level, class_1314 mob, long gameTime) {
        mob.method_5942().method_6340();
        mob.method_19540(false);
        mob.method_6021();
        mob.method_18868().method_18875(ModMemoryModuleTypes.SPEAR_FLEEING_TIME.get());
        mob.method_18868().method_18875(ModMemoryModuleTypes.SPEAR_FLEEING_POSITION.get());
        mob.method_18868().method_18875(ModMemoryModuleTypes.SPEAR_STATUS.get());
    }
}
