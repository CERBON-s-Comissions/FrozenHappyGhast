package com.blackgear.vanillabackport.common.level.entities.mob.animal.wolf;

import com.blackgear.platform.core.BuiltInCoreRegistry;
import com.blackgear.platform.core.api.RegistryKey;
import com.blackgear.vanillabackport.common.api.modules.mob_variant.ClientAsset;
import com.blackgear.vanillabackport.common.api.modules.mob_variant.spawn.SpawnPrioritySelectors;
import com.blackgear.vanillabackport.common.api.modules.mob_variant.spawn.check.raw.RawBiomeCheck;
import com.blackgear.vanillabackport.core.VanillaBackport;
import net.minecraft.class_1959;
import net.minecraft.class_2960;
import net.minecraft.class_6862;

public class WolfDataVariants {
    public static final BuiltInCoreRegistry<WolfDataVariant> REGISTRIES = BuiltInCoreRegistry.create(class_2960.method_60656("wolf_variants"), VanillaBackport.NAMESPACE);

//    public static final ResourceKey<WolfDataVariant> TEST = register("test", "test_wolf", SpawnPrioritySelectors.fallback(0));

    private static RegistryKey<WolfDataVariant> register(String key, String assetId, class_6862<class_1959> tag) {
        return register(key, assetId, SpawnPrioritySelectors.single(new RawBiomeCheck(tag), 1));
    }

    private static RegistryKey<WolfDataVariant> register(String key, String assetId, SpawnPrioritySelectors selectors) {
        class_2960 wild = class_2960.method_60656("entity/wolf/" + assetId);
        class_2960 tame = class_2960.method_60656("entity/wolf/" + assetId + "_tame");
        class_2960 angry = class_2960.method_60656("entity/wolf/" + assetId + "_angry");
        return REGISTRIES.registerKey(
            key,
            new WolfDataVariant(
                new WolfDataVariant.AssetInfo(new ClientAsset(wild), new ClientAsset(tame), new ClientAsset(angry)),
                selectors
            )
        );
    }
}