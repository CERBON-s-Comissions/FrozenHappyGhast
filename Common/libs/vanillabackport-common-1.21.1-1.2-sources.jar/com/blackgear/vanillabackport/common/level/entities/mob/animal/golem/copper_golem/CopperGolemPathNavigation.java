package com.blackgear.vanillabackport.common.level.entities.mob.animal.golem.copper_golem;

import net.minecraft.class_11;
import net.minecraft.class_1308;
import net.minecraft.class_1409;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2818;
import net.minecraft.class_4076;
import org.jetbrains.annotations.Nullable;

public class CopperGolemPathNavigation extends class_1409 {
    private boolean canPathToTargetsBelowSurface;

    public CopperGolemPathNavigation(class_1308 mob, class_1937 level) {
        super(mob, level);
    }

    @Override
    public @Nullable class_11 method_6348(class_2338 pos, int reachRange) {
        class_2818 chunk = this.field_6677.method_8398().method_21730(class_4076.method_18675(pos.method_10263()), class_4076.method_18675(pos.method_10260()));
        if (chunk == null) {
            return null;
        } else {
            if (!this.canPathToTargetsBelowSurface) {
                pos = this.findSurfacePosition(chunk, pos);
            }

            return super.method_6348(pos, reachRange);
        }
    }

    private class_2338 findSurfacePosition(class_2818 chunk, class_2338 pos) {
        if (chunk.method_8320(pos).method_26215()) {
            class_2338.class_2339 columnPos = pos.method_25503().method_10098(class_2350.field_11033);

            while (columnPos.method_10264() >= this.field_6677.method_31607() && chunk.method_8320(columnPos).method_26215()) {
                columnPos.method_10098(class_2350.field_11033);
            }

            if (columnPos.method_10264() >= this.field_6677.method_31607()) {
                return columnPos.method_10084();
            }

            columnPos.method_33098(pos.method_10264() + 1);

            while (columnPos.method_10264() <= this.field_6677.method_31600() && chunk.method_8320(columnPos).method_26215()) {
                columnPos.method_10098(class_2350.field_11036);
            }

            pos = columnPos;
        }

        if (!chunk.method_8320(pos).method_51367()) {
            return pos;
        } else {
            class_2338.class_2339 columnPos = pos.method_25503().method_10098(class_2350.field_11036);

            while (columnPos.method_10264() >= this.field_6677.method_31600() && chunk.method_8320(columnPos).method_51367()) {
                columnPos.method_10098(class_2350.field_11036);
            }

            return columnPos.method_10062();
        }
    }

    public void setCanPathToTargetsBelowSurface(boolean canPathToTargetsBelowSurface) {
        this.canPathToTargetsBelowSurface = canPathToTargetsBelowSurface;
    }
}