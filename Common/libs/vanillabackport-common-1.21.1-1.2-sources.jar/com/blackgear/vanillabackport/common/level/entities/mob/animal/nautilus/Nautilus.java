package com.blackgear.vanillabackport.common.level.entities.mob.animal.nautilus;

import com.blackgear.vanillabackport.client.registries.ModSoundEvents;
import com.blackgear.vanillabackport.common.registries.entities.ModEntityTypes;
import com.mojang.serialization.Dynamic;
import net.minecraft.class_1282;
import net.minecraft.class_1296;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3695;
import net.minecraft.class_4048;
import net.minecraft.class_4050;
import net.minecraft.class_4095;
import org.jetbrains.annotations.Nullable;

public class Nautilus extends AbstractNautilus {
    public Nautilus(class_1299<? extends AbstractNautilus> entityType, class_1937 level) {
        super(entityType, level);
    }
    
    @Override
    protected class_4095<?> method_18867(Dynamic<?> dynamic) {
        return NautilusAi.makeBrain(this.method_28306().method_28335(dynamic));
    }
    
    @Override
    protected class_4095.class_5303<Nautilus> method_28306() {
        return NautilusAi.brainProvider();
    }
    
    @Override @SuppressWarnings("unchecked")
    public class_4095<Nautilus> method_18868() {
        return (class_4095<Nautilus>) super.method_18868();
    }
    
    @Override
    public @Nullable class_1296 method_5613(class_3218 level, class_1296 partner) {
        Nautilus baby = ModEntityTypes.NAUTILUS.get().method_5883(level);
        if (baby != null && this.method_6181()) {
            baby.method_6174(this.method_6139());
            baby.method_6173(true, true);
        }
        
        return baby;
    }
    
    @Override
    protected class_4048 method_55694(class_4050 pose) {
        return this.method_6109() ? super.method_55694(pose).method_18383(0.5F) : super.method_55694(pose);
    }
    
    @Override
    protected void method_5958() {
        class_3695 profiler = this.method_37908().method_16107();
        profiler.method_15396("nautilusBrain");
        this.method_18868().method_19542((class_3218) this.method_37908(), this);
        profiler.method_15405("nautilusActivityUpdate");
        NautilusAi.updateActivity(this);
        profiler.method_15407();
        super.method_5958();
    }
    
    @Override
    protected @Nullable class_3414 method_5994() {
        if (this.method_6109()) {
            return this.method_5869() ? ModSoundEvents.BABY_NAUTILUS_AMBIENT.get() : ModSoundEvents.BABY_NAUTILUS_AMBIENT_ON_LAND.get();
        } else {
            return this.method_5869() ? ModSoundEvents.NAUTILUS_AMBIENT.get() : ModSoundEvents.NAUTILUS_AMBIENT_ON_LAND.get();
        }
    }
    
    @Override
    protected @Nullable class_3414 method_6011(class_1282 source) {
        if (this.method_6109()) {
            return this.method_5869() ? ModSoundEvents.BABY_NAUTILUS_HURT.get() : ModSoundEvents.BABY_NAUTILUS_HURT_ON_LAND.get();
        } else {
            return this.method_5869() ? ModSoundEvents.NAUTILUS_HURT.get() : ModSoundEvents.NAUTILUS_HURT_ON_LAND.get();
        }
    }
    
    @Override
    protected @Nullable class_3414 method_6002() {
        if (this.method_6109()) {
            return this.method_5869() ? ModSoundEvents.BABY_NAUTILUS_DEATH.get() : ModSoundEvents.BABY_NAUTILUS_DEATH_ON_LAND.get();
        } else {
            return this.method_5869() ? ModSoundEvents.NAUTILUS_DEATH.get() : ModSoundEvents.NAUTILUS_DEATH_ON_LAND.get();
        }
    }
    
    @Override
    protected @Nullable class_3414 getDashSound() {
        return this.method_5869() ? ModSoundEvents.NAUTILUS_DASH.get() : ModSoundEvents.NAUTILUS_DASH_ON_LAND.get();
    }
    
    @Override
    protected @Nullable class_3414 getDashReadySound() {
        return this.method_5869() ? ModSoundEvents.NAUTILUS_DASH_READY.get() : ModSoundEvents.NAUTILUS_DASH_READY_ON_LAND.get();
    }
    
    @Override
    protected void playEatingSound() {
        class_3414 nautilusEatSound = this.method_6109() ? ModSoundEvents.BABY_NAUTILUS_EAT.get() : ModSoundEvents.NAUTILUS_EAT.get();
        this.method_43077(nautilusEatSound);
    }
    
    @Override
    protected class_3414 method_5737() {
        return this.method_6109() ? ModSoundEvents.BABY_NAUTILUS_SWIM.get() : ModSoundEvents.NAUTILUS_SWIM.get();
    }
    
    protected void handleAirSupply(int preTickAirSupply) {
        if (this.method_5805() && !this.method_5799()) {
            this.method_5855(preTickAirSupply - 1);
            if (this.method_5669() <= -20) {
                this.method_5855(0);
                this.method_5643(this.method_48923().method_48834(), 2.0F);
            }
        } else {
            this.method_5855(300);
        }
    }
    
    @Override
    public void method_5670() {
        int airSupply = this.method_5669();
        super.method_5670();
        this.handleAirSupply(airSupply);
    }
    
    @Override
    public boolean method_5931() {
        return !this.isAggravated();
    }
}