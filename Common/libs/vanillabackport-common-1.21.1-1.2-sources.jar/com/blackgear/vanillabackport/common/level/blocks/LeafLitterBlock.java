package com.blackgear.vanillabackport.common.level.blocks;

import com.blackgear.vanillabackport.core.util.WorldUtilities.BlockUtils;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2261;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2753;
import net.minecraft.class_3726;
import net.minecraft.class_4538;
import net.minecraft.class_4970;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.Nullable;

import java.util.function.Function;

public class LeafLitterBlock extends class_2261 implements SegmentableBlock {
    public static final class_2753 FACING = class_2741.field_12481;
    private final Function<class_2680, class_265> shapes;
    
    @Override
    public MapCodec<LeafLitterBlock> method_53969() {
        return method_54094(LeafLitterBlock::new);
    }

    public LeafLitterBlock(class_4970.class_2251 properties) {
        super(properties);
        this.method_9590(this.method_9595().method_11664()
            .method_11657(FACING, class_2350.field_11043)
            .method_11657(this.getSegmentAmountProperty(), MIN_SEGMENT));
        this.shapes = this.makeShapes();
    }
    
    private Function<class_2680, class_265> makeShapes() {
        return BlockUtils.getShapeForEachState(this, this.getShapeCalculator(FACING, this.getSegmentAmountProperty()));
    }
    
    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(FACING, rotation.method_10503(state.method_11654(FACING)));
    }

    @Override
    public class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(FACING)));
    }

    @Override
    public boolean method_9616(class_2680 state, class_1750 useContext) {
        return this.canBeReplaced(state, useContext, this.getSegmentAmountProperty()) || super.method_9616(state, useContext);
    }

    @Override
    public boolean method_9558(class_2680 state, class_4538 level, class_2338 pos) {
        class_2338 belowPos = pos.method_10074();
        return level.method_8320(belowPos).method_26206(level, belowPos, class_2350.field_11036);
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return this.shapes.apply(state);
    }

    @Override
    public @Nullable class_2680 method_9605(class_1750 context) {
        return this.getStateForPlacement(context, this, this.getSegmentAmountProperty(), FACING);
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING, this.getSegmentAmountProperty());
    }
}