package com.blackgear.vanillabackport.common.level.worldgen.features;

import com.mojang.serialization.Codec;
import java.util.Optional;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_3031;
import net.minecraft.class_5819;
import net.minecraft.class_5821;

public class SpeleothemFeature extends class_3031<SpeleothemConfiguration> {
    public SpeleothemFeature(Codec<SpeleothemConfiguration> codec) {
        super(codec);
    }

    @Override
    public boolean method_13151(class_5821<SpeleothemConfiguration> context) {
        class_1936 level = context.method_33652();
        class_2338 pos = context.method_33655();
        class_5819 random = context.method_33654();
        SpeleothemConfiguration config = context.method_33656();
        Optional<class_2350> tipDirection = getTipDirection(level, pos, random, config);
        if (tipDirection.isEmpty()) {
            return false;
        } else {
            class_2338 rootPos = pos.method_10093(tipDirection.get().method_10153());
            createPatchOfBaseBlocks(level, random, rootPos, config);
            int height = random.method_43057() < config.chanceOfTallerGeneration() && SpeleothemUtils.isEmptyOrWater(level.method_8320(pos.method_10093(tipDirection.get())))
                ? 2
                : 1;
            SpeleothemUtils.growSpeleothem(
                level,
                pos,
                tipDirection.get(),
                height,
                false,
                config.baseBlock().method_26204(),
                config.pointedBlock().method_26204(),
                config.replaceableBlocks()
            );
            return true;
        }
    }

    private static Optional<class_2350> getTipDirection(
        class_1936 level,
        class_2338 pos,
        class_5819 random,
        SpeleothemConfiguration config
    ) {
        boolean canPlaceAbove = SpeleothemUtils.isBase(level.method_8320(pos.method_10084()), config.baseBlock().method_26204(), config.replaceableBlocks());
        boolean canPlaceBelow = SpeleothemUtils.isBase(level.method_8320(pos.method_10074()), config.baseBlock().method_26204(), config.replaceableBlocks());
        if (canPlaceAbove && canPlaceBelow) {
            return Optional.of(random.method_43056() ? class_2350.field_11033 : class_2350.field_11036);
        } else if (canPlaceAbove) {
            return Optional.of(class_2350.field_11033);
        } else {
            return canPlaceBelow ? Optional.of(class_2350.field_11036) : Optional.empty();
        }
    }

    private void createPatchOfBaseBlocks(class_1936 level, class_5819 random, class_2338 pos, SpeleothemConfiguration config) {
        SpeleothemUtils.placeBaseBlockIfPossible(level, pos, config.baseBlock().method_26204(), config.replaceableBlocks());

        for (class_2350 direction : class_2350.class_2353.field_11062) {
            if (random.method_43057() <= config.chanceOfDirectionalSpread()) {
                class_2338 pos1 = pos.method_10093(direction);
                SpeleothemUtils.placeBaseBlockIfPossible(level, pos1, config.baseBlock().method_26204(), config.replaceableBlocks());
                if (random.method_43057() <= config.chanceOfSpreadRadius2()) {
                    class_2338 pos2 = pos1.method_10093(class_2350.method_10162(random));
                    SpeleothemUtils.placeBaseBlockIfPossible(level, pos2, config.baseBlock().method_26204(), config.replaceableBlocks());
                    if (random.method_43057() <= config.chanceOfSpreadRadius3()) {
                        class_2338 pos3 = pos2.method_10093(class_2350.method_10162(random));
                        SpeleothemUtils.placeBaseBlockIfPossible(level, pos3, config.baseBlock().method_26204(), config.replaceableBlocks());
                    }
                }
            }
        }
    }
}