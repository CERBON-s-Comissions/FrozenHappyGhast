package com.blackgear.vanillabackport.common.level.blocks;

import com.blackgear.vanillabackport.client.registries.ModSoundEvents;
import com.blackgear.vanillabackport.common.level.block_entities.ShelfBlockEntity;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlockStateProperties;
import com.blackgear.vanillabackport.core.data.tags.ModBlockTags;
import com.blackgear.vanillabackport.core.util.BlockShaper;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_10;
import net.minecraft.class_1264;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2754;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_3486;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_3965;
import net.minecraft.class_5712;
import net.minecraft.class_9062;
import net.minecraft.world.*;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Map;
import java.util.OptionalInt;

public class ShelfBlock extends class_2237 implements SelectableSlotContainer, SideChainPartBlock, class_3737 {
    public static final MapCodec<ShelfBlock> CODEC = method_54094(ShelfBlock::new);
    public static final class_2746 POWERED = class_2741.field_12484;
    public static final class_2754<class_2350> FACING = class_2741.field_12481;
    public static final class_2754<SideChainPart> SIDE_CHAIN_PART = ModBlockStateProperties.SIDE_CHAIN_PART;
    public static final class_2746 WATERLOGGED = class_2741.field_12508;
    private static final Map<class_2350, class_265> SHAPES = BlockShaper.rotateHorizontal(class_259.method_17786(class_2248.method_9541(0.0, 12.0, 11.0, 16.0, 16.0, 13.0), class_2248.method_9541(0.0, 0.0, 13.0, 16.0, 16.0, 16.0), class_2248.method_9541(0.0, 0.0, 11.0, 16.0, 4.0, 13.0)));

    @Override
    protected MapCodec<ShelfBlock> method_53969() {
        return field_46280;
    }

    public ShelfBlock(class_2251 properties) {
        super(properties);
        this.method_9590(
            this.field_10647
                .method_11664()
                .method_11657(FACING, class_2350.field_11043)
                .method_11657(POWERED, false)
                .method_11657(SIDE_CHAIN_PART, SideChainPart.UNCONNECTED)
                .method_11657(WATERLOGGED, false)
        );
    }

    @Override
    protected class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return SHAPES.get(state.method_11654(FACING));
    }

    @Override
    protected boolean method_9526(class_2680 state) {
        return true;
    }
    
    @Override
    protected boolean method_9516(class_2680 state, class_10 type) {
        return type == class_10.field_48 && state.method_26227().method_15767(class_3486.field_15517);
    }

    @Override @Nullable
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new ShelfBlockEntity(pos, state);
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING, POWERED, SIDE_CHAIN_PART, WATERLOGGED);
    }

    @Override
    protected void method_9536(class_2680 state, class_1937 level, class_2338 pos, class_2680 newState, boolean movedByPiston) {
        class_1264.method_54291(state, newState, level, pos);
        if (!state.method_27852(newState.method_26204())) {
            super.method_9536(state, level, pos, newState, movedByPiston);
            level.method_8455(pos, state.method_26204());
            this.updateNeighborsAfterPoweringDown(level, pos, state);
        }
    }

    @Override
    protected void method_9612(class_2680 state, class_1937 level, class_2338 pos, class_2248 neighborBlock, class_2338 neighborPos, boolean movedByPiston) {
        if (!level.method_8608()) {
            boolean signal = level.method_49803(pos);
            if (state.method_11654(POWERED) != signal) {
                class_2680 newState = state.method_11657(POWERED, signal);
                if (!signal) {
                    newState = newState.method_11657(SIDE_CHAIN_PART, SideChainPart.UNCONNECTED);
                }

                level.method_8652(pos, newState, 3);
                this.playSound(level, pos, signal ? ModSoundEvents.SHELF_ACTIVATE.get() : ModSoundEvents.SHELF_DEACTIVATE.get());
                level.method_43276(signal ? class_5712.field_28174 : class_5712.field_28175, pos, class_5712.class_7397.method_43287(newState));
            }
        }
    }

    @Override @Nullable
    public class_2680 method_9605(class_1750 context) {
        class_3610 replacedFluidState = context.method_8045().method_8316(context.method_8037());
        return this.method_9564()
            .method_11657(FACING, context.method_8042().method_10153())
            .method_11657(POWERED, context.method_8045().method_49803(context.method_8037()))
            .method_11657(WATERLOGGED, replacedFluidState.method_39360(class_3612.field_15910));
    }

    @Override
    protected class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(FACING, rotation.method_10503(state.method_11654(FACING)));
    }

    @Override
    protected class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(FACING)));
    }

    @Override
    protected class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Override
    public int getRows() {
        return 1;
    }

    @Override
    public int getColumns() {
        return 3;
    }
    
    @Override
    protected class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hitResult) {
        if (level.method_8321(pos) instanceof ShelfBlockEntity shelf && !hand.equals(class_1268.field_5810)) {
            OptionalInt hitSlot = this.getHitSlot(hitResult, state.method_11654(FACING));
            if (hitSlot.isEmpty()) {
                return class_9062.field_47731;
            } else {
                class_1661 inventory = player.method_31548();
                if (level.method_8608()) {
                    return inventory.method_7391().method_7960() ? class_9062.field_47731 : class_9062.field_47728;
                } else if (!state.method_11654(POWERED)) {
                    boolean itemRemoved = swapSingleItem(stack, player, shelf, hitSlot.getAsInt(), inventory);
                    if (itemRemoved) {
                        this.playSound(level, pos, stack.method_7960() ? ModSoundEvents.SHELF_TAKE_ITEM.get() : ModSoundEvents.SHELF_SINGLE_SWAP.get());
                    } else {
                        if (stack.method_7960()) {
                            return class_9062.field_47731;
                        }

                        this.playSound(level, pos, ModSoundEvents.SHELF_PLACE_ITEM.get());
                    }

                    return class_9062.field_47728;
                } else {
                    boolean anySwapped = this.swapHotbar(level, pos, inventory);
                    if (!anySwapped) {
                        return class_9062.field_47729;
                    } else {
                        this.playSound(level, pos, ModSoundEvents.SHELF_MULTI_SWAP.get());
                        return class_9062.field_47728;
                    }
                }
            }
        } else {
            return class_9062.field_47731;
        }
    }

    private boolean swapSingleItem(class_1799 stack, class_1657 player, ShelfBlockEntity shelf, int hitSlot, class_1661 inventory) {
        class_1799 removedItem = shelf.swapItemNoUpdate(hitSlot, stack);
        class_1799 newInventoryItem = player.method_56992() && removedItem.method_7960() ? stack.method_7972() : removedItem;
        inventory.method_5447(inventory.field_7545, newInventoryItem);
        inventory.method_5431();
        shelf.setChanged(class_5712.field_28146);
        return !removedItem.method_7960();
    }

    private boolean swapHotbar(class_1937 level, class_2338 pos, class_1661 inventory) {
        List<class_2338> connectedBlocks = this.getAllBlocksConnectedTo(level, pos);
        if (connectedBlocks.isEmpty()) {
            return false;
        } else {
            boolean anySwapped = false;

            for (int shelfPartIndex = 0; shelfPartIndex < connectedBlocks.size(); shelfPartIndex++) {
                ShelfBlockEntity shelfPart = (ShelfBlockEntity) level.method_8321(connectedBlocks.get(shelfPartIndex));
                if (shelfPart != null) {
                    for (int slot = 0; slot < shelfPart.method_5439(); slot++) {
                        int inventorySlot = 9 - (connectedBlocks.size() - shelfPartIndex) * shelfPart.method_5439() + slot;
                        if (inventorySlot >= 0 && inventorySlot <= inventory.method_5439()) {
                            class_1799 placedInventoryItem = inventory.method_5441(inventorySlot);
                            class_1799 removedShelfItem = shelfPart.swapItemNoUpdate(slot, placedInventoryItem);
                            if (!placedInventoryItem.method_7960() || !removedShelfItem.method_7960()) {
                                inventory.method_5447(inventorySlot, removedShelfItem);
                                anySwapped = true;
                            }
                        }
                    }

                    inventory.method_5431();
                    shelfPart.setChanged(class_5712.field_28725);
                }
            }

            return anySwapped;
        }
    }

    @Override
    public SideChainPart getSideChainPart(class_2680 state) {
        return state.method_11654(SIDE_CHAIN_PART);
    }

    @Override
    public class_2680 setSideChainPart(class_2680 state, SideChainPart newPart) {
        return state.method_11657(SIDE_CHAIN_PART, newPart);
    }

    @Override
    public class_2350 getFacing(class_2680 state) {
        return state.method_11654(FACING);
    }

    @Override
    public boolean isConnectable(class_2680 state) {
        return state.method_26164(ModBlockTags.WOODEN_SHELVES) && state.method_28498(POWERED) && state.method_11654(POWERED);
    }

    @Override
    public int getMaxChainLength() {
        return 3;
    }

    @Override
    protected void method_9615(class_2680 state, class_1937 level, class_2338 pos, class_2680 oldState, boolean movedByPiston) {
        if (state.method_11654(POWERED)) {
            this.updateSelfAndNeighborsOnPoweringUp(level, pos, state, oldState);
        } else {
            this.updateNeighborsAfterPoweringDown(level, pos, state);
        }
    }

    private void playSound(class_1936 level, class_2338 pos, class_3414 sound) {
        level.method_8396(null, pos, sound, class_3419.field_15245, 1.0F, 1.0F);
    }

    @Override
    protected class_3610 method_9545(class_2680 state) {
        return state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
    }

    @Override
    protected class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 level, class_2338 pos, class_2338 neighborPos) {
        if (state.method_11654(WATERLOGGED)) {
            level.method_39281(pos, class_3612.field_15910, class_3612.field_15910.method_15789(level));
        }

        return super.method_9559(state, direction, neighborState, level, pos, neighborPos);
    }

    @Override
    protected boolean method_9498(class_2680 state) {
        return true;
    }

    @Override
    protected int method_9572(class_2680 state, class_1937 level, class_2338 pos) {
        if (level.method_8608()) {
            return 0;
        } else if (level.method_8321(pos) instanceof ShelfBlockEntity shelf) {
            int item1Bit = shelf.method_5438(0).method_7960() ? 0 : 1;
            int item2Bit = shelf.method_5438(1).method_7960() ? 0 : 1;
            int item3Bit = shelf.method_5438(2).method_7960() ? 0 : 1;
            return item1Bit | item2Bit << 1 | item3Bit << 2;
        } else {
            return 0;
        }
    }
}