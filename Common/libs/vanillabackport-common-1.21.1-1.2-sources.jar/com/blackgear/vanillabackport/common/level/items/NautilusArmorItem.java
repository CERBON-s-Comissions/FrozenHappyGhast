package com.blackgear.vanillabackport.common.level.items;

import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_2960;
import net.minecraft.class_6880;

public class NautilusArmorItem extends class_1738 {
	private final class_2960 textureLocation;

	public NautilusArmorItem(class_6880<class_1741> material, class_1793 properties) {
		super(material, class_8051.field_48838, properties);
		this.textureLocation = material.method_40230().orElseThrow().method_29177().method_45134( s -> "textures/entity/nautilus/armor/" + s + ".png");
	}

	public class_2960 getTexture() {
		return this.textureLocation;
	}
}
