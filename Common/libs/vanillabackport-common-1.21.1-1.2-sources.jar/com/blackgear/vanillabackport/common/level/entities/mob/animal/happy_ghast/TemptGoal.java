package com.blackgear.vanillabackport.common.level.entities.mob.animal.happy_ghast;

import org.jetbrains.annotations.Nullable;

import java.util.EnumSet;
import java.util.function.Predicate;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1314;
import net.minecraft.class_1335;
import net.minecraft.class_1352;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_4051;

public class TemptGoal extends class_1352 {
    private static final class_4051 TEMP_TARGETING = class_4051.method_36626().method_18418(10.0).method_36627();
    private final class_4051 targetingConditions;
    protected final class_1308 mob;
    protected final double speedModifier;
    private double px;
    private double py;
    private double pz;
    private double pRotX;
    private double pRotY;
    @Nullable protected class_1657 player;
    private int calmDown;
    private boolean isRunning;
    private final Predicate<class_1799> items;
    private final boolean canScare;
    private final double stopDistance;
    private int temptRange = 10;

    public TemptGoal(class_1314 mob, double speedModifier, Predicate<class_1799> items, boolean canScare) {
        this((class_1308)mob, speedModifier, items, canScare, 2.5);
    }

    public TemptGoal(class_1314 mob, double speedModifier, Predicate<class_1799> items, boolean canScare, double stopDistance) {
        this((class_1308)mob, speedModifier, items, canScare, stopDistance);
    }

    public TemptGoal(class_1308 mob, double speedModifier, Predicate<class_1799> items, boolean canScare, double stopDistance) {
        this.mob = mob;
        this.speedModifier = speedModifier;
        this.items = items;
        this.canScare = canScare;
        this.stopDistance = stopDistance;
        this.method_6265(EnumSet.of(class_4134.field_18405, class_4134.field_18406));
        this.targetingConditions = TEMP_TARGETING.method_33335().method_18420(this::shouldFollow);
    }

    @Override
    public boolean method_6264() {
        if (this.calmDown > 0) {
            this.calmDown--;
            return false;
        } else {
            this.player = this.mob.method_37908().method_18462(this.targetingConditions.method_18418(this.temptRange), this.mob);
            return this.player != null;
        }
    }

    private boolean shouldFollow(class_1309 entity) {
        return this.items.test(entity.method_6047()) || this.items.test(entity.method_6079());
    }

    @Override
    public boolean method_6266() {
        if (this.canScare()) {
            if (this.mob.method_5858(this.player) < 36.0) {
                if (this.player.method_5649(this.px, this.py, this.pz) > 0.01) {
                    return false;
                }

                if (Math.abs(this.player.method_36455() - this.pRotX) > 5.0 || Math.abs(this.player.method_36454() - this.pRotY) > 5.0) {
                    return false;
                }
            } else {
                this.px = this.player.method_23317();
                this.py = this.player.method_23318();
                this.pz = this.player.method_23321();
            }

            this.pRotX = this.player.method_36455();
            this.pRotY = this.player.method_36454();
        }

        return this.method_6264();
    }

    protected boolean canScare() {
        return this.canScare;
    }

    @Override
    public void method_6269() {
        this.px = this.player.method_23317();
        this.py = this.player.method_23318();
        this.pz = this.player.method_23321();
        this.isRunning = true;
    }

    @Override
    public void method_6270() {
        this.player = null;
        this.stopNavigation();
        this.calmDown = method_38848(100);
        this.isRunning = false;
    }

    @Override
    public void method_6268() {
        this.mob.method_5988().method_6226(this.player, this.mob.method_5986() + 20, this.mob.method_5978());
        if (this.mob.method_5858(this.player) < this.stopDistance * this.stopDistance) {
            this.stopNavigation();
        } else {
            this.navigateTowards(this.player);
        }
    }

    protected void stopNavigation() {
        this.mob.method_5942().method_6340();
    }

    protected void navigateTowards(class_1657 player) {
        this.mob.method_5942().method_6335(player, this.speedModifier);
    }

    public boolean isRunning() {
        return this.isRunning;
    }

    public TemptGoal setTemptRange(int range) {
        this.temptRange = range;
        return this;
    }

    public static class ForNonPathfinders extends TemptGoal {
        public ForNonPathfinders(class_1308 mob, double speedModifier, Predicate<class_1799> items, boolean canScare, double stopDistance) {
            super(mob, speedModifier, items, canScare, stopDistance);
        }

        @Override
        protected void stopNavigation() {
            this.mob.method_5962().field_6374 = class_1335.class_1336.field_6377;
        }

        @Override
        protected void navigateTowards(class_1657 player) {
            class_243 target = player.method_33571().method_1020(this.mob.method_19538()).method_1021(this.mob.method_59922().method_43058()).method_1019(this.mob.method_19538());
            this.mob.method_5962().method_6239(target.field_1352, target.field_1351, target.field_1350, this.speedModifier);
        }
    }
}