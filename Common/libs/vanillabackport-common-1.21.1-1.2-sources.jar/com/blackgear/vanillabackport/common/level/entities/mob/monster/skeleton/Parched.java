package com.blackgear.vanillabackport.common.level.entities.mob.monster.skeleton;

import com.blackgear.vanillabackport.client.registries.ModSoundEvents;
import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1299;
import net.minecraft.class_1547;
import net.minecraft.class_1665;
import net.minecraft.class_1667;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3414;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import org.jetbrains.annotations.Nullable;

public class Parched extends class_1547 {
    public Parched(class_1299<? extends class_1547> entityType, class_1937 level) {
        super(entityType, level);
    }
    
    @Override
    protected boolean method_5972() {
        return false;
    }
    
    @Override
    protected class_1665 method_6996(class_1799 arrowStack, float velocity, @Nullable class_1799 weapon) {
        class_1665 arrow = super.method_6996(arrowStack, velocity, weapon);
        if (arrow instanceof class_1667 instance) {
            instance.method_7463(new class_1293(class_1294.field_5911, 600));
        }
        
        return arrow;
    }
    
    public static class_5132.class_5133 method_26905() {
        return class_1547.method_26905().method_26868(class_5134.field_23716, 16.0);
    }
    
    @Override
    protected @Nullable class_3414 method_5994() {
        return ModSoundEvents.PARCHED_AMBIENT.get();
    }
    
    @Override
    protected class_3414 method_6011(class_1282 damageSource) {
        return ModSoundEvents.PARCHED_HURT.get();
    }
    
    @Override
    protected class_3414 method_6002() {
        return ModSoundEvents.PARCHED_DEATH.get();
    }
    
    @Override
    protected class_3414 method_6998() {
        return ModSoundEvents.PARCHED_STEP.get();
    }
    
    @Override
    public int method_57078() {
        return 50;
    }
    
    @Override
    public int method_57079() {
        return 70;
    }
    
    @Override
    public boolean method_6049(class_1293 effect) {
        return effect.method_5579() == class_1294.field_5911 || super.method_6049(effect);
    }
}