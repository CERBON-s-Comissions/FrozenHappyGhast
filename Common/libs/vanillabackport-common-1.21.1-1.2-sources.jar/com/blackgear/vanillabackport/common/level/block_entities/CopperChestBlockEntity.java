package com.blackgear.vanillabackport.common.level.block_entities;

import com.blackgear.vanillabackport.common.level.blocks.CopperChestBlock;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlockEntities;
import com.blackgear.vanillabackport.core.mixin.common.access.ChestBlockEntityAccessor;
import com.blackgear.vanillabackport.core.mixin.common.access.ContainerOpenersCounterAccessor;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2281;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2595;
import net.minecraft.class_2680;
import net.minecraft.class_2745;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_5561;

public class CopperChestBlockEntity extends class_2595 {
    public CopperChestBlockEntity(class_2338 pos, class_2680 blockState) {
        super(ModBlockEntities.COPPER_CHEST.get(), pos, blockState);
        class_5561 counter = ((ChestBlockEntityAccessor) this).getOpenersCounter();
        ((ChestBlockEntityAccessor) this).setOpenersCounter(new class_5561() {
            @Override
            protected void method_31681(class_1937 level, class_2338 pos, class_2680 state) {
                if (state.method_26204() instanceof CopperChestBlock chest) {
                    method_11050(level, pos, state, chest.getOpenChestSound());
                }
            }
            
            @Override
            protected void method_31683(class_1937 level, class_2338 pos, class_2680 state) {
                if (state.method_26204() instanceof CopperChestBlock chest) {
                    method_11050(level, pos, state, chest.getCloseChestSound());
                }
            }
            
            @Override
            protected void method_31682(class_1937 level, class_2338 pos, class_2680 state, int count, int openCount) {
                ((ContainerOpenersCounterAccessor) counter).callOpenerCountChanged(level, pos, state, count, openCount);
            }
            
            @Override
            protected boolean method_31679(class_1657 player) {
                return ((ContainerOpenersCounterAccessor) counter).callIsOwnContainer(player);
            }
        });
    }

    static void method_11050(class_1937 level, class_2338 pos, class_2680 state, class_3414 sound) {
        class_2745 type = state.method_11654(class_2281.field_10770);
        if (type != class_2745.field_12574) {
            double x = (double) pos.method_10263() + 0.5;
            double y = (double) pos.method_10264() + 0.5;
            double z = (double) pos.method_10260() + 0.5;
            if (type == class_2745.field_12571) {
                class_2350 direction = class_2281.method_9758(state);
                x += (double) direction.method_10148() * 0.5;
                z += (double) direction.method_10165() * 0.5;
            }
            
            level.method_43128(null, x, y, z, sound, class_3419.field_15245, 0.5F, level.field_9229.method_43057() * 0.1F + 0.9F);
        }
    }
}