package com.blackgear.vanillabackport.common.level.blocks;

import com.blackgear.vanillabackport.client.registries.ModSoundEvents;
import com.blackgear.vanillabackport.core.util.BlockShaper;
import com.mojang.serialization.MapCodec;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1541;
import net.minecraft.class_1542;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2256;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_243;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2758;
import net.minecraft.class_3218;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_4538;
import net.minecraft.class_5819;

public class ShelfMushroomBlock extends class_2383 implements class_2256 {
    public static final MapCodec<ShelfMushroomBlock> CODEC = method_54094(ShelfMushroomBlock::new);
    public static final class_2758 AGE = class_2741.field_12521;
    private static final List<Map<class_2350, class_265>> SHAPES = IntStream.rangeClosed(0, 1).mapToObj(value -> BlockShaper.rotateHorizontal(
        class_259.method_1084(
            BlockShaper.column(10 + value * 4, 7 + value * 3, 1 + value, 3 + value * 2).method_1096(0.0, (8 - value * 2) / 16.0, -(value * 1.5 - 4.5) / 16.0).method_1097(),
            BlockShaper.column(6 + value * 2, 4 + value * 2, 0.0, 1 + value).method_1096(0.0, (8 - value * 2) / 16.0, -(value - 6) / 16.0).method_1097()
        )
    )).toList();
    
    public ShelfMushroomBlock(class_2251 properties) {
        super(properties);
        this.method_9590(this.method_9595().method_11664().method_11657(field_11177, class_2350.field_11043).method_11657(AGE, 0));
    }
    
    @Override
    protected boolean method_9558(class_2680 state, class_4538 level, class_2338 pos) {
        class_2350 facing = state.method_11654(field_11177);
        class_2338 supportPos = pos.method_10093(facing.method_10153());
        class_2680 supportState = level.method_8320(supportPos);
        return supportState.method_26206(level, supportPos, facing);
    }
    
    @Override
    protected class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return SHAPES.get(state.method_11654(AGE)).get(state.method_11654(field_11177));
    }
    
    @Override
    public @Nullable class_2680 method_9605(class_1750 context) {
        class_2680 state = this.method_9564();
        class_4538 level = context.method_8045();
        class_2338 pos = context.method_8037();
        
        for (class_2350 direction : context.method_7718()) {
            if (direction.method_10166().method_10179()) {
                state = state.method_11657(field_11177, direction.method_10153());
                if (state.method_26184(level, pos)) {
                    return state;
                }
            }
        }
        
        return null;
    }
    
    @Override
    public void method_9554(class_1937 level, class_2680 state, class_2338 pos, class_1297 entity, float fallDistance) {
        super.method_9554(level, state, pos, entity, fallDistance * 0.5F);
    }
    
    @Override
    public void method_9502(class_1922 level, class_1297 entity) {
        if (entity.method_21750()) {
            super.method_9502(level, entity);
        } else {
            this.bounceUp(entity);
        }
    }
    
    private void bounceUp(class_1297 entity) {
        class_243 restitution = entity.method_18798();
        if (restitution.field_1351 < 0.0) {
            double bounciness = entity instanceof class_1309 ? 1.0 : 0.8;
            entity.method_18800(restitution.field_1352, -restitution.field_1351 * 0.75 * bounciness, restitution.field_1350);
            if (!entity.method_37908().field_9236 && restitution.field_1351 < -0.1) {
                if (!(entity instanceof class_1542) && !(entity instanceof class_1541)) {
                    entity.method_37908().method_45447(
                        null,
                        entity.method_24515(),
                        ModSoundEvents.SHELF_MUSHROOM_BOUNCE.get(),
                        class_3419.field_15245
                    );
                }
            }
        }
    }
    
    @Override
    protected class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 level, class_2338 pos, class_2338 neighborPos) {
        return direction == state.method_11654(field_11177).method_10153() && !state.method_26184(level, pos)
            ? class_2246.field_10124.method_9564()
            : super.method_9559(state, direction, neighborState, level, pos, neighborPos);
    }
    
    @Override
    public boolean method_9651(class_4538 level, class_2338 pos, class_2680 state) {
        return state.method_11654(AGE) < 1;
    }
    
    @Override
    public boolean method_9650(class_1937 level, class_5819 random, class_2338 pos, class_2680 state) {
        return true;
    }
    
    @Override
    public void method_9652(class_3218 level, class_5819 random, class_2338 pos, class_2680 state) {
        level.method_8652(pos, state.method_11657(AGE, state.method_11654(AGE) + 1), 2);
    }
    
    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(field_11177, AGE);
    }
    
    @Override
    protected MapCodec<? extends class_2383> method_53969() {
        return field_46280;
    }
}