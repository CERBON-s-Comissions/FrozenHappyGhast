package com.blackgear.vanillabackport.common.level.components;

import com.blackgear.vanillabackport.common.api.extensions.SoundExtensions;
import com.blackgear.vanillabackport.common.api.extensions.entity.movement.MotionAwareEntity;
import com.blackgear.vanillabackport.common.api.extensions.entity.spear.MobSpearHandler;
import com.blackgear.vanillabackport.common.registries.ModCriteriaTriggers;
import com.blackgear.vanillabackport.common.registries.items.ModDataComponents;
import com.blackgear.vanillabackport.core.util.AdditionalCodecs;
import com.blackgear.vanillabackport.core.util.ProjectileUtils;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.netty.buffer.ByteBuf;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1508;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3966;
import net.minecraft.class_5134;
import net.minecraft.class_5699;
import net.minecraft.class_6880;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record KineticWeapon(
    int contactCooldownTicks,
    int delayTicks,
    Optional<Condition> dismountConditions,
    Optional<Condition> knockbackConditions,
    Optional<Condition> damageConditions,
    float forwardMovement,
    float damageMultiplier,
    Optional<class_6880<class_3414>> sound,
    Optional<class_6880<class_3414>> hitSound
) {
    public static final Codec<KineticWeapon> CODEC = RecordCodecBuilder.create(instance -> instance.group(
        class_5699.field_33441.optionalFieldOf("contact_cooldown_ticks", 10).forGetter(KineticWeapon::contactCooldownTicks),
        class_5699.field_33441.optionalFieldOf("delay_ticks", 0).forGetter(KineticWeapon::delayTicks),
        Condition.CODEC.optionalFieldOf("dismount_conditions").forGetter(KineticWeapon::dismountConditions),
        Condition.CODEC.optionalFieldOf("knockback_conditions").forGetter(KineticWeapon::knockbackConditions),
        Condition.CODEC.optionalFieldOf("damage_conditions").forGetter(KineticWeapon::damageConditions),
        Codec.FLOAT.optionalFieldOf("forward_movement", 0.0F).forGetter(KineticWeapon::forwardMovement),
        Codec.FLOAT.optionalFieldOf("damage_multiplier", 1.0F).forGetter(KineticWeapon::damageMultiplier),
        class_3414.field_41699.optionalFieldOf("sound").forGetter(KineticWeapon::sound),
        class_3414.field_41699.optionalFieldOf("hit_sound").forGetter(KineticWeapon::hitSound)
    ).apply(instance, KineticWeapon::new));

    public static final class_9139<class_9129, KineticWeapon> STREAM_CODEC = AdditionalCodecs.composite(
        class_9135.field_48550, KineticWeapon::contactCooldownTicks,
        class_9135.field_48550, KineticWeapon::delayTicks,
        Condition.STREAM_CODEC.method_56433(class_9135::method_56382), KineticWeapon::dismountConditions,
        Condition.STREAM_CODEC.method_56433(class_9135::method_56382), KineticWeapon::knockbackConditions,
        Condition.STREAM_CODEC.method_56433(class_9135::method_56382), KineticWeapon::damageConditions,
        class_9135.field_48552, KineticWeapon::forwardMovement,
        class_9135.field_48552, KineticWeapon::damageMultiplier,
        class_3414.field_48279.method_56433(class_9135::method_56382), KineticWeapon::sound,
        class_3414.field_48279.method_56433(class_9135::method_56382), KineticWeapon::hitSound,
        KineticWeapon::new
    );

    public static class_243 getMotion(class_1297 entity) {
        if (!(entity instanceof class_1657) && entity.method_5765()) {
            entity = entity.method_5668();
        }

        return ((MotionAwareEntity) entity).getKnownSpeed().method_1021(20.0);
    }

    public void makeSound(class_1297 causer) {
        this.sound.ifPresent(sound -> ((SoundExtensions) causer.method_37908()).playSound(causer, causer.method_23317(), causer.method_23318(), causer.method_23321(), sound, causer.method_5634(), 1.0F, 1.0F));
    }

    public void makeLocalHitSound(class_1297 causer) {
        this.hitSound.ifPresent(sound -> causer.method_37908().method_55116(causer, sound.comp_349(), causer.method_5634(), 1.0F, 1.0F));
    }

    public int computeDamageUseDuration() {
        return this.delayTicks + this.damageConditions.map(Condition::maxDurationTicks).orElse(0);
    }

    public void damageEntities(class_1799 stack, int ticksRemaining, class_1309 attacker, class_1304 equipmentSlot) {
        MobSpearHandler handler = (MobSpearHandler) attacker;
        int ticksUsed = stack.method_7935(attacker) - ticksRemaining;
        if (ticksUsed >= this.delayTicks) {
            ticksUsed -= this.delayTicks;
            class_243 attackerLookVector = attacker.method_5720();
            double attackerSpeedProjection = attackerLookVector.method_1026(getMotion(attacker));
            float actionFactor = attacker instanceof class_1657 ? 1.0F : 0.2F;
            AttackRange attackRange = handler.vb$getAttackRangeWith(stack);
            double baseMobDamage = attacker.method_45326(class_5134.field_23721);
            boolean affected = false;

            Collection<class_3966> hitResults = ProjectileUtils.getHitEntitiesAlong(attacker, attackRange, e -> PiercingWeapon.canHitEntity(attacker, e), class_3959.class_3960.field_17558).map(a -> List.of(), e -> e);
            for (class_3966 hitResult : hitResults) {
                class_1297 otherEntity = hitResult.method_17782();
                if (otherEntity instanceof class_1508 part) {
                    otherEntity = part.field_7007;
                }

                boolean wasStabbed = handler.vb$wasRecentlyStabbed(otherEntity, this.contactCooldownTicks);
                if (!wasStabbed) {
                    handler.vb$rememberStabbedEntity(otherEntity);
                    double targetSpeedProjection = attackerLookVector.method_1026(getMotion(otherEntity));
                    double relativeSpeed = Math.max(0.0, attackerSpeedProjection - targetSpeedProjection);
                    boolean dealsDismount = this.dismountConditions.isPresent() && this.dismountConditions.get().test(ticksUsed, attackerSpeedProjection, relativeSpeed, actionFactor);
                    boolean dealsKnockback = this.knockbackConditions.isPresent() && this.knockbackConditions.get().test(ticksUsed, attackerSpeedProjection, relativeSpeed, actionFactor);
                    boolean dealsDamage = this.damageConditions.isPresent() && this.damageConditions.get().test(ticksUsed, attackerSpeedProjection, relativeSpeed, actionFactor);
                    if (dealsDismount || dealsKnockback || dealsDamage) {
                        float damageDealt = (float) baseMobDamage + class_3532.method_15357(relativeSpeed * this.damageMultiplier);
                        affected |= handler.vb$stabAttack(equipmentSlot, otherEntity, damageDealt, dealsDamage, dealsKnockback, dealsDismount);
                    }
                }
            }

            if (affected) {
                attacker.method_37908().method_8421(attacker, (byte) 2);
                if (attacker instanceof class_3222 player) {
                    ModCriteriaTriggers.SPEAR_MOBS_TRIGGER.get().trigger(player, handler.vb$stabbedEntities(entity -> entity instanceof class_1309));
                }
            }
        }
    }
    
    @SuppressWarnings("unchecked")
    public static KineticWeapon get(class_1799 stack) {
        Object component = stack.method_57824(ModDataComponents.KINETIC_WEAPON.get());
        
        if (component == null) return null;
        if (component instanceof KineticWeapon weapon) return weapon;
        
        try {
            Class<?> clazz = component.getClass();
            
            int contactCooldownTicks = (int) clazz.getMethod("contactCooldownTicks").invoke(component);
            int delayTicks = (int) clazz.getMethod("delayTicks").invoke(component);
            
            Optional<Condition> dismountConditions = convertConditionOpt(clazz.getMethod("dismountConditions").invoke(component));
            Optional<Condition> knockbackConditions = convertConditionOpt(clazz.getMethod("knockbackConditions").invoke(component));
            Optional<Condition> damageConditions = convertConditionOpt(clazz.getMethod("damageConditions").invoke(component));
            
            float forwardMovement = (float) clazz.getMethod("forwardMovement").invoke(component);
            float damageMultiplier = (float) clazz.getMethod("damageMultiplier").invoke(component);
            
            Optional<class_6880<class_3414>> sound = (Optional<class_6880<class_3414>>) clazz.getMethod("sound").invoke(component);
            Optional<class_6880<class_3414>> hitSound = (Optional<class_6880<class_3414>>) clazz.getMethod("hitSound").invoke(component);
            
            return new KineticWeapon(
                contactCooldownTicks,
                delayTicks,
                dismountConditions,
                knockbackConditions,
                damageConditions,
                forwardMovement,
                damageMultiplier,
                sound,
                hitSound
            );
        } catch (Exception e) {
            return null;
        }
    }
    
    private static Optional<Condition> convertConditionOpt(Object optRaw) {
        if (!(optRaw instanceof Optional<?> opt) || opt.isEmpty()) {
            return Optional.empty();
        }
        
        Object rawCond = opt.get();
        if (rawCond instanceof Condition cond) {
            return Optional.of(cond);
        }
        
        try {
            Class<?> condClass = rawCond.getClass();
            int maxDurationTicks = (int) condClass.getMethod("maxDurationTicks").invoke(rawCond);
            float minSpeed = (float) condClass.getMethod("minSpeed").invoke(rawCond);
            float minRelativeSpeed = (float) condClass.getMethod("minRelativeSpeed").invoke(rawCond);
            
            return Optional.of(new Condition(maxDurationTicks, minSpeed, minRelativeSpeed));
        } catch (Exception e) {
            return Optional.empty();
        }
    }
    
    public record Condition(
        int maxDurationTicks,
        float minSpeed,
        float minRelativeSpeed)
    {
        public static final Codec<Condition> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            class_5699.field_33441.fieldOf("max_duration_ticks").forGetter(Condition::maxDurationTicks),
            Codec.FLOAT.optionalFieldOf("min_speed", 0.0F).forGetter(Condition::minSpeed),
            Codec.FLOAT.optionalFieldOf("min_relative_speed", 0.0F).forGetter(Condition::minRelativeSpeed)
        ).apply(instance, Condition::new));

        public static final class_9139<ByteBuf, Condition> STREAM_CODEC = class_9139.method_56436(
            class_9135.field_48550, Condition::maxDurationTicks,
            class_9135.field_48552, Condition::minSpeed,
            class_9135.field_48552, Condition::minRelativeSpeed,
            Condition::new
        );

        public boolean test(int ticksUsed, double attackerSpeed, double relativeSpeed, double entityFactor) {
            return ticksUsed <= this.maxDurationTicks && attackerSpeed >= this.minSpeed * entityFactor && relativeSpeed >= this.minRelativeSpeed * entityFactor;
        }

        public static Optional<Condition> ofAttackerSpeed(int untilTicks, float minAttackerSpeed) {
            return Optional.of(new Condition(untilTicks, minAttackerSpeed, 0.0F));
        }

        public static Optional<Condition> ofRelativeSpeed(int untilTicks, float minRelativeSpeed) {
            return Optional.of(new Condition(untilTicks, 0.0F, minRelativeSpeed));
        }
    }
}