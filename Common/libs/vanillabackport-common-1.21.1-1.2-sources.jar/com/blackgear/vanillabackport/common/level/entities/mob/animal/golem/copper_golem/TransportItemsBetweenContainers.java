package com.blackgear.vanillabackport.common.level.entities.mob.animal.golem.copper_golem;

import com.blackgear.vanillabackport.common.level.entities.mob.animal.golem.copper_golem.container.ContainerManager;
import com.blackgear.vanillabackport.common.registries.entities.ModMemoryModuleTypes;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.blackgear.vanillabackport.core.mixin.common.access.BaseContainerBlockEntityAccessor;
import com.google.common.collect.ImmutableMap;
import org.apache.logging.log4j.util.TriConsumer;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Stream;
import net.minecraft.class_11;
import net.minecraft.class_1263;
import net.minecraft.class_1273;
import net.minecraft.class_1304;
import net.minecraft.class_1314;
import net.minecraft.class_1799;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2281;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_2624;
import net.minecraft.class_2680;
import net.minecraft.class_2745;
import net.minecraft.class_2818;
import net.minecraft.class_3218;
import net.minecraft.class_3959;
import net.minecraft.class_4097;
import net.minecraft.class_4099;
import net.minecraft.class_4140;
import net.minecraft.class_4141;
import net.minecraft.class_4208;
import net.minecraft.class_4215;

public class TransportItemsBetweenContainers extends class_4097<class_1314> {
    private final float speedModifier;
    private final int horizontalSearchDistance;
    private final int verticalSearchDistance;
    private final Predicate<class_2680> sourceBlockType;
    private final Predicate<class_2680> destinationBlockType;
    private final Predicate<TransportItemTarget> shouldQueueForTarget;
    private final Consumer<class_1314> onStartTravelling;
    private final Map<ContainerInteractionState, OnTargetReachedInteraction> onTargetInteractionActions;
    @Nullable private TransportItemTarget target = null;
    private TransportItemState state = TransportItemState.TRAVELLING;
    @Nullable private ContainerInteractionState interactionState;
    private int ticksSinceReachingTarget;

    public TransportItemsBetweenContainers(
        float speedModifier,
        Predicate<class_2680> sourceBlockType,
        Predicate<class_2680> destinationBlockType,
        int horizontalSearchDistance,
        int verticalSearchDistance,
        Map<ContainerInteractionState, OnTargetReachedInteraction> onTargetInteractionActions,
        Consumer<class_1314> onStartTravelling,
        Predicate<TransportItemTarget> shouldQueueForTarget
    ) {
        super(
            ImmutableMap.of(
                ModMemoryModuleTypes.VISITED_BLOCK_POSITIONS.get(), class_4141.field_18458,
                ModMemoryModuleTypes.UNREACHABLE_TRANSPORT_BLOCK_POSITIONS.get(), class_4141.field_18458,
                ModMemoryModuleTypes.TRANSPORT_ITEMS_COOLDOWN_TICKS.get(), class_4141.field_18457,
                class_4140.field_39408, class_4141.field_18457
            )
        );
        this.speedModifier = speedModifier;
        this.horizontalSearchDistance = horizontalSearchDistance;
        this.verticalSearchDistance = verticalSearchDistance;
        this.sourceBlockType = sourceBlockType;
        this.destinationBlockType = destinationBlockType;
        this.shouldQueueForTarget = shouldQueueForTarget;
        this.onStartTravelling = onStartTravelling;
        this.onTargetInteractionActions = onTargetInteractionActions;
    }

    @Override
    protected void start(class_3218 level, class_1314 entity, long gameTime) {
        if (entity.method_5942() instanceof CopperGolemPathNavigation navigation) {
            navigation.setCanPathToTargetsBelowSurface(true);
        }
    }

    @Override
    protected boolean checkExtraStartConditions(class_3218 level, class_1314 entity) {
        return !entity.method_60953();
    }

    @Override
    protected boolean canStillUse(class_3218 level, class_1314 entity, long gameTime) {
        return entity.method_18868().method_18904(ModMemoryModuleTypes.TRANSPORT_ITEMS_COOLDOWN_TICKS.get()).isEmpty() && !entity.method_52546() && !entity.method_60953();
    }

    @Override
    protected boolean method_18915(long gameTime) {
        return false;
    }

    @Override
    protected void tick(class_3218 level, class_1314 entity, long gameTime) {
        boolean updatedInvalidTarget = this.updateInvalidTarget(level, entity);
        if (this.target == null) {
            this.stop(level, entity, gameTime);
        } else if (!updatedInvalidTarget) {
            if (this.state.equals(TransportItemState.QUEUING)) {
                this.onQueuingForTarget(this.target, level, entity);
            }

            if (this.state.equals(TransportItemState.TRAVELLING)) {
                this.onTravelToTarget(this.target, level, entity);
            }

            if (this.state.equals(TransportItemState.INTERACTING)) {
                this.onReachedTarget(this.target, level, entity);
            }
        }
    }

    private boolean updateInvalidTarget(class_3218 level, class_1314 entity) {
        if (!this.hasValidTarget(level, entity)) {
            this.stopTargetingCurrentTarget(entity);
            Optional<TransportItemTarget> targetBlockPosition = this.getTransportTarget(level, entity);
            if (targetBlockPosition.isPresent()) {
                this.target = targetBlockPosition.get();
                this.onStartTravelling(entity);
                this.setVisitedBlockPos(entity, level, this.target.pos);
            } else {
                this.enterCooldownAfterNoMatchingTargetFound(entity);
            }

            return true;
        } else {
            return false;
        }
    }

    private void onQueuingForTarget(TransportItemTarget target, class_1937 level, class_1314 entity) {
        if (!this.isAnotherMobInteractingWithTarget(target, level)) {
            this.resumeTravelling(entity);
        }
    }

    private void onTravelToTarget(TransportItemTarget target, class_1937 level, class_1314 entity) {
        if (this.isWithinTargetDistance(3.0, target, level, entity, this.getCenterPos(entity)) && this.isAnotherMobInteractingWithTarget(target, level)) {
            this.startQueuing(entity);
        } else if (this.isWithinTargetDistance(getInteractionRange(entity), target, level, entity, this.getCenterPos(entity))) {
            this.startOnReachedTargetInteraction(target, entity);
        } else {
            this.walkTowardsTarget(entity);
        }
    }

    private class_243 getCenterPos(class_1314 entity) {
        return this.setMiddleYPosition(entity, entity.method_19538());
    }

    private void onReachedTarget(TransportItemTarget target, class_1937 level, class_1314 entity) {
        if (!this.isWithinTargetDistance(2.0, target, level, entity, this.getCenterPos(entity))) {
            this.onStartTravelling(entity);
        } else {
            this.ticksSinceReachingTarget++;
            this.onTargetInteraction(target, entity);
            if (this.ticksSinceReachingTarget >= 60) {
                this.doReachedTargetInteraction(
                    entity,
                    target.container,
                    this::pickUpItems,
                    (mob, container) -> this.stopTargetingCurrentTarget(entity),
                    this::putDownItem,
                    (mob, container) -> this.stopTargetingCurrentTarget(entity)
                );
                this.onStartTravelling(entity);
            }
        }
    }

    private void startQueuing(class_1314 entity) {
        this.stopInPlace(entity);
        this.setTransportingState(TransportItemState.QUEUING);
    }

    private void resumeTravelling(class_1314 entity) {
        this.setTransportingState(TransportItemState.TRAVELLING);
        this.walkTowardsTarget(entity);
    }

    private void walkTowardsTarget(class_1314 entity) {
        if (this.target != null) {
            class_4215.method_24561(entity, this.target.pos, this.speedModifier, 0);
        }
    }

    private void startOnReachedTargetInteraction(TransportItemTarget target, class_1314 entity) {
        this.doReachedTargetInteraction(
            entity,
            target.container,
            this.onReachedInteraction(ContainerInteractionState.PICKUP_ITEM),
            this.onReachedInteraction(ContainerInteractionState.PICKUP_NO_ITEM),
            this.onReachedInteraction(ContainerInteractionState.PLACE_ITEM),
            this.onReachedInteraction(ContainerInteractionState.PLACE_NO_ITEM)
        );
        this.setTransportingState(TransportItemState.INTERACTING);
    }

    private void onStartTravelling(class_1314 entity) {
        this.onStartTravelling.accept(entity);
        this.setTransportingState(TransportItemState.TRAVELLING);
        this.interactionState = null;
        this.ticksSinceReachingTarget = 0;
    }

    private BiConsumer<class_1314, class_1263> onReachedInteraction(ContainerInteractionState state) {
        return (mob, container) -> this.setInteractionState(state);
    }

    private void setTransportingState(TransportItemState state) {
        this.state = state;
    }

    private void setInteractionState(ContainerInteractionState state) {
        this.interactionState = state;
    }

    private void onTargetInteraction(TransportItemTarget target, class_1314 entity) {
        entity.method_18868().method_18878(class_4140.field_18446, new class_4099(target.pos));
        this.stopInPlace(entity);
        if (this.interactionState != null) {
            Optional.ofNullable(this.onTargetInteractionActions.get(this.interactionState))
                .ifPresent(action -> action.accept(entity, target, this.ticksSinceReachingTarget));
        }
    }

    private void doReachedTargetInteraction(
        class_1314 entity,
        class_1263 container,
        BiConsumer<class_1314, class_1263> onPickupSuccess,
        BiConsumer<class_1314, class_1263> onPickupFailure,
        BiConsumer<class_1314, class_1263> onPlaceSuccess,
        BiConsumer<class_1314, class_1263> onPlaceFailure
    ) {
        if (isPickingUpItems(entity)) {
            if (matchesGettingItemsRequirement(container)) {
                onPickupSuccess.accept(entity, container);
            } else {
                onPickupFailure.accept(entity, container);
            }
        } else if (matchesLeavingItemsRequirement(entity, container)) {
            onPlaceSuccess.accept(entity, container);
        } else {
            onPlaceFailure.accept(entity, container);
        }
    }

    private Optional<TransportItemTarget> getTransportTarget(class_3218 level, class_1314 entity) {
        class_238 targetBlockSearchArea = this.getTargetSearchArea(entity);
        Set<class_4208> visitedPositions = getVisitedPositions(entity);
        Set<class_4208> unreachablePositions = getUnreachablePositions(entity);
        List<class_1923> chunkPositions = class_1923.method_19280(new class_1923(entity.method_24515()), Math.floorDiv(this.getHorizontalSearchDistance(entity), 16) + 1).toList();
        TransportItemTarget target = null;
        double closestDistance = Float.MAX_VALUE;

        for (class_1923 chunkPos : chunkPositions) {
            class_2818 levelChunk = level.method_14178().method_21730(chunkPos.field_9181, chunkPos.field_9180);
            if (levelChunk != null) {
                for (class_2586 potentialTarget : levelChunk.method_12214().values()) {
                    if (potentialTarget instanceof class_1263) {
                        double distance = potentialTarget.method_11016().method_19770(entity.method_19538());
                        if (distance < closestDistance) {
                            TransportItemTarget targetValidToPick = this.isTargetValidToPick(entity, level, potentialTarget, visitedPositions, unreachablePositions, targetBlockSearchArea);
                            if (targetValidToPick != null) {
                                target = targetValidToPick;
                                closestDistance = distance;
                            }
                        }
                    }
                }
            }
        }

        return target == null ? Optional.empty() : Optional.of(target);
    }

    @Nullable
    private TransportItemTarget isTargetValidToPick(
        class_1314 entity,
        class_1937 level,
        class_2586 blockEntity,
        Set<class_4208> visitedPositions,
        Set<class_4208> unreachablePositions,
        class_238 targetBlockSearchArea
    ) {
        class_2338 blockPos = blockEntity.method_11016();
        boolean isWithinSearchArea = targetBlockSearchArea.method_1008(blockPos.method_10263(), blockPos.method_10264(), blockPos.method_10260());
        if (!isWithinSearchArea) {
            return null;
        } else {
            TransportItemTarget transportItemTarget = TransportItemTarget.tryCreatePossibleTarget(blockEntity, level);
            if (transportItemTarget == null) {
                return null;
            } else {
                boolean isValidTarget = this.isWantedBlock(entity, transportItemTarget.state)
                    && !this.isPositionAlreadyVisited(visitedPositions, unreachablePositions, transportItemTarget, level)
                    && !this.isContainerLocked(transportItemTarget);
                return isValidTarget ? transportItemTarget : null;
            }
        }
    }

    private boolean isContainerLocked(TransportItemTarget target) {
        return target.blockEntity instanceof class_2624 container && !((BaseContainerBlockEntityAccessor) container).getLockKey().equals(class_1273.field_5817);
    }

    private boolean hasValidTarget(class_1937 level, class_1314 entity) {
        boolean targetIsOfValidType = this.target != null && this.isWantedBlock(entity, this.target.state) && this.targetHasNotChanged(level, this.target);
        if (targetIsOfValidType && !this.isTargetBlocked(level, this.target)) {
            if (!this.state.equals(TransportItemState.TRAVELLING)) {
                return true;
            }

            if (this.hasValidTravellingPath(level, this.target, entity)) {
                return true;
            }

            this.markVisitedBlockPosAsUnreachable(entity, level, this.target.pos);
        }

        return false;
    }

    private boolean hasValidTravellingPath(class_1937 level, TransportItemTarget target, class_1314 entity) {
        class_11 path = entity.method_5942().method_6345() != null ? entity.method_5942().method_6345() : entity.method_5942().method_6348(target.pos, 0);
        class_243 posFromWhichToReachTarget = this.getPositionToReachTargetFrom(path, entity);
        boolean canReachTarget = this.isWithinTargetDistance(getInteractionRange(entity), target, level, entity, posFromWhichToReachTarget);
        boolean hasNotYetCreatedPathToTarget = path == null && !canReachTarget;
        return hasNotYetCreatedPathToTarget || this.targetIsReachableFromPosition(level, canReachTarget, posFromWhichToReachTarget, target, entity);
    }

    private class_243 getPositionToReachTargetFrom(@Nullable class_11 path, class_1314 entity) {
        boolean haveNoValidPath = path == null || path.method_45() == null;
        class_243 bottomCenter = haveNoValidPath ? entity.method_19538() : path.method_45().method_22879().method_61082();
        return this.setMiddleYPosition(entity, bottomCenter);
    }

    private class_243 setMiddleYPosition(class_1314 entity, class_243 pos) {
        return pos.method_1031(0.0, entity.method_5829().method_17940() / 2.0, 0.0);
    }

    private boolean isTargetBlocked(class_1937 level, TransportItemTarget target) {
        return target.blockEntity() instanceof class_2595 && class_2281.method_9756(level, target.pos);
    }

    private boolean targetHasNotChanged(class_1937 level, TransportItemTarget target) {
        return target.blockEntity.equals(level.method_8321(target.pos));
    }

    private Stream<TransportItemTarget> getConnectedTargets(TransportItemTarget target, class_1937 level) {
        if (target.state.method_26204() instanceof class_2281 && target.state.method_28500(class_2281.field_10770).orElse(class_2745.field_12569) != class_2745.field_12569) {
            TransportItemTarget connectedTarget = TransportItemTarget.tryCreatePossibleTarget(ContainerManager.getConnectedBlockPos(target.pos, target.state), level);
            return connectedTarget != null ? Stream.of(target, connectedTarget) : Stream.of(target);
        } else {
            return Stream.of(target);
        }
    }

    private class_238 getTargetSearchArea(class_1314 entity) {
        int horizontalSearchDistance = this.getHorizontalSearchDistance(entity);
        return new class_238(entity.method_24515()).method_1009(horizontalSearchDistance, this.getVerticalSearchDistance(entity), horizontalSearchDistance);
    }

    private int getHorizontalSearchDistance(class_1314 entity) {
        return entity.method_5765() ? 1 : this.horizontalSearchDistance;
    }

    private int getVerticalSearchDistance(class_1314 entity) {
        return entity.method_5765() ? 1 : this.verticalSearchDistance;
    }

    private static Set<class_4208> getVisitedPositions(class_1314 entity) {
        return entity.method_18868().method_18904(ModMemoryModuleTypes.VISITED_BLOCK_POSITIONS.get()).orElse(Set.of());
    }

    private static Set<class_4208> getUnreachablePositions(class_1314 entity) {
        return entity.method_18868().method_18904(ModMemoryModuleTypes.UNREACHABLE_TRANSPORT_BLOCK_POSITIONS.get()).orElse(Set.of());
    }

    private boolean isPositionAlreadyVisited(
        Set<class_4208> visitedPositions,
        Set<class_4208> unreachablePositions,
        TransportItemTarget target,
        class_1937 level
    ) {
        return this.getConnectedTargets(target, level)
            .map(transportItemTarget -> class_4208.method_19443(level.method_27983(), transportItemTarget.pos))
            .anyMatch(pos -> visitedPositions.contains(pos) || unreachablePositions.contains(pos));
    }

    private static boolean hasFinishedPath(class_1314 entity) {
        return entity.method_5942().method_6345() != null && entity.method_5942().method_6345().method_46();
    }

    private void setVisitedBlockPos(class_1314 entity, class_1937 level, class_2338 target) {
        Set<class_4208> visitedPositions = new HashSet<>(getVisitedPositions(entity));
        visitedPositions.add(class_4208.method_19443(level.method_27983(), target));
        if (visitedPositions.size() > 10) {
            this.enterCooldownAfterNoMatchingTargetFound(entity);
        } else {
            entity.method_18868().method_24525(ModMemoryModuleTypes.VISITED_BLOCK_POSITIONS.get(), visitedPositions, 6000L);
        }
    }

    private void markVisitedBlockPosAsUnreachable(class_1314 entity, class_1937 level, class_2338 target) {
        Set<class_4208> visitedPositions = new HashSet<>(getVisitedPositions(entity));
        visitedPositions.remove(class_4208.method_19443(level.method_27983(), target));
        Set<class_4208> unreachablePositions = new HashSet<>(getUnreachablePositions(entity));
        unreachablePositions.add(class_4208.method_19443(level.method_27983(), target));
        if (unreachablePositions.size() > 50) {
            this.enterCooldownAfterNoMatchingTargetFound(entity);
        } else {
            entity.method_18868().method_24525(ModMemoryModuleTypes.VISITED_BLOCK_POSITIONS.get(), visitedPositions, 6000L);
            entity.method_18868().method_24525(ModMemoryModuleTypes.UNREACHABLE_TRANSPORT_BLOCK_POSITIONS.get(), unreachablePositions, 6000L);
        }
    }

    private boolean isWantedBlock(class_1314 entity, class_2680 block) {
        return isPickingUpItems(entity) ? this.sourceBlockType.test(block) : this.destinationBlockType.test(block);
    }

    private static double getInteractionRange(class_1314 entity) {
        return hasFinishedPath(entity) ? 1.0 : 0.5;
    }

    private boolean isWithinTargetDistance(double distance, TransportItemTarget target, class_1937 level, class_1314 entity, class_243 fromPos) {
        class_238 boundingBox = entity.method_5829();
        class_238 movedBoundBox = class_238.method_30048(fromPos, boundingBox.method_17939(), boundingBox.method_17940(), boundingBox.method_17941());
        return target.state.method_26220(level, target.pos).method_1107().method_1009(distance, 0.5, distance).method_996(target.pos).method_994(movedBoundBox);
    }

    private boolean targetIsReachableFromPosition(class_1937 level, boolean canReachTarget, class_243 pos, TransportItemTarget target, class_1314 entity) {
        return canReachTarget && this.canSeeAnyTargetSide(target, level, entity, pos);
    }

    private boolean canSeeAnyTargetSide(TransportItemTarget target, class_1937 level, class_1314 entity, class_243 eyePosition) {
        class_243 center = target.pos.method_46558();
        return class_2350.method_42013()
            .map(direction -> center.method_1031(0.5 * direction.method_10148(), 0.5 * direction.method_10164(), 0.5 * direction.method_10165()))
            .map(hitTarget -> level.method_17742(new class_3959(eyePosition, hitTarget, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, entity)))
            .anyMatch(hitResult -> hitResult.method_17783() == class_239.class_240.field_1332 && hitResult.method_17777().equals(target.pos));
    }

    private boolean isAnotherMobInteractingWithTarget(TransportItemTarget target, class_1937 level) {
        return this.getConnectedTargets(target, level).anyMatch(this.shouldQueueForTarget);
    }

    private static boolean isPickingUpItems(class_1314 entity) {
        return entity.method_6047().method_7960();
    }

    private static boolean matchesGettingItemsRequirement(class_1263 container) {
        return !container.method_5442();
    }

    private static boolean matchesLeavingItemsRequirement(class_1314 entity, class_1263 container) {
        return container.method_5442() || hasItemMatchingHandItem(entity, container);
    }

    private static boolean hasItemMatchingHandItem(class_1314 entity, class_1263 container) {
        class_1799 mainHandItem = entity.method_6047();

        for (int i = 0; i < container.method_5439(); i++) {
            class_1799 itemStack = container.method_5438(i);
            if (class_1799.method_7984(itemStack, mainHandItem)) {
                return true;
            }
        }

        return false;
    }

    private void pickUpItems(class_1314 entity, class_1263 container) {
        entity.method_5673(class_1304.field_6173, pickupItemFromContainer(container));
        entity.method_25939(class_1304.field_6173);
        container.method_5431();
        this.clearMemoriesAfterMatchingTargetFound(entity);
    }

    private void putDownItem(class_1314 entity, class_1263 container) {
        class_1799 itemsLeftAfterVisitingChest = addItemsToContainer(entity, container);
        container.method_5431();
        entity.method_5673(class_1304.field_6173, itemsLeftAfterVisitingChest);
        if (itemsLeftAfterVisitingChest.method_7960()) {
            this.clearMemoriesAfterMatchingTargetFound(entity);
        } else {
            this.stopTargetingCurrentTarget(entity);
        }
    }

    private class_1799 pickupItemFromContainer(class_1263 container) {
        int slot = 0;

        for (int i = 0; i < container.method_5439(); i++) {
            class_1799 itemStack = container.method_5438(i);
            if (!itemStack.method_7960()) {
                int itemCount = Math.min(itemStack.method_7947(), VanillaBackport.COMMON_CONFIG.golemItemCarryAmount.get());
                return container.method_5434(slot, itemCount);
            }

            slot++;
        }

        return class_1799.field_8037;
    }

    private class_1799 addItemsToContainer(class_1314 entity, class_1263 container) {
        int slot = 0;
        class_1799 itemStack = entity.method_6047();

        for (int i = 0; i < container.method_5439(); i++) {
            class_1799 containerItemStack = container.method_5438(i);
            if (containerItemStack.method_7960()) {
                container.method_5447(slot, itemStack);
                return class_1799.field_8037;
            }

            if (class_1799.method_31577(containerItemStack, itemStack) && containerItemStack.method_7947() < containerItemStack.method_7914()) {
                int countThatCanBeAdded = containerItemStack.method_7914() - containerItemStack.method_7947();
                int countToAdd = Math.min(countThatCanBeAdded, itemStack.method_7947());
                containerItemStack.method_7939(containerItemStack.method_7947() + countToAdd);
                itemStack.method_7939(itemStack.method_7947() - countThatCanBeAdded);
                container.method_5447(slot, containerItemStack);
                if (itemStack.method_7960()) {
                    return class_1799.field_8037;
                }
            }

            slot++;
        }

        return itemStack;
    }

    private void stopTargetingCurrentTarget(class_1314 entity) {
        this.ticksSinceReachingTarget = 0;
        this.target = null;
        entity.method_5942().method_6340();
        entity.method_18868().method_18875(class_4140.field_18445);
    }

    private void clearMemoriesAfterMatchingTargetFound(class_1314 entity) {
        this.stopTargetingCurrentTarget(entity);
        entity.method_18868().method_18875(ModMemoryModuleTypes.VISITED_BLOCK_POSITIONS.get());
        entity.method_18868().method_18875(ModMemoryModuleTypes.UNREACHABLE_TRANSPORT_BLOCK_POSITIONS.get());
    }

    private void enterCooldownAfterNoMatchingTargetFound(class_1314 entity) {
        this.stopTargetingCurrentTarget(entity);
        entity.method_18868().method_18878(ModMemoryModuleTypes.TRANSPORT_ITEMS_COOLDOWN_TICKS.get(), 140);
        entity.method_18868().method_18875(ModMemoryModuleTypes.VISITED_BLOCK_POSITIONS.get());
        entity.method_18868().method_18875(ModMemoryModuleTypes.UNREACHABLE_TRANSPORT_BLOCK_POSITIONS.get());
    }

    @Override
    protected void stop(class_3218 level, class_1314 entity, long gameTime) {
        this.onStartTravelling(entity);
        if (entity.method_5942() instanceof CopperGolemPathNavigation navigation) {
            navigation.setCanPathToTargetsBelowSurface(false);
        }
    }

    private void stopInPlace(class_1314 mob) {
        mob.method_5942().method_6340();
        mob.method_5938(0.0F);
        mob.method_5976(0.0F);
        mob.method_6125(0.0F);
        mob.method_18800(0.0, mob.method_18798().field_1351, 0.0);
    }

    public enum ContainerInteractionState {
        PICKUP_ITEM, PICKUP_NO_ITEM, PLACE_ITEM, PLACE_NO_ITEM
    }

    public interface OnTargetReachedInteraction extends TriConsumer<class_1314, TransportItemTarget, Integer> {}

    public enum TransportItemState {
        TRAVELLING, QUEUING, INTERACTING
    }

    public record TransportItemTarget(class_2338 pos, class_1263 container, class_2586 blockEntity, class_2680 state) {
        @Nullable
        public static TransportItemTarget tryCreatePossibleTarget(class_2586 blockEntity, class_1937 level) {
            class_2338 blockPos = blockEntity.method_11016();
            class_2680 blockState = blockEntity.method_11010();
            class_1263 container = getBlockEntityContainer(blockEntity, blockState, level, blockPos);
            return container != null ? new TransportItemTarget(blockPos, container, blockEntity, blockState) : null;
        }

        @Nullable
        public static TransportItemTarget tryCreatePossibleTarget(class_2338 blockPos, class_1937 level) {
            class_2586 blockEntity = level.method_8321(blockPos);
            return blockEntity == null ? null : tryCreatePossibleTarget(blockEntity, level);
        }

        @Nullable
        private static class_1263 getBlockEntityContainer(class_2586 blockEntity, class_2680 blockState, class_1937 level, class_2338 blockPos) {
            if (blockState.method_26204() instanceof class_2281 chestBlock) {
                return class_2281.method_17458(chestBlock, blockState, level, blockPos, false);
            } else {
                return blockEntity instanceof class_1263 container ? container : null;
            }
        }
    }
}