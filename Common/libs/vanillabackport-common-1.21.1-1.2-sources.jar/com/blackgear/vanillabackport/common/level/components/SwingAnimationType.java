package com.blackgear.vanillabackport.common.level.components;

import com.mojang.serialization.Codec;
import io.netty.buffer.ByteBuf;
import java.util.function.IntFunction;
import net.minecraft.class_3542;
import net.minecraft.class_7995;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public enum SwingAnimationType implements class_3542 {
    NONE(0, "none"),
    WHACK(1, "whack"),
    STAB(2, "stab");

    private static final IntFunction<SwingAnimationType> BY_ID = class_7995.method_47914(SwingAnimationType::getId, values(), class_7995.class_7996.field_41664);
    public static final Codec<SwingAnimationType> CODEC = class_3542.method_28140(SwingAnimationType::values);
    public static final class_9139<ByteBuf, SwingAnimationType> STREAM_CODEC = class_9135.method_56375(BY_ID, SwingAnimationType::getId);
    private final int id;
    private final String name;

    SwingAnimationType(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public int getId() {
        return this.id;
    }

    @Override
    public String method_15434() {
        return this.name;
    }
}
