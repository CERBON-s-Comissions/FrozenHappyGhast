package com.blackgear.vanillabackport.common.level.entities.mob.animal.cow;

import com.blackgear.platform.core.BuiltInCoreRegistry;
import com.blackgear.platform.core.api.RegistryKey;
import com.blackgear.vanillabackport.common.api.modules.mob_variant.ModelAndTexture;
import com.blackgear.vanillabackport.common.api.modules.mob_variant.spawn.SpawnPrioritySelectors;
import com.blackgear.vanillabackport.common.api.modules.mob_variant.spawn.check.raw.RawBiomeCheck;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.blackgear.vanillabackport.core.data.tags.ModBiomeTags;
import net.minecraft.class_1959;
import net.minecraft.class_2960;
import net.minecraft.class_6862;

public class CowVariants {
    public static final BuiltInCoreRegistry<CowVariant> REGISTRIES = BuiltInCoreRegistry.create(class_2960.method_60656("cow_variants"), VanillaBackport.NAMESPACE);
    
    public static final RegistryKey<CowVariant> TEMPERATE = register("temperate",
        CowVariant.ModelType.NORMAL,
        "cow",
        SpawnPrioritySelectors.fallback(0));
    public static final RegistryKey<CowVariant> WARM = register("warm",
        CowVariant.ModelType.WARM,
        "warm_cow",
        ModBiomeTags.SPAWNS_WARM_VARIANT_FARM_ANIMALS);
    public static final RegistryKey<CowVariant> COLD = register("cold",
        CowVariant.ModelType.COLD,
        "cold_cow",
        ModBiomeTags.SPAWNS_COLD_VARIANT_FARM_ANIMALS);

    private static RegistryKey<CowVariant> register(String key, CowVariant.ModelType type, String assetId, class_6862<class_1959> biome) {
        return register(key, type, assetId, SpawnPrioritySelectors.single(new RawBiomeCheck(biome), 1));
    }

    private static RegistryKey<CowVariant> register(String key, CowVariant.ModelType type, String assetId, SpawnPrioritySelectors selectors) {
        class_2960 path = class_2960.method_60656("entity/cow/" + assetId);
        return REGISTRIES.registerKey(key, new CowVariant(new ModelAndTexture<>(type, path), selectors));
    }
}