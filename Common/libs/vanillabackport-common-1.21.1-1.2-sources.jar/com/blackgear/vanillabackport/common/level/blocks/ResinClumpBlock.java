package com.blackgear.vanillabackport.common.level.blocks;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3737;
import net.minecraft.class_5778;
import net.minecraft.class_7118;
import org.jetbrains.annotations.Nullable;

public class ResinClumpBlock extends class_5778 implements class_3737 {
    private static final class_2746 WATERLOGGED = class_2741.field_12508;

    @Override
    protected MapCodec<? extends class_5778> method_53969() {
        return method_54094(ResinClumpBlock::new);
    }

    public ResinClumpBlock(class_2251 properties) {
        super(properties);
        this.method_9590(this.method_9564().method_11657(WATERLOGGED, false));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        builder.method_11667(WATERLOGGED);
    }

    @Override
    public class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 level, class_2338 pos, class_2338 neighborPos) {
        if (state.method_11654(WATERLOGGED)) {
            level.method_39281(pos, class_3612.field_15910, class_3612.field_15910.method_15789(level));
        }

        return super.method_9559(state, direction, neighborState, level, pos, neighborPos);
    }

    @Override
    public class_3610 method_9545(class_2680 state) {
        return state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
    }

    @Override
    public class_7118 method_41432() {
        return new class_7118(new NoOpSpreadConfig());
    }

    private static class NoOpSpreadConfig implements class_7118.class_7120 {
        @Override
        public @Nullable class_2680 method_41459(class_2680 currentState, class_1922 level, class_2338 pos, class_2350 lookingDirection) {
            return null;
        }

        @Override
        public boolean method_41457(class_1922 level, class_2338 pos, class_7118.class_7121 spreadPos) {
            return false;
        }
    }
}