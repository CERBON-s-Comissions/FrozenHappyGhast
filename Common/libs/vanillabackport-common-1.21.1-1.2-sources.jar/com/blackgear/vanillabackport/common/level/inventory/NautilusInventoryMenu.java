package com.blackgear.vanillabackport.common.level.inventory;

import com.blackgear.vanillabackport.common.level.entities.mob.animal.nautilus.AbstractNautilus;
import net.minecraft.class_1263;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_9692;

public class NautilusInventoryMenu extends class_1703 {
	private final class_1263 horseContainer;
	private final class_1263 armorContainer;
	private final AbstractNautilus nautilus;

	public NautilusInventoryMenu(int containerId, class_1661 inventory, class_1263 container, AbstractNautilus nautilus) {
		super(null, containerId);
		this.horseContainer = container;
		this.armorContainer = nautilus.getBodyArmorAccess();
		this.nautilus = nautilus;
		
		container.method_5435(inventory.field_7546);
		
		this.method_7621(new class_1735(container, 0, 8, 18) {
			@Override
			public boolean method_7680(class_1799 stack) {
				return stack.method_31574(class_1802.field_8175) && !this.method_7681() && nautilus.method_6765();
			}

			@Override
			public boolean method_7682() {
				return nautilus.method_6765();
			}
		});
		
		this.method_7621(new class_9692(this.armorContainer, nautilus, class_1304.field_48824, 0, 8, 36, null) {
			@Override
			public boolean method_7680(class_1799 stack) {
				return nautilus.method_6773(stack);
			}

			@Override
			public boolean method_7682() {
				return nautilus.method_56991(class_1304.field_48824);
			}
		});

		for (int row = 0; row < 3; row++) {
			for (int col = 0; col < 9; col++) {
				this.method_7621(new class_1735(inventory, col + row * 9 + 9, 8 + col * 18, 102 + row * 18 + -18));
			}
		}

		for (int col = 0; col < 9; col++) {
			this.method_7621(new class_1735(inventory, col, 8 + col * 18, 142));
		}
	}

	@Override
	public boolean method_7597(class_1657 player) {
		return !this.nautilus.hasInventoryChanged(this.horseContainer)
			&& this.horseContainer.method_5443(player)
			&& this.armorContainer.method_5443(player)
			&& this.nautilus.method_5805()
			&& player.method_56094(this.nautilus, 4.0);
	}

	@Override
	public class_1799 method_7601(class_1657 player, int index) {
		class_1799 itemStack = class_1799.field_8037;
		class_1735 slot = this.field_7761.get(index);
		if (slot != null && slot.method_7681()) {
			class_1799 itemStack2 = slot.method_7677();
			itemStack = itemStack2.method_7972();
			int i = this.horseContainer.method_5439() + 1;
			if (index < i) {
				if (!this.method_7616(itemStack2, i, this.field_7761.size(), true)) {
					return class_1799.field_8037;
				}
			} else if (this.method_7611(1).method_7680(itemStack2) && !this.method_7611(1).method_7681()) {
				if (!this.method_7616(itemStack2, 1, 2, false)) {
					return class_1799.field_8037;
				}
			} else if (this.method_7611(0).method_7680(itemStack2)) {
				if (!this.method_7616(itemStack2, 0, 1, false)) {
					return class_1799.field_8037;
				}
			} else if (i <= 1 || !this.method_7616(itemStack2, 2, i, false)) {
				int k = i + 27;
				int m = k + 9;
				if (index >= k && index < m) {
					if (!this.method_7616(itemStack2, i, k, false)) {
						return class_1799.field_8037;
					}
				} else if (index >= i && index < k) {
					if (!this.method_7616(itemStack2, k, m, false)) {
						return class_1799.field_8037;
					}
				} else if (!this.method_7616(itemStack2, k, k, false)) {
					return class_1799.field_8037;
				}
				
				return class_1799.field_8037;
			}
			
			if (itemStack2.method_7960()) {
				slot.method_53512(class_1799.field_8037);
			} else {
				slot.method_7668();
			}
		}

		return itemStack;
	}

	@Override
	public void method_7595(class_1657 player) {
		super.method_7595(player);
		this.horseContainer.method_5432(player);
	}
}