package com.blackgear.vanillabackport.common.level.block_entities;

import com.blackgear.vanillabackport.client.level.particle.particleoptions.TrailParticleOption;
import com.blackgear.vanillabackport.client.registries.ModParticles;
import com.blackgear.vanillabackport.client.registries.ModSoundEvents;
import com.blackgear.vanillabackport.common.level.blocks.CreakingHeartBlock;
import com.blackgear.vanillabackport.common.level.blocks.CreakingHeartState;
import com.blackgear.vanillabackport.common.level.entities.mob.monster.creaking.Creaking;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlockEntities;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import com.blackgear.vanillabackport.common.registries.entities.ModEntityTypes;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.blackgear.vanillabackport.core.data.tags.ModBlockTags;
import com.blackgear.vanillabackport.core.util.Utilities.CollisionUtils;
import com.blackgear.vanillabackport.core.util.WorldUtilities.EnvironmentUtils;
import com.blackgear.vanillabackport.core.util.WorldUtilities.SpawnUtils;
import com.mojang.datafixers.util.Either;
import org.apache.commons.lang3.mutable.Mutable;
import org.apache.commons.lang3.mutable.MutableObject;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_1267;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_156;
import net.minecraft.class_1657;
import net.minecraft.class_1928;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_3218;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_3730;
import net.minecraft.class_5712;
import net.minecraft.class_5778;
import net.minecraft.class_5819;
import net.minecraft.class_7225;

import static com.blackgear.vanillabackport.core.util.Utilities.*;
import static com.blackgear.vanillabackport.core.util.WorldUtilities.*;

public class CreakingHeartBlockEntity extends class_2586 {
    private static final Optional<Creaking> NO_CREAKING = Optional.empty();
    @Nullable private Either<Creaking, UUID> creakingInfo;
    private long ticksExisted;
    private int ticker;
    private int emitter;
    @Nullable private class_243 emitterTarget;
    private int outputSignal;

    public CreakingHeartBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.CREAKING_HEART.get(), pos, state);
    }

    public static void serverTick(class_1937 level, class_2338 pos, class_2680 state, CreakingHeartBlockEntity heart) {
        heart.ticksExisted++;
        if (level instanceof class_3218 server) {
            int computedOutputSignal = heart.computeAnalogOutputSignal();
            if (heart.outputSignal != computedOutputSignal) {
                heart.outputSignal = computedOutputSignal;
                level.method_8455(pos, ModBlocks.CREAKING_HEART.get());
            }

            if (heart.emitter > 0) {
                if (heart.emitter > 50) {
                    heart.emitParticles(server, 1, true);
                    heart.emitParticles(server, 1, false);
                }

                if (heart.emitter % 10 == 0 && heart.emitterTarget != null) {
                    heart.getCreakingProtector().ifPresent(creaking -> heart.emitterTarget = creaking.method_5829().method_1005());
                    class_243 heartPosition = class_243.method_24953(pos);
                    float progress = 0.2F + 0.8F * (100 - heart.emitter) / 100.0F;
                    class_243 soundLocation = heartPosition.method_1020(heart.emitterTarget).method_1021(progress).method_1019(heart.emitterTarget);
                    class_2338 soundPos = class_2338.method_49638(soundLocation);
                    float volume = heart.emitter / 2.0F / 100.0F + 0.5F;
                    level.method_8396(null, soundPos, ModSoundEvents.CREAKING_HEART_HURT.get(), class_3419.field_15245, volume, 1.0F);
                }

                heart.emitter--;
            }

            if (heart.ticker-- < 0) {
                heart.ticker = heart.field_11863 == null ? 20 : heart.field_11863.method_8409().method_43048(5) + 20;
                class_2680 updatedState = updateCreakingState(level, state, pos, heart);
                if (updatedState != state) {
                    level.method_8501(pos, updatedState);
                    if (updatedState.method_11654(CreakingHeartBlock.STATE) == CreakingHeartState.UPROOTED) {
                        return;
                    }
                }

                if (heart.creakingInfo == null) {
                    if (updatedState.method_11654(CreakingHeartBlock.STATE) == CreakingHeartState.AWAKE) {
                        if (level.method_8450().method_8355(class_1928.field_19390) && level.method_8407() != class_1267.field_5801) {
                            class_1657 player = level.method_18459(pos.method_10263(), pos.method_10264(), pos.method_10260(), 32.0, false);
                            if (player != null) {
                                Creaking creaking = spawnProtector(server, heart);
                                if (creaking != null) {
                                    heart.setCreakingInfo(creaking);
                                    creaking.method_43077(ModSoundEvents.CREAKING_SPAWN.get());
                                    level.method_8396(null, heart.method_11016(), ModSoundEvents.CREAKING_HEART_SPAWN.get(), class_3419.field_15245, 1.0F, 1.0F);
                                }
                            }
                        }
                    }
                } else {
                    Optional<Creaking> optionalCreaking = heart.getCreakingProtector();
                    if (optionalCreaking.isPresent()) {
                        Creaking creaking = optionalCreaking.get();
                        if (!(EnvironmentUtils.isNaturalNight(level) || VanillaBackport.COMMON_CONFIG.doCreakingHeartsWorkOnDay.get())
                            && !creaking.method_5947()
                            || heart.distanceToCreaking() > 34.0
                            || creaking.playerIsStuckInYou()) {
                            heart.removeProtector(null);
                        }
                    }
                }
            }
        }
    }

    private static class_2680 updateCreakingState(class_1937 level, class_2680 state, class_2338 pos, CreakingHeartBlockEntity heart) {
        if (!CreakingHeartBlock.hasRequiredLogs(state, level, pos) && heart.creakingInfo == null) {
            return state.method_11657(CreakingHeartBlock.STATE, CreakingHeartState.UPROOTED);
        } else {
            boolean isNaturalNight = VanillaBackport.COMMON_CONFIG.doCreakingHeartsWorkOnDay.get() || EnvironmentUtils.isNaturalNight(level);
            return state.method_11657(CreakingHeartBlock.STATE, isNaturalNight ? CreakingHeartState.AWAKE : CreakingHeartState.DORMANT);
        }
    }

    private double distanceToCreaking() {
        return this.getCreakingProtector()
            .map(creaking -> Math.sqrt(creaking.method_5707(class_243.method_24955(this.method_11016()))))
            .orElse(0.0);
    }

    private void clearCreakingInfo() {
        this.creakingInfo = null;
        this.method_5431();
    }

    public void setCreakingInfo(Creaking creaking) {
        this.creakingInfo = Either.left(creaking);
        this.method_5431();
    }

    public void setCreakingInfo(UUID uuid) {
        this.creakingInfo = Either.right(uuid);
        this.ticksExisted = 0L;
        this.method_5431();
    }

    private Optional<Creaking> getCreakingProtector() {
        if (this.creakingInfo == null) {
            return NO_CREAKING;
        } else {
            if (this.creakingInfo.left().isPresent()) {
                Creaking creaking = this.creakingInfo.left().get();
                if (!creaking.method_31481()) {
                    return Optional.of(creaking);
                }

                this.setCreakingInfo(creaking.method_5667());
            }

            if (this.field_11863 instanceof class_3218 server && this.creakingInfo.right().isPresent()) {
                UUID uuid = this.creakingInfo.right().get();
                if (server.method_14190(uuid) instanceof Creaking creaking) {
                    this.setCreakingInfo(creaking);
                    return Optional.of(creaking);
                } else {
                    if (this.ticksExisted >= 30L) {
                        this.clearCreakingInfo();
                    }

                    return NO_CREAKING;
                }
            } else {
                return NO_CREAKING;
            }
        }
    }

    @Nullable
    private static Creaking spawnProtector(class_3218 level, CreakingHeartBlockEntity heart) {
        if (!VanillaBackport.COMMON_CONFIG.hasCreaking.get()) return null;

        class_2338 pos = heart.method_11016();
        Optional<Creaking> spawnedMob = SpawnUtils.trySpawnMob(ModEntityTypes.CREAKING.get(), class_3730.field_16469, level, pos, 5, 16, 8, SpawnUtils.ON_TOP_OF_COLLIDER_NO_LEAVES, true);

        if (spawnedMob.isEmpty()) {
            return null;
        } else {
            Creaking spawnedCreaking = spawnedMob.get();
            level.method_43275(spawnedCreaking, class_5712.field_28738, spawnedCreaking.method_19538());
            level.method_8421(spawnedCreaking, (byte) 60);
            spawnedCreaking.setTransient(pos);
            return spawnedCreaking;
        }
    }

    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 provider) {
        return this.method_58692(provider);
    }

    public void creakingHurt() {
        Optional<Creaking> creaking = this.getCreakingProtector();
        if (creaking.isPresent()) {
            if (this.field_11863 instanceof class_3218 server) {
                if (this.emitter <= 0) {
                    this.emitParticles(server, 20, false);
                    if (this.method_11010().method_11654(CreakingHeartBlock.STATE) == CreakingHeartState.AWAKE && VanillaBackport.COMMON_CONFIG.hasResin.get()) {
                        int numberOfClumps = this.field_11863.method_8409().method_39332(2, 3);

                        for (int i = 0; i < numberOfClumps; i++) {
                            this.spreadResin(server).ifPresent(pos -> {
                                this.field_11863.method_8396(null, pos, ModSoundEvents.RESIN_PLACE.get(), class_3419.field_15245, 1.0F, 1.0F);
                                this.field_11863.method_43276(class_5712.field_28164, pos, class_5712.class_7397.method_43287(this.method_11010()));
                            });
                        }
                    }

                    this.emitter = 100;
                    this.emitterTarget = creaking.get().method_5829().method_1005();
                }
            }
        }
    }

    private Optional<class_2338> spreadResin(class_3218 level) {
        class_5819 random = level.method_8409();
        Mutable<class_2338> placedResin = new MutableObject<>(null);
        class_2338.method_49925(this.field_11867, 2, 64, (pos, acceptor) -> {
            for (class_2350 dir : class_156.method_43253(class_2350.values(), random)) {
                class_2338 neighbourPos = pos.method_10093(dir);
                if (level.method_8320(neighbourPos).method_26164(ModBlockTags.CREAKING_HEART_HOLDERS)) {
                    acceptor.accept(neighbourPos);
                }
            }
        }, pos -> {
            if (level.method_8320(pos).method_26164(ModBlockTags.CREAKING_HEART_HOLDERS)) {
                for (class_2350 dir : class_156.method_43253(class_2350.values(), random)) {
                    class_2338 neighbourPos = pos.method_10093(dir);
                    class_2680 neighbourState = level.method_8320(neighbourPos);
                    class_2350 opposite = dir.method_10153();
                    if (neighbourState.method_26215()) {
                        neighbourState = ModBlocks.RESIN_CLUMP.get().method_9564();
                    } else if (neighbourState.method_27852(class_2246.field_10382) && neighbourState.method_26227().method_15771()) {
                        neighbourState = ModBlocks.RESIN_CLUMP.get().method_9564().method_11657(class_2741.field_12508, true);
                    }

                    if (neighbourState.method_27852(ModBlocks.RESIN_CLUMP.get()) && !class_5778.method_33366(neighbourState, opposite)) {
                        level.method_8501(neighbourPos, neighbourState.method_11657(class_5778.method_33374(opposite), true));
                        placedResin.setValue(neighbourPos);
                        return false;
                    }
                }
            }

            return true;
        });
        return Optional.ofNullable(placedResin.getValue());
    }

    private void emitParticles(class_3218 level, int count, boolean towardsCreaking) {
        Optional<Creaking> creaking = this.getCreakingProtector();
        if (creaking.isPresent()) {
            int color = towardsCreaking ? VanillaBackport.COMMON_CONFIG.creakingParticleReverseColor.get() : VanillaBackport.COMMON_CONFIG.creakingParticleColor.get();
            class_5819 random = level.method_8409();
            
            for (double i = 0.0; i < count; i++) {
                class_238 box = creaking.get().method_5829();
                class_243 source = CollisionUtils.getMinPosition(box).method_1031(random.method_43058() * box.method_17939(), random.method_43058() * box.method_17940(), random.method_43058() * box.method_17941());
                class_243 destination = class_243.method_24954(this.method_11016()).method_1031(random.method_43058(), random.method_43058(), random.method_43058());
                if (towardsCreaking) {
                    class_243 foo = source;
                    source = destination;
                    destination = foo;
                }

                TrailParticleOption particle = new TrailParticleOption(destination, color, random.method_43048(40) + 10);
                ModParticles.sendParticles(level, particle, true, true, source.field_1352, source.field_1351, source.field_1350, 1, 0.0, 0.0, 0.0, 0.0);
            }
        }
    }

    public void removeProtector(@Nullable class_1282 source) {
        Optional<Creaking> creakingProtector = this.getCreakingProtector();
        if (creakingProtector.isPresent()) {
            Creaking creaking = creakingProtector.get();
            if (source == null) {
                creaking.tearDown();
            } else {
                creaking.creakingDeathEffects(source);
                creaking.setTearingDown();
                creaking.method_6033(0.0F);
            }

            this.clearCreakingInfo();
        }
    }

    public boolean isProtector(Creaking creaking) {
        return this.getCreakingProtector().map(target -> target == creaking).orElse(false);
    }

    public int getAnalogOutputSignal() {
        return this.outputSignal;
    }

    public int computeAnalogOutputSignal() {
        if (this.creakingInfo != null && this.getCreakingProtector().isPresent()) {
            double distance = this.distanceToCreaking();
            double scaledDistance = class_3532.method_15350(distance, 0.0, 32.0) / 32.0;
            return 15 - (int) Math.floor(scaledDistance * 15.0);
        } else {
            return 0;
        }
    }

    @Override
    public void method_11014(class_2487 tag, class_7225.class_7874 provider) {
        super.method_11014(tag, provider);
        if (tag.method_25928("creaking")) {
            this.setCreakingInfo(tag.method_25926("creaking"));
        } else {
            this.clearCreakingInfo();
        }
    }

    @Override
    protected void method_11007(class_2487 tag, class_7225.class_7874 provider) {
        super.method_11007(tag, provider);
        if (this.creakingInfo != null) {
            tag.method_25927("creaking", this.creakingInfo.map(class_1297::method_5667, uuid -> uuid));
        }
    }
}