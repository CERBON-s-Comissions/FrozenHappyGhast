package com.blackgear.vanillabackport.common.level.blocks;

import com.blackgear.vanillabackport.core.data.tags.ModBlockTags;
import com.blackgear.vanillabackport.core.util.BlockShaper;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_1922;
import net.minecraft.class_2261;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3726;
import net.minecraft.class_5431;

public class CactusFlowerBlock extends class_2261 {
    private static final class_265 SHAPE = BlockShaper.column(14.0, 0.0, 12.0);

    public CactusFlowerBlock(class_2251 properties) {
        super(properties);
    }

    @Override
    protected MapCodec<? extends class_2261> method_53969() {
        return method_54094(CactusFlowerBlock::new);
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    @Override
    protected boolean method_9695(class_2680 state, class_1922 level, class_2338 pos) {
        class_2680 belowPos = level.method_8320(pos);
        return belowPos.method_26164(ModBlockTags.SUPPORT_OVERRIDE_CACTUS_FLOWER) || belowPos.method_30368(level, pos, class_2350.field_11036, class_5431.field_25823);
    }
}