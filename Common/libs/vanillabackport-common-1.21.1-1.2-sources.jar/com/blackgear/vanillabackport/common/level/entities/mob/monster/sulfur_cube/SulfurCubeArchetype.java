package com.blackgear.vanillabackport.common.level.entities.mob.monster.sulfur_cube;

import com.blackgear.platform.core.api.RegistryKey;
import com.blackgear.vanillabackport.client.registries.ModSoundEvents;
import com.blackgear.vanillabackport.core.util.AdditionalCodecs;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_5321;
import net.minecraft.class_5699;
import net.minecraft.class_5863;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_8110;

public record SulfurCubeArchetype(
    class_6862<class_1792> items,
    List<AttributeEntry> attributeModifiers,
    boolean buoyant,
    Optional<ExplosionData> explosion,
    Optional<ContactDamage> contactDamage,
    KnockbackModifiers knockbackModifiers,
    SoundSettings soundSettings
) {
    public static final Codec<SulfurCubeArchetype> CODEC = RecordCodecBuilder.create(instance -> instance.group(
        class_6862.method_40093(class_7924.field_41197).fieldOf("items").forGetter(SulfurCubeArchetype::items),
        AttributeEntry.CODEC.listOf().fieldOf("attribute_modifiers").forGetter(SulfurCubeArchetype::attributeModifiers),
        Codec.BOOL.fieldOf("buoyant").forGetter(SulfurCubeArchetype::buoyant),
        ExplosionData.CODEC.optionalFieldOf("explosion").forGetter(SulfurCubeArchetype::explosion),
        ContactDamage.CODEC.optionalFieldOf("contact_damage").forGetter(SulfurCubeArchetype::contactDamage),
        KnockbackModifiers.CODEC.fieldOf("knockback_modifiers").forGetter(SulfurCubeArchetype::knockbackModifiers),
        SoundSettings.CODEC.fieldOf("sound_settings").forGetter(SulfurCubeArchetype::soundSettings)
    ).apply(instance, SulfurCubeArchetype::new));

    public static final KnockbackModifiers DEFAULT_KNOCKBACK_MODIFIERS = new KnockbackModifiers(0.33F, 0.06F);
    public static final SoundSettings DEFAULT_SOUND_SETTINGS = new SoundSettings(ModSoundEvents.SULFUR_CUBE_REGULAR_HIT, ModSoundEvents.SULFUR_CUBE_REGULAR_PUSH, 0.2F, 0.5F);

    public record AttributeEntry(class_6880<class_1320> attribute, class_1322 modifier) {
        public static final Codec<AttributeEntry> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            class_7923.field_41190.method_40294().fieldOf("attribute").forGetter(AttributeEntry::attribute),
            class_1322.field_46247.fieldOf("modifier").forGetter(AttributeEntry::modifier)
        ).apply(instance, AttributeEntry::new));

        public static AttributeEntry add(class_6880<class_1320> attribute, double amount, RegistryKey<SulfurCubeArchetype> archetype) {
            class_2960 attributeLocation = attribute.method_40230()
                .orElseThrow(() -> new IllegalStateException("Attribute has no registry key"))
                .method_29177();
            return new AttributeEntry(
                attribute,
                new class_1322(
                    class_2960.method_60656(archetype.location().method_12832() + "_add_" + attributeLocation.method_12836() + "_" + attributeLocation.method_12832()),
                    amount,
                    class_1322.class_1323.field_6328
                )
            );
        }

        public static AttributeEntry multiply(class_6880<class_1320> attribute, double amount, RegistryKey<SulfurCubeArchetype> archetype) {
            class_2960 attributeLocation = attribute.method_40230()
                .orElseThrow(() -> new IllegalStateException("Attribute has no registry key"))
                .method_29177();
            return new AttributeEntry(
                attribute,
                new class_1322(
                    class_2960.method_60656(archetype.location().method_12832() + "_mul_" + attributeLocation.method_12836() + "_" + attributeLocation.method_12832()),
                    amount - 1.0,
                    class_1322.class_1323.field_6331
                )
            );
        }
    }

    public record ContactDamage(class_5321<class_8110> damageType, class_5863 amount, boolean attributeToSource) {
        public static final Codec<ContactDamage> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            class_5321.method_39154(class_7924.field_42534).fieldOf("damage_type").forGetter(ContactDamage::damageType),
            AdditionalCodecs.floatProvider(0.0F).fieldOf("amount").forGetter(ContactDamage::amount),
            Codec.BOOL.fieldOf("attribute_to_source").forGetter(ContactDamage::attributeToSource)
        ).apply(instance, ContactDamage::new));
    }

    public record ExplosionData(int power, boolean causesFire, int fuse) {
        public static final Codec<ExplosionData> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            class_5699.field_33441.fieldOf("power").forGetter(ExplosionData::power),
            Codec.BOOL.fieldOf("causes_fire").forGetter(ExplosionData::causesFire),
            class_5699.field_33442.fieldOf("fuse").forGetter(ExplosionData::fuse)
        ).apply(instance, ExplosionData::new));
    }

    public record KnockbackModifiers(float horizontalPower, float verticalPower) {
        public static final Codec<KnockbackModifiers> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.FLOAT.fieldOf("horizontal_power").forGetter(KnockbackModifiers::horizontalPower),
            Codec.FLOAT.fieldOf("vertical_power").forGetter(KnockbackModifiers::verticalPower)
        ).apply(instance, KnockbackModifiers::new));
    }

    public record SoundSettings(class_6880<class_3414> hitSound, class_6880<class_3414> pushSound, float pushSoundImpulseThreshold, float pushSoundCooldown) {
        public static final Codec<SoundSettings> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                class_3414.field_41699.fieldOf("hit_sound").forGetter(SoundSettings::hitSound),
                class_3414.field_41699.fieldOf("push_sound").forGetter(SoundSettings::pushSound),
                Codec.FLOAT.fieldOf("push_sound_impulse_threshold").forGetter(SoundSettings::pushSoundImpulseThreshold),
                Codec.FLOAT.fieldOf("push_sound_cooldown").forGetter(SoundSettings::pushSoundCooldown)
        ).apply(instance, SoundSettings::new));
    }
}