package com.blackgear.vanillabackport.common.level.entities.mob.monster.creaking;

import java.util.function.Predicate;
import net.minecraft.class_1268;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1811;
import net.minecraft.class_4102;
import net.minecraft.class_4140;
import net.minecraft.class_6670;
import net.minecraft.class_7894;
import net.minecraft.class_7898;

public class CreakingMeleeAttack {
    public static <T extends class_1308> class_7894<T> create(Predicate<T> canAttackPredicate, int cooldownBetweenAttacks) {
        return class_7898.method_47224(
            instance -> instance.group(
                    instance.method_47235(class_4140.field_18446),
                    instance.method_47244(class_4140.field_22355),
                    instance.method_47245(class_4140.field_22475),
                    instance.method_47244(class_4140.field_18442)
                )
                .apply(
                    instance,
                    (lookTarget, attackTarget, attackCoolingDown, nearestVisibleLivingEntities) -> (level, body, timestamp) -> {
                        class_1309 target = instance.method_47243(attackTarget);
                        if (canAttackPredicate.test(body)
                            && !isHoldingUsableProjectileWeapon(body)
                            && body.method_42150(target)
                            && instance.<class_6670>method_47243(nearestVisibleLivingEntities).method_38972(target)) {
                            lookTarget.method_47249(new class_4102(target, true));
                            body.method_6104(class_1268.field_5808);
                            body.method_6121(target);
                            attackCoolingDown.method_47250(true, cooldownBetweenAttacks);
                            return true;
                        } else {
                            return false;
                        }
                    }
                )
        );
    }

    private static boolean isHoldingUsableProjectileWeapon(class_1308 body) {
        return body.method_24520(stack -> {
            class_1792 item = stack.method_7909();
            return item instanceof class_1811 projectile && body.method_25938(projectile);
        });
    }
}