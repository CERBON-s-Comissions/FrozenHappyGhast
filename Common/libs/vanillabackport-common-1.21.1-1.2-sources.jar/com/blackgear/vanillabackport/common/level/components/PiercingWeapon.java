package com.blackgear.vanillabackport.common.level.components;

import com.blackgear.vanillabackport.common.api.extensions.SoundExtensions;
import com.blackgear.vanillabackport.common.api.extensions.entity.spear.MobSpearHandler;
import com.blackgear.vanillabackport.common.registries.items.ModDataComponents;
import com.blackgear.vanillabackport.core.util.ProjectileUtils;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_3414;
import net.minecraft.class_3959;
import net.minecraft.class_3966;
import net.minecraft.class_5134;
import net.minecraft.class_6880;
import net.minecraft.class_8150;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record PiercingWeapon(
    boolean dealsKnockback,
    boolean dismounts,
    Optional<class_6880<class_3414>> sound,
    Optional<class_6880<class_3414>> hitSound
) {
    public static final Codec<PiercingWeapon> CODEC = RecordCodecBuilder.create(instance -> instance.group(
        Codec.BOOL.optionalFieldOf("deals_knockback", true).forGetter(PiercingWeapon::dealsKnockback),
        Codec.BOOL.optionalFieldOf("dismounts", false).forGetter(PiercingWeapon::dismounts),
        class_3414.field_41699.optionalFieldOf("sound").forGetter(PiercingWeapon::sound),
        class_3414.field_41699.optionalFieldOf("hit_sound").forGetter(PiercingWeapon::hitSound)
    ).apply(instance, PiercingWeapon::new));

    public static final class_9139<class_9129, PiercingWeapon> STREAM_CODEC = class_9139.method_56905(
        class_9135.field_48547, PiercingWeapon::dealsKnockback,
        class_9135.field_48547, PiercingWeapon::dismounts,
        class_3414.field_48279.method_56433(class_9135::method_56382), PiercingWeapon::sound,
        class_3414.field_48279.method_56433(class_9135::method_56382), PiercingWeapon::hitSound,
        PiercingWeapon::new
    );

    public void makeSound(class_1297 causer) {
        this.sound.ifPresent(sound -> ((SoundExtensions) causer.method_37908()).playSound(null, causer.method_23317(), causer.method_23318(), causer.method_23321(), sound, causer.method_5634(), 1.0F, 1.0F));
    }

    public void makeHitSound(class_1297 causer) {
        this.hitSound.ifPresent(sound -> causer.method_37908().method_60511(null, causer.method_23317(), causer.method_23318(), causer.method_23321(), sound, causer.method_5634(), 1.0F, 1.0F));
    }

    public static boolean canHitEntity(class_1297 jabber, class_1297 target) {
        if (target.method_5655() || !target.method_5805()) {
            return false;
        } else if (target instanceof class_8150) {
            return true;
        } else if (!target.method_49108()) {
            return false;
        } else {
            return (!(target instanceof class_1657 targetPlayer) || !(jabber instanceof class_1657 jabbingPlayer) || jabbingPlayer.method_7256(targetPlayer)) && !jabber.method_5794(target);
        }
    }

    public void attack(class_1309 attacker, class_1304 hand) {
        MobSpearHandler handler = (MobSpearHandler) attacker;
        float damage = (float) attacker.method_45325(class_5134.field_23721);
        class_1799 weapon = attacker.method_6118(hand);
        AttackRange attackRange = handler.vb$getAttackRangeWith(weapon);
        boolean hitSomething = false;

        Collection<class_3966> hitResults = ProjectileUtils.getHitEntitiesAlong(attacker, attackRange, target -> canHitEntity(attacker, target), class_3959.class_3960.field_17558).map(a -> List.of(), e -> e);
        for (class_3966 hitResult : hitResults) {
            hitSomething |= handler.vb$stabAttack(hand, hitResult.method_17782(), damage, true, this.dealsKnockback, this.dismounts);
        }

        handler.vb$onAttack();
        handler.vb$postPiercingAttack();
        if (hitSomething) {
            this.makeHitSound(attacker);
        }

        this.makeSound(attacker);
        attacker.method_6104(class_1268.field_5808);
    }
    
    @SuppressWarnings("unchecked")
    public static PiercingWeapon get(class_1799 stack) {
        Object component = stack.method_57824(ModDataComponents.PIERCING_WEAPON.get());
        
        if (component == null) return null;
        if (component instanceof PiercingWeapon weapon) return weapon;
        
        try {
            Class<?> clazz = component.getClass();
            
            boolean dealsKnockback = (boolean) clazz.getMethod("dealsKnockback").invoke(component);
            boolean dismounts = (boolean) clazz.getMethod("dismounts").invoke(component);
            Optional<class_6880<class_3414>> sound = (Optional<class_6880<class_3414>>) clazz.getMethod("sound").invoke(component);
            Optional<class_6880<class_3414>> hitSound = (Optional<class_6880<class_3414>>) clazz.getMethod("hitSound").invoke(component);
            
            return new PiercingWeapon(dealsKnockback, dismounts, sound, hitSound);
        } catch (Exception e) {
            return null;
        }
    }
}