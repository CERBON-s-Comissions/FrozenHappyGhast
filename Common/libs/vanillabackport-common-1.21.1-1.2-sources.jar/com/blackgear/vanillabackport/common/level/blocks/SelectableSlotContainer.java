package com.blackgear.vanillabackport.common.level.blocks;

import java.util.Optional;
import java.util.OptionalInt;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_3965;

public interface SelectableSlotContainer {
    int getRows();

    int getColumns();

    default OptionalInt getHitSlot(class_3965 hitResult, class_2350 blockFacing) {
        return getRelativeHitCoordinatesForBlockFace(hitResult, blockFacing).map(hitCoords -> {
            int row = getSection(1.0F - hitCoords.field_1342, this.getRows());
            int column = getSection(hitCoords.field_1343, this.getColumns());
            return OptionalInt.of(column + row * this.getColumns());
        }).orElseGet(OptionalInt::empty);
    }

    private static Optional<class_241> getRelativeHitCoordinatesForBlockFace(class_3965 hitResult, class_2350 blockFacing) {
        class_2350 hitDirection = hitResult.method_17780();
        if (blockFacing != hitDirection) {
            return Optional.empty();
        } else {
            class_2338 hitBlockPos = hitResult.method_17777().method_10093(hitDirection);
            class_243 relativeHit = hitResult.method_17784().method_1023(hitBlockPos.method_10263(), hitBlockPos.method_10264(), hitBlockPos.method_10260());
            double relativeX = relativeHit.method_10216();
            double relativeY = relativeHit.method_10214();
            double relativeZ = relativeHit.method_10215();

            return switch (hitDirection) {
                case field_11043 -> Optional.of(new class_241((float) (1.0 - relativeX), (float) relativeY));
                case field_11035 -> Optional.of(new class_241((float) relativeX, (float) relativeY));
                case field_11039 -> Optional.of(new class_241((float) relativeZ, (float) relativeY));
                case field_11034 -> Optional.of(new class_241((float) (1.0 - relativeZ), (float) relativeY));
                case field_11033, field_11036 -> Optional.empty();
            };
        }
    }

    private static int getSection(float relativeCoordinate, int maxSections) {
        float targetedPixel = relativeCoordinate * 16.0F;
        float sectionSize = 16.0F / maxSections;
        return class_3532.method_15340(class_3532.method_15375(targetedPixel / sectionSize), 0, maxSections - 1);
    }
}