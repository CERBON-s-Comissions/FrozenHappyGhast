package com.blackgear.vanillabackport.common.level.items;

import com.blackgear.vanillabackport.common.registries.entities.ModEntityTypes;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.Supplier;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_174;
import net.minecraft.class_1755;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_3612;
import net.minecraft.class_3730;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_5712;
import net.minecraft.class_5761;
import net.minecraft.class_7225;
import net.minecraft.class_9279;
import net.minecraft.class_9334;

public class SulfurCubeBucketItem<T extends class_1297> extends class_1755 {
    private final Supplier<class_1299<T>> type;
    private final class_3414 emptySound;

    public SulfurCubeBucketItem(Supplier<class_1299<T>> type, class_3414 emptySound, class_1792.class_1793 properties) {
        super(class_3612.field_15906, properties);
        this.type = type;
        this.emptySound = emptySound;
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        class_3965 hit = method_7872(level, player, class_3959.class_242.field_1348);

        if (hit.method_17783() == class_239.class_240.field_1333 || hit.method_17783() != class_239.class_240.field_1332) {
            return class_1271.method_22430(stack);
        }

        class_2338 clickedPos = hit.method_17777();
        class_2350 direction = hit.method_17780();
        class_2338 placePos = clickedPos.method_10093(direction);

        if (!level.method_8505(player, clickedPos) || !player.method_7343(placePos, direction, stack)) {
            return class_1271.method_22431(stack);
        }

        if (this.method_7731(player, level, placePos, hit)) {
            this.method_7728(player, level, stack, placePos);
            if (player instanceof class_3222 serverPlayer) {
                class_174.field_1191.method_23889(serverPlayer, placePos, stack);
            }
            player.method_7259(class_3468.field_15372.method_14956(this));
            return class_1271.method_29237(method_7732(stack, player), level.method_8608());
        }

        return class_1271.method_22431(stack);
    }

    @Override
    public boolean method_7731(@Nullable class_1657 player, class_1937 level, class_2338 pos, @Nullable class_3965 result) {
        this.method_7727(player, level, pos);
        return true;
    }

    @Override
    public void method_7728(@Nullable class_1657 player, class_1937 level, class_1799 containerStack, class_2338 pos) {
        if (level instanceof class_3218 serverLevel) {
            this.spawn(serverLevel, containerStack, pos);
            level.method_33596(player, class_5712.field_28738, pos);
        }
    }

    @Override
    protected void method_7727(@Nullable class_1657 player, class_1936 level, class_2338 pos) {
        level.method_8396(player, pos, this.emptySound, class_3419.field_15254, 1.0F, 1.0F);
    }

    private void spawn(class_3218 level, class_1799 stack, class_2338 pos) {
        class_1297 entity = this.type.get().method_5894(level, stack, null, pos, class_3730.field_16473, true, false);
        if (entity instanceof class_5761 bucketable) {
            class_9279 customData = stack.method_57825(class_9334.field_49610, class_9279.field_49302);
            bucketable.method_35170(customData.method_57461());
            bucketable.method_6454(true);
        }
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> tooltipComponents, class_1836 tooltipFlag) {
        if (this.type.get() == ModEntityTypes.SULFUR_CUBE.get()) {
            class_9279 customData = stack.method_57825(class_9334.field_49610, class_9279.field_49302);
            class_7225.class_7874 registries = context.method_59527();
            if (customData.method_57458() || registries == null) return;

            class_2487 tag = customData.method_57461();
            if (tag.method_10573("absorbed_block", class_2487.field_33260)) {
                class_1799 absorbedBlock = class_1799.method_57360(registries, tag.method_10562("absorbed_block")).orElse(class_1799.field_8037);
                if (!absorbedBlock.method_7960()) {
                    tooltipComponents.add(class_2561.method_43469("entity.minecraft.sulfur_cube.content", absorbedBlock.method_7964()).method_27695(class_124.field_1056, class_124.field_1080));
                }
            }
        }
    }
}