package com.blackgear.vanillabackport.common.level.items.enchantment.effects;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_9699;
import net.minecraft.class_9704;
import net.minecraft.class_9721;

public record ApplyExhaustion(class_9704 amount) implements class_9721 {
    public static final MapCodec<ApplyExhaustion> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
        class_9704.field_51690.fieldOf("amount").forGetter(e -> e.amount)
    ).apply(instance, ApplyExhaustion::new));
    
    @Override
    public void method_60220(class_3218 level, int enchantmentLevel, class_9699 item, class_1297 entity, class_243 origin) {
        if (entity instanceof class_1657 player) {
            player.method_7322(this.amount.method_60188(enchantmentLevel));
        }
    }
    
    @Override
    public MapCodec<? extends class_9721> method_60219() {
        return CODEC;
    }
}