package com.blackgear.vanillabackport.common.level.worldgen.features;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_3037;
import net.minecraft.class_5863;
import net.minecraft.class_6017;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public record SpeleothemClusterConfiguration(
    class_2680 baseBlock,
    class_2680 pointedBlock,
    class_6862<class_2248> replaceableBlocks,
    int floorToCeilingSearchRange,
    class_6017 height,
    class_6017 radius,
    int maxStalagmiteStalactiteHeightDiff,
    int heightDeviation,
    class_6017 speleothemBlockLayerThickness,
    class_5863 density,
    class_5863 wetness,
    float chanceOfSpeleothemColumnAtMaxDistanceFromCenter,
    int maxDistanceFromEdgeAffectingChanceOfSpeleothemColumn,
    int maxDistanceFromCenterAffectingHeightBias
) implements class_3037 {
    public static final Codec<SpeleothemClusterConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group(
        class_2680.field_24734.fieldOf("base_block").forGetter(SpeleothemClusterConfiguration::baseBlock),
        class_2680.field_24734.fieldOf("pointed_block").forGetter(SpeleothemClusterConfiguration::pointedBlock),
        class_6862.method_40093(class_7924.field_41254).fieldOf("replaceable_blocks").forGetter(SpeleothemClusterConfiguration::replaceableBlocks),
        Codec.intRange(1, 512).fieldOf("floor_to_ceiling_search_range").forGetter(SpeleothemClusterConfiguration::floorToCeilingSearchRange),
        class_6017.method_35004(1, 128).fieldOf("height").forGetter(SpeleothemClusterConfiguration::height),
        class_6017.method_35004(1, 128).fieldOf("radius").forGetter(SpeleothemClusterConfiguration::radius),
        Codec.intRange(0, 64).fieldOf("max_stalagmite_stalactite_height_diff").forGetter(SpeleothemClusterConfiguration::maxStalagmiteStalactiteHeightDiff),
        Codec.intRange(1, 64).fieldOf("height_deviation").forGetter(SpeleothemClusterConfiguration::heightDeviation),
        class_6017.method_35004(0, 128).fieldOf("speleothem_block_layer_thickness").forGetter(SpeleothemClusterConfiguration::speleothemBlockLayerThickness),
        class_5863.method_33916(0.0F, 2.0F).fieldOf("density").forGetter(SpeleothemClusterConfiguration::density), 
        class_5863.method_33916(0.0F, 2.0F).fieldOf("wetness").forGetter(SpeleothemClusterConfiguration::wetness),
        Codec.floatRange(0.0F, 1.0F).fieldOf("chance_of_speleothem_column_at_max_distance_from_center").forGetter(SpeleothemClusterConfiguration::chanceOfSpeleothemColumnAtMaxDistanceFromCenter),
        Codec.intRange(1, 64).fieldOf("max_distance_from_edge_affecting_chance_of_speleothem_column").forGetter(SpeleothemClusterConfiguration::maxDistanceFromEdgeAffectingChanceOfSpeleothemColumn),
        Codec.intRange(1, 64).fieldOf("max_distance_from_center_affecting_height_bias").forGetter(SpeleothemClusterConfiguration::maxDistanceFromCenterAffectingHeightBias)
    ).apply(instance, SpeleothemClusterConfiguration::new));
}
