package com.blackgear.vanillabackport.common.level.block_entities;

import java.util.function.Predicate;
import net.minecraft.class_1262;
import net.minecraft.class_1263;
import net.minecraft.class_1799;
import net.minecraft.class_2371;

public interface ListBackedContainer extends class_1263 {
    class_2371<class_1799> getItems();
    
    default int count() {
        return (int) this.getItems().stream().filter(Predicate.not(class_1799::method_7960)).count();
    }
    
    @Override
    default int method_5439() {
        return this.getItems().size();
    }
    
    @Override
    default void method_5448() {
        this.getItems().clear();
    }
    
    @Override
    default boolean method_5442() {
        return this.getItems().stream().allMatch(class_1799::method_7960);
    }
    
    @Override
    default class_1799 method_5438(int slot) {
        return this.getItems().get(slot);
    }
    
    @Override
    default class_1799 method_5434(int slot, int count) {
        class_1799 result = class_1262.method_5430(this.getItems(), slot, count);
        if (!result.method_7960()) {
            this.method_5431();
        }
        
        return result;
    }
    
    @Override
    default class_1799 method_5441(int slot) {
        return class_1262.method_5430(this.getItems(), slot, this.method_5444());
    }
    
    @Override
    default boolean method_5437(int slot, class_1799 stack) {
        return this.acceptsItemType(stack) && (this.method_5438(slot).method_7960() || this.method_5438(slot).method_7947() < this.method_58350(stack));
    }
    
    default boolean acceptsItemType(class_1799 stack) {
        return true;
    }
    
    @Override
    default void method_5447(int slot, class_1799 stack) {
        this.setItemNoUpdate(slot, stack);
        this.method_5431();
    }
    
    default void setItemNoUpdate(int slot, class_1799 stack) {
        this.getItems().set(slot, stack);
        int maxSize = this.method_58350(stack);
        if (!stack.method_7960() && stack.method_7947() > maxSize)
            stack.method_7939(maxSize);
    }
}