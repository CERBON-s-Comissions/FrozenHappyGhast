package com.blackgear.vanillabackport.common.level.worldgen.features;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_3037;
import net.minecraft.class_4651;
import net.minecraft.class_4662;
import net.minecraft.class_6017;

public class FallenTreeConfiguration implements class_3037 {
    public static final Codec<FallenTreeConfiguration> CODEC = RecordCodecBuilder.create(
        instance -> instance.group(
                class_4651.field_24937.fieldOf("trunk_provider").forGetter(config -> config.trunkProvider),
                class_6017.method_35004(0, 16).fieldOf("log_length").forGetter(config -> config.logLength),
                class_4662.field_24962.listOf().fieldOf("stump_decorators").forGetter(config -> config.stumpDecorators),
                class_4662.field_24962.listOf().fieldOf("log_decorators").forGetter(config -> config.logDecorators)
            )
            .apply(instance, FallenTreeConfiguration::new)
    );
    public final class_4651 trunkProvider;
    public final class_6017 logLength;
    public final List<class_4662> stumpDecorators;
    public final List<class_4662> logDecorators;

    protected FallenTreeConfiguration(class_4651 trunkProvider, class_6017 logLength, List<class_4662> stumpDecorators, List<class_4662> logDecorators) {
        this.trunkProvider = trunkProvider;
        this.logLength = logLength;
        this.stumpDecorators = stumpDecorators;
        this.logDecorators = logDecorators;
    }

    public static class FallenTreeConfigurationBuilder {
        private final class_4651 trunkProvider;
        private final class_6017 logLength;
        private final List<class_4662> stumpDecorators = new ArrayList<>();
        private final List<class_4662> logDecorators = new ArrayList<>();

        public FallenTreeConfigurationBuilder(class_4651 trunkProvider, class_6017 logLength) {
            this.trunkProvider = trunkProvider;
            this.logLength = logLength;
        }

        public FallenTreeConfigurationBuilder stumpDecorator(class_4662 decorator) {
            this.stumpDecorators.add(decorator);
            return this;
        }
        
        public FallenTreeConfigurationBuilder logDecorator(class_4662 decorator) {
            this.logDecorators.add(decorator);
            return this;
        }

        public FallenTreeConfiguration build() {
            return new FallenTreeConfiguration(this.trunkProvider, this.logLength, this.stumpDecorators, this.logDecorators);
        }
    }
}