package com.blackgear.vanillabackport.common.level.worldgen.features;

import com.mojang.serialization.Codec;
import java.util.Optional;
import java.util.OptionalInt;
import net.minecraft.class_1936;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2353;
import net.minecraft.class_2680;
import net.minecraft.class_3031;
import net.minecraft.class_3481;
import net.minecraft.class_3486;
import net.minecraft.class_3532;
import net.minecraft.class_4538;
import net.minecraft.class_5281;
import net.minecraft.class_5721;
import net.minecraft.class_5819;
import net.minecraft.class_5821;
import net.minecraft.class_5861;

public class SpeleothemClusterFeature extends class_3031<SpeleothemClusterConfiguration> {
    public SpeleothemClusterFeature(Codec<SpeleothemClusterConfiguration> codec) {
        super(codec);
    }

    public boolean method_13151(class_5821<SpeleothemClusterConfiguration> context) {
        class_5281 level = context.method_33652();
        class_2338 origin = context.method_33655();
        SpeleothemClusterConfiguration config = context.method_33656();
        class_5819 random = context.method_33654();
        if (!SpeleothemUtils.isEmptyOrWater(level, origin)) {
            return false;
        } else {
            int height = config.height().method_35008(random);
            float wetness = config.wetness().method_33920(random);
            float density = config.density().method_33920(random);
            int xRadius = config.radius().method_35008(random);
            int zRadius = config.radius().method_35008(random);

            for (int x = -xRadius; x <= xRadius; ++x) {
                for (int z = -zRadius; z <= zRadius; ++z) {
                    double chanceOfStalagmiteOrStalactite = this.getChanceOfStalagmiteOrStalactite(xRadius, zRadius, x, z, config);
                    class_2338 pos = origin.method_10069(x, 0, z);
                    this.placeColumn(level, random, pos, x, z, wetness, chanceOfStalagmiteOrStalactite, height, density, config);
                }
            }

            return true;
        }
    }

    private void placeColumn(
        class_5281 level,
        class_5819 random,
        class_2338 pos,
        int x,
        int z,
        float wetness,
        double chanceOfStalagmiteOrStalactite,
        int height,
        float density,
        SpeleothemClusterConfiguration config
    ) {
        Optional<class_5721> baseColumn = class_5721.method_32982(level, pos, config.floorToCeilingSearchRange(), SpeleothemUtils::isEmptyOrWater, SpeleothemUtils::isNeitherEmptyNorWater);
        if (baseColumn.isPresent()) {
            OptionalInt ceiling = baseColumn.get().method_32985();
            OptionalInt baseFloor = baseColumn.get().method_32987();
            if (ceiling.isPresent() || baseFloor.isPresent()) {
                boolean wantPool = random.method_43057() < wetness;
                class_5721 column;
                if (wantPool && baseFloor.isPresent() && this.canPlacePool(level, pos.method_33096(baseFloor.getAsInt()), config)) {
                    int baseFloorY = baseFloor.getAsInt();
                    column = baseColumn.get().method_32983(OptionalInt.of(baseFloorY - 1));
                    level.method_8652(pos.method_33096(baseFloorY), class_2246.field_10382.method_9564(), 2);
                } else {
                    column = baseColumn.get();
                }

                OptionalInt floor = column.method_32987();
                boolean wantStalactite = random.method_43058() < chanceOfStalagmiteOrStalactite;
                int stalactiteHeight;
                if (ceiling.isPresent() && wantStalactite && !this.isLava(level, pos.method_33096(ceiling.getAsInt()))) {
                    int ceilingThickness = config.speleothemBlockLayerThickness().method_35008(random);
                    this.replaceBlocksWithBaseBlocks(level, pos.method_33096(ceiling.getAsInt()), ceilingThickness, class_2350.field_11036, config);
                    int maxHeightForThisColumn;
                    if (floor.isPresent()) {
                        maxHeightForThisColumn = Math.min(height, ceiling.getAsInt() - floor.getAsInt());
                    } else {
                        maxHeightForThisColumn = height;
                    }

                    stalactiteHeight = this.getSpeleothemHeight(random, x, z, density, maxHeightForThisColumn, config);
                } else {
                    stalactiteHeight = 0;
                }

                boolean wantStalagmite = random.method_43058() < chanceOfStalagmiteOrStalactite;
                int stalagmiteHeight;
                if (floor.isPresent() && wantStalagmite && !this.isLava(level, pos.method_33096(floor.getAsInt()))) {
                    stalagmiteHeight = config.speleothemBlockLayerThickness().method_35008(random);
                    this.replaceBlocksWithBaseBlocks(level, pos.method_33096(floor.getAsInt()), stalagmiteHeight, class_2350.field_11033, config);
                    if (ceiling.isPresent()) {
                        stalagmiteHeight = Math.max(0, stalactiteHeight + class_3532.method_32751(random, -config.maxStalagmiteStalactiteHeightDiff(), config.maxStalagmiteStalactiteHeightDiff()));
                    } else {
                        stalagmiteHeight = this.getSpeleothemHeight(random, x, z, density, height, config);
                    }
                } else {
                    stalagmiteHeight = 0;
                }

                int actualStalactiteHeight;
                int actualStalagmiteHeight;
                if (ceiling.isPresent() && floor.isPresent() && ceiling.getAsInt() - stalactiteHeight <= floor.getAsInt() + stalagmiteHeight) {
                    int floorY = floor.getAsInt();
                    int ceilingY = ceiling.getAsInt();
                    int lowestStalactiteBottom = Math.max(ceilingY - stalactiteHeight, floorY + 1);
                    int highestStalagmiteTop = Math.min(floorY + stalagmiteHeight, ceilingY - 1);
                    int actualStalactiteBottom = class_3532.method_32751(random, lowestStalactiteBottom, highestStalagmiteTop + 1);
                    int actualStalagmiteTop = actualStalactiteBottom - 1;
                    actualStalactiteHeight = ceilingY - actualStalactiteBottom;
                    actualStalagmiteHeight = actualStalagmiteTop - floorY;
                } else {
                    actualStalactiteHeight = stalactiteHeight;
                    actualStalagmiteHeight = stalagmiteHeight;
                }

                boolean mergeTips = random.method_43056()
                    && actualStalactiteHeight > 0
                    && actualStalagmiteHeight > 0
                    && column.method_33385().isPresent()
                    && actualStalactiteHeight + actualStalagmiteHeight == column.method_33385().getAsInt();
                if (ceiling.isPresent()) {
                    SpeleothemUtils.growSpeleothem(
                        level,
                        pos.method_33096(ceiling.getAsInt() - 1),
                        class_2350.field_11033,
                        actualStalactiteHeight,
                        mergeTips,
                        config.baseBlock().method_26204(),
                        config.pointedBlock().method_26204(),
                        config.replaceableBlocks()
                    );
                }

                if (floor.isPresent()) {
                    SpeleothemUtils.growSpeleothem(
                        level,
                        pos.method_33096(floor.getAsInt() + 1),
                        class_2350.field_11036,
                        actualStalagmiteHeight,
                        mergeTips,
                        config.baseBlock().method_26204(),
                        config.pointedBlock().method_26204(),
                        config.replaceableBlocks()
                    );
                }
            }
        }
    }

    private boolean isLava(class_4538 level, class_2338 pos) {
        return level.method_8320(pos).method_27852(class_2246.field_10164);
    }

    private int getSpeleothemHeight(
        class_5819 random,
        int x,
        int z,
        float chance,
        int height,
        SpeleothemClusterConfiguration config
    ) {
        if (random.method_43057() > chance) {
            return 0;
        } else {
            int distanceFromCenter = Math.abs(x) + Math.abs(z);
            float heightMean = (float) class_3532.method_32854(distanceFromCenter, 0.0, config.maxDistanceFromCenterAffectingHeightBias(), height / 2.0, 0.0);
            return (int) randomBetweenBiased(random, 0.0F, height, heightMean, config.heightDeviation());
        }
    }

    private boolean canPlacePool(class_5281 level, class_2338 pos, SpeleothemClusterConfiguration config) {
        class_2680 state = level.method_8320(pos);
        if (!state.method_27852(class_2246.field_10382) && !state.method_27852(config.baseBlock().method_26204()) && !state.method_27852(config.pointedBlock().method_26204())) {
            if (level.method_8320(pos.method_10084()).method_26227().method_15767(class_3486.field_15517)) {
                return false;
            } else {
                for (class_2350 direction : class_2353.field_11062) {
                    if (!this.canBeAdjacentToWater(level, pos.method_10093(direction))) {
                        return false;
                    }
                }

                return this.canBeAdjacentToWater(level, pos.method_10074());
            }
        } else {
            return false;
        }
    }

    private boolean canBeAdjacentToWater(class_1936 level, class_2338 pos) {
        class_2680 blockState = level.method_8320(pos);
        return blockState.method_26164(class_3481.field_25806) || blockState.method_26227().method_15767(class_3486.field_15517);
    }

    private void replaceBlocksWithBaseBlocks(
        class_5281 level,
        class_2338 origin,
        int maxCount,
        class_2350 direction,
        SpeleothemClusterConfiguration config
    ) {
        class_2338.class_2339 pos = origin.method_25503();

        for (int i = 0; i < maxCount; ++i) {
            if (!SpeleothemUtils.placeBaseBlockIfPossible(level, pos, config.baseBlock().method_26204(), config.replaceableBlocks())) {
                return;
            }

            pos.method_10098(direction);
        }

    }

    private double getChanceOfStalagmiteOrStalactite(
        int xRadius,
        int zRadius,
        int x,
        int z,
        SpeleothemClusterConfiguration config
    ) {
        int xDistanceFromEdge = xRadius - Math.abs(x);
        int zDistanceFromEdge = zRadius - Math.abs(z);
        int distanceFromEdge = Math.min(xDistanceFromEdge, zDistanceFromEdge);
        return class_3532.method_37958((float) distanceFromEdge, 0.0F, (float) config.maxDistanceFromEdgeAffectingChanceOfSpeleothemColumn(), config.chanceOfSpeleothemColumnAtMaxDistanceFromCenter(), 1.0F);
    }

    private static float randomBetweenBiased(class_5819 random, float min, float max, float mean, float deviation) {
        return class_5861.method_33903(random, mean, deviation, min, max);
    }
}
