package com.blackgear.vanillabackport.common.level.entities.mob.monster.creaking;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import com.mojang.datafixers.util.Pair;
import net.minecraft.class_1308;
import net.minecraft.class_3218;
import net.minecraft.class_4095;
import net.minecraft.class_4101;
import net.minecraft.class_4110;
import net.minecraft.class_4112;
import net.minecraft.class_4118;
import net.minecraft.class_4120;
import net.minecraft.class_4125;
import net.minecraft.class_4140;
import net.minecraft.class_4148;
import net.minecraft.class_4149;
import net.minecraft.class_4168;
import net.minecraft.class_4818;
import net.minecraft.class_4822;
import net.minecraft.class_4824;
import net.minecraft.class_4828;
import net.minecraft.class_6019;
import net.minecraft.class_7895;
import net.minecraft.world.entity.ai.behavior.*;

public class CreakingAi {
    protected static final ImmutableList<? extends class_4149<? extends class_4148<? super Creaking>>> SENSOR_TYPES = ImmutableList.of(
        class_4149.field_18466,
        class_4149.field_18467);
    protected static final ImmutableList<? extends class_4140<?>> MEMORY_TYPES = ImmutableList.of(
        class_4140.field_18441,
        class_4140.field_18442,
        class_4140.field_18444,
        class_4140.field_22354,
        class_4140.field_18446,
        class_4140.field_18445,
        class_4140.field_19293,
        class_4140.field_18449,
        class_4140.field_22355,
        class_4140.field_22475);

    static void initCoreActivity(class_4095<Creaking> brain) {
        brain.method_18882(
            class_4168.field_18594,
            0,
            ImmutableList.of(
                new class_4125(0.8F) {
                    @Override protected boolean method_19010(class_3218 level, class_1308 owner) {
                        return owner instanceof Creaking creaking && creaking.canMove() && super.method_19010(level, owner);
                    }
                },
                new class_4110(45, 90),
                new class_4112()
            )
        );
    }

    static void initIdleActivity(class_4095<Creaking> brain) {
        brain.method_18882(
            class_4168.field_18595,
            10,
            ImmutableList.of(
                class_4824.method_47120(Creaking::isActive, creaking -> creaking.method_18868().method_18904(class_4140.field_22354)),
                class_7895.method_47067(8.0F, class_6019.method_35017(30, 60)),
                new class_4118<>(ImmutableList.of(
                    Pair.of(class_4818.method_47014(0.3F), 2),
                    Pair.of(class_4120.method_47104(0.3F, 3), 2),
                    Pair.of(new class_4101(30, 60), 1)
                ))
            )
        );
    }

    static void initFightActivity(class_4095<Creaking> brain) {
        brain.method_24527(
            class_4168.field_22396,
            10,
            ImmutableList.of(
                class_4822.method_47094(1.0F),
                CreakingMeleeAttack.create(Creaking::canMove, 40),
                class_4828.method_47132()
            ),
            class_4140.field_22355
        );
    }

    public static class_4095.class_5303<Creaking> brainProvider() {
        return class_4095.method_28311(MEMORY_TYPES, SENSOR_TYPES);
    }

    public static class_4095<Creaking> makeBrain(class_4095<Creaking> brain) {
        initCoreActivity(brain);
        initIdleActivity(brain);
        initFightActivity(brain);
        brain.method_18890(ImmutableSet.of(class_4168.field_18594));
        brain.method_18897(class_4168.field_18595);
        brain.method_24536();
        return brain;
    }

    public static void updateActivity(Creaking creaking) {
        if (!creaking.canMove()) {
            creaking.method_18868().method_24536();
        } else {
            creaking.method_18868().method_24531(ImmutableList.of(class_4168.field_22396, class_4168.field_18595));
        }
    }
}