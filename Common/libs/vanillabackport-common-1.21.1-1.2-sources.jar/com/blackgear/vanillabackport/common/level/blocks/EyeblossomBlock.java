package com.blackgear.vanillabackport.common.level.blocks;

import com.blackgear.vanillabackport.client.level.particle.particleoptions.TrailParticleOption;
import com.blackgear.vanillabackport.client.registries.ModSoundEvents;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import com.blackgear.vanillabackport.core.util.WorldUtilities.EnvironmentUtils;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_1267;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2356;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_4466;
import net.minecraft.class_4970;
import net.minecraft.class_5712;
import net.minecraft.class_5819;
import net.minecraft.class_6880;

public class EyeblossomBlock extends class_2356 {
    private final Type type;

    public EyeblossomBlock(Type type, class_2251 properties) {
        super(type.effect, type.effectDuration, properties);
        this.type = type;
    }

    public EyeblossomBlock(boolean open, class_4970.class_2251 properties) {
        super(Type.fromBoolean(open).effect, Type.fromBoolean(open).effectDuration, properties);
        this.type = Type.fromBoolean(open);
    }

    @Override
    public void method_9496(class_2680 state, class_1937 level, class_2338 pos, class_5819 random) {
        if (this.type.emitSounds() && random.method_43048(700) == 0) {
            class_2680 below = level.method_8320(pos.method_10074());
            if (below.method_27852(ModBlocks.PALE_MOSS_BLOCK.get())) {
                level.method_8486(pos.method_10263(), pos.method_10264(), pos.method_10260(), ModSoundEvents.EYEBLOSSOM_IDLE.get(), class_3419.field_15245, 1.0F, 1.0F, false);
            }
        }
    }

    @Override
    public void method_9514(class_2680 state, class_3218 level, class_2338 pos, class_5819 random) {
        if (this.tryChangingState(state, level, pos, random)) {
            level.method_8396(null, pos, this.type.transform().longSwitchSound, class_3419.field_15245, 1.0F, 1.0F);
        }

        super.method_9514(state, level, pos, random);
    }

    @Override
    public void method_9588(class_2680 state, class_3218 level, class_2338 pos, class_5819 random) {
        if (this.tryChangingState(state, level, pos, random)) {
            level.method_8396(null, pos, this.type.transform().shortSwitchSound, class_3419.field_15245, 1.0F, 1.0F);
        }

        super.method_9588(state, level, pos, random);
    }

    private boolean tryChangingState(class_2680 state, class_3218 level, class_2338 origin, class_5819 random) {
        boolean shouldBeOpen = EnvironmentUtils.isNaturalNight(level);
        if (shouldBeOpen == this.type.open) {
            return false;
        } else {
            Type newType = this.type.transform();
            level.method_8501(origin, newType.state());
            level.method_43276(class_5712.field_28733, origin, class_5712.class_7397.method_43287(state));
            newType.spawnTransformParticle(level, origin, random);
            class_2338.method_10097(origin.method_10069(-3, -2, -3), origin.method_10069(3, 2, 3)).forEach(nearbyPos -> {
                class_2680 nearbyState = level.method_8320(nearbyPos);
                if (nearbyState == state) {
                    double distance = Math.sqrt(origin.method_10262(nearbyPos));
                    int delay = random.method_39332((int) (distance * 5.0), (int) (distance * 10.0));
                    level.method_39279(nearbyPos, state.method_26204(), delay);
                }
            });
            return true;
        }
    }

    @Override
    public void method_9548(class_2680 state, class_1937 level, class_2338 pos, class_1297 entity) {
        if (!level.method_8608()
            && level.method_8407() != class_1267.field_5801
            && entity instanceof class_4466 bee
            && !bee.method_6059(class_1294.field_5899)
        ) {
            bee.method_6092(new class_1293(class_1294.field_5899, 25));
        }
    }
    
    @Override
    public MapCodec<? extends EyeblossomBlock> method_53969() {
        return RecordCodecBuilder.mapCodec(instance -> instance.group(Codec.BOOL.fieldOf("open").forGetter(block -> block.type.open), method_54096()).apply(instance, EyeblossomBlock::new));
    }

    public enum Type {
        OPEN(true, class_1294.field_5919, 11.0F, ModSoundEvents.EYEBLOSSOM_OPEN_LONG.get(), ModSoundEvents.EYEBLOSSOM_OPEN.get(), 16545810),
        CLOSED(false, class_1294.field_5916, 7.0F, ModSoundEvents.EYEBLOSSOM_CLOSE_LONG.get(), ModSoundEvents.EYEBLOSSOM_CLOSE.get(), 6250335);

        final boolean open;
        final class_6880<class_1291> effect;
        final float effectDuration;
        final class_3414 longSwitchSound;
        final class_3414 shortSwitchSound;
        final int particleColor;

        Type(boolean open, class_6880<class_1291> effect, float effectDuration, class_3414 longSwitchSound, class_3414 shortSwitchSound, int particleColor) {
            this.open = open;
            this.effect = effect;
            this.effectDuration = effectDuration;
            this.longSwitchSound = longSwitchSound;
            this.shortSwitchSound = shortSwitchSound;
            this.particleColor = particleColor;
        }

        public class_2248 block() {
            return this.open ? ModBlocks.OPEN_EYEBLOSSOM.get() : ModBlocks.CLOSED_EYEBLOSSOM.get();
        }

        public class_2680 state() {
            return this.block().method_9564();
        }

        public Type transform() {
            return fromBoolean(!this.open);
        }

        public boolean emitSounds() {
            return this.open;
        }

        public static Type fromBoolean(boolean open) {
            return open ? OPEN : CLOSED;
        }

        public void spawnTransformParticle(class_3218 level, class_2338 pos, class_5819 random) {
            class_243 start = pos.method_46558();
            double lifetime = 0.5 + random.method_43058();
            class_243 velocity = new class_243(random.method_43058() - 0.5, random.method_43058() + 1.0, random.method_43058() - 0.5);
            class_243 target = start.method_1019(velocity.method_1021(lifetime));
            TrailParticleOption particle = new TrailParticleOption(target, this.particleColor, (int) (20.0 * lifetime));
            level.method_14199(particle, start.field_1352, start.field_1351, start.field_1350, 1, 0.0, 0.0, 0.0, 0.0);
        }

        public class_3414 longSwitchSound() {
            return this.longSwitchSound;
        }
    }
}