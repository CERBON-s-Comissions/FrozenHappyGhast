package com.blackgear.vanillabackport.common.level.entities.mob.animal.golem.copper_golem;

import com.mojang.serialization.Codec;
import io.netty.buffer.ByteBuf;
import java.util.function.IntFunction;
import net.minecraft.class_3542;
import net.minecraft.class_7995;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public enum CopperGolemState implements class_3542 {
    IDLE("idle", 0),
    GETTING_ITEM("getting_item", 1),
    GETTING_NO_ITEM("getting_no_item", 2),
    DROPPING_ITEM("dropping_item", 3),
    DROPPING_NO_ITEM("dropping_no_item", 4);

    public static final Codec<CopperGolemState> CODEC = class_3542.method_28140(CopperGolemState::values);
    private static final IntFunction<CopperGolemState> BY_ID = class_7995.method_47914(CopperGolemState::id, values(), class_7995.class_7996.field_41664);
    public static final class_9139<ByteBuf, CopperGolemState> STREAM_CODEC = class_9135.method_56375(BY_ID, CopperGolemState::id);
    private final String name;
    private final int id;

    CopperGolemState(String name, int id) {
        this.name = name;
        this.id = id;
    }

    @Override
    public String method_15434() {
        return this.name;
    }

    public int id() {
        return this.id;
    }
}