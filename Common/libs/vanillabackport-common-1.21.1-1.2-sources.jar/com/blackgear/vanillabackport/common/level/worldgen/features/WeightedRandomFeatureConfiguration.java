package com.blackgear.vanillabackport.common.level.worldgen.features;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.stream.Stream;
import net.minecraft.class_2975;
import net.minecraft.class_3037;
import net.minecraft.class_6005;
import net.minecraft.class_6796;
import net.minecraft.class_6880;

public record WeightedRandomFeatureConfiguration(class_6005<class_6880<class_6796>> features) implements class_3037 {
    public static final Codec<WeightedRandomFeatureConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group(
        class_6005.method_39521(class_6796.field_35730).fieldOf("features").forGetter(WeightedRandomFeatureConfiguration::features)
    ).apply(instance, WeightedRandomFeatureConfiguration::new));

    @Override
    public Stream<class_2975<?, ?>> method_30649() {
        return this.features.method_34994().stream().flatMap(weighted -> weighted.comp_2542().comp_349().method_39643());
    }
}