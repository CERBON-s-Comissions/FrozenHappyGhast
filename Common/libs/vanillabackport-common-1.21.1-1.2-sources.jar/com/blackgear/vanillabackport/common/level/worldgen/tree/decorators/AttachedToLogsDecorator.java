package com.blackgear.vanillabackport.common.level.worldgen.tree.decorators;

import com.blackgear.vanillabackport.common.registries.worldgen.ModTreeDecorators;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import net.minecraft.class_156;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_4651;
import net.minecraft.class_4662;
import net.minecraft.class_4663;
import net.minecraft.class_5699;
import net.minecraft.class_5819;

public class AttachedToLogsDecorator extends class_4662 {
    public static final MapCodec<AttachedToLogsDecorator> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
        Codec.floatRange(0.0F, 1.0F).fieldOf("probability").forGetter(decorator -> decorator.probability),
        class_4651.field_24937.fieldOf("block_provider").forGetter(decorator -> decorator.blockProvider),
        class_5699.method_36973(class_2350.field_29502.listOf()).fieldOf("directions").forGetter(decorator -> decorator.directions)
    ).apply(instance, AttachedToLogsDecorator::new));
    private final float probability;
    private final class_4651 blockProvider;
    private final List<class_2350> directions;

    public AttachedToLogsDecorator(float probability, class_4651 blockProvider, List<class_2350> directions) {
        this.probability = probability;
        this.blockProvider = blockProvider;
        this.directions = directions;
    }

    @Override
    public void method_23469(class_7402 context) {
        class_5819 random = context.method_43320();

        for (class_2338 logPos : class_156.method_43027(context.method_43321(), random)) {
            class_2350 direction = class_156.method_32309(this.directions, random);
            class_2338 placementPos = logPos.method_10093(direction);
            if (random.method_43057() <= this.probability && context.method_43317(placementPos)) {
                context.method_43318(placementPos, this.blockProvider.method_23455(random, placementPos));
            }
        }
    }

    @Override
    protected class_4663<?> method_28893() {
        return ModTreeDecorators.ATTACHED_TO_LOGS.get();
    }
}