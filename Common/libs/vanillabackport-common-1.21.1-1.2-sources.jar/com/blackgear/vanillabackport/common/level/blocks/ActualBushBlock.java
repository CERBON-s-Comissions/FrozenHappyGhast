package com.blackgear.vanillabackport.common.level.blocks;

import com.blackgear.vanillabackport.common.api.extensions.block.SpreadableBonemealableBlock;
import com.blackgear.vanillabackport.core.util.BlockShaper;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2261;
import net.minecraft.class_2338;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3726;
import net.minecraft.class_4538;
import net.minecraft.class_5819;

public class ActualBushBlock extends class_2261 implements SpreadableBonemealableBlock {
    private static final class_265 SHAPE = BlockShaper.column(16.0, 0.0, 13);

    public ActualBushBlock(class_2251 properties) {
        super(properties);
    }

    @Override
    protected MapCodec<? extends class_2261> method_53969() {
        return method_54094(ActualBushBlock::new);
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    @Override
    public boolean method_9651(class_4538 level, class_2338 pos, class_2680 state) {
        return SpreadableBonemealableBlock.hasSpreadableNeighbourPos(level, pos, state);
    }

    @Override
    public boolean method_9650(class_1937 level, class_5819 random, class_2338 pos, class_2680 state) {
        return true;
    }

    @Override
    public void method_9652(class_3218 level, class_5819 random, class_2338 pos, class_2680 state) {
        SpreadableBonemealableBlock.findSpreadableNeighbourPos(level, pos, state)
            .ifPresent(newPos -> level.method_8501(newPos, this.method_9564()));
    }
}