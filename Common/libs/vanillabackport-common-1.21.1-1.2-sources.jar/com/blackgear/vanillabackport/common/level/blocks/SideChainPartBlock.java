package com.blackgear.vanillabackport.common.level.blocks;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.IntFunction;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;

public interface SideChainPartBlock {
    SideChainPart getSideChainPart(class_2680 state);

    class_2680 setSideChainPart(class_2680 state, SideChainPart newPart);

    class_2350 getFacing(class_2680 state);

    boolean isConnectable(class_2680 state);

    int getMaxChainLength();

    default List<class_2338> getAllBlocksConnectedTo(class_1936 level, class_2338 pos) {
        class_2680 state = level.method_8320(pos);
        if (!this.isConnectable(state)) {
            return List.of();
        } else {
            Neighbors neighbors = this.getNeighbors(level, pos, this.getFacing(state));
            List<class_2338> results = new LinkedList<>();
            results.add(pos);
            this.addBlocksConnectingTowards(neighbors::left, SideChainPart.LEFT, results::addFirst);
            this.addBlocksConnectingTowards(neighbors::right, SideChainPart.RIGHT, results::addLast);
            return results;
        }
    }

    private void addBlocksConnectingTowards(IntFunction<Neighbor> getNeighbor, SideChainPart endPart, Consumer<class_2338> accumulator) {
        for (int steps = 1; steps < this.getMaxChainLength(); steps++) {
            Neighbor neighbor = getNeighbor.apply(steps);
            if (neighbor.connectsTowards(endPart)) {
                accumulator.accept(neighbor.pos());
            }

            if (neighbor.isUnconnectableOrChainEnd()) {
                break;
            }
        }
    }

    default void updateNeighborsAfterPoweringDown(class_1936 level, class_2338 pos, class_2680 state) {
        Neighbors neighbors = this.getNeighbors(level, pos, this.getFacing(state));
        neighbors.left().disconnectFromRight();
        neighbors.right().disconnectFromLeft();
    }

    default void updateSelfAndNeighborsOnPoweringUp(class_1936 level, class_2338 pos, class_2680 state, class_2680 oldState) {
        if (this.isConnectable(state)) {
            if (!this.isBeingUpdatedByNeighbor(state, oldState)) {
                Neighbors neighbors = this.getNeighbors(level, pos, this.getFacing(state));
                SideChainPart newPartForSelf = SideChainPart.UNCONNECTED;
                int existingChainOnTheLeft = neighbors.left().isConnectable() ? this.getAllBlocksConnectedTo(level, neighbors.left().pos()).size() : 0;
                int existingChainOnTheRight = neighbors.right().isConnectable() ? this.getAllBlocksConnectedTo(level, neighbors.right().pos()).size() : 0;
                int currentChainLength = 1;
                if (this.canConnect(existingChainOnTheLeft, currentChainLength)) {
                    newPartForSelf = newPartForSelf.whenConnectedToTheLeft();
                    neighbors.left().connectToTheRight();
                    currentChainLength += existingChainOnTheLeft;
                }

                if (this.canConnect(existingChainOnTheRight, currentChainLength)) {
                    newPartForSelf = newPartForSelf.whenConnectedToTheRight();
                    neighbors.right().connectToTheLeft();
                }

                this.setPart(level, pos, newPartForSelf);
            }
        }
    }

    private boolean canConnect(int newBlocksToConnectTo, int currentChainLength) {
        return newBlocksToConnectTo > 0 && currentChainLength + newBlocksToConnectTo <= this.getMaxChainLength();
    }

    private boolean isBeingUpdatedByNeighbor(class_2680 state, class_2680 oldState) {
        boolean isGettingConnected = this.getSideChainPart(state).isConnected();
        boolean hasBeenConnectedBefore = this.isConnectable(oldState) && this.getSideChainPart(oldState).isConnected();
        return isGettingConnected || hasBeenConnectedBefore;
    }

    private Neighbors getNeighbors(class_1936 level, class_2338 center, class_2350 facing) {
        return new Neighbors(this, level, facing, center, new HashMap<>());
    }

    private void setPart(class_1936 level, class_2338 pos, SideChainPart part) {
        class_2680 state = level.method_8320(pos);
        if (this.getSideChainPart(state) != part) {
            level.method_8652(pos, this.setSideChainPart(state, part), 3);
        }
    }

    interface Neighbor {
        class_2338 pos();

        boolean isConnectable();

        boolean isUnconnectableOrChainEnd();

        boolean connectsTowards(SideChainPart endPart);

        default void connectToTheRight() {
        }

        default void connectToTheLeft() {
        }

        default void disconnectFromRight() {
        }

        default void disconnectFromLeft() {
        }
    }

    record Neighbors(SideChainPartBlock block, class_1936 level, class_2350 facing, class_2338 center, Map<class_2338, Neighbor> cache) {
        private boolean isConnectableToThisBlock(class_2680 neighbor) {
            return this.block.isConnectable(neighbor) && this.block.getFacing(neighbor) == this.facing;
        }

        private Neighbor createNewNeighbor(class_2338 pos) {
            class_2680 neighbor = this.level.method_8320(pos);
            SideChainPart part = this.isConnectableToThisBlock(neighbor) ? this.block.getSideChainPart(neighbor) : null;
            return part == null
                ? new EmptyNeighbor(pos)
                : new SideChainNeighbor(this.level, this.block, pos, part);
        }

        private Neighbor getOrCreateNeighbor(class_2350 direction, int steps) {
            return this.cache.computeIfAbsent(this.center.method_10079(direction, steps), this::createNewNeighbor);
        }

        public Neighbor left(int steps) {
            return this.getOrCreateNeighbor(this.facing.method_10170(), steps);
        }

        public Neighbor right(int steps) {
            return this.getOrCreateNeighbor(this.facing.method_10160(), steps);
        }

        public Neighbor left() {
            return this.left(1);
        }

        public Neighbor right() {
            return this.right(1);
        }
    }

    record EmptyNeighbor(class_2338 pos) implements Neighbor {
        @Override
        public boolean isConnectable() {
            return false;
        }

        @Override
        public boolean isUnconnectableOrChainEnd() {
            return true;
        }

        @Override
        public boolean connectsTowards(SideChainPart endPart) {
            return false;
        }
    }

    record SideChainNeighbor(class_1936 level, SideChainPartBlock block, class_2338 pos, SideChainPart part) implements Neighbor {
        @Override
        public boolean isConnectable() {
            return true;
        }

        @Override
        public boolean isUnconnectableOrChainEnd() {
            return this.part.isChainEnd();
        }

        @Override
        public boolean connectsTowards(SideChainPart endPart) {
            return this.part.isConnectionTowards(endPart);
        }

        @Override
        public void connectToTheRight() {
            this.block.setPart(this.level, this.pos, this.part.whenConnectedToTheRight());
        }

        @Override
        public void connectToTheLeft() {
            this.block.setPart(this.level, this.pos, this.part.whenConnectedToTheLeft());
        }

        @Override
        public void disconnectFromRight() {
            this.block.setPart(this.level, this.pos, this.part.whenDisconnectedFromTheRight());
        }

        @Override
        public void disconnectFromLeft() {
            this.block.setPart(this.level, this.pos, this.part.whenDisconnectedFromTheLeft());
        }
    }
}