package com.blackgear.vanillabackport.common.level.blocks;

import com.blackgear.vanillabackport.client.registries.ModSoundEvents;
import com.blackgear.vanillabackport.core.util.BlockShaper;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_1269;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_156;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_1941;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_243;
import net.minecraft.class_2464;
import net.minecraft.class_2561;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2742;
import net.minecraft.class_2746;
import net.minecraft.class_2754;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_3532;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_4732;
import net.minecraft.class_4970;
import net.minecraft.class_5275;
import net.minecraft.world.level.block.*;
import org.apache.commons.lang3.ArrayUtils;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.Optional;

public class StrawBedBlock extends class_2383 {
    public static final MapCodec<StrawBedBlock> CODEC = method_54094(StrawBedBlock::new);
    public static final class_2754<class_2742> PART = class_2741.field_12483;
    public static final class_2746 OCCUPIED = class_2741.field_12528;
    
    private static final class_265 BASE_SHAPE = BlockShaper.column(16.0, 0.0, 4.0);
    private static final class_265 PILLOW_SHAPE = class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 5.0, 8.0);
    private static final Map<class_2350, class_265> FOOT_SHAPES = class_156.method_656(() -> BlockShaper.rotateHorizontal(BASE_SHAPE));
    private static final Map<class_2350, class_265> HEAD_SHAPES = class_156.method_656(() -> BlockShaper.rotateHorizontal(class_259.method_1084(BASE_SHAPE, PILLOW_SHAPE)));
    
    public StrawBedBlock(class_4970.class_2251 properties) {
        super(properties);
        this.method_9590(this.field_10647.method_11664()
            .method_11657(field_11177, class_2350.field_11043)
            .method_11657(PART, class_2742.field_12557)
            .method_11657(OCCUPIED, false));
    }
    
    @Override
    protected MapCodec<? extends class_2383> method_53969() {
        return field_46280;
    }
    
    @Override
    protected class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }
    
    @Override
    protected class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        Map<class_2350, class_265> shapes = state.method_11654(PART) == class_2742.field_12560 ? HEAD_SHAPES : FOOT_SHAPES;
        return shapes.get(getConnectedDirection(state).method_10153());
    }
    
    private void destroyBed(class_1937 level, class_2338 pos) {
        level.method_8396(null, pos, ModSoundEvents.STRAW_BED_BREAK_LEAVE.get(), class_3419.field_15245, 1.0F, 1.0F);
        level.method_8501(pos, class_2246.field_10124.method_9564());
    }
    
    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hitResult) {
        if (level.method_8608()) return class_1269.field_5812;
        
        class_2742 part = state.method_11654(PART);
        class_2338 otherPos = pos.method_10093(getNeighbourDirection(part, state.method_11654(field_11177)));
        class_2680 otherState = level.method_8320(otherPos);
        
        if (!otherState.method_27852(this) || otherState.method_11654(PART) == part) {
            return class_1269.field_21466;
        }
        
        if (part != class_2742.field_12560) {
            pos = otherPos;
            state = otherState;
        }
        
        if (!level.method_8597().comp_648()) {
            this.destroyBed(level, pos);
            return class_1269.field_5812;
        }
        
        if (state.method_11654(OCCUPIED)) {
            player.method_7353(class_2561.method_43471("block.minecraft.bed.occupied"), true);
            return class_1269.field_5812;
        }
        
        player.method_7269(pos).ifLeft(problem -> {
            if (problem.method_19206() != null) {
                player.method_7353(problem.method_19206(), true);
            }
        }).ifRight(unit -> player.method_7281(class_3468.field_15381));
        
        return class_1269.field_5812;
    }
    
    public void onStopSleeping(class_1937 level, class_2338 pos) {
        this.destroyBed(level, pos);
    }
    
    @Override
    protected class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 level, class_2338 pos, class_2338 neighborPos) {
        if (direction == getNeighbourDirection(state.method_11654(PART), state.method_11654(field_11177))) {
            return neighborState.method_27852(this) && neighborState.method_11654(PART) != state.method_11654(PART)
                ? state.method_11657(OCCUPIED, neighborState.method_11654(OCCUPIED))
                : class_2246.field_10124.method_9564();
        }
        return super.method_9559(state, direction, neighborState, level, pos, neighborPos);
    }
    
    private static class_2350 getNeighbourDirection(class_2742 part, class_2350 facing) {
        return part == class_2742.field_12557 ? facing : facing.method_10153();
    }
    
    public static class_2350 getConnectedDirection(class_2680 state) {
        class_2350 facing = state.method_11654(field_11177);
        return state.method_11654(PART) == class_2742.field_12560 ? facing.method_10153() : facing;
    }
    
    @Override
    public class_2680 method_9576(class_1937 level, class_2338 pos, class_2680 state, class_1657 player) {
        if (!level.method_8608() && player.method_7337()) {
            class_2742 part = state.method_11654(PART);
            if (part == class_2742.field_12557) {
                class_2338 headPos = pos.method_10093(getNeighbourDirection(part, state.method_11654(field_11177)));
                class_2680 headState = level.method_8320(headPos);
                if (headState.method_27852(this) && headState.method_11654(PART) == class_2742.field_12560) {
                    level.method_8652(headPos, class_2246.field_10124.method_9564(), 35);
                    level.method_8444(player, 2001, headPos, class_2248.method_9507(headState));
                }
            }
        }
        return super.method_9576(level, pos, state, player);
    }
    
    @Override
    public void method_9567(class_1937 level, class_2338 pos, class_2680 state, @Nullable class_1309 placer, class_1799 stack) {
        super.method_9567(level, pos, state, placer, stack);
        class_2338 headPos = pos.method_10093(state.method_11654(field_11177));
        level.method_8501(headPos, state.method_11657(PART, class_2742.field_12560));
    }
    
    @Nullable
    @Override
    public class_2680 method_9605(class_1750 context) {
        class_2350 facing = context.method_8042();
        class_2338 pos = context.method_8037();
        class_2338 relative = pos.method_10093(facing);
        class_1937 level = context.method_8045();
        
        return level.method_8320(relative).method_26166(context) && level.method_8621().method_11952(relative)
            ? this.method_9564().method_11657(field_11177, facing)
            : null;
    }
    
    @Override
    protected long method_9535(class_2680 state, class_2338 pos) {
        class_2338 sourcePos = pos.method_10079(state.method_11654(field_11177), state.method_11654(PART) == class_2742.field_12560 ? 0 : 1);
        return class_3532.method_15371(sourcePos.method_10263(), pos.method_10264(), sourcePos.method_10260());
    }
    
    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(field_11177, PART, OCCUPIED);
    }
    
    public static class_4732.class_4733 getBlockType(class_2680 state) {
        return state.method_11654(PART) == class_2742.field_12560 ? class_4732.class_4733.field_21784 : class_4732.class_4733.field_21785;
    }
    
    private static boolean isBunkBed(class_1922 level, class_2338 pos) {
        return level.method_8320(pos.method_10074()).method_26204() instanceof StrawBedBlock;
    }
    
    public static Optional<class_243> findStandUpPosition(class_1299<?> type, class_1941 level, class_2338 pos, class_2350 forward, float yaw) {
        class_2350 right = forward.method_10170();
        class_2350 side = right.method_30928(yaw) ? right.method_10153() : right;
        if (isBunkBed(level, pos)) {
            return findBunkBedStandUpPosition(type, level, pos, forward, side);
        } else {
            int[][] offsets = bedStandUpOffsets(forward, side);
            Optional<class_243> safePosition = findStandUpPositionAtOffset(type, level, pos, offsets, true);
            return safePosition.isPresent() ? safePosition : findStandUpPositionAtOffset(type, level, pos, offsets, false);
        }
    }
    
    private static Optional<class_243> findBunkBedStandUpPosition(class_1299<?> type, class_1941 level, class_2338 pos, class_2350 forward, class_2350 side) {
        int[][] offsets = bedSurroundStandUpOffsets(forward, side);
        Optional<class_243> safePosition = findStandUpPositionAtOffset(type, level, pos, offsets, true);
        if (safePosition.isPresent()) {
            return safePosition;
        } else {
            class_2338 below = pos.method_10074();
            Optional<class_243> belowSafePosition = findStandUpPositionAtOffset(type, level, below, offsets, true);
            if (belowSafePosition.isPresent()) {
                return belowSafePosition;
            } else {
                int[][] aboveOffsets = bedAboveStandUpOffsets(forward);
                Optional<class_243> aboveSafePosition = findStandUpPositionAtOffset(type, level, pos, aboveOffsets, true);
                if (aboveSafePosition.isPresent()) {
                    return aboveSafePosition;
                } else {
                    Optional<class_243> unsafePosition = findStandUpPositionAtOffset(type, level, pos, offsets, false);
                    if (unsafePosition.isPresent()) {
                        return unsafePosition;
                    } else {
                        Optional<class_243> belowUnsafePosition = findStandUpPositionAtOffset(type, level, below, offsets, false);
                        return belowUnsafePosition.isPresent() ? belowUnsafePosition : findStandUpPositionAtOffset(type, level, pos, aboveOffsets, false);
                    }
                }
            }
        }
    }
    
    private static Optional<class_243> findStandUpPositionAtOffset(class_1299<?> type, class_1941 level, class_2338 pos, int[][] offsets, boolean checkDangerous) {
        class_2338.class_2339 blockPos = new class_2338.class_2339();
        for (int[] offset : offsets) {
            blockPos.method_10103(pos.method_10263() + offset[0], pos.method_10264(), pos.method_10260() + offset[1]);
            class_243 position = class_5275.method_30769(type, level, blockPos, checkDangerous);
            if (position != null) {
                return Optional.of(position);
            }
        }
        return Optional.empty();
    }
    
    private static int[][] bedStandUpOffsets(class_2350 forward, class_2350 side) {
        return ArrayUtils.addAll(bedSurroundStandUpOffsets(forward, side), bedAboveStandUpOffsets(forward));
    }
    
    private static int[][] bedSurroundStandUpOffsets(class_2350 forward, class_2350 side) {
        return new int[][]{
            {side.method_10148(), side.method_10165()},
            {side.method_10148() - forward.method_10148(), side.method_10165() - forward.method_10165()},
            {side.method_10148() - forward.method_10148() * 2, side.method_10165() - forward.method_10165() * 2},
            {-forward.method_10148() * 2, -forward.method_10165() * 2},
            {-side.method_10148() - forward.method_10148() * 2, -side.method_10165() - forward.method_10165() * 2},
            {-side.method_10148() - forward.method_10148(), -side.method_10165() - forward.method_10165()},
            {-side.method_10148(), -side.method_10165()},
            {-side.method_10148() + forward.method_10148(), -side.method_10165() + forward.method_10165()},
            {forward.method_10148(), forward.method_10165()},
            {side.method_10148() + forward.method_10148(), side.method_10165() + forward.method_10165()}
        };
    }
    
    private static int[][] bedAboveStandUpOffsets(class_2350 forward) {
        return new int[][]{{0, 0}, {-forward.method_10148(), -forward.method_10165()}};
    }
}