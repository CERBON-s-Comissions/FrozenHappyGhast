package com.blackgear.vanillabackport.common.level.entities.mob.animal.golem.copper_golem.container;

import com.blackgear.vanillabackport.core.mixin.common.access.ContainerOpenersCounterAccessor;
import java.lang.reflect.Field;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_2680;
import net.minecraft.class_5561;
import net.minecraft.class_5712;

public class ContainerOpenersCounterAdapter implements ContainerAdapter {
    private static final Map<Class<?>, Optional<Field>> COUNTER_FIELD_CACHE = new ConcurrentHashMap<>();
    
    @Override
    public boolean supports(class_2586 blockEntity) {
        return getCounter(blockEntity).isPresent();
    }
    
    public static Optional<class_5561> getCounter(class_2586 container) {
        if (container == null) return Optional.empty();
        
        Field counter = COUNTER_FIELD_CACHE.computeIfAbsent(container.getClass(), ContainerOpenersCounterAdapter::tryFetchCounter).orElse(null);
        if (counter == null) return Optional.empty();
        
        try {
            return Optional.ofNullable((class_5561) counter.get(container));
        } catch (IllegalAccessException e) {
            return Optional.empty();
        }
    }
    
    private static Optional<Field> tryFetchCounter(Class<?> clazz) {
        Class<?> current = clazz;
        while (current != null && current != class_2586.class) {
            for (Field field : current.getDeclaredFields()) {
                if (class_5561.class.isAssignableFrom(field.getType())) {
                    field.setAccessible(true);
                    return Optional.of(field);
                }
            }
            current = current.getSuperclass();
        }
        return Optional.empty();
    }
    
    @Override
    public void startOpen(class_2586 blockEntity, ContainerUser user) {
        if (!ContainerManager.isValid(blockEntity, user)) return;
        
        getCounter(blockEntity).ifPresent(counter -> {
            class_1937 level = blockEntity.method_10997();
            incrementOpeners(counter, user.getLivingEntity(), level, blockEntity.method_11016(), blockEntity.method_11010(), user.getContainerInteractionRange());
            
            handleDoubleChest(blockEntity, level, (connectedCounter, connectedPos, connectedState) ->
                incrementOpeners(connectedCounter, user.getLivingEntity(), level, connectedPos, connectedState, user.getContainerInteractionRange())
            );
        });
    }
    
    @Override
    public void stopOpen(class_2586 blockEntity, ContainerUser user) {
        if (!ContainerManager.isValid(blockEntity, user)) return;
        
        getCounter(blockEntity).ifPresent(counter -> {
            class_1937 level = blockEntity.method_10997();
            decrementOpeners(counter, user.getLivingEntity(), level, blockEntity.method_11016(), blockEntity.method_11010());
            
            handleDoubleChest(blockEntity, level, (connectedCounter, connectedPos, connectedState) ->
                decrementOpeners(connectedCounter, user.getLivingEntity(), level, connectedPos, connectedState)
            );
        });
    }
    
    private static void incrementOpeners(class_5561 counter, class_1309 entity, class_1937 level, class_2338 pos, class_2680 state, double maxInteractionRange) {
        int previous = counter.field_27215++;
        if (previous == 0) {
            ((ContainerOpenersCounterAccessor) counter).callOnOpen(level, pos, state);
            level.method_33596(entity, class_5712.field_28176, pos);
        }
        
        ((ContainerOpenersCounterAccessor) counter).callOpenerCountChanged(level, pos, state, previous, counter.field_27215);
        counter.field_48376 = Math.max(maxInteractionRange, counter.field_48376);
    }
    
    private static void decrementOpeners(class_5561 counter, class_1309 entity, class_1937 level, class_2338 pos, class_2680 state) {
        int previous = counter.field_27215--;
        if (counter.field_27215 == 0) {
            ((ContainerOpenersCounterAccessor) counter).callOnClose(level, pos, state);
            level.method_33596(entity, class_5712.field_28177, pos);
            counter.field_48376 = 0.0;
        }
        
        ((ContainerOpenersCounterAccessor) counter).callOpenerCountChanged(level, pos, state, previous, counter.field_27215);
    }
    
    @Override
    public List<class_1309> getEntitiesWithContainerOpen(class_2586 blockEntity) {
        if (blockEntity == null || blockEntity.method_10997() == null) return List.of();
        
        Optional<class_5561> counterOpt = getCounter(blockEntity);
        if (counterOpt.isEmpty()) return List.of();
        
        class_5561 counter = counterOpt.get();
        double range = counter.field_48376 + 4.0;
        
        return ContainerManager.getEntitiesWithContainerOpen(
            blockEntity,
            range,
            (entity, pos) -> hasContainerOpen(counter, entity, pos)
        );
    }
    
    private static boolean hasContainerOpen(class_5561 counter, class_1297 entity, class_2338 pos) {
        if (entity instanceof class_1657 player) {
            return ((ContainerOpenersCounterAccessor) counter).callIsOwnContainer(player);
        }
        return entity instanceof ContainerUser user && !user.getLivingEntity().method_7325() && user.hasContainerOpen(counter, pos);
    }
    
    private void handleDoubleChest(class_2586 blockEntity, class_1937 level, ConnectedChestConsumer consumer) {
        if (blockEntity instanceof class_2595) {
            class_2338 connectedPos = ContainerManager.getConnectedBlockPos(blockEntity.method_11016(), blockEntity.method_11010());
            class_2586 connectedContainer = level.method_8321(connectedPos);
            
            if (connectedContainer instanceof class_2595) {
                getCounter(connectedContainer).ifPresent(counter ->
                    consumer.accept(counter, connectedPos, connectedContainer.method_11010())
                );
            }
        }
    }
    
    @FunctionalInterface
    private interface ConnectedChestConsumer {
        void accept(class_5561 counter, class_2338 pos, class_2680 state);
    }
}