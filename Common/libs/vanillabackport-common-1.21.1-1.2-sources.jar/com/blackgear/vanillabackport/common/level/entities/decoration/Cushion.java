package com.blackgear.vanillabackport.common.level.entities.decoration;

import com.blackgear.vanillabackport.client.registries.ModSoundEvents;
import com.blackgear.vanillabackport.common.registries.entities.ModEntityDataSerializers;
import com.blackgear.vanillabackport.common.registries.items.ModItems;
import com.blackgear.vanillabackport.core.util.Utilities.CollisionUtils;
import com.blackgear.vanillabackport.core.util.Utilities.PositionUtils;
import org.jetbrains.annotations.Nullable;

import java.util.EnumMap;
import java.util.Map;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1538;
import net.minecraft.class_1657;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1928;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2388;
import net.minecraft.class_2398;
import net.minecraft.class_247;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2940;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3481;
import net.minecraft.class_9334;
import net.minecraft.class_9691;

public class Cushion extends class_9691 {
    public static final Map<class_1767, CushionData> CUSHIONS_BY_DYE = new EnumMap<>(class_1767.class);
    private static final class_1767 DEFAULT_COLOR = class_1767.field_7952;
    private static final class_2940<class_1767> DATA_COLOR = class_2945.method_12791(Cushion.class, ModEntityDataSerializers.DYE_COLOR.get());
    
    public Cushion(class_1299<? extends class_9691> entityType, class_1937 level) {
        super(entityType, level);
    }
    
    public class_1767 getColor() {
        return this.field_6011.method_12789(DATA_COLOR);
    }
    
    public void setColor(class_1767 color) {
        this.field_6011.method_12778(DATA_COLOR, color);
    }
    
    @Override
    public void method_6889(@Nullable class_1297 entity) {
        this.method_43077(ModSoundEvents.CUSHION_BREAK.get());
        this.showBreakingParticles();
        if (this.method_37908() instanceof class_3218 level && level.method_8450().method_8355(class_1928.field_19393)) {
            if (!(entity instanceof class_1657 player && player.method_56992())) {
                class_1799 cushion = new class_1799(Cushion.getByColor(this.getColor()).cushion());
                cushion.method_57379(class_9334.field_49631, this.method_5797());
                this.method_5775(cushion);
            }
        }
    }
    
    @Override
    public class_1269 method_5688(class_1657 player, class_1268 hand) {
        if (!player.method_21823() && !this.method_5782() && (this.method_37908().method_8608() || player.method_5804(this))) {
            if (!this.method_37908().method_8608()) {
                this.method_43077(ModSoundEvents.CUSHION_SIT.get());
                return class_1269.field_21466;
            } else {
                return class_1269.field_5812;
            }
        } else {
            return class_1269.field_5811;
        }
    }
    
    @Override
    protected void method_5793(class_1297 passenger) {
        super.method_5793(passenger);
        if (!this.method_37908().method_8608() && this.method_35049() == null) {
            this.method_43077(ModSoundEvents.CUSHION_GET_UP.get());
        }
    }
    
    @Override
    public @Nullable class_1799 method_31480() {
        return new class_1799(Cushion.getByColor(this.getColor()).cushion());
    }
    
    @Override
    public void method_5814(double x, double y, double z) {
        this.method_23327(x, y, z);
        super.method_5814(x, y, z);
    }
    
    private void showBreakingParticles() {
        if (this.method_37908() instanceof class_3218 level) {
            level.method_14199(
                new class_2388(class_2398.field_11217, Cushion.getByColor(this.getColor()).wool().method_9564()),
                this.method_23317(),
                this.method_23323(0.67F),
                this.method_23321(),
                10,
                this.method_17681() / 4.0F,
                this.method_17681() / 4.0F,
                this.method_17681() / 4.0F,
                0.05
            );
        }
    }

    public static boolean canBePlacedAt(final class_1937 level, final class_238 boundingBox) {
        return wouldSurviveAt(level, boundingBox) && !isAnchorBuried(level, boundingBox);
    }

    public static boolean wouldSurviveAt(final class_1937 level, final class_238 boundingBox) {
        return hasAnchorBelow(level, boundingBox) && !isCoveredBySuffocatingBlocks(level, boundingBox);
    }

    private static boolean isCoveredBySuffocatingBlocks(final class_1937 level, final class_238 boundingBox) {
        for (class_2338 blockPos : PositionUtils.betweenClosed(CollisionUtils.nextDeflated(boundingBox))) {
            if (!level.method_8320(blockPos).method_26228(level, blockPos)) {
                return false;
            }
        }

        return true;
    }

    public static boolean hasAnchorBelow(class_1937 level, class_238 box) {
        class_238 anchorBox = new class_238(box.field_1323, box.field_1322 - 0.015625, box.field_1321, Math.nextDown(box.field_1320), box.field_1322, Math.nextDown(box.field_1324));

        for (class_2338 pos : PositionUtils.betweenClosed(anchorBox)) {
            class_2680 state = level.method_8320(pos);
            class_265 shape = state.method_26218(level, pos);
            if (!shape.method_1110() && shape.method_1107().method_996(pos).method_994(anchorBox)) {
                return true;
            }
        }

        return false;
    }

    private static boolean isAnchorBuried(final class_1937 level, final class_238 boundingBox) {
        class_238 restingSlice = CollisionUtils.nextDeflated(
            new class_238(boundingBox.field_1323, boundingBox.field_1322, boundingBox.field_1321, boundingBox.field_1320, boundingBox.field_1322 + 0.015625, boundingBox.field_1324)
        );
        class_265 exposedSurface = class_259.method_1078(restingSlice);

        for (class_265 collider : level.method_20812(null, restingSlice)) {
            exposedSurface = class_259.method_1072(exposedSurface, collider, class_247.field_16886);
            if (exposedSurface.method_1110()) {
                return true;
            }
        }
        return false;
    }
    
    @Override
    public boolean method_6888() {
        return wouldSurviveAt(this.method_37908(), this.method_5829());
    }

    @Override
    public void method_5773() {
        super.method_5773();

        if (method_37908() instanceof class_3218 serverLevel) {
            destroyIfInFire(serverLevel);
        }
    }

    public void destroyIfInFire(class_3218 level) {
        if (this.method_31481()) return;

        boolean isInFire = level
            .method_29546(CollisionUtils.nextDeflated(method_5829()))
            .anyMatch(blockState -> blockState.method_26164(class_3481.field_21952));

        if (isInFire) method_5643(method_48923().method_48794(), 1.0f);
    }

    @Override
    public void method_5800(class_3218 level, class_1538 lightning) {
        if (!this.method_31481()) {
            this.method_5768();
            this.method_6889(null);
        }
    }

    @Override
    public boolean method_5643(class_1282 source, float amount) {
        return !isBreakingDeniedFor(source) && super.method_5643(source, amount);
    }

    private boolean isBreakingDeniedFor(final class_1282 source) {
        if (!(source.method_5529() instanceof class_1657 player)) return false;

        boolean deniedBecauseEntity = !player.method_7294();
        boolean deniedBecauseLevel = !this.method_37908().method_8505(player, this.field_51589);

        return deniedBecauseEntity || deniedBecauseLevel;
    }

    @Override
    protected void method_6895() {
        this.method_5857(this.method_33332());
    }
    
    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        builder.method_56912(DATA_COLOR, DEFAULT_COLOR);
    }
    
    @Override
    public void method_5652(class_2487 compound) {
        super.method_5652(compound);
        compound.method_10582("color", this.getColor().method_7792());
    }
    
    @Override
    public void method_5749(class_2487 compound) {
        super.method_5749(compound);
        if (compound.method_10573("color", class_2520.field_33258)) {
            this.setColor(class_1767.method_7793(compound.method_10558("color"), DEFAULT_COLOR));
        } else {
            this.setColor(DEFAULT_COLOR);
        }
    }
    
    public static void register(class_1767 color, class_2248 wool, class_1792 cushion) {
        CUSHIONS_BY_DYE.put(color, new CushionData(wool, cushion));
    }
    
    public static CushionData getByColor(class_1767 color) {
        return CUSHIONS_BY_DYE.getOrDefault(color, new CushionData(class_2246.field_10446, ModItems.WHITE_CUSHION.get()));
    }
    
    static {
        register(class_1767.field_7952, class_2246.field_10446, ModItems.WHITE_CUSHION.get());
        register(class_1767.field_7946, class_2246.field_10095, ModItems.ORANGE_CUSHION.get());
        register(class_1767.field_7958, class_2246.field_10215, ModItems.MAGENTA_CUSHION.get());
        register(class_1767.field_7951, class_2246.field_10294, ModItems.LIGHT_BLUE_CUSHION.get());
        register(class_1767.field_7947, class_2246.field_10490, ModItems.YELLOW_CUSHION.get());
        register(class_1767.field_7961, class_2246.field_10028, ModItems.LIME_CUSHION.get());
        register(class_1767.field_7954, class_2246.field_10459, ModItems.PINK_CUSHION.get());
        register(class_1767.field_7944, class_2246.field_10423, ModItems.GRAY_CUSHION.get());
        register(class_1767.field_7967, class_2246.field_10222, ModItems.LIGHT_GRAY_CUSHION.get());
        register(class_1767.field_7955, class_2246.field_10619, ModItems.CYAN_CUSHION.get());
        register(class_1767.field_7945, class_2246.field_10259, ModItems.PURPLE_CUSHION.get());
        register(class_1767.field_7966, class_2246.field_10514, ModItems.BLUE_CUSHION.get());
        register(class_1767.field_7957, class_2246.field_10113, ModItems.BROWN_CUSHION.get());
        register(class_1767.field_7942, class_2246.field_10170, ModItems.GREEN_CUSHION.get());
        register(class_1767.field_7964, class_2246.field_10314, ModItems.RED_CUSHION.get());
        register(class_1767.field_7963, class_2246.field_10146, ModItems.BLACK_CUSHION.get());
    }
    
    public record CushionData(class_2248 wool, class_1792 cushion) { /* NO-OP */ }
}