package com.blackgear.vanillabackport.common.level.entities.mob.animal.golem.copper_golem.container;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.BiPredicate;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_2281;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

public class ContainerManager {
    private static final List<ContainerAdapter> ADAPTERS = new CopyOnWriteArrayList<>();
    private static final ContainerAdapter DEFAULT = new DefaultContainerAdapter();
    public static final double DEFAULT_RANGE = 7.0;
    
    static {
        registerAdapter(new ContainerOpenersCounterAdapter());
    }
    
    public static void registerAdapter(ContainerAdapter adapter) {
        ADAPTERS.addFirst(adapter);
    }
    
    public static ContainerAdapter getAdapter(class_2586 blockEntity) {
        if (blockEntity == null) return DEFAULT;
        
        return ADAPTERS.stream()
            .filter(adapter -> adapter.supports(blockEntity))
            .findFirst()
            .orElse(DEFAULT);
    }
    
    public static class_2338 getConnectedBlockPos(class_2338 pos, class_2680 state) {
        class_2350 connectedDirection = class_2281.method_9758(state);
        return pos.method_10093(connectedDirection);
    }
    
    public static void startOpen(class_2586 blockEntity, ContainerUser user) {
        getAdapter(blockEntity).startOpen(blockEntity, user);
    }
    
    public static void stopOpen(class_2586 blockEntity, ContainerUser user) {
        getAdapter(blockEntity).stopOpen(blockEntity, user);
    }
    
    public static List<class_1309> getEntitiesWithContainerOpen(class_2586 container) {
        return getAdapter(container).getEntitiesWithContainerOpen(container);
    }
    
    public static List<class_1309> getEntitiesWithContainerOpen(class_2586 blockEntity, double range, BiPredicate<class_1309, class_2338> isOpenPredicate) {
        class_1937 level = blockEntity.method_10997();
        if (level == null) return List.of();
        
        class_2338 pos = blockEntity.method_11016();
        class_238 searchBox = new class_238(pos).method_1014(range);
        
        return level.method_8390(class_1309.class, searchBox, entity -> {
            if (entity.method_7325()) return false;
            return isOpenPredicate.test(entity, pos);
        });
    }
    
    public static boolean isValid(class_2586 blockEntity, ContainerUser user) {
        return blockEntity != null && !blockEntity.method_11015() && !user.getLivingEntity().method_7325();
    }
}