package com.blackgear.vanillabackport.common.level.worldgen.tree.decorators;

import com.blackgear.vanillabackport.common.level.blocks.CreakingHeartBlock;
import com.blackgear.vanillabackport.common.level.blocks.CreakingHeartState;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import com.blackgear.vanillabackport.common.registries.worldgen.ModTreeDecorators;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_156;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_3481;
import net.minecraft.class_4662;
import net.minecraft.class_4663;
import net.minecraft.class_5819;

public class CreakingHeartDecorator extends class_4662 {
    public static final MapCodec<CreakingHeartDecorator> CODEC = Codec.floatRange(0.0F, 1.0F)
        .fieldOf("probability")
        .xmap(CreakingHeartDecorator::new, decorator -> decorator.probability);
    private final float probability;

    public CreakingHeartDecorator(float probability) {
        this.probability = probability;
    }

    @Override
    protected class_4663<?> method_28893() {
        return ModTreeDecorators.CREAKING_HEART.get();
    }

    @Override
    public void method_23469(class_7402 context) {
        class_5819 random = context.method_43320();
        List<class_2338> logs = context.method_43321();
        if (!logs.isEmpty()) {
            if (random.method_43057() < this.probability) {
                List<class_2338> heartPlacements = new ArrayList<>(context.method_43321());
                class_156.method_43028(heartPlacements, random);
                Optional<class_2338> targetPos = heartPlacements.stream().filter(pos -> {
                    for (class_2350 dir : class_2350.values()) {
                        if (!context.method_43316().method_16358(pos.method_10093(dir), state -> state.method_26164(class_3481.field_15475))) {
                            return false;
                        }
                    }

                    return true;
                }).findFirst();
                targetPos.ifPresent(pos ->
                    context.method_43318(
                        pos,
                        ModBlocks.CREAKING_HEART.get().method_9564().method_11657(CreakingHeartBlock.STATE, CreakingHeartState.DORMANT).method_11657(CreakingHeartBlock.NATURAL, true)
                    )
                );
            }
        }
    }
}