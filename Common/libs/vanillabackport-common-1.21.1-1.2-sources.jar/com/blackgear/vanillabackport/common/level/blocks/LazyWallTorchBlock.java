package com.blackgear.vanillabackport.common.level.blocks;

import java.util.function.Supplier;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_2555;
import net.minecraft.class_2680;
import net.minecraft.class_5819;

public class LazyWallTorchBlock extends class_2555 {
    private final Supplier<? extends class_2394> particle;

    public LazyWallTorchBlock(Supplier<? extends class_2394> particle, class_2251 properties) {
        super(null, properties);
        this.particle = particle;
    }

    public void method_9496(class_2680 state, class_1937 level, class_2338 pos, class_5819 random) {
        class_2350 direction = state.method_11654(field_11731);
        double x = pos.method_10263() + 0.5;
        double y = pos.method_10264() + 0.7;
        double z = pos.method_10260() + 0.5;
        class_2350 opposite = direction.method_10153();
        level.method_8406(class_2398.field_11251, x + 0.27 * opposite.method_10148(), y + 0.22, z + 0.27 * opposite.method_10165(), 0.0, 0.0, 0.0);
        level.method_8406(this.particle.get(), x + 0.27 * opposite.method_10148(), y + 0.22, z + 0.27 * opposite.method_10165(), 0.0, 0.0, 0.0);
    }
}