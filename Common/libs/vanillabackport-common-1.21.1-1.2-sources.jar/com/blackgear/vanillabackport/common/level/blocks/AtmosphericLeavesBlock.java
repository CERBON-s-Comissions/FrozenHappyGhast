package com.blackgear.vanillabackport.common.level.blocks;

import com.blackgear.vanillabackport.common.level.sounds.AmbientLeavesBlockSoundPlayer;
import java.util.function.Supplier;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2394;
import net.minecraft.class_2680;
import net.minecraft.class_5819;

public class AtmosphericLeavesBlock extends ParticleLeavesBlock {
    protected final AmbientLeavesBlockSoundPlayer ambientLeavesBlockSoundPlayer;
    
    public AtmosphericLeavesBlock(float leafParticleChance, Supplier<? extends class_2394> particle, class_2251 properties, AmbientLeavesBlockSoundPlayer ambientLeavesBlockSoundPlayer) {
        super(leafParticleChance, particle, properties);
        this.ambientLeavesBlockSoundPlayer = ambientLeavesBlockSoundPlayer;
    }
    
    @Override
    public void method_9496(class_2680 state, class_1937 level, class_2338 pos, class_5819 random) {
        super.method_9496(state, level, pos, random);
        this.ambientLeavesBlockSoundPlayer.playAmbientLeavesSounds(level, pos, this, random);
    }
}