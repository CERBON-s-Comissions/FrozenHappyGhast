package com.blackgear.vanillabackport.common.level.blocks;

import com.blackgear.vanillabackport.client.registries.ModSoundEvents;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlockStateProperties;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import com.blackgear.vanillabackport.core.data.tags.ModBlockTags;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2256;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2746;
import net.minecraft.class_3218;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_4538;
import net.minecraft.class_5778;
import net.minecraft.class_5819;

public class HangingMossBlock extends class_2248 implements class_2256 {
    private static final class_265 TIP_SHAPE = class_2248.method_9541(1.0, 2.0, 1.0, 15.0, 16.0, 15.0);
    private static final class_265 BASE_SHAPE = class_2248.method_9541(1.0, 0.0, 1.0, 15.0, 16.0, 15.0);
    public static final class_2746 TIP = ModBlockStateProperties.TIP;

    public HangingMossBlock(class_2251 properties) {
        super(properties);
        this.method_9590(this.method_9595().method_11664().method_11657(TIP, true));
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return state.method_11654(TIP) ? TIP_SHAPE : BASE_SHAPE;
    }

    @Override
    public void method_9496(class_2680 state, class_1937 level, class_2338 pos, class_5819 random) {
        if (random.method_43048(500) == 0) {
            class_2680 above = level.method_8320(pos.method_10084());
            if (above.method_26164(ModBlockTags.PALE_OAK_LOGS) || above.method_27852(ModBlocks.PALE_OAK_LEAVES.get())) {
                level.method_8486(pos.method_10263(), pos.method_10264(), pos.method_10260(), ModSoundEvents.PALE_HANGING_MOSS_IDLE.get(), class_3419.field_15245, 1.0F, 1.0F, false);
            }
        }
    }

    @Override
    public boolean method_9579(class_2680 state, class_1922 level, class_2338 pos) {
        return true;
    }

    @Override
    public boolean method_9558(class_2680 state, class_4538 level, class_2338 pos) {
        return this.canStayAtPosition(level, pos);
    }

    private boolean canStayAtPosition(class_1922 level, class_2338 pos) {
        class_2338 neighbourPos = pos.method_10084();
        class_2680 blockState = level.method_8320(neighbourPos);
        return class_5778.method_33358(level, class_2350.field_11036, neighbourPos, blockState) || blockState.method_27852(ModBlocks.PALE_HANGING_MOSS.get());
    }

    @Override
    public class_2680 method_9559(
        class_2680 state,
        class_2350 direction,
        class_2680 neighborState,
        class_1936 level,
        class_2338 pos,
        class_2338 neighborPos
    ) {
        if (!this.canStayAtPosition(level, pos)) {
            level.method_39279(pos, this, 1);
        }

        return state.method_11657(TIP, !level.method_8320(pos.method_10074()).method_27852(this));
    }

    @Override
    public void method_9588(class_2680 state, class_3218 level, class_2338 pos, class_5819 random) {
        if (!this.canStayAtPosition(level, pos)) {
            level.method_22352(pos, true);
        }
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(TIP);
    }

    @Override
    public boolean method_9651(class_4538 level, class_2338 pos, class_2680 state) {
        return this.canGrowInto(level.method_8320(this.getTip(level, pos).method_10074()));
    }

    private boolean canGrowInto(class_2680 state) {
        return state.method_26215();
    }

    public class_2338 getTip(class_1922 level, class_2338 pos) {
        class_2338.class_2339 forwardPos = pos.method_25503();
        
        class_2680 forwardState;
        do {
            forwardPos.method_10098(class_2350.field_11033);
            forwardState = level.method_8320(forwardPos);
        } while (forwardState.method_27852(this));

        return forwardPos.method_10093(class_2350.field_11036).method_10062();
    }

    @Override
    public boolean method_9650(class_1937 level, class_5819 random, class_2338 pos, class_2680 state) {
        return true;
    }

    @Override
    public void method_9652(class_3218 level, class_5819 random, class_2338 pos, class_2680 state) {
        class_2338 tipPos = this.getTip(level, pos).method_10074();
        if (this.canGrowInto(level.method_8320(tipPos))) {
            level.method_8501(tipPos, state.method_11657(TIP, true));
        }
    }
}