package com.blackgear.vanillabackport.common.level.entities.mob.animal.nautilus;

import com.blackgear.vanillabackport.client.registries.ModSoundEvents;
import com.blackgear.vanillabackport.common.api.extensions.entity.mounts.ControllableMob;
import com.blackgear.vanillabackport.common.api.extensions.entity.mounts.MountInventoryHandler;
import com.blackgear.vanillabackport.common.level.items.NautilusArmorItem;
import com.blackgear.vanillabackport.common.registries.entities.ModMobEffects;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.blackgear.vanillabackport.core.data.tags.ModItemTags;
import net.minecraft.class_1263;
import net.minecraft.class_1265;
import net.minecraft.class_1266;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1277;
import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1313;
import net.minecraft.class_1315;
import net.minecraft.class_1316;
import net.minecraft.class_1321;
import net.minecraft.class_1332;
import net.minecraft.class_1408;
import net.minecraft.class_1412;
import net.minecraft.class_1429;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1890;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3222;
import net.minecraft.class_3321;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_3486;
import net.minecraft.class_3532;
import net.minecraft.class_3730;
import net.minecraft.class_4140;
import net.minecraft.class_4174;
import net.minecraft.class_4538;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.class_5146;
import net.minecraft.class_5328;
import net.minecraft.class_5425;
import net.minecraft.class_5630;
import net.minecraft.class_5712;
import net.minecraft.class_5757;
import net.minecraft.class_5819;
import net.minecraft.class_6025;
import net.minecraft.class_7;
import net.minecraft.class_7248;
import net.minecraft.class_8181;
import net.minecraft.class_9334;
import net.minecraft.class_9701;
import net.minecraft.world.*;
import net.minecraft.world.entity.*;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

public abstract class AbstractNautilus extends class_1321 implements class_1265, class_7248, class_6025, class_1316, class_5146, ControllableMob {
    private static final class_2940<Boolean> SADDLED = class_2945.method_12791(AbstractNautilus.class, class_2943.field_13323);
    private static final class_2940<Boolean> DASH = class_2945.method_12791(AbstractNautilus.class, class_2943.field_13323);
    private int dashCooldown;
    protected float playerJumpPendingScale;
    protected class_1277 inventory;
    
    protected boolean isJumping;
    @Nullable private UUID owner;
    private final class_1263 bodyArmorAccess = new class_8181() {
        @Override
        public class_1799 method_54079() {
            return AbstractNautilus.this.method_56676();
        }
        
        @Override
        public void method_54077(class_1799 item) {
            AbstractNautilus.this.method_56678(item);
        }
        
        @Override
        public void method_5431() {
        }
        
        @Override
        public boolean method_5443(class_1657 player) {
            return player.method_5854() == AbstractNautilus.this || player.method_56094(AbstractNautilus.this, 4.0);
        }
    };
    
    protected AbstractNautilus(class_1299<? extends AbstractNautilus> entityType, class_1937 level) {
        super(entityType, level);
        this.field_6207 = new class_5757(this, 85, 10, 0.011F, 0.0F, true);
        this.field_6206 = new class_1332(this, 10);
        this.method_5941(class_7.field_18, 0.0F);
        this.createInventory();
    }
    
    @Override
    public void method_5652(class_2487 compound) {
        super.method_5652(compound);
        if (this.method_6139() != null) {
            compound.method_25927("Owner", this.method_6139());
        }
        
        if (!this.inventory.method_5438(0).method_7960()) {
            compound.method_10566("SaddleItem", this.inventory.method_5438(0).method_57358(this.method_56673()));
        }
        
        if (!this.inventory.method_5438(1).method_7960()) {
            compound.method_10566("ArmorItem", this.inventory.method_5438(1).method_57358(this.method_56673()));
        }
    }
    
    @Override
    public void method_5749(class_2487 compound) {
        super.method_5749(compound);
        UUID uUID;
        if (compound.method_25928("Owner")) {
            uUID = compound.method_25926("Owner");
        } else {
            String string = compound.method_10558("Owner");
            uUID = class_3321.method_14546(this.method_5682(), string);
        }
        
        if (uUID != null) {
            this.method_6174(uUID);
        }
        
        if (compound.method_10573("SaddleItem", 10)) {
            class_1799 itemStack = class_1799.method_57360(this.method_56673(), compound.method_10562("SaddleItem")).orElse(class_1799.field_8037);
            if (itemStack.method_31574(class_1802.field_8175)) {
                this.inventory.method_5447(0, itemStack);
            }
        }
        
        if (compound.method_10573("ArmorItem", 10)) {
            class_1799 itemstack = class_1799.method_57360(this.method_56673(), compound.method_10562("ArmorItem")).orElse(class_1799.field_8037);
            if (!itemstack.method_7960() && this.method_6773(itemstack)) {
                this.inventory.method_5447(1, itemstack);
            }
        }
        
        this.syncSaddleToClients();
    }
    
    @Override
    public boolean method_6481(class_1799 stack) {
        return !this.method_6181() && !this.method_6109() ? stack.method_31573(ModItemTags.NAUTILUS_TAMING_ITEMS) : stack.method_31573(ModItemTags.NAUTILUS_FOOD);
    }
    
    @Override
    protected void method_6475(class_1657 player, class_1268 hand, class_1799 stack) {
        if (stack.method_31573(ModItemTags.NAUTILUS_BUCKET_FOOD)) {
            player.method_6122(hand, class_5328.method_30012(stack, player, new class_1799(class_1802.field_8705)));
        } else {
            super.method_6475(player, hand, stack);
        }
    }
    
    public static class_5132.class_5133 createAttributes() {
        return class_1429.method_26828()
            .method_26868(class_5134.field_23716, 15.0)
            .method_26868(class_5134.field_23719, 1.0)
            .method_26868(class_5134.field_23721, 3.0)
            .method_26868(class_5134.field_23718, 0.3);
    }
    
    @Override
    public boolean method_5675() {
        return false;
    }
    
    @Override
    protected class_1408 method_5965(class_1937 level) {
        return new class_1412(this, level);
    }
    
    @Override
    public float method_6144(class_2338 pos, class_4538 level) {
        return 0.0F;
    }
    
    public static boolean checkNautilusSpawnRules(class_1299<? extends AbstractNautilus> type, class_1936 level, class_3730 reason, class_2338 pos, class_5819 random) {
        int seaLevel = level.method_8615();
        int minSpawnLevel = seaLevel - 25;
        return pos.method_10264() >= minSpawnLevel
            && pos.method_10264() <= seaLevel - 5
            && level.method_8316(pos.method_10074()).method_15767(class_3486.field_15517)
            && level.method_8320(pos.method_10084()).method_27852(class_2246.field_10382);
    }
    
    @Override
    public boolean method_5957(class_4538 level) {
        return level.method_8606(this);
    }
    
    @Override
    protected boolean method_5818(class_1297 passenger) {
        return !this.method_5782();
    }
    
    @Override
    public @Nullable class_1309 method_5642() {
        return this.method_6725() && this.method_31483() instanceof class_1657 player ? player : super.method_5642();
    }
    
    @Override
    protected class_243 method_49482(class_1657 controller, class_243 selfInput) {
        float strafe = controller.field_6212;
        float forward = 0.0F;
        float up = 0.0F;
        
        if (controller.field_6250 != 0.0F) {
            float forwardLook = class_3532.method_15362(controller.method_36455() * class_3532.field_29847);
            float upLook = -class_3532.method_15374(controller.method_36455() * class_3532.field_29847);
            if (controller.field_6250 < 0.0F) {
                forwardLook *= -0.5F;
                upLook *= -0.5F;
            }
            
            up = upLook;
            forward = forwardLook;
        }
        
        return new class_243(strafe, up, forward);
    }
    
    protected class_241 getRiddenRotation(class_1309 controller) {
        return new class_241(controller.method_36455() * 0.5F, controller.method_36454());
    }
    
    @Override
    protected void method_49481(class_1657 controller, class_243 riddenInput) {
        super.method_49481(controller, riddenInput);
        class_241 rotation = this.getRiddenRotation(controller);
        float yRot = this.method_36454();
        float diff = class_3532.method_15393(rotation.field_1342 - yRot);
        float turnSpeed = 0.5F;
        yRot += diff * turnSpeed;
        this.method_5710(yRot, rotation.field_1343);
        this.field_5982 = this.field_6283 = this.field_6241 = yRot;
        if (this.method_5787()) {
            if (this.playerJumpPendingScale > 0.0F && !this.isJumping) {
                this.executeRidersJump(this.playerJumpPendingScale, controller);
            }
            
            this.playerJumpPendingScale = 0.0F;
        }
    }
    
    @Override
    public void method_6091(class_243 input) {
        if (this.method_5805() && this.method_5799()) {
            float speed = this.method_6029();
            this.method_5724(speed, input);
            this.method_5784(class_1313.field_6308, this.method_18798());
            this.method_18799(this.method_18798().method_1021(0.9));
        } else {
            super.method_6091(input);
        }
    }
    
    @Override
    protected float method_49485(class_1657 controller) {
        return this.method_5799()
            ? 0.0325F * (float) this.method_45325(class_5134.field_23719)
            : 0.02F * (float) this.method_45325(class_5134.field_23719);
    }
    
    protected void doPlayerRide(class_1657 player) {
        if (!this.method_37908().method_8608()) {
            player.method_5804(this);
            if (!this.method_5782()) {
                this.method_35055();
            }
        }
    }
    
    private int getNautilusRestrictionRadius() {
        return !this.method_6109() && !this.method_6725() ? 32 : 16;
    }
    
    protected void checkRestriction() {
        if (!this.method_60953() && !this.method_5782() && this.method_6181()) {
            int radius = this.getNautilusRestrictionRadius();
            if (!this.method_18410() || !this.method_18412().method_19771(this.method_24515(), radius + 8) || radius != this.method_18413()) {
                this.method_18408(this.method_24515(), radius);
            }
        }
    }
    
    @Override
    protected void method_5958() {
        this.checkRestriction();
        super.method_5958();
    }
    
    private void applyEffects(class_1937 level) {
        if (this.method_31483() instanceof class_1657 player) {
            boolean hasEffect = player.method_6059(ModMobEffects.BREATH_OF_THE_NAUTILUS);
            boolean shouldRefresh = level.method_8510() % 40L == 0L;
            if (!hasEffect || shouldRefresh) {
                player.method_6092(new class_1293(ModMobEffects.BREATH_OF_THE_NAUTILUS, 60, 0, true, true, true));
            }
        }
    }
    
    private void spawnBubbles() {
        double speed = this.method_18798().method_1033();
        double bubbleProbability = class_3532.method_15350(speed * 2.0, 0.15F, 1.0);
        if (this.field_5974.method_43057() < bubbleProbability) {
            float yRot = this.method_36454();
            float xRot = class_3532.method_15363(this.method_36455(), -10.0F, 10.0F);
            class_243 mouthDirectionVector = this.method_5631(xRot, yRot);
            double spread = this.field_5974.method_43058() * 0.8 * (1.0 + speed);
            double dx = (this.field_5974.method_43057() - 0.5) * spread;
            double dy = (this.field_5974.method_43057() - 0.5) * spread;
            double dz = (this.field_5974.method_43057() - 0.5) * spread;
            this.method_37908().method_8406(
                class_2398.field_11247,
                this.method_23317() - mouthDirectionVector.field_1352 * 1.1,
                this.method_23318() - mouthDirectionVector.field_1351 + 0.25,
                this.method_23321() - mouthDirectionVector.field_1350 * 1.1,
                dx, dy, dz
            );
        }
    }
    
    @Override
    public void method_5773() {
        super.method_5773();
        if (!this.method_37908().method_8608()) {
            this.applyEffects(this.method_37908());
        }
        
        if (this.isDashing() && this.dashCooldown < 35) {
            this.setDashing(false);
        }
        
        if (this.dashCooldown > 0) {
            this.dashCooldown--;
            if (this.dashCooldown == 0) {
                this.method_43077(this.getDashReadySound());
            }
        }
        
        if (this.method_5799()) {
            this.spawnBubbles();
        }
    }
    
    @Override
    public boolean method_6153() {
        return this.method_6725();
    }
    
    @Override
    public void method_6154(int jumpAmount) {
        if (this.method_6725() && this.dashCooldown <= 0) {
            this.playerJumpPendingScale = jumpAmount >= 90 ? 1.0F : 0.4F + 0.4F * jumpAmount / 90.0F;
        }
    }
    
    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        super.method_5693(builder);
        builder.method_56912(DASH, false);
        builder.method_56912(SADDLED, false);
    }
    
    public boolean isDashing() {
        return this.field_6011.method_12789(DASH);
    }
    
    public void setDashing(boolean isDashing) {
        this.field_6011.method_12778(DASH, isDashing);
    }
    
    protected void executeRidersJump(float amount, class_1657 controller) {
        this.method_45319(controller.method_5720().method_1021((this.method_5799() ? 1.2F : 0.5F) * amount * this.method_45325(class_5134.field_23719) * this.method_23326()));
        this.dashCooldown = 40;
        this.setDashing(true);
        this.field_6007 = true;
    }
    
    @Override
    public void method_6155(int jumpScale) {
        this.method_43077(this.getDashSound());
        this.method_32876(class_5712.field_28725);
        this.setDashing(true);
    }
    
    @Override
    public int method_45327() {
        return this.dashCooldown;
    }
    
    @Override
    public void method_5674(class_2940<?> key) {
        if (!this.field_5953 && DASH.equals(key)) {
            this.dashCooldown = this.dashCooldown == 0 ? 40 : this.dashCooldown;
        }
        
        super.method_5674(key);
    }
    
    @Override
    public void method_6156() {
    }
    
    @Override
    protected void method_5712(class_2338 pos, class_2680 state) {
    }
    
    protected @Nullable class_3414 getDashSound() {
        return null;
    }
    
    protected @Nullable class_3414 getDashReadySound() {
        return null;
    }
    
    @Override
    public class_1269 method_5992(class_1657 player, class_1268 hand) {
        this.method_5971();
        
        if (this.method_6109()) {
            return super.method_5992(player, hand);
        } else if (this.method_6181() && player.method_21823()) {
            this.method_6722(player);
            return class_1269.method_29236(this.method_37908().field_9236);
        } else {
            class_1799 stack = player.method_5998(hand);
            if (!stack.method_7960()) {
                if (!this.method_37908().method_8608() && !this.method_6181() && this.method_6481(stack)) {
                    this.method_6475(player, hand, stack);
                    this.tryToTame(player);
                    return class_1269.field_5812;
                }
                
                if (this.method_6481(stack) && this.method_6032() < this.method_6063()) {
                    class_4174 properties = stack.method_57824(class_9334.field_50075);
                    this.method_6475(player, hand, stack);
                    this.method_6025(properties != null ? 2.0F * properties.comp_2491() : 1.0F);
                    this.playEatingSound();
                    return class_1269.method_29236(this.method_37908().field_9236);
                }
                
                class_1269 interactionResult = stack.method_7920(player, this, hand);
                if (interactionResult.method_23665()) {
                    return interactionResult;
                }
                
                if (this.method_56991(class_1304.field_48824) && this.method_6773(stack) && !this.method_56677()) {
                    this.equipBodyArmor(player, stack);
                    return class_1269.method_29236(this.method_37908().field_9236);
                }
            }
            
            if (stack.method_31574(class_1802.field_8868) && !player.method_21823() && this.method_6171(player) && !this.method_5782() && this.method_56677()) {
                stack.method_7970(1, player, method_56079(hand));
                this.method_43077(ModSoundEvents.ARMOR_UNEQUIP_NAUTILUS.get());
                class_1799 armor = this.method_56676();
                this.method_56678(class_1799.field_8037);
                this.method_5699(armor, this.method_17682() + 0.5F);
                return class_1269.method_29236(this.method_37908().field_9236);
            }
            
            if (this.method_6181() && !player.method_21823() && !this.method_6481(stack)) {
                this.doPlayerRide(player);
                return class_1269.method_29236(this.method_37908().field_9236);
            }
            
            return super.method_5992(player, hand);
        }
    }
    
    protected void playEatingSound() {
    }
    
    private void tryToTame(class_1657 player) {
        if (this.field_5974.method_43048(3) == 0) {
            this.method_6170(player);
            this.field_6189.method_6340();
            this.method_37908().method_8421(this, (byte) 7);
        } else {
            this.method_37908().method_8421(this, (byte) 6);
        }
        
        this.playEatingSound();
    }
    
    @Override
    public boolean method_5974(double distanceToClosestPlayer) {
        return true;
    }
    
    @Override
    public boolean method_5643(class_1282 source, float damage) {
        boolean wasHurt = super.method_5643(source, damage);
        if (wasHurt && source.method_5529() instanceof class_1309 attacker) {
            NautilusAi.setAngerTarget(this, attacker);
        }
        
        return wasHurt;
    }
    
    @Override
    public boolean method_6049(class_1293 effect) {
        return effect.method_5579() != class_1294.field_5899 && super.method_6049(effect);
    }
    
    @Override
    public @Nullable class_1315 method_5943(class_5425 level, class_1266 difficulty, class_3730 reason, @Nullable class_1315 spawnData) {
        class_5819 random = level.method_8409();
        NautilusAi.initMemories(this, random);
        return super.method_5943(level, difficulty, reason, spawnData);
    }
    
    @Override
    public class_3414 method_45328() {
        return this.method_5869() ? ModSoundEvents.NAUTILUS_SADDLE_UNDERWATER_EQUIP.get() : ModSoundEvents.NAUTILUS_SADDLE_EQUIP.get();
    }
    
    protected int getInventorySize() {
        return 2;
    }
    
    protected void createInventory() {
        class_1277 old = this.inventory;
        this.inventory = new class_1277(this.getInventorySize());
        if (old != null) {
            old.method_5488(this);
            int max = Math.min(old.method_5439(), this.inventory.method_5439());
            
            for (int slot = 0; slot < max; slot++) {
                class_1799 stack = old.method_5438(slot);
                if (!stack.method_7960()) {
                    this.inventory.method_5447(slot, stack.method_7972());
                }
            }
        }
        
        this.inventory.method_5489(this);
        this.syncSaddleToClients();
    }
    
    @Override
    public void method_6722(class_1657 player) {
        if (!VanillaBackport.COMMON_CONFIG.hasNautilus.get()) return;
        if (!this.method_37908().method_8608() && (!this.method_5782() || this.method_5626(player)) && this.method_6181()) {
            if (player instanceof class_3222 sp && sp instanceof MountInventoryHandler mounts) {
                mounts.openNautilusInventory(this, this.inventory);
            }
        }
    }
    
    @Override
    public class_5630 method_32318(int slot) {
        int i = slot - 400;
        if (i == 0) {
            return new class_5630() {
                @Override
                public class_1799 method_32327() {
                    return AbstractNautilus.this.inventory.method_5438(0);
                }
                
                @Override
                public boolean method_32332(class_1799 carried) {
                    if (!carried.method_7960() && !carried.method_31574(class_1802.field_8175)) {
                        return false;
                    } else {
                        AbstractNautilus.this.inventory.method_5447(0, carried);
                        AbstractNautilus.this.syncSaddleToClients();
                        return true;
                    }
                }
            };
        } else {
            int inventorySlot = slot - 500 + 1;
            return inventorySlot >= 1 && inventorySlot < this.inventory.method_5439() ? class_5630.method_32328(this.inventory, inventorySlot) : super.method_32318(slot);
        }
    }
    
    public boolean hasInventoryChanged(class_1263 inventory) {
        return this.inventory != inventory;
    }
    
    @Override
    public boolean isMobControlled() {
        return this.method_31483() instanceof class_1308;
    }
    
    protected boolean isAggravated() {
        return this.method_18868().method_18896(class_4140.field_22333) || this.method_18868().method_18896(class_4140.field_22355);
    }
    
    @Override
    public boolean method_17326() {
        return super.method_17326() || this.method_6181();
    }
    
    @Override
    public @Nullable UUID method_6139() {
        return this.owner;
    }
    
    public void method_6174(@Nullable UUID uuid) {
        this.owner = uuid;
    }
    
    @Override
    public boolean method_6765() {
        return this.method_5805() && !this.method_6109() && this.method_6181();
    }
    
    @Override
    public void method_6576(class_1799 stack, @Nullable class_3419 soundSource) {
        this.inventory.method_5447(0, stack);
    }
    
    public void equipBodyArmor(class_1657 player, class_1799 armor) {
        if (this.method_6773(armor)) {
            this.method_56678(armor.method_46651(1));
            armor.method_57008(1, player);
        }
    }
    
    @Override
    public boolean method_6725() {
        return this.field_6011.method_12789(SADDLED);
    }
    
    protected void syncSaddleToClients() {
        if (!this.method_37908().field_9236) {
            this.field_6011.method_12778(SADDLED, !this.inventory.method_5438(0).method_7960());
        }
    }
    
    @Override
    public void method_5453(class_1263 container) {
        boolean wasSaddled = this.method_6725();
        this.syncSaddleToClients();
        
        if (this.field_6012 > 20) {
            if (!wasSaddled && this.method_6725()) {
                this.method_5783(this.method_45328(), 0.5F, 1.0F);
            }
            class_1799 armor = this.method_56676();
            if (this.method_6773(armor) && !armor.method_7960()) {
                this.method_5783(ModSoundEvents.ARMOR_EQUIP_NAUTILUS.get(), 0.5F, 1.0F);
            }
        }
    }
    
    @Override
    protected void method_16078() {
        super.method_16078();
        if (this.inventory != null) {
            for (int size = 0; size < this.inventory.method_5439(); size++) {
                class_1799 stack = this.inventory.method_5438(size);
                if (!stack.method_7960() && !class_1890.method_60142(stack, class_9701.field_51655)) {
                    this.method_5775(stack);
                }
            }
        }
    }
    
    @Override
    public boolean method_56991(class_1304 slot) {
        return true;
    }
    
    @Override
    public boolean method_6773(class_1799 stack) {
        return stack.method_7909() instanceof NautilusArmorItem;
    }
    
    @Override
    public boolean method_6094() {
        return true;
    }
    
    public final class_1263 getBodyArmorAccess() {
        return this.bodyArmorAccess;
    }
}