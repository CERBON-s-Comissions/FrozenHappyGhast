package com.blackgear.vanillabackport.common.level.items.spear;

import com.blackgear.vanillabackport.common.api.extensions.entity.spear.MobSpearHandler;
import com.blackgear.vanillabackport.common.level.components.KineticWeapon;
import com.blackgear.vanillabackport.common.level.components.KineticWeapon.Condition;
import com.blackgear.vanillabackport.core.util.Ease;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_572;
import net.minecraft.class_630;
import net.minecraft.class_7833;

@Environment(EnvType.CLIENT)
public class SpearAnimations {
    private static float progress(float time, float start, float end) {
        return class_3532.method_15363(class_3532.method_37960(time, start, end), 0.0F, 1.0F);
    }

    public static <T extends class_1309> void thirdPersonHandUse(
        class_572<T> model,
        class_630 arm,
        class_630 head,
        class_1306 holdingArm,
        class_1799 item,
        T entity
    ) {
        int invert = holdingArm == class_1306.field_6183 ? 1 : -1;
        arm.field_3675 = -0.1F * invert + head.field_3675;
        arm.field_3654 = -class_3532.field_29845 + head.field_3654 + 0.8F;
        if (entity.method_6128() || model.field_3396 > 0.0F) {
            arm.field_3654 -= 0.9599311F;
        }

        arm.field_3675 = class_3532.field_29847 * class_3532.method_15363(class_3532.field_29848 * arm.field_3675, -60.0F, 60.0F);
        arm.field_3654 = class_3532.field_29847 * class_3532.method_15363(class_3532.field_29848 * arm.field_3654, -120.0F, 30.0F);
        if (entity.method_6048() > 0.0F && (!entity.method_6115() || entity.method_6058() == (holdingArm == class_1306.field_6183 ? class_1268.field_5808 : class_1268.field_5810))) {
            KineticWeapon kineticWeapon = KineticWeapon.get(item);
            if (kineticWeapon != null) {
                UseParams params = UseParams.fromKineticWeapon(kineticWeapon, entity.method_6048());
                arm.field_3675 += -invert * params.swayScaleFast() * class_3532.field_29847 * params.swayIntensity() * 1.0F;
                arm.field_3674 += -invert * params.swayScaleSlow() * class_3532.field_29847 * params.swayIntensity() * 0.5F;
                arm.field_3654 += class_3532.field_29847 * (-40.0F * params.raiseProgressStart() + 30.0F * params.raiseProgressMiddle() + -20.0F * params.raiseProgressEnd() + 20.0F * params.lowerProgress() + 10.0F * params.raiseBackProgress() + 0.6F * params.swayScaleSlow() * params.swayIntensity());
            }
        }
    }

    public static <T extends class_1309> void thirdPersonUseItem(
        class_572<T> model,
        T entity,
        class_4587 pose,
        float timeHeld,
        class_1306 arm,
        class_1799 actualItem
    ) {
        KineticWeapon kineticWeapon = KineticWeapon.get(actualItem);
        if (kineticWeapon != null && timeHeld != 0.0F) {
            float partial = class_310.method_1551().method_60646().method_60637(true);
            float attack = Ease.inQuad(progress(model.field_3447, 0.05F, 0.2F));
            float retract = Ease.inOutExpo(progress(model.field_3447, 0.4F, 1.0F));
            UseParams params = UseParams.fromKineticWeapon(kineticWeapon, timeHeld);
            int invert = arm == class_1306.field_6183 ? 1 : -1;
            float raiseProgressModified = 1.0F - Ease.outBack(1.0F - params.raiseProgress());
            float hitFeedback = hitFeedbackAmount(((MobSpearHandler)entity).vb$getTicksSinceLastKineticHitFeedback(partial));
            pose.method_22904(0.0, -hitFeedback * 0.4, -kineticWeapon.forwardMovement() * (raiseProgressModified - params.raiseBackProgress()) + hitFeedback);
            pose.method_49278(class_7833.field_40713.rotationDegrees(70.0F * (params.raiseProgress() - params.raiseBackProgress()) - 40.0F * (attack - retract)), 0.0F, -0.03125F, 0.125F);
            pose.method_49278(class_7833.field_40716.rotationDegrees(invert * 90 * (params.raiseProgress() - params.swayProgress() + 3.0F * retract + attack)), 0.0F, 0.0F, 0.125F);
        }
    }

    public static <T extends class_1309> void thirdPersonAttackHand(
        class_572<T> model,
        float animation,
        class_1306 attackArm
    ) {
        model.field_3401.field_3675 = model.field_3401.field_3675 - model.field_3391.field_3675;
        model.field_27433.field_3675 = model.field_27433.field_3675 - model.field_3391.field_3675;
        model.field_27433.field_3654 = model.field_27433.field_3654 - model.field_3391.field_3675;
        float prepare = Ease.inOutSine(progress(animation, 0.0F, 0.05F));
        float attack = Ease.inQuad(progress(animation, 0.05F, 0.2F));
        float retract = Ease.inOutExpo(progress(animation, 0.4F, 1.0F));
        class_630 arm = attackArm == class_1306.field_6183 ? model.field_3401 : model.field_27433;
        arm.field_3654 += (90.0F * prepare - 120.0F * attack + 30.0F * retract) * class_3532.field_29847;
    }

    public static <T extends class_1309> void thirdPersonAttackItem(
        class_572<T> model,
        T entity,
        class_4587 pose
    ) {
        if (model.field_3447 > 0.0F) {
            KineticWeapon kineticWeapon = KineticWeapon.get(entity.method_6047());
            float jetForward = kineticWeapon != null ? kineticWeapon.forwardMovement() : 0.0F;
            float attack = Ease.inQuad(progress(model.field_3447, 0.05F, 0.2F));
            float retract = Ease.inOutExpo(progress(model.field_3447, 0.4F, 1.0F));
            pose.method_49278(class_7833.field_40713.rotationDegrees(70.0F * (attack - retract)), 0.0F, -0.125F, 0.125F);
            pose.method_46416(0.0F, jetForward * (attack - retract), 0.0F);
        }
    }

    private static float hitFeedbackAmount(float ticksSinceFeedbackStart) {
        return 0.4F * (Ease.outQuart(progress(ticksSinceFeedbackStart, 1.0F, 3.0F)) - Ease.inOutSine(progress(ticksSinceFeedbackStart, 3.0F, 10.0F)));
    }

    public static void firstPersonUse(
        float ticksSinceKineticHitFeedback,
        class_4587 pose,
        float timeHeld,
        class_1306 arm,
        class_1799 stack
    ) {
        KineticWeapon kineticWeapon = KineticWeapon.get(stack);
        if (kineticWeapon != null) {
            UseParams params = UseParams.fromKineticWeapon(kineticWeapon, timeHeld);
            int invert = arm == class_1306.field_6183 ? 1 : -1;
            pose.method_22904(
                invert * (params.raiseProgress() * 0.15F + params.raiseProgressEnd() * -0.05F + params.swayProgress() * -0.1F + params.swayScaleSlow() * 0.005F),
                params.raiseProgress() * -0.075F + params.raiseProgressMiddle() * 0.075F + params.swayScaleFast() * 0.01F,
                params.raiseProgressStart() * 0.05 + params.raiseProgressEnd() * -0.05 + params.swayScaleSlow() * 0.005F
            );
            pose.method_49278(
                class_7833.field_40714.rotationDegrees(-65.0F * Ease.inOutBack(params.raiseProgress()) - 35.0F * params.lowerProgress() + 100.0F * params.raiseBackProgress() + -0.5F * params.swayScaleFast()),
                0.0F,
                0.1F,
                0.0F
            );
            pose.method_49278(
                class_7833.field_40715.rotationDegrees(invert * (-90.0F * progress(params.raiseProgress(), 0.5F, 0.55F) + 90.0F * params.swayProgress() + 2.0F * params.swayScaleSlow())),
                invert * 0.15F,
                0.0F,
                0.0F
            );
            pose.method_46416(0.0F, -hitFeedbackAmount(ticksSinceKineticHitFeedback), 0.0F);
        }
    }

    public static void firstPersonAttack(
        float attack,
        class_4587 pose,
        int invert
    ) {
        float startingAmount = Ease.inOutSine(progress(attack, 0.0F, 0.05F));
        float middleAmount = Ease.outBack(progress(attack, 0.05F, 0.2F));
        float endingAmount = Ease.inOutExpo(progress(attack, 0.4F, 1.0F));
        pose.method_46416(invert * 0.1F * (startingAmount - middleAmount), -0.075F * (startingAmount - endingAmount), 0.65F * (startingAmount - middleAmount));
        pose.method_22907(class_7833.field_40714.rotationDegrees(-70.0F * (startingAmount - endingAmount)));
        pose.method_22904(0.0, 0.0, -0.25 * (endingAmount - middleAmount));
    }

    record UseParams(
        float raiseProgress,
        float raiseProgressStart,
        float raiseProgressMiddle,
        float raiseProgressEnd,
        float swayProgress,
        float lowerProgress,
        float raiseBackProgress,
        float swayIntensity,
        float swayScaleSlow,
        float swayScaleFast
    ) {
        public static UseParams fromKineticWeapon(KineticWeapon kineticWeapon, float time) {
            int finishRaisingTick = kineticWeapon.delayTicks();
            int finishSwayingTick = kineticWeapon.dismountConditions().map(Condition::maxDurationTicks).orElse(0) + finishRaisingTick;
            int startSwayingTick = finishSwayingTick - 20;
            int finishLoweringTick = kineticWeapon.knockbackConditions().map(Condition::maxDurationTicks).orElse(0) + finishRaisingTick;
            int startLoweringTick = finishLoweringTick - 40;
            int finishRaisingBackTick = kineticWeapon.damageConditions().map(Condition::maxDurationTicks).orElse(0) + finishRaisingTick;
            float raiseProgress = SpearAnimations.progress(time, 0.0F, (float) finishRaisingTick);
            float raiseProgressStart = SpearAnimations.progress(raiseProgress, 0.0F, 0.5F);
            float raiseProgressMiddle = SpearAnimations.progress(raiseProgress, 0.5F, 0.8F);
            float raiseProgressEnd = SpearAnimations.progress(raiseProgress, 0.8F, 1.0F);
            float swayProgress = SpearAnimations.progress(time, (float) startSwayingTick, (float) finishSwayingTick);
            float lowerProgress = Ease.outCubic(Ease.inOutElastic(SpearAnimations.progress(time - 20.0F, (float) startLoweringTick, (float) finishLoweringTick)));
            float raiseBackProgress = SpearAnimations.progress(time, (float) (finishRaisingBackTick - 5), (float) finishRaisingBackTick);
            float swayIntensity = 2.0F * Ease.outCirc(swayProgress) - 2.0F * Ease.inCirc(raiseBackProgress);
            float swayScaleSlow = class_3532.method_15374(time * 19.0F * class_3532.field_29847) * swayIntensity;
            float swayScaleFast = class_3532.method_15374(time * 30.0F * class_3532.field_29847) * swayIntensity;

            return new UseParams(
                raiseProgress,
                raiseProgressStart,
                raiseProgressMiddle,
                raiseProgressEnd,
                swayProgress,
                lowerProgress,
                raiseBackProgress,
                swayIntensity,
                swayScaleSlow,
                swayScaleFast
            );
        }
    }
}