package com.blackgear.vanillabackport.common.level.worldgen.surface;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Optional;
import net.minecraft.class_2680;
import net.minecraft.class_3532;
import net.minecraft.class_5216;
import net.minecraft.class_5321;
import net.minecraft.class_5699;
import net.minecraft.class_6686;
import net.minecraft.class_7243;
import net.minecraft.class_7924;

public record NoiseGradientRuleSource(class_5321<class_5216.class_5487> noise, List<Optional<class_2680>> gradient) implements class_6686.class_6708 {
    private static final Codec<Optional<class_2680>> OPTIONAL_STATE_CODEC = class_2680.field_24734.optionalFieldOf("state").codec();
    private static final MapCodec<NoiseGradientRuleSource> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
        class_5321.method_39154(class_7924.field_41244).fieldOf("noise").forGetter(NoiseGradientRuleSource::noise),
        class_5699.method_36973(OPTIONAL_STATE_CODEC.listOf()).fieldOf("gradient").forGetter(NoiseGradientRuleSource::gradient)
    ).apply(instance, NoiseGradientRuleSource::new));
    public static final class_7243<NoiseGradientRuleSource> CODEC = class_7243.method_42116(MAP_CODEC);

    @Override
    public class_7243<? extends class_6686.class_6708> method_39061() {
        return CODEC;
    }

    @Override
    public class_6686.class_6715 apply(class_6686.class_6694 context) {
        class_5216 noise = context.field_37703.method_41558(this.noise);
        return new NoiseGradientRule(noise, this.gradient.stream().map(state -> state.orElse(null)).toList());
    }

    private record NoiseGradientRule(class_5216 noise, List<class_2680> gradient) implements class_6686.class_6715 {
        @Override @Nullable
        public class_2680 tryApply(int x, int y, int z) {
            double noiseValue = this.noise.method_27406(x, y, z);
            double normalizedNoiseValue = (noiseValue + 1.0) / 2.0;
            int index = class_3532.method_15357(normalizedNoiseValue * this.gradient.size());
            return this.gradient.get(class_3532.method_15340(index, 0, this.gradient.size() - 1));
        }
    }
}