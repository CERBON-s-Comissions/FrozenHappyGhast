package com.blackgear.vanillabackport.common.level.entities.mob.animal.golem.copper_golem;

import com.blackgear.vanillabackport.client.registries.ModSoundEvents;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.golem.copper_golem.TransportItemsBetweenContainers.ContainerInteractionState;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.golem.copper_golem.TransportItemsBetweenContainers.OnTargetReachedInteraction;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.golem.copper_golem.TransportItemsBetweenContainers.TransportItemTarget;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.golem.copper_golem.container.ContainerManager;
import com.blackgear.vanillabackport.common.registries.entities.ModMemoryModuleTypes;
import com.blackgear.vanillabackport.core.data.tags.ModBlockTags;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.mojang.datafixers.util.Pair;
import net.minecraft.class_1299;
import net.minecraft.class_1314;
import net.minecraft.class_2680;
import net.minecraft.class_3414;
import net.minecraft.class_4095;
import net.minecraft.class_4101;
import net.minecraft.class_4107;
import net.minecraft.class_4110;
import net.minecraft.class_4112;
import net.minecraft.class_4118;
import net.minecraft.class_4140;
import net.minecraft.class_4141;
import net.minecraft.class_4148;
import net.minecraft.class_4149;
import net.minecraft.class_4168;
import net.minecraft.class_4818;
import net.minecraft.class_5753;
import net.minecraft.class_6019;
import net.minecraft.class_6028;
import net.minecraft.class_7895;
import net.minecraft.world.entity.ai.behavior.*;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Predicate;

import static com.blackgear.vanillabackport.common.level.entities.mob.animal.golem.copper_golem.TransportItemsBetweenContainers.*;

public class CopperGolemAi {
    private static final Predicate<class_2680> TRANSPORT_ITEM_SOURCE_BLOCK = block -> block.method_26164(ModBlockTags.TRANSPORT_ITEM_SOURCE_BLOCKS);
    private static final Predicate<class_2680> TRANSPORT_ITEM_DESTINATION_BLOCK = block -> block.method_26164(ModBlockTags.TRANSPORT_ITEM_DESTINATION_BLOCKS);
    private static final ImmutableList<class_4149<? extends class_4148<? super CopperGolem>>> SENSOR_TYPES = ImmutableList.of(
        class_4149.field_18466,
        class_4149.field_18469
    );
    private static final ImmutableList<class_4140<?>> MEMORY_TYPES = ImmutableList.of(
        class_4140.field_39408,
        class_4140.field_18451,
        class_4140.field_18452,
        class_4140.field_18441,
        class_4140.field_18442,
        class_4140.field_18445,
        class_4140.field_18446,
        class_4140.field_19293,
        class_4140.field_18449,
        class_4140.field_40127,
        ModMemoryModuleTypes.TRANSPORT_ITEMS_COOLDOWN_TICKS.get(),
        ModMemoryModuleTypes.VISITED_BLOCK_POSITIONS.get(),
        ModMemoryModuleTypes.UNREACHABLE_TRANSPORT_BLOCK_POSITIONS.get(),
        class_4140.field_26389
    );

    public static class_4095.class_5303<CopperGolem> brainProvider() {
        return class_4095.method_28311(MEMORY_TYPES, SENSOR_TYPES);
    }

    public static class_4095<?> makeBrain(class_4095<CopperGolem> brain) {
        initCoreActivity(brain);
        initIdleActivity(brain);
        brain.method_18890(Set.of(class_4168.field_18594));
        brain.method_18897(class_4168.field_18595);
        brain.method_24536();
        return brain;
    }

    public static void updateActivity(CopperGolem golem) {
        golem.method_18868().method_24531(ImmutableList.of(class_4168.field_18595));
    }

    public static void initCoreActivity(class_4095<CopperGolem> brain) {
        brain.method_18882(
            class_4168.field_18594,
            0,
            ImmutableList.of(
                new class_6028<>(1.5F),
                new class_4110(45, 90),
                new class_4112(),
                class_4107.method_46964(),
                new class_5753(class_4140.field_40127),
                new class_5753(ModMemoryModuleTypes.TRANSPORT_ITEMS_COOLDOWN_TICKS.get()))
        );
    }

    public static void initIdleActivity(class_4095<CopperGolem> brain) {
        brain.method_18881(
            class_4168.field_18595,
            ImmutableList.of(
                Pair.of(0,
                    new TransportItemsBetweenContainers(
                        1.0F,
                        TRANSPORT_ITEM_SOURCE_BLOCK,
                        state -> TRANSPORT_ITEM_DESTINATION_BLOCK.test(state) && !TRANSPORT_ITEM_SOURCE_BLOCK.test(state),
                        32,
                        8,
                        getTargetReachedInteractions(),
                        onTravelling(),
                        shouldQueueForTarget()
                    )
                ),
                Pair.of(1, class_7895.method_47069(class_1299.field_6097, 6.0F, class_6019.method_35017(40, 80))),
                Pair.of(2,
                    new class_4118<>(
                        ImmutableMap.of(
                            class_4140.field_18445, class_4141.field_18457,
                            ModMemoryModuleTypes.TRANSPORT_ITEMS_COOLDOWN_TICKS.get(), class_4141.field_18456
                        ),
                        ImmutableList.of(
                            Pair.of(class_4818.method_47015(1.0F, 2, 2), 1),
                            Pair.of(new class_4101(30, 60), 1)
                        )
                    )
                )
            )
        );
    }

    private static Map<ContainerInteractionState, OnTargetReachedInteraction> getTargetReachedInteractions() {
        return Map.of(
            ContainerInteractionState.PICKUP_ITEM, onTargetReachedInteraction(CopperGolemState.GETTING_ITEM, ModSoundEvents.COPPER_GOLEM_ITEM_GET.get()),
            ContainerInteractionState.PICKUP_NO_ITEM, onTargetReachedInteraction(CopperGolemState.GETTING_NO_ITEM, ModSoundEvents.COPPER_GOLEM_ITEM_NO_GET.get()),
            ContainerInteractionState.PLACE_ITEM, onTargetReachedInteraction(CopperGolemState.DROPPING_ITEM, ModSoundEvents.COPPER_GOLEM_ITEM_DROP.get()),
            ContainerInteractionState.PLACE_NO_ITEM, onTargetReachedInteraction(CopperGolemState.DROPPING_NO_ITEM, ModSoundEvents.COPPER_GOLEM_ITEM_NO_DROP.get())
        );
    }

    private static OnTargetReachedInteraction onTargetReachedInteraction(CopperGolemState state, @Nullable class_3414 sound) {
        return (entity, target, tickSinceReachingTarget) -> {
            if (entity instanceof CopperGolem golem) {
                if (tickSinceReachingTarget == 1) {
                    ContainerManager.startOpen(target.blockEntity(), golem);
                    golem.setOpenedChestPos(target.pos());
                    golem.setState(state);
                }

                if (tickSinceReachingTarget == 9 && sound != null) {
                    golem.method_43077(sound);
                }

                if (tickSinceReachingTarget == 60) {
                    if (ContainerManager.getEntitiesWithContainerOpen(target.blockEntity()).contains(golem)) {
                        ContainerManager.stopOpen(target.blockEntity(), golem);
                    }

                    golem.clearOpenedChestPos();
                }
            }
        };
    }

    private static Consumer<class_1314> onTravelling() {
        return entity -> {
            if (entity instanceof CopperGolem golem) {
                golem.clearOpenedChestPos();
                golem.setState(CopperGolemState.IDLE);
            }
        };
    }

    private static Predicate<TransportItemTarget> shouldQueueForTarget() {
        return target -> !ContainerManager.getEntitiesWithContainerOpen(target.blockEntity()).isEmpty();
    }
}