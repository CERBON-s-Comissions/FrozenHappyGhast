package com.blackgear.vanillabackport.common.level.entities.ai.goal;

import com.blackgear.vanillabackport.common.level.entities.mob.animal.golem.copper_golem.CopperGolem;
import com.blackgear.vanillabackport.core.data.tags.ModEntityTypeTags;
import com.blackgear.vanillabackport.core.util.WorldUtilities.EntityUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.EnumSet;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1352;
import net.minecraft.class_1439;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_238;
import net.minecraft.class_4051;

public class OfferCopperGolemFlowerGoal extends class_1352 {
	private static final class_4051 OFFER_TARGET_CONTEXT = class_4051.method_36626().method_18418(6.0);
	private static final class_1792 OFFER_ITEM = class_1802.field_8880;
	private final class_1439 golem;
	@Nullable private class_1309 entity;
	private int tick;

	public OfferCopperGolemFlowerGoal(class_1439 golem) {
		this.golem = golem;
		this.method_6265(EnumSet.of(class_4134.field_18405, class_4134.field_18406));
	}

	@Override
	public boolean method_6264() {
		if (!this.golem.method_37908().method_8530()) {
			return false;
		} else if (this.golem.method_59922().method_43048(8000) != 0) {
			return false;
		} else {
			this.entity = EntityUtils.getNearestEntity(
				this.golem.method_37908(),
				ModEntityTypeTags.ACCEPTS_IRON_GOLEM_GIFT,
				OFFER_TARGET_CONTEXT,
				this.golem,
				this.golem.method_23317(),
				this.golem.method_23318(),
				this.golem.method_23321(),
				this.getGolemBoundingBox()
			);
			return this.entity != null;
		}
	}
	
	@Override
	public boolean method_6266() {
		return this.tick > 0;
	}
	
	@Override
	public void method_6269() {
		this.tick = this.method_38847(400);
		this.golem.method_6497(true);
	}
	
	@Override
	public void method_6270() {
		this.golem.method_6497(false);
		if (this.tick == 0
			&& this.entity instanceof class_1308 mob
			&& mob.method_5864().method_20210(ModEntityTypeTags.ACCEPTS_IRON_GOLEM_GIFT)
			&& mob.method_6118(CopperGolem.EQUIPMENT_SLOT_ANTENNA).method_7960()
			&& this.getGolemBoundingBox().method_994(mob.method_5829())) {
			mob.method_5673(CopperGolem.EQUIPMENT_SLOT_ANTENNA, OFFER_ITEM.method_7854());
			mob.method_25939(CopperGolem.EQUIPMENT_SLOT_ANTENNA);
		}
		
		this.entity = null;
	}
	
	@Override
	public void method_6268() {
		if (this.entity != null) {
			this.golem.method_5988().method_6226(this.entity, 30.0F, 30.0F);
		}
		
		this.tick--;
	}
	
	private @NotNull class_238 getGolemBoundingBox() {
		return this.golem.method_5829().method_1009(6.0, 2.0, 6.0);
	}
}
