package com.blackgear.vanillabackport.common.level.entities.boat;

import com.blackgear.vanillabackport.common.registries.entities.ModEntityTypes;
import net.minecraft.class_1299;
import net.minecraft.class_1690;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1928;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2604;
import net.minecraft.class_2680;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_2960;
import net.minecraft.class_3231;
import net.minecraft.class_3486;
import net.minecraft.class_7264;

public class CustomChestBoat extends class_7264 implements CustomBoatBehavior {
    private static final class_2940<String> BOAT_TYPE_ID = class_2945.method_12791(CustomChestBoat.class, class_2943.field_13326);
    
    public CustomChestBoat(class_1299<? extends class_1690> entityType, class_1937 level) {
        super(entityType, level);
    }

    public CustomChestBoat(class_1937 level, double x, double y, double z, class_2960 type) {
        this(ModEntityTypes.CUSTOM_CHEST_BOAT.get(), level);
        this.setBoatType(type);
        this.method_5814(x, y, z);
        this.field_6014 = x;
        this.field_6036 = y;
        this.field_5969 = z;
    }
    
    @Override
    public class_1792 method_7557() {
        return this.getBoatType().getChestBoat();
    }

    @Override
    protected void method_5623(double y, boolean onGround, class_2680 state, class_2338 pos) {
        this.field_7696 = this.method_18798().field_1351;
        if (!this.method_5765()) {
            if (onGround) {
                if (this.field_6017 > 3.0F) {
                    if (this.field_7702 != class_1690.class_1691.field_7719) {
                        this.method_38785();
                        return;
                    }
                    
                    this.method_5747(this.field_6017, 1.0F, this.method_48923().method_48827());
                    if (!this.method_37908().method_8608() && !this.method_31481()) {
                        this.method_5768();
                        if (this.method_37908().method_8450().method_8355(class_1928.field_19393)) {
                            for (int i = 0; i < 3; i++) {
                                this.method_5706(this.getBoatType().getPlanks());
                            }
                            
                            for (int i = 0; i < 3; i++) {
                                this.method_5706(class_1802.field_8600);
                            }
                        }
                    }
                }
                
                this.method_38785();
            } else if (!this.method_37908().method_8316(this.method_24515().method_10074()).method_15767(class_3486.field_15517) && y < 0.0) {
                this.field_6017 -= (float) y;
            }
        }
    }
    
    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        super.method_5693(builder);
        builder.method_56912(BOAT_TYPE_ID, "minecraft:oak");
    }
    
    @Override
    protected void method_5652(class_2487 compound) {
        super.method_5652(compound);
        compound.method_10582("BoatType", this.getBoatType().id().toString());
    }
    
    @Override
    protected void method_5749(class_2487 compound) {
        super.method_5749(compound);
        if (compound.method_10573("BoatType", 8)) {
            class_2960 id = class_2960.method_12829(compound.method_10558("BoatType"));
            if (id != null) this.setBoatType(id);
        }
    }
    
    public void setBoatType(class_2960 variant) {
        this.field_6011.method_12778(BOAT_TYPE_ID, variant.toString());
    }
    
    @Override
    public BoatRegistry.BoatType getBoatType() {
        class_2960 id = class_2960.method_12829(this.field_6011.method_12789(BOAT_TYPE_ID));
        return BoatRegistry.getType(id != null ? id : BoatRegistry.DEFAULT_TYPE);
    }
    
    @Override
    public class_2596<class_2602> method_18002(class_3231 entity) {
        return new class_2604(this, entity);
    }
}