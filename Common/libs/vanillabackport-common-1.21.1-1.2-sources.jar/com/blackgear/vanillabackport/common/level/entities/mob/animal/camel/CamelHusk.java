package com.blackgear.vanillabackport.common.level.entities.mob.animal.camel;

import com.blackgear.vanillabackport.client.registries.ModSoundEvents;
import com.blackgear.vanillabackport.common.api.extensions.entity.modifiers.CamelSoundModifier;
import com.blackgear.vanillabackport.common.api.extensions.entity.mounts.ControllableMob;
import com.blackgear.vanillabackport.core.data.tags.ModItemTags;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1296;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1429;
import net.minecraft.class_1642;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3481;
import net.minecraft.class_7689;
import org.jetbrains.annotations.Nullable;

public class CamelHusk extends class_7689 implements ControllableMob, CamelSoundModifier {
    public CamelHusk(class_1299<? extends class_7689> entityType, class_1937 level) {
        super(entityType, level);
    }
    
    @Override
    public boolean method_5974(double distanceToClosestPlayer) {
        return true;
    }
    
    @Override
    public boolean isMobControlled() {
        return this.method_31483() instanceof class_1308;
    }
    
    @Override
    public class_1269 method_5992(class_1657 player, class_1268 hand) {
        this.method_5971();
        return super.method_5992(player, hand);
    }
    
    @Override
    public boolean method_5931() {
        return !this.isMobControlled();
    }
    
    @Override
    public boolean method_6481(class_1799 stack) {
        return stack.method_31573(ModItemTags.CAMEL_HUSK_FOOD);
    }
    
    @Override
    protected class_3414 method_5994() {
        return ModSoundEvents.CAMEL_HUSK_AMBIENT.get();
    }
    
    @Override
    public boolean method_6474(class_1429 otherAnimal) {
        return false;
    }
    
    @Override
    public @Nullable class_7689 method_5613(class_3218 level, class_1296 otherParent) {
        return null;
    }
    
    @Override
    public boolean method_6482() {
        return false;
    }
    
    @Override
    public void method_7217(boolean baby) {
    }
    
    @Override
    protected class_3414 method_6002() {
        return ModSoundEvents.CAMEL_HUSK_DEATH.get();
    }
    
    @Override
    protected class_3414 method_6011(class_1282 damageSource) {
        return ModSoundEvents.CAMEL_HUSK_HURT.get();
    }
    
    @Override
    protected void method_5712(class_2338 pos, class_2680 state) {
        if (state.method_26164(class_3481.field_45064)) {
            this.method_5783(ModSoundEvents.CAMEL_HUSK_STEP_SAND.get(), 1.0F, 1.0F);
        } else {
            this.method_5783(ModSoundEvents.CAMEL_HUSK_STEP.get(), 1.0F, 1.0F);
        }
    }
    
    @Override
    public class_3414 getDashingSound() {
        return ModSoundEvents.CAMEL_HUSK_DASH.get();
    }
    
    @Override
    public class_3414 getDashReadySound() {
        return ModSoundEvents.CAMEL_HUSK_DASH_READY.get();
    }
    
    @Override
    protected @Nullable class_3414 method_28368() {
        return ModSoundEvents.CAMEL_HUSK_EAT.get();
    }
    
    @Override
    public class_3414 getStandUpSound() {
        return ModSoundEvents.CAMEL_HUSK_STAND.get();
    }
    
    @Override
    public class_3414 getSitDownSound() {
        return ModSoundEvents.CAMEL_HUSK_SIT.get();
    }
    
    @Override
    public class_3414 method_45328() {
        return ModSoundEvents.CAMEL_HUSK_SADDLE.get();
    }
    
    @Override
    public float chargeSpeedModifier() {
        return 4.0F;
    }
    
    public static class HuskGroupData extends class_1642.class_1644 {
        public boolean triedToSpawnCamelHusk = false;
        
        public HuskGroupData(class_1642.class_1644 data) {
            super(data.field_7439, data.field_25607);
        }
    }
}