package com.blackgear.vanillabackport.common.level.blocks;

import com.blackgear.vanillabackport.client.registries.ModParticles;
import com.blackgear.vanillabackport.client.registries.ModSoundEvents;
import com.blackgear.vanillabackport.common.api.extensions.block.SpreadableBonemealableBlock;
import com.blackgear.vanillabackport.core.util.WorldUtilities.*;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_1937;
import net.minecraft.class_2261;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2902;
import net.minecraft.class_3218;
import net.minecraft.class_3419;
import net.minecraft.class_4538;
import net.minecraft.class_5819;

public class FireflyBushBlock extends class_2261 implements SpreadableBonemealableBlock {
    private static final double FIREFLY_CHANCE_PER_TICK = 0.7;
    private static final double FIREFLY_HORIZONTAL_RANGE = 10.0;
    private static final double FIREFLY_VERTICAL_RANGE = 5.0;
    private static final int FIREFLY_SPAWN_MAX_BRIGHTNESS_LEVEL = 13;
    private static final int FIREFLY_AMBIENT_SOUND_CHANCE_ONE_IN = 30;

    public FireflyBushBlock(class_2251 properties) {
        super(properties);
    }

    @Override
    protected MapCodec<? extends class_2261> method_53969() {
        return method_54094(FireflyBushBlock::new);
    }

    @Override
    public void method_9496(class_2680 state, class_1937 level, class_2338 pos, class_5819 random) {
        if (random.method_43048(FIREFLY_AMBIENT_SOUND_CHANCE_ONE_IN) == 0 && EnvironmentUtils.isNaturalNight(level) && level.method_8624(class_2902.class_2903.field_13203, pos.method_10263(), pos.method_10260()) <= pos.method_10264()) {
            level.method_45446(pos, ModSoundEvents.FIREFLY_BUSH_IDLE.get(), class_3419.field_15256, 1.0F, 1.0F, false);
        }

        if (EnvironmentUtils.isNaturalNight(level) || level.method_22339(pos) <= FIREFLY_SPAWN_MAX_BRIGHTNESS_LEVEL) {
            if (random.method_43058() <= FIREFLY_CHANCE_PER_TICK) {
                double fireflyX = pos.method_10263() + random.method_43058() * FIREFLY_HORIZONTAL_RANGE - FIREFLY_VERTICAL_RANGE;
                double fireflyY = pos.method_10264() + random.method_43058() * FIREFLY_VERTICAL_RANGE;
                double fireflyZ = pos.method_10260() + random.method_43058() * FIREFLY_HORIZONTAL_RANGE - FIREFLY_VERTICAL_RANGE;
                level.method_8406(ModParticles.FIREFLY.get(), fireflyX, fireflyY, fireflyZ, 0.0, 0.0, 0.0);
            }
        }
    }

    @Override
    public boolean method_9651(class_4538 level, class_2338 pos, class_2680 state) {
        return SpreadableBonemealableBlock.hasSpreadableNeighbourPos(level, pos, state);
    }

    @Override
    public boolean method_9650(class_1937 level, class_5819 random, class_2338 pos, class_2680 state) {
        return true;
    }

    @Override
    public void method_9652(class_3218 level, class_5819 random, class_2338 pos, class_2680 state) {
        SpreadableBonemealableBlock.findSpreadableNeighbourPos(level, pos, state)
            .ifPresent(newPos -> level.method_8501(newPos, this.method_9564()));
    }
}