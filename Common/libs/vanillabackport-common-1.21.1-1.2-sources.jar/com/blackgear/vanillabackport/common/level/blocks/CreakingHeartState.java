package com.blackgear.vanillabackport.common.level.blocks;

import net.minecraft.class_3542;

public enum CreakingHeartState implements class_3542 {
    UPROOTED("uprooted"),
    DORMANT("dormant"),
    AWAKE("awake");

    private final String name;

    CreakingHeartState(String name) {
        this.name = name;
    }

    public String toString() {
        return this.name;
    }

    @Override
    public String method_15434() {
        return this.name;
    }
}