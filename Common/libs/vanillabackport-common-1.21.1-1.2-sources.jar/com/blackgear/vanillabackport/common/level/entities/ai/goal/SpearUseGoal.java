package com.blackgear.vanillabackport.common.level.entities.ai.goal;

import com.blackgear.vanillabackport.common.api.extensions.entity.mounts.ControllableMob;
import com.blackgear.vanillabackport.common.level.components.KineticWeapon;
import com.blackgear.vanillabackport.common.registries.items.ModDataComponents;
import com.blackgear.vanillabackport.core.util.WorldUtilities.PathfindingUtils;
import org.jetbrains.annotations.Nullable;

import java.util.EnumSet;
import java.util.Optional;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1352;
import net.minecraft.class_1588;
import net.minecraft.class_243;

public class SpearUseGoal<T extends class_1588> extends class_1352 {
    private static final double MAX_FLEEING_TIME = method_38848(100);
    private final T mob;
    @Nullable private SpearUseGoal.SpearUseState state;
    private final double speedModifierWhenCharging;
    private final double speedModifierWhenRepositioning;
    private final float approachDistanceSq;
    private final float targetInRangeRadiusSq;

    public SpearUseGoal(
        T mob,
        double speedModifierWhenCharging,
        double speedModifierWhenRepositioning,
        float approachDistance,
        float targetInRangeRadius
    ) {
        this.mob = mob;
        this.speedModifierWhenCharging = speedModifierWhenCharging;
        this.speedModifierWhenRepositioning = speedModifierWhenRepositioning;
        this.approachDistanceSq = approachDistance * approachDistance;
        this.targetInRangeRadiusSq = targetInRangeRadius * targetInRangeRadius;
        this.method_6265(EnumSet.of(class_4134.field_18405, class_4134.field_18406));
    }

    @Override
    public boolean method_6264() {
        return this.ableToAttack() && !this.mob.method_6115();
    }

    private boolean ableToAttack() {
        return this.mob.method_5968() != null && this.mob.method_6047().method_57826(ModDataComponents.KINETIC_WEAPON.get());
    }

    private int getKineticWeaponUseDuration() {
        int durationTicks = Optional.ofNullable(this.mob.method_6047().method_57824(ModDataComponents.KINETIC_WEAPON.get()))
            .map(KineticWeapon::computeDamageUseDuration)
            .orElse(0);
        return method_38848(durationTicks);
    }

    @Override
    public boolean method_6266() {
        return this.state != null && !this.state.done && this.ableToAttack();
    }

    @Override
    public void method_6269() {
        super.method_6269();
        this.mob.method_19540(true);
        this.state = new SpearUseState();
    }

    @Override
    public void method_6270() {
        super.method_6270();
        this.mob.method_5942().method_6340();
        this.mob.method_19540(false);
        this.state = null;
        this.mob.method_6021();
    }

    @Override
    public void method_6268() {
        if (this.state != null) {
            class_1309 target = this.mob.method_5968();
            double targetDistSqr = this.mob.method_5649(target.method_23317(), target.method_23318(), target.method_23321());
            class_1297 mount = this.mob.method_5668();
            float speedModifier = 1.0F;
            if (mount != null) {
                speedModifier = ControllableMob.of(mount).chargeSpeedModifier();
            }

            int mountDistance = this.mob.method_5765() ? 2 : 0;
            this.mob.method_5951(target, 30.0F, 30.0F);
            this.mob.method_5988().method_6226(target, 30.0F, 30.0F);
            if (this.state.notEngagedYet()) {
                if (targetDistSqr > this.approachDistanceSq) {
                    this.mob.method_5942().method_6335(target, speedModifier * this.speedModifierWhenRepositioning);
                    return;
                }

                this.state.startEngagement(this.getKineticWeaponUseDuration());
                this.mob.method_6019(class_1268.field_5808);
            }

            if (this.state.tickAndCheckEngagement()) {
                this.mob.method_6021();
                double distance = Math.sqrt(targetDistSqr);
                this.state.awayPos = PathfindingUtils.getPosAway(this.mob, Math.max(0.0, 9 + mountDistance - distance), Math.max(1.0, 11 + mountDistance - distance), 7, target.method_19538());
                this.state.fleeingTime = 1;
            }

            if (!this.state.tickAndCheckFleeing()) {
                if (this.state.awayPos != null) {
                    this.mob.method_5942().method_6337(this.state.awayPos.field_1352, this.state.awayPos.field_1351, this.state.awayPos.field_1350, speedModifier * this.speedModifierWhenRepositioning);
                    if (this.mob.method_5942().method_6357()) {
                        if (this.state.fleeingTime > 0) {
                            this.state.done = true;
                            return;
                        }

                        this.state.awayPos = null;
                    }
                } else {
                    this.mob.method_5942().method_6335(target, speedModifier * this.speedModifierWhenCharging);
                    if (targetDistSqr < this.targetInRangeRadiusSq || this.mob.method_5942().method_6357()) {
                        double distance = Math.sqrt(targetDistSqr);
                        this.state.awayPos = PathfindingUtils.getPosAway(this.mob, 6 + mountDistance - distance, 7 + mountDistance - distance, 7, target.method_19538());
                    }
                }
            }
        }
    }

    public static class SpearUseState {
        private int engageTime = -1;
        private int fleeingTime = -1;
        @Nullable private class_243 awayPos;
        private boolean done = false;

        public boolean notEngagedYet() {
            return this.engageTime < 0;
        }

        public void startEngagement(int spearDownTime) {
            this.engageTime = spearDownTime;
        }

        public boolean tickAndCheckEngagement() {
            if (this.engageTime > 0) {
                this.engageTime--;
                return this.engageTime == 0;
            }

            return false;
        }

        public boolean tickAndCheckFleeing() {
            if (this.fleeingTime > 0) {
                this.fleeingTime++;
                if (this.fleeingTime > MAX_FLEEING_TIME) {
                    this.done = true;
                    return true;
                }
            }

            return false;
        }
    }
}