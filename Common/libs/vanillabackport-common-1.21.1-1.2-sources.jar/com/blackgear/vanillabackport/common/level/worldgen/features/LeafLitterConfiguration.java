package com.blackgear.vanillabackport.common.level.worldgen.features;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_3037;
import net.minecraft.class_4651;
import net.minecraft.class_5699;

public record LeafLitterConfiguration(int tries, int radius, int height, class_4651 blockStateProvider) implements class_3037 {
    public static final Codec<LeafLitterConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group(
        class_5699.field_33442.fieldOf("tries").orElse(128).forGetter(decorator -> decorator.tries),
        class_5699.field_33441.fieldOf("radius").orElse(2).forGetter(decorator -> decorator.radius),
        class_5699.field_33441.fieldOf("height").orElse(1).forGetter(decorator -> decorator.height),
        class_4651.field_24937.fieldOf("block_state_provider").forGetter(decorator -> decorator.blockStateProvider)
    ).apply(instance, LeafLitterConfiguration::new));
}