package com.blackgear.vanillabackport.common.level.items.spear;

import com.blackgear.vanillabackport.client.registries.ModSoundEvents;
import com.blackgear.vanillabackport.common.api.extensions.entity.arms.ItemUseAnimations;
import com.blackgear.vanillabackport.common.level.components.*;
import com.blackgear.vanillabackport.common.level.components.KineticWeapon.Condition;
import com.blackgear.vanillabackport.common.registries.items.ModDataComponents;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1322;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1831;
import net.minecraft.class_1832;
import net.minecraft.class_1834;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_5134;
import net.minecraft.class_9274;
import net.minecraft.class_9285;
import net.minecraft.world.item.*;
import java.util.Optional;

public class SpearItem extends class_1831 {
    public SpearItem(
        class_1832 tier,
        float attackDuration,
        float damageMultiplier,
        float delay,
        float dismountTime,
        float dismountThreshold,
        float knockbackTime,
        float knockbackThreshold,
        float damageTime,
        float damageThreshold,
        class_1793 properties
    ) {
        super(
            tier,
            properties.method_7895(tier.method_8025())
                .method_57349(ModDataComponents.KINETIC_WEAPON.get(),
                    new KineticWeapon(
                        10,
                        (int) (delay * 20.0F),
                        Condition.ofAttackerSpeed((int) (dismountTime * 20.0F), dismountThreshold),
                        Condition.ofAttackerSpeed((int) (knockbackTime * 20.0F), knockbackThreshold),
                        Condition.ofRelativeSpeed((int) (damageTime * 20.0F), damageThreshold),
                        0.38F,
                        damageMultiplier,
                        Optional.of(tier == class_1834.field_8922 ? ModSoundEvents.SPEAR_WOOD_USE : ModSoundEvents.SPEAR_USE),
                        Optional.of(tier == class_1834.field_8922 ? ModSoundEvents.SPEAR_WOOD_HIT : ModSoundEvents.SPEAR_HIT)
                    ))
                .method_57349(ModDataComponents.PIERCING_WEAPON.get(),
                    new PiercingWeapon(
                        true,
                        false,
                        Optional.of(tier == class_1834.field_8922 ? ModSoundEvents.SPEAR_WOOD_ATTACK : ModSoundEvents.SPEAR_ATTACK),
                        Optional.of(tier == class_1834.field_8922 ? ModSoundEvents.SPEAR_WOOD_HIT : ModSoundEvents.SPEAR_HIT)
                    ))
                .method_57349(ModDataComponents.ATTACK_RANGE.get(),
                    new AttackRange(
                        2.0F,
                        4.5F,
                        2.0F,
                        6.5F,
                        0.125F,
                        0.5F
                    ))
                .method_57349(ModDataComponents.MINIMUM_ATTACK_CHARGE.get(), 1.0F)
                .method_57349(ModDataComponents.SWING_ANIMATION.get(),
                    new SwingAnimation(SwingAnimationType.STAB, (int) (attackDuration * 20.0F)))
                .method_57349(ModDataComponents.USE_EFFECTS.get(),
                    new UseEffects(true, false, 1.0F))
                .method_57348(class_9285.method_57480()
                    .method_57487(class_5134.field_23721,
                        new class_1322(class_1792.field_8006, 0.0F + tier.method_8028(), class_1322.class_1323.field_6328),
                        class_9274.field_49217)
                    .method_57487(class_5134.field_23723,
                        new class_1322(class_1792.field_8001, 1.0F / attackDuration - 4.0, class_1322.class_1323.field_6328),
                        class_9274.field_49217)
                    .method_57486()
                )
        );
    }
    
    @Override
    public void method_7852(class_1937 level, class_1309 livingEntity, class_1799 stack, int remainingUseDuration) {
        KineticWeapon kineticWeapon = stack.method_57824(ModDataComponents.KINETIC_WEAPON.get());
        if (kineticWeapon != null && !level.method_8608()) {
            kineticWeapon.damageEntities(stack, remainingUseDuration, livingEntity, livingEntity.method_6058() == class_1268.field_5808 ? class_1304.field_6173 : class_1304.field_6171);
        }
    }
    
    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 usedHand) {
        class_1799 heldItem = player.method_5998(usedHand);
        KineticWeapon kineticWeapon = heldItem.method_57824(ModDataComponents.KINETIC_WEAPON.get());
        if (kineticWeapon != null) {
            player.method_6019(usedHand);
            kineticWeapon.makeSound(player);
            return class_1271.method_22428(heldItem);
        }
        
        return class_1271.method_22430(heldItem);
    }
    
    @Override
    public int method_7837() {
        return this.method_8022().method_8026();
    }
    
    @Override
    public class_1839 method_7853(class_1799 stack) {
        return ItemUseAnimations.REAL_SPEAR.get();
    }
    
    @Override
    public int method_7881(class_1799 stack, class_1309 entity) {
        return 72000;
    }
    
    @Override
    public boolean method_7885(class_2680 state, class_1937 level, class_2338 pos, class_1657 player) {
        return false;
    }
    
    @Override
    public boolean method_7873(class_1799 stack, class_1309 target, class_1309 attacker) {
        return true;
    }
    
    @Override
    public void method_59978(class_1799 stack, class_1309 target, class_1309 attacker) {
        if (attacker instanceof class_1657 player && !player.method_7337())
            stack.method_7970(1, attacker, class_1304.field_6173);
    }
}