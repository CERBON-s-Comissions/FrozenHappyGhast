package com.blackgear.vanillabackport.common.level.entities.ai.behavior;

import com.blackgear.vanillabackport.common.api.extensions.entity.mounts.ControllableMob;
import com.blackgear.vanillabackport.common.level.components.KineticWeapon;
import com.blackgear.vanillabackport.common.registries.entities.ModMemoryModuleTypes;
import com.blackgear.vanillabackport.common.registries.items.ModDataComponents;
import com.blackgear.vanillabackport.core.util.WorldUtilities.PathfindingUtils;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.Optional;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1314;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_4097;
import net.minecraft.class_4102;
import net.minecraft.class_4140;
import net.minecraft.class_4141;

public class SpearAttack extends class_4097<class_1314> {
    private final double speedModifierWhenCharging;
    private final double speedModifierWhenRepositioning;
    private final float targetInRangeRadiusSq;

    public SpearAttack(double speedModifierWhenCharging, double speedModifierWhenRepositioning, float targetInRangeRadius) {
        super(Map.of(ModMemoryModuleTypes.SPEAR_STATUS.get(), class_4141.field_18456));
        this.speedModifierWhenCharging = speedModifierWhenCharging;
        this.speedModifierWhenRepositioning = speedModifierWhenRepositioning;
        this.targetInRangeRadiusSq = targetInRangeRadius * targetInRangeRadius;
    }

    @Nullable
    private class_1309 getTarget(class_1314 mob) {
        return mob.method_18868().method_18904(class_4140.field_22355).orElse(null);
    }

    private boolean ableToAttack(class_1314 mob) {
        return this.getTarget(mob) != null && mob.method_6047().method_57826(ModDataComponents.KINETIC_WEAPON.get());
    }

    private int getKineticWeaponUseDuration(class_1314 mob) {
        return Optional.ofNullable(mob.method_6047().method_57824(ModDataComponents.KINETIC_WEAPON.get())).map(KineticWeapon::computeDamageUseDuration).orElse(0);
    }

    @Override
    protected boolean checkExtraStartConditions(class_3218 level, class_1314 mob) {
        return mob.method_18868().method_18904(ModMemoryModuleTypes.SPEAR_STATUS.get()).orElse(SpearStatus.APPROACH) == SpearStatus.CHARGING
            && this.ableToAttack(mob)
            && !mob.method_6115();
    }

    @Override
    protected void start(class_3218 level, class_1314 mob, long gameTime) {
        mob.method_19540(true);
        mob.method_18868().method_18878(ModMemoryModuleTypes.SPEAR_ENGAGE_TIME.get(), this.getKineticWeaponUseDuration(mob));
        mob.method_18868().method_18875(ModMemoryModuleTypes.SPEAR_CHARGE_POSITION.get());
        mob.method_6019(class_1268.field_5808);
        super.method_18920(level, mob, gameTime);
    }

    @Override
    protected boolean canStillUse(class_3218 level, class_1314 mob, long gameTime) {
        return mob.method_18868().method_18904(ModMemoryModuleTypes.SPEAR_ENGAGE_TIME.get()).orElse(0) > 0 && this.ableToAttack(mob);
    }

    @Override
    protected void tick(class_3218 level, class_1314 mob, long gameTime) {
        class_1309 target = this.getTarget(mob);
        double targetDistSqr = mob.method_5649(target.method_23317(), target.method_23318(), target.method_23321());
        class_1297 mount = mob.method_5668();
        float speedModifier = ControllableMob.of(mount).chargeSpeedModifier();

        int mountDistance = mob.method_5765() ? 2 : 0;
        mob.method_18868().method_18878(class_4140.field_18446, new class_4102(target, true));
        mob.method_18868().method_18878(ModMemoryModuleTypes.SPEAR_ENGAGE_TIME.get(), mob.method_18868().method_18904(ModMemoryModuleTypes.SPEAR_ENGAGE_TIME.get()).orElse(0) - 1);
        class_243 awayPos = mob.method_18868().method_18904(ModMemoryModuleTypes.SPEAR_CHARGE_POSITION.get()).orElse(null);
        if (awayPos != null) {
            mob.method_5942().method_6337(awayPos.field_1352, awayPos.field_1351, awayPos.field_1350, speedModifier * this.speedModifierWhenRepositioning);
            if (mob.method_5942().method_6357()) {
                mob.method_18868().method_18875(ModMemoryModuleTypes.SPEAR_CHARGE_POSITION.get());
            }
        } else {
            mob.method_5942().method_6335(target, speedModifier * this.speedModifierWhenCharging);
            if (targetDistSqr < this.targetInRangeRadiusSq || mob.method_5942().method_6357()) {
                double distance = Math.sqrt(targetDistSqr);
                class_243 newAwayPos = PathfindingUtils.getPosAway(mob, 6 + mountDistance - distance, 7 + mountDistance - distance, 7, target.method_19538());
                mob.method_18868().method_18878(ModMemoryModuleTypes.SPEAR_CHARGE_POSITION.get(), newAwayPos);
            }
        }
    }

    @Override
    protected void stop(class_3218 level, class_1314 mob, long gameTime) {
        mob.method_5942().method_6340();
        mob.method_6021();
        mob.method_18868().method_18875(ModMemoryModuleTypes.SPEAR_CHARGE_POSITION.get());
        mob.method_18868().method_18875(ModMemoryModuleTypes.SPEAR_ENGAGE_TIME.get());
        mob.method_18868().method_18878(ModMemoryModuleTypes.SPEAR_STATUS.get(), SpearStatus.RETREAT);
    }

    @Override
    protected boolean method_18915(long gameTime) {
        return false;
    }
}