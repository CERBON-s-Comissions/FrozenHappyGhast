package com.blackgear.vanillabackport.common.level.entities.mob.animal.nautilus;

import com.blackgear.vanillabackport.client.registries.ModSoundEvents;
import com.blackgear.vanillabackport.common.level.entities.ai.behavior.ChargeAttack;
import com.blackgear.vanillabackport.common.registries.entities.ModEntityTypes;
import com.blackgear.vanillabackport.common.registries.entities.ModMemoryModuleTypes;
import com.blackgear.vanillabackport.common.registries.entities.ModSensorTypes;
import com.blackgear.vanillabackport.core.data.tags.ModEntityTypeTags;
import com.blackgear.vanillabackport.core.data.tags.ModItemTags;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import com.mojang.datafixers.util.Pair;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1856;
import net.minecraft.class_1928;
import net.minecraft.class_3218;
import net.minecraft.class_4051;
import net.minecraft.class_4095;
import net.minecraft.class_4103;
import net.minecraft.class_4110;
import net.minecraft.class_4112;
import net.minecraft.class_4120;
import net.minecraft.class_4140;
import net.minecraft.class_4141;
import net.minecraft.class_4148;
import net.minecraft.class_4149;
import net.minecraft.class_4168;
import net.minecraft.class_4215;
import net.minecraft.class_4806;
import net.minecraft.class_4818;
import net.minecraft.class_4824;
import net.minecraft.class_5753;
import net.minecraft.class_5754;
import net.minecraft.class_5819;
import net.minecraft.class_6019;
import net.minecraft.class_6028;
import net.minecraft.class_6670;
import net.minecraft.world.entity.ai.behavior.*;
import java.util.Optional;
import java.util.Set;

public class NautilusAi {
    private static final class_6019 TIME_BETWEEN_NON_PLAYER_ATTACKS = class_6019.method_35017(2400, 3600);
    static final class_4051 ATTACK_TARGET_CONDITIONS = class_4051.method_36625()
        .method_18420(target -> {
            return (target.method_37908().method_8450().method_8355(class_1928.field_19388) || target.method_5864() != class_1299.field_6131)
                && target.method_37908().method_8621().method_11966(target.method_5829());
        });
    static final ImmutableList<class_4149<? extends class_4148<? super AbstractNautilus>>> SENSOR_TYPES = ImmutableList.of(
        class_4149.field_18466,
        class_4149.field_25362,
        class_4149.field_18467,
        class_4149.field_18469,
        ModSensorTypes.NAUTILUS_TEMPTATIONS.get()
    );
    static final ImmutableList<class_4140<?>> MEMORY_TYPES = ImmutableList.of(
        class_4140.field_39408,
        class_4140.field_18451,
        class_4140.field_18452,
        class_4140.field_18441,
        class_4140.field_18442,
        class_4140.field_18445,
        class_4140.field_18446,
        class_4140.field_19293,
        class_4140.field_18449,
        class_4140.field_22333,
        class_4140.field_18448,
        class_4140.field_22355,
        class_4140.field_28326,
        ModMemoryModuleTypes.CHARGE_COOLDOWN_TICKS.get(),
        ModMemoryModuleTypes.ATTACK_TARGET_COOLDOWN.get()
    );
    
    public static class_4095.class_5303<Nautilus> brainProvider() {
        return class_4095.method_28311(MEMORY_TYPES, SENSOR_TYPES);
    }
    
    public static void initMemories(AbstractNautilus nautilus, class_5819 random) {
        nautilus.method_18868().method_18878(ModMemoryModuleTypes.ATTACK_TARGET_COOLDOWN.get(), TIME_BETWEEN_NON_PLAYER_ATTACKS.method_35008(random));
    }
    
    public static class_4095<?> makeBrain(class_4095<Nautilus> brain) {
        initCoreActivity(brain);
        initIdleActivity(brain);
        initFightActivity(brain);
        brain.method_18890(Set.of(class_4168.field_18594));
        brain.method_18897(class_4168.field_18595);
        brain.method_24536();
        return brain;
    }
    
    public static void initCoreActivity(class_4095<Nautilus> brain) {
        brain.method_18882(
            class_4168.field_18594,
            0,
            ImmutableList.of(
                new class_6028<>(1.6F),
                new class_4110(45, 90),
                new class_4112(),
                new class_5753(class_4140.field_28326),
                new class_5753(ModMemoryModuleTypes.CHARGE_COOLDOWN_TICKS.get()),
                new class_5753(ModMemoryModuleTypes.ATTACK_TARGET_COOLDOWN.get())
            )
        );
    }
    
    public static void initIdleActivity(class_4095<Nautilus> brain) {
        brain.method_18881(
            class_4168.field_18595,
            ImmutableList.of(
                Pair.of(1, new class_4806(ModEntityTypes.NAUTILUS.get(), 0.4F, 2)),
                Pair.of(2, new class_5754(mob -> 1.3F, mob -> mob.method_6109() ? 2.5 : 3.5)),
                Pair.of(3, class_4824.method_47119(NautilusAi::findNearestValidAttackTarget)),
                Pair.of(4, new class_4103<>(
                    ImmutableMap.of(class_4140.field_18445, class_4141.field_18457),
                    ImmutableSet.of(),
                    class_4103.class_4104.field_18348,
                    class_4103.class_4216.field_18856,
                    ImmutableList.of(
                        Pair.of(class_4818.method_47027(1.0F), 2),
                        Pair.of(class_4120.method_47104(1.0F, 3), 3)
                    )
                ))
            )
        );
    }
    
    public static void initFightActivity(class_4095<Nautilus> brain) {
        brain.method_24529(
            class_4168.field_22396,
            ImmutableList.of(
                Pair.of(0, new ChargeAttack(80, ATTACK_TARGET_CONDITIONS, 0.6F, 2.0F, 12.0, 11.0, ModSoundEvents.NAUTILUS_DASH.get()))
            ),
            ImmutableSet.of(
                Pair.of(class_4140.field_22355, class_4141.field_18456),
                Pair.of(class_4140.field_28325, class_4141.field_18457),
                Pair.of(class_4140.field_18448, class_4141.field_18457),
                Pair.of(ModMemoryModuleTypes.CHARGE_COOLDOWN_TICKS.get(), class_4141.field_18457)
            )
        );
    }
    
    protected static Optional<? extends class_1309> findNearestValidAttackTarget(AbstractNautilus nautilus) {
        if (!(nautilus.method_37908() instanceof class_3218 level)) return Optional.empty();
        
        if (!class_4215.method_41331(nautilus) && nautilus.method_5799() && !nautilus.method_6109() && !nautilus.method_6181()) {
            Optional<class_1309> angryAt = class_4215.method_24560(nautilus, class_4140.field_22333)
                .filter(target -> target.method_5799() && class_4148.method_37456(nautilus, target));
            
            if (angryAt.isPresent()) {
                return angryAt;
            } else if (nautilus.method_18868().method_18896(ModMemoryModuleTypes.ATTACK_TARGET_COOLDOWN.get())) {
                return Optional.empty();
            } else {
                class_5819 random = level.method_8409();
                nautilus.method_18868().method_18878(ModMemoryModuleTypes.ATTACK_TARGET_COOLDOWN.get(), TIME_BETWEEN_NON_PLAYER_ATTACKS.method_35008(random));
                return random.method_43057() < 0.5F
                    ? Optional.empty()
                    : nautilus.method_18868().method_18904(class_4140.field_18442).orElse(class_6670.method_38971()).method_38975(NautilusAi::isHostileTarget);
            }
        } else {
            return Optional.empty();
        }
    }
    
    protected static void setAngerTarget(AbstractNautilus nautilus, class_1309 target) {
        if (class_4148.method_37456(nautilus, target)) {
            nautilus.method_18868().method_18875(class_4140.field_19293);
            nautilus.method_18868().method_24525(class_4140.field_22333, target.method_5667(), 400L);
        }
    }
    
    private static boolean isHostileTarget(class_1309 target) {
        return target.method_5799() && target.method_5864().method_20210(ModEntityTypeTags.NAUTILUS_HOSTILES);
    }
    
    public static void updateActivity(AbstractNautilus nautilus) {
        nautilus.method_18868().method_24531(ImmutableList.of(class_4168.field_22396, class_4168.field_18595));
    }

    public static class_1856 getTemptations() {
        return class_1856.method_8106(ModItemTags.NAUTILUS_FOOD);
    }
}