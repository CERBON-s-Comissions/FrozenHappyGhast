package com.blackgear.vanillabackport.common.level.blocks;

import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import com.blackgear.vanillabackport.core.util.BlockShaper;
import com.blackgear.vanillabackport.core.util.WorldUtilities.BlockUtils;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_1309;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2256;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2754;
import net.minecraft.class_3218;
import net.minecraft.class_3726;
import net.minecraft.class_4538;
import net.minecraft.class_4778;
import net.minecraft.class_5778;
import net.minecraft.class_5819;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.properties.*;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.function.BooleanSupplier;
import java.util.function.Function;

public class MossyCarpetBlock extends class_2248 implements class_2256 {
    public static final class_2746 BASE = class_2741.field_16562;
    private static final class_2754<class_4778> NORTH = class_2741.field_22175;
    private static final class_2754<class_4778> EAST = class_2741.field_22174;
    private static final class_2754<class_4778> SOUTH = class_2741.field_22176;
    private static final class_2754<class_4778> WEST = class_2741.field_22177;
    private static final Map<class_2350, class_2754<class_4778>> PROPERTY_BY_DIRECTION = ImmutableMap.copyOf(Maps.newEnumMap(Map.of(class_2350.field_11043, NORTH, class_2350.field_11034, EAST, class_2350.field_11035, SOUTH, class_2350.field_11039, WEST)));
    private final Function<class_2680, class_265> shapes;

    @Override
    public MapCodec<MossyCarpetBlock> method_53969() {
        return method_54094(MossyCarpetBlock::new);
    }

    public MossyCarpetBlock(class_2251 properties) {
        super(properties);
        this.method_9590(this.method_9595().method_11664()
            .method_11657(BASE, true)
            .method_11657(NORTH, class_4778.field_22178)
            .method_11657(EAST, class_4778.field_22178)
            .method_11657(SOUTH, class_4778.field_22178)
            .method_11657(WEST, class_4778.field_22178));
        
        this.shapes = this.makeShapes();
    }
    
    public Function<class_2680, class_265> makeShapes() {
        Map<class_2350, class_265> low = BlockShaper.rotateHorizontal(BlockShaper.boxZ(16.0, 0.0, 10.0, 0.0, 1.0));
        Map<class_2350, class_265> tall = BlockShaper.rotateAll(BlockShaper.boxZ(16.0, 0.0, 1.0));
        return BlockUtils.getShapeForEachState(this, state -> {
            class_265 shape = state.method_11654(BASE) ? tall.get(class_2350.field_11033) : class_259.method_1073();
            
            for (Map.Entry<class_2350, class_2754<class_4778>> entry : PROPERTY_BY_DIRECTION.entrySet()) {
                switch (state.method_11654(entry.getValue())) {
                    case field_22179 -> shape = class_259.method_1084(shape, low.get(entry.getKey()));
                    case field_22180 -> shape = class_259.method_1084(shape, tall.get(entry.getKey()));
                }
            }
            
            return shape.method_1110() ? class_259.method_1077() : shape;
        });
    }
    
    @Override
    protected class_265 method_9571(class_2680 state, class_1922 level, class_2338 pos) {
        return class_259.method_1073();
    }
    
    @Override
    public class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return this.shapes.apply(state);
    }

    @Override
    public class_265 method_9549(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return state.method_11654(BASE) ? this.shapes.apply(this.method_9564()) : class_259.method_1073();
    }

    @Override
    public boolean method_9579(class_2680 state, class_1922 level, class_2338 pos) {
        return true;
    }

    @Override
    public boolean method_9558(class_2680 state, class_4538 level, class_2338 pos) {
        class_2680 belowState = level.method_8320(pos.method_10074());
        return state.method_11654(BASE) ? !belowState.method_26215() : belowState.method_27852(this) && belowState.method_11654(BASE);
    }

    private static boolean hasFaces(class_2680 state) {
        if (state.method_11654(BASE)) {
            return true;
        } else {
            return PROPERTY_BY_DIRECTION.values().stream().anyMatch(property -> state.method_11654(property) != class_4778.field_22178);
        }
    }

    private static boolean canSupportAtFace(class_1922 level, class_2338 pos, class_2350 direction) {
        class_2338 neighbourPos = pos.method_10093(direction);
        class_2680 blockState = level.method_8320(neighbourPos);
        return direction != class_2350.field_11036 && class_5778.method_33358(level, direction, neighbourPos, blockState);
    }

    private static class_2680 getUpdatedState(class_2680 state, class_1922 level, class_2338 pos, boolean createSides) {
        class_2680 aboveState = null;
        class_2680 belowState = null;
        createSides |= state.method_11654(BASE);

        for (class_2350 direction : class_2350.class_2353.field_11062) {
            class_2754<class_4778> property = getPropertyForFace(direction);
            class_4778 side = canSupportAtFace(level, pos, direction) ? (createSides ? class_4778.field_22179 : state.method_11654(property)) : class_4778.field_22178;
            if (side == class_4778.field_22179) {
                if (aboveState == null) {
                    aboveState = level.method_8320(pos.method_10084());
                }

                if (aboveState.method_27852(ModBlocks.PALE_MOSS_CARPET.get()) && aboveState.method_11654(property) != class_4778.field_22178 && !aboveState.method_11654(BASE)) {
                    side = class_4778.field_22180;
                }

                if (!state.method_11654(BASE)) {
                    if (belowState == null) {
                        belowState = level.method_8320(pos.method_10074());
                    }

                    if (belowState.method_27852(ModBlocks.PALE_MOSS_CARPET.get()) && belowState.method_11654(property) == class_4778.field_22178) {
                        side = class_4778.field_22178;
                    }
                }
            }

            state = state.method_11657(property, side);
        }

        return state;
    }
    
    @Override
    public @Nullable class_2680 method_9605(class_1750 context) {
        return getUpdatedState(this.method_9564(), context.method_8045(), context.method_8037(), true);
    }

    public static void placeAt(class_1936 level, class_2338 pos, class_5819 random, int updateType) {
        class_2680 simpleCarpetLayer = ModBlocks.PALE_MOSS_CARPET.get().method_9564();
        class_2680 adjustedCarpetLayer = getUpdatedState(simpleCarpetLayer, level, pos, true);
        level.method_8652(pos, adjustedCarpetLayer, updateType);
        class_2680 state = createTopperWithSideChance(level, pos, random::method_43056);
        if (!state.method_26215()) {
            level.method_8652(pos.method_10084(), state, updateType);
            class_2680 updateBottomCarpet = getUpdatedState(adjustedCarpetLayer, level, pos, true);
            level.method_8652(pos, updateBottomCarpet, updateType);
        }
    }

    @Override
    public void method_9567(class_1937 level, class_2338 pos, class_2680 state, @Nullable class_1309 placer, class_1799 stack) {
        if (!level.field_9236) {
            class_5819 random = level.method_8409();
            class_2680 topper = createTopperWithSideChance(level, pos, random::method_43056);
            if (!topper.method_26215()) level.method_8501(pos.method_10084(), topper);
        }
    }

    private static class_2680 createTopperWithSideChance(class_1922 level, class_2338 pos, BooleanSupplier sideSurvivalTest) {
        class_2338 above = pos.method_10084();
        class_2680 abovePreviousState = level.method_8320(above);
        boolean isMossyCarpetAbove = abovePreviousState.method_27852(ModBlocks.PALE_MOSS_CARPET.get());
        if ((!isMossyCarpetAbove || !abovePreviousState.method_11654(BASE)) && (isMossyCarpetAbove || abovePreviousState.method_45474())) {
            class_2680 noCarpetBaseState = ModBlocks.PALE_MOSS_CARPET.get().method_9564().method_11657(BASE, false);
            class_2680 aboveState = getUpdatedState(noCarpetBaseState, level, pos.method_10084(), true);

            for (class_2350 direction : class_2350.class_2353.field_11062) {
                class_2754<class_4778> property = getPropertyForFace(direction);
                if (aboveState.method_11654(property) != class_4778.field_22178 && !sideSurvivalTest.getAsBoolean()) {
                    aboveState = aboveState.method_11657(property, class_4778.field_22178);
                }
            }

            return hasFaces(aboveState) && aboveState != abovePreviousState ? aboveState : class_2246.field_10124.method_9564();
        } else {
            return class_2246.field_10124.method_9564();
        }
    }

    @Override
    public class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 level, class_2338 pos, class_2338 neighborPos) {
        if (!state.method_26184(level, pos)) {
            return class_2246.field_10124.method_9564();
        } else {
            class_2680 blockState = getUpdatedState(state, level, pos, false);
            return !hasFaces(blockState) ? class_2246.field_10124.method_9564() : blockState;
        }
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(BASE, NORTH, EAST, SOUTH, WEST);
    }

    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return switch (rotation) {
            case field_11464 -> state.method_11657(NORTH, state.method_11654(SOUTH))
                .method_11657(EAST, state.method_11654(WEST))
                .method_11657(SOUTH, state.method_11654(NORTH))
                .method_11657(WEST, state.method_11654(EAST));
            case field_11465 -> state.method_11657(NORTH, state.method_11654(EAST))
                .method_11657(EAST, state.method_11654(SOUTH))
                .method_11657(SOUTH, state.method_11654(WEST))
                .method_11657(WEST, state.method_11654(NORTH));
            case field_11463 -> state.method_11657(NORTH, state.method_11654(WEST))
                .method_11657(EAST, state.method_11654(NORTH))
                .method_11657(SOUTH, state.method_11654(EAST))
                .method_11657(WEST, state.method_11654(SOUTH));
            default -> state;
        };
    }

    @Override
    public class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return switch (mirror) {
            case field_11300 -> state.method_11657(NORTH, state.method_11654(SOUTH)).method_11657(SOUTH, state.method_11654(NORTH));
            case field_11301 -> state.method_11657(EAST, state.method_11654(WEST)).method_11657(WEST, state.method_11654(EAST));
            default -> super.method_9569(state, mirror);
        };
    }

    @Nullable
    public static class_2754<class_4778> getPropertyForFace(class_2350 direction) {
        return PROPERTY_BY_DIRECTION.get(direction);
    }

    @Override
    public boolean method_9651(class_4538 level, class_2338 pos, class_2680 state) {
        return state.method_11654(BASE) && !createTopperWithSideChance(level, pos, () -> true).method_26215();
    }

    @Override
    public boolean method_9650(class_1937 level, class_5819 random, class_2338 pos, class_2680 state) {
        return true;
    }

    @Override
    public void method_9652(class_3218 level, class_5819 random, class_2338 pos, class_2680 state) {
        class_2680 topper = createTopperWithSideChance(level, pos, () -> true);
        if (!topper.method_26215()) level.method_8501(pos.method_10084(), topper);
    }
}