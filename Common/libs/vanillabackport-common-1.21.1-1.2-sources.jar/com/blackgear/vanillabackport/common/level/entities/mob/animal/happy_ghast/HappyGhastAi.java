package com.blackgear.vanillabackport.common.level.entities.mob.animal.happy_ghast;

import com.blackgear.vanillabackport.common.registries.entities.ModSensorTypes;
import com.google.common.collect.ImmutableList;
import com.mojang.datafixers.util.Pair;
import net.minecraft.class_4095;
import net.minecraft.class_4110;
import net.minecraft.class_4112;
import net.minecraft.class_4118;
import net.minecraft.class_4120;
import net.minecraft.class_4125;
import net.minecraft.class_4140;
import net.minecraft.class_4141;
import net.minecraft.class_4148;
import net.minecraft.class_4149;
import net.minecraft.class_4168;
import net.minecraft.class_4818;
import net.minecraft.class_5753;
import net.minecraft.class_5754;
import net.minecraft.class_6019;
import net.minecraft.class_6028;
import net.minecraft.world.entity.ai.behavior.*;
import java.util.Set;

public class HappyGhastAi {
    private static final float IDLE_SPEED = 1.0F;
    private static final float TEMPTED_SPEED = 1.25F;
    private static final float FOLLOWING_ADULT_SPEED = 1.1F;
    private static final double CLOSE_ENOUGH_DIST = 5.0;
    private static final class_6019 ADULT_FOLLOW_RANGE = class_6019.method_35017(5, 16);
    private static final ImmutableList<class_4149<? extends class_4148<? super HappyGhast>>> SENSOR_TYPES = ImmutableList.of(
        class_4149.field_18466,
        class_4149.field_18469,
        ModSensorTypes.HAPPY_GHAST_TEMPTATIONS.get(),
        ModSensorTypes.NEAREST_ADULT_ANY_TYPE.get(),
        class_4149.field_18467
    );
    private static final ImmutableList<class_4140<?>> MEMORY_TYPES = ImmutableList.of(
        class_4140.field_18445,
        class_4140.field_18446,
        class_4140.field_19293,
        class_4140.field_18449,
        class_4140.field_18442,
        class_4140.field_28325,
        class_4140.field_28326,
        class_4140.field_28327,
        class_4140.field_18448,
        class_4140.field_39408,
        class_4140.field_18451,
        class_4140.field_25359,
        class_4140.field_18443,
        class_4140.field_18444,
        class_4140.field_22354
    );

    public static class_4095.class_5303<HappyGhast> brainProvider() {
        return class_4095.method_28311(MEMORY_TYPES, SENSOR_TYPES);
    }

    protected static class_4095<?> makeBrain(class_4095<HappyGhast> brain) {
        initCoreActivity(brain);
        initIdleActivity(brain);
        initPanicActivity(brain);
        brain.method_18890(Set.of(class_4168.field_18594));
        brain.method_18897(class_4168.field_18595);
        brain.method_24536();
        return brain;
    }

    private static void initCoreActivity(class_4095<HappyGhast> brain) {
        brain.method_18882(
            class_4168.field_18594,
            0,
            ImmutableList.of(
                new class_4125(0.8F),
                new class_6028<>(2.0F),
                new class_4110(45, 90),
                new class_4112(),
                new class_5753(class_4140.field_28326)
            )
        );
    }

    private static void initIdleActivity(class_4095<HappyGhast> brain) {
        brain.method_18881(
            class_4168.field_18595,
            ImmutableList.of(
                Pair.of(1, new class_5754(entity -> TEMPTED_SPEED, entity -> CLOSE_ENOUGH_DIST)),
                Pair.of(2, GhastlingFollowAdult.create(ADULT_FOLLOW_RANGE, entity -> FOLLOWING_ADULT_SPEED, class_4140.field_18444)),
                Pair.of(3, GhastlingFollowAdult.create(ADULT_FOLLOW_RANGE, entity -> FOLLOWING_ADULT_SPEED, class_4140.field_25359)),
                Pair.of(4, new class_4118<>(ImmutableList.of(Pair.of(class_4818.method_47025(IDLE_SPEED), 1), Pair.of(class_4120.method_47104(1.0F, 3), 1))))
            )
        );
    }

    private static void initPanicActivity(class_4095<HappyGhast> brain) {
        brain.method_24529(
            class_4168.field_18599,
            ImmutableList.of(),
            Set.of(Pair.of(class_4140.field_39408, class_4141.field_18456))
        );
    }

    public static void updateActivity(HappyGhast happyGhast) {
        happyGhast.method_18868().method_24531(ImmutableList.of(class_4168.field_18599, class_4168.field_18595));
    }
}