package com.blackgear.vanillabackport.common.level.blocks;

import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_5554;
import net.minecraft.class_5819;
import net.minecraft.class_5955;

public class WeatheringLightningRodBlock extends class_5554 implements class_5955 {
    private final class_5811 weatherState;

    public WeatheringLightningRodBlock(class_5811 weatherState, class_2251 properties) {
        super(properties);
        this.weatherState = weatherState;
    }

    @Override
    public void method_9514(class_2680 state, class_3218 level, class_2338 pos, class_5819 random) {
        this.method_54764(state, level, pos, random);
    }

    @Override
    public boolean method_9542(class_2680 state) {
        return class_5955.method_34737(state.method_26204()).isPresent();
    }

    @Override
    public class_5811 method_33622() {
        return this.weatherState;
    }
}