package com.blackgear.vanillabackport.common.level.block_entities;

import com.blackgear.vanillabackport.common.level.blocks.CopperGolemStatueBlock;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.golem.copper_golem.CopperGolem;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlockEntities;
import com.blackgear.vanillabackport.common.registries.entities.ModEntityTypes;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_9275;
import net.minecraft.class_9323;
import net.minecraft.class_9334;
import org.jetbrains.annotations.Nullable;

public class CopperGolemStatueBlockEntity extends class_2586 {
    public CopperGolemStatueBlockEntity(class_2338 pos, class_2680 blockState) {
        super(ModBlockEntities.COPPER_GOLEM_STATUE.get(), pos, blockState);
    }
    
    public void createStatue(CopperGolem golem) {
        this.method_58684(class_9323.method_57827().method_57839(this.method_58693()).method_57840(class_9334.field_49631, golem.method_5797()).method_57838());
        super.method_5431();
    }
    
    @Nullable
    public CopperGolem removeStatue(class_2680 state) {
        if (this.field_11863 != null) {
            CopperGolem golem = ModEntityTypes.COPPER_GOLEM.get().method_5883(this.field_11863);
            if (golem != null) {
                golem.method_5665(this.method_58693().method_57829(class_9334.field_49631));
                return this.initCopperGolem(state, golem);
            }
        }
        
        return null;
    }
    
    private CopperGolem initCopperGolem(class_2680 state, CopperGolem golem) {
        class_2338 pos = this.method_11016();
        golem.method_5808(pos.method_46558().field_1352, pos.method_10264(), pos.method_46558().field_1350, state.method_11654(CopperGolemStatueBlock.FACING).method_10144(), 0.0F);
        golem.field_6241 = golem.method_36454();
        golem.field_6283 = golem.method_36454();
        golem.playSpawnSound();
        return golem;
    }
    
    @Override
    public @Nullable class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }
    
    public class_1799 getItem(class_1799 stack, CopperGolemStatueBlock.Pose pose) {
        stack.method_57365(this.method_57590());
        stack.method_57379(class_9334.field_49623, class_9275.field_49284.method_57420(CopperGolemStatueBlock.POSE, pose));
        return stack;
    }
}
