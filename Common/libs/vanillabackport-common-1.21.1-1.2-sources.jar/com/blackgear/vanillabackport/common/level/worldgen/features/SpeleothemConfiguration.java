package com.blackgear.vanillabackport.common.level.worldgen.features;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_3037;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public record SpeleothemConfiguration(
    class_2680 baseBlock,
    class_2680 pointedBlock,
    class_6862<class_2248> replaceableBlocks,
    float chanceOfTallerGeneration,
    float chanceOfDirectionalSpread,
    float chanceOfSpreadRadius2,
    float chanceOfSpreadRadius3
) implements class_3037 {
    public static final Codec<SpeleothemConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group(
        class_2680.field_24734.fieldOf("base_block").forGetter(SpeleothemConfiguration::baseBlock),
        class_2680.field_24734.fieldOf("pointed_block").forGetter(SpeleothemConfiguration::pointedBlock),
        class_6862.method_40093(class_7924.field_41254).fieldOf("replaceable_blocks").forGetter(SpeleothemConfiguration::replaceableBlocks),
        Codec.floatRange(0.0F, 1.0F).fieldOf("chance_of_taller_generation").orElse(0.2F).forGetter(SpeleothemConfiguration::chanceOfTallerGeneration),
        Codec.floatRange(0.0F, 1.0F).fieldOf("chance_of_directional_spread").orElse(0.7F).forGetter(SpeleothemConfiguration::chanceOfDirectionalSpread),
        Codec.floatRange(0.0F, 1.0F).fieldOf("chance_of_spread_radius_2").orElse(0.5F).forGetter(SpeleothemConfiguration::chanceOfSpreadRadius2),
        Codec.floatRange(0.0F, 1.0F).fieldOf("chance_of_spread_radius_3").orElse(0.5F).forGetter(SpeleothemConfiguration::chanceOfSpreadRadius3)
    ).apply(instance, SpeleothemConfiguration::new));
}