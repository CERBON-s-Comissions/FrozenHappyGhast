package com.blackgear.vanillabackport.common.level.components;

import com.blackgear.vanillabackport.common.api.extensions.entity.movement.MotionAwareEntity;
import com.blackgear.vanillabackport.common.registries.items.ModDataComponents;
import com.blackgear.vanillabackport.core.util.AdditionalCodecs;
import com.blackgear.vanillabackport.core.util.ProjectileUtils;
import com.blackgear.vanillabackport.core.util.Utilities.DirectionUtils;
import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.netty.buffer.ByteBuf;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_5134;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.world.phys.*;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.function.Predicate;
import java.util.function.ToDoubleFunction;

public record AttackRange(
    float minReach,
    float maxReach,
    float minCreativeReach,
    float maxCreativeReach,
    float hitboxMargin,
    float mobFactor
) {
    public static final Codec<AttackRange> CODEC = RecordCodecBuilder.create(instance -> instance.group(
        AdditionalCodecs.floatRange(0.0F, 64.0F).optionalFieldOf("min_reach", 0.0F).forGetter(AttackRange::minReach),
        AdditionalCodecs.floatRange(0.0F, 64.0F).optionalFieldOf("max_reach", 0.0F).forGetter(AttackRange::maxReach),
        AdditionalCodecs.floatRange(0.0F, 64.0F).optionalFieldOf("min_creative_reach", 0.0F).forGetter(AttackRange::minCreativeReach),
        AdditionalCodecs.floatRange(0.0F, 64.0F).optionalFieldOf("max_creative_reach", 0.0F).forGetter(AttackRange::maxCreativeReach),
        AdditionalCodecs.floatRange(0.0F, 1.0F).optionalFieldOf("hitbox_margin", 0.0F).forGetter(AttackRange::hitboxMargin),
        Codec.floatRange(0.0F, 2.0F).optionalFieldOf("mob_factor", 1.0F).forGetter(AttackRange::mobFactor)
    ).apply(instance, AttackRange::new));

    public static final class_9139<ByteBuf, AttackRange> STREAM_CODEC = class_9139.method_58025(
        class_9135.field_48552, AttackRange::minReach,
        class_9135.field_48552, AttackRange::maxReach,
        class_9135.field_48552, AttackRange::minCreativeReach,
        class_9135.field_48552, AttackRange::maxCreativeReach,
        class_9135.field_48552, AttackRange::hitboxMargin,
        class_9135.field_48552, AttackRange::mobFactor,
        AttackRange::new
    );

    public static AttackRange defaultFor(class_1309 entity) {
        return new AttackRange(
            0.0F,
            (float) entity.method_45325(class_5134.field_47759),
            0.0F,
            (float) entity.method_45325(class_5134.field_47759),
            0.0F,
            1.0F
        );
    }

    public class_239 getClosestHit(class_1297 attacker, float partial, Predicate<class_1297> matching) {
        Either<class_3965, Collection<class_3966>> result = ProjectileUtils.getHitEntitiesAlong(attacker, this, matching, class_3959.class_3960.field_17559);
        if (result.left().isPresent()) {
            return result.left().get();
        } else {
            class_3966 entity = null;
            class_243 attackerPos = attacker.method_5836(partial);
            double closestDistance = Double.MAX_VALUE;

            Collection<class_3966> targets = result.right().get();
            for (class_3966 target : targets) {
                double distance = attackerPos.method_1025(target.method_17784());
                if (distance < closestDistance) {
                    closestDistance = distance;
                    entity = target;
                }
            }

            if (entity != null) {
                return entity;
            } else {
                class_243 eyeGaze = ((MotionAwareEntity) attacker).getHeadLookAngle();
                class_243 missPosition = attacker.method_5836(partial).method_1019(eyeGaze);
                return class_3965.method_17778(missPosition, DirectionUtils.getApproximateNearest(eyeGaze), class_2338.method_49638(missPosition));
            }
        }
    }

    public float effectiveMinRange(class_1297 entity) {
        if (entity instanceof class_1657 player) {
            return player.method_7337() ? this.minCreativeReach : this.minReach;
        } else {
            return this.minReach * this.mobFactor;
        }
    }

    public float effectiveMaxRange(class_1297 entity) {
        if (entity instanceof class_1657 player) {
            return player.method_7337() ? this.maxCreativeReach : this.maxReach;
        } else {
            return this.maxReach * this.mobFactor;
        }
    }

    public boolean isInRange(class_1309 attacker, class_243 location) {
        return this.isInRange(attacker, location::method_1025, 0.0);
    }

    public boolean isInRange(class_1309 attacker, class_238 boundingBox, double extraBuffer) {
        return this.isInRange(attacker, boundingBox::method_49271, extraBuffer);
    }

    private boolean isInRange(class_1309 attacker, ToDoubleFunction<class_243> distanceFunction, double extraBuffer) {
        double distance = Math.sqrt(distanceFunction.applyAsDouble(attacker.method_33571()));
        double minReach = this.effectiveMinRange(attacker) - this.hitboxMargin - extraBuffer;
        double maxReach = this.effectiveMaxRange(attacker) + this.hitboxMargin + extraBuffer;
        return distance >= minReach && distance <= maxReach;
    }
    
    public static AttackRange get(class_1799 stack) {
        Object component = stack.method_57824(ModDataComponents.ATTACK_RANGE.get());
        
        if (component == null) return null;
        if (component instanceof AttackRange range) return range;
        
        return parseForeign(component);
    }
    
    private static @Nullable AttackRange parseForeign(Object component) {
        try {
            Class<?> clazz = component.getClass();
            
            float minReach = (float) clazz.getMethod("minReach").invoke(component);
            float maxReach = (float) clazz.getMethod("maxReach").invoke(component);
            float minCreativeReach = (float) clazz.getMethod("minCreativeReach").invoke(component);
            float maxCreativeReach = (float) clazz.getMethod("maxCreativeReach").invoke(component);
            float hitboxMargin = (float) clazz.getMethod("hitboxMargin").invoke(component);
            float mobFactor = (float) clazz.getMethod("mobFactor").invoke(component);
            
            return new AttackRange(minReach, maxReach, minCreativeReach, maxCreativeReach, hitboxMargin, mobFactor);
        } catch (Exception e) {
            return null;
        }
    }
}