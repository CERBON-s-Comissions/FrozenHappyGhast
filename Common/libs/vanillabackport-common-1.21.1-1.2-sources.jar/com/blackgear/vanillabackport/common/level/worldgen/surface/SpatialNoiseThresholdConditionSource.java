package com.blackgear.vanillabackport.common.level.worldgen.surface;

import com.blackgear.vanillabackport.common.api.extensions.worldgen.ContextNoiseSampler;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.function.DoubleSupplier;
import net.minecraft.class_5216.class_5487;
import net.minecraft.class_5321;
import net.minecraft.class_6686;
import net.minecraft.class_7243;
import net.minecraft.class_7924;

public class SpatialNoiseThresholdConditionSource implements class_6686.class_6693 {
    private static final MapCodec<SpatialNoiseThresholdConditionSource> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
        class_5321.method_39154(class_7924.field_41244).fieldOf("noise").forGetter(condition -> condition.noise),
        Codec.DOUBLE.fieldOf("min_threshold").forGetter(condition -> condition.minThreshold),
        Codec.DOUBLE.fieldOf("max_threshold").forGetter(condition -> condition.maxThreshold)
    ).apply(instance, SpatialNoiseThresholdConditionSource::new));
    public static final class_7243<SpatialNoiseThresholdConditionSource> CODEC = class_7243.method_42116(MAP_CODEC);

    private final class_5321<class_5487> noise;
    private final double minThreshold;
    private final double maxThreshold;

    public SpatialNoiseThresholdConditionSource(class_5321<class_5487> noise, double minThreshold, double maxThreshold) {
        this.noise = noise;
        this.minThreshold = minThreshold;
        this.maxThreshold = maxThreshold;
    }

    @Override
    public class_7243<? extends class_6686.class_6693> method_39064() {
        return CODEC;
    }

    @Override
    public class_6686.class_6692 apply(class_6686.class_6694 context) {
        DoubleSupplier noise = ((ContextNoiseSampler) (Object) context).getNoiseSampler3D(this.noise);
        return new NoiseThresholdCondition(this, noise);
    }

    private record NoiseThresholdCondition(SpatialNoiseThresholdConditionSource source, DoubleSupplier noise) implements class_6686.class_6692 {
        @Override
        public boolean method_39069() {
            double value = noise.getAsDouble();
            return value >= source.minThreshold && value <= source.maxThreshold;
        }
    }
}