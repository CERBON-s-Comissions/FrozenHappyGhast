package com.blackgear.vanillabackport.common.level.worldgen.tree.trunk;

import com.blackgear.vanillabackport.common.registries.worldgen.ModTrunkPlacers;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2465;
import net.minecraft.class_2680;
import net.minecraft.class_3746;
import net.minecraft.class_4643;
import net.minecraft.class_4647;
import net.minecraft.class_5141;
import net.minecraft.class_5142;
import net.minecraft.class_5819;
import net.minecraft.class_6017;

public class PoplarTrunkPlacer extends class_5141 {
    public static final MapCodec<PoplarTrunkPlacer> CODEC = RecordCodecBuilder.mapCodec(instance -> method_28904(instance).and(instance.group(
        class_6017.method_35004(0, 8).fieldOf("trunk_height_above_branches").forGetter(placer -> placer.trunkHeightAboveBranches),
        class_6017.method_35004(1, 4).fieldOf("branch_amount").forGetter(placer -> placer.branchAmount)
    )).apply(instance, PoplarTrunkPlacer::new));
    private final class_6017 trunkHeightAboveBranches;
    private final class_6017 branchAmount;
    
    public PoplarTrunkPlacer(int baseHeight, int heightRandA, int heightRandB, class_6017 trunkHeightAboveBranches, class_6017 branchAmount) {
        super(baseHeight, heightRandA, heightRandB);
        this.trunkHeightAboveBranches = trunkHeightAboveBranches;
        this.branchAmount = branchAmount;
    }
    
    @Override
    protected class_5142<?> method_28903() {
        return ModTrunkPlacers.POPLAR_TRUNK_PLACER.get();
    }
    
    @Override
    public List<class_4647.class_5208> method_26991(
        class_3746 level,
        BiConsumer<class_2338, class_2680> blockSetter,
        class_5819 random,
        int freeTreeHeight,
        class_2338 pos,
        class_4643 config
    ) {
        int trunkHeightUpToFoliageBranches = freeTreeHeight - this.trunkHeightAboveBranches.method_35008(random);
        
        for (int y = 0; y < freeTreeHeight; y++) {
            this.method_35375(level, blockSetter, random, pos.method_10086(y), config);
            List<class_2350> directions = getShuffledBranchDirections(random);
            if (trunkHeightUpToFoliageBranches - 1 == y) {
                int branches = this.branchAmount.method_35008(random);
                
                for (int x = 0; x < branches; x++) {
                    class_2350 branchDirection = directions.get(x);
                    this.method_27402(level, blockSetter, random, pos.method_10086(y).method_10079(branchDirection, 1), config, getSidewaysStateModifier(branchDirection));
                }
            }
        }

        return List.of(new class_4647.class_5208(pos.method_10086(trunkHeightUpToFoliageBranches), 0, false));
    }
    
    private static Function<class_2680, class_2680> getSidewaysStateModifier(class_2350 branchDirection) {
        return state -> state.method_47968(class_2465.field_11459, branchDirection.method_10166());
    }
    
    private static List<class_2350> getShuffledBranchDirections(class_5819 random) {
        return class_2350.method_42014(random).stream()
            .filter(direction -> !direction.method_10166().method_10178())
            .collect(Collectors.toList());
    }
}