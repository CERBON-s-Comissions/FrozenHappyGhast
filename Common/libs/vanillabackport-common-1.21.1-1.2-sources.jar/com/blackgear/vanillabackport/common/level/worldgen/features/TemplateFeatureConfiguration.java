package com.blackgear.vanillabackport.common.level.worldgen.features;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_2470;
import net.minecraft.class_2960;
import net.minecraft.class_3037;
import net.minecraft.class_3828;
import net.minecraft.class_5497;
import net.minecraft.class_6005;
import net.minecraft.class_6880;

public record TemplateFeatureConfiguration(class_6005<TemplateEntry> templates, Optional<class_6880<class_5497>> processors) implements class_3037 {
    public static final Codec<TemplateFeatureConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group(
        class_6005.method_39521(TemplateEntry.CODEC).fieldOf("templates").forGetter(TemplateFeatureConfiguration::templates),
        class_3828.field_25877.optionalFieldOf("processors").forGetter(TemplateFeatureConfiguration::processors)
    ).apply(instance, TemplateFeatureConfiguration::new));

    public TemplateFeatureConfiguration(class_6005<TemplateEntry> templates) {
        this(templates, Optional.empty());
    }
    
    public static TemplateFeatureConfiguration simple(class_2960 id, class_6880<class_5497> processors) {
        return new TemplateFeatureConfiguration(class_6005.method_38061(TemplateEntry.of(id)), Optional.of(processors));
    }
    
    public static TemplateFeatureConfiguration simple(class_2960 id) {
        return new TemplateFeatureConfiguration(class_6005.method_38061(TemplateEntry.of(id)), Optional.empty());
    }
    
    public record TemplateEntry(class_2960 template, List<class_2470> rotations) {
        public static final Codec<TemplateEntry> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            class_2960.field_25139.fieldOf("id").forGetter(TemplateEntry::template),
            class_2470.field_39313.listOf().optionalFieldOf("rotations", List.of(class_2470.values())).forGetter(TemplateEntry::rotations)
        ).apply(instance, TemplateEntry::new));

        public static TemplateEntry of(class_2960 template) {
            return new TemplateEntry(template, List.of(class_2470.values()));
        }
    }
}