package com.blackgear.vanillabackport.common.level.worldgen.features;

import com.blackgear.vanillabackport.common.level.worldgen.features.TemplateFeatureConfiguration.TemplateEntry;
import com.blackgear.vanillabackport.core.util.Utilities.DirectionUtils;
import com.mojang.serialization.Codec;
import net.minecraft.class_156;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_2470;
import net.minecraft.class_3031;
import net.minecraft.class_3485;
import net.minecraft.class_3491;
import net.minecraft.class_3492;
import net.minecraft.class_3499;
import net.minecraft.class_5281;
import net.minecraft.class_5819;
import net.minecraft.class_5821;

public class TemplateFeature extends class_3031<TemplateFeatureConfiguration> {
    public TemplateFeature(Codec<TemplateFeatureConfiguration> codec) {
        super(codec);
    }

    @Override
    public boolean method_13151(class_5821<TemplateFeatureConfiguration> context) {
        class_5819 random = context.method_33654();
        class_5281 level = context.method_33652();
        TemplateFeatureConfiguration config = context.method_33656();
        TemplateEntry entry = config.templates().method_34973(random).orElseThrow();
        class_2470 rotation = class_156.method_32309(entry.rotations(), random);
        class_3485 manager = level.method_8410().method_14183();
        class_3499 template = manager.method_15091(entry.template());
        class_2382 offsetX = this.getRotatedOffset(rotation, class_2350.class_2351.field_11048, template);
        class_2382 offsetZ = this.getRotatedOffset(rotation, class_2350.class_2351.field_11051, template);
        class_2338 pos = context.method_33655().method_10081(offsetX).method_10081(offsetZ);
        class_3492 settings = new class_3492().method_15123(rotation).method_15112(random);
        
        if (config.processors().isPresent()) {
            for (class_3491 processor : config.processors().get().comp_349().method_31027()) {
                settings.method_16184(processor);
            }
        }
        
        return template.method_15172(level, pos, pos, settings, random, 3);
    }
    
    private class_2382 getRotatedOffset(class_2470 rotation, class_2350.class_2351 axis, class_3499 template) {
        return rotation.method_10503(DirectionUtils.getNegative(axis)).method_10163().method_35862(template.method_15160().method_30558(axis) / 2);
    }
}