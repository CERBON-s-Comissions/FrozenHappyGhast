package com.blackgear.vanillabackport.common.level.entities.boat;

import com.blackgear.vanillabackport.client.registries.ModModelLayers;
import com.mojang.datafixers.util.Pair;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1690;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_4595;
import net.minecraft.class_554;
import net.minecraft.class_5601;
import net.minecraft.class_5617;
import net.minecraft.class_630;
import net.minecraft.class_7752;
import net.minecraft.class_7753;
import net.minecraft.class_7754;
import net.minecraft.client.model.*;
import java.util.Collection;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Supplier;

public final class BoatRegistry {
    public static final class_2960 DEFAULT_TYPE = class_2960.method_60656("oak");
    private static final Map<class_2960, BoatType> TYPES = new ConcurrentHashMap<>();
    
    static {
        register(DEFAULT_TYPE, () -> class_1802.field_8533, () -> class_1802.field_38216, () -> class_2246.field_10161, false);
    }
    
    public static BoatType register(class_2960 id, Supplier<class_1792> boat, Supplier<class_1792> chestBoat, Supplier<class_2248> planks, boolean isRaft) {
        BoatType type = new BoatType(id, boat, chestBoat, planks, isRaft);
        TYPES.put(id, type);
        return type;
    }
    
    public static BoatType getType(class_2960 id) {
        return TYPES.getOrDefault(id, TYPES.get(DEFAULT_TYPE));
    }
    
    public static Collection<BoatType> getAllTypes() {
        return TYPES.values();
    }
    
    @Environment(EnvType.CLIENT)
    public static Map<BoatType, Pair<class_2960, class_4595<class_1690>>> createModels(class_5617.class_5618 context, boolean chest) {
        Map<BoatType, Pair<class_2960, class_4595<class_1690>>> map = new IdentityHashMap<>();
        for (BoatType type : TYPES.values()) {
            class_2960 texture = chest ? type.chestTexture() : type.texture();
            class_4595<class_1690> model = createModel(context, type, chest);
            map.put(type, Pair.of(texture, model));
        }
        
        return map;
    }
    
    @Environment(EnvType.CLIENT)
    private static class_4595<class_1690> createModel(class_5617.class_5618 context, BoatType type, boolean chest) {
        class_5601 layer = chest ? ModModelLayers.CUSTOM_CHEST_BOAT : ModModelLayers.CUSTOM_BOAT;
        class_630 part = context.method_32167(layer);
        
        if (type.isRaft()) {
            return chest ? new class_7753(part) : new class_7754(part);
        }
        
        return chest ? new class_7752(part) : new class_554(part);
    }
    
    public record BoatType(
        class_2960 id,
        Supplier<class_1792> boatItem,
        Supplier<class_1792> chestBoatItem,
        Supplier<class_2248> planksBlock,
        boolean isRaft,
        class_2960 texture,
        class_2960 chestTexture
    ) {
        public BoatType(class_2960 id, Supplier<class_1792> boatItem, Supplier<class_1792> chestBoatItem, Supplier<class_2248> planksBlock, boolean isRaft) {
            this(
                id,
                boatItem,
                chestBoatItem,
                planksBlock,
                isRaft,
                class_2960.method_60655(id.method_12836(), "textures/entity/boat/" + id.method_12832() + ".png"),
                class_2960.method_60655(id.method_12836(), "textures/entity/chest_boat/" + id.method_12832() + ".png")
            );
        }
        
        public class_1792 getBoat() { return this.boatItem.get(); }
        public class_1792 getChestBoat() { return this.chestBoatItem.get(); }
        public class_2248 getPlanks() { return this.planksBlock.get(); }
    }
}