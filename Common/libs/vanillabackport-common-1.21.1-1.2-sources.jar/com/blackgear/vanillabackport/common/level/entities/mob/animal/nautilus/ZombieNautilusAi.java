package com.blackgear.vanillabackport.common.level.entities.mob.animal.nautilus;

import com.blackgear.vanillabackport.client.registries.ModSoundEvents;
import com.blackgear.vanillabackport.common.level.entities.ai.behavior.ChargeAttack;
import com.blackgear.vanillabackport.common.registries.entities.ModMemoryModuleTypes;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import com.mojang.datafixers.util.Pair;
import net.minecraft.class_4095;
import net.minecraft.class_4103;
import net.minecraft.class_4110;
import net.minecraft.class_4112;
import net.minecraft.class_4120;
import net.minecraft.class_4140;
import net.minecraft.class_4141;
import net.minecraft.class_4168;
import net.minecraft.class_4818;
import net.minecraft.class_4824;
import net.minecraft.class_5753;
import net.minecraft.class_5754;
import net.minecraft.world.entity.ai.behavior.*;
import java.util.Set;

public class ZombieNautilusAi {
    public static class_4095.class_5303<ZombieNautilus> brainProvider() {
        return class_4095.method_28311(NautilusAi.MEMORY_TYPES, NautilusAi.SENSOR_TYPES);
    }
    
    public static class_4095<?> makeBrain(class_4095<ZombieNautilus> brain) {
        initCoreActivity(brain);
        initIdleActivity(brain);
        initFightActivity(brain);
        brain.method_18890(Set.of(class_4168.field_18594));
        brain.method_18897(class_4168.field_18595);
        brain.method_24536();
        return brain;
    }
    
    public static void initCoreActivity(class_4095<ZombieNautilus> brain) {
        brain.method_18882(
            class_4168.field_18594,
            0,
            ImmutableList.of(
                new class_4110(45, 90),
                new class_4112(),
                new class_5753(class_4140.field_28326),
                new class_5753(ModMemoryModuleTypes.CHARGE_COOLDOWN_TICKS.get()),
                new class_5753(ModMemoryModuleTypes.ATTACK_TARGET_COOLDOWN.get())
            )
        );
    }
    
    public static void initIdleActivity(class_4095<ZombieNautilus> brain) {
        brain.method_18881(
            class_4168.field_18595,
            ImmutableList.of(
                Pair.of(1, new class_5754(mob -> 1.3F, mob -> mob.method_6109() ? 2.5 : 3.5)),
                Pair.of(2, class_4824.method_47119(NautilusAi::findNearestValidAttackTarget)),
                Pair.of(3, new class_4103<>(
                    ImmutableMap.of(class_4140.field_18445, class_4141.field_18457),
                    ImmutableSet.of(),
                    class_4103.class_4104.field_18348,
                    class_4103.class_4216.field_18856,
                    ImmutableList.of(
                        Pair.of(class_4818.method_47027(1.0F), 2),
                        Pair.of(class_4120.method_47104(1.0F, 3), 3)
                    )
                ))
            )
        );
    }
    
    public static void initFightActivity(class_4095<ZombieNautilus> brain) {
        brain.method_24529(
            class_4168.field_22396,
            ImmutableList.of(
                Pair.of(0, new ChargeAttack(80, NautilusAi.ATTACK_TARGET_CONDITIONS, 0.6F, 2.0F, 12.0, 11.0, ModSoundEvents.ZOMBIE_NAUTILUS_DASH.get()))
            ),
            ImmutableSet.of(
                Pair.of(class_4140.field_22355, class_4141.field_18456),
                Pair.of(class_4140.field_28325, class_4141.field_18457),
                Pair.of(class_4140.field_18448, class_4141.field_18457),
                Pair.of(ModMemoryModuleTypes.CHARGE_COOLDOWN_TICKS.get(), class_4141.field_18457)
            )
        );
    }
    
    public static void updateActivity(AbstractNautilus nautilus) {
        nautilus.method_18868().method_24531(ImmutableList.of(class_4168.field_22396, class_4168.field_18595));
    }
}