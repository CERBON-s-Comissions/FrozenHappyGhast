package com.blackgear.vanillabackport.common.level.entities.mob.animal.golem.copper_golem.container;

import net.minecraft.class_1309;
import net.minecraft.class_2338;
import net.minecraft.class_5561;

public interface ContainerUser {
    boolean hasContainerOpen(class_5561 container, class_2338 blockPos);
    
    double getContainerInteractionRange();
    
    default class_1309 getLivingEntity() {
        if (this instanceof class_1309 living) {
            return living;
        } else {
            throw new IllegalStateException("A container user must be a LivingEntity");
        }
    }
}