package com.blackgear.vanillabackport.common.level.sounds;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_5699;
import net.minecraft.class_5819;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7924;

public record AmbientLeavesBlockSoundPlayer(
    Optional<class_6880<class_3414>> ambientSound,
    int chance,
    Optional<class_6862<class_2248>> satisfyingBlocks,
    int nearbySatisfyingBlocksRequired,
    int nearbySameLeavesRequired
) {
    public static final Codec<AmbientLeavesBlockSoundPlayer> CODEC = RecordCodecBuilder.create(instance -> instance.group(
        class_3414.field_41699.optionalFieldOf("ambient_sound").forGetter(AmbientLeavesBlockSoundPlayer::ambientSound),
        class_5699.field_33441.optionalFieldOf("chance", 300).forGetter(AmbientLeavesBlockSoundPlayer::chance),
        class_6862.method_40090(class_7924.field_41254).optionalFieldOf("satisfying_blocks").forGetter(AmbientLeavesBlockSoundPlayer::satisfyingBlocks),
        class_5699.field_33441.optionalFieldOf("nearby_satisfying_blocks_required", 1).forGetter(AmbientLeavesBlockSoundPlayer::nearbySatisfyingBlocksRequired),
        class_5699.field_33441.optionalFieldOf("nearby_same_leaves_required", 3).forGetter(AmbientLeavesBlockSoundPlayer::nearbySameLeavesRequired)
    ).apply(instance, AmbientLeavesBlockSoundPlayer::new));
    private static final AmbientLeavesBlockSoundPlayer NO_SOUND = new AmbientLeavesBlockSoundPlayer(Optional.empty(), 0, Optional.empty(), 0, 0);
    
    public static AmbientLeavesBlockSoundPlayer of(class_6880<class_3414> ambientSound, class_6862<class_2248> satisfyingBlocks) {
        return new AmbientLeavesBlockSoundPlayer(Optional.of(ambientSound), 300, Optional.of(satisfyingBlocks), 1, 3);
    }
    
    public static AmbientLeavesBlockSoundPlayer noAmbientSound() {
        return NO_SOUND;
    }
    
    public void playAmbientLeavesSounds(class_1937 level, class_2338 pos, class_2248 block, class_5819 random) {
        if (this.ambientSound.isPresent() && random.method_43048(this.chance) == 0) {
            class_6862<class_2248> satisfyingBlocks = this.satisfyingBlocks.orElse(null);
            int nearbyLogs = 0;
            int nearbyLeaves = 0;
            
            for (class_2350 direction : class_2350.class_2353.field_11062) {
                class_2338 neighborPos = pos.method_10093(direction);
                class_2680 neighborState = level.method_8320(neighborPos);
                if (satisfyingBlocks != null && neighborState.method_26164(satisfyingBlocks)) {
                    nearbyLogs++;
                }
                
                if (neighborState.method_27852(block)) {
                    nearbyLeaves++;
                }
                
                if (nearbyLogs == this.nearbySatisfyingBlocksRequired && nearbyLeaves == this.nearbySameLeavesRequired) {
                    level.method_8486(pos.method_10263(), pos.method_10264(), pos.method_10260(), this.ambientSound.get().comp_349(), class_3419.field_15256, 1.0F, 1.0F, false);
                    return;
                }
            }
        }
    }

}