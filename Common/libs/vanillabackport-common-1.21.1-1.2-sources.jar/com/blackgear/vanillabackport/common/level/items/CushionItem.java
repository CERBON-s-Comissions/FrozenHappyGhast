package com.blackgear.vanillabackport.common.level.items;

import com.blackgear.vanillabackport.client.registries.ModSoundEvents;
import com.blackgear.vanillabackport.common.level.entities.decoration.Cushion;
import com.blackgear.vanillabackport.common.registries.entities.ModEntityTypes;
import com.blackgear.vanillabackport.core.data.tags.ModBlockTags;
import java.util.function.Consumer;
import net.minecraft.class_1269;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3419;
import net.minecraft.class_3730;
import net.minecraft.class_3965;
import net.minecraft.class_5712;

public class CushionItem extends class_1792 {
    private final class_1767 color;
    
    public CushionItem(class_1793 properties, class_1767 color) {
        super(properties);
        this.color = color;
    }
    
    @Override
    public class_1269 method_7884(class_1838 context) {
        class_1838 recalculatedContext = recalculateContextForSpecialCollisionShapes(context);
        class_2350 clickedFace = recalculatedContext.method_8038();
        if (clickedFace != class_2350.field_11036) return class_1269.field_5814;
        
        class_1937 level = context.method_8045();
        class_1750 placeContext = new class_1750(recalculatedContext);
        class_2338 pos = placeContext.method_8037();
        class_243 entityPos = new class_243(pos.method_10263() + 0.5, recalculatedContext.method_17698().field_1351, pos.method_10260() + 0.5);
        class_238 spawnAABB = ModEntityTypes.CUSHION.get().method_58629(entityPos.field_1352, entityPos.field_1351, entityPos.field_1350);
        
        if (!Cushion.canBePlacedAt(level, spawnAABB)) return class_1269.field_5814;
        
        class_1799 stack = context.method_8041();
        if (level instanceof class_3218 server) {
            if (!server.method_18467(Cushion.class, spawnAABB).isEmpty()) return class_1269.field_5814;
            
            Consumer<Cushion> entityConfig = class_1299.method_48009(server, stack, context.method_8036());
            Cushion cushion = ModEntityTypes.CUSHION.get().method_5888(server, entityConfig, pos, class_3730.field_16465, true, true);
            if (cushion == null) return class_1269.field_5814;
            
            cushion.method_60949(entityPos, class_2350.method_10150(placeContext.method_8044()).method_10144(), 0.0F);
            cushion.setColor(this.color);
            server.method_8649(cushion);
            cushion.destroyIfInFire(server);
            level.method_43128(null, cushion.method_23317(), cushion.method_23318(), cushion.method_23321(), ModSoundEvents.CUSHION_PLACE.get(), class_3419.field_15245, 0.75F, 0.8F);
            cushion.method_32875(class_5712.field_28738, context.method_8036());
            stack.method_57008(1, placeContext.method_8036());
        }
        
        return class_1269.field_5812;
    }

    private static class_1838 recalculateContextForSpecialCollisionShapes(final class_1838 context) {
        class_1657 player = context.method_8036();
        if (player == null) {
            return context;
        } else {
            class_1937 level = context.method_8045();
            class_2338 clickedPos = context.method_8037();
            class_2680 clickedState = level.method_8320(clickedPos);
            if (!clickedState.method_26164(ModBlockTags.CUSHION_USES_COLLISION_SHAPE)) {
                return context;
            } else {
                class_243 rayFrom = player.method_33571();
                class_243 ray = context.method_17698().method_1020(rayFrom);
                class_243 rayTo = context.method_17698().method_1019(ray.method_1029().method_1021(0.001));
                class_3965 collisionHitResult = clickedState.method_26220(level, clickedPos).method_1092(rayFrom, rayTo, clickedPos);
                return collisionHitResult == null ? context : new class_1838(player, context.method_20287(), collisionHitResult);
            }
        }
    }
}