package com.blackgear.vanillabackport.common.level.worldgen.tree.foliage;

import com.blackgear.vanillabackport.common.registries.worldgen.ModFoliagePlacers;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.function.Function;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2465;
import net.minecraft.class_2680;
import net.minecraft.class_3532;
import net.minecraft.class_3746;
import net.minecraft.class_4643;
import net.minecraft.class_4647;
import net.minecraft.class_4648;
import net.minecraft.class_5819;
import net.minecraft.class_6017;

public class PoplarFoliagePlacer extends class_4647 {
    public static final MapCodec<PoplarFoliagePlacer> CODEC = RecordCodecBuilder.mapCodec(instance -> method_30411(instance).and(instance.group(
        class_6017.method_35004(5, 16).fieldOf("height").forGetter(placer -> placer.height),
        Codec.floatRange(0.0F, 1.0F).fieldOf("side_hole_chance").forGetter(placer -> placer.sideHoleChance)
    )).apply(instance, PoplarFoliagePlacer::new));
    private final class_6017 height;
    private final float sideHoleChance;
    
    public PoplarFoliagePlacer(class_6017 radius, class_6017 offset, class_6017 height, float sideHoleChance) {
        super(radius, offset);
        this.height = height;
        this.sideHoleChance = sideHoleChance;
    }
    
    @Override
    protected class_4648<?> method_28843() {
        return ModFoliagePlacers.POPLAR_FOLIAGE_PLACER.get();
    }
    
    @Override
    protected void method_23448(
        class_3746 level,
        class_8179 blockSetter,
        class_5819 random,
        class_4643 config,
        int maxFreeTreeHeight,
        class_5208 attachment,
        int foliageHeight,
        int foliageRadius,
        int offset
    ) {
        boolean doubleTrunk = attachment.method_27390();
        class_2338 foliagePos = attachment.method_27388().method_10086(offset);
        int currentRadius = foliageRadius + attachment.method_27389() - 1;
        boolean flipRhombusShape = random.method_43056();
        this.placeLeavesRow(level, blockSetter, random, config, foliagePos, currentRadius - 2, foliageHeight - 1, doubleTrunk, foliageHeight, flipRhombusShape);
        this.placeLeavesRow(level, blockSetter, random, config, foliagePos, currentRadius - 1, foliageHeight - 2, doubleTrunk, foliageHeight, flipRhombusShape);
        this.placeLeavesRow(level, blockSetter, random, config, foliagePos, currentRadius - 1, foliageHeight - 3, doubleTrunk, foliageHeight, flipRhombusShape);
        
        for (int y = foliageHeight - 4; y >= 1; y--) {
            this.placeLeavesRow(level, blockSetter, random, config, foliagePos, currentRadius, y, doubleTrunk, foliageHeight, flipRhombusShape);
        }
        
        this.replaceLeavesWithLog(level, blockSetter, config, random, foliagePos, currentRadius, foliageHeight - 4, doubleTrunk, foliageHeight, flipRhombusShape);
        this.placeLeavesRow(level, blockSetter, random, config, foliagePos, currentRadius - 1, 0, doubleTrunk, foliageHeight, flipRhombusShape);
        this.placeLeavesRow(level, blockSetter, random, config, foliagePos, class_3532.method_15340(currentRadius - 2, 1, 2), -1, doubleTrunk, foliageHeight, flipRhombusShape);
    }
    
    private void replaceLeavesWithLog(
        class_3746 level,
        class_4647.class_8179 foliageSetter,
        class_4643 tree,
        class_5819 random,
        class_2338 origin,
        int currentRadius,
        int y,
        boolean doubleTrunk,
        int foliageHeight,
        boolean flipRhombusShape
    ) {
        int offset = doubleTrunk ? 1 : 0;
        class_2338.class_2339 pos = new class_2338.class_2339();
        
        for (int dx = -currentRadius; dx <= currentRadius + offset; dx++) {
            for (int dz = -currentRadius; dz <= currentRadius + offset; dz++) {
                int absDz = class_3532.method_15382(dz);
                int absDx = class_3532.method_15382(dx);
                if (isWithinRhombusShape(currentRadius, absDx, absDz, this.getCornerBlocksToCutForRhombusShape(dx, dz, currentRadius, this.shouldRowBePartialRhombusShape(foliageHeight, y), flipRhombusShape), 2)
                    && (absDz == 0 && currentRadius - absDx >= 4 || absDx == 0 && currentRadius - absDz >= 4)) {
                    pos.method_25504(origin, dx, y, dz);
                    tryPlaceLog(level, foliageSetter, random, tree, pos, getSidewaysStateModifier(class_2350.method_10169(absDz == 0 ? class_2350.class_2351.field_11048 : class_2350.class_2351.field_11051, class_2350.class_2352.field_11056)));
                }
            }
        }
    }
    
    private static void tryPlaceLog(
        class_3746 level,
        class_4647.class_8179 foliageSetter,
        class_5819 random,
        class_4643 tree,
        class_2338 pos,
        Function<class_2680, class_2680> stateModifier
    ) {
        if (level.method_16358(pos, state -> state.equals(tree.field_29280.method_23455(random, pos)))) {
            foliageSetter.method_49240(pos, stateModifier.apply(tree.field_21288.method_23455(random, pos)));
        }
    }
    
    private static Function<class_2680, class_2680> getSidewaysStateModifier(class_2350 branchDirection) {
        return state -> state.method_47968(class_2465.field_11459, branchDirection.method_10166());
    }
    
    @Override
    public int method_26989(class_5819 random, int height, class_4643 config) {
        return this.height.method_35008(random);
    }
    
    private void placeLeavesRow(
        class_3746 level,
        class_4647.class_8179 foliageSetter,
        class_5819 random,
        class_4643 tree,
        class_2338 origin,
        int currentRadius,
        int y,
        boolean doubleTrunk,
        int foliageHeight,
        boolean flipRhombusShape
    ) {
        int offset = doubleTrunk ? 1 : 0;
        class_2338.class_2339 pos = new class_2338.class_2339();
        
        for (int dx = -currentRadius; dx <= currentRadius + offset; dx++) {
            for (int dz = -currentRadius; dz <= currentRadius + offset; dz++) {
                if (!this.shouldSkipLocation(random, dx, y, dz, currentRadius, foliageHeight, flipRhombusShape)) {
                    pos.method_25504(origin, dx, y, dz);
                    method_34359(level, foliageSetter, random, tree, pos);
                }
            }
        }
    }
    
    private boolean shouldSkipLocation(
        class_5819 random,
        int dx,
        int y,
        int dz,
        int currentRadius,
        int foliageHeight,
        boolean flipRhombusShape
    ) {
        boolean shouldRowBePartialRhombusShape = this.shouldRowBePartialRhombusShape(foliageHeight, y);
        int cornerBlocksToCutForRhombusShape = this.getCornerBlocksToCutForRhombusShape(dx, dz, currentRadius, shouldRowBePartialRhombusShape, flipRhombusShape);
        int absDx = class_3532.method_15382(dx);
        int absDz = class_3532.method_15382(dz);
        boolean isRhombusEdgeBlock = absDx == currentRadius || absDz == currentRadius;
        if (shouldRowBePartialRhombusShape && isRhombusEdgeBlock) {
            return true;
        } else {
            int additionalSideRemoval = random.method_43057() <= this.sideHoleChance ? 1 : 0;
            return !isWithinRhombusShape(currentRadius, absDx, absDz, cornerBlocksToCutForRhombusShape, additionalSideRemoval);
        }
    }
    
    @Override
    protected boolean method_27387(class_5819 random, int localX, int localY, int localZ, int range, boolean large) {
        throw new IllegalStateException("Overridden method needs more context");
    }
    
    @Override
    protected boolean method_23451(class_5819 random, int localX, int localY, int localZ, int range, boolean large) {
        throw new IllegalStateException("Overridden method needs more context");
    }
    
    private int getCornerBlocksToCutForRhombusShape(int x, int z, int currentRadius, boolean shouldRowBePartialRhombusShape, boolean flipRhombusShape) {
        boolean isSmallCornerOfShape = flipRhombusShape ? isLeftTopCornerOrRightLowerCorner(x, z) : isLeftLowerCornerOrRightTopCorner(x, z);
        return isSmallCornerOfShape ? currentRadius - 1 : (shouldRowBePartialRhombusShape ? currentRadius + 1 : currentRadius);
    }
    
    private static boolean isWithinRhombusShape(int currentRadius, int absDx, int absDz, int cornerBlocksToCutForRhombusShape, int additionalSideRemoval) {
        return absDx + absDz <= currentRadius * 2 - (cornerBlocksToCutForRhombusShape + additionalSideRemoval);
    }
    
    private static boolean isLeftLowerCornerOrRightTopCorner(int dx, int dz) {
        return dx > 0 && dz < 0 || dz > 0 && dx < 0;
    }
    
    private static boolean isLeftTopCornerOrRightLowerCorner(int dx, int dz) {
        return dx > 0 && dz > 0 || dz < 0 && dx < 0;
    }
    
    private boolean shouldRowBePartialRhombusShape(int foliageHeight, int y) {
        return foliageHeight - 1 == y || foliageHeight - 2 == y;
    }
}