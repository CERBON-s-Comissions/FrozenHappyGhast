package com.blackgear.vanillabackport.common.level.entities.mob.monster.creaking;

import com.blackgear.vanillabackport.client.registries.ModParticles;
import com.blackgear.vanillabackport.client.registries.ModSoundEvents;
import com.blackgear.vanillabackport.common.level.block_entities.CreakingHeartBlockEntity;
import com.blackgear.vanillabackport.common.level.blocks.CreakingHeartBlock;
import com.blackgear.vanillabackport.common.level.blocks.CreakingHeartState;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import com.blackgear.vanillabackport.core.util.WorldUtilities.EntityUtils;
import com.mojang.serialization.Dynamic;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_13;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1330;
import net.minecraft.class_1333;
import net.minecraft.class_1334;
import net.minecraft.class_1335;
import net.minecraft.class_14;
import net.minecraft.class_1408;
import net.minecraft.class_1409;
import net.minecraft.class_1493;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1676;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2382;
import net.minecraft.class_2388;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2512;
import net.minecraft.class_2680;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3695;
import net.minecraft.class_4095;
import net.minecraft.class_4140;
import net.minecraft.class_4538;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.class_5712;
import net.minecraft.class_7;
import net.minecraft.class_7094;
import net.minecraft.class_8103;
import net.minecraft.class_9316;
import net.minecraft.world.entity.*;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Optional;

public class Creaking extends class_1588 {
    private static final class_2940<Boolean> CAN_MOVE = class_2945.method_12791(Creaking.class, class_2943.field_13323);
    private static final class_2940<Boolean> IS_ACTIVE = class_2945.method_12791(Creaking.class, class_2943.field_13323);
    private static final class_2940<Boolean> IS_TEARING_DOWN = class_2945.method_12791(Creaking.class, class_2943.field_13323);
    private static final class_2940<Optional<class_2338>> HOME_POS = class_2945.method_12791(Creaking.class, class_2943.field_13315);

    public static final byte CREAKING_ATTACK = 4;
    public static final byte CREAKING_HURT = 66;

    private int attackAnimationRemainingTicks;
    public final class_7094 attackAnimationState = new class_7094();
    public final class_7094 invulnerabilityAnimationState = new class_7094();
    public final class_7094 deathAnimationState = new class_7094();
    private int invulnerabilityAnimationRemainingTicks;
    private boolean eyesGlowing;
    private int nextFlickerTime;
    private int playerStuckCounter;
    private int creakingDeathTime;

    public Creaking(class_1299<? extends class_1588> entityType, class_1937 level) {
        super(entityType, level);
        this.field_6206 = new CreakingLookControl(this);
        this.field_6207 = new CreakingMoveControl(this);
        this.field_6204 = new CreakingJumpControl(this);
        class_1409 navigation = (class_1409) this.method_5942();
        navigation.method_6354(true);
        this.field_6194 = 0;
    }

    public void setTransient(class_2338 pos) {
        this.setHomePos(pos);
        this.method_5941(class_7.field_17, 8.0F);
        this.method_5941(class_7.field_33534, 8.0F);
        this.method_5941(class_7.field_14, 8.0F);
        this.method_5941(class_7.field_3, 0.0F);
        this.method_5941(class_7.field_9, 0.0F);
    }

    public boolean isHeartBound() {
        return this.getHomePos() != null;
    }

    @Override
    protected class_1330 method_5963() {
        return new CreakingBodyRotationControl(this);
    }

    @Override
    protected class_4095.class_5303<Creaking> method_28306() {
        return CreakingAi.brainProvider();
    }

    @Override
    protected class_4095<?> method_18867(Dynamic<?> dynamic) {
        return CreakingAi.makeBrain(this.method_28306().method_28335(dynamic));
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        super.method_5693(builder);
        builder.method_56912(CAN_MOVE, true);
        builder.method_56912(IS_ACTIVE, false);
        builder.method_56912(IS_TEARING_DOWN, false);
        builder.method_56912(HOME_POS, Optional.empty());
    }

    public static class_5132.class_5133 createAttributes() {
        return class_1588.method_26918()
            .method_26868(class_5134.field_23716, 1.0)
            .method_26868(class_5134.field_23719, 0.4)
            .method_26868(class_5134.field_23721, 3.0)
            .method_26868(class_5134.field_23717, 32.0)
            .method_26868(class_5134.field_47761, 1.0625);
    }

    public boolean canMove() {
        return this.field_6011.method_12789(CAN_MOVE);
    }

    @Override
    public boolean method_6121(class_1297 target) {
        if (!(target instanceof class_1309)) {
            return false;
        } else {
            this.attackAnimationRemainingTicks = 15;
            this.method_37908().method_8421(this, CREAKING_ATTACK);
            return super.method_6121(target);
        }
    }

    @Override
    public boolean method_5643(class_1282 source, float amount) {
        class_2338 homePos = this.getHomePos();
        if (homePos == null || source.method_48789(class_8103.field_42242)) {
            return super.method_5643(source, amount);
        } else if (!this.method_5679(source) && this.invulnerabilityAnimationRemainingTicks <= 0 && !this.method_29504()) {
            class_1657 responsiblePlayer = this.blameSourceForDamage(source);
            class_1297 directEntity = source.method_5526();
            if (directEntity instanceof class_1309 || directEntity instanceof class_1676 || responsiblePlayer != null) {
                this.invulnerabilityAnimationRemainingTicks = 8;
                this.method_37908().method_8421(this, CREAKING_HURT);
                this.method_32876(class_5712.field_45148);
                if (this.method_37908().method_8321(homePos) instanceof CreakingHeartBlockEntity heart && heart.isProtector(this)) {
                    if (responsiblePlayer != null) {
                        heart.creakingHurt();
                    }

                    this.method_6013(source);
                }

                return true;
            }
        }

        return false;
    }

    @Nullable
    public class_1657 blameSourceForDamage(class_1282 source) {
        class_1297 sourceEntity = source.method_5529();
        if (sourceEntity instanceof class_1309 living && !source.method_48789(class_8103.field_42254)) {
            this.method_6015(living);

            if (sourceEntity instanceof class_1657 player) {
                this.field_6238 = 100;
                this.field_6258 = player;
            } else if (sourceEntity instanceof class_1493 wolf && wolf.method_6181()) {
                this.field_6238 = 100;
                if (wolf.method_35057() instanceof class_1657 player) {
                    this.field_6258 = player;
                } else {
                    this.field_6258 = null;
                }
            }
        }

        return this.field_6258;
    }

    @Override
    public boolean method_5810() {
        return super.method_5810() && this.canMove();
    }

    @Override
    public void method_5762(double x, double y, double z) {
        if (this.canMove()) {
            super.method_5762(x, y, z);
        }
    }

    @Override @SuppressWarnings("unchecked")
    public class_4095<Creaking> method_18868() {
        return (class_4095<Creaking>) super.method_18868();
    }

    @Override
    protected void method_5958() {
        class_3695 profiler = this.method_37908().method_16107();
        profiler.method_15396("creakingBrain");
        this.method_18868().method_19542((class_3218) this.method_37908(), this);
        profiler.method_15407();
        CreakingAi.updateActivity(this);
    }

    @Override
    public void method_6007() {
        if (this.invulnerabilityAnimationRemainingTicks > 0) {
            this.invulnerabilityAnimationRemainingTicks--;
        }

        if (this.attackAnimationRemainingTicks > 0) {
            this.attackAnimationRemainingTicks--;
        }

        if (!this.method_37908().method_8608()) {
            boolean canMove = this.field_6011.method_12789(CAN_MOVE);
            boolean nowCanMove = this.checkCanMove();
            if (nowCanMove != canMove) {
                this.method_32876(class_5712.field_45148);
                if (nowCanMove) {
                    this.method_43077(ModSoundEvents.CREAKING_UNFREEZE.get());
                } else {
                    EntityUtils.stopInPlace(this);
                    this.method_43077(ModSoundEvents.CREAKING_FREEZE.get());
                }
            }

            this.field_6011.method_12778(CAN_MOVE, nowCanMove);
        }

        super.method_6007();
    }

    @Override
    public void method_5773() {
        if (!this.method_37908().method_8608()) {
            class_2338 homePos = this.getHomePos();
            if (homePos != null) {
                boolean hasProtectionFromCreakingHeart = this.method_37908().method_8321(homePos) instanceof CreakingHeartBlockEntity heart && heart.isProtector(this);
                if (!hasProtectionFromCreakingHeart) {
                    this.method_6033(0.0F);
                }
            }
        }

        super.method_5773();
        if (this.method_37908().method_8608()) {
            if (this.isTearingDown() && this.field_6213 != 0) this.field_6213 = 0;
            this.setupAnimationStates();
            this.checkEyeBlink();
        }
    }

    @Override
    protected void method_6108() {
        if (this.isHeartBound() && this.isTearingDown()) {
            this.creakingDeathTime++;
            if (!this.method_37908().method_8608() && this.creakingDeathTime > 45 && !this.method_31481()) {
                this.tearDown();
            }
        } else {
            super.method_6108();
        }
    }

    @Override
    protected void method_48565(float distance) {
        float targetSpeed = Math.min(distance * 25.0F, 3.0F);
        this.field_42108.method_48568(targetSpeed, 0.4F);
    }

    private void setupAnimationStates() {
        this.attackAnimationState.method_45317(this.attackAnimationRemainingTicks > 0, this.field_6012);
        this.invulnerabilityAnimationState.method_45317(this.invulnerabilityAnimationRemainingTicks > 0, this.field_6012);
        this.deathAnimationState.method_45317(this.isTearingDown(), this.field_6012);
    }

    public void tearDown() {
        if (this.method_37908() instanceof class_3218 server) {
            class_238 box = this.method_5829();
            class_243 center = box.method_1005();
            double xSpread = box.method_17939() * 0.3;
            double ySpread = box.method_17940() * 0.3;
            double zSpread = box.method_17941() * 0.3;
            ModParticles.sendParticles(server,
                new class_2388(class_2398.field_11217, ModBlocks.PALE_OAK_WOOD.get().method_9564()),
                center.field_1352,
                center.field_1351,
                center.field_1350,
                100,
                xSpread,
                ySpread,
                zSpread,
                0.0
            );
            ModParticles.sendParticles(server,
                new class_2388(class_2398.field_11217, ModBlocks.CREAKING_HEART.get().method_9564().method_11657(CreakingHeartBlock.STATE, CreakingHeartState.AWAKE)),
                center.field_1352,
                center.field_1351,
                center.field_1350,
                10,
                xSpread,
                ySpread,
                zSpread,
                0.0
            );
        }

        this.method_43077(this.method_6002());
        this.method_31472();
    }

    public void creakingDeathEffects(class_1282 source) {
        this.blameSourceForDamage(source);
        this.method_6078(source);
        this.method_43077(ModSoundEvents.CREAKING_TWITCH.get());
    }

    @Override
    public void method_5711(byte id) {
        if (id == CREAKING_HURT) {
            this.invulnerabilityAnimationRemainingTicks = 8;
            this.method_6013(this.method_48923().method_48830());
        } else if (id == CREAKING_ATTACK) {
            this.attackAnimationRemainingTicks = 15;
            this.method_59928();
        } else {
            super.method_5711(id);
        }
    }

    @Override
    public boolean method_5753() {
        return this.isHeartBound() || super.method_5753();
    }

    @Override
    protected boolean method_5818(class_1297 passenger) {
        return !this.isHeartBound() && super.method_5818(passenger);
    }
    
    @Override
    protected boolean method_48921() {
        return !this.isHeartBound() && super.method_48921();
    }

    @Override
    protected void method_5627(class_1297 passenger) {
        if (!this.isHeartBound()) super.method_5627(passenger);
    }

    @Override
    public boolean method_5822(boolean allowPassengers) {
        return !this.isHeartBound() && super.method_5822(allowPassengers);
    }

    @Override
    protected class_1408 method_5965(class_1937 level) {
        return new CreakingPathNavigation(this, level);
    }

    public boolean playerIsStuckInYou() {
        List<class_1657> players = this.field_18321.method_18904(class_4140.field_18443).orElse(List.of());
        if (!players.isEmpty()) {
            class_238 ownBox = this.method_5829();

            for (class_1657 player : players) {
                if (ownBox.method_1006(player.method_33571())) {
                    this.playerStuckCounter++;
                    return this.playerStuckCounter > 4;
                }
            }
        }

        this.playerStuckCounter = 0;
        return false;
    }

    @Override
    public void method_5749(class_2487 tag) {
        super.method_5749(tag);
        if (tag.method_10545("home_pos")) this.setTransient(class_2512.method_10691(tag, "home_pos").get());
    }

    @Override
    public void method_5652(class_2487 tag) {
        super.method_5652(tag);
        if (this.getHomePos() != null) tag.method_10566("home_pos", class_2512.method_10692(this.getHomePos()));
    }

    public void setHomePos(class_2338 pos) {
        this.field_6011.method_12778(HOME_POS, Optional.of(pos));
    }

    public class_2338 getHomePos() {
        return this.field_6011.method_12789(HOME_POS).orElse(null);
    }

    public void setTearingDown() {
        this.field_6011.method_12778(IS_TEARING_DOWN, true);
    }

    public boolean isTearingDown() {
        return this.field_6011.method_12789(IS_TEARING_DOWN);
    }

    public boolean hasGlowingEyes() {
        return this.eyesGlowing;
    }

    public boolean shouldEyesGlow() {
        return this.isTearingDown() ? this.hasGlowingEyes() : this.isActive();
    }

    public void checkEyeBlink() {
        if (this.creakingDeathTime > this.nextFlickerTime) {
            this.nextFlickerTime = this.creakingDeathTime + this.method_59922().method_39332(this.eyesGlowing ? 2 : this.creakingDeathTime / 4, this.eyesGlowing ? 8 : this.creakingDeathTime / 2);
            this.eyesGlowing = !this.eyesGlowing;
        }
    }

    public void method_59928() {
        this.method_37908().method_8486(this.method_23317(), this.method_23318(), this.method_23321(), ModSoundEvents.CREAKING_ATTACK.get(), this.method_5634(), 1.0F, 1.0F, false);
    }

    @Override
    protected @Nullable class_3414 method_5994() {
        return this.isActive() ? null : ModSoundEvents.CREAKING_AMBIENT.get();
    }

    @Override
    protected class_3414 method_6011(class_1282 source) {
        return this.isHeartBound() ? ModSoundEvents.CREAKING_SWAY.get() : super.method_6011(source);
    }

    @Override
    protected class_3414 method_6002() {
        return ModSoundEvents.CREAKING_DEATH.get();
    }

    @Override
    protected void method_5712(class_2338 pos, class_2680 state) {
        this.method_5783(ModSoundEvents.CREAKING_STEP.get(), 0.15F, 1.0F);
    }

    @Override
    public @Nullable class_1309 method_5968() {
        return this.method_18868().method_18904(class_4140.field_22355).orElse(null);
    }

    @Override
    public void method_6005(double strength, double x, double z) {
        if (this.canMove()) {
            super.method_6005(strength, x, z);
        }
    }

    public boolean checkCanMove() {
        List<class_1657> players = this.field_18321.method_18904(class_4140.field_18443).orElse(List.of());
        boolean active = this.isActive();
        if (players.isEmpty()) {
            if (active) {
                this.deactivate();
            }
        } else {
            boolean hasPotentialTarget = false;

            for (class_1657 player : players) {
                if (this.method_18395(player) && !this.method_5722(player)) {
                    hasPotentialTarget = true;
                    if ((!active || !player.method_6118(class_1304.field_6169).method_31574(class_2246.field_10147.method_8389()))
                        && EntityUtils.isLookingAtMe(this, player, 0.5, false, true, this.method_23320(), this.method_23318() + 0.5 * this.method_55693(), (this.method_23320() + this.method_23318()) / 2.0)
                    ) {
                        if (active) return false;

                        if (player.method_5858(this) < 144.0) {
                            this.activate(player);
                            return false;
                        }
                    }
                }
            }

            if (!hasPotentialTarget && active) {
                this.deactivate();
            }
        }

        return true;
    }

    public void activate(class_1657 player) {
        this.method_18868().method_18878(class_4140.field_22355, player);
        this.method_32876(class_5712.field_45148);
        this.method_43077(ModSoundEvents.CREAKING_ACTIVATE.get());
        this.setIsActive(true);
    }

    public void deactivate() {
        this.method_18868().method_18875(class_4140.field_22355);
        this.method_32876(class_5712.field_45148);
        this.method_43077(ModSoundEvents.CREAKING_DEACTIVATE.get());
        this.setIsActive(false);
    }

    public void setIsActive(boolean active) {
        this.field_6011.method_12778(IS_ACTIVE, active);
    }

    public boolean isActive() {
        return this.field_6011.method_12789(IS_ACTIVE);
    }

    @Override
    public float method_6144(class_2338 pos, class_4538 level) {
        return 0.0F;
    }

    class CreakingBodyRotationControl extends class_1330 {
        public CreakingBodyRotationControl(Creaking mob) {
            super(mob);
        }

        @Override
        public void method_6224() {
            if (Creaking.this.canMove()) {
                super.method_6224();
            }
        }
    }

    class CreakingJumpControl extends class_1334 {
        public CreakingJumpControl(Creaking mob) {
            super(mob);
        }

        @Override
        public void method_6234() {
            if (Creaking.this.canMove()) {
                super.method_6234();
            } else {
                Creaking.this.method_6100(false);
            }
        }
    }

    class CreakingLookControl extends class_1333 {
        public CreakingLookControl(Creaking mob) {
            super(mob);
        }

        @Override
        public void method_6231() {
            if (Creaking.this.canMove()) {
                super.method_6231();
            }
        }
    }

    class CreakingMoveControl extends class_1335 {
        public CreakingMoveControl(Creaking mob) {
            super(mob);
        }

        @Override
        public void method_6240() {
            if (Creaking.this.canMove()) {
                super.method_6240();
            }
        }
    }

    class CreakingPathNavigation extends class_1409 {
        CreakingPathNavigation(Creaking mob, class_1937 level) {
            super(mob, level);
        }

        @Override
        public void method_6360() {
            if (Creaking.this.canMove()) {
                super.method_6360();
            }
        }

        @Override
        protected class_13 method_6336(int maxVisitedNodes) {
            this.field_6678 = new HomeNodeEvaluator();
            this.field_6678.method_15(true);
            return new class_13(this.field_6678, maxVisitedNodes);
        }
    }

    class HomeNodeEvaluator extends class_14 {
        @Override
        public class_7 method_17(class_9316 context, int x, int y, int z) {
            class_2338 homePos = Creaking.this.getHomePos();
            if (homePos == null) {
                return super.method_17(context, x, y, z);
            } else {
                double homeDistance = homePos.method_10262(new class_2382(x, y, z));
                return homeDistance > 1024.0 && homeDistance >= homePos.method_10262(context.method_57624()) ? class_7.field_22 : super.method_17(context, x, y, z);
            }
        }
    }
}