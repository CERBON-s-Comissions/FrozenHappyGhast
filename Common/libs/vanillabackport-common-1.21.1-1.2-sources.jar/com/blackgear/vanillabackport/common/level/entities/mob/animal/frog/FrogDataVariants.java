package com.blackgear.vanillabackport.common.level.entities.mob.animal.frog;

import com.blackgear.platform.core.BuiltInCoreRegistry;
import com.blackgear.platform.core.api.RegistryKey;
import com.blackgear.vanillabackport.common.api.modules.mob_variant.ClientAsset;
import com.blackgear.vanillabackport.common.api.modules.mob_variant.spawn.SpawnPrioritySelectors;
import com.blackgear.vanillabackport.common.api.modules.mob_variant.spawn.check.raw.RawBiomeCheck;
import com.blackgear.vanillabackport.core.VanillaBackport;
import net.minecraft.class_1959;
import net.minecraft.class_2960;
import net.minecraft.class_6862;

public class FrogDataVariants {
    public static final BuiltInCoreRegistry<FrogDataVariant> REGISTRIES = BuiltInCoreRegistry.create(class_2960.method_60656("frog_variants"), VanillaBackport.NAMESPACE);

//    public static final RegistryKey<FrogDataVariant> TEST = register("test", BiomeTags.IS_FOREST);

    private static RegistryKey<FrogDataVariant> register(String key, class_6862<class_1959> biome) {
        return register(key, SpawnPrioritySelectors.single(new RawBiomeCheck(biome), 1));
    }

    private static RegistryKey<FrogDataVariant> register(String key, SpawnPrioritySelectors selectors) {
        class_2960 texture = class_2960.method_60656("entity/frog/" + key + "_frog");
        return REGISTRIES.registerKey(key, new FrogDataVariant(new ClientAsset(texture), selectors));
    }
}