package com.blackgear.vanillabackport.common.level.items;

import net.minecraft.class_1792;

/**
 * added for retro-compatibility with Happy Airships, highly recommended for the dev to migrate!
 */
@Deprecated(forRemoval = true)
public class HarnessItem extends class_1792 {
    public HarnessItem(class_1793 properties) {
        super(properties);
    }
}