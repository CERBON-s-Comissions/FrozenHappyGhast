package com.blackgear.vanillabackport.common.level.blocks;

import com.google.common.collect.ImmutableBiMap;
import com.google.common.collect.ImmutableList;
import org.apache.commons.lang3.function.TriFunction;

import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.class_2248;
import net.minecraft.class_4970;
import net.minecraft.class_5955;
import net.minecraft.class_5955.class_5811;

public record WeatheringCopperBlocks(
    Supplier<class_2248> unaffected,
    Supplier<class_2248> exposed,
    Supplier<class_2248> weathered,
    Supplier<class_2248> oxidized,
    Supplier<class_2248> waxed,
    Supplier<class_2248> waxedExposed,
    Supplier<class_2248> waxedWeathered,
    Supplier<class_2248> waxedOxidized
) {
    public static <WaxedBlock extends class_2248, WeatheringBlock extends class_2248 & class_5955> WeatheringCopperBlocks create(
        String id,
        TriFunction<String, Function<class_4970.class_2251, class_2248>, class_4970.class_2251, Supplier<class_2248>> register,
        Function<class_4970.class_2251, WaxedBlock> waxedFactory,
        BiFunction<class_5811, class_4970.class_2251, WeatheringBlock> weatheringFactory,
        Function<class_5811, class_4970.class_2251> properties
    ) {
        return new WeatheringCopperBlocks(
            register.apply(id, p -> weatheringFactory.apply(class_5811.field_28704, p), properties.apply(class_5811.field_28704)),
            register.apply("exposed_" + id, p -> weatheringFactory.apply(class_5811.field_28705, p), properties.apply(class_5811.field_28705)),
            register.apply("weathered_" + id, p -> weatheringFactory.apply(class_5811.field_28706, p), properties.apply(class_5811.field_28706)),
            register.apply("oxidized_" + id, p -> weatheringFactory.apply(class_5811.field_28707, p), properties.apply(class_5811.field_28707)),
            register.apply("waxed_" + id, waxedFactory::apply, properties.apply(class_5811.field_28704)),
            register.apply("waxed_exposed_" + id, waxedFactory::apply, properties.apply(class_5811.field_28705)),
            register.apply("waxed_weathered_" + id, waxedFactory::apply, properties.apply(class_5811.field_28706)),
            register.apply("waxed_oxidized_" + id, waxedFactory::apply, properties.apply(class_5811.field_28707))
        );
    }

    public ImmutableBiMap<Supplier<class_2248>, Supplier<class_2248>> weatheringMapping() {
        return ImmutableBiMap.of(this.unaffected, this.exposed, this.exposed, this.weathered, this.weathered, this.oxidized);
    }

    public ImmutableBiMap<Supplier<class_2248>, Supplier<class_2248>> waxedMapping() {
        return ImmutableBiMap.of(this.unaffected, this.waxed, this.exposed, this.waxedExposed, this.weathered, this.waxedWeathered, this.oxidized, this.waxedOxidized);
    }

    public ImmutableList<Supplier<class_2248>> asList() {
        return ImmutableList.of(this.unaffected, this.exposed, this.weathered, this.oxidized, this.waxed, this.waxedExposed, this.waxedWeathered, this.waxedOxidized);
    }

    public void forEach(Consumer<Supplier<class_2248>> consumer) {
        consumer.accept(this.unaffected);
        consumer.accept(this.exposed);
        consumer.accept(this.weathered);
        consumer.accept(this.oxidized);
        consumer.accept(this.waxed);
        consumer.accept(this.waxedExposed);
        consumer.accept(this.waxedWeathered);
        consumer.accept(this.waxedOxidized);
    }
}