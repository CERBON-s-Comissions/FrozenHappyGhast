package com.blackgear.vanillabackport.common.level.items;

import com.blackgear.vanillabackport.common.level.entities.boat.CustomBoat;
import com.blackgear.vanillabackport.common.level.entities.boat.CustomBoatBehavior;
import com.blackgear.vanillabackport.common.level.entities.boat.CustomChestBoat;
import java.util.List;
import java.util.function.Predicate;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1297;
import net.minecraft.class_1301;
import net.minecraft.class_1657;
import net.minecraft.class_1690;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3468;
import net.minecraft.class_3959;
import net.minecraft.class_5712;

public class CustomBoatItem extends class_1792 {
    private static final Predicate<class_1297> ENTITY_PREDICATE = class_1301.field_6155.and(class_1297::method_5863);
    private final boolean hasChest;
    private final class_2960 type;

    public CustomBoatItem(class_2960 type, boolean hasChest, class_1793 properties) {
        super(properties);
        this.type = type;
        this.hasChest = hasChest;
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 heldStack = player.method_5998(hand);
        class_239 hitResult = method_7872(level, player, class_3959.class_242.field_1347);
        if (hitResult.method_17783() == class_239.class_240.field_1333) {
            return class_1271.method_22430(heldStack);
        } else {
            class_243 viewVector = player.method_5828(1.0F);
            List<class_1297> list = level.method_8333(player, player.method_5829().method_18804(viewVector.method_1021(5.0)).method_1014(1.0), ENTITY_PREDICATE);
            if (!list.isEmpty()) {
                class_243 eyePosition = player.method_33571();
                for (class_1297 entity : list) {
                    class_238 aabb = entity.method_5829().method_1014(entity.method_5871());
                    if (aabb.method_1006(eyePosition)) {
                        return class_1271.method_22430(heldStack);
                    }
                }
            }
            if (hitResult.method_17783() == class_239.class_240.field_1332) {
                class_1690 boat = this.getBoat(level, hitResult);
                boat.method_36456(player.method_36454());
                if (!level.method_8587(boat, boat.method_5829())) {
                    return class_1271.method_22431(heldStack);
                } else {
                    if (!level.method_8608()) {
                        level.method_8649(boat);
                        level.method_33596(player, class_5712.field_28738, class_2338.method_49638(hitResult.method_17784()));
                        if (!player.method_31549().field_7477) {
                            heldStack.method_7934(1);
                        }
                    }
                    player.method_7259(class_3468.field_15372.method_14956(this));
                    return class_1271.method_29237(heldStack, level.method_8608());
                }
            } else {
                return class_1271.method_22430(heldStack);
            }
        }
    }

    private class_1690 getBoat(class_1937 level, class_239 hitResult) {
        return this.hasChest
            ? new CustomChestBoat(level, hitResult.method_17784().field_1352, hitResult.method_17784().field_1351, hitResult.method_17784().field_1350, this.type)
            : new CustomBoat(level, hitResult.method_17784().field_1352, hitResult.method_17784().field_1351, hitResult.method_17784().field_1350, this.type);
    }
}