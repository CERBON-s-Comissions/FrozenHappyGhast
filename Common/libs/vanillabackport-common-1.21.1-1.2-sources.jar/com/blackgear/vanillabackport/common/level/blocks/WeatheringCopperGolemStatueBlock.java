package com.blackgear.vanillabackport.common.level.blocks;

import com.blackgear.vanillabackport.common.level.block_entities.CopperGolemStatueBlockEntity;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.golem.copper_golem.CopperGolem;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3489;
import net.minecraft.class_3965;
import net.minecraft.class_5819;
import net.minecraft.class_5955;
import net.minecraft.class_9062;

public class WeatheringCopperGolemStatueBlock extends CopperGolemStatueBlock implements class_5955 {
    public WeatheringCopperGolemStatueBlock(class_5811 weatheringState, class_2251 properties) {
        super(weatheringState, properties);
    }
    
    @Override
    protected boolean method_9542(class_2680 state) {
        return class_5955.method_34737(state.method_26204()).isPresent();
    }
    
    @Override
    protected void method_9514(class_2680 state, class_3218 level, class_2338 pos, class_5819 random) {
        this.method_54764(state, level, pos, random);
    }
    
    @Override
    public class_5811 method_33622() {
        return this.getWeatheringState();
    }
    
    @Override
    protected class_9062 method_55765(
        class_1799 stack,
        class_2680 state,
        class_1937 level,
        class_2338 pos,
        class_1657 player,
        class_1268 hand,
        class_3965 hitResult
    ) {
        if (level.method_8321(pos) instanceof CopperGolemStatueBlockEntity statue) {
            if (!stack.method_31573(class_3489.field_42612)) {
                if (stack.method_31574(class_1802.field_20414)) {
                    return class_9062.field_47731;
                }
                
                this.updatePose(level, state, pos, player);
                return class_9062.field_47728;
            }
            
            if (this.method_33622() == class_5811.field_28704) {
                CopperGolem golem = statue.removeStatue(state);
                stack.method_7970(1, player, class_1309.method_56079(hand));
                if (golem != null) {
                    level.method_8649(golem);
                    level.method_8650(pos, false);
                    return class_9062.field_47728;
                }
            }
        }

        return class_9062.field_47731;
    }
}