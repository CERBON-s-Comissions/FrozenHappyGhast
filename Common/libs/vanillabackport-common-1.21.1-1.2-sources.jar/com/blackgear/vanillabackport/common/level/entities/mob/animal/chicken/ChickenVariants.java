package com.blackgear.vanillabackport.common.level.entities.mob.animal.chicken;

import com.blackgear.platform.core.BuiltInCoreRegistry;
import com.blackgear.platform.core.api.RegistryKey;
import com.blackgear.vanillabackport.common.api.modules.mob_variant.ModelAndTexture;
import com.blackgear.vanillabackport.common.api.modules.mob_variant.spawn.SpawnPrioritySelectors;
import com.blackgear.vanillabackport.common.api.modules.mob_variant.spawn.check.raw.RawBiomeCheck;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.blackgear.vanillabackport.core.data.tags.ModBiomeTags;
import net.minecraft.class_1959;
import net.minecraft.class_2960;
import net.minecraft.class_6862;

public class ChickenVariants {
    public static final BuiltInCoreRegistry<ChickenVariant> REGISTRIES = BuiltInCoreRegistry.create(class_2960.method_60656("chicken_variants"), VanillaBackport.NAMESPACE);

    public static final RegistryKey<ChickenVariant> TEMPERATE = register("temperate",
        ChickenVariant.ModelType.NORMAL,
        class_2960.method_60656("entity/chicken"),
        SpawnPrioritySelectors.fallback(0));
    public static final RegistryKey<ChickenVariant> WARM = register("warm",
        ChickenVariant.ModelType.NORMAL,
        "warm_chicken",
        ModBiomeTags.SPAWNS_WARM_VARIANT_FARM_ANIMALS);
    public static final RegistryKey<ChickenVariant> COLD = register("cold",
        ChickenVariant.ModelType.COLD,
        "cold_chicken",
        ModBiomeTags.SPAWNS_COLD_VARIANT_FARM_ANIMALS);

    private static RegistryKey<ChickenVariant> register(String key, ChickenVariant.ModelType type, String assetId, class_6862<class_1959> biome) {
        class_2960 path = class_2960.method_60656("entity/chicken/" + assetId);
        return register(key, type, path, SpawnPrioritySelectors.single(new RawBiomeCheck(biome), 1));
    }

    private static RegistryKey<ChickenVariant> register(String key, ChickenVariant.ModelType type, class_2960 assetId, SpawnPrioritySelectors selectors) {
        return REGISTRIES.registerKey(key, new ChickenVariant(new ModelAndTexture<>(type, assetId), selectors));
    }
}