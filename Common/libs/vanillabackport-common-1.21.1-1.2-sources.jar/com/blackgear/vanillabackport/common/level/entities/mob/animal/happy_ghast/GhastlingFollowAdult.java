package com.blackgear.vanillabackport.common.level.entities.mob.animal.happy_ghast;

import java.util.function.Function;
import net.minecraft.class_1309;
import net.minecraft.class_4102;
import net.minecraft.class_4140;
import net.minecraft.class_4142;
import net.minecraft.class_6019;
import net.minecraft.class_7894;
import net.minecraft.class_7898;

public class GhastlingFollowAdult {
    public static class_7894<class_1309> create(class_6019 followRange, float speed) {
        return create(followRange, entity -> speed, class_4140.field_25359);
    }

    public static class_7894<class_1309> create(
        class_6019 followRange,
        Function<class_1309, Float> speedFactory,
        class_4140<? extends class_1309> memory
    ) {
        return class_7898.method_47224(
            instance -> instance.group(
                    instance.method_47244(memory),
                    instance.method_47235(class_4140.field_18446),
                    instance.method_47245(class_4140.field_18445)
                )
                .apply(instance, (followTarget, lookTarget, walkTarget) -> (level, entity, gameTme) -> {
                    if (!entity.method_6109()) {
                        return false;
                    } else {
                        class_1309 leader = instance.method_47243(followTarget);
                        if (entity.method_24516(leader, followRange.method_35011() + 1) && !entity.method_24516(leader, followRange.method_35009())) {
                            class_4142 target = new class_4142(new class_4102(leader, false), speedFactory.apply(entity), followRange.method_35009() - 1);
                            lookTarget.method_47249(new class_4102(leader, true));
                            walkTarget.method_47249(target);
                            return true;
                        } else {
                            return false;
                        }
                    }
                })
        );
    }
}
