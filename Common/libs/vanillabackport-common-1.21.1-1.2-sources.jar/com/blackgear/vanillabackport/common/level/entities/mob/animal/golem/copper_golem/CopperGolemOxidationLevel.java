package com.blackgear.vanillabackport.common.level.entities.mob.animal.golem.copper_golem;

import net.minecraft.class_2960;
import net.minecraft.class_3414;

public record CopperGolemOxidationLevel(
	class_3414 spinHeadSound,
	class_3414 hurtSound,
	class_3414 deathSound,
	class_3414 stepSound,
	class_2960 texture,
	class_2960 eyeTexture
) {}