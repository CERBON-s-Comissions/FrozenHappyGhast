package com.blackgear.vanillabackport.common.level.items.enchantment.effects;

import com.blackgear.vanillabackport.core.util.AdditionalCodecs;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3532;
import net.minecraft.class_5819;
import net.minecraft.class_5863;
import net.minecraft.class_6880;
import net.minecraft.class_9699;
import net.minecraft.class_9721;

public record PlaySoundEffect(List<class_6880<class_3414>> soundEvent, class_5863 volume, class_5863 pitch) implements class_9721 {
	public static final MapCodec<PlaySoundEffect> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
		AdditionalCodecs.compactListCodec(class_3414.field_41699, class_3414.field_41699.sizeLimitedListOf(255)).fieldOf("sound").forGetter(PlaySoundEffect::soundEvent),
		class_5863.method_33916(1.0E-5F, 10.0F).fieldOf("volume").forGetter(PlaySoundEffect::volume),
		class_5863.method_33916(1.0E-5F, 2.0F).fieldOf("pitch").forGetter(PlaySoundEffect::pitch)
	).apply(instance, PlaySoundEffect::new));
	
	@Override
	public void method_60220(class_3218 level, int enchantmentLevel, class_9699 item, class_1297 entity, class_243 origin) {
		if (!entity.method_5701()) {
			class_5819 randomSource = entity.method_59922();
			int index = class_3532.method_15340(enchantmentLevel - 1, 0, this.soundEvent.size() - 1);
			level.method_60511(
				null,
				origin.method_10216(),
				origin.method_10214(),
				origin.method_10215(),
				this.soundEvent.get(index),
				entity.method_5634(),
				this.volume.method_33920(randomSource),
				this.pitch.method_33920(randomSource)
			);
		}
	}
	
	@Override
	public MapCodec<PlaySoundEffect> method_60219() {
		return CODEC;
	}
}