package com.blackgear.vanillabackport.common.value_providers;

import com.blackgear.vanillabackport.common.registries.ModValueProviders;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_3532;
import net.minecraft.class_5819;
import net.minecraft.class_6017;
import net.minecraft.class_6018;

public class TrapezoidInt extends class_6017 {
    public static final MapCodec<TrapezoidInt> CODEC = RecordCodecBuilder.<TrapezoidInt>mapCodec(instance -> instance.group(
            Codec.INT.fieldOf("min").forGetter(p -> p.minInclusive),
            Codec.INT.fieldOf("max").forGetter(provider -> provider.maxInclusive),
            Codec.INT.fieldOf("plateau").forGetter(p -> p.plateau)
        ).apply(instance, TrapezoidInt::new)
        ).validate(provider -> {
            if (provider.maxInclusive < provider.minInclusive) {
                return DataResult.error(() -> "Max must be larger than min: [" + provider.minInclusive + ", " + provider.maxInclusive + "]");
            } else {
                return provider.plateau > provider.maxInclusive - provider.minInclusive
                    ? DataResult.error(() -> "Plateau can at most be the full span: [" + provider.minInclusive + ", " + provider.maxInclusive + "]")
                    : DataResult.success(provider);
            }
        });

    private final int minInclusive;
    private final int maxInclusive;
    private final int plateau;

    private TrapezoidInt(int minInclusive, int maxInclusive, int plateau) {
        this.minInclusive = minInclusive;
        this.maxInclusive = maxInclusive;
        this.plateau = plateau;
    }

    public static TrapezoidInt of(int min, int max, int plateau) {
        return new TrapezoidInt(min, max, plateau);
    }

    public static TrapezoidInt triangle(int range) {
        return of(-range, range, 0);
    }

    @Override
    public int method_35008(class_5819 random) {
        if (this.plateau == 0 && this.maxInclusive == -this.minInclusive) {
            return random.method_43048(this.maxInclusive + 1) - random.method_43048(this.maxInclusive + 1);
        } else {
            int range = this.maxInclusive - this.minInclusive;
            if (this.plateau == range) {
                return class_3532.method_32751(random, this.minInclusive, this.maxInclusive);
            } else {
                int plateauStart = (range - this.plateau) / 2;
                int plateauEnd = range - plateauStart;
                return this.minInclusive + class_3532.method_32751(random, 0, plateauEnd) + class_3532.method_32751(random, 0, plateauStart);
            }
        }
    }

    @Override
    public int method_35009() {
        return this.minInclusive;
    }

    @Override
    public int method_35011() {
        return this.maxInclusive;
    }

    @Override
    public class_6018<?> method_35012() {
        return ModValueProviders.TRAPEZOID_INT.get();
    }

    @Override
    public String toString() {
        return "trapezoid(" + this.plateau + ") in [" + this.minInclusive + "-" + this.maxInclusive + "]";
    }
}
