package com.blackgear.vanillabackport.common.commands.arguments;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.Arrays;
import java.util.Collection;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2172;
import net.minecraft.class_2561;

public class ColorArgument implements ArgumentType<class_124> {
    private static final Collection<String> EXAMPLES = Arrays.asList("red", "green");
    public static final DynamicCommandExceptionType ERROR_INVALID_VALUE = new DynamicCommandExceptionType(value -> class_2561.method_54159("argument.color.invalid", value));

    public static ColorArgument color() {
        return new ColorArgument();
    }
    
    public static class_124 getTeamColor(CommandContext<class_2168> context, String name) {
        return context.getArgument(name, class_124.class);
    }
    
    @Override
    public class_124 parse(StringReader reader) throws CommandSyntaxException {
        String id = reader.readUnquotedString();
        class_124 result = class_124.method_533(id);
        if (result == null) {
            throw ERROR_INVALID_VALUE.createWithContext(reader, id);
        } else {
            return result;
        }
    }
    
    @Override
    public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> context, SuggestionsBuilder builder) {
        return class_2172.method_9265(class_124.method_540(true, false), builder);
    }
    
    @Override
    public Collection<String> getExamples() {
        return EXAMPLES;
    }
}