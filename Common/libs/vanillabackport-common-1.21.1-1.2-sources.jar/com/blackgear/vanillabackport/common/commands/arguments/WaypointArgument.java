package com.blackgear.vanillabackport.common.commands.arguments;

import com.blackgear.vanillabackport.common.api.modules.waypoints.WaypointTransmitter;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import net.minecraft.class_2168;
import net.minecraft.class_2300;
import net.minecraft.class_2561;

public class WaypointArgument {
    public static final SimpleCommandExceptionType ERROR_NOT_A_WAYPOINT = new SimpleCommandExceptionType(class_2561.method_43471("argument.waypoint.invalid"));
    
    public static WaypointTransmitter getWaypoint(CommandContext<class_2168> context, String name) throws CommandSyntaxException {
        if (context.getArgument(name, class_2300.class).method_9809(context.getSource()) instanceof WaypointTransmitter waypoint) {
            return waypoint;
        } else {
            throw ERROR_NOT_A_WAYPOINT.create();
        }
    }
}