package com.blackgear.vanillabackport.common.commands.arguments;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.Arrays;
import java.util.Collection;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_2168;
import net.minecraft.class_2172;
import net.minecraft.class_2561;
import net.minecraft.class_5253.class_5254;

public class HexColorArgument implements ArgumentType<Integer> {
	private static final Collection<String> EXAMPLES = Arrays.asList("F00", "FF0000");
	public static final DynamicCommandExceptionType ERROR_INVALID_HEX = new DynamicCommandExceptionType(value -> class_2561.method_54159("argument.hexcolor.invalid", value));

	public static HexColorArgument hexColor() {
		return new HexColorArgument();
	}

	public static Integer getHexColor(CommandContext<class_2168> context, String name) {
		return context.getArgument(name, Integer.class);
	}

	public Integer parse(StringReader reader) throws CommandSyntaxException {
		String colorString = reader.readUnquotedString();

		return switch (colorString.length()) {
			case 3 -> class_5254.method_57173(
				duplicateDigit(Integer.parseInt(colorString, 0, 1, 16)),
				duplicateDigit(Integer.parseInt(colorString, 1, 2, 16)),
				duplicateDigit(Integer.parseInt(colorString, 2, 3, 16))
			);
			case 6 -> class_5254.method_57173(
				Integer.parseInt(colorString, 0, 2, 16),
				Integer.parseInt(colorString, 2, 4, 16),
				Integer.parseInt(colorString, 4, 6, 16)
			);
			default -> throw ERROR_INVALID_HEX.createWithContext(reader, colorString);
		};
	}

	private static int duplicateDigit(int digit) {
		return digit * 17;
	}

	@Override
	public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> contextBuilder, SuggestionsBuilder builder) {
		return class_2172.method_9265(EXAMPLES, builder);
	}

	@Override
	public Collection<String> getExamples() {
		return EXAMPLES;
	}
}
