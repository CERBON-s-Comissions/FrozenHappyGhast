package com.blackgear.vanillabackport.common.commands;

import com.blackgear.vanillabackport.common.api.modules.waypoints.*;
import com.blackgear.vanillabackport.common.api.modules.waypoints.Waypoint.Icon;
import com.blackgear.vanillabackport.common.commands.arguments.HexColorArgument;
import com.blackgear.vanillabackport.common.commands.arguments.ColorArgument;
import com.blackgear.vanillabackport.common.commands.arguments.WaypointArgument;
import com.mojang.brigadier.CommandDispatcher;
import java.util.HexFormat;
import java.util.Optional;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Function;
import net.minecraft.class_124;
import net.minecraft.class_1309;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2232;
import net.minecraft.class_2338;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2564;
import net.minecraft.class_2568;
import net.minecraft.class_3218;
import net.minecraft.class_5253.class_5254;
import net.minecraft.class_5321;
import net.minecraft.class_7157;

public class WaypointCommand {
    public static void register(CommandDispatcher<class_2168> dispatcher, class_7157 context) {
        dispatcher.register(
            class_2170.method_9247("waypoint")
                .requires(src -> src.method_9259(class_2170.field_31839))
                .then(class_2170.method_9247("list").executes(c -> listWaypoints(c.getSource())))
                .then(
                    class_2170.method_9247("modify")
                        .then(
                            class_2170.method_9244("waypoint", class_2186.method_9309())
                                .then(
                                    class_2170.method_9247("color")
                                        .then(
                                            class_2170.method_9244("color", ColorArgument.color())
                                                .executes(c -> setWaypointColor(c.getSource(), WaypointArgument.getWaypoint(c, "waypoint"), ColorArgument.getTeamColor(c, "color")))
                                        )
                                        .then(
                                            class_2170.method_9247("hex")
                                                .then(
                                                    class_2170.method_9244("color", HexColorArgument.hexColor())
                                                        .executes(c -> setWaypointColor(c.getSource(), WaypointArgument.getWaypoint(c, "waypoint"), HexColorArgument.getHexColor(c, "color")))
                                                )
                                        )
                                        .then(
                                            class_2170.method_9247("reset").executes(c -> resetWaypointColor(c.getSource(), WaypointArgument.getWaypoint(c, "waypoint")))
                                        )
                                )
                                .then(
                                    class_2170.method_9247("style")
                                        .then(
                                            class_2170.method_9247("reset").executes(c -> setWaypointStyle(c.getSource(), WaypointArgument.getWaypoint(c, "waypoint"), WaypointStyleAssets.DEFAULT))
                                        )
                                        .then(
                                            class_2170.method_9247("set")
                                                .then(
                                                    class_2170.method_9244("style", class_2232.method_9441())
                                                        .executes(
                                                            c -> setWaypointStyle(
                                                                c.getSource(),
                                                                WaypointArgument.getWaypoint(c, "waypoint"),
                                                                class_5321.method_29179(WaypointStyleAssets.ROOT_ID, class_2232.method_9443(c, "style"))
                                                            )
                                                        )
                                                )
                                        )
                                )
                        )
                )
        );
    }
    
    private static int setWaypointStyle(class_2168 source, WaypointTransmitter waypoint, class_5321<WaypointStyleAsset> style) {
        mutateIcon(source, waypoint, icon -> icon.style = style);
        source.method_9226(() -> class_2561.method_43471("commands.waypoint.modify.style"), false);
        return 0;
    }
    
    private static int setWaypointColor(class_2168 source, WaypointTransmitter waypoint, class_124 color) {
        mutateIcon(source, waypoint, icon -> icon.color = Optional.ofNullable(color.method_532()));
        source.method_9226(() -> class_2561.method_43469("commands.waypoint.modify.color", class_2561.method_43470(color.method_537()).method_27692(color)), false);
        return 0;
    }
    
    private static int setWaypointColor(class_2168 source, WaypointTransmitter waypoint, Integer color) {
        mutateIcon(source, waypoint, icon -> icon.color = Optional.of(color));
        source.method_9226(() -> class_2561.method_43469("commands.waypoint.modify.color", class_2561.method_43470(HexFormat.of().withUpperCase().toHexDigits(class_5254.method_58144(0, color), 6)).method_54663(color)), false);
        return 0;
    }
    
    private static int resetWaypointColor(class_2168 source, WaypointTransmitter waypoint) {
        mutateIcon(source, waypoint, icon -> icon.color = Optional.empty());
        source.method_9226(() -> class_2561.method_43471("commands.waypoint.modify.color.reset"), false);
        return 0;
    }
    
    private static int listWaypoints(class_2168 source) {
        class_3218 level = source.method_9225();
        Set<WaypointTransmitter> waypoints = ServerWaypointManager.get(level).transmitters();
        String dimension = level.method_27983().method_29177().toString();
        if (waypoints.isEmpty()) {
            source.method_9226(() -> class_2561.method_43469("commands.waypoint.list.empty", dimension), false);
            return 0;
        } else {
            class_2561 waypointNames = class_2564.method_10884(
                waypoints.stream()
                    .map(transmitter -> {
                        if (transmitter instanceof class_1309 entity) {
                            class_2338 pos = entity.method_24515();
                            return entity.method_55423().method_27661()
                                .method_27694(
                                    s -> s.method_10958(new class_2558(class_2558.class_2559.field_11745, "/execute in " + dimension + " run tp @s " + pos.method_10263() + " " + pos.method_10264() + " " + pos.method_10260()))
                                        .method_10949(new class_2568(class_2568.class_5247.field_24342, class_2561.method_43471("chat.coordinates.tooltip")))
                                        .method_36139(transmitter.waypointIcon().color.orElse(-1)));
                        } else {
                            return class_2561.method_43470(transmitter.toString());
                        }
                    })
                    .toList(),
                Function.identity()
            );
            source.method_9226(() -> class_2561.method_43469("commands.waypoint.list.success", waypoints.size(), dimension, waypointNames), false);
            return waypoints.size();
        }
    }
    
    private static void mutateIcon(class_2168 source, WaypointTransmitter waypoint, Consumer<Icon> consumer) {
        class_3218 level = source.method_9225();
        ServerWaypointManager.get(level).untrackWaypoint(waypoint);
        consumer.accept(waypoint.waypointIcon());
        ServerWaypointManager.get(level).trackWaypoint(waypoint);
    }
}