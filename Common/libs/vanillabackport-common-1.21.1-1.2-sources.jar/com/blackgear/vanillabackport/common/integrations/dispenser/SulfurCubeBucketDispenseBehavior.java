package com.blackgear.vanillabackport.common.integrations.dispenser;

import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2315;
import net.minecraft.class_2338;
import net.minecraft.class_2342;
import net.minecraft.class_2347;
import net.minecraft.class_5633;

public class SulfurCubeBucketDispenseBehavior extends class_2347 {
    private final class_2347 defaultDispenseItemBehavior = new class_2347();
    
    @Override
    public class_1799 method_10135(class_2342 blockSource, class_1799 item) {
        class_5633 dispensibleContainerItem = (class_5633) item.method_7909();
        class_2338 blockPos = blockSource.comp_1968().method_10093(blockSource.comp_1969().method_11654(class_2315.field_10918));
        class_1937 level = blockSource.comp_1967();
        if (dispensibleContainerItem.method_7731(null, level, blockPos, null)) {
            dispensibleContainerItem.method_7728(null, level, item, blockPos);
            return this.method_60577(blockSource, item, new class_1799(class_1802.field_8550));
        } else {
            return this.defaultDispenseItemBehavior.dispense(blockSource, item);
        }
    }
}