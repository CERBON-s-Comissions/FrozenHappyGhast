package com.blackgear.vanillabackport.common.integrations.compat.everycompat;

import com.blackgear.vanillabackport.client.registries.ModSoundTypes;
import com.blackgear.vanillabackport.common.level.blocks.ShelfBlock;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlockEntities;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.blackgear.vanillabackport.core.data.tags.ModBlockTags;
import com.blackgear.vanillabackport.core.data.tags.ModItemTags;
import net.mehvahdjukaar.every_compat.api.PaletteStrategies;
import net.mehvahdjukaar.every_compat.api.SimpleEntrySet;
import net.mehvahdjukaar.every_compat.modules.EveryCompatModule;
import net.mehvahdjukaar.moonlight.api.set.wood.VanillaWoodChildKeys;
import net.mehvahdjukaar.moonlight.api.set.wood.VanillaWoodTypes;
import net.mehvahdjukaar.moonlight.api.set.wood.WoodType;
import net.minecraft.class_1761;
import net.minecraft.class_2248;
import net.minecraft.class_2766;
import net.minecraft.class_2960;
import net.minecraft.class_3481;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class ShelfModule extends EveryCompatModule {
    public final SimpleEntrySet<WoodType, class_2248> shelf;
    
    public ShelfModule(String modId) {
        super(modId, VanillaBackport.MOD_ID);
        class_5321<class_1761> tab = class_7706.field_40197;
        
        this.shelf = SimpleEntrySet.builder(WoodType.class, "shelf",
                () -> class_7923.field_41175.method_10223(class_2960.method_60656("oak_shelf")),
                () -> VanillaWoodTypes.OAK,
                w -> new ShelfBlock(class_4970.class_2251.method_9637()
                    .method_31710(w.planks.method_26403())
                    .method_51368(class_2766.field_12651)
                    .method_9626(ModSoundTypes.WOODEN_SHELF)
                    .method_50013()
                    .method_9629(2.0F, 3.0F)
                ))
            .requiresChildren(VanillaWoodChildKeys.STRIPPED_LOG)
            .addTexture(class_2960.method_60656("block/oak_shelf"), PaletteStrategies.PLANKS_REMOVE_2_DARKEST)
            .includeModelsBlock(
                class_2960.method_60656("block/oak_shelf"),
                class_2960.method_60656("block/oak_shelf_center"),
                class_2960.method_60656("block/oak_shelf_inventory"),
                class_2960.method_60656("block/oak_shelf_left"),
                class_2960.method_60656("block/oak_shelf_right"),
                class_2960.method_60656("block/oak_shelf_unconnected"),
                class_2960.method_60656("block/oak_shelf_unpowered")
            )
            .addModelTransform(t -> {
                t.addModifier((s, id, woodType) ->
                    s.replace(
                            "\"minecraft:block/oak_shelf\"",
                            "\"" + id.method_45138("block/") + "\""
                        )
                        .replaceAll("\"minecraft:block/oak_shelf_([a-z]+)\"", "\"" + id.method_45138("block/") + "_$1\"")
                );
            })
            .addTile(ModBlockEntities.SHELF)
            .addTag(class_3481.field_33713, class_7924.field_41254)
            .addTag(ModBlockTags.WOODEN_SHELVES, class_7924.field_41254)
            .addTag(ModItemTags.WOODEN_SHELVES, class_7924.field_41197)
            .setTabKey(tab)
            .addRecipe(class_2960.method_60656("oak_shelf"))
            .build();
        this.addEntry(this.shelf);
    }
}
