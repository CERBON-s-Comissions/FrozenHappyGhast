package com.blackgear.vanillabackport.common.integrations.dispenser;

import com.blackgear.vanillabackport.common.level.entities.boat.CustomBoat;
import com.blackgear.vanillabackport.common.level.entities.boat.CustomChestBoat;
import net.minecraft.class_1299;
import net.minecraft.class_1690;
import net.minecraft.class_1799;
import net.minecraft.class_2315;
import net.minecraft.class_2338;
import net.minecraft.class_2342;
import net.minecraft.class_2347;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3486;

public class BoatDispenseBehavior extends class_2347 {
    private final class_2347 defaultDispenseItemBehavior;
    private final boolean isChestBoat;
    private final class_2960 type;

    public BoatDispenseBehavior(class_2960 type) {
        this(type, false);
    }

    public BoatDispenseBehavior(class_2960 type, boolean isChestBoat) {
        this.defaultDispenseItemBehavior = new class_2347();
        this.isChestBoat = isChestBoat;
        this.type = type;
    }

    public class_1799 method_10135(class_2342 source, class_1799 stack) {
        class_2350 direction = source.comp_1969().method_11654(class_2315.field_10918);
        class_3218 level = source.comp_1967();
        class_243 center = source.method_53906();
        double width = 0.5625 + (double) class_1299.field_6121.method_17685() / 2.0;
        double x = center.method_10216() + (double) direction.method_10148() * width;
        double y = center.method_10214() + (double) ((float) direction.method_10164() * 1.125F);
        double z = center.method_10215() + (double) direction.method_10165() * width;
        class_2338 blockpos = source.comp_1968().method_10093(direction);
        double offset = 0.0;
        if (level.method_8316(blockpos).method_15767(class_3486.field_15517)) {
            offset = 1.0;
        } else {
            if (!level.method_8320(blockpos).method_26215() || !level.method_8316(blockpos.method_10074()).method_15767(class_3486.field_15517)) {
                return this.defaultDispenseItemBehavior.dispense(source, stack);
            }
        }

        class_1690 boat = this.isChestBoat ? new CustomChestBoat(level, x, y, z, this.type) : new CustomBoat(level, x, y, z, this.type);
        boat.method_36456(direction.method_10144());
        boat.method_5814(x, y + offset, z);
        level.method_8649(boat);
        stack.method_7934(1);
        return stack;
    }

    protected void method_10136(class_2342 source) {
        source.comp_1967().method_20290(1000, source.comp_1968(), 0);
    }
}