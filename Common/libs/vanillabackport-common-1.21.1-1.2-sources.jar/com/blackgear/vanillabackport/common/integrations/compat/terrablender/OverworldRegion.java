package com.blackgear.vanillabackport.common.integrations.compat.terrablender;

import com.blackgear.vanillabackport.common.integrations.worldgen.BiomeGeneration;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.mojang.datafixers.util.Pair;
import terrablender.api.Region;
import terrablender.api.RegionType;
import terrablender.api.VanillaParameterOverlayBuilder;

import java.util.function.Consumer;
import net.minecraft.class_1959;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6544;

public class OverworldRegion extends Region {
    public OverworldRegion(class_2960 name, RegionType type, int weight) {
        super(name, type, weight);
    }

    @Override
    public void addBiomes(class_2378<class_1959> registry, Consumer<Pair<class_6544.class_4762, class_5321<class_1959>>> mapper) {
        VanillaParameterOverlayBuilder builder = new VanillaParameterOverlayBuilder();

        if (VanillaBackport.COMMON_CONFIG.hasPaleGarden.get())
            BiomeGeneration.PALE_GARDEN.forEach(pair -> builder.add(pair.getFirst(), pair.getSecond()));
        
        if (VanillaBackport.COMMON_CONFIG.hasSulfurCaves.get())
            builder.add(BiomeGeneration.SULFUR_CAVES.getFirst(), BiomeGeneration.SULFUR_CAVES.getSecond());
        
        if (VanillaBackport.COMMON_CONFIG.hasDappledForest.get())
            BiomeGeneration.DAPPLED_FOREST.forEach(pair -> builder.add(pair.getFirst(), pair.getSecond()));
        
        builder.build().forEach(mapper);
    }
}