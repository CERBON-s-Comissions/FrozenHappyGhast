package com.blackgear.vanillabackport.common.integrations;

import com.blackgear.vanillabackport.core.data.tags.ModBlockTags;
import net.minecraft.class_1267;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1588;
import net.minecraft.class_2338;
import net.minecraft.class_3730;
import net.minecraft.class_5425;
import net.minecraft.class_5819;
import net.minecraft.class_7689;

public class MobSpawns {
    static boolean checkCamelSpawnRules(class_1299<? extends class_7689> type, class_5425 level, class_3730 spawnType, class_2338 pos, class_5819 random) {
        return level.method_8320(pos.method_10074()).method_26164(ModBlockTags.CAMELS_SPAWNABLE_ON) && level.method_22335(pos, 0) > 8;
    }
    
    static boolean checkMonsterSpawnRules(class_1299<? extends class_1308> type, class_5425 level, class_3730 spawnType, class_2338 pos, class_5819 random) {
        return level.method_8407() != class_1267.field_5801 && (class_3730.method_54987(spawnType) || class_1588.method_20679(level, pos, random)) && class_1308.method_20636(type, level, spawnType, pos, random);
    }
    
    static boolean checkSurfaceMonstersSpawnRules(class_1299<? extends class_1308> type, class_5425 level, class_3730 spawnType, class_2338 pos, class_5819 random) {
        return checkMonsterSpawnRules(type, level, spawnType, pos, random) && (class_3730.method_54986(spawnType) || level.method_8311(pos));
    }
}