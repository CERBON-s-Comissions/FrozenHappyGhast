package com.blackgear.vanillabackport.common.integrations.worldgen;

import com.blackgear.platform.common.worldgen.placement.BiomePlacement;
import com.blackgear.platform.common.worldgen.placement.Placement;
import com.blackgear.platform.common.worldgen.placement.parameters.*;
import com.blackgear.vanillabackport.common.registries.worldgen.ModBiomes;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.mojang.datafixers.util.Pair;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_156;
import net.minecraft.class_1959;
import net.minecraft.class_5321;
import net.minecraft.class_6544;

public class BiomeGeneration {
    public static final List<Pair<class_6544.class_4762, class_5321<class_1959>>> PALE_GARDEN = class_156.method_656(() -> {
        List<Pair<class_6544.class_4762, class_5321<class_1959>>> parameters = new ArrayList<>();
        addBiome(parameters, ModBiomes.PALE_GARDEN, Placement.MID_SLICE_VARIANT, Temperature.NEUTRAL, Humidity.HUMID, Continentalness.FAR_INLAND.parameter(), Erosion.EROSION_1.parameter());
        addBiome(parameters, ModBiomes.PALE_GARDEN, Placement.MID_SLICE_VARIANT, Temperature.NEUTRAL, Humidity.HUMID, Continentalness.FAR_INLAND.parameter(), Erosion.EROSION_2.parameter());
        addBiome(parameters, ModBiomes.PALE_GARDEN, Placement.HIGH_SLICE_VARIANT, Temperature.NEUTRAL, Humidity.HUMID, Continentalness.span(Continentalness.MID_INLAND, Continentalness.FAR_INLAND), Erosion.EROSION_2.parameter());
        addBiome(parameters, ModBiomes.PALE_GARDEN, Placement.HIGH_SLICE_VARIANT, Temperature.NEUTRAL, Humidity.HUMID, Continentalness.FAR_INLAND.parameter(), Erosion.EROSION_3.parameter());
        addBiome(parameters, ModBiomes.PALE_GARDEN, Placement.PEAK_VARIANT, Temperature.NEUTRAL, Humidity.HUMID, Continentalness.span(Continentalness.MID_INLAND, Continentalness.FAR_INLAND), Erosion.EROSION_2.parameter());
        addBiome(parameters, ModBiomes.PALE_GARDEN, Placement.PEAK_VARIANT, Temperature.NEUTRAL, Humidity.HUMID, Continentalness.FAR_INLAND.parameter(), Erosion.EROSION_3.parameter());
        return List.copyOf(parameters);
    });
    
    public static final List<Pair<class_6544.class_4762, class_5321<class_1959>>> DAPPLED_FOREST = class_156.method_656(() -> {
        List<Pair<class_6544.class_4762, class_5321<class_1959>>> parameters = new ArrayList<>();
        addBiome(parameters, ModBiomes.DAPPLED_FOREST, Placement.MID_SLICE_VARIANT, Temperature.COOL, Humidity.ARID, Continentalness.span(Continentalness.NEAR_INLAND, Continentalness.FAR_INLAND), Erosion.span(Erosion.EROSION_2, Erosion.EROSION_4));
        addBiome(parameters, ModBiomes.DAPPLED_FOREST, Placement.HIGH_SLICE_VARIANT, Temperature.COOL, Humidity.ARID, Continentalness.span(Continentalness.COAST, Continentalness.FAR_INLAND), Erosion.span(Erosion.EROSION_2, Erosion.EROSION_4));
        return List.copyOf(parameters);
    });
    
    public static final Pair<class_6544.class_4762, class_5321<class_1959>> SULFUR_CAVES = Pair.of(
        class_6544.method_38118(
            Temperature.FULL_RANGE.parameter(),
            Humidity.FULL_RANGE.parameter(),
            Continentalness.span(Continentalness.COAST, Continentalness.INLAND),
            Erosion.span(Erosion.EROSION_5, Erosion.EROSION_6),
            Depth.UNDERGROUND.parameter(),
            class_6544.class_6546.method_38121(-1.1F, -0.85F),
            0.0F
        ),
        ModBiomes.SULFUR_CAVES
    );
    
    public static void bootstrap(BiomePlacement.Event event) {
        if (VanillaBackport.COMMON_CONFIG.hasPaleGarden.get())
            PALE_GARDEN.forEach(event::add);
        
        if (VanillaBackport.COMMON_CONFIG.hasSulfurCaves.get())
            event.add(SULFUR_CAVES);
        
        if (VanillaBackport.COMMON_CONFIG.hasDappledForest.get())
            DAPPLED_FOREST.forEach(event::add);
    }
    
    private static void addBiome(List<Pair<class_6544.class_4762, class_5321<class_1959>>> parameters, class_5321<class_1959> biome, Placement placement, Temperature temperature, Humidity humidity, class_6544.class_6546 continentalness, class_6544.class_6546 erosion) {
        for (Weirdness weirdness : placement.getWeirdnesses()) {
            parameters.add(Pair.of(
                class_6544.method_38118(
                    temperature.parameter(),
                    humidity.parameter(),
                    continentalness,
                    erosion,
                    Depth.SURFACE.parameter(),
                    weirdness.parameter(),
                    0.0F
                ),
                biome
            ));
        }
    }
}