package com.blackgear.vanillabackport.common.integrations;

import com.blackgear.platform.common.integration.BlockIntegration;
import com.blackgear.vanillabackport.common.integrations.dispenser.BoatDispenseBehavior;
import com.blackgear.vanillabackport.common.integrations.dispenser.SulfurCubeBucketDispenseBehavior;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import com.blackgear.vanillabackport.common.registries.entities.ModBoatTypes;
import com.blackgear.vanillabackport.common.registries.items.ModItems;
import com.blackgear.vanillabackport.core.ModChecker;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.blackgear.vanillabackport.core.data.tags.ModItemTags;
import net.minecraft.class_2246;
import net.minecraft.class_2965;

public class BlockIntegrations {
    private static void registerFuel(BlockIntegration.Event event) {
        // Spring to Life
        event.registerFuelItem(ModBlocks.SHORT_DRY_GRASS.get(), 100);
        event.registerFuelItem(ModBlocks.TALL_DRY_GRASS.get(), 100);
        event.registerFuelItem(ModBlocks.LEAF_LITTER.get(), 100);
        
        // Miscellaneous
        event.registerFuelItem(ModItemTags.WOOL_STAIRS, 100);
        event.registerFuelItem(ModItemTags.WOOL_SLABS, 100);
        event.registerFuelItem(ModItemTags.CUSHIONS, 200);
    }
    
    private static void registerFlammables(BlockIntegration.Event event) {
        // The Garden Awakens
        event.registerFlammableBlock(ModBlocks.PALE_OAK_PLANKS.get(), 5, 20);
        event.registerFlammableBlock(ModBlocks.PALE_OAK_SLAB.get(), 5, 20);
        event.registerFlammableBlock(ModBlocks.PALE_OAK_FENCE_GATE.get(), 5, 20);
        event.registerFlammableBlock(ModBlocks.PALE_OAK_FENCE.get(), 5, 20);
        event.registerFlammableBlock(ModBlocks.PALE_OAK_STAIRS.get(), 5, 20);
        event.registerFlammableBlock(ModBlocks.PALE_OAK_LOG.get(), 5, 5);
        event.registerFlammableBlock(ModBlocks.STRIPPED_PALE_OAK_LOG.get(), 5, 5);
        event.registerFlammableBlock(ModBlocks.STRIPPED_PALE_OAK_WOOD.get(), 5, 5);
        event.registerFlammableBlock(ModBlocks.PALE_OAK_WOOD.get(), 5, 5);
        event.registerFlammableBlock(ModBlocks.PALE_OAK_LEAVES.get(), 30, 60);
        event.registerFlammableBlock(ModBlocks.PALE_MOSS_BLOCK.get(), 5, 100);
        event.registerFlammableBlock(ModBlocks.PALE_MOSS_CARPET.get(), 5, 100);
        event.registerFlammableBlock(ModBlocks.PALE_HANGING_MOSS.get(), 5, 100);
        event.registerFlammableBlock(ModBlocks.OPEN_EYEBLOSSOM.get(), 60, 100);
        event.registerFlammableBlock(ModBlocks.CLOSED_EYEBLOSSOM.get(), 60, 100);
        
        // Spring to Life
        event.registerFlammableBlock(ModBlocks.BUSH.get(), 60, 100);
        event.registerFlammableBlock(ModBlocks.FIREFLY_BUSH.get(), 60, 100);
        event.registerFlammableBlock(ModBlocks.WILDFLOWERS.get(), 60, 100);
        event.registerFlammableBlock(ModBlocks.CACTUS_FLOWER.get(), 60, 100);
        event.registerFlammableBlock(ModBlocks.SHORT_DRY_GRASS.get(), 60, 100);
        event.registerFlammableBlock(ModBlocks.TALL_DRY_GRASS.get(), 60, 100);
        event.registerFlammableBlock(ModBlocks.LEAF_LITTER.get(), 60, 100);
        
        // Wilderness Bound
        event.registerFlammableBlock(ModBlocks.STRAW_BED.get(), 30, 60);
        
        event.registerFlammableBlock(ModBlocks.WHITE_WOOL_STAIRS.get(), 30, 60);
        event.registerFlammableBlock(ModBlocks.ORANGE_WOOL_STAIRS.get(), 30, 60);
        event.registerFlammableBlock(ModBlocks.MAGENTA_WOOL_STAIRS.get(), 30, 60);
        event.registerFlammableBlock(ModBlocks.LIGHT_BLUE_WOOL_STAIRS.get(), 30, 60);
        event.registerFlammableBlock(ModBlocks.YELLOW_WOOL_STAIRS.get(), 30, 60);
        event.registerFlammableBlock(ModBlocks.LIME_WOOL_STAIRS.get(), 30, 60);
        event.registerFlammableBlock(ModBlocks.PINK_WOOL_STAIRS.get(), 30, 60);
        event.registerFlammableBlock(ModBlocks.GRAY_WOOL_STAIRS.get(), 30, 60);
        event.registerFlammableBlock(ModBlocks.LIGHT_GRAY_WOOL_STAIRS.get(), 30, 60);
        event.registerFlammableBlock(ModBlocks.CYAN_WOOL_STAIRS.get(), 30, 60);
        event.registerFlammableBlock(ModBlocks.PURPLE_WOOL_STAIRS.get(), 30, 60);
        event.registerFlammableBlock(ModBlocks.BLUE_WOOL_STAIRS.get(), 30, 60);
        event.registerFlammableBlock(ModBlocks.BROWN_WOOL_STAIRS.get(), 30, 60);
        event.registerFlammableBlock(ModBlocks.GREEN_WOOL_STAIRS.get(), 30, 60);
        event.registerFlammableBlock(ModBlocks.RED_WOOL_STAIRS.get(), 30, 60);
        event.registerFlammableBlock(ModBlocks.BLACK_WOOL_STAIRS.get(), 30, 60);
        
        event.registerFlammableBlock(ModBlocks.WHITE_WOOL_SLAB.get(), 30, 60);
        event.registerFlammableBlock(ModBlocks.ORANGE_WOOL_SLAB.get(), 30, 60);
        event.registerFlammableBlock(ModBlocks.MAGENTA_WOOL_SLAB.get(), 30, 60);
        event.registerFlammableBlock(ModBlocks.LIGHT_BLUE_WOOL_SLAB.get(), 30, 60);
        event.registerFlammableBlock(ModBlocks.YELLOW_WOOL_SLAB.get(), 30, 60);
        event.registerFlammableBlock(ModBlocks.LIME_WOOL_SLAB.get(), 30, 60);
        event.registerFlammableBlock(ModBlocks.PINK_WOOL_SLAB.get(), 30, 60);
        event.registerFlammableBlock(ModBlocks.GRAY_WOOL_SLAB.get(), 30, 60);
        event.registerFlammableBlock(ModBlocks.LIGHT_GRAY_WOOL_SLAB.get(), 30, 60);
        event.registerFlammableBlock(ModBlocks.CYAN_WOOL_SLAB.get(), 30, 60);
        event.registerFlammableBlock(ModBlocks.PURPLE_WOOL_SLAB.get(), 30, 60);
        event.registerFlammableBlock(ModBlocks.BLUE_WOOL_SLAB.get(), 30, 60);
        event.registerFlammableBlock(ModBlocks.BROWN_WOOL_SLAB.get(), 30, 60);
        event.registerFlammableBlock(ModBlocks.GREEN_WOOL_SLAB.get(), 30, 60);
        event.registerFlammableBlock(ModBlocks.RED_WOOL_SLAB.get(), 30, 60);
        event.registerFlammableBlock(ModBlocks.BLACK_WOOL_SLAB.get(), 30, 60);
    }
    
    private static void registerCompostables(BlockIntegration.Event event) {
        // The Garden Awakens
        event.registerCompostableItem(ModBlocks.PALE_OAK_LEAVES.get(), 0.3F);
        event.registerCompostableItem(ModBlocks.PALE_OAK_SAPLING.get(), 0.3F);
        event.registerCompostableItem(ModBlocks.PALE_MOSS_CARPET.get(), 0.3F);
        event.registerCompostableItem(ModBlocks.PALE_HANGING_MOSS.get(), 0.3F);
        event.registerCompostableItem(ModBlocks.PALE_MOSS_BLOCK.get(), 0.65F);
        event.registerCompostableItem(ModBlocks.OPEN_EYEBLOSSOM.get(), 0.65F);
        event.registerCompostableItem(ModBlocks.CLOSED_EYEBLOSSOM.get(), 0.65F);
        
        // Spring to Life
        event.registerCompostableItem(ModBlocks.BUSH.get(), 0.3F);
        event.registerCompostableItem(ModBlocks.LEAF_LITTER.get(), 0.3F);
        event.registerCompostableItem(ModBlocks.FIREFLY_BUSH.get(), 0.3F);
        event.registerCompostableItem(ModBlocks.WILDFLOWERS.get(), 0.3F);
        event.registerCompostableItem(ModBlocks.CACTUS_FLOWER.get(), 0.3F);
        event.registerCompostableItem(ModBlocks.SHORT_DRY_GRASS.get(), 0.3F);
        event.registerCompostableItem(ModBlocks.TALL_DRY_GRASS.get(), 0.3F);
        
        // Wilderness Bound
        event.registerCompostableItem(ModBlocks.RED_SHRUB.get(), 0.3F);
        event.registerCompostableItem(ModBlocks.RED_POPLAR_LEAVES.get(), 0.3F);
        event.registerCompostableItem(ModBlocks.ORANGE_POPLAR_LEAVES.get(), 0.3F);
        event.registerCompostableItem(ModBlocks.YELLOW_POPLAR_LEAVES.get(), 0.3F);
        event.registerCompostableItem(ModBlocks.POPLAR_SAPLING.get(), 0.3F);
        event.registerCompostableItem(ModBlocks.SHELF_MUSHROOM.get(), 0.65F);
    }
    
    private static void registerStrippables(BlockIntegration.Event event) {
        // The Garden Awakens
        event.registerStrippableBlock(ModBlocks.PALE_OAK_LOG.get(), ModBlocks.STRIPPED_PALE_OAK_LOG.get());
        event.registerStrippableBlock(ModBlocks.PALE_OAK_WOOD.get(), ModBlocks.STRIPPED_PALE_OAK_WOOD.get());
        
        // Wilderness Bound
        event.registerStrippableBlock(ModBlocks.POPLAR_LOG.get(), ModBlocks.STRIPPED_POPLAR_LOG.get());
        event.registerStrippableBlock(ModBlocks.POPLAR_WOOD.get(), ModBlocks.STRIPPED_POPLAR_WOOD.get());
    }
    
    private static void registerWaxables(BlockIntegration.Event event) {
        event.registerWaxableBlock(ModBlocks.COPPER_CHEST.get(), ModBlocks.WAXED_COPPER_CHEST.get());
        event.registerWaxableBlock(ModBlocks.EXPOSED_COPPER_CHEST.get(), ModBlocks.WAXED_EXPOSED_COPPER_CHEST.get());
        event.registerWaxableBlock(ModBlocks.WEATHERED_COPPER_CHEST.get(), ModBlocks.WAXED_WEATHERED_COPPER_CHEST.get());
        event.registerWaxableBlock(ModBlocks.OXIDIZED_COPPER_CHEST.get(), ModBlocks.WAXED_OXIDIZED_COPPER_CHEST.get());
        
        event.registerWaxableBlock(ModBlocks.COPPER_GOLEM_STATUE.get(), ModBlocks.WAXED_COPPER_GOLEM_STATUE.get());
        event.registerWaxableBlock(ModBlocks.EXPOSED_COPPER_GOLEM_STATUE.get(), ModBlocks.WAXED_EXPOSED_COPPER_GOLEM_STATUE.get());
        event.registerWaxableBlock(ModBlocks.WEATHERED_COPPER_GOLEM_STATUE.get(), ModBlocks.WAXED_WEATHERED_COPPER_GOLEM_STATUE.get());
        event.registerWaxableBlock(ModBlocks.OXIDIZED_COPPER_GOLEM_STATUE.get(), ModBlocks.WAXED_OXIDIZED_COPPER_GOLEM_STATUE.get());
        
        if (VanillaBackport.COMMON_CONFIG.hasWeatheringLightningRods.get() || !ModChecker.CAVERNS_AND_CHASMS) {
            event.registerWaxableBlock(class_2246.field_27171, ModBlocks.WAXED_LIGHTNING_ROD.get());
            event.registerWaxableBlock(ModBlocks.EXPOSED_LIGHTNING_ROD.get(), ModBlocks.WAXED_EXPOSED_LIGHTNING_ROD.get());
            event.registerWaxableBlock(ModBlocks.WEATHERED_LIGHTNING_ROD.get(), ModBlocks.WAXED_WEATHERED_LIGHTNING_ROD.get());
            event.registerWaxableBlock(ModBlocks.OXIDIZED_LIGHTNING_ROD.get(), ModBlocks.WAXED_OXIDIZED_LIGHTNING_ROD.get());
        }
        
        ModBlocks.COPPER_LANTERN.waxedMapping().forEach((from, to) -> event.registerWaxableBlock(from.get(), to.get()));
        ModBlocks.COPPER_BARS.waxedMapping().forEach((from, to) -> event.registerWaxableBlock(from.get(), to.get()));
        ModBlocks.COPPER_CHAIN.waxedMapping().forEach((from, to) -> event.registerWaxableBlock(from.get(), to.get()));
    }
    
    private static void registerOxidables(BlockIntegration.Event event) {
        event.registerOxidableBlock(ModBlocks.COPPER_CHEST.get(), ModBlocks.EXPOSED_COPPER_CHEST.get());
        event.registerOxidableBlock(ModBlocks.EXPOSED_COPPER_CHEST.get(), ModBlocks.WEATHERED_COPPER_CHEST.get());
        event.registerOxidableBlock(ModBlocks.WEATHERED_COPPER_CHEST.get(), ModBlocks.OXIDIZED_COPPER_CHEST.get());
        
        event.registerOxidableBlock(ModBlocks.COPPER_GOLEM_STATUE.get(), ModBlocks.EXPOSED_COPPER_GOLEM_STATUE.get());
        event.registerOxidableBlock(ModBlocks.EXPOSED_COPPER_GOLEM_STATUE.get(), ModBlocks.WEATHERED_COPPER_GOLEM_STATUE.get());
        event.registerOxidableBlock(ModBlocks.WEATHERED_COPPER_GOLEM_STATUE.get(), ModBlocks.OXIDIZED_COPPER_GOLEM_STATUE.get());
        
        if (VanillaBackport.COMMON_CONFIG.hasWeatheringLightningRods.get() || !ModChecker.CAVERNS_AND_CHASMS) {
            event.registerOxidableBlock(class_2246.field_27171, ModBlocks.EXPOSED_LIGHTNING_ROD.get());
            event.registerOxidableBlock(ModBlocks.EXPOSED_LIGHTNING_ROD.get(), ModBlocks.WEATHERED_LIGHTNING_ROD.get());
            event.registerOxidableBlock(ModBlocks.WEATHERED_LIGHTNING_ROD.get(), ModBlocks.OXIDIZED_LIGHTNING_ROD.get());
        }
        
        ModBlocks.COPPER_LANTERN.weatheringMapping().forEach((from, to) -> event.registerOxidableBlock(from.get(), to.get()));
        ModBlocks.COPPER_BARS.weatheringMapping().forEach((from, to) -> event.registerOxidableBlock(from.get(), to.get()));
        ModBlocks.COPPER_CHAIN.weatheringMapping().forEach((from, to) -> event.registerOxidableBlock(from.get(), to.get()));
    }
    
    private static void registerDispensables(BlockIntegration.Event event) {
        // The Garden Awakens
        event.registerDispenserBehavior(ModItems.PALE_OAK_BOAT.get(), new BoatDispenseBehavior(ModBoatTypes.PALE_OAK));
        event.registerDispenserBehavior(ModItems.PALE_OAK_CHEST_BOAT.get(), new BoatDispenseBehavior(ModBoatTypes.PALE_OAK, true));
        
        // Spring to Life
        event.registerDispenserBehavior(ModItems.BLUE_EGG.get(), new class_2965(ModItems.BLUE_EGG.get()));
        event.registerDispenserBehavior(ModItems.BROWN_EGG.get(), new class_2965(ModItems.BROWN_EGG.get()));
        
        // Chaos Cubed
        event.registerDispenserBehavior(ModItems.SULFUR_CUBE_BUCKET.get(), new SulfurCubeBucketDispenseBehavior());
        
        // Wilderness Bound
        event.registerDispenserBehavior(ModItems.POPLAR_BOAT.get(), new BoatDispenseBehavior(ModBoatTypes.POPLAR));
        event.registerDispenserBehavior(ModItems.POPLAR_CHEST_BOAT.get(), new BoatDispenseBehavior(ModBoatTypes.POPLAR, true));
    }
    
    public static void bootstrap(BlockIntegration.Event event) {
        registerFuel(event);
        registerFlammables(event);
        registerCompostables(event);
        registerStrippables(event);
        registerWaxables(event);
        registerOxidables(event);
        registerDispensables(event);
    }
}