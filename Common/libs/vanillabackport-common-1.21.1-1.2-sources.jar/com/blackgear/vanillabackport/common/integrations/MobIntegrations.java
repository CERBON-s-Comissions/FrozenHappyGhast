package com.blackgear.vanillabackport.common.integrations;

import com.blackgear.platform.common.integration.MobIntegration.Event;
import com.blackgear.platform.common.integration.v2.spawn_placement.SpawnPlacementStrategy;
import com.blackgear.vanillabackport.common.integrations.interactions.GhastHarnessInteraction;
import com.blackgear.vanillabackport.common.integrations.interactions.LeashInteraction;
import com.blackgear.vanillabackport.common.level.entities.ai.goal.OfferCopperGolemFlowerGoal;
import com.blackgear.vanillabackport.common.level.entities.ai.goal.SpearUseGoal;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.golem.copper_golem.CopperGolem;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.happy_ghast.HappyGhast;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.nautilus.AbstractNautilus;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.nautilus.ZombieNautilus;
import com.blackgear.vanillabackport.common.level.entities.mob.monster.creaking.Creaking;
import com.blackgear.vanillabackport.common.level.entities.mob.monster.skeleton.Parched;
import com.blackgear.vanillabackport.common.level.entities.mob.monster.sulfur_cube.SulfurCube;
import com.blackgear.vanillabackport.common.registries.entities.ModEntityTypes;
import com.blackgear.vanillabackport.core.data.tags.ModItemTags;
import net.minecraft.class_1299;
import net.minecraft.class_1314;
import net.minecraft.class_1338;
import net.minecraft.class_1347;
import net.minecraft.class_1391;
import net.minecraft.class_1439;
import net.minecraft.class_1507;
import net.minecraft.class_1588;
import net.minecraft.class_1590;
import net.minecraft.class_1642;
import net.minecraft.class_1856;
import net.minecraft.class_2902;
import net.minecraft.class_7689;
import net.minecraft.class_9169;
import net.minecraft.world.entity.*;

public class MobIntegrations {
    private static void registerInteractions(Event event) {
        event.registerMobInteraction(new GhastHarnessInteraction());
        event.registerMobInteraction(new LeashInteraction());
    }
    
    private static void registerPlacements(Event event) {
        event.registerPlacement(ModEntityTypes.CREAKING, class_9169.field_48745, class_2902.class_2903.field_13203, MobSpawns::checkMonsterSpawnRules);
        event.registerPlacement(() -> class_1299.field_40116, class_9169.field_48745, class_2902.class_2903.field_13203, MobSpawns::checkCamelSpawnRules, SpawnPlacementStrategy.OR);
        event.registerPlacement(ModEntityTypes.SULFUR_CUBE, class_9169.field_48745, class_2902.class_2903.field_13203, SulfurCube::checkSulfurCubeSpawnRules);
        event.registerPlacement(ModEntityTypes.PARCHED, class_9169.field_48745, class_2902.class_2903.field_13203, MobSpawns::checkSurfaceMonstersSpawnRules);
        event.registerPlacement(ModEntityTypes.CAMEL_HUSK, class_9169.field_48745, class_2902.class_2903.field_13203, MobSpawns::checkSurfaceMonstersSpawnRules);
        event.registerPlacement(ModEntityTypes.NAUTILUS, class_9169.field_48743, class_2902.class_2903.field_13203, AbstractNautilus::checkNautilusSpawnRules);
        event.registerPlacement(() -> class_1299.field_6048, class_9169.field_48745, class_2902.class_2903.field_13203, MobSpawns::checkMonsterSpawnRules, SpawnPlacementStrategy.REPLACE);
    }
    
    private static void registerAttributes(Event event) {
        event.registerAttributes(ModEntityTypes.CREAKING, Creaking::createAttributes);
        event.registerAttributes(ModEntityTypes.HAPPY_GHAST, HappyGhast::createAttributes);
        event.registerAttributes(ModEntityTypes.SULFUR_CUBE, SulfurCube::createSulfurCubeAttributes);
        event.registerAttributes(ModEntityTypes.COPPER_GOLEM, CopperGolem::createAttributes);
        event.registerAttributes(ModEntityTypes.PARCHED, Parched::method_26905);
        event.registerAttributes(ModEntityTypes.CAMEL_HUSK, class_7689::method_45360);
        event.registerAttributes(ModEntityTypes.NAUTILUS, AbstractNautilus::createAttributes);
        event.registerAttributes(ModEntityTypes.ZOMBIE_NAUTILUS, ZombieNautilus::createAttributes);
    }
    
    private static void registerGoals(Event event) {
        event.registerGoal(class_1299.field_6117, 1, mob -> new class_1338<>((class_1314) mob, Creaking.class, 8.0F, 0.6, 1.2));
        event.registerGoal(class_1299.field_6105, 1, mob -> new class_1338<>((class_1314) mob, Creaking.class, 8.0F, 0.6, 1.2));
        event.registerGoal(class_1299.field_6065, 3, mob -> new class_1338<>((class_1314) mob, Creaking.class, 8.0F, 0.6, 1.2));
        event.registerGoal(class_1299.field_6090, 3, mob -> new class_1338<>((class_1314) mob, Creaking.class, 8.0F, 0.6, 1.2));
        
        event.registerGoal(class_1299.field_6147, 5, mob -> new OfferCopperGolemFlowerGoal((class_1439) mob));
        
        event.registerGoal(mob -> mob instanceof class_1642, 2, mob -> new SpearUseGoal<>((class_1588) mob, 1.0, 1.0, 10.0F, 2.0F));
        event.registerGoal(mob -> mob instanceof class_1590, 1, mob -> new SpearUseGoal<>((class_1588) mob, 1.0, 1.0, 10.0F, 2.0F));
        
        event.registerGoal(mob -> mob instanceof class_1507, 0, class_1347::new);
        event.registerGoal(mob -> mob instanceof class_1507, 3, mob -> new class_1391((class_1314) mob, 1.25, class_1856.method_8106(ModItemTags.ZOMBIE_HORSE_FOOD), false));
    }
    
    public static void bootstrap(Event event) {
        registerInteractions(event);
        registerPlacements(event);
        registerAttributes(event);
        registerGoals(event);
    }
}