package com.blackgear.vanillabackport.common.integrations.interactions;

import com.blackgear.platform.common.integration.MobInteraction;
import com.blackgear.vanillabackport.common.api.modules.leash_behavior.LeashPhysics;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_5712;
import net.minecraft.class_9817;

public class LeashInteraction implements MobInteraction {
    @Override
    public class_1269 onInteract(class_1657 player, class_1297 entity, class_1268 hand) {
        class_1937 level = entity.method_37908();

        if (!level.method_8608()
            && player.method_21823()
            && entity instanceof class_9817 leashable
            && leashable.method_5931()
            && entity.method_5805()
            && !(entity instanceof class_1309 living && living.method_6109())) {

            List<class_9817> mobsToLeash = LeashPhysics.leashableInArea(entity, l -> l.method_60952() == player);
            if (!mobsToLeash.isEmpty()) {
                boolean anyLeashed = false;

                for (class_9817 target : mobsToLeash) {
                    if (LeashPhysics.canAttachLeash(target, entity)) {
                        target.method_60964(entity, true);
                        anyLeashed = true;
                    }
                }

                if (anyLeashed) {
                    level.method_43276(class_5712.field_28725, entity.method_24515(), class_5712.class_7397.method_43285(player));
                    entity.method_43077(class_3417.field_15062);
                    return class_1269.field_5812;
                }
            }
        }

        class_1799 heldItem = player.method_5998(hand);
        if (heldItem.method_31574(class_1802.field_8868) && shearAllConnections(entity, player)) {
            heldItem.method_7970(1, player, class_1309.method_56079(hand));
            return class_1269.method_29236(level.method_8608());
        }

        if (entity.method_5805() && entity instanceof class_9817 leashable) {
            if (leashable.method_60952() == player) {
                if (!level.method_8608()) {
                    leashable.method_5932(true, !player.method_7337());
                    entity.method_32875(class_5712.field_28725, player);
                    entity.method_43077(class_3417.field_15184);
                }

                return class_1269.method_29236(level.method_8608());
            }

            if (heldItem.method_31574(class_1802.field_8719) && !(leashable.method_60952() instanceof class_1657)) {
                if (level.method_8608()) {
                    return class_1269.field_21466;
                }

                if (LeashPhysics.canAttachLeash(leashable, player)) {
                    if (leashable.method_60953()) leashable.method_5932(true, true);
                    leashable.method_60964(player, true);
                    entity.method_43077(class_3417.field_15062);
                    if (!player.method_7337()) heldItem.method_7934(1);
                    return class_1269.field_5812;
                }
            }
        }

        return class_1269.field_5811;
    }

    private static boolean shearAllConnections(class_1297 entity, class_1657 player) {
        boolean dropped = LeashPhysics.dropAllLeashConnections(entity, player);
        if (dropped && entity.method_37908() instanceof class_3218 server) {
            server.method_45447(null, entity.method_24515(), class_3417.field_14975, player != null ? player.method_5634() : entity.method_5634());
        }

        return dropped;
    }
}