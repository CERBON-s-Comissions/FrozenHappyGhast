package com.blackgear.vanillabackport.common.integrations.interactions;

import com.blackgear.platform.common.integration.MobInteraction;
import com.blackgear.vanillabackport.common.level.entities.mob.animal.happy_ghast.HappyGhast;
import com.blackgear.vanillabackport.core.data.tags.ModItemTags;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_5712;

public class GhastHarnessInteraction implements MobInteraction {
    @Override
    public class_1269 onInteract(class_1657 player, class_1297 target, class_1268 hand) {
        if (target instanceof HappyGhast ghast && target.method_5805()) {
            class_1799 stack = player.method_5998(hand);
            if (!stack.method_31573(ModItemTags.HARNESSES)) return class_1269.field_5811;

            if (!ghast.isHarnessed() && ghast.canBeHarnessed()) {
                if (!player.method_37908().field_9236) {
                    ghast.equipHarness();
                    ghast.method_5673(class_1304.field_6174, new class_1799(stack.method_7909()));
                    target.method_37908().method_43275(target, class_5712.field_28739, target.method_19538());
                    if (!player.method_31549().field_7477) stack.method_7934(1);
                }

                return class_1269.method_29236(player.method_37908().field_9236);
            }
        }

        return class_1269.field_5811;
    }
}
