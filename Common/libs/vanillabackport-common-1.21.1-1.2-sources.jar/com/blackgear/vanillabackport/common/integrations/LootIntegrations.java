package com.blackgear.vanillabackport.common.integrations;

import com.blackgear.platform.common.data.LootModifier;
import com.blackgear.vanillabackport.common.registries.worldgen.ModBiomes;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import com.blackgear.vanillabackport.common.registries.items.ModItems;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.blackgear.vanillabackport.core.data.ModBuiltInLootTables;
import net.minecraft.advancements.critereon.*;
import net.minecraft.class_106;
import net.minecraft.class_109;
import net.minecraft.class_1299;
import net.minecraft.class_141;
import net.minecraft.class_149;
import net.minecraft.class_1802;
import net.minecraft.class_190;
import net.minecraft.class_2022;
import net.minecraft.class_2040;
import net.minecraft.class_2048;
import net.minecraft.class_205;
import net.minecraft.class_2090;
import net.minecraft.class_215;
import net.minecraft.class_221;
import net.minecraft.class_39;
import net.minecraft.class_44;
import net.minecraft.class_47;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_55;
import net.minecraft.class_5662;
import net.minecraft.class_6885;
import net.minecraft.class_73;
import net.minecraft.class_77;
import net.minecraft.class_7924;
import net.minecraft.class_8103;
import net.minecraft.class_8129;
import java.util.List;

public class LootIntegrations implements LootModifier.LootTableModifier {
    public static final LootIntegrations INSTANCE = new LootIntegrations();
    
    private static final List<class_5321<class_52>> CONTAIN_BUNDLE = List.of(
        class_39.field_434,
        class_39.field_16751,
        class_39.field_16750,
        class_39.field_16748,
        class_39.field_16749,
        class_39.field_16753,
        class_39.field_16754,
        class_39.field_16752
    );
    
    private static final List<class_5321<class_52>> CONTAIN_NAUTILUS_ARMOR = List.of(
        class_39.field_251,
        class_39.field_300,
        class_39.field_397,
        class_39.field_880,
        class_39.field_841,
        class_39.field_665
    );

    @Override
    public void modify(class_5321<class_52> key, LootModifier.LootTableContext context, boolean builtin) {
        if (key.equals(class_1299.field_6107.method_16351()) && VanillaBackport.COMMON_CONFIG.hasTearsMusicDisc.get()) {
            context.addPool(class_55.method_347()
                .method_352(class_44.method_32448(1.0F))
                .method_351(class_77.method_411(ModItems.MUSIC_DISC_TEARS.get()))
                .method_353(class_141.method_621(class_44.method_32448(1.0F)))
                .method_356(class_190.method_837(
                    class_2022.class_2023.method_8855()
                        .method_48785(class_8129.method_48965(class_8103.field_42247))
                        .method_8854(class_2048.class_2049.method_8916().method_8921(class_1299.field_6066))))
                .method_356(class_221.method_939()));
        }

        if (key.equals(class_39.field_22402) && VanillaBackport.COMMON_CONFIG.hasDriedGhasts.get()) {
            context.addToPool(class_77.method_411(ModBlocks.DRIED_GHAST.get())
                .method_437(10)
                .method_438(class_141.method_621(class_44.method_32448(1.0F))));
        }

        if (key.equals(class_1299.field_6051.method_16351()) && VanillaBackport.COMMON_CONFIG.hasLavaChickenMusicDisc.get()) {
            context.addPool(class_55.method_347()
                .method_351(class_77.method_411(ModItems.MUSIC_DISC_LAVA_CHICKEN.get()))
                .method_356(class_221.method_939())
                .method_356(class_215.method_917(
                    class_47.class_50.field_935,
                    class_2048.class_2049.method_8916()
                        .method_8919(class_2040.class_2041.method_8897().method_29935(true))
                        .method_27971(class_2048.class_2049.method_8916().method_8921(class_1299.field_6132))
                )));
        }

        if (key.equals(class_39.field_484) && VanillaBackport.COMMON_CONFIG.hasResinLoot.get()) {
            context.addToPool(1, class_77.method_411(ModBlocks.RESIN_CLUMP.get())
                .method_437(50)
                .method_438(class_141.method_621(class_5662.method_32462(2.0F, 4.0F))));
        }

        if (CONTAIN_BUNDLE.contains(key) && VanillaBackport.COMMON_CONFIG.hasBundleLoot.get()) {
            context.addPool(class_55.method_347()
                .method_352(class_44.method_32448(1.0F))
                .method_351(class_77.method_411(class_1802.field_27023).method_437(1).method_438(class_141.method_621(class_44.method_32448(1.0F))))
                .method_351(class_73.method_401().method_437(2)));
        }

        if (key.equals(class_39.field_24050) && VanillaBackport.COMMON_CONFIG.hasLodestoneLoot.get()) {
            context.addPool(class_55.method_347()
                .method_352(class_44.method_32448(1.0F))
                .method_351(class_77.method_411(class_1802.field_23256).method_437(2).method_438(class_141.method_621(class_5662.method_32462(1.0F, 2.0F))))
                .method_351(class_73.method_401().method_437(1)));
        }
        
        if (key.equals(class_39.field_472) && VanillaBackport.COMMON_CONFIG.hasBounceMusicDisc.get()) {
            var biomes = context.registries().method_46762(class_7924.field_41236);
            context.addToPool(2, class_77.method_411(ModItems.MUSIC_DISC_BOUNCE.get())
                .method_421(class_205.method_884(class_2090.class_2091.method_22484().method_9024(class_6885.method_40246(biomes.method_46747(ModBiomes.SULFUR_CAVES)))))
                .method_437(10));
        }
        
        // GENERATE COPPER HORSE ARMOR
        if (VanillaBackport.COMMON_CONFIG.hasCopperHorseArmorLoot.get()) {
            if (key.equals(class_39.field_356)) {
                context.addToPool(class_77.method_411(ModItems.COPPER_HORSE_ARMOR.get()).method_437(15));
            }
            
            if (key.equals(class_39.field_434)) {
                context.addToPool(class_77.method_411(ModItems.COPPER_HORSE_ARMOR.get()));
            }
            
            if (key.equals(class_39.field_274)) {
                context.addToPool(class_77.method_411(ModItems.COPPER_HORSE_ARMOR.get()));
            }
            
            if (key.equals(class_39.field_615)) {
                context.addToPool(class_77.method_411(ModItems.COPPER_HORSE_ARMOR.get()).method_437(5));
            }
            
            if (key.equals(class_39.field_842)) {
                context.addToPool(class_77.method_411(ModItems.COPPER_HORSE_ARMOR.get()));
            }
            
            if (key.equals(class_39.field_803)) {
                context.addToPool(class_77.method_411(ModItems.COPPER_HORSE_ARMOR.get()));
            }
            
            if (key.equals(class_39.field_885)) {
                context.addToPool(class_77.method_411(ModItems.COPPER_HORSE_ARMOR.get()).method_437(15));
            }
        }
        
        if (CONTAIN_NAUTILUS_ARMOR.contains(key) && VanillaBackport.COMMON_CONFIG.hasNautilusArmorLoot.get()) {
            context.addPool(class_55.method_347()
                .method_352(class_44.method_32448(1.0F))
                .method_351(class_73.method_401().method_437(148))
                .method_351(class_77.method_411(ModItems.COPPER_NAUTILUS_ARMOR.get())
                    .method_437(20)
                    .method_438(class_141.method_621(class_44.method_32448(1.0F))))
                .method_351(class_77.method_411(ModItems.IRON_NAUTILUS_ARMOR.get())
                    .method_437(10)
                    .method_438(class_141.method_621(class_44.method_32448(1.0F))))
                .method_351(class_77.method_411(ModItems.GOLDEN_NAUTILUS_ARMOR.get())
                    .method_437(5)
                    .method_438(class_141.method_621(class_44.method_32448(1.0F))))
                .method_351(class_77.method_411(ModItems.DIAMOND_NAUTILUS_ARMOR.get())
                    .method_437(2)
                    .method_438(class_141.method_621(class_44.method_32448(1.0F)))));
        }
        
        if (VanillaBackport.COMMON_CONFIG.hasCopperToolSet.get()) {
            if (key.equals(ModBuiltInLootTables.ABANDONED_CAMP_COMMON_CHEST)) {
                context.addToPool(1,
                    class_77.method_411(ModItems.COPPER_SPEAR.get()).method_437(1).method_438(class_141.method_621(class_44.method_32448(1))),
                    class_77.method_411(ModItems.COPPER_AXE.get()).method_437(1).method_438(class_141.method_621(class_44.method_32448(1))),
                    class_77.method_411(ModItems.COPPER_BOOTS.get()).method_437(1).method_438(class_141.method_621(class_44.method_32448(1))),
                    class_77.method_411(ModItems.COPPER_CHESTPLATE.get()).method_437(1).method_438(class_141.method_621(class_44.method_32448(1))),
                    class_77.method_411(ModItems.COPPER_LEGGINGS.get()).method_437(1).method_438(class_141.method_621(class_44.method_32448(1))),
                    class_77.method_411(ModItems.COPPER_SWORD.get()).method_437(1).method_438(class_141.method_621(class_44.method_32448(1)))
                );
            }
        }
        
        if (VanillaBackport.COMMON_CONFIG.hasSpears.get()) {
            if (key.equals(class_39.field_251)) {
                context.addToPool(3, class_77.method_411(ModItems.IRON_SPEAR.get()));
            }
            
            if (key.equals(class_39.field_300) || key.equals(class_39.field_397)) {
                context.addToPool(
                    class_77.method_411(ModItems.IRON_SPEAR.get())
                        .method_437(2)
                );
            }
            
            if (key.equals(class_39.field_434)) {
                context.addToPool(class_77.method_411(ModItems.IRON_SPEAR.get()).method_437(5));
                
                if (VanillaBackport.COMMON_CONFIG.hasCopperToolSet.get()) {
                    context.addToPool(class_77.method_411(ModItems.COPPER_SPEAR.get()).method_437(7));
                }
            }
            
            if (key.equals(class_39.field_274)) {
                context.addToPool(
                    class_77.method_411(ModItems.DIAMOND_SPEAR.get())
                        .method_437(3)
                        .method_438(class_106.method_481(context.registries(), class_5662.method_32462(20, 39)))
                );
            }
            
            if (key.equals(class_39.field_24046)) {
                context.addToPool(
                    class_77.method_411(ModItems.DIAMOND_SPEAR.get())
                        .method_437(6)
                        .method_438(class_149.method_633(class_5662.method_32462(0.8F, 1.0F)))
                        .method_438(class_109.method_489(context.registries())),
                    
                    class_77.method_411(ModItems.DIAMOND_SPEAR.get())
                        .method_437(6)
                );
            }
            
            if (VanillaBackport.COMMON_CONFIG.hasCopperToolSet.get()) {
                if (key.equals(ModBuiltInLootTables.ABANDONED_CAMP_COMMON_CHEST)) {
                    context.addToPool(1, class_77.method_411(ModItems.COPPER_SPEAR.get()).method_437(1).method_438(class_141.method_621(class_44.method_32448(1))));
                }
            }
            
            if (key.equals(ModBuiltInLootTables.ABANDONED_CAMP_SECRET_CHEST)) {
                context.addToPool(2, class_77.method_411(ModItems.IRON_SPEAR.get()).method_437(1).method_438(class_141.method_621(class_44.method_32448(1))));
            }
        }
    }
}