package com.blackgear.vanillabackport.common.worldgen;

import com.blackgear.platform.common.worldgen.modifier.BiomeContext;
import com.blackgear.platform.common.worldgen.modifier.BiomeWriter;
import com.blackgear.platform.common.worldgen.modifier.FeatureManager;
import com.blackgear.vanillabackport.common.registries.entities.ModEntityTypes;
import com.blackgear.vanillabackport.common.registries.worldgen.ModBiomes;
import com.blackgear.vanillabackport.common.worldgen.placements.ChaosCubedPlacements;
import com.blackgear.vanillabackport.core.VanillaBackport;
import net.minecraft.class_1311;
import net.minecraft.class_2893;
import net.minecraft.class_5483;

public class ChaosCubedFeatureManager extends FeatureManager {
    public ChaosCubedFeatureManager(BiomeContext context, BiomeWriter writer) {
        super(context, writer);
    }

    @Override
    public void bootstrap() {
        this.addIf(VanillaBackport.COMMON_CONFIG.hasSulfurSprings.get(), (context, writer) -> {
            this.getOrCreateBiomeBuilder(ModBiomes.SULFUR_CAVES)
                .add(() -> writer.addFeature(class_2893.class_2895.field_25186, ChaosCubedPlacements.ROOTED_SULFUR_SPRING));
        });

        this.addIf(VanillaBackport.COMMON_CONFIG.hasSulfurCubes.get(), (context, writer) -> {
            this.getOrCreateBiomeBuilder(ModBiomes.SULFUR_CAVES)
                .add(() -> writer.addSpawn(class_1311.field_6302, new class_5483.class_1964(ModEntityTypes.SULFUR_CUBE.get(), 100, 2, 4)));
        });
    }
}