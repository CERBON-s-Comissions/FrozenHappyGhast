package com.blackgear.vanillabackport.common.worldgen.placements;

import com.blackgear.platform.core.api.registrar.bootstrap.PlacedFeatureRegistrar;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import com.blackgear.vanillabackport.common.value_providers.TrapezoidInt;
import com.blackgear.vanillabackport.common.worldgen.features.WildernessBoundFeatures;
import com.blackgear.vanillabackport.core.VanillaBackport;
import net.minecraft.class_5321;
import net.minecraft.class_5450;
import net.minecraft.class_5934;
import net.minecraft.class_6646;
import net.minecraft.class_6658;
import net.minecraft.class_6732;
import net.minecraft.class_6792;
import net.minecraft.class_6793;
import net.minecraft.class_6796;
import net.minecraft.class_6799;
import net.minecraft.class_6809;
import net.minecraft.class_6817;
import net.minecraft.class_6819;
import net.minecraft.world.level.levelgen.placement.*;

public class WildernessBoundPlacements {
    public static final PlacedFeatureRegistrar REGISTRIES = PlacedFeatureRegistrar.create(VanillaBackport.NAMESPACE);
    
    public static final class_5321<class_6796> RED_POPLAR = REGISTRIES.register("red_poplar",
        WildernessBoundFeatures.RED_POPLAR,
        class_6817.method_40365(ModBlocks.POPLAR_SAPLING.get()));
    public static final class_5321<class_6796> ORANGE_POPLAR = REGISTRIES.register("orange_poplar",
        WildernessBoundFeatures.ORANGE_POPLAR,
        class_6817.method_40365(ModBlocks.POPLAR_SAPLING.get()));
    public static final class_5321<class_6796> YELLOW_POPLAR = REGISTRIES.register("yellow_poplar",
        WildernessBoundFeatures.YELLOW_POPLAR,
        class_6817.method_40365(ModBlocks.POPLAR_SAPLING.get()));
    public static final class_5321<class_6796> FALLEN_POPLAR_TREE = REGISTRIES.register("fallen_poplar_tree",
        WildernessBoundFeatures.FALLEN_POPLAR_TREE,
        class_6819.method_39741(class_6799.method_39659(80), ModBlocks.POPLAR_SAPLING.get()));
    
    public static final class_5321<class_6796> PATCH_RED_SHRUB = REGISTRIES.register("patch_red_shrub",
        WildernessBoundFeatures.RED_SHRUB,
        class_5450.method_39639(),
        class_6817.field_36080,
        class_6792.method_39614(),
        class_6793.method_39623(8),
        class_6732.method_39657(TrapezoidInt.triangle(7), TrapezoidInt.triangle(3)),
        class_6658.method_39618(class_6646.field_35696)
    );
    public static final class_5321<class_6796> BROWN_MUSHROOM_DAPPLED_FOREST = REGISTRIES.register("brown_mushroom_dappled_forest",
        WildernessBoundFeatures.BROWN_MUSHROOM,
        class_6799.method_39659(2),
        class_5450.method_39639(),
        class_6817.field_36078,
        class_6792.method_39614(),
        class_6793.method_39623(96),
        class_6732.method_39657(TrapezoidInt.triangle(7), TrapezoidInt.triangle(3)),
        class_6658.method_39618(class_6646.field_35696)
    );
    
    public static final class_5321<class_6796> BAMBOO_IN_STRUCTURE = REGISTRIES.register("bamboo_in_structure",
        class_6809.field_35941,
        class_6817.method_40371());
    
    public static final class_5321<class_6796> TREES_DAPPLED_FOREST = REGISTRIES.register("trees_dappled_forest",
        WildernessBoundFeatures.TREES_DAPPLED_FOREST,
        class_6793.method_39623(6),
        class_5450.method_39639(),
        class_5934.method_39662(0),
        class_6817.field_36081,
        class_6792.method_39614());
}