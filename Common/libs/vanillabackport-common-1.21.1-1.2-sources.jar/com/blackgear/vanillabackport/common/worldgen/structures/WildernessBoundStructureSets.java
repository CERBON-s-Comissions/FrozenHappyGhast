package com.blackgear.vanillabackport.common.worldgen.structures;

import com.blackgear.platform.core.api.registrar.bootstrap.BootstrapRegistrar;
import com.blackgear.vanillabackport.core.VanillaBackport;
import java.util.List;
import net.minecraft.class_1959;
import net.minecraft.class_3195;
import net.minecraft.class_5321;
import net.minecraft.class_6872;
import net.minecraft.class_6873;
import net.minecraft.class_7059;
import net.minecraft.class_7871;
import net.minecraft.class_7924;

public class WildernessBoundStructureSets {
    public static final BootstrapRegistrar<class_7059> REGISTRIES = BootstrapRegistrar.create(class_7924.field_41248, VanillaBackport.NAMESPACE);
    
    public static final class_5321<class_7059> ABANDONED_CAMP = REGISTRIES.register("abandoned_camp", context -> {
        class_7871<class_3195> structures = context.method_46799(class_7924.field_41246);
        class_7871<class_1959> biomes = context.method_46799(class_7924.field_41236);
        return new class_7059(
            List.of(
                class_7059.method_41145(structures.method_46747(WildernessBoundStructures.ABANDONED_CAMP_BAMBOO_JUNGLE)),
                class_7059.method_41145(structures.method_46747(WildernessBoundStructures.ABANDONED_CAMP_BIRCH_FOREST)),
                class_7059.method_41145(structures.method_46747(WildernessBoundStructures.ABANDONED_CAMP_CHERRY_GROVE)),
                class_7059.method_41145(structures.method_46747(WildernessBoundStructures.ABANDONED_CAMP_DAPPLED_FOREST)),
                class_7059.method_41145(structures.method_46747(WildernessBoundStructures.ABANDONED_CAMP_FLOWER_FOREST)),
                class_7059.method_41145(structures.method_46747(WildernessBoundStructures.ABANDONED_CAMP_FOREST)),
                class_7059.method_41145(structures.method_46747(WildernessBoundStructures.ABANDONED_CAMP_MEADOW)),
                class_7059.method_41145(structures.method_46747(WildernessBoundStructures.ABANDONED_CAMP_OLD_GROWTH_PINE_TAIGA)),
                class_7059.method_41145(structures.method_46747(WildernessBoundStructures.ABANDONED_CAMP_OLD_GROWTH_BIRCH_FOREST)),
                class_7059.method_41145(structures.method_46747(WildernessBoundStructures.ABANDONED_CAMP_OLD_GROWTH_SPRUCE_TAIGA)),
                class_7059.method_41145(structures.method_46747(WildernessBoundStructures.ABANDONED_CAMP_PALE_GARDEN)),
                class_7059.method_41145(structures.method_46747(WildernessBoundStructures.ABANDONED_CAMP_SAVANNA)),
                class_7059.method_41145(structures.method_46747(WildernessBoundStructures.ABANDONED_CAMP_SNOWY_TAIGA)),
                class_7059.method_41145(structures.method_46747(WildernessBoundStructures.ABANDONED_CAMP_SPARSE_JUNGLE)),
                class_7059.method_41145(structures.method_46747(WildernessBoundStructures.ABANDONED_CAMP_SWAMP)),
                class_7059.method_41145(structures.method_46747(WildernessBoundStructures.ABANDONED_CAMP_TAIGA)),
                class_7059.method_41145(structures.method_46747(WildernessBoundStructures.ABANDONED_CAMP_WINDSWEPT_FOREST)),
                class_7059.method_41145(structures.method_46747(WildernessBoundStructures.ABANDONED_CAMP_WOODED_BADLANDS))
            ),
            new class_6872(37, 8, class_6873.field_36421, 91231127)
        );
    });
}