package com.blackgear.vanillabackport.common.worldgen.placements;

import com.blackgear.platform.core.api.registrar.bootstrap.PlacedFeatureRegistrar;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import com.blackgear.vanillabackport.common.worldgen.features.TheGardenAwakensFeatures;
import com.blackgear.vanillabackport.core.VanillaBackport;
import net.minecraft.class_2902;
import net.minecraft.class_5321;
import net.minecraft.class_5450;
import net.minecraft.class_5925;
import net.minecraft.class_5934;
import net.minecraft.class_6792;
import net.minecraft.class_6793;
import net.minecraft.class_6796;
import net.minecraft.class_6799;
import net.minecraft.class_6817;
import net.minecraft.world.level.levelgen.placement.*;

public class TheGardenAwakensPlacements {
    public static final PlacedFeatureRegistrar REGISTRIES = PlacedFeatureRegistrar.create(VanillaBackport.NAMESPACE);
    
    // TREE PLACEMENTS
    public static final class_5321<class_6796> PALE_OAK_CHECKED = REGISTRIES.register("pale_oak_checked",
        TheGardenAwakensFeatures.PALE_OAK,
        class_6817.method_40365(ModBlocks.PALE_OAK_SAPLING.get()));
    public static final class_5321<class_6796> PALE_OAK_CREAKING_CHECKED = REGISTRIES.register("pale_oak_creaking_checked",
        TheGardenAwakensFeatures.PALE_OAK_CREAKING,
        class_6817.method_40365(ModBlocks.PALE_OAK_SAPLING.get()));
    
    // VEGETATION PLACEMENTS
    public static final class_5321<class_6796> FLOWER_PALE_GARDEN = REGISTRIES.register("flower_pale_garden",
        TheGardenAwakensFeatures.FLOWER_PALE_GARDEN,
        class_6799.method_39659(32),
        class_5450.method_39639(),
        class_6817.field_36078,
        class_6792.method_39614());
    public static final class_5321<class_6796> PALE_GARDEN_VEGETATION = REGISTRIES.register("pale_garden_vegetation",
        TheGardenAwakensFeatures.PALE_GARDEN_VEGETATION,
        class_6793.method_39623(16),
        class_5450.method_39639(),
        class_5934.method_39662(0),
        class_6817.field_36081,
        class_6792.method_39614());
    public static final class_5321<class_6796> PALE_GARDEN_FLOWERS = REGISTRIES.register("pale_garden_flowers",
        TheGardenAwakensFeatures.PALE_GARDEN_FLOWERS,
        class_6799.method_39659(8),
        class_5450.method_39639(),
        class_5925.method_39638(class_2902.class_2903.field_13203),
        class_6792.method_39614());
    public static final class_5321<class_6796> PALE_MOSS_PATCH = REGISTRIES.register("pale_moss_patch",
        TheGardenAwakensFeatures.PALE_MOSS_PATCH,
        class_6793.method_39623(1),
        class_5450.method_39639(),
        class_5925.method_39638(class_2902.class_2903.field_13203),
        class_6792.method_39614());
}