package com.blackgear.vanillabackport.common.worldgen.features;

import com.blackgear.platform.core.api.registrar.bootstrap.ConfiguredFeatureRegistrar;
import com.blackgear.vanillabackport.common.level.blocks.LeafLitterBlock;
import com.blackgear.vanillabackport.common.level.worldgen.features.FallenTreeConfiguration;
import com.blackgear.vanillabackport.common.level.worldgen.features.LeafLitterConfiguration;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import com.blackgear.vanillabackport.common.registries.worldgen.ModFeatures;
import com.blackgear.vanillabackport.common.level.worldgen.tree.decorators.AttachedToLogsDecorator;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.google.common.collect.ImmutableList;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2754;
import net.minecraft.class_2758;
import net.minecraft.class_2975;
import net.minecraft.class_3031;
import net.minecraft.class_3175;
import net.minecraft.class_4638;
import net.minecraft.class_4651;
import net.minecraft.class_4657;
import net.minecraft.class_4664;
import net.minecraft.class_5321;
import net.minecraft.class_6005;
import net.minecraft.class_6019;
import net.minecraft.class_6646;
import net.minecraft.class_6803;
import net.minecraft.class_6817;
import net.minecraft.class_8169;
import net.minecraft.world.level.levelgen.feature.configurations.*;
import java.util.List;

public class SpringToLifeFeatures {
    public static final ConfiguredFeatureRegistrar REGISTRIES = ConfiguredFeatureRegistrar.create(VanillaBackport.NAMESPACE);
    
    // VEGETATION FEATURES
    public static final class_5321<class_2975<?, ?>> PATCH_BUSH = REGISTRIES.register("patch_bush",
        class_3031.field_21220,
        (features, placements) ->
            new class_4638(
                25,
                5,
                3,
                class_6817.method_40366(
                    class_3031.field_13518,
                    new class_3175(
                        class_4651.method_38432(ModBlocks.BUSH.get())
                    )
                )
            ));
    public static final class_5321<class_2975<?, ?>> PATCH_FIREFLY_BUSH = REGISTRIES.register("patch_firefly_bush",
        class_3031.field_21220,
        (features, placements) ->
            new class_4638(
                20,
                4,
                3,
                class_6817.method_40366(
                    class_3031.field_13518,
                    new class_3175(
                        class_4651.method_38432(ModBlocks.FIREFLY_BUSH.get())
                    )
                )
            ));
    public static final class_5321<class_2975<?, ?>> WILDFLOWERS_BIRCH_FOREST = REGISTRIES.register("wildflowers_birch_forest",
        class_3031.field_21219,
        (features, placements) ->
            new class_4638(
                64,
                6,
                2,
                class_6817.method_40366(
                    class_3031.field_13518,
                    new class_3175(
                        new class_4657(flowerBedPatchBuilder(ModBlocks.WILDFLOWERS.get()))
                    )
                )
            ));
    public static final class_5321<class_2975<?, ?>> WILDFLOWERS_MEADOW = REGISTRIES.register("wildflowers_meadow",
        class_3031.field_21219,
        (features, placements) ->
            new class_4638(
                8,
                6,
                2,
                class_6817.method_40366(
                    class_3031.field_13518,
                    new class_3175(
                        new class_4657(flowerBedPatchBuilder(ModBlocks.WILDFLOWERS.get()))
                    )
                )
            ));
    public static final class_5321<class_2975<?, ?>> PATCH_DRY_GRASS = REGISTRIES.register("patch_dry_grass",
        class_3031.field_21220,
        (features, placements) ->
            grassPatch(
                new class_4657(
                    class_6005.<class_2680>method_34971()
                        .method_34975(ModBlocks.SHORT_DRY_GRASS.get().method_9564(), 1)
                        .method_34975(ModBlocks.TALL_DRY_GRASS.get().method_9564(), 1)
                        .method_34974()
                ),
                64
            ));
    public static final class_5321<class_2975<?, ?>> PATCH_LEAF_LITTER = REGISTRIES.register("patch_leaf_litter",
        class_3031.field_21220,
        (features, placements) ->
            class_6803.method_39703(
                32,
                class_6817.method_40367(
                    class_3031.field_13518,
                    new class_3175(new class_4657(leafLitterPatchBuilder(1, 3))),
                    class_6646.method_38878(
                        class_6646.field_35696,
                        class_6646.method_43288(class_2350.field_11033.method_10163(), class_2246.field_10219)
                    )
                )
            ));
    
    public static final class_5321<class_2975<?, ?>> LEAF_LITTER_SPARSE = REGISTRIES.register("leaf_litter_sparse",
        ModFeatures.LEAF_LITTER.get(),
        (features, placements) -> new LeafLitterConfiguration(96, 4, 2, new class_4657(leafLitterPatchBuilder(1, 3))));
    public static final class_5321<class_2975<?, ?>> LEAF_LITTER_THICK = REGISTRIES.register("leaf_litter_thick",
        ModFeatures.LEAF_LITTER.get(),
        (features, placements) -> new LeafLitterConfiguration(150, 2, 2, new class_4657(leafLitterPatchBuilder(1, 4))));
    
    public static final class_5321<class_2975<?, ?>> CACTUS_FLOWER = REGISTRIES.register("cactus_flower",
        ModFeatures.CACTUS_FLOWER.get());

    // TREE FEATURES
    public static final class_5321<class_2975<?, ?>> FALLEN_OAK_TREE = REGISTRIES.register("fallen_oak_tree",
        ModFeatures.FALLEN_TREE.get(),
        (features, placements) -> createFallenOak().build());
    public static final class_5321<class_2975<?, ?>> FALLEN_BIRCH_TREE = REGISTRIES.register("fallen_birch_tree",
        ModFeatures.FALLEN_TREE.get(),
        (features, placements) -> createFallenBirch(8).build());
    public static final class_5321<class_2975<?, ?>> FALLEN_SUPER_BIRCH_TREE = REGISTRIES.register("fallen_super_birch_tree",
        ModFeatures.FALLEN_TREE.get(),
        (features, placements) -> createFallenBirch(15).build());
    public static final class_5321<class_2975<?, ?>> FALLEN_JUNGLE_TREE = REGISTRIES.register("fallen_jungle_tree",
        ModFeatures.FALLEN_TREE.get(),
        (features, placements) -> createFallenJungle().build());
    public static final class_5321<class_2975<?, ?>> FALLEN_SPRUCE_TREE = REGISTRIES.register("fallen_spruce_tree",
        ModFeatures.FALLEN_TREE.get(),
        (features, placements) -> createFallenSpruce().build());

    private static class_4638 grassPatch(class_4651 provider, int tries) {
        return class_6803.method_39703(tries, class_6817.method_40366(class_3031.field_13518, new class_3175(provider)));
    }

    private static class_6005.class_6006<class_2680> flowerBedPatchBuilder(class_2248 block) {
        return segmentedBlockPatchBuilder(block, 1, 4, class_8169.field_42765, class_8169.field_42764);
    }

    private static class_6005.class_6006<class_2680> leafLitterPatchBuilder(int min, int max) {
        return segmentedBlockPatchBuilder(ModBlocks.LEAF_LITTER.get(), min, max, LeafLitterBlock.AMOUNT, class_8169.field_42764);
    }

    private static class_6005.class_6006<class_2680> segmentedBlockPatchBuilder(
        class_2248 block,
        int min,
        int max,
        class_2758 amount,
        class_2754<class_2350> facing
    ) {
        class_6005.class_6006<class_2680> builder = class_6005.method_34971();

        for (int i = min; i <= max; i++) {
            for (class_2350 direction : class_2350.class_2353.field_11062) {
                builder.method_34975(block.method_9564().method_11657(amount, i).method_11657(facing, direction), 1);
            }
        }

        return builder;
    }

    private static FallenTreeConfiguration.FallenTreeConfigurationBuilder createFallenOak() {
        return createFallenTrees(class_2246.field_10431, 4, 7).stumpDecorator(class_4664.field_24965);
    }

    private static FallenTreeConfiguration.FallenTreeConfigurationBuilder createFallenBirch(int i) {
        return createFallenTrees(class_2246.field_10511, 5, i);
    }

    private static FallenTreeConfiguration.FallenTreeConfigurationBuilder createFallenJungle() {
        return createFallenTrees(class_2246.field_10306, 4, 11).stumpDecorator(class_4664.field_24965);
    }

    private static FallenTreeConfiguration.FallenTreeConfigurationBuilder createFallenSpruce() {
        return createFallenTrees(class_2246.field_10037, 6, 10);
    }

    private static FallenTreeConfiguration.FallenTreeConfigurationBuilder createFallenTrees(class_2248 block, int minLength, int maxLength) {
        return new FallenTreeConfiguration.FallenTreeConfigurationBuilder(class_4651.method_38432(block), class_6019.method_35017(minLength, maxLength))
            .logDecorator(
                new AttachedToLogsDecorator(
                    0.1F,
                    new class_4657(
                        class_6005.<class_2680>method_34971()
                            .method_34975(class_2246.field_10559.method_9564(), 2)
                            .method_34975(class_2246.field_10251.method_9564(), 1)
                    ),
                    List.of(class_2350.field_11036)
                )
            );
    }
}