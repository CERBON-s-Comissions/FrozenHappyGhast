package com.blackgear.vanillabackport.common.worldgen.biomes;

import com.blackgear.vanillabackport.common.worldgen.placements.WildernessBoundPlacements;
import com.blackgear.vanillabackport.core.mixin.common.access.OverworldBiomesAccessor;
import net.minecraft.class_1143;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1959;
import net.minecraft.class_2893;
import net.minecraft.class_2922;
import net.minecraft.class_3417;
import net.minecraft.class_3864;
import net.minecraft.class_4763;
import net.minecraft.class_5483;
import net.minecraft.class_5485;
import net.minecraft.class_6796;
import net.minecraft.class_7871;

public class WildernessBoundBiomes {
    public static class_1959 dappledForest(class_7871<class_6796> features, class_7871<class_2922<?>> carvers) {
        class_5483.class_5496 mobs = new class_5483.class_5496();
        class_3864.method_30580(mobs);
        class_3864.method_30581(mobs);
        mobs.method_31011(class_1311.field_6294, new class_5483.class_1964(class_1299.field_6140, 4, 2, 4));
        mobs.method_31011(class_1311.field_6294, new class_5483.class_1964(class_1299.field_17943, 4, 2, 4));
        
        class_5485.class_5495 generation = new class_5485.class_5495(features, carvers);
        OverworldBiomesAccessor.callGlobalOverworldGeneration(generation);
        class_3864.method_38568(generation);
        class_3864.method_17010(generation);
        generation.method_30992(class_2893.class_2895.field_13178, WildernessBoundPlacements.TREES_DAPPLED_FOREST);
        generation.method_30992(class_2893.class_2895.field_13178, WildernessBoundPlacements.BROWN_MUSHROOM_DAPPLED_FOREST);
        generation.method_30992(class_2893.class_2895.field_13178, WildernessBoundPlacements.PATCH_RED_SHRUB);
        class_3864.method_16971(generation);
        
        return new class_1959.class_1960()
            .method_48164(true)
            .method_8747(0.6F)
            .method_8727(0.6F)
            .method_24379(
                new class_4763.class_4764()
                    .method_24395(3625300)
                    .method_24397(3625300)
                    .method_30820(8168447)
                    .method_24392(13424866)
                    .method_30822(14641191)
                    .method_30821(15109680)
                    .method_27346(class_1143.method_27283(class_3417.field_44693))
                    .method_24391()
            )
            .method_30974(mobs.method_31007())
            .method_30973(generation.method_46671())
            .method_30972();
    }
}
