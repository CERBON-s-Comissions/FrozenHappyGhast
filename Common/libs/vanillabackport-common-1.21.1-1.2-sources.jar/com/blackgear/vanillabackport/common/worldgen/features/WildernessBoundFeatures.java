package com.blackgear.vanillabackport.common.worldgen.features;

import com.blackgear.platform.core.api.registrar.bootstrap.ConfiguredFeatureRegistrar;
import com.blackgear.vanillabackport.common.level.worldgen.features.FallenTreeConfiguration;
import com.blackgear.vanillabackport.common.level.worldgen.features.WeightedRandomFeatureConfiguration;
import com.blackgear.vanillabackport.common.level.worldgen.tree.decorators.AttachedToLogsDecorator;
import com.blackgear.vanillabackport.common.level.worldgen.tree.decorators.ShelfMushroomDecorator;
import com.blackgear.vanillabackport.common.level.worldgen.tree.foliage.PoplarFoliagePlacer;
import com.blackgear.vanillabackport.common.level.worldgen.tree.trunk.PoplarTrunkPlacer;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import com.blackgear.vanillabackport.common.registries.worldgen.ModFeatures;
import com.blackgear.vanillabackport.common.worldgen.placements.WildernessBoundPlacements;
import com.blackgear.vanillabackport.core.VanillaBackport;
import java.util.List;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2975;
import net.minecraft.class_3031;
import net.minecraft.class_3175;
import net.minecraft.class_4643;
import net.minecraft.class_4651;
import net.minecraft.class_5204;
import net.minecraft.class_5321;
import net.minecraft.class_6005;
import net.minecraft.class_6016;
import net.minecraft.class_6017;
import net.minecraft.class_6019;
import net.minecraft.class_6642;
import net.minecraft.class_6796;
import net.minecraft.class_6818;
import net.minecraft.class_6880;

public class WildernessBoundFeatures {
    public static final ConfiguredFeatureRegistrar REGISTRIES = ConfiguredFeatureRegistrar.create(VanillaBackport.NAMESPACE);
    
    public static final class_5321<class_2975<?, ?>> RED_POPLAR = REGISTRIES.register("red_poplar",
        class_3031.field_24134,
        (features, placements) -> createPoplar(ModBlocks.RED_POPLAR_LEAVES.get()).method_27376(List.of(new ShelfMushroomDecorator(0.4F))).method_23445());
    public static final class_5321<class_2975<?, ?>> ORANGE_POPLAR = REGISTRIES.register("orange_poplar",
        class_3031.field_24134,
        (features, placements) -> createPoplar(ModBlocks.ORANGE_POPLAR_LEAVES.get()).method_27376(List.of(new ShelfMushroomDecorator(0.4F))).method_23445());
    public static final class_5321<class_2975<?, ?>> YELLOW_POPLAR = REGISTRIES.register("yellow_poplar",
        class_3031.field_24134,
        (features, placements) -> createPoplar(ModBlocks.YELLOW_POPLAR_LEAVES.get()).method_27376(List.of(new ShelfMushroomDecorator(0.4F))).method_23445());
    
    public static final class_5321<class_2975<?, ?>> FALLEN_POPLAR_TREE = REGISTRIES.register("fallen_poplar_tree",
        ModFeatures.FALLEN_TREE.get(),
        (features, placements) -> createFallenPoplar().build());
    
    public static final class_5321<class_2975<?, ?>> RED_SHRUB = REGISTRIES.register("red_shrub",
        class_3031.field_13518,
        (features, placements) -> new class_3175(class_4651.method_38432(ModBlocks.RED_SHRUB.get())));
    public static final class_5321<class_2975<?, ?>> BROWN_MUSHROOM = REGISTRIES.register("brown_mushroom",
        class_3031.field_13518,
        (features, placements) -> new class_3175(class_4651.method_38432(class_2246.field_10251)));
    
    public static final class_5321<class_2975<?, ?>> TREES_DAPPLED_FOREST = REGISTRIES.register("trees_dappled_forest",
        ModFeatures.WEIGHTED_RANDOM_SELECTOR.get(),
        (features, placements) -> new WeightedRandomFeatureConfiguration(
            class_6005.<class_6880<class_6796>>method_34971()
                .method_34975(placements.method_46747(WildernessBoundPlacements.RED_POPLAR), 200)
                .method_34975(placements.method_46747(WildernessBoundPlacements.ORANGE_POPLAR), 240)
                .method_34975(placements.method_46747(WildernessBoundPlacements.YELLOW_POPLAR), 90)
                .method_34975(placements.method_46747(class_6818.field_36094), 27)
                .method_34974()
        ));
    
    public static FallenTreeConfiguration.FallenTreeConfigurationBuilder createFallenPoplar() {
        return new FallenTreeConfiguration.FallenTreeConfigurationBuilder(class_4651.method_38432(ModBlocks.POPLAR_LOG.get()), class_6019.method_35017(4, 7))
            .logDecorator(new AttachedToLogsDecorator(0.1F, class_4651.method_38432(class_2246.field_10251), List.of(class_2350.field_11036)))
            .logDecorator(new ShelfMushroomDecorator(0.8F));
    }
    
    private static class_4643.class_4644 createPoplar(class_2248 leafBlock) {
        return new class_4643.class_4644(
            class_4651.method_38432(ModBlocks.POPLAR_LOG.get()),
            new PoplarTrunkPlacer(7, 4, 0, class_6016.method_34998(4), class_6019.method_35017(1, 4)),
            class_4651.method_38432(leafBlock),
            new PoplarFoliagePlacer(
                new class_6642(class_6005.<class_6017>method_34971()
                    .method_34975(class_6016.method_34998(5), 5)
                    .method_34975(class_6016.method_34998(6), 5)
                    .method_34975(class_6016.method_34998(7), 1)
                    .method_34975(class_6016.method_34998(8), 1)
                    .method_34974()),
                class_6016.method_34998(0),
                class_6019.method_35017(5, 6),
                0.15F
            ),
            new class_5204(1, 0, 2)
        ).method_27374();
    }
}