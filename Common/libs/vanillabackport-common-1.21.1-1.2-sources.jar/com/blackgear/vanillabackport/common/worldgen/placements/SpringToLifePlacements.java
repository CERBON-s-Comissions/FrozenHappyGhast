package com.blackgear.vanillabackport.common.worldgen.placements;

import com.blackgear.platform.core.api.registrar.bootstrap.PlacedFeatureRegistrar;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import com.blackgear.vanillabackport.common.worldgen.features.SpringToLifeFeatures;
import com.blackgear.vanillabackport.core.VanillaBackport;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2902;
import net.minecraft.class_3003;
import net.minecraft.class_3612;
import net.minecraft.class_5321;
import net.minecraft.class_5450;
import net.minecraft.class_5925;
import net.minecraft.class_5934;
import net.minecraft.class_6646;
import net.minecraft.class_6658;
import net.minecraft.class_6792;
import net.minecraft.class_6793;
import net.minecraft.class_6796;
import net.minecraft.class_6799;
import net.minecraft.class_6817;
import net.minecraft.class_6819;
import net.minecraft.world.level.levelgen.placement.*;

public class SpringToLifePlacements {
    public static final PlacedFeatureRegistrar REGISTRIES = PlacedFeatureRegistrar.create(VanillaBackport.NAMESPACE);
    
    // VEGETATION PLACEMENTS
    public static final class_5321<class_6796> PATCH_BUSH = REGISTRIES.register("patch_bush",
        SpringToLifeFeatures.PATCH_BUSH,
        class_6799.method_39659(4),
        class_5450.method_39639(),
        class_6817.field_36078,
        class_6792.method_39614());
    public static final class_5321<class_6796> PATCH_FIREFLY_BUSH_NEAR_WATER = REGISTRIES.register("patch_firefly_bush_near_water",
        SpringToLifeFeatures.PATCH_FIREFLY_BUSH,
        class_6793.method_39623(2),
        class_5450.method_39639(),
        class_5925.method_39638(class_2902.class_2903.field_13203),
        class_6792.method_39614(),
        nearWaterPredicate(ModBlocks.FIREFLY_BUSH.get()));
    public static final class_5321<class_6796> PATCH_FIREFLY_BUSH_NEAR_WATER_SWAMP = REGISTRIES.register("patch_firefly_bush_near_water_swamp",
        SpringToLifeFeatures.PATCH_FIREFLY_BUSH,
        class_6793.method_39623(3),
        class_5450.method_39639(),
        class_6817.field_36078,
        class_6792.method_39614(),
        nearWaterPredicate(ModBlocks.FIREFLY_BUSH.get()));
    public static final class_5321<class_6796> PATCH_FIREFLY_BUSH_SWAMP = REGISTRIES.register("patch_firefly_bush_swamp",
        SpringToLifeFeatures.PATCH_FIREFLY_BUSH,
        class_6799.method_39659(8),
        class_5450.method_39639(),
        class_6817.field_36078,
        class_6792.method_39614());
    public static final class_5321<class_6796> WILDFLOWERS_BIRCH_FOREST = REGISTRIES.register("wildflowers_birch_forest",
        SpringToLifeFeatures.WILDFLOWERS_BIRCH_FOREST,
        class_6793.method_39623(3),
        class_6799.method_39659(2),
        class_5450.method_39639(),
        class_6817.field_36078,
        class_6792.method_39614());
    public static final class_5321<class_6796> WILDFLOWERS_MEADOW = REGISTRIES.register("wildflowers_meadow",
        SpringToLifeFeatures.WILDFLOWERS_MEADOW,
        class_3003.method_39642(-0.8, 5, 10),
        class_5450.method_39639(),
        class_6817.field_36078,
        class_6792.method_39614());
    public static final class_5321<class_6796> PATCH_DRY_GRASS_BADLANDS = REGISTRIES.register("patch_dry_grass_badlands",
        SpringToLifeFeatures.PATCH_DRY_GRASS,
        class_6799.method_39659(6),
        class_5450.method_39639(),
        class_6817.field_36078,
        class_6792.method_39614());
    public static final class_5321<class_6796> PATCH_DRY_GRASS_DESERT = REGISTRIES.register("patch_dry_grass_desert",
        SpringToLifeFeatures.PATCH_DRY_GRASS,
        class_6799.method_39659(3),
        class_5450.method_39639(),
        class_6817.field_36078,
        class_6792.method_39614());
    public static final class_5321<class_6796> PATCH_LEAF_LITTER = REGISTRIES.register("patch_leaf_litter",
        SpringToLifeFeatures.PATCH_LEAF_LITTER,
        class_6819.method_39738(2));
    public static final class_5321<class_6796> LEAF_LITTER_SPARSE = REGISTRIES.register("leaf_litter_sparse",
        SpringToLifeFeatures.LEAF_LITTER_SPARSE,
        class_5934.method_39662(0),
        class_6817.field_36081,
        class_6792.method_39614());
    public static final class_5321<class_6796> LEAF_LITTER_THICK = REGISTRIES.register("leaf_litter_thick",
        SpringToLifeFeatures.LEAF_LITTER_THICK,
        class_5934.method_39662(0),
        class_6817.field_36081,
        class_6792.method_39614());
    public static final class_5321<class_6796> CACTUS_FLOWER = REGISTRIES.register("cactus_flower",
        SpringToLifeFeatures.CACTUS_FLOWER,
        class_5934.method_39662(0),
        class_6817.field_36081,
        class_6792.method_39614());

    // TREE PLACEMENTS
    public static final class_5321<class_6796> FALLEN_OAK_TREE = REGISTRIES.register("fallen_oak_tree",
        SpringToLifeFeatures.FALLEN_OAK_TREE,
        class_6817.method_40365(class_2246.field_10394));
    public static final class_5321<class_6796> FALLEN_BIRCH_TREE = REGISTRIES.register("fallen_birch_tree",
        SpringToLifeFeatures.FALLEN_BIRCH_TREE,
        class_6817.method_40365(class_2246.field_10575));
    public static final class_5321<class_6796> FALLEN_SUPER_BIRCH_TREE = REGISTRIES.register("fallen_super_birch_tree",
        SpringToLifeFeatures.FALLEN_SUPER_BIRCH_TREE,
        class_6817.method_40365(class_2246.field_10575));
    public static final class_5321<class_6796> FALLEN_JUNGLE_TREE = REGISTRIES.register("fallen_jungle_tree",
        SpringToLifeFeatures.FALLEN_JUNGLE_TREE,
        class_6817.method_40365(class_2246.field_10276));
    public static final class_5321<class_6796> FALLEN_SPRUCE_TREE = REGISTRIES.register("fallen_spruce_tree",
        SpringToLifeFeatures.FALLEN_SPRUCE_TREE,
        class_6817.method_40365(class_2246.field_10217));

    public static final class_5321<class_6796> PLACED_FALLEN_OAK_TREE = REGISTRIES.register("placed_fallen_oak_tree",
        SpringToLifeFeatures.FALLEN_OAK_TREE,
        class_6819.method_39741(class_6799.method_39659(80), class_2246.field_10394));

    public static final class_5321<class_6796> PLACED_RARE_FALLEN_BIRCH_TREE = REGISTRIES.register("placed_rare_fallen_birch_tree",
        SpringToLifeFeatures.FALLEN_BIRCH_TREE,
        class_6819.method_39741(class_6799.method_39659(400), class_2246.field_10575));
    public static final class_5321<class_6796> PLACED_FALLEN_BIRCH_TREE = REGISTRIES.register("placed_fallen_birch_tree",
        SpringToLifeFeatures.FALLEN_BIRCH_TREE,
        class_6819.method_39741(class_6799.method_39659(80), class_2246.field_10575));

    public static final class_5321<class_6796> PLACED_FALLEN_SUPER_BIRCH_TREE = REGISTRIES.register("placed_fallen_super_birch_tree",
        SpringToLifeFeatures.FALLEN_SUPER_BIRCH_TREE,
        class_6819.method_39741(class_6799.method_39659(160), class_2246.field_10575));

    public static final class_5321<class_6796> PLACED_FALLEN_JUNGLE_TREE = REGISTRIES.register("placed_fallen_jungle_tree",
        SpringToLifeFeatures.FALLEN_JUNGLE_TREE,
        class_6819.method_39741(class_6799.method_39659(80), class_2246.field_10276));

    public static final class_5321<class_6796> PLACED_FALLEN_SPRUCE_TREE = REGISTRIES.register("placed_fallen_spruce_tree",
        SpringToLifeFeatures.FALLEN_SPRUCE_TREE,
        class_6819.method_39741(class_6799.method_39659(80), class_2246.field_10217));
    public static final class_5321<class_6796> PLACED_RARE_FALLEN_SPRUCE_TREE = REGISTRIES.register("placed_rare_fallen_spruce_tree",
        SpringToLifeFeatures.FALLEN_SPRUCE_TREE,
        class_6819.method_39741(class_6799.method_39659(120), class_2246.field_10217));

    public static class_6658 nearWaterPredicate(class_2248 block) {
        return class_6658.method_39618(
            class_6646.method_38882(
                class_6646.field_35696,
                class_6646.method_39009(block.method_9564(), class_2338.field_10980),
                class_6646.method_38887(
                    class_6646.method_43289(new class_2338(1, -1, 0), class_3612.field_15910, class_3612.field_15909),
                    class_6646.method_43289(new class_2338(-1, -1, 0), class_3612.field_15910, class_3612.field_15909),
                    class_6646.method_43289(new class_2338(0, -1, 1), class_3612.field_15910, class_3612.field_15909),
                    class_6646.method_43289(new class_2338(0, -1, -1), class_3612.field_15910, class_3612.field_15909)
                )
            )
        );
    }
}