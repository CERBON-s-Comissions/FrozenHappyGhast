package com.blackgear.vanillabackport.common.worldgen.features;

import com.blackgear.platform.core.api.registrar.bootstrap.ConfiguredFeatureRegistrar;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import com.blackgear.vanillabackport.common.worldgen.placements.TheGardenAwakensPlacements;
import com.blackgear.vanillabackport.common.level.worldgen.tree.decorators.CreakingHeartDecorator;
import com.blackgear.vanillabackport.common.level.worldgen.tree.decorators.PaleMossDecorator;
import com.blackgear.vanillabackport.core.VanillaBackport;
import net.minecraft.class_2246;
import net.minecraft.class_2680;
import net.minecraft.class_2975;
import net.minecraft.class_3031;
import net.minecraft.class_3141;
import net.minecraft.class_3175;
import net.minecraft.class_3226;
import net.minecraft.class_3481;
import net.minecraft.class_4638;
import net.minecraft.class_4643;
import net.minecraft.class_4651;
import net.minecraft.class_4657;
import net.minecraft.class_5203;
import net.minecraft.class_5206;
import net.minecraft.class_5211;
import net.minecraft.class_5321;
import net.minecraft.class_5927;
import net.minecraft.class_5932;
import net.minecraft.class_6005;
import net.minecraft.class_6016;
import net.minecraft.class_6019;
import net.minecraft.class_6803;
import net.minecraft.class_6817;
import net.minecraft.world.level.levelgen.feature.configurations.*;
import java.util.List;
import java.util.OptionalInt;

public class TheGardenAwakensFeatures {
    public static final ConfiguredFeatureRegistrar REGISTRIES = ConfiguredFeatureRegistrar.create(VanillaBackport.NAMESPACE);
    
    // TREE FEATURES
    
    public static final class_5321<class_2975<?, ?>> PALE_OAK = REGISTRIES.register("pale_oak", class_3031.field_24134,
        (features, placements) ->
            new class_4643.class_4644(
                class_4651.method_38432(ModBlocks.PALE_OAK_LOG.get()),
                new class_5211(6, 2, 1),
                class_4651.method_38432(ModBlocks.PALE_OAK_LEAVES.get()),
                new class_5206(class_6016.method_34998(0), class_6016.method_34998(0)),
                new class_5203(1, 1, 0, 1, 2, OptionalInt.empty())
            )
            .method_27376(List.of(new PaleMossDecorator(0.15F, 0.4F, 0.8F)))
            .method_27374()
            .method_23445());
    public static final class_5321<class_2975<?, ?>> PALE_OAK_BONEMEAL = REGISTRIES.register("pale_oak_bonemeal", class_3031.field_24134,
        (features, placements) ->
            new class_4643.class_4644(
                class_4651.method_38432(ModBlocks.PALE_OAK_LOG.get()),
                new class_5211(6, 2, 1),
                class_4651.method_38432(ModBlocks.PALE_OAK_LEAVES.get()),
                new class_5206(class_6016.method_34998(0), class_6016.method_34998(0)),
                new class_5203(1, 1, 0, 1, 2, OptionalInt.empty())
            )
            .method_27374()
            .method_23445());
    public static final class_5321<class_2975<?, ?>> PALE_OAK_CREAKING = REGISTRIES.register("pale_oak_creaking", class_3031.field_24134,
        (features, placements) ->
            new class_4643.class_4644(
                class_4651.method_38432(ModBlocks.PALE_OAK_LOG.get()),
                new class_5211(6, 2, 1),
                class_4651.method_38432(ModBlocks.PALE_OAK_LEAVES.get()),
                new class_5206(class_6016.method_34998(0), class_6016.method_34998(0)),
                new class_5203(1, 1, 0, 1, 2, OptionalInt.empty())
            )
            .method_27376(List.of(
                new PaleMossDecorator(0.15F, 0.4F, 0.8F),
                new CreakingHeartDecorator(1.0F)
            ))
            .method_27374()
            .method_23445());
    
    // VEGETATION FEATURES
    
    public static final class_5321<class_2975<?, ?>> FLOWER_PALE_GARDEN = REGISTRIES.register("flower_pale_garden", class_3031.field_21219,
        (features, placements) ->
            new class_4638(
                1,
                0,
                0,
                class_6817.method_40366(
                    class_3031.field_13518,
                    new class_3175(class_4651.method_38432(ModBlocks.CLOSED_EYEBLOSSOM.get()))
                )
            ));
    public static final class_5321<class_2975<?, ?>> PALE_GARDEN_FLOWERS = REGISTRIES.register("pale_garden_flowers", class_3031.field_21220,
        (features, placements) ->
            class_6803.method_39704(
                class_3031.field_13518,
                new class_3175(class_4651.method_38432(ModBlocks.CLOSED_EYEBLOSSOM.get()))
            ));
    public static final class_5321<class_2975<?, ?>> PALE_GARDEN_VEGETATION = REGISTRIES.register("pale_garden_vegetation", class_3031.field_13593,
        (features, placements) ->
            new class_3141(
                List.of(
                    new class_3226(placements.method_46747(TheGardenAwakensPlacements.PALE_OAK_CREAKING_CHECKED), 0.1F),
                    new class_3226(placements.method_46747(TheGardenAwakensPlacements.PALE_OAK_CHECKED), 0.9F)
                ),
                placements.method_46747(TheGardenAwakensPlacements.PALE_OAK_CHECKED)
            ));
    public static final class_5321<class_2975<?, ?>> PALE_MOSS_VEGETATION = REGISTRIES.register("pale_moss_vegetation", class_3031.field_13518,
        (features, placements) ->
            new class_3175(
                new class_4657(
                    class_6005.<class_2680>method_34971()
                        .method_34975(ModBlocks.PALE_MOSS_CARPET.get().method_9564(), 25)
                        .method_34975(class_2246.field_10479.method_9564(), 25)
                        .method_34975(class_2246.field_10214.method_9564(), 10)
                )
            ));
    public static final class_5321<class_2975<?, ?>> PALE_MOSS_PATCH = REGISTRIES.register("pale_moss_patch", class_3031.field_29250,
        (features, placements) ->
            new class_5927(
                class_3481.field_28622,
                class_4651.method_38432(ModBlocks.PALE_MOSS_BLOCK.get()),
                class_6817.method_40369(features.method_46747(PALE_MOSS_VEGETATION)),
                class_5932.field_29314,
                class_6016.method_34998(1),
                0.0F,
                5,
                0.3F,
                class_6019.method_35017(2, 4),
                0.75F
            ));
    public static final class_5321<class_2975<?, ?>> PALE_MOSS_PATCH_BONEMEAL = REGISTRIES.register("pale_moss_patch_bonemeal", class_3031.field_29250,
        (features, placements) ->
            new class_5927(
                class_3481.field_28622,
                class_4651.method_38432(ModBlocks.PALE_MOSS_BLOCK.get()),
                class_6817.method_40369(features.method_46747(PALE_MOSS_VEGETATION)),
                class_5932.field_29314,
                class_6016.method_34998(1),
                0.0F,
                5,
                0.6F,
                class_6019.method_35017(1, 2),
                0.75F
            ));
}