package com.blackgear.vanillabackport.common.worldgen.biomes;

import com.blackgear.vanillabackport.client.registries.ModSoundEvents;
import com.blackgear.vanillabackport.common.worldgen.placements.ChaosCubedPlacements;
import com.blackgear.vanillabackport.core.mixin.common.access.OverworldBiomesAccessor;
import net.minecraft.class_1143;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1959;
import net.minecraft.class_2893;
import net.minecraft.class_2922;
import net.minecraft.class_3532;
import net.minecraft.class_3864;
import net.minecraft.class_4763;
import net.minecraft.class_5483;
import net.minecraft.class_5485;
import net.minecraft.class_6796;
import net.minecraft.class_7871;

public class ChaosCubedBiomes {
    public static int calculateSkyColor(float temperature) {
        float temp = temperature / 3.0F;
        temp = class_3532.method_15363(temp, -1.0F, 1.0F);
        return class_3532.method_15369(0.62222224F - temp * 0.05F, 0.5F + temp * 0.1F, 1.0F);
    }

    public static class_1959 sulfurCaves(class_7871<class_6796> features, class_7871<class_2922<?>> carvers) {
        class_5483.class_5496 mobs = new class_5483.class_5496();
        mobs.method_31011(class_1311.field_6303, new class_5483.class_1964(class_1299.field_6108, 10, 8, 8));
        mobs.method_31011(class_1311.field_6302, new class_5483.class_1964(class_1299.field_6046, 50, 2, 2));
        mobs.method_31011(class_1311.field_6302, new class_5483.class_1964(class_1299.field_6137, 50, 2, 2));
        mobs.method_31011(class_1311.field_6302, new class_5483.class_1964(class_1299.field_6069, 25, 1, 1));
        mobs.method_31011(class_1311.field_6302, new class_5483.class_1964(class_1299.field_6084, 20, 1, 1));
        mobs.method_31011(class_1311.field_6302, new class_5483.class_1964(class_1299.field_6051, 50, 2, 2));
        mobs.method_31011(class_1311.field_6302, new class_5483.class_1964(class_1299.field_6091, 10, 1, 1));
        mobs.method_31011(class_1311.field_6302, new class_5483.class_1964(class_1299.field_6145, 1, 1, 1));
        mobs.method_31011(class_1311.field_6302, new class_5483.class_1964(class_1299.field_6054, 1, 1, 1));

        class_5485.class_5495 generation = new class_5485.class_5495(features, carvers);
        OverworldBiomesAccessor.callGlobalOverworldGeneration(generation);
        class_3864.method_16981(generation);
        class_3864.method_38568(generation);
        class_3864.method_17010(generation);
        generation.method_30992(class_2893.class_2895.field_25186, ChaosCubedPlacements.SULFUR_POOL);
        generation.method_30992(class_2893.class_2895.field_13177, ChaosCubedPlacements.SULFUR_SPIKE_CLUSTER);
        generation.method_30992(class_2893.class_2895.field_13177, ChaosCubedPlacements.SULFUR_SPIKE);

        return new class_1959.class_1960()
            .method_48164(true)
            .method_8747(0.8F)
            .method_8727(0.4F)
            .method_24379(
                new class_4763.class_4764()
                    .method_24395(-13320311)
                    .method_24397(-15248324)
                    .method_30820(calculateSkyColor(0.8F))
                    .method_24392(12638463)
                    .method_30822(11249231)
                    .method_27346(class_1143.method_27283(ModSoundEvents.MUSIC_BIOME_SULFUR_CAVES))
                    .method_24391()
            )
            .method_30974(mobs.method_31007())
            .method_30973(generation.method_46671())
            .method_30972();
    }
}
