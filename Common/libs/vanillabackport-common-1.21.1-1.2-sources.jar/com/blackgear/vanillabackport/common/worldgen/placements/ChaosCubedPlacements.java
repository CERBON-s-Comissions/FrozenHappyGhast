package com.blackgear.vanillabackport.common.worldgen.placements;

import com.blackgear.platform.core.api.registrar.bootstrap.PlacedFeatureRegistrar;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import com.blackgear.vanillabackport.common.worldgen.features.ChaosCubedFeatures;
import com.blackgear.vanillabackport.core.VanillaBackport;
import net.minecraft.class_2350;
import net.minecraft.class_5321;
import net.minecraft.class_5450;
import net.minecraft.class_6016;
import net.minecraft.class_6019;
import net.minecraft.class_6646;
import net.minecraft.class_6658;
import net.minecraft.class_6728;
import net.minecraft.class_6732;
import net.minecraft.class_6792;
import net.minecraft.class_6793;
import net.minecraft.class_6794;
import net.minecraft.class_6796;
import net.minecraft.class_6817;
import net.minecraft.world.level.levelgen.placement.*;

public class ChaosCubedPlacements {
    public static final PlacedFeatureRegistrar REGISTRIES = PlacedFeatureRegistrar.create(VanillaBackport.NAMESPACE);

    public static final class_5321<class_6796> SULFUR_POOL = REGISTRIES.register("sulfur_pool",
        ChaosCubedFeatures.SULFUR_POOL,
        class_6793.method_39623(256),
        class_5450.method_39639(),
        class_6817.field_36086,
        class_6658.method_39618(class_6646.method_39585()),
        class_6794.method_39628(class_2350.field_11036, class_6646.field_35696, 32),
        class_6732.method_39656(class_6016.method_34998(-1)),
        class_6658.method_39618(class_6646.method_43290(ModBlocks.SULFUR.get())),
        class_6792.method_39614());
    public static final class_5321<class_6796> ROOTED_SULFUR_SPRING = REGISTRIES.register("rooted_sulfur_spring",
        ChaosCubedFeatures.ROOTED_SULFUR_SPRING,
        class_6793.method_39624(class_6019.method_35017(1, 2)),
        class_5450.method_39639(),
        class_6817.field_36086,
        class_6794.method_39629(class_2350.field_11036, class_6646.method_39585(), class_6646.field_35696, 12),
        class_6732.method_39656(class_6016.method_34998(-1)),
        class_6792.method_39614());
    public static final class_5321<class_6796> SULFUR_SPIKE_CLUSTER = REGISTRIES.register("sulfur_spike_cluster",
        ChaosCubedFeatures.SULFUR_SPIKE_CLUSTER,
        class_6793.method_39624(class_6019.method_35017(48, 96)),
        class_5450.method_39639(),
        class_6817.field_36086,
        class_6792.method_39614());
    public static final class_5321<class_6796> SULFUR_SPIKE = REGISTRIES.register("sulfur_spike",
        ChaosCubedFeatures.SULFUR_SPIKE,
        class_6793.method_39624(class_6019.method_35017(192, 256)),
        class_5450.method_39639(),
        class_6817.field_36086,
        class_6793.method_39624(class_6019.method_35017(1, 5)),
        class_6732.method_39657(class_6728.method_39156(0.0F, 3.0F, -10, 10), class_6728.method_39156(0.0F, 0.6F, -2, 2)),
        class_6792.method_39614());
}