package com.blackgear.vanillabackport.common.worldgen;

import com.blackgear.platform.common.worldgen.modifier.BiomeContext;
import com.blackgear.platform.common.worldgen.modifier.BiomeWriter;
import com.blackgear.platform.common.worldgen.modifier.FeatureManager;
import com.blackgear.vanillabackport.common.registries.entities.ModEntityTypes;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.blackgear.vanillabackport.core.data.tags.ModBiomeTags;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_5483;
import net.minecraft.class_6908;

public class MountsOfMayhemFeatureManager extends FeatureManager {
    public MountsOfMayhemFeatureManager(BiomeContext context, BiomeWriter writer) {
        super(context, writer);
    }

    @Override
    public void bootstrap() {
        this.addIf(VanillaBackport.COMMON_CONFIG.hasParchedSkeletons.get(), (context, writer) -> {
            this.getOrCreateBiomeBuilder(class_6908.field_36520)
                .add(() -> writer.addSpawn(class_1311.field_6302, new class_5483.class_1964(ModEntityTypes.PARCHED.get(), 50, 4, 4)));
        });
        this.addIf(VanillaBackport.COMMON_CONFIG.hasZombieHorses.get(), (context, writer) -> {
            this.getOrCreateBiomeBuilder(ModBiomeTags.SPAWNS_ZOMBIE_HORSES)
                .add(() -> writer.addSpawn(class_1311.field_6302, new class_5483.class_1964(class_1299.field_6048, 5, 1, 1)));
        });
        
        this.addIf(VanillaBackport.COMMON_CONFIG.hasNautilus.get(), (context, writer) -> {
            this.getOrCreateBiomeBuilder(ModBiomeTags.SPAWNS_NAUTILUS)
                .add(() -> writer.addSpawn(class_1311.field_6300, new class_5483.class_1964(ModEntityTypes.NAUTILUS.get(), 2, 1, 1)));
            
            this.getOrCreateBiomeBuilder(ModBiomeTags.SPAWNS_NAUTILUS_FREQUENTLY)
                .add(() -> writer.addSpawn(class_1311.field_6300, new class_5483.class_1964(ModEntityTypes.NAUTILUS.get(), 5, 1, 1)));
        });
    }
}