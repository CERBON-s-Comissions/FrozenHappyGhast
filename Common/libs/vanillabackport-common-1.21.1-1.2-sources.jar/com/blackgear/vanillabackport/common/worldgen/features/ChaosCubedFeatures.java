package com.blackgear.vanillabackport.common.worldgen.features;

import com.blackgear.platform.core.api.registrar.bootstrap.ConfiguredFeatureRegistrar;
import com.blackgear.vanillabackport.common.level.blocks.PotentSulfurBlock;
import com.blackgear.vanillabackport.common.level.blocks.PotentSulfurState;
import com.blackgear.vanillabackport.common.level.worldgen.features.*;
import com.blackgear.vanillabackport.common.level.worldgen.features.TemplateFeatureConfiguration.TemplateEntry;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import com.blackgear.vanillabackport.common.registries.worldgen.ModFeatures;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.blackgear.vanillabackport.core.data.tags.ModBlockTags;
import com.blackgear.vanillabackport.common.value_providers.TrapezoidInt;
import net.minecraft.class_2246;
import net.minecraft.class_2350;
import net.minecraft.class_2960;
import net.minecraft.class_2975;
import net.minecraft.class_3031;
import net.minecraft.class_3085;
import net.minecraft.class_3175;
import net.minecraft.class_3179;
import net.minecraft.class_3481;
import net.minecraft.class_3612;
import net.minecraft.class_4651;
import net.minecraft.class_5321;
import net.minecraft.class_5862;
import net.minecraft.class_5866;
import net.minecraft.class_6005;
import net.minecraft.class_6016;
import net.minecraft.class_6019;
import net.minecraft.class_6646;
import net.minecraft.class_6658;
import net.minecraft.class_6732;
import net.minecraft.class_6793;
import net.minecraft.class_6794;
import net.minecraft.class_6796;
import net.minecraft.class_6817;
import net.minecraft.class_6880;
import net.minecraft.class_6885;
import net.minecraft.world.level.levelgen.feature.configurations.*;
import net.minecraft.world.level.levelgen.placement.*;
import java.util.function.BiFunction;
import java.util.function.Function;

public class ChaosCubedFeatures {
    public static final ConfiguredFeatureRegistrar REGISTRIES = ConfiguredFeatureRegistrar.create(VanillaBackport.NAMESPACE);

    public static final class_5321<class_2975<?, ?>> SULFUR_POOL = REGISTRIES.register("sulfur_pool",
        ModFeatures.SEQUENCE.get(),
        (features, placements) ->
            new class_3179(
                class_6885.method_40246(
                    class_6817.method_40368(
                        class_3031.field_13573,
                        new class_3085.class_6788(
                            class_4651.method_38433(class_2246.field_10382.method_9564()),
                            class_4651.method_38433(ModBlocks.SULFUR.get().method_9564())
                        )
                    ),
                    class_6817.method_40368(
                        class_3031.field_13518,
                        new class_3175(class_4651.method_38433(ModBlocks.POTENT_SULFUR.get().method_9564().method_11657(PotentSulfurBlock.STATE, PotentSulfurState.WET))),
                        class_6794.method_39628(class_2350.field_11033, class_6646.method_38878(class_6646.method_39585(), class_6646.method_43289(class_2350.field_11036.method_10163(), class_3612.field_15910)), 4)
                    )
                )
            ));
    public static final class_5321<class_2975<?, ?>> SULFUR_SPRING = REGISTRIES.register("sulfur_spring",
        ModFeatures.WEIGHTED_RANDOM_SELECTOR.get(),
        (features, placements) -> {
            BiFunction<Integer, Integer, class_6880<class_6796>> tuffCover = (count, spread) -> class_6817.method_40368(
                class_3031.field_13518,
                new class_3175(class_4651.method_38432(class_2246.field_27165)),
                class_6793.method_39623(count),
                class_6732.method_39657(TrapezoidInt.triangle(spread), TrapezoidInt.triangle(3)),
                class_6794.method_39628(class_2350.field_11033, class_6646.method_39585(), 4),
                class_6658.method_39618(class_6646.method_39585())
            );
            Function<class_6005<TemplateEntry>, class_6880<class_6796>> sulfurSprings = entries -> class_6817.method_40368(
                ModFeatures.TEMPLATE.get(), new TemplateFeatureConfiguration(entries), class_6732.method_39656(class_6016.method_34998(-7))
            );
            
            return new WeightedRandomFeatureConfiguration(
                class_6005.<class_6880<class_6796>>method_34971()
                    .method_34975(
                        class_6817.method_40368(
                            ModFeatures.SEQUENCE.get(),
                            new class_3179(
                                class_6885.method_40246(
                                    tuffCover.apply(64, 7),
                                    sulfurSprings.apply(
                                        class_6005.<TemplateEntry>method_34971()
                                            .method_34975(TemplateEntry.of(class_2960.method_60656("spring/sulfur_spring_small_1")), 1)
                                            .method_34975(TemplateEntry.of(class_2960.method_60656("spring/sulfur_spring_small_2")), 1)
                                            .method_34975(TemplateEntry.of(class_2960.method_60656("spring/sulfur_spring_small_3")), 1)
                                            .method_34975(TemplateEntry.of(class_2960.method_60656("spring/sulfur_spring_small_4")), 1)
                                            .method_34974()
                                    )
                                )
                            )
                        ),
                        200
                    )
                    .method_34975(
                        class_6817.method_40368(
                            ModFeatures.SEQUENCE.get(),
                            new class_3179(
                                class_6885.method_40246(
                                    tuffCover.apply(80, 8),
                                    sulfurSprings.apply(
                                        class_6005.<TemplateEntry>method_34971()
                                            .method_34975(TemplateEntry.of(class_2960.method_60656("spring/sulfur_spring_medium_1")), 1)
                                            .method_34975(TemplateEntry.of(class_2960.method_60656("spring/sulfur_spring_medium_2")), 1)
                                            .method_34975(TemplateEntry.of(class_2960.method_60656("spring/sulfur_spring_medium_3")), 1)
                                            .method_34974()
                                    )
                                )
                            )
                        ),
                        90
                    )
                    .method_34975(
                        class_6817.method_40368(
                            ModFeatures.SEQUENCE.get(),
                            new class_3179(
                                class_6885.method_40246(
                                    tuffCover.apply(96, 9),
                                    sulfurSprings.apply(
                                        class_6005.<TemplateEntry>method_34971()
                                            .method_34975(TemplateEntry.of(class_2960.method_60656("spring/sulfur_spring_large_1")), 1)
                                            .method_34975(TemplateEntry.of(class_2960.method_60656("spring/sulfur_spring_large_2")), 1)
                                            .method_34974()
                                    )
                                )
                            )
                        ),
                        20
                    )
                    .method_34975(
                        class_6817.method_40368(
                            ModFeatures.SEQUENCE.get(),
                            new class_3179(
                                class_6885.method_40246(
                                    tuffCover.apply(128, 10),
                                    sulfurSprings.apply(
                                        class_6005.method_38061(TemplateEntry.of(class_2960.method_60656("spring/sulfur_spring_extra_large_1")))
                                    )
                                )
                            )
                        ),
                        5
                    )
                    .method_34974());
        });
    public static final class_5321<class_2975<?, ?>> ROOTED_SULFUR_SPRING = REGISTRIES.register("rooted_sulfur_spring",
        ModFeatures.SULFUR_ROOT_SYSTEM.get(),
        (features, placements) ->
            new SulfurRootSystemConfiguration(
                class_6817.method_40369(features.method_46747(SULFUR_SPRING)),
                5,
                8,
                2,
                3,
                class_3481.field_36268,
                class_4651.method_38432(ModBlocks.SULFUR.get()),
                20,
                184,
                1,
                1,
                class_4651.method_38432(ModBlocks.SULFUR.get()),
                1,
                1,
                class_6646.field_35696
            ));
    public static final class_5321<class_2975<?, ?>> SULFUR_SPIKE_CLUSTER = REGISTRIES.register("sulfur_spike_cluster",
        ModFeatures.SPELEOTHEM_CLUSTER.get(),
        (features, placements) ->
            new SpeleothemClusterConfiguration(
                ModBlocks.SULFUR.get().method_9564(),
                ModBlocks.SULFUR_SPIKE.get().method_9564(),
                ModBlockTags.SULFUR_SPIKE_REPLACEABLE,
                12,
                class_6019.method_35017(1, 4),
                class_6019.method_35017(2, 8),
                1,
                3,
                class_6019.method_35017(2, 4),
                class_5866.method_33934(0.3F, 0.7F),
                class_5862.field_29003,
                0.1F,
                3,
                8
            ));
    public static final class_5321<class_2975<?, ?>> SULFUR_SPIKE = REGISTRIES.register("sulfur_spike",
        class_3031.field_13555,
        (features, placements) ->
            new class_3179(
                class_6885.method_40246(
                    class_6817.method_40368(
                        ModFeatures.SPELEOTHEM.get(),
                        new SpeleothemConfiguration(
                            ModBlocks.SULFUR.get().method_9564(),
                            ModBlocks.SULFUR_SPIKE.get().method_9564(),
                            ModBlockTags.SULFUR_SPIKE_REPLACEABLE,
                            0.2F,
                            0.7F,
                            0.5F,
                            0.5F
                        ),
                        class_6794.method_39629(class_2350.field_11033, class_6646.method_39585(), class_6646.field_35697, 12),
                        class_6732.method_39656(class_6016.method_34998(1))
                    ),
                    class_6817.method_40368(
                        ModFeatures.SPELEOTHEM.get(),
                        new SpeleothemConfiguration(
                            ModBlocks.SULFUR.get().method_9564(),
                            ModBlocks.SULFUR_SPIKE.get().method_9564(),
                            ModBlockTags.SULFUR_SPIKE_REPLACEABLE,
                            0.2F,
                            0.7F,
                            0.5F,
                            0.5F
                        ),
                        class_6794.method_39629(class_2350.field_11036, class_6646.method_39585(), class_6646.field_35697, 12),
                        class_6732.method_39656(class_6016.method_34998(-1))
                    )
                )
            ));
}