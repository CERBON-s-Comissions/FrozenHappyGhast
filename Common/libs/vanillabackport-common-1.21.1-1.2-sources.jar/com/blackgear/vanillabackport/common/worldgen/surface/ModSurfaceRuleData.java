package com.blackgear.vanillabackport.common.worldgen.surface;

import com.blackgear.vanillabackport.common.registries.worldgen.ModBiomes;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import com.blackgear.vanillabackport.common.registries.worldgen.ModNoises;
import com.blackgear.vanillabackport.common.level.worldgen.surface.SpatialNoiseThresholdConditionSource;
import com.google.common.collect.ImmutableList;
import java.util.List;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_5216;
import net.minecraft.class_5321;
import net.minecraft.class_5843;
import net.minecraft.class_6686;

public class ModSurfaceRuleData {
    public static class_6686.class_6708 makeRules() {
        class_6686.class_6708 cinnabar = makeStateRule(ModBlocks.CINNABAR.get());
        class_6686.class_6708 sulfur = makeStateRule(ModBlocks.SULFUR.get());
        class_6686.class_6708 stone = makeStateRule(class_2246.field_10340);
        class_6686.class_6708 coarse_dirt = makeStateRule(class_2246.field_10253);

        return class_6686.method_39050(
            class_6686.method_39049(
                class_6686.method_39055(ModBiomes.DAPPLED_FOREST),
                class_6686.method_39049(class_6686.method_39052(ModNoises.SMALL_PATCH, 1.2F), coarse_dirt)
            ),
            class_6686.method_39049(
                class_6686.method_39055(ModBiomes.SULFUR_CAVES),
                class_6686.method_39050(
                    bedrock(),
                    class_6686.method_39049(noiseCondition3d(ModNoises.SULFUR_CAVE_GRADIENT, -0.4F, -0.1F), cinnabar),
                    class_6686.method_39049(noiseCondition3d(ModNoises.SULFUR_CAVE_GRADIENT, 0.0F, 0.4F), sulfur),
                    class_6686.method_39049(noiseCondition3d(ModNoises.SULFUR_CAVE_GRADIENT, 0.4F), cinnabar),
                    class_6686.method_39049(class_6686.method_39473(), stone)
                )
            )
        );
    }

    public static class_6686.class_6693 noiseCondition3d(class_5321<class_5216.class_5487> noise, double minRange, double maxRange) {
        return new SpatialNoiseThresholdConditionSource(noise, minRange, maxRange);
    }

    public static class_6686.class_6693 noiseCondition3d(class_5321<class_5216.class_5487> noise, double minRange) {
        return noiseCondition3d(noise, minRange, Double.MAX_VALUE);
    }

    private static class_6686.class_6708 makeStateRule(class_2248 block) {
        return class_6686.method_39047(block.method_9564());
    }
    
    private static class_6686.class_6708 bedrock() {
        class_6686.class_6708 bedrock = class_6686.method_39047(class_2246.field_9987.method_9564());
        class_6686.class_6693 bedrockCondition = class_6686.method_39472("bedrock", class_5843.method_33840(), class_5843.method_33846(5));
        return class_6686.method_39049(bedrockCondition, bedrock);
    }
    
    public static class_6686.class_6708 merge(class_6686.class_6708 original, List<class_6686.class_6708> rules) {
        ImmutableList.Builder<class_6686.class_6708> builder = ImmutableList.builder();
        builder.addAll(rules);
        builder.add(original);
        return class_6686.method_39050(builder.build().toArray(class_6686.class_6708[]::new));
    }
}