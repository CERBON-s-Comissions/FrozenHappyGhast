package com.blackgear.vanillabackport.common.worldgen.structures;

import com.blackgear.platform.core.api.registrar.bootstrap.BootstrapRegistrar;
import com.blackgear.vanillabackport.common.level.worldgen.structure.AbandonedCampStructurePools;
import com.blackgear.vanillabackport.core.VanillaBackport;
import com.blackgear.vanillabackport.core.data.tags.ModBiomeTags;
import net.minecraft.class_1959;
import net.minecraft.class_2902;
import net.minecraft.class_3195;
import net.minecraft.class_3785;
import net.minecraft.class_5321;
import net.minecraft.class_5434;
import net.minecraft.class_5843;
import net.minecraft.class_5847;
import net.minecraft.class_6121;
import net.minecraft.class_7871;
import net.minecraft.class_7924;
import net.minecraft.world.level.levelgen.placement.*;

public class WildernessBoundStructures {
    public static final BootstrapRegistrar<class_3195> REGISTRIES = BootstrapRegistrar.create(class_7924.field_41246, VanillaBackport.NAMESPACE);
    
    public static final class_5321<class_3195> ABANDONED_CAMP_BAMBOO_JUNGLE = REGISTRIES.register("abandoned_camp_bamboo_jungle", context -> {
        class_7871<class_1959> biomes = context.method_46799(class_7924.field_41236);
        class_7871<class_3785> templates = context.method_46799(class_7924.field_41249);
        return new class_5434(
            new class_3195.class_7302.class_9821(biomes.method_46735(ModBiomeTags.HAS_ABANDONED_CAMP_BAMBOO_JUNGLE))
                .method_61010(class_5847.field_38431)
                .method_61008(),
            templates.method_46747(AbandonedCampStructurePools.BAMBOO_JUNGLE.tentStructureDirectory()),
            2,
            class_6121.method_35383(class_5843.method_33841(0)),
            true,
            class_2902.class_2903.field_13194
        );
    });
    public static final class_5321<class_3195> ABANDONED_CAMP_BIRCH_FOREST = REGISTRIES.register("abandoned_camp_birch_forest", context -> {
        class_7871<class_1959> biomes = context.method_46799(class_7924.field_41236);
        class_7871<class_3785> templates = context.method_46799(class_7924.field_41249);
        return new class_5434(
            new class_3195.class_7302.class_9821(biomes.method_46735(ModBiomeTags.HAS_ABANDONED_CAMP_BIRCH_FOREST))
                .method_61010(class_5847.field_38431)
                .method_61008(),
            templates.method_46747(AbandonedCampStructurePools.BIRCH_FOREST.tentStructureDirectory()),
            2,
            class_6121.method_35383(class_5843.method_33841(0)),
            true,
            class_2902.class_2903.field_13194
        );
    });
    public static final class_5321<class_3195> ABANDONED_CAMP_CHERRY_GROVE = REGISTRIES.register("abandoned_camp_cherry_grove", context -> {
        class_7871<class_1959> biomes = context.method_46799(class_7924.field_41236);
        class_7871<class_3785> templates = context.method_46799(class_7924.field_41249);
        return new class_5434(
            new class_3195.class_7302.class_9821(biomes.method_46735(ModBiomeTags.HAS_ABANDONED_CAMP_CHERRY_GROVE))
                .method_61010(class_5847.field_38431)
                .method_61008(),
            templates.method_46747(AbandonedCampStructurePools.CHERRY_GROVE.tentStructureDirectory()),
            2,
            class_6121.method_35383(class_5843.method_33841(0)),
            true,
            class_2902.class_2903.field_13194
        );
    });
    public static final class_5321<class_3195> ABANDONED_CAMP_DAPPLED_FOREST = REGISTRIES.register("abandoned_camp_dappled_forest", context -> {
        class_7871<class_1959> biomes = context.method_46799(class_7924.field_41236);
        class_7871<class_3785> templates = context.method_46799(class_7924.field_41249);
        return new class_5434(
            new class_3195.class_7302.class_9821(biomes.method_46735(ModBiomeTags.HAS_ABANDONED_CAMP_DAPPLED_FOREST))
                .method_61010(class_5847.field_38431)
                .method_61008(),
            templates.method_46747(AbandonedCampStructurePools.DAPPLED_FOREST.tentStructureDirectory()),
            2,
            class_6121.method_35383(class_5843.method_33841(0)),
            true,
            class_2902.class_2903.field_13194
        );
    });
    public static final class_5321<class_3195> ABANDONED_CAMP_FLOWER_FOREST = REGISTRIES.register("abandoned_camp_flower_forest", context -> {
        class_7871<class_1959> biomes = context.method_46799(class_7924.field_41236);
        class_7871<class_3785> templates = context.method_46799(class_7924.field_41249);
        return new class_5434(
            new class_3195.class_7302.class_9821(biomes.method_46735(ModBiomeTags.HAS_ABANDONED_CAMP_FLOWER_FOREST))
                .method_61010(class_5847.field_38431)
                .method_61008(),
            templates.method_46747(AbandonedCampStructurePools.FLOWER_FOREST.tentStructureDirectory()),
            2,
            class_6121.method_35383(class_5843.method_33841(0)),
            true,
            class_2902.class_2903.field_13194
        );
    });
    public static final class_5321<class_3195> ABANDONED_CAMP_FOREST = REGISTRIES.register("abandoned_camp_forest", context -> {
        class_7871<class_1959> biomes = context.method_46799(class_7924.field_41236);
        class_7871<class_3785> templates = context.method_46799(class_7924.field_41249);
        return new class_5434(
            new class_3195.class_7302.class_9821(biomes.method_46735(ModBiomeTags.HAS_ABANDONED_CAMP_FOREST))
                .method_61010(class_5847.field_38431)
                .method_61008(),
            templates.method_46747(AbandonedCampStructurePools.FOREST.tentStructureDirectory()),
            2,
            class_6121.method_35383(class_5843.method_33841(0)),
            true,
            class_2902.class_2903.field_13194
        );
    });
    public static final class_5321<class_3195> ABANDONED_CAMP_MEADOW = REGISTRIES.register("abandoned_camp_meadow", context -> {
        class_7871<class_1959> biomes = context.method_46799(class_7924.field_41236);
        class_7871<class_3785> templates = context.method_46799(class_7924.field_41249);
        return new class_5434(
            new class_3195.class_7302.class_9821(biomes.method_46735(ModBiomeTags.HAS_ABANDONED_CAMP_MEADOW))
                .method_61010(class_5847.field_38431)
                .method_61008(),
            templates.method_46747(AbandonedCampStructurePools.MEADOW.tentStructureDirectory()),
            2,
            class_6121.method_35383(class_5843.method_33841(0)),
            true,
            class_2902.class_2903.field_13194
        );
    });
    public static final class_5321<class_3195> ABANDONED_CAMP_OLD_GROWTH_BIRCH_FOREST = REGISTRIES.register("abandoned_camp_old_growth_birch_forest", context -> {
        class_7871<class_1959> biomes = context.method_46799(class_7924.field_41236);
        class_7871<class_3785> templates = context.method_46799(class_7924.field_41249);
        return new class_5434(
            new class_3195.class_7302.class_9821(biomes.method_46735(ModBiomeTags.HAS_ABANDONED_CAMP_OLD_GROWTH_BIRCH_FOREST))
                .method_61010(class_5847.field_38431)
                .method_61008(),
            templates.method_46747(AbandonedCampStructurePools.OLD_GROWTH_BIRCH_FOREST.tentStructureDirectory()),
            2,
            class_6121.method_35383(class_5843.method_33841(0)),
            true,
            class_2902.class_2903.field_13194
        );
    });
    public static final class_5321<class_3195> ABANDONED_CAMP_OLD_GROWTH_PINE_TAIGA = REGISTRIES.register("abandoned_camp_old_growth_pine_taiga", context -> {
        class_7871<class_1959> biomes = context.method_46799(class_7924.field_41236);
        class_7871<class_3785> templates = context.method_46799(class_7924.field_41249);
        return new class_5434(
            new class_3195.class_7302.class_9821(biomes.method_46735(ModBiomeTags.HAS_ABANDONED_CAMP_OLD_GROWTH_PINE_TAIGA))
                .method_61010(class_5847.field_38431)
                .method_61008(),
            templates.method_46747(AbandonedCampStructurePools.OLD_GROWTH_PINE_TAIGA.tentStructureDirectory()),
            2,
            class_6121.method_35383(class_5843.method_33841(0)),
            true,
            class_2902.class_2903.field_13194
        );
    });
    public static final class_5321<class_3195> ABANDONED_CAMP_OLD_GROWTH_SPRUCE_TAIGA = REGISTRIES.register("abandoned_camp_old_growth_spruce_taiga", context -> {
        class_7871<class_1959> biomes = context.method_46799(class_7924.field_41236);
        class_7871<class_3785> templates = context.method_46799(class_7924.field_41249);
        return new class_5434(
            new class_3195.class_7302.class_9821(biomes.method_46735(ModBiomeTags.HAS_ABANDONED_CAMP_OLD_GROWTH_SPRUCE_TAIGA))
                .method_61010(class_5847.field_38431)
                .method_61008(),
            templates.method_46747(AbandonedCampStructurePools.OLD_GROWTH_SPRUCE_TAIGA.tentStructureDirectory()),
            2,
            class_6121.method_35383(class_5843.method_33841(0)),
            true,
            class_2902.class_2903.field_13194
        );
    });
    public static final class_5321<class_3195> ABANDONED_CAMP_PALE_GARDEN = REGISTRIES.register("abandoned_camp_pale_garden", context -> {
        class_7871<class_1959> biomes = context.method_46799(class_7924.field_41236);
        class_7871<class_3785> templates = context.method_46799(class_7924.field_41249);
        return new class_5434(
            new class_3195.class_7302.class_9821(biomes.method_46735(ModBiomeTags.HAS_ABANDONED_CAMP_PALE_GARDEN))
                .method_61010(class_5847.field_38431)
                .method_61008(),
            templates.method_46747(AbandonedCampStructurePools.PALE_GARDEN.tentStructureDirectory()),
            2,
            class_6121.method_35383(class_5843.method_33841(0)),
            true,
            class_2902.class_2903.field_13194
        );
    });
    public static final class_5321<class_3195> ABANDONED_CAMP_SAVANNA = REGISTRIES.register("abandoned_camp_savanna", context -> {
        class_7871<class_1959> biomes = context.method_46799(class_7924.field_41236);
        class_7871<class_3785> templates = context.method_46799(class_7924.field_41249);
        return new class_5434(
            new class_3195.class_7302.class_9821(biomes.method_46735(ModBiomeTags.HAS_ABANDONED_CAMP_SAVANNA))
                .method_61010(class_5847.field_38431)
                .method_61008(),
            templates.method_46747(AbandonedCampStructurePools.SAVANNA.tentStructureDirectory()),
            2,
            class_6121.method_35383(class_5843.method_33841(0)),
            true,
            class_2902.class_2903.field_13194
        );
    });
    public static final class_5321<class_3195> ABANDONED_CAMP_SNOWY_TAIGA = REGISTRIES.register("abandoned_camp_snowy_taiga", context -> {
        class_7871<class_1959> biomes = context.method_46799(class_7924.field_41236);
        class_7871<class_3785> templates = context.method_46799(class_7924.field_41249);
        return new class_5434(
            new class_3195.class_7302.class_9821(biomes.method_46735(ModBiomeTags.HAS_ABANDONED_CAMP_SNOWY_TAIGA))
                .method_61010(class_5847.field_38431)
                .method_61008(),
            templates.method_46747(AbandonedCampStructurePools.SNOWY_TAIGA.tentStructureDirectory()),
            2,
            class_6121.method_35383(class_5843.method_33841(0)),
            true,
            class_2902.class_2903.field_13194
        );
    });
    public static final class_5321<class_3195> ABANDONED_CAMP_SPARSE_JUNGLE = REGISTRIES.register("abandoned_camp_sparse_jungle", context -> {
        class_7871<class_1959> biomes = context.method_46799(class_7924.field_41236);
        class_7871<class_3785> templates = context.method_46799(class_7924.field_41249);
        return new class_5434(
            new class_3195.class_7302.class_9821(biomes.method_46735(ModBiomeTags.HAS_ABANDONED_CAMP_SPARSE_JUNGLE))
                .method_61010(class_5847.field_38431)
                .method_61008(),
            templates.method_46747(AbandonedCampStructurePools.SPARSE_JUNGLE.tentStructureDirectory()),
            2,
            class_6121.method_35383(class_5843.method_33841(0)),
            true,
            class_2902.class_2903.field_13194
        );
    });
    public static final class_5321<class_3195> ABANDONED_CAMP_SWAMP = REGISTRIES.register("abandoned_camp_swamp", context -> {
        class_7871<class_1959> biomes = context.method_46799(class_7924.field_41236);
        class_7871<class_3785> templates = context.method_46799(class_7924.field_41249);
        return new class_5434(
            new class_3195.class_7302.class_9821(biomes.method_46735(ModBiomeTags.HAS_ABANDONED_CAMP_SWAMP))
                .method_61010(class_5847.field_38431)
                .method_61008(),
            templates.method_46747(AbandonedCampStructurePools.SWAMP.tentStructureDirectory()),
            2,
            class_6121.method_35383(class_5843.method_33841(0)),
            true,
            class_2902.class_2903.field_13194
        );
    });
    public static final class_5321<class_3195> ABANDONED_CAMP_TAIGA = REGISTRIES.register("abandoned_camp_taiga", context -> {
        class_7871<class_1959> biomes = context.method_46799(class_7924.field_41236);
        class_7871<class_3785> templates = context.method_46799(class_7924.field_41249);
        return new class_5434(
            new class_3195.class_7302.class_9821(biomes.method_46735(ModBiomeTags.HAS_ABANDONED_CAMP_TAIGA))
                .method_61010(class_5847.field_38431)
                .method_61008(),
            templates.method_46747(AbandonedCampStructurePools.TAIGA.tentStructureDirectory()),
            2,
            class_6121.method_35383(class_5843.method_33841(0)),
            true,
            class_2902.class_2903.field_13194
        );
    });
    public static final class_5321<class_3195> ABANDONED_CAMP_WINDSWEPT_FOREST = REGISTRIES.register("abandoned_camp_windswept_forest", context -> {
        class_7871<class_1959> biomes = context.method_46799(class_7924.field_41236);
        class_7871<class_3785> templates = context.method_46799(class_7924.field_41249);
        return new class_5434(
            new class_3195.class_7302.class_9821(biomes.method_46735(ModBiomeTags.HAS_ABANDONED_CAMP_WINDSWEPT_FOREST))
                .method_61010(class_5847.field_38431)
                .method_61008(),
            templates.method_46747(AbandonedCampStructurePools.WINDSWEPT_FOREST.tentStructureDirectory()),
            2,
            class_6121.method_35383(class_5843.method_33841(0)),
            true,
            class_2902.class_2903.field_13194
        );
    });
    public static final class_5321<class_3195> ABANDONED_CAMP_WOODED_BADLANDS = REGISTRIES.register("abandoned_camp_wooded_badlands", context -> {
        class_7871<class_1959> biomes = context.method_46799(class_7924.field_41236);
        class_7871<class_3785> templates = context.method_46799(class_7924.field_41249);
        return new class_5434(
            new class_3195.class_7302.class_9821(biomes.method_46735(ModBiomeTags.HAS_ABANDONED_CAMP_WOODED_BADLANDS))
                .method_61010(class_5847.field_38431)
                .method_61008(),
            templates.method_46747(AbandonedCampStructurePools.WOODED_BADLANDS.tentStructureDirectory()),
            2,
            class_6121.method_35383(class_5843.method_33841(0)),
            true,
            class_2902.class_2903.field_13194
        );
    });
}