package com.blackgear.vanillabackport.common.predicates;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_1702;
import net.minecraft.class_2096;

public record FoodPredicate(class_2096.class_2100 level, class_2096.class_2099 saturation) {
    public static final FoodPredicate ANY = new FoodPredicate(class_2096.class_2100.field_9708, class_2096.class_2099.field_9705);
    public static final Codec<FoodPredicate> CODEC = RecordCodecBuilder.create(instance -> instance.group(
        class_2096.class_2100.field_45763.optionalFieldOf("level", class_2096.class_2100.field_9708).forGetter(FoodPredicate::level),
        class_2096.class_2099.field_45762.optionalFieldOf("saturation", class_2096.class_2099.field_9705).forGetter(FoodPredicate::saturation)
    ).apply(instance, FoodPredicate::new));
    
    public boolean matches(class_1702 food) {
        return this.level.method_9054(food.method_7586()) && this.saturation.method_9047(food.method_7589());
    }
    
    public static class Builder {
        private class_2096.class_2100 level = class_2096.class_2100.field_9708;
        private class_2096.class_2099 saturation = class_2096.class_2099.field_9705;
        
        public Builder withLevel(class_2096.class_2100 level) {
            this.level = level;
            return this;
        }
        
        public Builder withSaturation(class_2096.class_2099 saturation) {
            this.saturation = saturation;
            return this;
        }
        
        public static Builder food() {
            return new Builder();
        }
        
        public FoodPredicate build() {
            return new FoodPredicate(this.level, this.saturation);
        }
    }
}