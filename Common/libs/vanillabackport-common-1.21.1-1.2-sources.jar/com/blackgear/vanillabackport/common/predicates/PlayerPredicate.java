package com.blackgear.vanillabackport.common.predicates;

import com.google.common.base.Suppliers;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Maps;
import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import it.unimi.dsi.fastutil.objects.Object2BooleanMap;
import it.unimi.dsi.fastutil.objects.Object2BooleanMaps;
import it.unimi.dsi.fastutil.objects.Object2BooleanOpenHashMap;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.function.Supplier;
import net.minecraft.class_1297;
import net.minecraft.class_167;
import net.minecraft.class_1675;
import net.minecraft.class_178;
import net.minecraft.class_2048;
import net.minecraft.class_2096;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_2985;
import net.minecraft.class_2989;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3441;
import net.minecraft.class_3445;
import net.minecraft.class_3448;
import net.minecraft.class_3469;
import net.minecraft.class_3966;
import net.minecraft.class_5699;
import net.minecraft.class_6880;
import net.minecraft.class_7376;
import net.minecraft.class_7923;
import net.minecraft.class_8779;
import net.minecraft.class_9789;

public record PlayerPredicate(
    class_2096.class_2100 level,
    FoodPredicate food,
    class_9789 gameType,
    List<StatMatcher<?>> stats,
    Object2BooleanMap<class_2960> recipes,
    Map<class_2960, AdvancementPredicate> advancements,
    Optional<class_2048> lookingAt
) implements class_7376 {
    public static final MapCodec<PlayerPredicate> CODEC = RecordCodecBuilder.mapCodec(
        instance -> instance.group(
                class_2096.class_2100.field_45763.optionalFieldOf("level", class_2096.class_2100.field_9708).forGetter(PlayerPredicate::level),
                FoodPredicate.CODEC.optionalFieldOf("food", FoodPredicate.ANY).forGetter(PlayerPredicate::food),
                class_9789.field_52014.optionalFieldOf("gamemode", class_9789.field_52012).forGetter(PlayerPredicate::gameType),
                StatMatcher.CODEC.listOf().optionalFieldOf("stats", List.of()).forGetter(PlayerPredicate::stats),
                class_5699.method_53058(class_2960.field_25139).optionalFieldOf("recipes", Object2BooleanMaps.emptyMap()).forGetter(PlayerPredicate::recipes),
                Codec.unboundedMap(class_2960.field_25139, AdvancementPredicate.CODEC)
                    .optionalFieldOf("advancements", Map.of())
                    .forGetter(PlayerPredicate::advancements),
                class_2048.field_45746.optionalFieldOf("looking_at").forGetter(PlayerPredicate::lookingAt)
            )
            .apply(instance, PlayerPredicate::new)
    );
    
    @Override
    public MapCodec<? extends class_7376> method_58152() {
        return CODEC;
    }
    
    @Override
    public boolean method_22497(class_1297 entity, class_3218 level, @Nullable class_243 position) {
        if (!(entity instanceof class_3222 player)) {
            return false;
        } else if (!this.level.method_9054(player.field_7520)) {
            return false;
        } else if (!this.food.matches(player.method_7344())) {
            return false;
        } else if (!this.gameType.method_60723(player.field_13974.method_14257())) {
            return false;
        } else {
            class_3469 stats = player.method_14248();
            
            for (StatMatcher<?> stat : this.stats) {
                if (!stat.matches(stats)) {
                    return false;
                }
            }
            
            class_3441 recipes = player.method_14253();
            
            for (var entry : this.recipes.object2BooleanEntrySet()) {
                if (recipes.method_22845(entry.getKey()) != entry.getBooleanValue()) {
                    return false;
                }
            }
            
            if (!this.advancements.isEmpty()) {
                class_2985 advancements = player.method_14236();
                class_2989 serverAdvancements = player.method_37908().method_8503().method_3851();
                
                for (var entry : this.advancements.entrySet()) {
                    class_8779 advancement = serverAdvancements.method_12896(entry.getKey());
                    if (advancement == null || !entry.getValue().test(advancements.method_12882(advancement))) {
                        return false;
                    }
                }
            }
            
            if (this.lookingAt.isPresent()) {
                class_243 from = player.method_33571();
                class_243 viewVec = player.method_5828(1.0F);
                class_243 to = from.method_1031(viewVec.field_1352 * 100.0, viewVec.field_1351 * 100.0, viewVec.field_1350 * 100.0);
                class_3966 lookingAtResult = class_1675.method_37226(player.method_37908(), player, from, to, new class_238(from, to).method_1014(1.0), ex -> !ex.method_7325(), 0.0F);
                if (lookingAtResult == null || lookingAtResult.method_17783() != class_239.class_240.field_1331) {
                    return false;
                }
                
                class_1297 lookingAtEntity = lookingAtResult.method_17782();
                return this.lookingAt.get().method_8914(player, lookingAtEntity) && player.method_6057(lookingAtEntity);
            }
            
            return true;
        }
    }
    
    private record AdvancementCriterionsPredicate(Object2BooleanMap<String> criterions) implements AdvancementPredicate {
        public static final Codec<AdvancementCriterionsPredicate> CODEC = class_5699.method_53058(Codec.STRING).xmap(AdvancementCriterionsPredicate::new, AdvancementCriterionsPredicate::criterions);
        
        @Override
        public boolean test(class_167 progress) {
            for (var entry : this.criterions.object2BooleanEntrySet()) {
                class_178 criterion = progress.method_737(entry.getKey());
                if (criterion == null || criterion.method_784() != entry.getBooleanValue()) {
                    return false;
                }
            }
            
            return true;
        }
    }
    
    private record AdvancementDonePredicate(boolean state) implements AdvancementPredicate {
        public static final Codec<AdvancementDonePredicate> CODEC = Codec.BOOL.xmap(AdvancementDonePredicate::new, AdvancementDonePredicate::state);
        
        @Override
        public boolean test(class_167 progress) {
            return progress.method_740() == this.state;
        }
    }
    
    private interface AdvancementPredicate extends Predicate<class_167> {
        Codec<AdvancementPredicate> CODEC = Codec.either(AdvancementDonePredicate.CODEC, AdvancementCriterionsPredicate.CODEC)
            .xmap(Either::unwrap, predicate -> {
                if (predicate instanceof AdvancementDonePredicate done) {
                    return Either.left(done);
                } else if (predicate instanceof AdvancementCriterionsPredicate criterions) {
                    return Either.right(criterions);
                } else {
                    throw new UnsupportedOperationException();
                }
            });
    }
    
    public static class Builder {
        private class_2096.class_2100 level = class_2096.class_2100.field_9708;
        private FoodPredicate food = FoodPredicate.ANY;
        private class_9789 gameType = class_9789.field_52012;
        private final ImmutableList.Builder<StatMatcher<?>> stats = ImmutableList.builder();
        private final Object2BooleanMap<class_2960> recipes = new Object2BooleanOpenHashMap<>();
        private final Map<class_2960, AdvancementPredicate> advancements = Maps.newHashMap();
        private Optional<class_2048> lookingAt = Optional.empty();
        
        public static Builder player() {
            return new Builder();
        }
        
        public Builder setLevel(class_2096.class_2100 level) {
            this.level = level;
            return this;
        }
        
        public Builder setFood(FoodPredicate food) {
            this.food = food;
            return this;
        }
        
        public <T> Builder addStat(class_3448<T> type, class_6880.class_6883<T> value, class_2096.class_2100 range) {
            this.stats.add(new StatMatcher<>(type, value, range));
            return this;
        }
        
        public Builder addRecipe(class_2960 recipe, boolean present) {
            this.recipes.put(recipe, present);
            return this;
        }
        
        public Builder setGameType(class_9789 gameType) {
            this.gameType = gameType;
            return this;
        }
        
        public Builder setLookingAt(class_2048.class_2049 lookingAt) {
            this.lookingAt = Optional.of(lookingAt.method_8920());
            return this;
        }
        
        public Builder checkAdvancementDone(class_2960 advancement, boolean isDone) {
            this.advancements.put(advancement, new AdvancementDonePredicate(isDone));
            return this;
        }
        
        public Builder checkAdvancementCriterions(class_2960 advancement, Map<String, Boolean> criterions) {
            this.advancements.put(advancement, new AdvancementCriterionsPredicate(new Object2BooleanOpenHashMap<>(criterions)));
            return this;
        }
        
        public PlayerPredicate build() {
            return new PlayerPredicate(this.level, this.food, this.gameType, this.stats.build(), this.recipes, this.advancements, this.lookingAt);
        }
    }
    
    private record StatMatcher<T>(class_3448<T> type, class_6880<T> value, class_2096.class_2100 range, Supplier<class_3445<T>> stat) {
        public static final Codec<StatMatcher<?>> CODEC = class_7923.field_41193.method_39673().dispatch(StatMatcher::type, StatMatcher::createTypedCodec);
        
        public StatMatcher(class_3448<T> type, class_6880<T> value, class_2096.class_2100 range) {
            this(type, value, range, Suppliers.memoize(() -> type.method_14956(value.comp_349())));
        }
        
        private static <T> MapCodec<StatMatcher<T>> createTypedCodec(class_3448<T> type) {
            return RecordCodecBuilder.mapCodec(instance -> instance.group(
                type.method_14959().method_40294().fieldOf("stat").forGetter(StatMatcher::value),
                class_2096.class_2100.field_45763.optionalFieldOf("value", class_2096.class_2100.field_9708).forGetter(StatMatcher::range)
            ).apply(instance, (value, range) -> new StatMatcher<>(type, value, range)));
        }
        
        public boolean matches(class_3469 counter) {
            return this.range.method_9054(counter.method_15025(this.stat.get()));
        }
    }
}