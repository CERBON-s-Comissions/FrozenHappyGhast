package com.blackgear.vanillabackport.data.client;

import com.blackgear.vanillabackport.common.level.blocks.CreakingHeartBlock;
import com.blackgear.vanillabackport.common.level.blocks.DriedGhastBlock;
import com.blackgear.vanillabackport.common.level.blocks.HangingMossBlock;
import com.blackgear.vanillabackport.common.level.blocks.MossyCarpetBlock;
import com.blackgear.vanillabackport.common.level.blocks.blockstates.CreakingHeartState;
import com.blackgear.vanillabackport.common.registries.ModBlocks;
import com.blackgear.vanillabackport.data.client.model.ModelTemplates;
import com.blackgear.vanillabackport.data.client.model.TextureMappings;
import com.blackgear.vanillabackport.data.client.model.TexturedModels;
import com.mojang.datafixers.util.Pair;
import net.minecraft.class_156;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2754;
import net.minecraft.class_2960;
import net.minecraft.class_4778;
import net.minecraft.class_4910;
import net.minecraft.class_4918;
import net.minecraft.class_4922;
import net.minecraft.class_4925;
import net.minecraft.class_4926;
import net.minecraft.class_4935;
import net.minecraft.class_4936;
import net.minecraft.class_4936.class_4937;
import net.minecraft.class_4941;
import net.minecraft.class_4944;
import net.minecraft.class_4945;
import net.minecraft.class_4946;
import net.minecraft.data.models.blockstates.*;
import java.util.List;
import java.util.function.Function;

public record BlockModels(class_4910 gen) {
    private static final List<Pair<class_2350, Function<class_2960, class_4935>>> MULTIFACE_GENERATOR = List.of(
        Pair.of(class_2350.field_11043, path -> class_4935.method_25824().method_25828(class_4936.field_22887, path)),
        Pair.of(
            class_2350.field_11034,
            path -> class_4935.method_25824()
                .method_25828(class_4936.field_22887, path)
                .method_25828(class_4936.field_22886, class_4937.field_22891)
                .method_25828(class_4936.field_22888, true)
        ),
        Pair.of(
            class_2350.field_11035,
            path -> class_4935.method_25824()
                .method_25828(class_4936.field_22887, path)
                .method_25828(class_4936.field_22886, class_4937.field_22892)
                .method_25828(class_4936.field_22888, true)
        ),
        Pair.of(
            class_2350.field_11039,
            path -> class_4935.method_25824()
                .method_25828(class_4936.field_22887, path)
                .method_25828(class_4936.field_22886, class_4937.field_22893)
                .method_25828(class_4936.field_22888, true)
        ),
        Pair.of(
            class_2350.field_11036,
            path -> class_4935.method_25824()
                .method_25828(class_4936.field_22887, path)
                .method_25828(class_4936.field_22885, class_4937.field_22893)
                .method_25828(class_4936.field_22888, true)
        ),
        Pair.of(
            class_2350.field_11033,
            path -> class_4935.method_25824()
                .method_25828(class_4936.field_22887, path)
                .method_25828(class_4936.field_22885, class_4937.field_22891)
                .method_25828(class_4936.field_22888, true)
        )
    );

    public void createMossyCarpet(class_2248 block) {
        class_2960 baseModel = class_4946.field_23044.method_25923(block, gen.field_22831);
        class_2960 tallSideModel = TexturedModels.MOSSY_CARPET_SIDE
            .get(block)
            .method_25917(mapping -> mapping.method_25868(class_4945.field_23018, class_4944.method_25866(block, "_side_tall")))
            .method_25915(block, "_side_tall", gen.field_22831);
        class_2960 shortSideModel = TexturedModels.MOSSY_CARPET_SIDE
            .get(block)
            .method_25917(mapping -> mapping.method_25868(class_4945.field_23018, class_4944.method_25866(block, "_side_small")))
            .method_25915(block, "_side_small", gen.field_22831);

        class_4922 generator = class_4922.method_25758(block);
        class_4918.class_4921 terminal = class_4918.method_25744().method_25751(MossyCarpetBlock.BASE, false);

        generator.method_25760(class_4918.method_25744().method_25751(MossyCarpetBlock.BASE, true), class_4935.method_25824().method_25828(class_4936.field_22887, baseModel));
        generator.method_25760(terminal, class_4935.method_25824().method_25828(class_4936.field_22887, baseModel));

        MULTIFACE_GENERATOR.stream().map(Pair::getFirst).forEach(direction -> {
            class_2754<class_4778> property = MossyCarpetBlock.getPropertyForFace(direction);
            if (property != null && block.method_9564().method_28498(property)) {
                terminal.method_25751(property, class_4778.field_22178);
            }
        });

        for (Pair<class_2350, Function<class_2960, class_4935>> pair : MULTIFACE_GENERATOR) {
            class_2350 direction = pair.getFirst();
            class_2754<class_4778> property = MossyCarpetBlock.getPropertyForFace(direction);

            if (property != null) {
                Function<class_2960, class_4935> variant = pair.getSecond();
                generator.method_25760(class_4918.method_25744().method_25751(property, class_4778.field_22180), variant.apply(tallSideModel));
                generator.method_25760(class_4918.method_25744().method_25751(property, class_4778.field_22179), variant.apply(shortSideModel));
                generator.method_25760(terminal, variant.apply(tallSideModel));
            }
        }

        gen.field_22830.accept(generator);
    }

    public void createHangingMoss(class_2248 block) {
        class_4926 dispatch = class_4926.method_25783(HangingMossBlock.TIP)
            .method_25795(value -> {
                String suffix = value ? "_tip" : "";
                class_4944 textureMapping = class_4944.method_25880(class_4944.method_25866(block, suffix));
                class_2960 path = class_4910.class_4913.field_22840.method_25726().method_25847(block, suffix, textureMapping, gen.field_22831);
                return class_4935.method_25824().method_25828(class_4936.field_22887, path);
            });

        gen.method_25600(block);
        gen.field_22830.accept(class_4925.method_25769(block).method_25775(dispatch));
    }

    public void createCreakingHeart(class_2248 block) {
        class_2960 base = class_4946.field_23055.method_25923(block, gen.field_22831);
        class_2960 baseSide = class_4946.field_23056.method_25923(block, gen.field_22831);

        class_2960 awake = createCreakingHeartModel(class_4946.field_23055, block, "_awake");
        class_2960 awakeSide = createCreakingHeartModel(class_4946.field_23056, block, "_awake");
        class_2960 dormant = createCreakingHeartModel(class_4946.field_23055, block, "_dormant");
        class_2960 dormantSide = createCreakingHeartModel(class_4946.field_23056, block, "_dormant");

        class_4926 state = class_4926.method_25784(class_2741.field_12496, CreakingHeartBlock.STATE)
            .method_25797(class_2350.class_2351.field_11052, CreakingHeartState.UPROOTED, createVariant(base, class_4937.field_22890, class_4937.field_22890))
            .method_25797(class_2350.class_2351.field_11051, CreakingHeartState.UPROOTED, createVariant(baseSide, class_4937.field_22891, class_4937.field_22890))
            .method_25797(class_2350.class_2351.field_11048, CreakingHeartState.UPROOTED, createVariant(baseSide, class_4937.field_22891, class_4937.field_22891))
            .method_25797(class_2350.class_2351.field_11052, CreakingHeartState.DORMANT, createVariant(dormant, class_4937.field_22890, class_4937.field_22890))
            .method_25797(class_2350.class_2351.field_11051, CreakingHeartState.DORMANT, createVariant(dormantSide, class_4937.field_22891, class_4937.field_22890))
            .method_25797(class_2350.class_2351.field_11048, CreakingHeartState.DORMANT, createVariant(dormantSide, class_4937.field_22891, class_4937.field_22891))
            .method_25797(class_2350.class_2351.field_11052, CreakingHeartState.AWAKE, createVariant(awake, class_4937.field_22890, class_4937.field_22890))
            .method_25797(class_2350.class_2351.field_11051, CreakingHeartState.AWAKE, createVariant(awakeSide, class_4937.field_22891, class_4937.field_22890))
            .method_25797(class_2350.class_2351.field_11048, CreakingHeartState.AWAKE, createVariant(awakeSide, class_4937.field_22891, class_4937.field_22891));

        gen.field_22830.accept(class_4925.method_25769(block).method_25775(state));
    }

    private class_4935 createVariant(class_2960 model, class_4937 xRot, class_4937 yRot) {
        class_4935 variant = class_4935.method_25824().method_25828(class_4936.field_22887, model);

        if (xRot != class_4937.field_22890) variant = variant.method_25828(class_4936.field_22885, xRot);
        if (yRot != class_4937.field_22890) variant = variant.method_25828(class_4936.field_22886, yRot);

        return variant;
    }

    private class_2960 createCreakingHeartModel(class_4946.class_4947 provider, class_2248 block, String suffix) {
        return provider.method_35912(mapping -> mapping
            .method_25868(class_4945.field_23018, class_4944.method_25866(block, suffix))
            .method_25868(class_4945.field_23013, class_4944.method_25866(block, "_top" + suffix))
        ).method_25922(block, suffix, gen.field_22831);
    }

    public void createMultiface(class_2248 block, class_1792 item) {
        gen.method_25537(item);
        class_2960 model = class_4941.method_25842(block);
        class_4922 generator = class_4922.method_25758(block);
        class_4918.class_4921 terminalCondition = class_156.method_654(
            class_4918.method_25744(),
            condition -> class_4910.field_28548.stream()
                .map(Pair::getFirst)
                .forEach(property -> {
                    if (block.method_9564().method_28498(property)) {
                        condition.method_25751(property, false);
                    }
                })
        );

        for (Pair<class_2746, Function<class_2960, class_4935>> pair : class_4910.field_28548) {
            class_2746 property = pair.getFirst();
            Function<class_2960, class_4935> variant = pair.getSecond();

            if (block.method_9564().method_28498(property)) {
                generator.method_25760(class_4918.method_25744().method_25751(property, true), variant.apply(model));
                generator.method_25760(terminalCondition, variant.apply(model));
            }
        }

        gen.field_22830.accept(generator);
    }

    public void createDriedGhastBlock() {
        class_2960 model = class_4941.method_25843(ModBlocks.DRIED_GHAST.get(), "_hydration_0");
        gen.method_25623(ModBlocks.DRIED_GHAST.get(), model);
        Function<Integer, class_2960> variant = integer -> {
            String string = switch (integer) {
                case 1 -> "_hydration_1";
                case 2 -> "_hydration_2";
                case 3 -> "_hydration_3";
                default -> "_hydration_0";
            };
            class_4944 mapping = TextureMappings.driedGhast(string);
            return ModelTemplates.DRIED_GHAST.method_25847(ModBlocks.DRIED_GHAST.get(), string, mapping, gen.field_22831);
        };

        gen.field_22830
            .accept(
                class_4925.method_25769(ModBlocks.DRIED_GHAST.get())
                    .method_25775(class_4926.method_25783(DriedGhastBlock.HYDRATION_LEVEL).method_25795(level -> class_4935.method_25824().method_25828(class_4936.field_22887, variant.apply(level))))
                    .method_25775(class_4910.method_25599())
            );
    }
}