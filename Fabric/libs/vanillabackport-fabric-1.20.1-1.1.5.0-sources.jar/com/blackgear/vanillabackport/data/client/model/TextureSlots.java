package com.blackgear.vanillabackport.data.client.model;

import com.blackgear.vanillabackport.core.mixin.access.TextureSlotAccessor;
import net.minecraft.class_4945;

public class TextureSlots {
    public static final class_4945 TENTACLES = TextureSlotAccessor.create("tentacles");
}