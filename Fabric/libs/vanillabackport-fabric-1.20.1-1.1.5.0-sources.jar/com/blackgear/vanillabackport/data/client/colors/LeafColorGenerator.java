package com.blackgear.vanillabackport.data.client.colors;

import com.blackgear.vanillabackport.core.VanillaBackport;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2405;
import net.minecraft.class_2960;
import net.minecraft.class_7403;
import net.minecraft.class_7784;
import net.minecraft.class_7923;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.function.Supplier;

public class LeafColorGenerator implements class_2405 {
    private final Map<class_2960, Supplier<JsonElement>> leafColors = new HashMap<>();
    private final class_7784.class_7489 pathProvider;

    public LeafColorGenerator(FabricDataOutput output) {
        this.pathProvider = output.method_45973(class_7784.class_7490.field_39368, "leaf_colors");
    }

    private void addLeafColors() {
        this.add(class_2246.field_28673, -9399763);
        this.add(class_2246.field_28674, -9399763);
    }

    private void add(class_2248 block, int color) {
        class_2960 registry = class_7923.field_41175.method_10221(block);
        class_2960 name = VanillaBackport.vanilla(registry.method_12832());
        this.addElement(name, registry.toString(), color);
    }

    private void add(String block, int color) {
        this.addElement(VanillaBackport.vanilla(block), block, color);
    }

    @Override
    public CompletableFuture<?> method_10319(class_7403 cachedOutput) {
        this.addLeafColors();

        return CompletableFuture.allOf(
            this.leafColors.entrySet().stream()
                .map(entry -> {
                    Path path = this.pathProvider.method_44107(entry.getKey());
                    JsonElement jsonElement = entry.getValue().get();
                    return class_2405.method_10320(cachedOutput, jsonElement, path);
                })
                .toArray(CompletableFuture[]::new)
        );
    }

    public void addElement(class_2960 name, String block, int color) {
        this.addElement(name, block, color, 0);
    }

    public void addElement(class_2960 name, String block, int color, int priority) {
        JsonObject json = new JsonObject();
        json.addProperty("block", block);

        JsonObject properties = new JsonObject();
        properties.addProperty("color", color);
        properties.addProperty("priority", priority);
        json.add("properties", properties);

        if (this.leafColors.put(name, () -> json) != null) {
            throw new IllegalStateException("Duplicate leaf color " + name);
        }
    }

    @Override
    public String method_10321() {
        return "Leaf Color Definitions";
    }
}