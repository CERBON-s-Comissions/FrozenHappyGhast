package com.blackgear.vanillabackport.data.client.model.provider;

import com.google.gson.JsonElement;
import java.util.function.BiConsumer;
import java.util.function.Supplier;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_4915;
import net.minecraft.class_4941;
import net.minecraft.class_4943;
import net.minecraft.class_4944;

public class VanillaItemModels extends class_4915 {
    public VanillaItemModels(BiConsumer<class_2960, Supplier<JsonElement>> output) {
        super(output);
    }

    public void createFlatItem(class_1792 item) {
        this.method_25733(item, class_4943.field_22938);
    }

    public void createFlatItemWithSuffix(class_1792 item, String suffix) {
        class_4943.field_22938.method_25852(class_4941.method_25840(item), class_4944.method_25895(class_4944.method_25863(item, suffix)), this.field_22844);
    }

    public void createMusicDisc(class_1792 item) {
        this.method_25733(item, class_4943.field_44581);
    }
}