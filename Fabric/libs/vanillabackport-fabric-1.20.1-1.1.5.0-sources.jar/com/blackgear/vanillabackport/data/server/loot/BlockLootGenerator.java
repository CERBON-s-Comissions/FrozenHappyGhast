package com.blackgear.vanillabackport.data.server.loot;

import com.blackgear.vanillabackport.common.level.blocks.MossyCarpetBlock;
import com.blackgear.vanillabackport.common.registries.ModBlocks;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.minecraft.class_114;
import net.minecraft.class_141;
import net.minecraft.class_1893;
import net.minecraft.class_1935;
import net.minecraft.class_212;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_42;
import net.minecraft.class_44;
import net.minecraft.class_4559;
import net.minecraft.class_52;
import net.minecraft.class_55;
import net.minecraft.class_5662;
import net.minecraft.class_5778;
import net.minecraft.class_77;
import net.minecraft.class_94;

public class BlockLootGenerator extends FabricBlockLootTableProvider {
    public BlockLootGenerator(FabricDataOutput dataOutput) {
        super(dataOutput);
    }

    @Override
    public void method_10379() {
        // The Garden Awakens
        this.method_46025(ModBlocks.PALE_OAK_PLANKS.get());
        this.method_46025(ModBlocks.PALE_OAK_SAPLING.get());
        this.method_46025(ModBlocks.PALE_OAK_LOG.get());
        this.method_46025(ModBlocks.STRIPPED_PALE_OAK_LOG.get());
        this.method_46025(ModBlocks.PALE_OAK_WOOD.get());
        this.method_46025(ModBlocks.STRIPPED_PALE_OAK_WOOD.get());
        this.method_46025(ModBlocks.PALE_OAK_SIGN.getFirst().get());
        this.method_46025(ModBlocks.PALE_OAK_HANGING_SIGN.getFirst().get());
        this.method_46025(ModBlocks.PALE_OAK_PRESSURE_PLATE.get());
        this.method_46025(ModBlocks.PALE_OAK_TRAPDOOR.get());
        this.method_46025(ModBlocks.PALE_OAK_BUTTON.get());
        this.method_46025(ModBlocks.PALE_OAK_STAIRS.get());
        this.method_46025(ModBlocks.PALE_OAK_FENCE_GATE.get());
        this.method_46025(ModBlocks.PALE_OAK_FENCE.get());
        this.method_45994(ModBlocks.PALE_OAK_SLAB.get(), this::method_45980);
        this.method_45994(ModBlocks.PALE_OAK_DOOR.get(), this::method_46022);
        this.method_45994(ModBlocks.PALE_OAK_LEAVES.get(), block -> this.method_45986(block, ModBlocks.PALE_OAK_SAPLING.get(), field_40605));

        this.method_46025(ModBlocks.OPEN_EYEBLOSSOM.get());
        this.method_46025(ModBlocks.CLOSED_EYEBLOSSOM.get());

        this.method_45994(ModBlocks.PALE_MOSS_CARPET.get(), this::createMossyCarpetBlockDrops);
        this.method_45994(ModBlocks.PALE_HANGING_MOSS.get(), this::createShearsOrSilkTouchOnlyDrop);
        this.method_46025(ModBlocks.PALE_MOSS_BLOCK.get());

        this.method_46023(ModBlocks.POTTED_PALE_OAK_SAPLING.get());
        this.method_46023(ModBlocks.POTTED_OPEN_EYEBLOSSOM.get());
        this.method_46023(ModBlocks.POTTED_CLOSED_EYEBLOSSOM.get());

        this.method_46025(ModBlocks.RESIN_BLOCK.get());
        this.method_46025(ModBlocks.RESIN_BRICKS.get());
        this.method_46025(ModBlocks.RESIN_BRICK_WALL.get());
        this.method_46025(ModBlocks.RESIN_BRICK_STAIRS.get());
        this.method_46025(ModBlocks.CHISELED_RESIN_BRICKS.get());
        this.method_45994(ModBlocks.RESIN_BRICK_SLAB.get(), this::method_45980);
        this.method_45994(ModBlocks.RESIN_CLUMP.get(), this::createMultifaceBlockDrops);

        this.method_45994(
            ModBlocks.CREAKING_HEART.get(),
            block -> method_45989(
                block,
                this.method_45977(
                    block,
                    class_77.method_411(ModBlocks.RESIN_CLUMP.get())
                        .method_438(class_141.method_621(class_5662.method_32462(1.0F, 3.0F)))
                        .method_438(class_94.method_456(class_1893.field_9130))
                        .method_438(class_114.method_506(class_42.method_277(9)))
                )
            )
        );

        // Chase the Skies
        this.method_46025(ModBlocks.DRIED_GHAST.get());

        // Spring to Life
        this.method_46025(ModBlocks.FIREFLY_BUSH.get());
        this.method_45994(ModBlocks.BUSH.get(), this::createShearsOrSilkTouchOnlyDrop);
        this.method_45988(ModBlocks.WILDFLOWERS.get(), this.method_49358(ModBlocks.WILDFLOWERS.get()));
        this.method_45988(ModBlocks.LEAF_LITTER.get(), this.method_49358(ModBlocks.LEAF_LITTER.get()));
        this.method_46025(ModBlocks.CACTUS_FLOWER.get());
        this.method_45994(ModBlocks.SHORT_DRY_GRASS.get(), this::createShearsOrSilkTouchOnlyDrop);
        this.method_45994(ModBlocks.TALL_DRY_GRASS.get(), this::createShearsOrSilkTouchOnlyDrop);
    }

    protected class_52.class_53 createMultifaceBlockDrops(class_2248 block) {
        return class_52.method_324()
            .method_336(
                class_55.method_347()
                    .method_351(
                        this.method_45977(
                            block,
                            class_77.method_411(block)
                                .method_43740(
                                    class_2350.values(),
                                    direction -> class_141.method_35540(class_44.method_32448(1.0F), true)
                                        .method_524(
                                            class_212.method_900(block)
                                                .method_22584(class_4559.class_4560.method_22523().method_22527(class_5778.method_33374(direction), true))
                                        )
                                )
                                .method_438(class_141.method_35540(class_44.method_32448(-1.0F), true))
                        )
                    )
            );
    }

    protected class_52.class_53 createMossyCarpetBlockDrops(class_2248 block) {
        return class_52.method_324()
            .method_336(
                class_55.method_347()
                    .method_351(
                        this.method_45977(
                            block,
                            class_77.method_411(block)
                                .method_421(
                                    class_212.method_900(block)
                                        .method_22584(class_4559.class_4560.method_22523().method_22527(MossyCarpetBlock.BASE, true))
                                )
                        )
                    )
            );
    }

    protected class_52.class_53 createShearsOrSilkTouchOnlyDrop(class_1935 itemLike) {
        return class_52.method_324()
            .method_336(class_55.method_347().method_352(class_44.method_32448(1.0F)).method_356(field_40606).method_351(class_77.method_411(itemLike)));
    }
}