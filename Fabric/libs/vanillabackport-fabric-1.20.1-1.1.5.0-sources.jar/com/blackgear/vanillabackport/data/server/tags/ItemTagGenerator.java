package com.blackgear.vanillabackport.data.server.tags;

import com.blackgear.vanillabackport.common.registries.ModBlocks;
import com.blackgear.vanillabackport.common.registries.ModItems;
import com.blackgear.vanillabackport.core.data.tags.ModItemTags;
import com.blackgear.vanillabackport.core.data.tags.create.CreateItemTags;
import com.blackgear.vanillabackport.core.data.tags.fabric.FabricItemTags;
import com.blackgear.vanillabackport.core.data.tags.forge.ForgeItemTags;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1935;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_3489;
import net.minecraft.class_6862;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;

public class ItemTagGenerator extends FabricTagProvider.ItemTagProvider {
    public ItemTagGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected void method_10514(class_7225.class_7874 provider) {
        new BlockItemTagGenerator() {
            @Override
            protected TagHolder tag(class_6862<class_2248> block, class_6862<class_1792> item) {
            return new TagHolder(ItemTagGenerator.this.getOrCreateTagBuilder(item), null);
            }
        }.addTags();
        this.handleConventionalTags();

        this.getOrCreateTagBuilder(class_3489.field_15536)
            .add(ModItems.PALE_OAK_BOAT.get());

        this.getOrCreateTagBuilder(class_3489.field_38080)
            .add(ModItems.PALE_OAK_CHEST_BOAT.get());

        this.getOrCreateTagBuilder(ModItemTags.BUNDLES)
            .add(
                class_1802.field_27023,
                ModItems.BLACK_BUNDLE.get(),
                ModItems.BLUE_BUNDLE.get(),
                ModItems.BROWN_BUNDLE.get(),
                ModItems.CYAN_BUNDLE.get(),
                ModItems.GRAY_BUNDLE.get(),
                ModItems.GREEN_BUNDLE.get(),
                ModItems.LIGHT_BLUE_BUNDLE.get(),
                ModItems.LIGHT_GRAY_BUNDLE.get(),
                ModItems.LIME_BUNDLE.get(),
                ModItems.MAGENTA_BUNDLE.get(),
                ModItems.ORANGE_BUNDLE.get(),
                ModItems.PINK_BUNDLE.get(),
                ModItems.PURPLE_BUNDLE.get(),
                ModItems.RED_BUNDLE.get(),
                ModItems.YELLOW_BUNDLE.get(),
                ModItems.WHITE_BUNDLE.get()
            );

        this.getOrCreateTagBuilder(class_3489.field_15541)
            .add(ModItems.MUSIC_DISC_TEARS.get(), ModItems.MUSIC_DISC_LAVA_CHICKEN.get());

        this.getOrCreateTagBuilder(class_3489.field_41891)
            .add(ModItems.RESIN_BRICK.get());

        this.getOrCreateTagBuilder(ModItemTags.HARNESSES)
            .add(
                ModItems.WHITE_HARNESS.get(),
                ModItems.ORANGE_HARNESS.get(),
                ModItems.MAGENTA_HARNESS.get(),
                ModItems.LIGHT_BLUE_HARNESS.get(),
                ModItems.YELLOW_HARNESS.get(),
                ModItems.LIME_HARNESS.get(),
                ModItems.PINK_HARNESS.get(),
                ModItems.GRAY_HARNESS.get(),
                ModItems.LIGHT_GRAY_HARNESS.get(),
                ModItems.CYAN_HARNESS.get(),
                ModItems.PURPLE_HARNESS.get(),
                ModItems.BLUE_HARNESS.get(),
                ModItems.BROWN_HARNESS.get(),
                ModItems.GREEN_HARNESS.get(),
                ModItems.RED_HARNESS.get(),
                ModItems.BLACK_HARNESS.get()
            );

        this.getOrCreateTagBuilder(ModItemTags.HAPPY_GHAST_FOOD)
            .add(class_1802.field_8543);

        this.getOrCreateTagBuilder(ModItemTags.HAPPY_GHAST_TEMPT_ITEMS)
            .method_26792(ModItemTags.HAPPY_GHAST_FOOD)
            .method_26792(ModItemTags.HARNESSES);

        this.getOrCreateTagBuilder(ModItemTags.EGGS)
            .add(class_1802.field_8803, ModItems.BLUE_EGG.get(), ModItems.BROWN_EGG.get());
    }

    private void handleConventionalTags() {
        this.getDualTagBuilder(ForgeItemTags.EGGS, FabricItemTags.EGGS)
            .addTag(ModItemTags.EGGS);
        
        this.getDualTagBuilder(ForgeItemTags.DYED, FabricItemTags.DYED)
            .addTag(ModItemTags.HARNESSES)
            .add(
                ModItems.BLACK_BUNDLE.get(),
                ModItems.BLUE_BUNDLE.get(),
                ModItems.BROWN_BUNDLE.get(),
                ModItems.CYAN_BUNDLE.get(),
                ModItems.GRAY_BUNDLE.get(),
                ModItems.GREEN_BUNDLE.get(),
                ModItems.LIGHT_BLUE_BUNDLE.get(),
                ModItems.LIGHT_GRAY_BUNDLE.get(),
                ModItems.LIME_BUNDLE.get(),
                ModItems.MAGENTA_BUNDLE.get(),
                ModItems.ORANGE_BUNDLE.get(),
                ModItems.PINK_BUNDLE.get(),
                ModItems.PURPLE_BUNDLE.get(),
                ModItems.RED_BUNDLE.get(),
                ModItems.YELLOW_BUNDLE.get(),
                ModItems.WHITE_BUNDLE.get()
            );

        this.getDualTagBuilder(ForgeItemTags.DYED_BLACK, FabricItemTags.DYED_BLACK)
            .add(ModItems.BLACK_BUNDLE.get(), ModItems.BLACK_HARNESS.get());

        this.getDualTagBuilder(ForgeItemTags.DYED_BLUE, FabricItemTags.DYED_BLUE)
            .add(ModItems.BLUE_BUNDLE.get(), ModItems.BLUE_HARNESS.get());

        this.getDualTagBuilder(ForgeItemTags.DYED_BROWN, FabricItemTags.DYED_BROWN)
            .add(ModItems.BROWN_BUNDLE.get(), ModItems.BROWN_HARNESS.get());

        this.getDualTagBuilder(ForgeItemTags.DYED_CYAN, FabricItemTags.DYED_CYAN)
            .add(ModItems.CYAN_BUNDLE.get(), ModItems.CYAN_HARNESS.get());

        this.getDualTagBuilder(ForgeItemTags.DYED_GRAY, FabricItemTags.DYED_GRAY)
            .add(ModItems.GRAY_BUNDLE.get(), ModItems.GRAY_HARNESS.get());

        this.getDualTagBuilder(ForgeItemTags.DYED_GREEN, FabricItemTags.DYED_GREEN)
            .add(ModItems.GREEN_BUNDLE.get(), ModItems.GREEN_HARNESS.get());

        this.getDualTagBuilder(ForgeItemTags.DYED_LIGHT_BLUE, FabricItemTags.DYED_LIGHT_BLUE)
            .add(ModItems.LIGHT_BLUE_BUNDLE.get(), ModItems.LIGHT_BLUE_HARNESS.get());

        this.getDualTagBuilder(ForgeItemTags.DYED_LIGHT_GRAY, FabricItemTags.DYED_LIGHT_GRAY)
            .add(ModItems.LIGHT_GRAY_BUNDLE.get(), ModItems.LIGHT_GRAY_HARNESS.get());

        this.getDualTagBuilder(ForgeItemTags.DYED_LIME, FabricItemTags.DYED_LIME)
            .add(ModItems.LIME_BUNDLE.get(), ModItems.LIME_HARNESS.get());

        this.getDualTagBuilder(ForgeItemTags.DYED_MAGENTA, FabricItemTags.DYED_MAGENTA)
            .add(ModItems.MAGENTA_BUNDLE.get(), ModItems.MAGENTA_HARNESS.get());

        this.getDualTagBuilder(ForgeItemTags.DYED_ORANGE, FabricItemTags.DYED_ORANGE)
            .add(ModItems.ORANGE_BUNDLE.get(), ModItems.ORANGE_HARNESS.get());

        this.getDualTagBuilder(ForgeItemTags.DYED_PINK, FabricItemTags.DYED_PINK)
            .add(ModItems.PINK_BUNDLE.get(), ModItems.PINK_HARNESS.get());

        this.getDualTagBuilder(ForgeItemTags.DYED_PURPLE, FabricItemTags.DYED_PURPLE)
            .add(ModItems.PURPLE_BUNDLE.get(), ModItems.PURPLE_HARNESS.get());

        this.getDualTagBuilder(ForgeItemTags.DYED_RED, FabricItemTags.DYED_RED)
            .add(ModItems.RED_BUNDLE.get(), ModItems.RED_HARNESS.get());

        this.getDualTagBuilder(ForgeItemTags.DYED_YELLOW, FabricItemTags.DYED_YELLOW)
            .add(ModItems.YELLOW_BUNDLE.get(), ModItems.YELLOW_HARNESS.get());

        this.getDualTagBuilder(ForgeItemTags.DYED_WHITE, FabricItemTags.DYED_WHITE)
            .add(ModItems.WHITE_BUNDLE.get(), ModItems.WHITE_HARNESS.get());

        this.getDualTagBuilder(ForgeItemTags.MUSIC_DISCS, FabricItemTags.MUSIC_DISCS)
            .add(ModItems.MUSIC_DISC_TEARS.get(), ModItems.MUSIC_DISC_LAVA_CHICKEN.get());

        this.getOrCreateTagBuilder(CreateItemTags.MODDED_STRIPPED_WOOD)
            .add(ModBlocks.STRIPPED_PALE_OAK_WOOD.get().method_8389());

        this.getOrCreateTagBuilder(CreateItemTags.MODDED_STRIPPED_LOGS)
            .add(ModBlocks.STRIPPED_PALE_OAK_LOG.get().method_8389());
    }

    protected DualTagHolder getDualTagBuilder(class_6862<class_1792> forge, class_6862<class_1792> fabric) {
        return new DualTagHolder(this.getOrCreateTagBuilder(fabric), this.getOrCreateTagBuilder(forge));
    }

    protected record DualTagHolder(FabricTagProvider<class_1792>.FabricTagBuilder forge, FabricTagProvider<class_1792>.FabricTagBuilder fabric) {
        public DualTagHolder add(class_1935 entry) {
            this.forge.add(entry.method_8389());
            this.fabric.add(entry.method_8389());
            return this;
        }

        public DualTagHolder add(class_1792... toAdd) {
            this.forge.add(toAdd);
            this.fabric.add(toAdd);
            return this;
        }

        public DualTagHolder addOptional(class_2960 location) {
            this.forge.method_35922(location);
            this.fabric.method_35922(location);
            return this;
        }

        public DualTagHolder addTag(class_6862<class_1792> tag) {
            this.forge.method_26792(tag);
            this.fabric.method_26792(tag);
            return this;
        }

        public DualTagHolder addOptionalTag(class_6862<class_1792> tag) {
            this.forge.addOptionalTag(tag);
            this.fabric.addOptionalTag(tag);
            return this;
        }
    }
}