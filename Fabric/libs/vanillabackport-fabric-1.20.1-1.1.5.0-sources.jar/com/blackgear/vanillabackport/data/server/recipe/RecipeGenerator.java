package com.blackgear.vanillabackport.data.server.recipe;

import com.blackgear.vanillabackport.common.registries.ModBlocks;
import com.blackgear.vanillabackport.common.registries.ModItems;
import com.blackgear.vanillabackport.common.registries.ModRecipeSerializers;
import com.blackgear.vanillabackport.core.data.tags.ModItemTags;
import com.blackgear.vanillabackport.data.client.BlockFamilies;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_1935;
import net.minecraft.class_2246;
import net.minecraft.class_2444;
import net.minecraft.class_2447;
import net.minecraft.class_2450;
import net.minecraft.class_2454;
import net.minecraft.class_2456;
import net.minecraft.class_7699;
import net.minecraft.class_7701;
import net.minecraft.class_7800;
import net.minecraft.data.recipes.*;
import java.util.function.Consumer;

public class RecipeGenerator extends FabricRecipeProvider {
    public RecipeGenerator(FabricDataOutput output) {
        super(output);
    }

    @Override
    public void method_10419(Consumer<class_2444> exporter) {
        BlockFamilies.getAllFamilies()
            .filter(family -> family.method_33478(class_7699.method_45398(class_7701.field_40177)))
            .forEach(family -> method_33535(exporter, family));
        method_24475(exporter, ModBlocks.PALE_OAK_PLANKS.get(), ModItemTags.PALE_OAK_LOGS, 4);
        method_24476(exporter, ModBlocks.PALE_OAK_WOOD.get(), ModBlocks.PALE_OAK_LOG.get());
        method_24476(exporter, ModBlocks.STRIPPED_PALE_OAK_WOOD.get(), ModBlocks.STRIPPED_PALE_OAK_LOG.get());
        method_24478(exporter, ModItems.PALE_OAK_BOAT.get(), ModBlocks.PALE_OAK_PLANKS.get());
        method_42754(exporter, ModItems.PALE_OAK_CHEST_BOAT.get(), ModItems.PALE_OAK_BOAT.get());
        method_46208(exporter, ModBlocks.PALE_OAK_HANGING_SIGN.getFirst().get(), ModBlocks.STRIPPED_PALE_OAK_LOG.get());
        method_24885(exporter, ModBlocks.PALE_MOSS_CARPET.get(), ModBlocks.PALE_MOSS_BLOCK.get());

        method_36444(exporter, class_1802.field_8492, ModBlocks.OPEN_EYEBLOSSOM.get(), "orange_dye");
        method_36444(exporter, class_1802.field_8298, ModBlocks.CLOSED_EYEBLOSSOM.get(), "gray_dye");

        method_46209(exporter, class_7800.field_40634, ModBlocks.RESIN_BRICKS.get(), ModItems.RESIN_BRICK.get());
        method_36325(exporter, class_7800.field_40642, ModBlocks.RESIN_CLUMP.get(), class_7800.field_40634, ModBlocks.RESIN_BLOCK.get());
        shaped(class_7800.field_40642, ModBlocks.CREAKING_HEART.get())
            .method_10434('R', ModBlocks.RESIN_BLOCK.get())
            .method_10434('L', ModBlocks.PALE_OAK_LOG.get())
            .method_10439(" L ")
            .method_10439(" R ")
            .method_10439(" L ")
            .method_10429("has_resin_block", method_10426(ModBlocks.RESIN_BLOCK.get()))
            .method_10431(exporter);
        class_2454.method_17802(class_1856.method_8091(ModBlocks.RESIN_CLUMP.get()), class_7800.field_40642, ModItems.RESIN_BRICK.get(), 0.1f, 200)
            .method_10469("has_resin_clump", method_10426(ModBlocks.RESIN_CLUMP.get()))
            .method_10431(exporter);
        method_33715(exporter, class_7800.field_40634, ModBlocks.RESIN_BRICK_SLAB.get(), ModBlocks.RESIN_BRICKS.get(), 2);
        method_33717(exporter, class_7800.field_40634, ModBlocks.RESIN_BRICK_STAIRS.get(), ModBlocks.RESIN_BRICKS.get());
        method_33717(exporter, class_7800.field_40634, ModBlocks.RESIN_BRICK_WALL.get(), ModBlocks.RESIN_BRICKS.get());
        method_33717(exporter, class_7800.field_40634, ModBlocks.CHISELED_RESIN_BRICKS.get(), ModBlocks.RESIN_BRICKS.get());

        this.dryGhast(exporter, ModBlocks.DRIED_GHAST.get());

        this.harness(exporter, ModItems.WHITE_HARNESS.get(), class_2246.field_10446);
        this.harness(exporter, ModItems.ORANGE_HARNESS.get(), class_2246.field_10095);
        this.harness(exporter, ModItems.MAGENTA_HARNESS.get(), class_2246.field_10215);
        this.harness(exporter, ModItems.LIGHT_BLUE_HARNESS.get(), class_2246.field_10294);
        this.harness(exporter, ModItems.YELLOW_HARNESS.get(), class_2246.field_10490);
        this.harness(exporter, ModItems.LIME_HARNESS.get(), class_2246.field_10028);
        this.harness(exporter, ModItems.PINK_HARNESS.get(), class_2246.field_10459);
        this.harness(exporter, ModItems.GRAY_HARNESS.get(), class_2246.field_10423);
        this.harness(exporter, ModItems.LIGHT_GRAY_HARNESS.get(), class_2246.field_10222);
        this.harness(exporter, ModItems.CYAN_HARNESS.get(), class_2246.field_10619);
        this.harness(exporter, ModItems.PURPLE_HARNESS.get(), class_2246.field_10259);
        this.harness(exporter, ModItems.BLUE_HARNESS.get(), class_2246.field_10514);
        this.harness(exporter, ModItems.BROWN_HARNESS.get(), class_2246.field_10113);
        this.harness(exporter, ModItems.GREEN_HARNESS.get(), class_2246.field_10170);
        this.harness(exporter, ModItems.RED_HARNESS.get(), class_2246.field_10314);
        this.harness(exporter, ModItems.BLACK_HARNESS.get(), class_2246.field_10146);

        shaped(class_7800.field_40639, class_1802.field_8175)
            .method_10434('X', class_1802.field_8745)
            .method_10434('#', class_1802.field_8620)
            .method_10439(" X ")
            .method_10439("X#X")
            .method_10429("has_leather", method_10426(class_1802.field_8745))
            .method_10431(exporter);
        shaped(class_7800.field_40638, class_1802.field_8719, 2)
            .method_10434('~', class_1802.field_8276)
            .method_10439("~~ ")
            .method_10439("~~ ")
            .method_10439("  ~")
            .method_10429("has_string", method_10426(class_1802.field_8276))
            .method_10431(exporter);

        method_36444(exporter, class_1802.field_8330, ModBlocks.CACTUS_FLOWER.get(), "pink_dye");

        shaped(class_7800.field_40635, class_2246.field_23261)
            .method_10434('S', class_1802.field_8525)
            .method_10434('#', class_1802.field_8620)
            .method_10439("SSS")
            .method_10439("S#S")
            .method_10439("SSS")
            .method_10429("has_iron_ingot", method_10426(class_1802.field_8620))
            .method_10429("has_lodestone", method_10426(class_1802.field_23256))
            .method_10431(exporter);

        shaped(class_7800.field_40638, class_1802.field_27023)
            .method_10434('-', class_1802.field_8276)
            .method_10434('#', class_1802.field_8745)
            .method_10439("-")
            .method_10439("#")
            .method_10429("has_string", method_10426(class_1802.field_8276))
            .method_10431(exporter);

        class_2450.method_10447(class_7800.field_40640, class_1802.field_8741)
            .method_10454(class_2246.field_10261)
            .method_10454(class_1802.field_8479)
            .method_10446(ModItemTags.EGGS)
            .method_10442("has_carved_pumpkin", method_10426(class_2246.field_10147))
            .method_10442("has_pumpkin", method_10426(class_2246.field_10261))
            .method_10431(exporter);

        shaped(class_7800.field_40640, class_2246.field_10183)
            .method_10434('A', class_1802.field_8103)
            .method_10434('B', class_1802.field_8479)
            .method_10434('C', class_1802.field_8861)
            .method_10433('E', ModItemTags.EGGS)
            .method_10439("AAA")
            .method_10439("BEB")
            .method_10439("CCC")
            .method_10429("has_egg", method_10420(ModItemTags.EGGS))
            .method_10431(exporter);

        class_2456.method_10476(ModRecipeSerializers.BUNDLE_COLORING.get()).method_10475(exporter, "bundle_coloring");
    }

    public static class_2447 shaped(class_7800 category, class_1935 entry) {
        return class_2447.method_10437(category, entry);
    }

    public static class_2447 shaped(class_7800 category, class_1935 entry, int amount) {
        return class_2447.method_10436(category, entry, amount);
    }

    private void dryGhast(Consumer<class_2444> exporter, class_1935 ghast) {
        class_2447.method_10437(class_7800.field_40634, ghast)
            .method_10434('#', class_1802.field_8070)
            .method_10434('X', class_1802.field_8067)
            .method_10439("###")
            .method_10439("#X#")
            .method_10439("###")
            .method_10435("dry_ghast")
            .method_10429(method_32807(class_1802.field_8070), method_10426(class_1802.field_8070))
            .method_10431(exporter);
    }

    private void harness(Consumer<class_2444> exporter, class_1935 harness, class_1935 carpet) {
        class_2447.method_10437(class_7800.field_40637, harness)
            .method_10434('#', carpet)
            .method_10434('G', class_1802.field_8280)
            .method_10434('L', class_1802.field_8745)
            .method_10439("LLL")
            .method_10439("G#G")
            .method_10435("harness")
            .method_10429("has_dried_ghast", method_10426(ModBlocks.DRIED_GHAST.get()))
            .method_10431(exporter);
    }
}