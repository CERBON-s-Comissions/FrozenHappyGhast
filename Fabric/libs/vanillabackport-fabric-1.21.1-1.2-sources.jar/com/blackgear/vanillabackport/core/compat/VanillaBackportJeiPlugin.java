package com.blackgear.vanillabackport.core.compat;

import com.blackgear.vanillabackport.common.api.modules.bundle_ui.BundleFeatures;
import com.blackgear.vanillabackport.common.api.modules.bundle_ui.BundleColoring;
import com.blackgear.vanillabackport.core.VanillaBackport;
import mezz.jei.api.IModPlugin;
import mezz.jei.api.JeiPlugin;
import mezz.jei.api.constants.RecipeTypes;
import mezz.jei.api.registration.IRecipeRegistration;
import net.minecraft.class_1767;
import net.minecraft.class_1769;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1863;
import net.minecraft.class_1867;
import net.minecraft.class_2371;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3955;
import net.minecraft.class_3956;
import net.minecraft.class_7710;
import net.minecraft.class_7923;
import net.minecraft.class_8786;
import net.minecraft.world.item.*;
import net.minecraft.world.item.crafting.*;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@JeiPlugin
public class VanillaBackportJeiPlugin implements IModPlugin {
    @Override
    public void registerRecipes(IRecipeRegistration registration) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null) return;

        class_1863 recipeManager = mc.field_1687.method_8433();

        boolean hasBundleColoring = recipeManager
            .method_30027(class_3956.field_17545)
            .stream()
            .map(class_8786::comp_1933)
            .anyMatch(r -> r instanceof BundleColoring);

        if (!hasBundleColoring) return;

        Map<class_1767, List<class_1792>> dyesByColor = getDyesByColor();
        List<class_1792> allBundles = getBundles();
        
        List<class_8786<class_3955>> extraRecipes = new ArrayList<>(class_1767.values().length);

        for (class_1767 dyeColor : class_1767.values()) {
            class_1792 resultBundle = BundleFeatures.getByColor(dyeColor);
            List<class_1792> dyeItems = dyesByColor.get(dyeColor);
            if (resultBundle == null || dyeItems == null || dyeItems.isEmpty()) continue;

            class_1799[] otherBundlesStacks = allBundles.stream()
                .filter(item -> item != resultBundle)
                .map(class_1799::new)
                .toArray(class_1799[]::new);

            if (otherBundlesStacks.length == 0) continue;

            class_1856 anyOtherBundle = class_1856.method_8101(otherBundlesStacks);
            class_1856 dyeChoices = class_1856.method_26964(dyeItems.stream().map(class_1799::new));

            class_2371<class_1856> inputs = class_2371.method_10212(class_1856.field_9017, anyOtherBundle, dyeChoices);
            class_1799 output = new class_1799(resultBundle);

            class_2960 baseId = class_7923.field_41178.method_10221(resultBundle);
            class_2960 displayId = class_2960.method_60655(baseId.method_12836(), "/" + baseId.method_12832());

            class_1867 recipe = new class_1867("", class_7710.field_40251, output, inputs);
            extraRecipes.add(new class_8786<>(displayId, recipe));
        }

        registration.addRecipes(RecipeTypes.CRAFTING, extraRecipes);
    }

    private static List<class_1792> getBundles() {
        return List.copyOf(BundleFeatures.BUNDLES_BY_DYE.values());
    }

    private static Map<class_1767, List<class_1792>> getDyesByColor() {
        return class_7923.field_41178.method_10220()
            .filter(class_1769.class::isInstance)
            .map(class_1769.class::cast)
            .collect(Collectors.groupingBy(
                class_1769::method_7802,
                () -> new EnumMap<>(class_1767.class),
                Collectors.mapping(d -> (class_1792) d, Collectors.toList())
            ));
    }

    @Override
    public class_2960 getPluginUid() {
        return VanillaBackport.resource("jei_plugin");
    }
}