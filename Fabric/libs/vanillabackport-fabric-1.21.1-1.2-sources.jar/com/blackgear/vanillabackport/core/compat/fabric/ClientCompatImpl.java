package com.blackgear.vanillabackport.core.compat.fabric;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1309;
import net.minecraft.class_1428;
import net.minecraft.class_1430;
import net.minecraft.class_1452;
import net.minecraft.class_7102;
import java.util.Optional;

@Environment(EnvType.CLIENT)
public class ClientCompatImpl {
    public static boolean getNMLActiveRemodel(class_1309 entity) {
        return false;
    }
    
    public static boolean hasQuarkCowTexture(class_1430 cow) {
        return false;
    }
    
    public static boolean hasQuarkPigTexture(class_1452 pig) {
        return false;
    }
    
    public static boolean hasQuarkChickenTexture(class_1428 chicken) {
        return false;
    }
    
    public static boolean hasQuarkFrogTexture(class_7102 frog) {
        return false;
    }
}