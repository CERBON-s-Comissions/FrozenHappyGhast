package com.blackgear.vanillabackport.core.fabric.mixin;

import com.bawnorton.mixinsquared.TargetHandler;
import com.blackgear.platform.core.fabric.CoreRegistryImpl;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import java.util.Set;
import net.minecraft.class_2370;
import net.minecraft.class_5321;

@SuppressWarnings("UnresolvedMixinReference")
@Mixin(value = class_2370.class, priority = 1500)
public abstract class MappedRegistryMixin<T> {
    @TargetHandler(
        mixin = "net.fabricmc.fabric.mixin.registry.sync.SimpleRegistryMixin",
        name = "onChange"
    )
    @WrapOperation(
        method = "@MixinSquared:Handler",
        at = @At(
            value = "INVOKE",
            target = "Ljava/util/Set;contains(Ljava/lang/Object;)Z",
            remap = false
        )
    )
    private boolean shouldSkipVanillaRegistry(
        Set<String> vanillaNamespaces,
        Object namespace,
        Operation<Boolean> original,
        class_5321<T> registryKey
    ) {
        boolean isVanillaNamespace = original.call(vanillaNamespaces, namespace);
        if (isVanillaNamespace && CoreRegistryImpl.VANILLA_KEYS.contains(registryKey)) {
            return false;
        }

        return isVanillaNamespace;
    }
}