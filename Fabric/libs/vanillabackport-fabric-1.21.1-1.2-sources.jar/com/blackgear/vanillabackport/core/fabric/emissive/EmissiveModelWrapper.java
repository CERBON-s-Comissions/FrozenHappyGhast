package com.blackgear.vanillabackport.core.fabric.emissive;

import com.blackgear.vanillabackport.client.api.modules.models.EmissiveQuad;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.renderer.v1.mesh.MutableQuadView;
import net.fabricmc.fabric.api.renderer.v1.model.ForwardingBakedModel;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.minecraft.class_1087;
import net.minecraft.class_1799;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

@Environment(EnvType.CLIENT)
public class EmissiveModelWrapper extends ForwardingBakedModel {
    private static final int FULL_BRIGHT_LIGHTMAP = 0x00F000F0;

    private final class_1087 emissiveModel;

    public EmissiveModelWrapper(class_1087 baseModel, class_1087 emissiveModel) {
        this.wrapped = baseModel;
        this.emissiveModel = emissiveModel;
    }

    @Override
    public boolean isVanillaAdapter() {
        return false;
    }

    @Override
    public void emitBlockQuads(class_1920 blockView, class_2680 state, class_2338 pos, Supplier<class_5819> randomSupplier, RenderContext context) {
        super.emitBlockQuads(blockView, state, pos, randomSupplier, context);

        context.pushTransform(EmissiveModelWrapper::forceFullBright);
        emissiveModel.emitBlockQuads(blockView, state, pos, randomSupplier, context);
        context.popTransform();
    }

    @Override
    public void emitItemQuads(class_1799 stack, Supplier<class_5819> randomSupplier, RenderContext context) {
        super.emitItemQuads(stack, randomSupplier, context);

        context.pushTransform(EmissiveModelWrapper::forceFullBright);
        emissiveModel.emitItemQuads(stack, randomSupplier, context);
        context.popTransform();
    }

    private static boolean forceFullBright(MutableQuadView quad) {
        quad.lightmap(0, FULL_BRIGHT_LIGHTMAP);
        quad.lightmap(1, FULL_BRIGHT_LIGHTMAP);
        quad.lightmap(2, FULL_BRIGHT_LIGHTMAP);
        quad.lightmap(3, FULL_BRIGHT_LIGHTMAP);
        return true;
    }

    @Override
    public List<class_777> method_4707(@Nullable class_2680 state, @Nullable class_2350 face, class_5819 random) {
        List<class_777> quads = new ArrayList<>(wrapped.method_4707(state, face, random));

        List<class_777> emissiveQuads = emissiveModel.method_4707(state, face, random);
        for (class_777 quad : emissiveQuads) {
            quads.add(new EmissiveQuad(quad));
        }

        return quads;
    }
}