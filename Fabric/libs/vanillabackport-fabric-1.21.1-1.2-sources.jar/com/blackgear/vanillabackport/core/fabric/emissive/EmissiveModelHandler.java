package com.blackgear.vanillabackport.core.fabric.emissive;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelLoadingPlugin;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelModifier;
import net.minecraft.class_1087;
import net.minecraft.class_1091;
import net.minecraft.class_2960;

@Environment(EnvType.CLIENT)
public class EmissiveModelHandler implements ClientModInitializer {
    private static final String[] EMISSIVE_BLOCKS = {
        "open_eyeblossom",
        "potted_open_eyeblossom",
        "firefly_bush"
    };

    @Override
    public void onInitializeClient() {
        ModelLoadingPlugin.register(pluginContext -> {
            pluginContext.addModels(getEmissiveModelLocations());
            pluginContext.modifyModelAfterBake().register(ModelModifier.WRAP_PHASE, (model, context) -> {
                class_1091 modelLocation = context.topLevelId();

                if (modelLocation == null) return model;
                if (!modelLocation.comp_2876().isEmpty()) return model;

                class_2960 id = modelLocation.comp_2875();

                if (!id.method_12836().equals(class_2960.field_33381)) return model;

                String path = id.method_12832();

                for (String blockName : EMISSIVE_BLOCKS) {
                    if (!path.equals(blockName) && !path.equals("block/" + blockName)) continue;

                    class_2960 emissiveModelId = emissiveModel(blockName);
                    class_1087 emissiveModel = context.baker().method_45873(emissiveModelId, context.settings());

                    if (emissiveModel != null) {
                        return new EmissiveModelWrapper(model, emissiveModel);
                    }
                }

                return model;
            });
        });
    }

    private static class_2960 emissiveModel(String blockName) {
        return class_2960.method_60656("block/" + blockName + "_emissive");
    }

    private static class_2960[] getEmissiveModelLocations() {
        class_2960[] locations = new class_2960[EMISSIVE_BLOCKS.length];
        for (int i = 0; i < EMISSIVE_BLOCKS.length; i++) {
            locations[i] = emissiveModel(EMISSIVE_BLOCKS[i]);
        }
        return locations;
    }
}