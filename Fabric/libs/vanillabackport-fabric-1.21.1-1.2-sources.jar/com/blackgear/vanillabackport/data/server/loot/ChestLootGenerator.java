package com.blackgear.vanillabackport.data.server.loot;

import com.blackgear.vanillabackport.common.registries.ModMapDecorationTypes;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import com.blackgear.vanillabackport.common.registries.items.ModItems;
import com.blackgear.vanillabackport.common.registries.worldgen.ModBiomes;
import com.blackgear.vanillabackport.core.data.ModBuiltInLootTables;
import com.blackgear.vanillabackport.core.data.tags.ModStructureTags;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.SimpleFabricLootTableProvider;
import net.minecraft.class_111;
import net.minecraft.class_141;
import net.minecraft.class_173;
import net.minecraft.class_1802;
import net.minecraft.class_1847;
import net.minecraft.class_1959;
import net.minecraft.class_1972;
import net.minecraft.class_205;
import net.minecraft.class_2090;
import net.minecraft.class_21;
import net.minecraft.class_2561;
import net.minecraft.class_3195;
import net.minecraft.class_3670;
import net.minecraft.class_44;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_55;
import net.minecraft.class_5662;
import net.minecraft.class_6662;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_6885;
import net.minecraft.class_7045;
import net.minecraft.class_7225;
import net.minecraft.class_77;
import net.minecraft.class_7871;
import net.minecraft.class_7924;
import net.minecraft.class_85;
import net.minecraft.class_9428;
import net.minecraft.world.level.storage.loot.functions.*;
import org.jetbrains.annotations.Nullable;

import java.util.concurrent.CompletableFuture;
import java.util.function.BiConsumer;

public class ChestLootGenerator extends SimpleFabricLootTableProvider {
    private final class_7871<class_1959> biomes;
    
    public ChestLootGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> lookup) {
        super(output, lookup, class_173.field_1179);
        class_7225.class_7874 registries = lookup.resultNow();
        this.biomes = registries.method_46762(class_7924.field_41236);
    }

    @Override
    public void method_10399(BiConsumer<class_5321<class_52>, class_52.class_53> output) {
        output.accept(
            ModBuiltInLootTables.ABANDONED_CAMP_BARREL,
            class_52.method_324()
                .method_336(
                    class_55.method_347()
                        .method_352(class_5662.method_32462(4, 8))
                        .method_351(class_77.method_411(class_1802.field_8107).method_437(1).method_438(class_141.method_621(class_5662.method_32462(1, 3))))
                        .method_351(class_77.method_411(class_1802.field_8606).method_437(1).method_438(class_141.method_621(class_5662.method_32462(2, 4))))
                        .method_351(class_77.method_411(class_1802.field_8428).method_437(1).method_438(class_141.method_621(class_5662.method_32462(1, 2))))
                        .method_351(class_77.method_411(class_1802.field_8229).method_437(1).method_438(class_141.method_621(class_5662.method_32462(1, 3))))
                        .method_351(class_77.method_411(class_1802.field_8713).method_437(1).method_438(class_141.method_621(class_5662.method_32462(2, 4))))
                        .method_351(class_77.method_411(class_1802.field_8786).method_437(1).method_438(class_141.method_621(class_44.method_32448(1))))
                        .method_351(class_77.method_411(class_1802.field_8469).method_437(1).method_438(class_141.method_621(class_5662.method_32462(1, 3))))
                        .method_351(class_77.method_411(class_1802.field_8745).method_437(1).method_438(class_141.method_621(class_5662.method_32462(1, 3))))
                        .method_351(class_77.method_411(class_1802.field_8245).method_437(1).method_438(class_141.method_621(class_5662.method_32462(1, 4))))
                        .method_351(class_77.method_411(class_1802.field_8276).method_437(1).method_438(class_141.method_621(class_5662.method_32462(1, 2))))
                        .method_351(class_77.method_411(class_1802.field_8861).method_437(1).method_438(class_141.method_621(class_5662.method_32462(1, 4))))
                        .method_351(class_77.method_411(class_1802.field_27025).method_437(1).method_438(class_141.method_621(class_5662.method_32462(1, 3))))
                        .method_351(class_77.method_411(ModItems.WHITE_CUSHION.get()).method_437(1).method_438(class_141.method_621(class_5662.method_32462(1, 2))))
                        .method_351(class_77.method_411(ModBlocks.STRAW_BED.get()).method_437(1).method_438(class_141.method_621(class_5662.method_32462(2, 4))))
                )
                .method_336(
                    class_55.method_347()
                        .method_352(class_44.method_32448(1))
                        .method_351(class_77.method_411(class_1802.field_27023).method_437(1).method_438(class_141.method_621(class_44.method_32448(1))))
                        .method_351(class_77.method_411(class_1802.field_8406).method_437(1).method_438(class_141.method_621(class_44.method_32448(1))))
                        .method_351(class_77.method_411(class_1802.field_8378).method_437(1).method_438(class_141.method_621(class_44.method_32448(1))))
                )
        );
        output.accept(
            ModBuiltInLootTables.ABANDONED_CAMP_COMMON_CHEST,
            class_52.method_324()
                .method_336(
                    class_55.method_347()
                        .method_352(class_5662.method_32462(4, 6))
                        .method_351(class_77.method_411(class_1802.field_8107).method_437(1).method_438(class_141.method_621(class_44.method_32448(4))))
                        .method_351(class_77.method_411(class_1802.field_8895).method_437(1).method_438(class_141.method_621(class_44.method_32448(1))))
                        .method_351(class_77.method_411(class_1802.field_8606).method_437(1).method_438(class_141.method_621(class_5662.method_32462(2, 4))))
                        .method_351(class_77.method_411(class_1802.field_8786).method_437(1).method_438(class_141.method_621(class_44.method_32448(1))))
                        .method_351(class_77.method_411(class_1802.field_8251).method_437(1).method_438(class_141.method_621(class_44.method_32448(1))))
                        .method_351(class_77.method_411(class_1802.field_8895).method_437(1).method_438(class_141.method_621(class_5662.method_32462(1, 2))))
                        .method_351(class_77.method_411(class_1802.field_8054).method_437(1).method_438(class_141.method_621(class_5662.method_32462(2, 4))))
                        .method_351(class_77.method_411(class_1802.field_8378).method_437(1).method_438(class_141.method_621(class_44.method_32448(1))))
                        .method_351(class_77.method_411(class_1802.field_8884).method_437(1).method_438(class_141.method_621(class_44.method_32448(1))))
                        .method_351(class_77.method_411(class_1802.field_8469).method_437(1).method_438(class_141.method_621(class_5662.method_32462(1, 4))))
                        .method_351(class_77.method_411(class_1802.field_8719).method_437(1).method_438(class_141.method_621(class_5662.method_32462(1, 3))))
                        .method_351(class_77.method_411(class_1802.field_8745).method_437(1).method_438(class_141.method_621(class_5662.method_32462(1, 4))))
                        .method_351(class_77.method_411(class_1802.field_27023).method_437(1).method_438(class_141.method_621(class_44.method_32448(1))))
                        .method_351(class_77.method_411(class_1802.field_8245).method_437(1).method_438(class_141.method_621(class_5662.method_32462(1, 4))))
                        .method_351(class_77.method_411(class_1802.field_8175).method_437(1).method_438(class_141.method_621(class_44.method_32448(1))))
                        .method_351(class_77.method_411(class_1802.field_27025).method_437(1).method_438(class_141.method_621(class_5662.method_32462(1, 3))))
                )
                .method_336(
                    class_55.method_347()
                        .method_352(class_44.method_32448(2))
                        .method_351(class_77.method_411(class_1802.field_8102).method_437(1).method_438(class_141.method_621(class_44.method_32448(1))))
                        .method_351(class_77.method_411(class_1802.field_8550).method_437(1).method_438(class_141.method_621(class_44.method_32448(1))))
                        .method_351(class_77.method_411(class_1802.field_27070).method_437(1).method_438(class_141.method_621(class_44.method_32448(1))))
                        .method_351(class_77.method_411(class_1802.field_8868).method_437(1).method_438(class_141.method_621(class_44.method_32448(1))))
                )
                .method_336(
                    class_55.method_347()
                        .method_352(class_44.method_32448(1))
                        .method_351(
                            this.explorationMapItemExcludingBiome(
                                ModStructureTags.ON_ABANDONED_CAMP_BAMBOO_JUNGLE_MAPS,
                                ModMapDecorationTypes.ABANDONED_CAMP,
                                "filled_map.bamboo_camp_map",
                                this.biomes.method_46747(class_1972.field_9440)
                            )
                        ).method_351(
                            this.explorationMapItemExcludingBiome(
                                ModStructureTags.ON_ABANDONED_CAMP_CHERRY_GROVE_MAPS,
                                ModMapDecorationTypes.ABANDONED_CAMP,
                                "filled_map.cherry_grove_camp_map",
                                this.biomes.method_46747(class_1972.field_42720)
                            )
                        )
                        .method_351(
                            this.explorationMapItemExcludingBiome(
                                ModStructureTags.ON_ABANDONED_CAMP_BIRCH_FOREST_MAPS,
                                ModMapDecorationTypes.ABANDONED_CAMP,
                                "filled_map.birch_forest_camp_map",
                                this.biomes.method_46747(class_1972.field_9412)
                            )
                        )
                        .method_351(
                            this.explorationMapItemExcludingBiome(
                                ModStructureTags.ON_ABANDONED_CAMP_DAPPLED_FOREST_MAPS,
                                ModMapDecorationTypes.ABANDONED_CAMP,
                                "filled_map.dappled_forest_camp_map",
                                this.biomes.method_46747(ModBiomes.DAPPLED_FOREST)
                            )
                        )
                        .method_351(
                            this.explorationMapItemExcludingBiome(
                                ModStructureTags.ON_ABANDONED_CAMP_FLOWER_FOREST_MAPS,
                                ModMapDecorationTypes.ABANDONED_CAMP,
                                "filled_map.flower_forest_camp_map",
                                this.biomes.method_46747(class_1972.field_9414)
                            )
                        )
                        .method_351(
                            this.explorationMapItemExcludingBiome(
                                ModStructureTags.ON_ABANDONED_CAMP_PALE_GARDEN_MAPS,
                                ModMapDecorationTypes.ABANDONED_CAMP,
                                "filled_map.pale_garden_camp_map",
                                this.biomes.method_46747(ModBiomes.PALE_GARDEN)
                            )
                        )
                        .method_351(
                            this.explorationMapItemExcludingBiome(
                                ModStructureTags.ON_ABANDONED_CAMP_SWAMP_MAPS,
                                ModMapDecorationTypes.ABANDONED_CAMP,
                                "filled_map.swamp_camp_map",
                                this.biomes.method_46747(class_1972.field_9471)
                            )
                        )
                        .method_351(
                            this.explorationMapItemExcludingBiome(
                                ModStructureTags.ON_ABANDONED_CAMP_WINDSWEPT_FOREST_MAPS,
                                ModMapDecorationTypes.ABANDONED_CAMP,
                                "filled_map.windswept_forest_camp_map",
                                this.biomes.method_46747(class_1972.field_35120)
                            )
                        )
                )
        );
        output.accept(
            ModBuiltInLootTables.ABANDONED_CAMP_SECRET_CHEST,
            class_52.method_324()
                .method_336(
                    class_55.method_347()
                        .method_352(class_44.method_32448(2))
                        .method_351(class_77.method_411(class_1802.field_8477).method_437(1).method_438(class_141.method_621(class_44.method_32448(1))))
                        .method_351(
                            class_77.method_411(class_1802.field_8574)
                                .method_437(1)
                                .method_438(class_141.method_621(class_44.method_32448(1)))
                                .method_438(class_6662.method_38927(class_1847.field_8963))
                        )
                        .method_351(
                            class_77.method_411(class_1802.field_8574)
                                .method_437(1)
                                .method_438(class_141.method_621(class_44.method_32448(1)))
                                .method_438(class_6662.method_38927(class_1847.field_8979))
                        )
                        .method_351(
                            class_77.method_411(class_1802.field_8574)
                                .method_437(1)
                                .method_438(class_141.method_621(class_44.method_32448(1)))
                                .method_438(class_6662.method_38927(class_1847.field_8968))
                        )
                        .method_351(
                            class_77.method_411(class_1802.field_8574)
                                .method_437(1)
                                .method_438(class_141.method_621(class_44.method_32448(1)))
                                .method_438(class_6662.method_38927(class_1847.field_9005))
                        )
                )
                .method_336(
                    class_55.method_347()
                        .method_352(class_5662.method_32462(4, 6))
                        .method_351(class_77.method_411(class_1802.field_8895).method_437(1).method_438(class_141.method_621(class_44.method_32448(1))))
                        .method_351(class_77.method_411(class_1802.field_27022).method_437(1).method_438(class_141.method_621(class_5662.method_32462(1, 2))))
                        .method_351(class_77.method_411(class_1802.field_8695).method_437(1).method_438(class_141.method_621(class_5662.method_32462(1, 2))))
                        .method_351(class_77.method_411(class_1802.field_8620).method_437(1).method_438(class_141.method_621(class_44.method_32448(1))))
                )
                .method_336(
                    class_55.method_347()
                        .method_352(class_5662.method_32462(0, 1))
                        .method_351(class_77.method_411(class_1802.field_8475).method_437(1).method_438(class_141.method_621(class_44.method_32448(1))))
                        .method_351(class_77.method_411(class_1802.field_8660).method_437(1).method_438(class_141.method_621(class_44.method_32448(1))))
                        .method_351(class_77.method_411(class_1802.field_8396).method_437(1).method_438(class_141.method_621(class_44.method_32448(1))))
                )
                .method_336(
                    class_55.method_347()
                        .method_352(class_44.method_32448(1))
                        .method_351(this.explorationMapItem(ModStructureTags.ON_ANCIENT_CITY_MAPS, ModMapDecorationTypes.ANCIENT_CITY))
                        .method_351(this.explorationMapItem(class_7045.field_49958, class_21.field_50019))
                        .method_351(this.explorationMapItem(ModStructureTags.ON_MINESHAFT_MAPS, ModMapDecorationTypes.MINESHAFT))
                        .method_351(this.explorationMapItem(ModStructureTags.ON_DESERT_PYRAMID_MAPS, ModMapDecorationTypes.DESERT_PYRAMID))
                        .method_351(this.explorationMapItem(class_7045.field_46163, class_21.field_46182))
                        .method_351(this.explorationMapItem(ModStructureTags.ON_OCEAN_RUIN_WARM_MAPS, ModMapDecorationTypes.OCEAN_RUIN_WARM))
                        .method_351(this.explorationMapItem(class_7045.field_37042, class_21.field_88))
                )
        );
    }
    
    private class_85.class_86<?> explorationMapItemExcludingBiome(class_6862<class_3195> structureTag, class_6880<class_9428> decoration, String translationKey, class_6880<class_1959> excludedBiome) {
        return this.explorationMapItem(structureTag, decoration, translationKey).method_421(class_205.method_884(class_2090.class_2091.method_22484().method_9024(class_6885.method_40246(excludedBiome))).method_16780());
    }
    
    private class_85.class_86<?> explorationMapItem(class_6862<class_3195> structureTag, class_6880<class_9428> decoration) {
        return this.explorationMapItem(structureTag, decoration, null);
    }
    
    private class_85.class_86<?> explorationMapItem(class_6862<class_3195> structureTag, class_6880<class_9428> decoration, @Nullable String translationKey) {
        var entry = class_77.method_411(class_1802.field_8895).method_437(1);
        
        entry.method_438(class_111.method_492().method_502(structureTag).method_499(decoration).method_500((byte)1).method_503(true));
        
        if (translationKey != null) {
            entry = entry.method_438(class_3670.method_35549(class_2561.method_43471(translationKey), class_3670.class_9475.field_50211));
        }
        
        return entry;
    }
}