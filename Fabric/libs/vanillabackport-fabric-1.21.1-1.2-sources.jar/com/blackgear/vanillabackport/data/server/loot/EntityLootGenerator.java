package com.blackgear.vanillabackport.data.server.loot;

import com.blackgear.vanillabackport.common.registries.entities.ModEntityTypes;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.SimpleFabricLootTableProvider;
import net.minecraft.class_125;
import net.minecraft.class_141;
import net.minecraft.class_173;
import net.minecraft.class_1802;
import net.minecraft.class_1847;
import net.minecraft.class_221;
import net.minecraft.class_225;
import net.minecraft.class_44;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_55;
import net.minecraft.class_5662;
import net.minecraft.class_6662;
import net.minecraft.class_7225;
import net.minecraft.class_77;
import java.util.concurrent.CompletableFuture;
import java.util.function.BiConsumer;

public class EntityLootGenerator extends SimpleFabricLootTableProvider {
    private final class_7225.class_7874 registries;
    
    public EntityLootGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> lookup) {
        super(output, lookup, class_173.field_1173);
        this.registries = lookup.resultNow();
    }

    @Override
    public void method_10399(BiConsumer<class_5321<class_52>, class_52.class_53> output) {
        output.accept(ModEntityTypes.CREAKING.get().method_16351(), class_52.method_324());
        output.accept(ModEntityTypes.HAPPY_GHAST.get().method_16351(), class_52.method_324());
        output.accept(ModEntityTypes.SULFUR_CUBE.get().method_16351(), class_52.method_324());
        output.accept(
            ModEntityTypes.COPPER_GOLEM.get().method_16351(),
            class_52.method_324()
                .method_336(class_55.method_347()
                    .method_352(class_44.method_32448(1))
                    .method_351(class_77.method_411(class_1802.field_27022)
                        .method_438(class_141.method_621(class_5662.method_32462(1.0F, 3.0F)))
                        .method_438(class_125.method_547(this.registries, class_5662.method_32462(0.0F, 1.0F)))))
        );
        output.accept(ModEntityTypes.PARCHED.get().method_16351(),
            class_52.method_324()
                .method_336(class_55.method_347()
                    .method_352(class_44.method_32448(1.0F))
                    .method_351(class_77.method_411(class_1802.field_8107)
                        .method_438(class_141.method_621(class_5662.method_32462(0.0F, 2.0F)))
                        .method_438(class_125.method_547(this.registries, class_5662.method_32462(0.0F, 1.0F)))))
                .method_336(class_55.method_347()
                    .method_352(class_44.method_32448(1.0F))
                    .method_351(class_77.method_411(class_1802.field_8606)
                        .method_438(class_141.method_621(class_5662.method_32462(0.0F, 2.0F)))
                        .method_438(class_125.method_547(this.registries, class_5662.method_32462(0.0F, 1.0F)))))
                .method_336(class_55.method_347()
                    .method_352(class_44.method_32448(1.0F))
                    .method_351(class_77.method_411(class_1802.field_8087)
                        .method_438(class_141.method_621(class_5662.method_32462(0.0F, 1.0F)))
                        .method_438(class_125.method_547(this.registries, class_5662.method_32462(0.0F, 1.0F)).method_551(1))
                        .method_438(class_6662.method_38927(class_1847.field_8975)))
                    .method_356(class_221.method_939()))
        );
        output.accept(ModEntityTypes.CAMEL_HUSK.get().method_16351(),
            class_52.method_324()
                .method_336(class_55.method_347()
                    .method_352(class_44.method_32448(1.0F))
                    .method_351(class_77.method_411(class_1802.field_8511)
                        .method_438(class_141.method_621(class_5662.method_32462(2.0F, 3.0F)))
                        .method_438(class_125.method_547(this.registries, class_5662.method_32462(0.0F, 1.0F)))))
        );
        output.accept(ModEntityTypes.NAUTILUS.get().method_16351(),
            class_52.method_324()
                .method_336(class_55.method_347()
                    .method_352(class_44.method_32448(1.0F))
                    .method_351(class_77.method_411(class_1802.field_8864)
                        .method_421(class_221.method_939())
                        .method_421(class_225.method_953(this.registries, 0.05F, 0.01F))))
        );
        output.accept(ModEntityTypes.ZOMBIE_NAUTILUS.get().method_16351(),
            class_52.method_324()
                .method_336(class_55.method_347()
                    .method_352(class_44.method_32448(1.0F))
                    .method_351(class_77.method_411(class_1802.field_8511)
                        .method_438(class_141.method_621(class_5662.method_32462(0.0F, 3.0F)))
                        .method_438(class_125.method_547(this.registries, class_5662.method_32462(0.0F, 1.0F))))
                    .method_356(class_221.method_939()))
        );
        output.accept(ModEntityTypes.CUSHION.get().method_16351(), class_52.method_324());
    }
}