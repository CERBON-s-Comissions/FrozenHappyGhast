package com.blackgear.vanillabackport.data.server.loot;

import com.blackgear.vanillabackport.common.level.blocks.CopperGolemStatueBlock;
import com.blackgear.vanillabackport.common.level.blocks.MossyCarpetBlock;
import com.blackgear.vanillabackport.common.level.blocks.SegmentableBlock;
import com.blackgear.vanillabackport.common.level.blocks.ShelfMushroomBlock;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.minecraft.class_114;
import net.minecraft.class_141;
import net.minecraft.class_1887;
import net.minecraft.class_1893;
import net.minecraft.class_1935;
import net.minecraft.class_212;
import net.minecraft.class_2244;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2742;
import net.minecraft.class_42;
import net.minecraft.class_44;
import net.minecraft.class_4488;
import net.minecraft.class_4559;
import net.minecraft.class_52;
import net.minecraft.class_55;
import net.minecraft.class_5662;
import net.minecraft.class_5778;
import net.minecraft.class_7225;
import net.minecraft.class_77;
import net.minecraft.class_7924;
import net.minecraft.class_9317;
import net.minecraft.class_9334;
import net.minecraft.class_94;
import net.minecraft.world.level.storage.loot.functions.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.IntStream;

public class BlockLootGenerator extends FabricBlockLootTableProvider {
    public BlockLootGenerator(FabricDataOutput dataOutput, CompletableFuture<class_7225.class_7874> registryLookup) {
        super(dataOutput, registryLookup);
    }

    @Override
    public void method_10379() {
        class_7225.class_7226<class_1887> enchantments = this.field_51845.method_46762(class_7924.field_41265);
        this.method_46025(ModBlocks.PALE_OAK_PLANKS.get());
        this.method_46025(ModBlocks.PALE_OAK_SAPLING.get());
        this.method_46025(ModBlocks.PALE_OAK_LOG.get());
        this.method_46025(ModBlocks.STRIPPED_PALE_OAK_LOG.get());
        this.method_46025(ModBlocks.PALE_OAK_WOOD.get());
        this.method_46025(ModBlocks.STRIPPED_PALE_OAK_WOOD.get());
        this.method_46025(ModBlocks.PALE_OAK_SIGN.getFirst().get());
        this.method_46025(ModBlocks.PALE_OAK_HANGING_SIGN.getFirst().get());
        this.method_46025(ModBlocks.PALE_OAK_PRESSURE_PLATE.get());
        this.method_46025(ModBlocks.PALE_OAK_TRAPDOOR.get());
        this.method_46025(ModBlocks.PALE_OAK_BUTTON.get());
        this.method_46025(ModBlocks.PALE_OAK_STAIRS.get());
        this.method_46025(ModBlocks.PALE_OAK_FENCE_GATE.get());
        this.method_46025(ModBlocks.PALE_OAK_FENCE.get());
        this.method_45994(ModBlocks.PALE_OAK_SLAB.get(), this::method_45980);
        this.method_45994(ModBlocks.PALE_OAK_DOOR.get(), this::method_46022);
        this.method_45994(ModBlocks.PALE_OAK_LEAVES.get(), block -> this.method_45986(block, ModBlocks.PALE_OAK_SAPLING.get(), field_40605));

        this.method_46025(ModBlocks.OPEN_EYEBLOSSOM.get());
        this.method_46025(ModBlocks.CLOSED_EYEBLOSSOM.get());

        this.method_45994(ModBlocks.PALE_MOSS_CARPET.get(), this::createMossyCarpetBlockDrops);
        this.method_45994(ModBlocks.PALE_HANGING_MOSS.get(), this::createShearsOrSilkTouchOnlyDrop);
        this.method_46025(ModBlocks.PALE_MOSS_BLOCK.get());

        this.method_46023(ModBlocks.POTTED_PALE_OAK_SAPLING.get());
        this.method_46023(ModBlocks.POTTED_OPEN_EYEBLOSSOM.get());
        this.method_46023(ModBlocks.POTTED_CLOSED_EYEBLOSSOM.get());

        this.method_46025(ModBlocks.RESIN_BLOCK.get());
        this.method_46025(ModBlocks.RESIN_BRICKS.get());
        this.method_46025(ModBlocks.RESIN_BRICK_WALL.get());
        this.method_46025(ModBlocks.RESIN_BRICK_STAIRS.get());
        this.method_46025(ModBlocks.CHISELED_RESIN_BRICKS.get());
        this.method_45994(ModBlocks.RESIN_BRICK_SLAB.get(), this::method_45980);
        this.method_45994(ModBlocks.RESIN_CLUMP.get(), this::createMultifaceBlockDrops);

        this.method_45994(
            ModBlocks.CREAKING_HEART.get(),
            block -> method_45989(
                block,
                this.method_45977(
                    block,
                    class_77.method_411(ModBlocks.RESIN_CLUMP.get())
                        .method_438(class_141.method_621(class_5662.method_32462(1.0F, 3.0F)))
                        .method_438(class_94.method_456(enchantments.method_46747(class_1893.field_9130)))
                        .method_438(class_114.method_506(class_42.method_277(9)))
                )
            )
        );

        // Chase the Skies
        this.method_46025(ModBlocks.DRIED_GHAST.get());

        // Spring to Life
        this.method_46025(ModBlocks.FIREFLY_BUSH.get());
        this.method_45994(ModBlocks.BUSH.get(), this::createShearsOrSilkTouchOnlyDrop);
        this.method_45988(ModBlocks.WILDFLOWERS.get(), this.method_49358(ModBlocks.WILDFLOWERS.get()));
        this.method_45988(ModBlocks.LEAF_LITTER.get(), this.createSegmentedBlockDrops(ModBlocks.LEAF_LITTER.get()));
        this.method_46025(ModBlocks.CACTUS_FLOWER.get());
        this.method_45994(ModBlocks.SHORT_DRY_GRASS.get(), this::createShearsOrSilkTouchOnlyDrop);
        this.method_45994(ModBlocks.TALL_DRY_GRASS.get(), this::createShearsOrSilkTouchOnlyDrop);

        // Chaos Cubed
        this.method_46025(ModBlocks.SULFUR_SPIKE.get());
        this.method_46025(ModBlocks.SULFUR.get());
        this.method_46025(ModBlocks.POTENT_SULFUR.get());
        this.method_46025(ModBlocks.SULFUR_STAIRS.get());
        this.method_45994(ModBlocks.SULFUR_SLAB.get(), this::method_45980);
        this.method_46025(ModBlocks.SULFUR_WALL.get());
        this.method_46025(ModBlocks.CHISELED_SULFUR.get());
        this.method_46025(ModBlocks.POLISHED_SULFUR.get());
        this.method_46025(ModBlocks.POLISHED_SULFUR_STAIRS.get());
        this.method_45994(ModBlocks.POLISHED_SULFUR_SLAB.get(), this::method_45980);
        this.method_46025(ModBlocks.POLISHED_SULFUR_WALL.get());
        this.method_46025(ModBlocks.SULFUR_BRICKS.get());
        this.method_46025(ModBlocks.SULFUR_BRICK_STAIRS.get());
        this.method_45994(ModBlocks.SULFUR_BRICK_SLAB.get(), this::method_45980);
        this.method_46025(ModBlocks.SULFUR_BRICK_WALL.get());
        this.method_46025(ModBlocks.CINNABAR.get());
        this.method_46025(ModBlocks.CINNABAR_STAIRS.get());
        this.method_45994(ModBlocks.CINNABAR_SLAB.get(), this::method_45980);
        this.method_46025(ModBlocks.CINNABAR_WALL.get());
        this.method_46025(ModBlocks.CHISELED_CINNABAR.get());
        this.method_46025(ModBlocks.POLISHED_CINNABAR.get());
        this.method_46025(ModBlocks.POLISHED_CINNABAR_STAIRS.get());
        this.method_45994(ModBlocks.POLISHED_CINNABAR_SLAB.get(), this::method_45980);
        this.method_46025(ModBlocks.POLISHED_CINNABAR_WALL.get());
        this.method_46025(ModBlocks.CINNABAR_BRICKS.get());
        this.method_46025(ModBlocks.CINNABAR_BRICK_STAIRS.get());
        this.method_45994(ModBlocks.CINNABAR_BRICK_SLAB.get(), this::method_45980);
        this.method_46025(ModBlocks.CINNABAR_BRICK_WALL.get());
        
        // Copper Age
        this.method_45994(ModBlocks.COPPER_CHEST.get(), this::method_45996);
        this.method_45994(ModBlocks.EXPOSED_COPPER_CHEST.get(), this::method_45996);
        this.method_45994(ModBlocks.WEATHERED_COPPER_CHEST.get(), this::method_45996);
        this.method_45994(ModBlocks.OXIDIZED_COPPER_CHEST.get(), this::method_45996);
        
        this.method_45994(ModBlocks.WAXED_COPPER_CHEST.get(), this::method_45996);
        this.method_45994(ModBlocks.WAXED_EXPOSED_COPPER_CHEST.get(), this::method_45996);
        this.method_45994(ModBlocks.WAXED_WEATHERED_COPPER_CHEST.get(), this::method_45996);
        this.method_45994(ModBlocks.WAXED_OXIDIZED_COPPER_CHEST.get(), this::method_45996);
        
        this.method_46025(ModBlocks.ACACIA_SHELF.get());
        this.method_46025(ModBlocks.BAMBOO_SHELF.get());
        this.method_46025(ModBlocks.BIRCH_SHELF.get());
        this.method_46025(ModBlocks.CHERRY_SHELF.get());
        this.method_46025(ModBlocks.CRIMSON_SHELF.get());
        this.method_46025(ModBlocks.DARK_OAK_SHELF.get());
        this.method_46025(ModBlocks.JUNGLE_SHELF.get());
        this.method_46025(ModBlocks.MANGROVE_SHELF.get());
        this.method_46025(ModBlocks.OAK_SHELF.get());
        this.method_46025(ModBlocks.PALE_OAK_SHELF.get());
        this.method_46025(ModBlocks.SPRUCE_SHELF.get());
        this.method_46025(ModBlocks.WARPED_SHELF.get());
        
        this.method_45994(ModBlocks.COPPER_GOLEM_STATUE.get(), this::createCopperGolemStatueBlock);
        this.method_45994(ModBlocks.EXPOSED_COPPER_GOLEM_STATUE.get(), this::createCopperGolemStatueBlock);
        this.method_45994(ModBlocks.WEATHERED_COPPER_GOLEM_STATUE.get(), this::createCopperGolemStatueBlock);
        this.method_45994(ModBlocks.OXIDIZED_COPPER_GOLEM_STATUE.get(), this::createCopperGolemStatueBlock);
        
        this.method_45994(ModBlocks.WAXED_COPPER_GOLEM_STATUE.get(), this::createCopperGolemStatueBlock);
        this.method_45994(ModBlocks.WAXED_EXPOSED_COPPER_GOLEM_STATUE.get(), this::createCopperGolemStatueBlock);
        this.method_45994(ModBlocks.WAXED_WEATHERED_COPPER_GOLEM_STATUE.get(), this::createCopperGolemStatueBlock);
        this.method_45994(ModBlocks.WAXED_OXIDIZED_COPPER_GOLEM_STATUE.get(), this::createCopperGolemStatueBlock);
        
        this.method_46025(ModBlocks.EXPOSED_LIGHTNING_ROD.get());
        this.method_46025(ModBlocks.WEATHERED_LIGHTNING_ROD.get());
        this.method_46025(ModBlocks.OXIDIZED_LIGHTNING_ROD.get());
        
        this.method_46025(ModBlocks.WAXED_LIGHTNING_ROD.get());
        this.method_46025(ModBlocks.WAXED_EXPOSED_LIGHTNING_ROD.get());
        this.method_46025(ModBlocks.WAXED_WEATHERED_LIGHTNING_ROD.get());
        this.method_46025(ModBlocks.WAXED_OXIDIZED_LIGHTNING_ROD.get());
        
        this.method_46025(ModBlocks.COPPER_TORCH.getFirst().get());
        ModBlocks.COPPER_LANTERN.forEach(holder -> this.method_45994(holder.get(), this::method_45976));
        ModBlocks.COPPER_BARS.forEach(holder -> this.method_46025(holder.get()));
        ModBlocks.COPPER_CHAIN.forEach(holder -> this.method_46025(holder.get()));
        
        // Wilderness bound
        
        this.method_46025(ModBlocks.POPLAR_PLANKS.get());
        this.method_46025(ModBlocks.POPLAR_SAPLING.get());
        this.method_46025(ModBlocks.POPLAR_LOG.get());
        this.method_46025(ModBlocks.STRIPPED_POPLAR_LOG.get());
        this.method_46025(ModBlocks.POPLAR_WOOD.get());
        this.method_46025(ModBlocks.STRIPPED_POPLAR_WOOD.get());
        this.method_46025(ModBlocks.POPLAR_SIGN.getFirst().get());
        this.method_46025(ModBlocks.POPLAR_HANGING_SIGN.getFirst().get());
        this.method_46025(ModBlocks.POPLAR_PRESSURE_PLATE.get());
        this.method_46025(ModBlocks.POPLAR_TRAPDOOR.get());
        this.method_46025(ModBlocks.POPLAR_BUTTON.get());
        this.method_46025(ModBlocks.POPLAR_STAIRS.get());
        this.method_46025(ModBlocks.POPLAR_FENCE_GATE.get());
        this.method_46025(ModBlocks.POPLAR_FENCE.get());
        this.method_46025(ModBlocks.POPLAR_SHELF.get());
        this.method_45994(ModBlocks.POPLAR_SLAB.get(), this::method_45980);
        this.method_45994(ModBlocks.POPLAR_DOOR.get(), this::method_46022);
        this.method_45994(ModBlocks.RED_POPLAR_LEAVES.get(), block -> this.method_45986(block, ModBlocks.POPLAR_SAPLING.get(), field_40605));
        this.method_45994(ModBlocks.ORANGE_POPLAR_LEAVES.get(), block -> this.method_45986(block, ModBlocks.POPLAR_SAPLING.get(), field_40605));
        this.method_45994(ModBlocks.YELLOW_POPLAR_LEAVES.get(), block -> this.method_45986(block, ModBlocks.POPLAR_SAPLING.get(), field_40605));
        
        this.method_46023(ModBlocks.POTTED_POPLAR_SAPLING.get());
        this.method_46025(ModBlocks.RED_SHRUB.get());
        this.method_45994(ModBlocks.SHELF_MUSHROOM.get(),
            block -> class_52.method_324()
                .method_336(
                    class_55.method_347()
                        .method_352(class_44.method_32448(1))
                        .method_351(
                            this.method_45977(
                                block,
                                class_77.method_411(ModBlocks.SHELF_MUSHROOM.get())
                                    .method_438(
                                        class_141.method_621(class_44.method_32448(2))
                                            .method_524(class_212.method_900(block).method_22584(class_4559.class_4560.method_22523().method_22524(ShelfMushroomBlock.AGE, 1)))
                                    )
                            )
                        )
                )
        );
        
        this.method_45994(ModBlocks.STRAW_BED.get(), block -> this.method_45987(block, class_2244.field_9967, class_2742.field_12560));
        
        this.method_46025(ModBlocks.WHITE_WOOL_STAIRS.get());
        this.method_46025(ModBlocks.ORANGE_WOOL_STAIRS.get());
        this.method_46025(ModBlocks.MAGENTA_WOOL_STAIRS.get());
        this.method_46025(ModBlocks.LIGHT_BLUE_WOOL_STAIRS.get());
        this.method_46025(ModBlocks.YELLOW_WOOL_STAIRS.get());
        this.method_46025(ModBlocks.LIME_WOOL_STAIRS.get());
        this.method_46025(ModBlocks.PINK_WOOL_STAIRS.get());
        this.method_46025(ModBlocks.GRAY_WOOL_STAIRS.get());
        this.method_46025(ModBlocks.LIGHT_GRAY_WOOL_STAIRS.get());
        this.method_46025(ModBlocks.CYAN_WOOL_STAIRS.get());
        this.method_46025(ModBlocks.PURPLE_WOOL_STAIRS.get());
        this.method_46025(ModBlocks.BLUE_WOOL_STAIRS.get());
        this.method_46025(ModBlocks.BROWN_WOOL_STAIRS.get());
        this.method_46025(ModBlocks.GREEN_WOOL_STAIRS.get());
        this.method_46025(ModBlocks.RED_WOOL_STAIRS.get());
        this.method_46025(ModBlocks.BLACK_WOOL_STAIRS.get());
        
        this.method_46025(ModBlocks.WHITE_WOOL_SLAB.get());
        this.method_46025(ModBlocks.ORANGE_WOOL_SLAB.get());
        this.method_46025(ModBlocks.MAGENTA_WOOL_SLAB.get());
        this.method_46025(ModBlocks.LIGHT_BLUE_WOOL_SLAB.get());
        this.method_46025(ModBlocks.YELLOW_WOOL_SLAB.get());
        this.method_46025(ModBlocks.LIME_WOOL_SLAB.get());
        this.method_46025(ModBlocks.PINK_WOOL_SLAB.get());
        this.method_46025(ModBlocks.GRAY_WOOL_SLAB.get());
        this.method_46025(ModBlocks.LIGHT_GRAY_WOOL_SLAB.get());
        this.method_46025(ModBlocks.CYAN_WOOL_SLAB.get());
        this.method_46025(ModBlocks.PURPLE_WOOL_SLAB.get());
        this.method_46025(ModBlocks.BLUE_WOOL_SLAB.get());
        this.method_46025(ModBlocks.BROWN_WOOL_SLAB.get());
        this.method_46025(ModBlocks.GREEN_WOOL_SLAB.get());
        this.method_46025(ModBlocks.RED_WOOL_SLAB.get());
        this.method_46025(ModBlocks.BLACK_WOOL_SLAB.get());

        this.method_46025(ModBlocks.WHITE_CONCRETE_STAIRS.get());
        this.method_46025(ModBlocks.ORANGE_CONCRETE_STAIRS.get());
        this.method_46025(ModBlocks.MAGENTA_CONCRETE_STAIRS.get());
        this.method_46025(ModBlocks.LIGHT_BLUE_CONCRETE_STAIRS.get());
        this.method_46025(ModBlocks.YELLOW_CONCRETE_STAIRS.get());
        this.method_46025(ModBlocks.LIME_CONCRETE_STAIRS.get());
        this.method_46025(ModBlocks.PINK_CONCRETE_STAIRS.get());
        this.method_46025(ModBlocks.GRAY_CONCRETE_STAIRS.get());
        this.method_46025(ModBlocks.LIGHT_GRAY_CONCRETE_STAIRS.get());
        this.method_46025(ModBlocks.CYAN_CONCRETE_STAIRS.get());
        this.method_46025(ModBlocks.PURPLE_CONCRETE_STAIRS.get());
        this.method_46025(ModBlocks.BLUE_CONCRETE_STAIRS.get());
        this.method_46025(ModBlocks.BROWN_CONCRETE_STAIRS.get());
        this.method_46025(ModBlocks.GREEN_CONCRETE_STAIRS.get());
        this.method_46025(ModBlocks.RED_CONCRETE_STAIRS.get());
        this.method_46025(ModBlocks.BLACK_CONCRETE_STAIRS.get());

        this.method_46025(ModBlocks.WHITE_CONCRETE_SLAB.get());
        this.method_46025(ModBlocks.ORANGE_CONCRETE_SLAB.get());
        this.method_46025(ModBlocks.MAGENTA_CONCRETE_SLAB.get());
        this.method_46025(ModBlocks.LIGHT_BLUE_CONCRETE_SLAB.get());
        this.method_46025(ModBlocks.YELLOW_CONCRETE_SLAB.get());
        this.method_46025(ModBlocks.LIME_CONCRETE_SLAB.get());
        this.method_46025(ModBlocks.PINK_CONCRETE_SLAB.get());
        this.method_46025(ModBlocks.GRAY_CONCRETE_SLAB.get());
        this.method_46025(ModBlocks.LIGHT_GRAY_CONCRETE_SLAB.get());
        this.method_46025(ModBlocks.CYAN_CONCRETE_SLAB.get());
        this.method_46025(ModBlocks.PURPLE_CONCRETE_SLAB.get());
        this.method_46025(ModBlocks.BLUE_CONCRETE_SLAB.get());
        this.method_46025(ModBlocks.BROWN_CONCRETE_SLAB.get());
        this.method_46025(ModBlocks.GREEN_CONCRETE_SLAB.get());
        this.method_46025(ModBlocks.RED_CONCRETE_SLAB.get());
        this.method_46025(ModBlocks.BLACK_CONCRETE_SLAB.get());
    }

    protected class_52.class_53 createMultifaceBlockDrops(class_2248 block) {
        return class_52.method_324()
            .method_336(
                class_55.method_347()
                    .method_351(
                        this.method_45977(
                            block,
                            class_77.method_411(block)
                                .method_43740(
                                    class_2350.values(),
                                    direction -> class_141.method_35540(class_44.method_32448(1.0F), true)
                                        .method_524(
                                            class_212.method_900(block)
                                                .method_22584(class_4559.class_4560.method_22523().method_22527(class_5778.method_33374(direction), true))
                                        )
                                )
                                .method_438(class_141.method_35540(class_44.method_32448(-1.0F), true))
                        )
                    )
            );
    }

    protected class_52.class_53 createMossyCarpetBlockDrops(class_2248 block) {
        return class_52.method_324()
            .method_336(
                class_55.method_347()
                    .method_351(
                        this.method_45977(
                            block,
                            class_77.method_411(block)
                                .method_421(
                                    class_212.method_900(block)
                                        .method_22584(class_4559.class_4560.method_22523().method_22527(MossyCarpetBlock.BASE, true))
                                )
                        )
                    )
            );
    }

    protected class_52.class_53 createShearsOrSilkTouchOnlyDrop(class_1935 itemLike) {
        return class_52.method_324()
            .method_336(class_55.method_347().method_352(class_44.method_32448(1.0F)).method_356(this.method_60392()).method_351(class_77.method_411(itemLike)));
    }

    public class_52.class_53 createSegmentedBlockDrops(class_2248 block) {
        return block instanceof SegmentableBlock segmentable
            ? class_52.method_324().method_336(class_55.method_347()
                .method_352(class_44.method_32448(1.0F))
                .method_351(this.method_45977(block,
                    class_77.method_411(block)
                        .method_43739(IntStream.rangeClosed(1, 4).boxed().toList(),
                            value -> class_141.method_621(class_44.method_32448((float) value))
                                .method_524(class_212.method_900(block)
                                    .method_22584(class_4559.class_4560.method_22523().method_22524(segmentable.getSegmentAmountProperty(), value)))))))
            : method_45975();
            
    }
    
    public class_52.class_53 createCopperGolemStatueBlock(class_2248 block) {
        return class_52.method_324()
            .method_336(
                this.method_45978(
                    block,
                    class_55.method_347()
                        .method_352(class_44.method_32448(1.0F))
                        .method_351(
                            class_77.method_411(block)
                                .method_438(class_9317.method_57637(class_9317.class_9319.field_49436).method_58730(class_9334.field_49631))
                                .method_438(class_4488.method_21892(block).method_21898(CopperGolemStatueBlock.POSE))
                        )
                )
            );
    }
}