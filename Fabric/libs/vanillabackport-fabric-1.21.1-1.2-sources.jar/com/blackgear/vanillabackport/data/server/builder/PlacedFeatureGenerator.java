package com.blackgear.vanillabackport.data.server.builder;

import com.blackgear.vanillabackport.common.worldgen.placements.ChaosCubedPlacements;
import com.blackgear.vanillabackport.common.worldgen.placements.SpringToLifePlacements;
import com.blackgear.vanillabackport.common.worldgen.placements.TheGardenAwakensPlacements;
import com.blackgear.vanillabackport.common.worldgen.placements.WildernessBoundPlacements;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricDynamicRegistryProvider;
import net.minecraft.class_5321;
import net.minecraft.class_6796;
import net.minecraft.class_7225;
import net.minecraft.class_7924;
import java.util.concurrent.CompletableFuture;

public class PlacedFeatureGenerator extends FabricDynamicRegistryProvider {
    public PlacedFeatureGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected void configure(class_7225.class_7874 provider, Entries entries) {
        // The Garden Awakens
        this.add(provider, entries, TheGardenAwakensPlacements.PALE_OAK_CHECKED);
        this.add(provider, entries, TheGardenAwakensPlacements.PALE_OAK_CREAKING_CHECKED);

        this.add(provider, entries, TheGardenAwakensPlacements.FLOWER_PALE_GARDEN);
        this.add(provider, entries, TheGardenAwakensPlacements.PALE_GARDEN_VEGETATION);
        this.add(provider, entries, TheGardenAwakensPlacements.PALE_GARDEN_FLOWERS);
        this.add(provider, entries, TheGardenAwakensPlacements.PALE_MOSS_PATCH);

        // Spring to Life
        this.add(provider, entries, SpringToLifePlacements.PATCH_BUSH);

        this.add(provider, entries, SpringToLifePlacements.PATCH_FIREFLY_BUSH_NEAR_WATER);
        this.add(provider, entries, SpringToLifePlacements.PATCH_FIREFLY_BUSH_NEAR_WATER_SWAMP);
        this.add(provider, entries, SpringToLifePlacements.PATCH_FIREFLY_BUSH_SWAMP);

        this.add(provider, entries, SpringToLifePlacements.WILDFLOWERS_BIRCH_FOREST);
        this.add(provider, entries, SpringToLifePlacements.WILDFLOWERS_MEADOW);

        this.add(provider, entries, SpringToLifePlacements.PATCH_DRY_GRASS_BADLANDS);
        this.add(provider, entries, SpringToLifePlacements.PATCH_DRY_GRASS_DESERT);

        this.add(provider, entries, SpringToLifePlacements.PATCH_LEAF_LITTER);
        this.add(provider, entries, SpringToLifePlacements.LEAF_LITTER_SPARSE);
        this.add(provider, entries, SpringToLifePlacements.LEAF_LITTER_THICK);

        this.add(provider, entries, SpringToLifePlacements.CACTUS_FLOWER);

        this.add(provider, entries, SpringToLifePlacements.FALLEN_OAK_TREE);
        this.add(provider, entries, SpringToLifePlacements.FALLEN_BIRCH_TREE);
        this.add(provider, entries, SpringToLifePlacements.FALLEN_SUPER_BIRCH_TREE);
        this.add(provider, entries, SpringToLifePlacements.FALLEN_JUNGLE_TREE);
        this.add(provider, entries, SpringToLifePlacements.FALLEN_SPRUCE_TREE);

        this.add(provider, entries, SpringToLifePlacements.PLACED_FALLEN_OAK_TREE);
        this.add(provider, entries, SpringToLifePlacements.PLACED_RARE_FALLEN_BIRCH_TREE);
        this.add(provider, entries, SpringToLifePlacements.PLACED_FALLEN_BIRCH_TREE);
        this.add(provider, entries, SpringToLifePlacements.PLACED_FALLEN_SUPER_BIRCH_TREE);
        this.add(provider, entries, SpringToLifePlacements.PLACED_FALLEN_JUNGLE_TREE);
        this.add(provider, entries, SpringToLifePlacements.PLACED_FALLEN_SPRUCE_TREE);
        this.add(provider, entries, SpringToLifePlacements.PLACED_RARE_FALLEN_SPRUCE_TREE);

        // Chaos Cubed
        this.add(provider, entries, ChaosCubedPlacements.SULFUR_POOL);
        this.add(provider, entries, ChaosCubedPlacements.ROOTED_SULFUR_SPRING);
        this.add(provider, entries, ChaosCubedPlacements.SULFUR_SPIKE_CLUSTER);
        this.add(provider, entries, ChaosCubedPlacements.SULFUR_SPIKE);
        
        // Wilderness Bound
        this.add(provider, entries, WildernessBoundPlacements.RED_POPLAR);
        this.add(provider, entries, WildernessBoundPlacements.ORANGE_POPLAR);
        this.add(provider, entries, WildernessBoundPlacements.YELLOW_POPLAR);
        this.add(provider, entries, WildernessBoundPlacements.FALLEN_POPLAR_TREE);
        this.add(provider, entries, WildernessBoundPlacements.PATCH_RED_SHRUB);
        this.add(provider, entries, WildernessBoundPlacements.BROWN_MUSHROOM_DAPPLED_FOREST);
        this.add(provider, entries, WildernessBoundPlacements.BAMBOO_IN_STRUCTURE);
        this.add(provider, entries, WildernessBoundPlacements.TREES_DAPPLED_FOREST);
    }

    private void add(class_7225.class_7874 provider, Entries entries, class_5321<class_6796> key) {
        final class_7225.class_7226<class_6796> registry = provider.method_46762(class_7924.field_41245);
        entries.add(key, registry.method_46747(key).comp_349());
    }

    @Override
    public String method_10321() {
        return "worldgen/placed_feature";
    }
}