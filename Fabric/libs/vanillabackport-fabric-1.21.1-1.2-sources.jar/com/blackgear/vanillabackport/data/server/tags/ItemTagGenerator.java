package com.blackgear.vanillabackport.data.server.tags;

import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import com.blackgear.vanillabackport.common.registries.items.ModItems;
import com.blackgear.vanillabackport.core.data.tags.ModItemTags;
import com.blackgear.vanillabackport.core.data.tags.create.CreateItemTags;
import com.blackgear.vanillabackport.core.data.tags.loader.ConventionalItemTags;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1935;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_3489;
import net.minecraft.class_6862;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;

public class ItemTagGenerator extends FabricTagProvider.ItemTagProvider {
    public ItemTagGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected void method_10514(class_7225.class_7874 provider) {
        new BlockItemTagGenerator() {
            @Override
            protected TagHolder tag(class_6862<class_2248> block, class_6862<class_1792> item) {
            return new TagHolder(ItemTagGenerator.this.getOrCreateTagBuilder(item), null);
            }
        }.addTags();
        this.handleConventionalTags();
        this.handleArchetypes();
        
        this.getOrCreateTagBuilder(class_3489.field_15536)
            .add(ModItems.PALE_OAK_BOAT.get())
            .add(ModItems.POPLAR_BOAT.get());

        this.getOrCreateTagBuilder(class_3489.field_38080)
            .add(ModItems.PALE_OAK_CHEST_BOAT.get())
            .add(ModItems.POPLAR_CHEST_BOAT.get());

        this.getOrCreateTagBuilder(ModItemTags.BUNDLES)
            .add(
                class_1802.field_27023,
                ModItems.BLACK_BUNDLE.get(),
                ModItems.BLUE_BUNDLE.get(),
                ModItems.BROWN_BUNDLE.get(),
                ModItems.CYAN_BUNDLE.get(),
                ModItems.GRAY_BUNDLE.get(),
                ModItems.GREEN_BUNDLE.get(),
                ModItems.LIGHT_BLUE_BUNDLE.get(),
                ModItems.LIGHT_GRAY_BUNDLE.get(),
                ModItems.LIME_BUNDLE.get(),
                ModItems.MAGENTA_BUNDLE.get(),
                ModItems.ORANGE_BUNDLE.get(),
                ModItems.PINK_BUNDLE.get(),
                ModItems.PURPLE_BUNDLE.get(),
                ModItems.RED_BUNDLE.get(),
                ModItems.YELLOW_BUNDLE.get(),
                ModItems.WHITE_BUNDLE.get()
            );

        this.getOrCreateTagBuilder(class_3489.field_41891)
            .add(ModItems.RESIN_BRICK.get());

        this.getOrCreateTagBuilder(ModItemTags.HARNESSES)
            .add(
                ModItems.WHITE_HARNESS.get(),
                ModItems.ORANGE_HARNESS.get(),
                ModItems.MAGENTA_HARNESS.get(),
                ModItems.LIGHT_BLUE_HARNESS.get(),
                ModItems.YELLOW_HARNESS.get(),
                ModItems.LIME_HARNESS.get(),
                ModItems.PINK_HARNESS.get(),
                ModItems.GRAY_HARNESS.get(),
                ModItems.LIGHT_GRAY_HARNESS.get(),
                ModItems.CYAN_HARNESS.get(),
                ModItems.PURPLE_HARNESS.get(),
                ModItems.BLUE_HARNESS.get(),
                ModItems.BROWN_HARNESS.get(),
                ModItems.GREEN_HARNESS.get(),
                ModItems.RED_HARNESS.get(),
                ModItems.BLACK_HARNESS.get()
            )
            .method_35922(class_2960.method_60655("vanillabackport", "harnesses"));

        this.getOrCreateTagBuilder(ModItemTags.HAPPY_GHAST_FOOD)
            .add(class_1802.field_8543);

        this.getOrCreateTagBuilder(ModItemTags.HAPPY_GHAST_TEMPT_ITEMS)
            .method_26792(ModItemTags.HAPPY_GHAST_FOOD)
            .method_26792(ModItemTags.HARNESSES);

        this.getOrCreateTagBuilder(ModItemTags.EGGS)
            .add(class_1802.field_8803, ModItems.BLUE_EGG.get(), ModItems.BROWN_EGG.get());
        
        this.getOrCreateTagBuilder(class_3489.field_42611)
            .add(ModItems.COPPER_SWORD.get());
        
        this.getOrCreateTagBuilder(class_3489.field_42612)
            .add(ModItems.COPPER_AXE.get());
        
        this.getOrCreateTagBuilder(class_3489.field_42614)
            .add(ModItems.COPPER_PICKAXE.get());
        
        this.getOrCreateTagBuilder(class_3489.field_42615)
            .add(ModItems.COPPER_SHOVEL.get());
        
        this.getOrCreateTagBuilder(class_3489.field_42613)
            .add(ModItems.COPPER_HOE.get());
        
        this.getOrCreateTagBuilder(class_3489.field_48297)
            .add(ModItems.COPPER_HELMET.get());
        
        this.getOrCreateTagBuilder(class_3489.field_48296)
            .add(ModItems.COPPER_CHESTPLATE.get());
        
        this.getOrCreateTagBuilder(class_3489.field_48295)
            .add(ModItems.COPPER_LEGGINGS.get());
        
        this.getOrCreateTagBuilder(class_3489.field_48294)
            .add(ModItems.COPPER_BOOTS.get());
        
        this.getOrCreateTagBuilder(ModItemTags.SHEARABLE_FROM_COPPER_GOLEM)
            .add(class_1802.field_8880);
        
        this.getOrCreateTagBuilder(ModItemTags.SPEARS)
            .add(
                ModItems.WOODEN_SPEAR.get(),
                ModItems.STONE_SPEAR.get(),
                ModItems.COPPER_SPEAR.get(),
                ModItems.IRON_SPEAR.get(),
                ModItems.GOLDEN_SPEAR.get(),
                ModItems.DIAMOND_SPEAR.get(),
                ModItems.NETHERITE_SPEAR.get()
            );
        
        this.getOrCreateTagBuilder(ModItemTags.CAMEL_HUSK_FOOD)
            .add(class_1802.field_8073);
        
        this.getOrCreateTagBuilder(ModItemTags.ZOMBIE_HORSE_FOOD)
            .add(class_1802.field_17517);
        
        this.getOrCreateTagBuilder(ModItemTags.CUSHIONS)
            .add(
                ModItems.BLACK_CUSHION.get(),
                ModItems.BLUE_CUSHION.get(),
                ModItems.BROWN_CUSHION.get(),
                ModItems.CYAN_CUSHION.get(),
                ModItems.GRAY_CUSHION.get(),
                ModItems.GREEN_CUSHION.get(),
                ModItems.LIGHT_BLUE_CUSHION.get(),
                ModItems.LIGHT_GRAY_CUSHION.get(),
                ModItems.LIME_CUSHION.get(),
                ModItems.MAGENTA_CUSHION.get(),
                ModItems.ORANGE_CUSHION.get(),
                ModItems.PINK_CUSHION.get(),
                ModItems.PURPLE_CUSHION.get(),
                ModItems.RED_CUSHION.get(),
                ModItems.YELLOW_CUSHION.get(),
                ModItems.WHITE_CUSHION.get()
            );
        
        this.getOrCreateTagBuilder(ModItemTags.NAUTILUS_TAMING_ITEMS)
            .add(class_1802.field_8108, class_1802.field_8323);
        
        this.getOrCreateTagBuilder(ModItemTags.NAUTILUS_BUCKET_FOOD)
            .add(class_1802.field_8108, class_1802.field_8666, class_1802.field_8714, class_1802.field_8478);
        
        this.getOrCreateTagBuilder(ModItemTags.NAUTILUS_FOOD)
            .forceAddTag(class_3489.field_15527)
            .method_26792(ModItemTags.NAUTILUS_BUCKET_FOOD);
        
        this.getOrCreateTagBuilder(ModItemTags.DISABLES_WAYPOINT_TRACKING)
            .add(class_1802.field_17519)
            .forceAddTag(class_3489.field_48298);
        
        this.getOrCreateTagBuilder(ModItemTags.MUSHROOMS).add(
                class_1802.field_17516,
                class_1802.field_17517,
                ModBlocks.SHELF_MUSHROOM.get().method_8389()
            ).addOptionalTag(ConventionalItemTags.MUSHROOMS);
    }

    private void handleArchetypes() {
        this.getOrCreateTagBuilder(ModItemTags.SULFUR_CUBE_FOOD)
            .add(class_1802.field_8777);

        this.getOrCreateTagBuilder(ModItemTags.SULFUR_CUBE_ARCHETYPE_BOUNCY)
            .forceAddTag(class_3489.field_15537)
            .forceAddTag(class_3489.field_15539)
            .forceAddTag(class_3489.field_40987)
            .add(class_1802.field_40214);

        this.getOrCreateTagBuilder(ModItemTags.SULFUR_CUBE_ARCHETYPE_SLOW_BOUNCY)
            .add(class_1802.field_27064, class_1802.field_20407, class_1802.field_22000, class_1802.field_23843, class_1802.field_20390, class_1802.field_27020)
            // Chiseled Blocks
            .add(
                ModBlocks.CHISELED_CINNABAR.get().method_8389(),
                class_1802.field_28861,
                class_1802.field_23829,
                class_1802.field_23836,
                class_1802.field_8084,
                class_1802.field_8822,
                class_1802.field_8552,
                class_1802.field_8525,
                ModBlocks.CHISELED_SULFUR.get().method_8389(),
                class_1802.field_47001,
                class_1802.field_47026
            )
            .add(ModBlocks.CINNABAR.get().method_8389(), ModBlocks.CINNABAR_BRICKS.get().method_8389(), class_1802.field_29025, class_1802.field_20412)
            // Cracked Blocks
            .add(
                class_1802.field_29214,
                class_1802.field_29215,
                class_1802.field_23828,
                class_1802.field_23841,
                class_1802.field_8343
            )
            .add(class_1802.field_22013, class_1802.field_22421, class_1802.field_20409, class_1802.field_20385, class_1802.field_20406)
            .add(class_1802.field_28866, class_1802.field_28859, class_1802.field_28860)
            .add(
                class_1802.field_8603,
                class_1802.field_20401,
                class_1802.field_28043,
                class_1802.field_8733,
                class_1802.field_20399,
                class_1802.field_20400,
                class_1802.field_23847,
                class_1802.field_8801,
                class_1802.field_20394,
                class_1802.field_8055
            )
            .add(
                class_1802.field_20392,
                class_1802.field_20396,
                class_1802.field_37519,
                class_1802.field_20398,
                class_1802.field_8328,
                class_1802.field_8537,
                class_1802.field_8281
            )
            .add(
                class_1802.field_20411,
                class_1802.field_23069,
                class_1802.field_23848,
                class_1802.field_23837,
                ModBlocks.POLISHED_CINNABAR.get().method_8389(),
                class_1802.field_28871,
                class_1802.field_20403,
                class_1802.field_20397,
                ModBlocks.POLISHED_SULFUR.get().method_8389(),
                class_1802.field_47002
            )
            .add(
                class_1802.field_20404,
                class_1802.field_20405,
                class_1802.field_20393,
                class_1802.field_8490,
                class_1802.field_20402,
                class_1802.field_23830,
                class_1802.field_8702,
                class_1802.field_8746
            )
            .add(class_1802.field_20410, class_1802.field_20408, class_1802.field_8230, class_1802.field_20384, class_1802.field_8305)
            .add(class_1802.field_29024, class_1802.field_20386, class_1802.field_20387, class_1802.field_20388, class_1802.field_20389)
            .add(
                class_1802.field_20391,
                class_1802.field_20395,
                ModBlocks.SULFUR.get().method_8389(),
                ModBlocks.SULFUR_BRICKS.get().method_8389(),
                class_1802.field_27021,
                class_1802.field_47006,
                class_1802.field_22015
            )
            .forceAddTag(ConventionalItemTags.CONCRETE)
            .forceAddTag(class_3489.field_29197)
            .forceAddTag(class_3489.field_28997)
            .forceAddTag(class_3489.field_28996)
            .forceAddTag(class_3489.field_28995)
            .forceAddTag(class_3489.field_29198)
            .forceAddTag(class_3489.field_36270)
            .forceAddTag(ConventionalItemTags.GLAZED_TERRACOTTA);

        this.getOrCreateTagBuilder(ModItemTags.SULFUR_CUBE_ARCHETYPE_FAST_FLAT)
            // Coral Blocks
            .add(class_1802.field_8402, class_1802.field_8474, class_1802.field_8883, class_1802.field_8278, class_1802.field_8104)
            // Dead Coral Blocks
            .add(class_1802.field_8856, class_1802.field_8237, class_1802.field_8089, class_1802.field_8160, class_1802.field_8698)
            // Sponge / Kelp
            .add(class_1802.field_8535, class_1802.field_8554, class_1802.field_17533)
            // Moss
            .add(class_1802.field_28654, ModBlocks.PALE_MOSS_BLOCK.get().method_8389())
            // Resin
            .add(ModBlocks.RESIN_BLOCK.get().method_8389(), ModBlocks.RESIN_BRICKS.get().method_8389(), ModBlocks.CHISELED_RESIN_BRICKS.get().method_8389())
            // Farm Blocks
            .add(class_1802.field_17522, class_1802.field_17528, class_1802.field_17518, class_1802.field_17519, class_1802.field_8693)
            // Froglights
            .add(class_1802.field_37539, class_1802.field_37541, class_1802.field_37540);

        this.getOrCreateTagBuilder(ModItemTags.SULFUR_CUBE_ARCHETYPE_FAST_SLIDING)
            // Frosty Blocks
            .add(class_1802.field_8178, class_1802.field_8081, class_1802.field_8246);

        this.getOrCreateTagBuilder(ModItemTags.SULFUR_CUBE_ARCHETYPE_HIGH_RESISTANCE)
            // Soul Blocks
            .add(class_1802.field_8067, class_1802.field_21999);

        this.getOrCreateTagBuilder(ModItemTags.SULFUR_CUBE_ARCHETYPE_LIGHT)
            .forceAddTag(class_3489.field_15544);

        this.getOrCreateTagBuilder(ModItemTags.SULFUR_CUBE_ARCHETYPE_SLOW_FLAT)
            // Compacted Metal Blocks
            .add(class_1802.field_8773, class_1802.field_8494, class_1802.field_33506, class_1802.field_33507, class_1802.field_33505)
            // Netherite
            .add(class_1802.field_22018, class_1802.field_22019)
            // Copper Blocks
            .add(class_1802.field_27071, class_1802.field_27072, class_1802.field_27073, class_1802.field_27074, class_1802.field_27039, class_1802.field_27040, class_1802.field_27041, class_1802.field_33403)
            .add(class_1802.field_47018, class_1802.field_47019, class_1802.field_47020, class_1802.field_47021, class_1802.field_47022, class_1802.field_47023, class_1802.field_47024, class_1802.field_47025)
            // Cut Copper Blocks
            .add(class_1802.field_27075, class_1802.field_27076, class_1802.field_27077, class_1802.field_27030, class_1802.field_27042, class_1802.field_27043, class_1802.field_27044, class_1802.field_33404)
            .add(class_1802.field_46974, class_1802.field_46975, class_1802.field_46976, class_1802.field_46977, class_1802.field_46978, class_1802.field_46979, class_1802.field_46980, class_1802.field_46981)
            // Metal Ores
            .forceAddTag(class_3489.field_23065)
            .forceAddTag(class_3489.field_28994)
            .forceAddTag(class_3489.field_29199);

        this.getOrCreateTagBuilder(ModItemTags.SULFUR_CUBE_ARCHETYPE_SLOW_SLIDING)
            // Fun Guys
            .add(class_1802.field_8506, class_1802.field_8682, class_1802.field_17521, class_1802.field_8610)
            .add(class_1802.field_22017)
            .forceAddTag(class_3489.field_38837);

        this.getOrCreateTagBuilder(ModItemTags.SULFUR_CUBE_ARCHETYPE_STICKY)
            .add(class_1802.field_21087);

        this.getOrCreateTagBuilder(ModItemTags.SULFUR_CUBE_ARCHETYPE_EXPLOSIVE)
            .add(class_1802.field_8626);

        this.getOrCreateTagBuilder(ModItemTags.SULFUR_CUBE_ARCHETYPE_HOT)
            .add(class_1802.field_8354);

        this.getOrCreateTagBuilder(ModItemTags.SULFUR_CUBE_ARCHETYPE_REGULAR)
            .forceAddTag(ConventionalItemTags.CONCRETE_POWDERS)
            .add(class_1802.field_37537, class_1802.field_37514, class_1802.field_37518)
            .add(class_1802.field_8797)
            .add(class_1802.field_8831, class_1802.field_8460, class_1802.field_28655, class_1802.field_8382, class_1802.field_8270, class_1802.field_19060)
            .add(class_1802.field_8242);

        this.getOrCreateTagBuilder(ModItemTags.SULFUR_CUBE_SWALLOWABLE)
            .forceAddTag(ModItemTags.SULFUR_CUBE_ARCHETYPE_REGULAR)
            .forceAddTag(ModItemTags.SULFUR_CUBE_ARCHETYPE_BOUNCY)
            .forceAddTag(ModItemTags.SULFUR_CUBE_ARCHETYPE_SLOW_BOUNCY)
            .forceAddTag(ModItemTags.SULFUR_CUBE_ARCHETYPE_SLOW_FLAT)
            .forceAddTag(ModItemTags.SULFUR_CUBE_ARCHETYPE_FAST_FLAT)
            .forceAddTag(ModItemTags.SULFUR_CUBE_ARCHETYPE_LIGHT)
            .forceAddTag(ModItemTags.SULFUR_CUBE_ARCHETYPE_FAST_SLIDING)
            .forceAddTag(ModItemTags.SULFUR_CUBE_ARCHETYPE_SLOW_SLIDING)
            .forceAddTag(ModItemTags.SULFUR_CUBE_ARCHETYPE_HIGH_RESISTANCE)
            .forceAddTag(ModItemTags.SULFUR_CUBE_ARCHETYPE_STICKY)
            .forceAddTag(ModItemTags.SULFUR_CUBE_ARCHETYPE_EXPLOSIVE)
            .forceAddTag(ModItemTags.SULFUR_CUBE_ARCHETYPE_HOT);
    }

    private void handleConventionalTags() {
        this.getOrCreateTagBuilder(ConventionalItemTags.EGGS)
            .method_26792(ModItemTags.EGGS);

        this.getOrCreateTagBuilder(ConventionalItemTags.DYED_BLACK)
            .add(ModItems.BLACK_BUNDLE.get(), ModItems.BLACK_HARNESS.get(), ModItems.BLACK_CUSHION.get());

        this.getOrCreateTagBuilder(ConventionalItemTags.DYED_BLUE)
            .add(ModItems.BLUE_BUNDLE.get(), ModItems.BLUE_HARNESS.get(), ModItems.BLUE_CUSHION.get());

        this.getOrCreateTagBuilder(ConventionalItemTags.DYED_BROWN)
            .add(ModItems.BROWN_BUNDLE.get(), ModItems.BROWN_HARNESS.get(), ModItems.BROWN_CUSHION.get());

        this.getOrCreateTagBuilder(ConventionalItemTags.DYED_CYAN)
            .add(ModItems.CYAN_BUNDLE.get(), ModItems.CYAN_HARNESS.get(), ModItems.CYAN_CUSHION.get());

        this.getOrCreateTagBuilder(ConventionalItemTags.DYED_GRAY)
            .add(ModItems.GRAY_BUNDLE.get(), ModItems.GRAY_HARNESS.get(), ModItems.GRAY_CUSHION.get());

        this.getOrCreateTagBuilder(ConventionalItemTags.DYED_GREEN)
            .add(ModItems.GREEN_BUNDLE.get(), ModItems.GREEN_HARNESS.get(), ModItems.GRAY_CUSHION.get());

        this.getOrCreateTagBuilder(ConventionalItemTags.DYED_LIGHT_BLUE)
            .add(ModItems.LIGHT_BLUE_BUNDLE.get(), ModItems.LIGHT_BLUE_HARNESS.get(), ModItems.LIGHT_BLUE_CUSHION.get());

        this.getOrCreateTagBuilder(ConventionalItemTags.DYED_LIGHT_GRAY)
            .add(ModItems.LIGHT_GRAY_BUNDLE.get(), ModItems.LIGHT_GRAY_HARNESS.get(), ModItems.LIGHT_GRAY_CUSHION.get());

        this.getOrCreateTagBuilder(ConventionalItemTags.DYED_LIME)
            .add(ModItems.LIME_BUNDLE.get(), ModItems.LIME_HARNESS.get(), ModItems.LIME_CUSHION.get());

        this.getOrCreateTagBuilder(ConventionalItemTags.DYED_MAGENTA)
            .add(ModItems.MAGENTA_BUNDLE.get(), ModItems.MAGENTA_HARNESS.get(), ModItems.MAGENTA_CUSHION.get());

        this.getOrCreateTagBuilder(ConventionalItemTags.DYED_ORANGE)
            .add(ModItems.ORANGE_BUNDLE.get(), ModItems.ORANGE_HARNESS.get(), ModItems.ORANGE_CUSHION.get());

        this.getOrCreateTagBuilder(ConventionalItemTags.DYED_PINK)
            .add(ModItems.PINK_BUNDLE.get(), ModItems.PINK_HARNESS.get(), ModItems.PINK_CUSHION.get());

        this.getOrCreateTagBuilder(ConventionalItemTags.DYED_PURPLE)
            .add(ModItems.PURPLE_BUNDLE.get(), ModItems.PURPLE_HARNESS.get(), ModItems.PURPLE_CUSHION.get());

        this.getOrCreateTagBuilder(ConventionalItemTags.DYED_RED)
            .add(ModItems.RED_BUNDLE.get(), ModItems.RED_HARNESS.get(), ModItems.RED_CUSHION.get());

        this.getOrCreateTagBuilder(ConventionalItemTags.DYED_YELLOW)
            .add(ModItems.YELLOW_BUNDLE.get(), ModItems.YELLOW_HARNESS.get(), ModItems.YELLOW_CUSHION.get());

        this.getOrCreateTagBuilder(ConventionalItemTags.DYED_WHITE)
            .add(ModItems.WHITE_BUNDLE.get(), ModItems.WHITE_HARNESS.get(), ModItems.WHITE_CUSHION.get());

        this.getOrCreateTagBuilder(ConventionalItemTags.NUGGETS)
            .add(ModItems.COPPER_NUGGET.get());
        
        this.getOrCreateTagBuilder(ConventionalItemTags.NUGGETS_COPPER)
            .add(ModItems.COPPER_NUGGET.get());

        this.getOrCreateTagBuilder(ConventionalItemTags.MUSIC_DISCS)
            .add(ModItems.MUSIC_DISC_TEARS.get(), ModItems.MUSIC_DISC_LAVA_CHICKEN.get(), ModItems.MUSIC_DISC_BOUNCE.get());

        this.getOrCreateTagBuilder(ConventionalItemTags.GLAZED_TERRACOTTA)
            .add(
                class_1802.field_8096,
                class_1802.field_8484,
                class_1802.field_8394,
                class_1802.field_8257,
                class_1802.field_8885,
                class_1802.field_8244,
                class_1802.field_8640,
                class_1802.field_8172,
                class_1802.field_8649,
                class_1802.field_8318,
                class_1802.field_8139,
                class_1802.field_8277,
                class_1802.field_8562,
                class_1802.field_8870,
                class_1802.field_8889,
                class_1802.field_8177
            );

        this.getOrCreateTagBuilder(ConventionalItemTags.CONCRETE)
            .add(
                class_1802.field_8704,
                class_1802.field_8737,
                class_1802.field_8762,
                class_1802.field_8637,
                class_1802.field_8333,
                class_1802.field_8120,
                class_1802.field_8364,
                class_1802.field_8735,
                class_1802.field_8839,
                class_1802.field_8508,
                class_1802.field_8771,
                class_1802.field_8127,
                class_1802.field_8411,
                class_1802.field_8197,
                class_1802.field_8686,
                class_1802.field_8341
            );

        this.getOrCreateTagBuilder(ConventionalItemTags.CONCRETE_POWDERS)
            .add(
                class_1802.field_8516,
                class_1802.field_8164,
                class_1802.field_8437,
                class_1802.field_8593,
                class_1802.field_8818,
                class_1802.field_8198,
                class_1802.field_8764,
                class_1802.field_8558,
                class_1802.field_8418,
                class_1802.field_8336,
                class_1802.field_8487,
                class_1802.field_8222,
                class_1802.field_8690,
                class_1802.field_8757,
                class_1802.field_8205,
                class_1802.field_8582
            );

        this.getOrCreateTagBuilder(CreateItemTags.MODDED_STRIPPED_WOOD)
            .add(ModBlocks.STRIPPED_PALE_OAK_WOOD.get().method_8389())
            .add(ModBlocks.STRIPPED_POPLAR_WOOD.get().method_8389());

        this.getOrCreateTagBuilder(CreateItemTags.MODDED_STRIPPED_LOGS)
            .add(ModBlocks.STRIPPED_PALE_OAK_LOG.get().method_8389())
            .add(ModBlocks.STRIPPED_POPLAR_LOG.get().method_8389());
        
        this.getOrCreateTagBuilder(ModItemTags.SHEARABLE_FROM_COPPER_GOLEM)
            .add(class_1802.field_8880);
        
        this.getOrCreateTagBuilder(ConventionalItemTags.HORSE_ARMOR)
            .add(ModItems.COPPER_HORSE_ARMOR.get())
            .add(ModItems.NETHERITE_HORSE_ARMOR.get());
        
        this.getOrCreateTagBuilder(class_3489.field_48310)
            .method_26792(ModItemTags.SPEARS);
        
        this.getOrCreateTagBuilder(class_3489.field_48304)
            .method_26792(ModItemTags.SPEARS);
        
        this.getOrCreateTagBuilder(class_3489.field_50108)
            .method_26792(ModItemTags.SPEARS);
        
        this.getOrCreateTagBuilder(class_3489.field_48305)
            .method_26792(ModItemTags.SPEARS);
        
        this.getOrCreateTagBuilder(ModItemTags.LUNGE_ENCHANTABLE)
            .method_26792(ModItemTags.SPEARS);
    }

    protected DualTagHolder getDualTagBuilder(class_6862<class_1792> forge, class_6862<class_1792> fabric) {
        return new DualTagHolder(this.getOrCreateTagBuilder(fabric), this.getOrCreateTagBuilder(forge));
    }

    protected record DualTagHolder(FabricTagProvider<class_1792>.FabricTagBuilder forge, FabricTagProvider<class_1792>.FabricTagBuilder fabric) {
        public DualTagHolder add(class_1935 entry) {
            this.forge.add(entry.method_8389());
            this.fabric.add(entry.method_8389());
            return this;
        }

        public DualTagHolder add(class_1792... toAdd) {
            this.forge.add(toAdd);
            this.fabric.add(toAdd);
            return this;
        }

        public DualTagHolder addOptional(class_2960 location) {
            this.forge.method_35922(location);
            this.fabric.method_35922(location);
            return this;
        }

        public DualTagHolder addTag(class_6862<class_1792> tag) {
            this.forge.method_26792(tag);
            this.fabric.method_26792(tag);
            return this;
        }

        public DualTagHolder addOptionalTag(class_6862<class_1792> tag) {
            this.forge.addOptionalTag(tag);
            this.fabric.addOptionalTag(tag);
            return this;
        }
    }
}