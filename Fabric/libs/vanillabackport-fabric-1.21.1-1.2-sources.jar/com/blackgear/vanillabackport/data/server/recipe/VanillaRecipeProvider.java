package com.blackgear.vanillabackport.data.server.recipe;

import com.google.common.collect.Sets;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_161;
import net.minecraft.class_1860;
import net.minecraft.class_2405;
import net.minecraft.class_2960;
import net.minecraft.class_5797;
import net.minecraft.class_7225;
import net.minecraft.class_7403;
import net.minecraft.class_7784;
import net.minecraft.class_7924;
import net.minecraft.class_8779;
import net.minecraft.class_8790;

public abstract class VanillaRecipeProvider implements class_2405 {
    private final class_7784.class_7489 recipePathProvider;
    private final class_7784.class_7489 advancementPathProvider;
    private final CompletableFuture<class_7225.class_7874> registries;

    public VanillaRecipeProvider(class_7784 output, CompletableFuture<class_7225.class_7874> registries) {
        this.recipePathProvider = output.method_60917(class_7924.field_52178);
        this.advancementPathProvider = output.method_60917(class_7924.field_52177);
        this.registries = registries;
    }

    @Override
    public CompletableFuture<?> method_10319(class_7403 cache) {
        return this.registries.thenCompose(provider -> this.run(cache, provider));
    }

    private CompletableFuture<?> run(class_7403 cache, class_7225.class_7874 registries) {
        Set<class_2960> duplicates = Sets.newHashSet();
        List<CompletableFuture<?>> output = new ArrayList<>();
        this.buildRecipes(new class_8790() {
            @Override
            public void method_53819(class_2960 location, class_1860<?> recipe, @Nullable class_8779 advancement) {
                if (!duplicates.add(location)) {
                    throw new IllegalStateException("Duplicate recipe " + location);
                } else {
                    output.add(class_2405.method_53496(cache, registries, class_1860.field_47319, recipe, recipePathProvider.method_44107(location)));
                    if (advancement != null) {
                        output.add(class_2405.method_53496(cache, registries, class_161.field_47179, advancement.comp_1920(), advancementPathProvider.method_44107(advancement.comp_1919())));
                    }
                }
            }

            @Override @SuppressWarnings("removal")
            public class_161.class_162 method_53818() {
                return class_161.class_162.method_51698().method_708(class_5797.field_39377);
            }
        });
        return CompletableFuture.allOf(output.toArray(CompletableFuture[]::new));
    }

    protected abstract void buildRecipes(class_8790 output);
}