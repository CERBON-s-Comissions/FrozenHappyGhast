package com.blackgear.vanillabackport.data.server.tags;

import com.blackgear.vanillabackport.common.worldgen.structures.WildernessBoundStructures;
import com.blackgear.vanillabackport.core.data.tags.ModStructureTags;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_2474;
import net.minecraft.class_3195;
import net.minecraft.class_7058;
import net.minecraft.class_7225;
import net.minecraft.class_7784;
import net.minecraft.class_7924;

public class StructureTagGenerator extends class_2474<class_3195> {
    public StructureTagGenerator(class_7784 output, CompletableFuture<class_7225.class_7874> lookupProvider) {
        super(output, class_7924.field_41246, lookupProvider);
    }

    @Override
    protected void method_10514(class_7225.class_7874 provider) {
        this.method_10512(ModStructureTags.ABANDONED_CAMP)
            .method_46835(WildernessBoundStructures.ABANDONED_CAMP_BAMBOO_JUNGLE)
            .method_46835(WildernessBoundStructures.ABANDONED_CAMP_BIRCH_FOREST)
            .method_46835(WildernessBoundStructures.ABANDONED_CAMP_CHERRY_GROVE)
            .method_46835(WildernessBoundStructures.ABANDONED_CAMP_DAPPLED_FOREST)
            .method_46835(WildernessBoundStructures.ABANDONED_CAMP_FLOWER_FOREST)
            .method_46835(WildernessBoundStructures.ABANDONED_CAMP_FOREST)
            .method_46835(WildernessBoundStructures.ABANDONED_CAMP_MEADOW)
            .method_46835(WildernessBoundStructures.ABANDONED_CAMP_OLD_GROWTH_BIRCH_FOREST)
            .method_46835(WildernessBoundStructures.ABANDONED_CAMP_OLD_GROWTH_PINE_TAIGA)
            .method_46835(WildernessBoundStructures.ABANDONED_CAMP_OLD_GROWTH_SPRUCE_TAIGA)
            .method_46835(WildernessBoundStructures.ABANDONED_CAMP_PALE_GARDEN)
            .method_46835(WildernessBoundStructures.ABANDONED_CAMP_SAVANNA)
            .method_46835(WildernessBoundStructures.ABANDONED_CAMP_SNOWY_TAIGA)
            .method_46835(WildernessBoundStructures.ABANDONED_CAMP_SPARSE_JUNGLE)
            .method_46835(WildernessBoundStructures.ABANDONED_CAMP_SWAMP)
            .method_46835(WildernessBoundStructures.ABANDONED_CAMP_TAIGA)
            .method_46835(WildernessBoundStructures.ABANDONED_CAMP_WINDSWEPT_FOREST)
            .method_46835(WildernessBoundStructures.ABANDONED_CAMP_WOODED_BADLANDS);
        
        this.method_10512(ModStructureTags.ON_ABANDONED_CAMP_BAMBOO_JUNGLE_MAPS).method_46835(WildernessBoundStructures.ABANDONED_CAMP_BAMBOO_JUNGLE);
        this.method_10512(ModStructureTags.ON_ABANDONED_CAMP_CHERRY_GROVE_MAPS).method_46835(WildernessBoundStructures.ABANDONED_CAMP_CHERRY_GROVE);
        this.method_10512(ModStructureTags.ON_ABANDONED_CAMP_BIRCH_FOREST_MAPS).method_46835(WildernessBoundStructures.ABANDONED_CAMP_BIRCH_FOREST);
        this.method_10512(ModStructureTags.ON_ABANDONED_CAMP_DAPPLED_FOREST_MAPS).method_46835(WildernessBoundStructures.ABANDONED_CAMP_DAPPLED_FOREST);
        this.method_10512(ModStructureTags.ON_ABANDONED_CAMP_FLOWER_FOREST_MAPS).method_46835(WildernessBoundStructures.ABANDONED_CAMP_FLOWER_FOREST);
        this.method_10512(ModStructureTags.ON_ABANDONED_CAMP_PALE_GARDEN_MAPS).method_46835(WildernessBoundStructures.ABANDONED_CAMP_PALE_GARDEN);
        this.method_10512(ModStructureTags.ON_ABANDONED_CAMP_SWAMP_MAPS).method_46835(WildernessBoundStructures.ABANDONED_CAMP_SWAMP);
        this.method_10512(ModStructureTags.ON_ABANDONED_CAMP_WINDSWEPT_FOREST_MAPS).method_46835(WildernessBoundStructures.ABANDONED_CAMP_WINDSWEPT_FOREST);
        this.method_10512(ModStructureTags.ON_ANCIENT_CITY_MAPS).method_46835(class_7058.field_38428);
        this.method_10512(ModStructureTags.ON_MINESHAFT_MAPS).method_46835(class_7058.field_37169);
        this.method_10512(ModStructureTags.ON_DESERT_PYRAMID_MAPS).method_46835(class_7058.field_37173);
        this.method_10512(ModStructureTags.ON_OCEAN_RUIN_WARM_MAPS).method_46835(class_7058.field_37181);
    }
}