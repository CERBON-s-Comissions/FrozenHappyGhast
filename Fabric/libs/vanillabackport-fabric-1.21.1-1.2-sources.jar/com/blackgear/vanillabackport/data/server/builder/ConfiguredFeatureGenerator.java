package com.blackgear.vanillabackport.data.server.builder;

import com.blackgear.vanillabackport.common.worldgen.features.ChaosCubedFeatures;
import com.blackgear.vanillabackport.common.worldgen.features.SpringToLifeFeatures;
import com.blackgear.vanillabackport.common.worldgen.features.TheGardenAwakensFeatures;
import com.blackgear.vanillabackport.common.worldgen.features.WildernessBoundFeatures;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricDynamicRegistryProvider;
import net.minecraft.class_2975;
import net.minecraft.class_5321;
import net.minecraft.class_7225;
import net.minecraft.class_7924;
import java.util.concurrent.CompletableFuture;

public class ConfiguredFeatureGenerator extends FabricDynamicRegistryProvider {
    public ConfiguredFeatureGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected void configure(class_7225.class_7874 provider, Entries entries) {
        // The Garden Awakens
        this.add(provider, entries, TheGardenAwakensFeatures.PALE_OAK);
        this.add(provider, entries, TheGardenAwakensFeatures.PALE_OAK_BONEMEAL);
        this.add(provider, entries, TheGardenAwakensFeatures.PALE_OAK_CREAKING);

        this.add(provider, entries, TheGardenAwakensFeatures.FLOWER_PALE_GARDEN);
        this.add(provider, entries, TheGardenAwakensFeatures.PALE_GARDEN_FLOWERS);
        this.add(provider, entries, TheGardenAwakensFeatures.PALE_GARDEN_VEGETATION);
        this.add(provider, entries, TheGardenAwakensFeatures.PALE_MOSS_VEGETATION);
        this.add(provider, entries, TheGardenAwakensFeatures.PALE_MOSS_PATCH);
        this.add(provider, entries, TheGardenAwakensFeatures.PALE_MOSS_PATCH_BONEMEAL);

        // Spring to Life
        this.add(provider, entries, SpringToLifeFeatures.PATCH_BUSH);
        this.add(provider, entries, SpringToLifeFeatures.PATCH_FIREFLY_BUSH);

        this.add(provider, entries, SpringToLifeFeatures.WILDFLOWERS_BIRCH_FOREST);
        this.add(provider, entries, SpringToLifeFeatures.WILDFLOWERS_MEADOW);

        this.add(provider, entries, SpringToLifeFeatures.PATCH_DRY_GRASS);

        this.add(provider, entries, SpringToLifeFeatures.PATCH_LEAF_LITTER);
        this.add(provider, entries, SpringToLifeFeatures.LEAF_LITTER_SPARSE);
        this.add(provider, entries, SpringToLifeFeatures.LEAF_LITTER_THICK);

        this.add(provider, entries, SpringToLifeFeatures.CACTUS_FLOWER);

        this.add(provider, entries, SpringToLifeFeatures.FALLEN_OAK_TREE);
        this.add(provider, entries, SpringToLifeFeatures.FALLEN_BIRCH_TREE);
        this.add(provider, entries, SpringToLifeFeatures.FALLEN_SUPER_BIRCH_TREE);
        this.add(provider, entries, SpringToLifeFeatures.FALLEN_JUNGLE_TREE);
        this.add(provider, entries, SpringToLifeFeatures.FALLEN_SPRUCE_TREE);

        // Chaos Cubed
        this.add(provider, entries, ChaosCubedFeatures.SULFUR_POOL);
        this.add(provider, entries, ChaosCubedFeatures.SULFUR_SPRING);
        this.add(provider, entries, ChaosCubedFeatures.ROOTED_SULFUR_SPRING);
        this.add(provider, entries, ChaosCubedFeatures.SULFUR_SPIKE_CLUSTER);
        this.add(provider, entries, ChaosCubedFeatures.SULFUR_SPIKE);
        
        // Wilderness Bound
        this.add(provider, entries, WildernessBoundFeatures.RED_POPLAR);
        this.add(provider, entries, WildernessBoundFeatures.ORANGE_POPLAR);
        this.add(provider, entries, WildernessBoundFeatures.YELLOW_POPLAR);
        this.add(provider, entries, WildernessBoundFeatures.FALLEN_POPLAR_TREE);
        this.add(provider, entries, WildernessBoundFeatures.RED_SHRUB);
        this.add(provider, entries, WildernessBoundFeatures.BROWN_MUSHROOM);
        this.add(provider, entries, WildernessBoundFeatures.TREES_DAPPLED_FOREST);
    }

    private void add(class_7225.class_7874 provider, Entries entries, class_5321<class_2975<?, ?>> key) {
        final class_7225.class_7226<class_2975<?, ?>> registry = provider.method_46762(class_7924.field_41239);
        entries.add(key, registry.method_46747(key).comp_349());
    }

    @Override
    public String method_10321() {
        return "worldgen/configured_feature";
    }
}