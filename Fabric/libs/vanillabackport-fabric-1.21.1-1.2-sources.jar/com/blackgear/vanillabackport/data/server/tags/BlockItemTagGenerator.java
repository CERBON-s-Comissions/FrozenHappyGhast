package com.blackgear.vanillabackport.data.server.tags;

import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import com.blackgear.vanillabackport.core.data.tags.ModBlockTags;
import com.blackgear.vanillabackport.core.data.tags.ModItemTags;
import com.blackgear.vanillabackport.core.data.tags.loader.ConventionalBlockTags;
import com.blackgear.vanillabackport.core.data.tags.loader.ConventionalItemTags;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_3481;
import net.minecraft.class_3489;
import net.minecraft.class_6862;
import net.minecraft.class_7924;
import java.util.Collection;
import java.util.function.Supplier;

public abstract class BlockItemTagGenerator {
    protected void addTags() {
        this.handleConventionalTags();

        this.tag(class_3481.field_15471, class_3489.field_15537)
            .add(ModBlocks.PALE_OAK_PLANKS.get())
            .add(ModBlocks.POPLAR_PLANKS.get());

        this.tag(class_3481.field_15499, class_3489.field_15555)
            .add(ModBlocks.PALE_OAK_BUTTON.get())
            .add(ModBlocks.POPLAR_BUTTON.get());

        this.tag(class_3481.field_15494, class_3489.field_15552)
            .add(ModBlocks.PALE_OAK_DOOR.get())
            .add(ModBlocks.POPLAR_DOOR.get());

        this.tag(class_3481.field_15502, class_3489.field_15557)
            .add(ModBlocks.PALE_OAK_STAIRS.get())
            .add(ModBlocks.POPLAR_STAIRS.get());

        this.tag(class_3481.field_15468, class_3489.field_15534)
            .add(ModBlocks.PALE_OAK_SLAB.get())
            .add(ModBlocks.POPLAR_SLAB.get());

        this.tag(class_3481.field_17619, class_3489.field_17620)
            .add(ModBlocks.PALE_OAK_FENCE.get())
            .add(ModBlocks.POPLAR_FENCE.get());

        this.tag(class_3481.field_25147, class_3489.field_40858)
            .add(ModBlocks.PALE_OAK_FENCE_GATE.get())
            .add(ModBlocks.POPLAR_FENCE_GATE.get());

        this.tag(class_3481.field_15477, class_3489.field_15540)
            .add(ModBlocks.PALE_OAK_PRESSURE_PLATE.get())
            .add(ModBlocks.POPLAR_PRESSURE_PLATE.get());

        this.tag(class_3481.field_15462, class_3489.field_15528)
            .add(ModBlocks.PALE_OAK_SAPLING.get())
            .add(ModBlocks.POPLAR_SAPLING.get());

        this.tag(ModBlockTags.PALE_OAK_LOGS, ModItemTags.PALE_OAK_LOGS)
            .add(ModBlocks.PALE_OAK_LOG.get(), ModBlocks.PALE_OAK_WOOD.get(), ModBlocks.STRIPPED_PALE_OAK_LOG.get(), ModBlocks.STRIPPED_PALE_OAK_WOOD.get());
            
        this.tag(ModBlockTags.POPLAR_LOGS, ModItemTags.POPLAR_LOGS)
            .add(ModBlocks.POPLAR_LOG.get(), ModBlocks.POPLAR_WOOD.get(), ModBlocks.STRIPPED_POPLAR_LOG.get(), ModBlocks.STRIPPED_POPLAR_WOOD.get());

        this.tag(class_3481.field_23210, class_3489.field_23212)
            .addTag(ModBlockTags.PALE_OAK_LOGS)
            .addTag(ModBlockTags.POPLAR_LOGS);

        this.tag(class_3481.field_15469, class_3489.field_15535)
            .add(
                ModBlocks.RESIN_BRICK_SLAB.get(),
                ModBlocks.CINNABAR_SLAB.get(),
                ModBlocks.POLISHED_CINNABAR_SLAB.get(),
                ModBlocks.CINNABAR_BRICK_SLAB.get(),
                ModBlocks.SULFUR_SLAB.get(),
                ModBlocks.POLISHED_SULFUR_SLAB.get(),
                ModBlocks.SULFUR_BRICK_SLAB.get()
            )
            .addTag(ModBlockTags.WOOL_SLABS);

        this.tag(class_3481.field_15504, class_3489.field_15560)
            .add(
                ModBlocks.RESIN_BRICK_WALL.get(),
                ModBlocks.CINNABAR_WALL.get(),
                ModBlocks.POLISHED_CINNABAR_WALL.get(),
                ModBlocks.CINNABAR_BRICK_WALL.get(),
                ModBlocks.SULFUR_WALL.get(),
                ModBlocks.POLISHED_SULFUR_WALL.get(),
                ModBlocks.SULFUR_BRICK_WALL.get()
            );

        this.tag(class_3481.field_15459, class_3489.field_15526)
            .add(
                ModBlocks.RESIN_BRICK_STAIRS.get(),
                ModBlocks.CINNABAR_STAIRS.get(),
                ModBlocks.POLISHED_CINNABAR_STAIRS.get(),
                ModBlocks.CINNABAR_BRICK_STAIRS.get(),
                ModBlocks.SULFUR_STAIRS.get(),
                ModBlocks.POLISHED_SULFUR_STAIRS.get(),
                ModBlocks.SULFUR_BRICK_STAIRS.get()
            )
            .addTag(ModBlockTags.WOOL_STAIRS);

        this.tag(class_3481.field_15503, class_3489.field_15558)
            .add(ModBlocks.PALE_OAK_LEAVES.get())
            .add(ModBlocks.RED_POPLAR_LEAVES.get())
            .add(ModBlocks.ORANGE_POPLAR_LEAVES.get())
            .add(ModBlocks.YELLOW_POPLAR_LEAVES.get());

        this.tag(class_3481.field_15491, class_3489.field_15550)
            .add(ModBlocks.PALE_OAK_TRAPDOOR.get())
            .add(ModBlocks.POPLAR_TRAPDOOR.get());

        this.tag(class_3481.field_15480, class_3489.field_15543)
            .add(ModBlocks.OPEN_EYEBLOSSOM.get(), ModBlocks.CLOSED_EYEBLOSSOM.get());

        this.tag(class_3481.field_20339, class_3489.field_20344)
            .add(ModBlocks.WILDFLOWERS.get(), ModBlocks.CACTUS_FLOWER.get());

        this.tag(class_3481.field_29822, class_3489.field_36269)
            .add(ModBlocks.PALE_MOSS_BLOCK.get());

        this.tag(class_3481.field_15472, class_3489.field_15533)
            .add(ModBlocks.PALE_OAK_SIGN.getFirst().get())
            .add(ModBlocks.POPLAR_SIGN.getFirst().get());

        this.tag(class_3481.field_40103, class_3489.field_40108)
            .add(ModBlocks.PALE_OAK_HANGING_SIGN.getFirst().get())
            .add(ModBlocks.POPLAR_HANGING_SIGN.getFirst().get());
        
        this.tag(ModBlockTags.COPPER, ModItemTags.COPPER) //TODO: check for conventional tag
            .add(class_2246.field_27119)
            .add(class_2246.field_27118)
            .add(class_2246.field_27117)
            .add(class_2246.field_27116)
            .add(class_2246.field_27133)
            .add(class_2246.field_27135)
            .add(class_2246.field_27134)
            .add(class_2246.field_33407);
        
        this.tag(ModBlockTags.COPPER_GOLEM_STATUES, ModItemTags.COPPER_GOLEM_STATUES)
            .add(ModBlocks.COPPER_GOLEM_STATUE.get())
            .add(ModBlocks.EXPOSED_COPPER_GOLEM_STATUE.get())
            .add(ModBlocks.WEATHERED_COPPER_GOLEM_STATUE.get())
            .add(ModBlocks.OXIDIZED_COPPER_GOLEM_STATUE.get())
            .add(ModBlocks.WAXED_COPPER_GOLEM_STATUE.get())
            .add(ModBlocks.WAXED_EXPOSED_COPPER_GOLEM_STATUE.get())
            .add(ModBlocks.WAXED_WEATHERED_COPPER_GOLEM_STATUE.get())
            .add(ModBlocks.WAXED_OXIDIZED_COPPER_GOLEM_STATUE.get());
        
        this.tag(ModBlockTags.LANTERNS, ModItemTags.LANTERNS)
            .add(class_2246.field_16541, class_2246.field_22110)
            .addAll(ModBlocks.COPPER_LANTERN.asList().stream().map(Supplier::get).toList());
        
        this.tag(ModBlockTags.BARS, ModItemTags.BARS)
            .add(class_2246.field_10576)
            .addAll(ModBlocks.COPPER_BARS.asList().stream().map(Supplier::get).toList());
        
        this.tag(ModBlockTags.CHAINS, ModItemTags.CHAINS)
            .add(class_2246.field_23985)
            .addAll(ModBlocks.COPPER_CHAIN.asList().stream().map(Supplier::get).toList());
        
        this.tag(ModBlockTags.LIGHTNING_RODS, ModItemTags.LIGHTNING_RODS)
            .add(class_2246.field_27171)
            .add(ModBlocks.EXPOSED_LIGHTNING_ROD.get())
            .add(ModBlocks.WEATHERED_LIGHTNING_ROD.get())
            .add(ModBlocks.OXIDIZED_LIGHTNING_ROD.get())
            .add(ModBlocks.WAXED_LIGHTNING_ROD.get())
            .add(ModBlocks.WAXED_EXPOSED_LIGHTNING_ROD.get())
            .add(ModBlocks.WAXED_WEATHERED_LIGHTNING_ROD.get())
            .add(ModBlocks.WAXED_OXIDIZED_LIGHTNING_ROD.get());

        this.tag(ModBlockTags.COPPER_CHESTS, ModItemTags.COPPER_CHESTS)
            .add(
                ModBlocks.COPPER_CHEST.get(),
                ModBlocks.EXPOSED_COPPER_CHEST.get(),
                ModBlocks.WEATHERED_COPPER_CHEST.get(),
                ModBlocks.OXIDIZED_COPPER_CHEST.get(),
                ModBlocks.WAXED_COPPER_CHEST.get(),
                ModBlocks.WAXED_EXPOSED_COPPER_CHEST.get(),
                ModBlocks.WAXED_WEATHERED_COPPER_CHEST.get(),
                ModBlocks.WAXED_OXIDIZED_COPPER_CHEST.get()
            );
        
        this.tag(ModBlockTags.WOODEN_SHELVES, ModItemTags.WOODEN_SHELVES)
            .add(ModBlocks.ACACIA_SHELF.get())
            .add(ModBlocks.BAMBOO_SHELF.get())
            .add(ModBlocks.BIRCH_SHELF.get())
            .add(ModBlocks.CHERRY_SHELF.get())
            .add(ModBlocks.CRIMSON_SHELF.get())
            .add(ModBlocks.DARK_OAK_SHELF.get())
            .add(ModBlocks.JUNGLE_SHELF.get())
            .add(ModBlocks.MANGROVE_SHELF.get())
            .add(ModBlocks.OAK_SHELF.get())
            .add(ModBlocks.PALE_OAK_SHELF.get())
            .add(ModBlocks.SPRUCE_SHELF.get())
            .add(ModBlocks.WARPED_SHELF.get())
            .add(ModBlocks.POPLAR_SHELF.get());
        
        this.tag(ModBlockTags.WOOL_STAIRS, ModItemTags.WOOL_STAIRS)
            .add(
                ModBlocks.BLACK_WOOL_STAIRS.get(),
                ModBlocks.BLUE_WOOL_STAIRS.get(),
                ModBlocks.BROWN_WOOL_STAIRS.get(),
                ModBlocks.CYAN_WOOL_STAIRS.get(),
                ModBlocks.GRAY_WOOL_STAIRS.get(),
                ModBlocks.GREEN_WOOL_STAIRS.get(),
                ModBlocks.LIGHT_BLUE_WOOL_STAIRS.get(),
                ModBlocks.LIGHT_GRAY_WOOL_STAIRS.get(),
                ModBlocks.LIME_WOOL_STAIRS.get(),
                ModBlocks.MAGENTA_WOOL_STAIRS.get(),
                ModBlocks.ORANGE_WOOL_STAIRS.get(),
                ModBlocks.PINK_WOOL_STAIRS.get(),
                ModBlocks.PURPLE_WOOL_STAIRS.get(),
                ModBlocks.RED_WOOL_STAIRS.get(),
                ModBlocks.YELLOW_WOOL_STAIRS.get(),
                ModBlocks.WHITE_WOOL_STAIRS.get()
            );
        
        this.tag(ModBlockTags.WOOL_SLABS, ModItemTags.WOOL_SLABS)
            .add(
                ModBlocks.BLACK_WOOL_SLAB.get(),
                ModBlocks.BLUE_WOOL_SLAB.get(),
                ModBlocks.BROWN_WOOL_SLAB.get(),
                ModBlocks.CYAN_WOOL_SLAB.get(),
                ModBlocks.GRAY_WOOL_SLAB.get(),
                ModBlocks.GREEN_WOOL_SLAB.get(),
                ModBlocks.LIGHT_BLUE_WOOL_SLAB.get(),
                ModBlocks.LIGHT_GRAY_WOOL_SLAB.get(),
                ModBlocks.LIME_WOOL_SLAB.get(),
                ModBlocks.MAGENTA_WOOL_SLAB.get(),
                ModBlocks.ORANGE_WOOL_SLAB.get(),
                ModBlocks.PINK_WOOL_SLAB.get(),
                ModBlocks.PURPLE_WOOL_SLAB.get(),
                ModBlocks.RED_WOOL_SLAB.get(),
                ModBlocks.YELLOW_WOOL_SLAB.get(),
                ModBlocks.WHITE_WOOL_SLAB.get()
            );
        
        this.tag(class_3481.field_38835, class_3489.field_28300)
            .addTag(ModBlockTags.WOOL_STAIRS)
            .addTag(ModBlockTags.WOOL_SLABS);

        this.tag(ModBlockTags.CONCRETE_STAIRS, ModItemTags.CONCRETE_STAIRS)
            .add(ModBlocks.BLACK_CONCRETE_STAIRS.get())
            .add(ModBlocks.BLUE_CONCRETE_STAIRS.get())
            .add(ModBlocks.BROWN_CONCRETE_STAIRS.get())
            .add(ModBlocks.CYAN_CONCRETE_STAIRS.get())
            .add(ModBlocks.GRAY_CONCRETE_STAIRS.get())
            .add(ModBlocks.GREEN_CONCRETE_STAIRS.get())
            .add(ModBlocks.LIGHT_BLUE_CONCRETE_STAIRS.get())
            .add(ModBlocks.LIGHT_GRAY_CONCRETE_STAIRS.get())
            .add(ModBlocks.LIME_CONCRETE_STAIRS.get())
            .add(ModBlocks.MAGENTA_CONCRETE_STAIRS.get())
            .add(ModBlocks.ORANGE_CONCRETE_STAIRS.get())
            .add(ModBlocks.PINK_CONCRETE_STAIRS.get())
            .add(ModBlocks.PURPLE_CONCRETE_STAIRS.get())
            .add(ModBlocks.RED_CONCRETE_STAIRS.get())
            .add(ModBlocks.YELLOW_CONCRETE_STAIRS.get())
            .add(ModBlocks.WHITE_CONCRETE_STAIRS.get());

        this.tag(ModBlockTags.CONCRETE_SLABS, ModItemTags.CONCRETE_SLABS)
            .add(ModBlocks.BLACK_CONCRETE_SLAB.get())
            .add(ModBlocks.BLUE_CONCRETE_SLAB.get())
            .add(ModBlocks.BROWN_CONCRETE_SLAB.get())
            .add(ModBlocks.CYAN_CONCRETE_SLAB.get())
            .add(ModBlocks.GRAY_CONCRETE_SLAB.get())
            .add(ModBlocks.GREEN_CONCRETE_SLAB.get())
            .add(ModBlocks.LIGHT_BLUE_CONCRETE_SLAB.get())
            .add(ModBlocks.LIGHT_GRAY_CONCRETE_SLAB.get())
            .add(ModBlocks.LIME_CONCRETE_SLAB.get())
            .add(ModBlocks.MAGENTA_CONCRETE_SLAB.get())
            .add(ModBlocks.ORANGE_CONCRETE_SLAB.get())
            .add(ModBlocks.PINK_CONCRETE_SLAB.get())
            .add(ModBlocks.PURPLE_CONCRETE_SLAB.get())
            .add(ModBlocks.RED_CONCRETE_SLAB.get())
            .add(ModBlocks.YELLOW_CONCRETE_SLAB.get())
            .add(ModBlocks.WHITE_CONCRETE_SLAB.get());
    }

    private void handleConventionalTags() {
        this.tag(ConventionalBlockTags.STRIPPED_LOGS, ConventionalItemTags.STRIPPED_LOGS)
            .add(ModBlocks.STRIPPED_PALE_OAK_LOG.get())
            .add(ModBlocks.STRIPPED_POPLAR_LOG.get());

        this.tag(ConventionalBlockTags.STRIPPED_WOODS, ConventionalItemTags.STRIPPED_WOOD)
            .add(ModBlocks.STRIPPED_PALE_OAK_WOOD.get())
            .add(ModBlocks.STRIPPED_POPLAR_WOOD.get());

        this.tag(ConventionalBlockTags.FENCE_GATES_WOODEN, ConventionalItemTags.FENCE_GATES_WOODEN)
            .add(ModBlocks.PALE_OAK_FENCE_GATE.get())
            .add(ModBlocks.POPLAR_FENCE_GATE.get());

        this.tag(ConventionalBlockTags.CHESTS, ConventionalItemTags.CHESTS)
            .addTag(ModBlockTags.COPPER_CHESTS);

        this.tag(ConventionalBlockTags.STORAGE_BLOCKS_RESIN, ConventionalItemTags.STORAGE_BLOCKS_RESIN)
            .add(ModBlocks.RESIN_BLOCK.get());

        this.tag(ConventionalBlockTags.DYED_BLACK, ConventionalItemTags.DYED_BLACK)
            .add(ModBlocks.BLACK_WOOL_STAIRS.get(), ModBlocks.BLACK_WOOL_SLAB.get(),
                ModBlocks.BLACK_CONCRETE_STAIRS.get(), ModBlocks.BLACK_CONCRETE_SLAB.get());

        this.tag(ConventionalBlockTags.DYED_BLUE, ConventionalItemTags.DYED_BLUE)
            .add(ModBlocks.BLUE_WOOL_STAIRS.get(), ModBlocks.BLUE_WOOL_SLAB.get(),
                ModBlocks.BLUE_CONCRETE_STAIRS.get(), ModBlocks.BLUE_CONCRETE_SLAB.get());

        this.tag(ConventionalBlockTags.DYED_BROWN, ConventionalItemTags.DYED_BROWN)
            .add(ModBlocks.BROWN_WOOL_STAIRS.get(), ModBlocks.BROWN_WOOL_SLAB.get(),
                ModBlocks.BROWN_CONCRETE_STAIRS.get(), ModBlocks.BROWN_CONCRETE_SLAB.get());

        this.tag(ConventionalBlockTags.DYED_CYAN, ConventionalItemTags.DYED_CYAN)
            .add(ModBlocks.CYAN_WOOL_STAIRS.get(), ModBlocks.CYAN_WOOL_SLAB.get(),
                ModBlocks.CYAN_CONCRETE_STAIRS.get(), ModBlocks.CYAN_CONCRETE_SLAB.get());

        this.tag(ConventionalBlockTags.DYED_GRAY, ConventionalItemTags.DYED_GRAY)
            .add(ModBlocks.GRAY_WOOL_STAIRS.get(), ModBlocks.GRAY_WOOL_SLAB.get(),
                ModBlocks.GRAY_CONCRETE_STAIRS.get(), ModBlocks.GRAY_CONCRETE_SLAB.get());

        this.tag(ConventionalBlockTags.DYED_GREEN, ConventionalItemTags.DYED_GREEN)
            .add(ModBlocks.GREEN_WOOL_STAIRS.get(), ModBlocks.GREEN_WOOL_SLAB.get(),
                ModBlocks.GREEN_CONCRETE_STAIRS.get(), ModBlocks.GREEN_CONCRETE_SLAB.get());

        this.tag(ConventionalBlockTags.DYED_LIGHT_BLUE, ConventionalItemTags.DYED_LIGHT_BLUE)
            .add(ModBlocks.LIGHT_BLUE_WOOL_STAIRS.get(), ModBlocks.LIGHT_BLUE_WOOL_SLAB.get(),
                ModBlocks.LIGHT_BLUE_CONCRETE_STAIRS.get(), ModBlocks.LIGHT_BLUE_CONCRETE_SLAB.get());

        this.tag(ConventionalBlockTags.DYED_LIGHT_GRAY, ConventionalItemTags.DYED_LIGHT_GRAY)
            .add(ModBlocks.LIGHT_GRAY_WOOL_STAIRS.get(), ModBlocks.LIGHT_GRAY_WOOL_SLAB.get(),
                ModBlocks.LIGHT_GRAY_CONCRETE_STAIRS.get(), ModBlocks.LIGHT_GRAY_CONCRETE_SLAB.get());

        this.tag(ConventionalBlockTags.DYED_LIME, ConventionalItemTags.DYED_LIME)
            .add(ModBlocks.LIME_WOOL_STAIRS.get(), ModBlocks.LIME_WOOL_SLAB.get(),
                ModBlocks.LIME_CONCRETE_STAIRS.get(), ModBlocks.LIME_CONCRETE_SLAB.get());

        this.tag(ConventionalBlockTags.DYED_MAGENTA, ConventionalItemTags.DYED_MAGENTA)
            .add(ModBlocks.MAGENTA_WOOL_STAIRS.get(), ModBlocks.MAGENTA_WOOL_SLAB.get(),
                ModBlocks.MAGENTA_CONCRETE_STAIRS.get(), ModBlocks.MAGENTA_CONCRETE_SLAB.get());

        this.tag(ConventionalBlockTags.DYED_ORANGE, ConventionalItemTags.DYED_ORANGE)
            .add(ModBlocks.ORANGE_WOOL_STAIRS.get(), ModBlocks.ORANGE_WOOL_SLAB.get(),
                ModBlocks.ORANGE_CONCRETE_STAIRS.get(), ModBlocks.ORANGE_CONCRETE_SLAB.get());

        this.tag(ConventionalBlockTags.DYED_PINK, ConventionalItemTags.DYED_PINK)
            .add(ModBlocks.PINK_WOOL_STAIRS.get(), ModBlocks.PINK_WOOL_SLAB.get(),
                ModBlocks.PINK_CONCRETE_STAIRS.get(), ModBlocks.PINK_CONCRETE_SLAB.get());

        this.tag(ConventionalBlockTags.DYED_PURPLE, ConventionalItemTags.DYED_PURPLE)
            .add(ModBlocks.PURPLE_WOOL_STAIRS.get(), ModBlocks.PURPLE_WOOL_SLAB.get(),
                ModBlocks.PURPLE_CONCRETE_STAIRS.get(), ModBlocks.PURPLE_CONCRETE_SLAB.get());

        this.tag(ConventionalBlockTags.DYED_RED, ConventionalItemTags.DYED_RED)
            .add(ModBlocks.RED_WOOL_STAIRS.get(), ModBlocks.RED_WOOL_SLAB.get(),
                ModBlocks.RED_CONCRETE_STAIRS.get(), ModBlocks.RED_CONCRETE_SLAB.get());

        this.tag(ConventionalBlockTags.DYED_WHITE, ConventionalItemTags.DYED_WHITE)
            .add(ModBlocks.WHITE_WOOL_STAIRS.get(), ModBlocks.WHITE_WOOL_SLAB.get(),
                ModBlocks.WHITE_CONCRETE_STAIRS.get(), ModBlocks.WHITE_CONCRETE_SLAB.get());

        this.tag(ConventionalBlockTags.DYED_YELLOW, ConventionalItemTags.DYED_YELLOW)
            .add(ModBlocks.YELLOW_WOOL_STAIRS.get(), ModBlocks.YELLOW_WOOL_SLAB.get(),
                ModBlocks.YELLOW_CONCRETE_STAIRS.get(), ModBlocks.YELLOW_CONCRETE_SLAB.get());
    }

    protected abstract TagHolder tag(class_6862<class_2248> block, class_6862<class_1792> item);

    protected static class TagHolder {
        private final FabricTagProvider<class_1792>.FabricTagBuilder item;
        private final FabricTagProvider<class_2248>.FabricTagBuilder block;

        public TagHolder(FabricTagProvider<class_1792>.FabricTagBuilder item, FabricTagProvider<class_2248>.FabricTagBuilder block) {
            this.item = item;
            this.block = block;
        }

        public TagHolder add(class_2248 block) {
            if (this.item != null) {
                this.item.add(block.method_8389());
            } else {
                this.block.add(block);
            }

            return this;
        }

        public TagHolder add(class_2248... toAdd) {
            if (this.item != null) {
                for (class_2248 block : toAdd) {
                    this.item.add(block.method_8389());
                }
            } else {
                this.block.add(toAdd);
            }

            return this;
        }
        
        public TagHolder addAll(Collection<class_2248> elements) {
            elements.forEach(this::add);
            return this;
        }

        private static class_6862<class_1792> blockTagToItemTag(class_6862<class_2248> tagKey) {
            return class_6862.method_40092(class_7924.field_41197, tagKey.comp_327());
        }

        public TagHolder addOptional(class_2960 location) {
            if (this.item != null) {
                this.item.method_35922(location);
            } else {
                this.block.method_35922(location);
            }

            return this;
        }

        public TagHolder addTag(class_6862<class_2248> tag) {
            if (this.item != null) {
                this.item.method_26792(blockTagToItemTag(tag));
            } else {
                this.block.method_26792(tag);
            }

            return this;
        }

        public TagHolder addOptionalTag(class_6862<class_2248> tag) {
            if (this.item != null) {
                this.item.addOptionalTag(blockTagToItemTag(tag));
            } else {
                this.block.addOptionalTag(tag);
            }

            return this;
        }
    }
}