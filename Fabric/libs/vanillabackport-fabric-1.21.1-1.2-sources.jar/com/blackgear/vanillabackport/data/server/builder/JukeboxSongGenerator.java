package com.blackgear.vanillabackport.data.server.builder;

import com.blackgear.vanillabackport.common.registries.items.ModJukeboxSongs;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricDynamicRegistryProvider;
import net.minecraft.class_5321;
import net.minecraft.class_7225;
import net.minecraft.class_7924;
import net.minecraft.class_9793;
import java.util.concurrent.CompletableFuture;

public class JukeboxSongGenerator extends FabricDynamicRegistryProvider {
    public JukeboxSongGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected void configure(class_7225.class_7874 provider, Entries entries) {
        this.add(provider, entries, ModJukeboxSongs.TEARS);
        this.add(provider, entries, ModJukeboxSongs.LAVA_CHICKEN);
        this.add(provider, entries, ModJukeboxSongs.BOUNCE);
    }

    private void add(class_7225.class_7874 provider, Entries entries, class_5321<class_9793> key) {
        final class_7225.class_7226<class_9793> registry = provider.method_46762(class_7924.field_52176);
        entries.add(key, registry.method_46747(key).comp_349());
    }

    @Override
    public String method_10321() {
        return "jukebox_songs";
    }
}