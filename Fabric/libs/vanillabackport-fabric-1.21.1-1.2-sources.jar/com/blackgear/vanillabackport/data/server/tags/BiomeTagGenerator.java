package com.blackgear.vanillabackport.data.server.tags;

import com.blackgear.vanillabackport.common.registries.worldgen.ModBiomes;
import com.blackgear.vanillabackport.core.data.tags.ModBiomeTags;
import com.blackgear.vanillabackport.core.data.tags.loader.FabricBiomeTags;
import com.blackgear.vanillabackport.core.data.tags.loader.ForgeBiomeTags;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_1959;
import net.minecraft.class_1972;
import net.minecraft.class_6908;
import net.minecraft.class_7225;
import net.minecraft.class_7924;
import java.util.concurrent.CompletableFuture;

public class BiomeTagGenerator extends FabricTagProvider<class_1959> {
    public BiomeTagGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> lookupProvider) {
        super(output, class_7924.field_41236, lookupProvider);
    }

    @Override
    protected void method_10514(class_7225.class_7874 provider) {
        this.addEntityPlacementTags(provider);
        this.addFeaturePlacementTags(provider);
        this.addStructureTags(provider);
        this.addBiomeConventionalTags(provider);

        this.getOrCreateTagBuilder(class_6908.field_36517)
            .method_46835(ModBiomes.PALE_GARDEN)
            .method_46835(ModBiomes.DAPPLED_FOREST);

        this.getOrCreateTagBuilder(class_6908.field_37393)
            .method_46835(ModBiomes.PALE_GARDEN)
            .method_46835(ModBiomes.SULFUR_CAVES)
            .method_46835(ModBiomes.DAPPLED_FOREST);

        this.getOrCreateTagBuilder(class_6908.field_36501)
            .method_46835(ModBiomes.PALE_GARDEN);

        this.getOrCreateTagBuilder(class_6908.field_37395)
            .method_46835(ModBiomes.PALE_GARDEN)
            .method_46835(ModBiomes.SULFUR_CAVES);
        
        this.getOrCreateTagBuilder(ModBiomeTags.SPAWNS_COLD_VARIANT_FARM_ANIMALS)
            .method_46835(class_1972.field_35117)
            .method_46835(class_1972.field_9453)
            .method_46835(class_1972.field_35115)
            .method_46835(class_1972.field_34474)
            .method_46835(class_1972.field_34472)
            .method_46835(class_1972.field_9435)
            .method_46835(class_1972.field_9418)
            .method_46835(class_1972.field_34471)
            .method_46835(class_1972.field_37543)
            .method_46835(class_1972.field_9463)
            .method_46835(class_1972.field_9454)
            .method_46835(class_1972.field_9478)
            .method_46835(class_1972.field_9467)
            .method_46835(class_1972.field_9470)
            .method_46835(class_1972.field_35119)
            .method_46835(class_1972.field_35113)
            .method_46835(class_1972.field_9420)
            .method_46835(class_1972.field_35120)
            .method_46835(class_1972.field_35111)
            .method_46835(class_1972.field_34475)
            .method_46835(ModBiomes.DAPPLED_FOREST)
            .forceAddTag(class_6908.field_37394)
            .addOptionalTag(ForgeBiomeTags.IS_COLD)
            .addOptionalTag(ForgeBiomeTags.IS_SNOWY)
            .addOptionalTag(FabricBiomeTags.CLIMATE_COLD)
            .addOptionalTag(FabricBiomeTags.SNOWY)
            .addOptionalTag(FabricBiomeTags.ICY);

        this.getOrCreateTagBuilder(ModBiomeTags.SPAWNS_WARM_VARIANT_FARM_ANIMALS)
            .method_46835(class_1972.field_9424)
            .method_46835(class_1972.field_9408)
            .method_46835(class_1972.field_38748)
            .method_46835(class_1972.field_9439)
            .method_46835(class_1972.field_9441)
            .forceAddTag(class_6908.field_36518)
            .forceAddTag(class_6908.field_37392)
            .forceAddTag(class_6908.field_36516)
            .forceAddTag(class_6908.field_36513)
            .addOptionalTag(ForgeBiomeTags.IS_HOT)
            .addOptionalTag(FabricBiomeTags.CLIMATE_HOT);
    }

    protected void addEntityPlacementTags(class_7225.class_7874 provider) {
        this.getOrCreateTagBuilder(ModBiomeTags.SPAWNS_CAMELS)
            .addOptionalTag(FabricBiomeTags.DESERT)
            .addOptionalTag(ForgeBiomeTags.IS_DESERT);
        
        this.getOrCreateTagBuilder(ModBiomeTags.SPAWNS_ZOMBIE_HORSES)
            .method_46835(class_1972.field_9451)
            .method_46835(class_1972.field_35117)
            .forceAddTag(class_6908.field_37392);
        
        this.getOrCreateTagBuilder(ModBiomeTags.SPAWNS_NAUTILUS)
            .method_46835(class_1972.field_9467)
            .method_46835(class_1972.field_9470)
            .method_46835(class_1972.field_9435)
            .method_46835(class_1972.field_9418);
        
        this.getOrCreateTagBuilder(ModBiomeTags.SPAWNS_NAUTILUS_FREQUENTLY)
            .method_46835(class_1972.field_9423)
            .method_46835(class_1972.field_9446)
            .method_46835(class_1972.field_9441)
            .method_46835(class_1972.field_9439)
            .method_46835(class_1972.field_9408);
        
        this.getOrCreateTagBuilder(ModBiomeTags.SPAWNS_CORAL_VARIANT_ZOMBIE_NAUTILUS)
            .method_46835(class_1972.field_9408);
    }

    protected void addFeaturePlacementTags(class_7225.class_7874 provider) {
        this.getOrCreateTagBuilder(ModBiomeTags.SPAWNS_BUSHES)
            .forceAddTag(class_6908.field_36514)
            .forceAddTag(class_6908.field_36511)
            .method_46835(class_1972.field_9409)
            .method_46835(class_1972.field_9412)
            .method_46835(class_1972.field_35112)
            .addOptionalTag(ForgeBiomeTags.IS_PLAINS)
            .addOptionalTag(FabricBiomeTags.PLAINS);

        this.getOrCreateTagBuilder(ModBiomeTags.SPAWNS_FIREFLY_BUSHES)
            .forceAddTag(class_6908.field_36510)
            .forceAddTag(class_6908.field_36511)
            .forceAddTag(class_6908.field_36515)
            .forceAddTag(class_6908.field_36517)
            .forceAddTag(class_6908.field_36509)
            .forceAddTag(class_6908.field_37392)
            .forceAddTag(class_6908.field_36514)
            .forceAddTag(class_6908.field_36516)
            .forceAddTag(class_6908.field_36513)
            .addOptionalTag(ForgeBiomeTags.IS_PLAINS)
            .addOptionalTag(FabricBiomeTags.PLAINS)
            .addOptionalTag(ForgeBiomeTags.IS_MUSHROOM)
            .addOptionalTag(FabricBiomeTags.MUSHROOM)
            .method_46835(class_1972.field_38748);

        this.getOrCreateTagBuilder(ModBiomeTags.SPAWNS_FIREFLY_BUSHES_SWAMP)
            .addOptionalTag(ForgeBiomeTags.IS_SWAMP)
            .addOptionalTag(FabricBiomeTags.SWAMP);

        this.getOrCreateTagBuilder(ModBiomeTags.SPAWNS_WILDFLOWERS)
            .method_46835(class_1972.field_9412)
            .method_46835(class_1972.field_35112)
            .addOptionalTag(FabricBiomeTags.BIRCH_FOREST);

        this.getOrCreateTagBuilder(ModBiomeTags.SPAWNS_NOISE_BASED_WILDFLOWERS)
            .method_46835(class_1972.field_34470);

        this.getOrCreateTagBuilder(ModBiomeTags.SPAWNS_DRY_GRASS)
            .addOptionalTag(FabricBiomeTags.DESERT)
            .addOptionalTag(ForgeBiomeTags.IS_DESERT);

        this.getOrCreateTagBuilder(ModBiomeTags.SPAWNS_DRY_GRASS_RARELY)
            .forceAddTag(class_6908.field_36513);

        this.getOrCreateTagBuilder(ModBiomeTags.SPAWNS_FALLEN_OAK_TREES)
            .method_46835(class_1972.field_9475)
            .forceAddTag(class_6908.field_36513)
            .forceAddTag(class_6908.field_37392)
            .forceAddTag(class_6908.field_36514)
            .method_46835(class_1972.field_9409)
            .method_46835(class_1972.field_9414)
            .addOptionalTag(FabricBiomeTags.PLAINS)
            .addOptionalTag(ForgeBiomeTags.IS_PLAINS);

        this.getOrCreateTagBuilder(ModBiomeTags.SPAWNS_FALLEN_BIRCH_TREES_RARELY)
            .forceAddTag(class_6908.field_36517);

        this.getOrCreateTagBuilder(ModBiomeTags.SPAWNS_FALLEN_BIRCH_TREES)
            .method_46835(class_1972.field_9412)
            .method_46835(class_1972.field_35112)
            .addOptionalTag(FabricBiomeTags.BIRCH_FOREST);

        this.getOrCreateTagBuilder(ModBiomeTags.SPAWNS_FALLEN_SUPER_BIRCH_TREES)
            .method_46835(class_1972.field_35112);

        this.getOrCreateTagBuilder(ModBiomeTags.SPAWNS_FALLEN_JUNGLE_TREES)
            .forceAddTag(class_6908.field_36516);

        this.getOrCreateTagBuilder(ModBiomeTags.SPAWNS_FALLEN_SPRUCE_TREES)
            .forceAddTag(class_6908.field_36515);

        this.getOrCreateTagBuilder(ModBiomeTags.SPAWNS_FALLEN_SPRUCE_TREES_RARELY)
            .forceAddTag(class_6908.field_36514);

        this.getOrCreateTagBuilder(ModBiomeTags.SPAWNS_LEAF_LITTER_PATCHES)
            .method_46835(class_1972.field_9475);

        this.getOrCreateTagBuilder(ModBiomeTags.SPAWNS_LEAF_LITTER)
            .method_40565(
                class_1972.field_9409,
                class_1972.field_9475,
                class_1972.field_35110
            )
            .method_46835(ModBiomes.DAPPLED_FOREST);

        this.getOrCreateTagBuilder(ModBiomeTags.HAS_DARK_LEAF_LITTER)
            .method_40565(
                class_1972.field_9475,
                class_1972.field_9471,
                class_1972.field_38748
            );

        this.getOrCreateTagBuilder(ModBiomeTags.HAS_PALE_LEAF_LITTER)
            .method_46835(ModBiomes.PALE_GARDEN);

        this.getOrCreateTagBuilder(ModBiomeTags.HAS_RED_LEAF_LITTER)
            .method_46835(ModBiomes.DAPPLED_FOREST);
    }

    protected void addStructureTags(class_7225.class_7874 provider) {
        this.getOrCreateTagBuilder(class_6908.field_47213)
            .method_46835(ModBiomes.PALE_GARDEN)
            .method_46835(ModBiomes.SULFUR_CAVES);

        this.getOrCreateTagBuilder(class_6908.field_36523)
            .method_46835(ModBiomes.SULFUR_CAVES);

        this.getOrCreateTagBuilder(class_6908.field_36492)
            .method_46835(ModBiomes.SULFUR_CAVES);
        
        this.getOrCreateTagBuilder(ModBiomeTags.HAS_ABANDONED_CAMP_BAMBOO_JUNGLE).method_46835(class_1972.field_9440);
        this.getOrCreateTagBuilder(ModBiomeTags.HAS_ABANDONED_CAMP_BIRCH_FOREST).method_46835(class_1972.field_9412);
        this.getOrCreateTagBuilder(ModBiomeTags.HAS_ABANDONED_CAMP_CHERRY_GROVE).method_46835(class_1972.field_42720);
        this.getOrCreateTagBuilder(ModBiomeTags.HAS_ABANDONED_CAMP_DAPPLED_FOREST).method_46835(ModBiomes.DAPPLED_FOREST);
        this.getOrCreateTagBuilder(ModBiomeTags.HAS_ABANDONED_CAMP_FLOWER_FOREST).method_46835(class_1972.field_9414);
        this.getOrCreateTagBuilder(ModBiomeTags.HAS_ABANDONED_CAMP_FOREST).method_46835(class_1972.field_9409);
        this.getOrCreateTagBuilder(ModBiomeTags.HAS_ABANDONED_CAMP_MEADOW).method_46835(class_1972.field_34470);
        this.getOrCreateTagBuilder(ModBiomeTags.HAS_ABANDONED_CAMP_OLD_GROWTH_BIRCH_FOREST).method_46835(class_1972.field_35112);
        this.getOrCreateTagBuilder(ModBiomeTags.HAS_ABANDONED_CAMP_OLD_GROWTH_PINE_TAIGA).method_46835(class_1972.field_35119);
        this.getOrCreateTagBuilder(ModBiomeTags.HAS_ABANDONED_CAMP_OLD_GROWTH_SPRUCE_TAIGA).method_46835(class_1972.field_35113);
        this.getOrCreateTagBuilder(ModBiomeTags.HAS_ABANDONED_CAMP_PALE_GARDEN).method_46835(ModBiomes.PALE_GARDEN);
        this.getOrCreateTagBuilder(ModBiomeTags.HAS_ABANDONED_CAMP_SAVANNA).method_46835(class_1972.field_9449);
        this.getOrCreateTagBuilder(ModBiomeTags.HAS_ABANDONED_CAMP_SNOWY_TAIGA).method_46835(class_1972.field_9454);
        this.getOrCreateTagBuilder(ModBiomeTags.HAS_ABANDONED_CAMP_SPARSE_JUNGLE).method_46835(class_1972.field_35118);
        this.getOrCreateTagBuilder(ModBiomeTags.HAS_ABANDONED_CAMP_SWAMP).method_46835(class_1972.field_9471);
        this.getOrCreateTagBuilder(ModBiomeTags.HAS_ABANDONED_CAMP_TAIGA).method_46835(class_1972.field_9420);
        this.getOrCreateTagBuilder(ModBiomeTags.HAS_ABANDONED_CAMP_WINDSWEPT_FOREST).method_46835(class_1972.field_35120);
        this.getOrCreateTagBuilder(ModBiomeTags.HAS_ABANDONED_CAMP_WOODED_BADLANDS).method_46835(class_1972.field_35110);
    }

    protected void addBiomeConventionalTags(class_7225.class_7874 provider) {
        this.getOrCreateTagBuilder(ForgeBiomeTags.IS_SPOOKY)
            .method_46835(ModBiomes.PALE_GARDEN);

        this.getOrCreateTagBuilder(ForgeBiomeTags.IS_DARK_FOREST)
            .method_46835(ModBiomes.PALE_GARDEN);

        this.getOrCreateTagBuilder(ForgeBiomeTags.IS_RARE)
            .method_46835(ModBiomes.PALE_GARDEN);

        this.getOrCreateTagBuilder(ForgeBiomeTags.IS_TREE_DECIDUOUS)
            .method_46835(ModBiomes.PALE_GARDEN);

        this.getOrCreateTagBuilder(ForgeBiomeTags.IS_CAVE)
            .method_46835(ModBiomes.SULFUR_CAVES);

        this.getOrCreateTagBuilder(FabricBiomeTags.CAVES)
            .method_46835(ModBiomes.SULFUR_CAVES);
    }
}