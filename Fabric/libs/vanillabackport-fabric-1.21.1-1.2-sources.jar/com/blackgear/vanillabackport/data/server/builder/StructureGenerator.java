package com.blackgear.vanillabackport.data.server.builder;

import com.blackgear.vanillabackport.common.level.worldgen.structure.AbandonedCampStructurePools;
import com.blackgear.vanillabackport.common.worldgen.structures.WildernessBoundStructureSets;
import com.blackgear.vanillabackport.common.worldgen.structures.WildernessBoundStructures;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricDynamicRegistryProvider;
import net.minecraft.class_3195;
import net.minecraft.class_3785;
import net.minecraft.class_5321;
import net.minecraft.class_7059;
import net.minecraft.class_7225;
import net.minecraft.class_7924;
import java.util.concurrent.CompletableFuture;

public class StructureGenerator extends FabricDynamicRegistryProvider {
    public StructureGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected void configure(class_7225.class_7874 provider, Entries entries) {
        // Wilderness Bound
        this.structure(provider, entries, WildernessBoundStructures.ABANDONED_CAMP_BAMBOO_JUNGLE);
        this.structure(provider, entries, WildernessBoundStructures.ABANDONED_CAMP_BIRCH_FOREST);
        this.structure(provider, entries, WildernessBoundStructures.ABANDONED_CAMP_CHERRY_GROVE);
        this.structure(provider, entries, WildernessBoundStructures.ABANDONED_CAMP_DAPPLED_FOREST);
        this.structure(provider, entries, WildernessBoundStructures.ABANDONED_CAMP_FLOWER_FOREST);
        this.structure(provider, entries, WildernessBoundStructures.ABANDONED_CAMP_FOREST);
        this.structure(provider, entries, WildernessBoundStructures.ABANDONED_CAMP_MEADOW);
        this.structure(provider, entries, WildernessBoundStructures.ABANDONED_CAMP_OLD_GROWTH_PINE_TAIGA);
        this.structure(provider, entries, WildernessBoundStructures.ABANDONED_CAMP_OLD_GROWTH_BIRCH_FOREST);
        this.structure(provider, entries, WildernessBoundStructures.ABANDONED_CAMP_OLD_GROWTH_SPRUCE_TAIGA);
        this.structure(provider, entries, WildernessBoundStructures.ABANDONED_CAMP_PALE_GARDEN);
        this.structure(provider, entries, WildernessBoundStructures.ABANDONED_CAMP_SAVANNA);
        this.structure(provider, entries, WildernessBoundStructures.ABANDONED_CAMP_SNOWY_TAIGA);
        this.structure(provider, entries, WildernessBoundStructures.ABANDONED_CAMP_SPARSE_JUNGLE);
        this.structure(provider, entries, WildernessBoundStructures.ABANDONED_CAMP_SWAMP);
        this.structure(provider, entries, WildernessBoundStructures.ABANDONED_CAMP_TAIGA);
        this.structure(provider, entries, WildernessBoundStructures.ABANDONED_CAMP_WINDSWEPT_FOREST);
        this.structure(provider, entries, WildernessBoundStructures.ABANDONED_CAMP_WOODED_BADLANDS);
        
        this.set(provider, entries, WildernessBoundStructureSets.ABANDONED_CAMP);
        
        this.pool(provider, entries, AbandonedCampStructurePools.SAVANNA.campStructureDirectory());
        this.pool(provider, entries, AbandonedCampStructurePools.FLOWER_FOREST.campStructureDirectory());
        this.pool(provider, entries, AbandonedCampStructurePools.BIRCH_FOREST.campStructureDirectory());
        this.pool(provider, entries, AbandonedCampStructurePools.FOREST.campStructureDirectory());
        this.pool(provider, entries, AbandonedCampStructurePools.SNOWY_TAIGA.campStructureDirectory());
        this.pool(provider, entries, AbandonedCampStructurePools.BAMBOO_JUNGLE.campStructureDirectory());
        this.pool(provider, entries, AbandonedCampStructurePools.SPARSE_JUNGLE.campStructureDirectory());
        this.pool(provider, entries, AbandonedCampStructurePools.CHERRY_GROVE.campStructureDirectory());
        this.pool(provider, entries, AbandonedCampStructurePools.MEADOW.campStructureDirectory());
        this.pool(provider, entries, AbandonedCampStructurePools.OLD_GROWTH_BIRCH_FOREST.campStructureDirectory());
        this.pool(provider, entries, AbandonedCampStructurePools.OLD_GROWTH_SPRUCE_TAIGA.campStructureDirectory());
        this.pool(provider, entries, AbandonedCampStructurePools.OLD_GROWTH_PINE_TAIGA.campStructureDirectory());
        this.pool(provider, entries, AbandonedCampStructurePools.SWAMP.campStructureDirectory());
        this.pool(provider, entries, AbandonedCampStructurePools.TAIGA.campStructureDirectory());
        this.pool(provider, entries, AbandonedCampStructurePools.WINDSWEPT_FOREST.campStructureDirectory());
        this.pool(provider, entries, AbandonedCampStructurePools.DAPPLED_FOREST.campStructureDirectory());
        this.pool(provider, entries, AbandonedCampStructurePools.WOODED_BADLANDS.campStructureDirectory());
        this.pool(provider, entries, AbandonedCampStructurePools.PALE_GARDEN.campStructureDirectory());
        
        this.pool(provider, entries, AbandonedCampStructurePools.SAVANNA.tentStructureDirectory());
        this.pool(provider, entries, AbandonedCampStructurePools.FLOWER_FOREST.tentStructureDirectory());
        this.pool(provider, entries, AbandonedCampStructurePools.BIRCH_FOREST.tentStructureDirectory());
        this.pool(provider, entries, AbandonedCampStructurePools.FOREST.tentStructureDirectory());
        this.pool(provider, entries, AbandonedCampStructurePools.SNOWY_TAIGA.tentStructureDirectory());
        this.pool(provider, entries, AbandonedCampStructurePools.BAMBOO_JUNGLE.tentStructureDirectory());
        this.pool(provider, entries, AbandonedCampStructurePools.SPARSE_JUNGLE.tentStructureDirectory());
        this.pool(provider, entries, AbandonedCampStructurePools.CHERRY_GROVE.tentStructureDirectory());
        this.pool(provider, entries, AbandonedCampStructurePools.MEADOW.tentStructureDirectory());
        this.pool(provider, entries, AbandonedCampStructurePools.OLD_GROWTH_BIRCH_FOREST.tentStructureDirectory());
        this.pool(provider, entries, AbandonedCampStructurePools.OLD_GROWTH_SPRUCE_TAIGA.tentStructureDirectory());
        this.pool(provider, entries, AbandonedCampStructurePools.OLD_GROWTH_PINE_TAIGA.tentStructureDirectory());
        this.pool(provider, entries, AbandonedCampStructurePools.SWAMP.tentStructureDirectory());
        this.pool(provider, entries, AbandonedCampStructurePools.TAIGA.tentStructureDirectory());
        this.pool(provider, entries, AbandonedCampStructurePools.WINDSWEPT_FOREST.tentStructureDirectory());
        this.pool(provider, entries, AbandonedCampStructurePools.DAPPLED_FOREST.tentStructureDirectory());
        this.pool(provider, entries, AbandonedCampStructurePools.WOODED_BADLANDS.tentStructureDirectory());
        this.pool(provider, entries, AbandonedCampStructurePools.PALE_GARDEN.tentStructureDirectory());
    }

    private void structure(class_7225.class_7874 provider, Entries entries, class_5321<class_3195> key) {
        final class_7225.class_7226<class_3195> registry = provider.method_46762(class_7924.field_41246);
        entries.add(key, registry.method_46747(key).comp_349());
    }

    private void set(class_7225.class_7874 provider, Entries entries, class_5321<class_7059> key) {
        final class_7225.class_7226<class_7059> registry = provider.method_46762(class_7924.field_41248);
        entries.add(key, registry.method_46747(key).comp_349());
    }

    private void pool(class_7225.class_7874 provider, Entries entries, class_5321<class_3785> key) {
        final class_7225.class_7226<class_3785> registry = provider.method_46762(class_7924.field_41249);
        entries.add(key, registry.method_46747(key).comp_349());
    }

    @Override
    public String method_10321() {
        return "worldgen/structure";
    }
}