package com.blackgear.vanillabackport.data.server.tags;

import com.blackgear.vanillabackport.common.registries.entities.ModEntityTypes;
import com.blackgear.vanillabackport.core.data.tags.ModEntityTypeTags;
import com.blackgear.vanillabackport.core.data.tags.create.SableEntityTags;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_1299;
import net.minecraft.class_3483;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;

public class EntityTypeTagGenerator extends FabricTagProvider.EntityTypeTagProvider {
    public EntityTypeTagGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected void method_10514(class_7225.class_7874 provider) {
        this.getOrCreateTagBuilder(class_3483.field_46231)
            .add(ModEntityTypes.CAMEL_HUSK.get())
            .add(ModEntityTypes.ZOMBIE_NAUTILUS.get());
        
        this.getOrCreateTagBuilder(class_3483.field_48288)
            .add(ModEntityTypes.NAUTILUS.get())
            .add(ModEntityTypes.ZOMBIE_NAUTILUS.get());
        
        this.getOrCreateTagBuilder(class_3483.field_48283)
            .add(ModEntityTypes.NAUTILUS.get())
            .add(ModEntityTypes.ZOMBIE_NAUTILUS.get())
            .add(ModEntityTypes.SULFUR_CUBE.get());
        
        this.getOrCreateTagBuilder(class_3483.field_42971)
            .add(ModEntityTypes.HAPPY_GHAST.get());
        
        this.getOrCreateTagBuilder(class_3483.field_15507)
            .add(ModEntityTypes.PARCHED.get());

        this.getOrCreateTagBuilder(class_3483.field_43096)
            .add(ModEntityTypes.HAPPY_GHAST.get());

        this.getOrCreateTagBuilder(ModEntityTypeTags.FOLLOWABLE_FRIENDLY_MOBS)
            .add(
                class_1299.field_20346,
                class_1299.field_40116,
                class_1299.field_16281,
                class_1299.field_6132,
                class_1299.field_6085,
                class_1299.field_6067,
                class_1299.field_17943,
                class_1299.field_30052,
                ModEntityTypes.HAPPY_GHAST.get(),
                class_1299.field_6139,
                class_1299.field_6075,
                class_1299.field_6074,
                class_1299.field_6057,
                class_1299.field_6081,
                class_1299.field_6146,
                class_1299.field_6104,
                class_1299.field_6093,
                class_1299.field_6042,
                class_1299.field_6140,
                class_1299.field_6115,
                class_1299.field_42622,
                class_1299.field_23214,
                class_1299.field_6077,
                class_1299.field_6055
            );

        this.getOrCreateTagBuilder(ModEntityTypeTags.MONSTERS_THAT_SPAWN_ON_PEACEFUL)
            .add(
                class_1299.field_22281,
                class_1299.field_21973,
                ModEntityTypes.SULFUR_CUBE.get()
            );

        this.getOrCreateTagBuilder(ModEntityTypeTags.NOT_AFFECTED_BY_GEYSERS)
            .add(
                class_1299.field_6116
            );
        
        this.getOrCreateTagBuilder(ModEntityTypeTags.ACCEPTS_IRON_GOLEM_GIFT)
            .add(ModEntityTypes.COPPER_GOLEM.get());
        
        this.getOrCreateTagBuilder(ModEntityTypeTags.CAN_FLOAT_WHILE_RIDDEN)
            .add(class_1299.field_6139, class_1299.field_6048, class_1299.field_6057, class_1299.field_6067, class_1299.field_40116, ModEntityTypes.CAMEL_HUSK.get());
        
        this.getOrCreateTagBuilder(SableEntityTags.RETAIN_IN_SUB_LEVEL)
            .add(ModEntityTypes.CUSHION.get());
        
        this.getOrCreateTagBuilder(ModEntityTypeTags.NAUTILUS_HOSTILES)
            .add(class_1299.field_6062);
    }
}