package com.blackgear.vanillabackport.data.server.tags;

import com.blackgear.vanillabackport.common.registries.enchantment.ModEnchantments;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_7225;
import net.minecraft.class_9636;
import java.util.concurrent.CompletableFuture;

public class EnchantmentTagGenerator extends FabricTagProvider.EnchantmentTagProvider {
    public EnchantmentTagGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> completableFuture) {
        super(output, completableFuture);
    }
    
    @Override
    protected void method_10514(class_7225.class_7874 registries) {
        this.getOrCreateTagBuilder(class_9636.field_51558)
            .method_46835(ModEnchantments.LUNGE);
        this.getOrCreateTagBuilder(class_9636.field_51545)
            .method_46835(ModEnchantments.LUNGE);
    }
}