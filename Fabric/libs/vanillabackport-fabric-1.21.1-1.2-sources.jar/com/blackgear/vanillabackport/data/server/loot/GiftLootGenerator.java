package com.blackgear.vanillabackport.data.server.loot;

import com.blackgear.vanillabackport.common.level.entities.mob.animal.chicken.ChickenVariants;
import com.blackgear.vanillabackport.common.registries.items.ModItems;
import com.blackgear.vanillabackport.core.data.ModBuiltInLootTables;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.SimpleFabricLootTableProvider;
import net.minecraft.class_173;
import net.minecraft.class_1802;
import net.minecraft.class_2048;
import net.minecraft.class_2105;
import net.minecraft.class_215;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_44;
import net.minecraft.class_47;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_55;
import net.minecraft.class_65;
import net.minecraft.class_7225;
import net.minecraft.class_77;
import java.util.concurrent.CompletableFuture;
import java.util.function.BiConsumer;

public class GiftLootGenerator extends SimpleFabricLootTableProvider {
    public GiftLootGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> lookup) {
        super(output, lookup, class_173.field_16235);
    }

    /**
     * Creates an NBT predicate that matches a chicken with the specified variant.
     * The variant is stored in the "variant" NBT tag as a resource location string.
     */
    private static class_2105 variantNbt(class_2960 variantId) {
        class_2487 tag = new class_2487();
        tag.method_10582("variant", variantId.toString());
        return new class_2105(tag);
    }

    @Override
    public void method_10399(BiConsumer<class_5321<class_52>, class_52.class_53> output) {

        output.accept(
            ModBuiltInLootTables.CHICKEN_LAY,
            class_52.method_324()
                .method_336(
                    class_55.method_347()
                        .method_352(class_44.method_32448(1.0F))
                        .method_351(
                            class_65.method_386(
                                class_77.method_411(class_1802.field_8803)
                                    .method_421(
                                        class_215.method_917(
                                            class_47.class_50.field_935,
                                            class_2048.class_2049.method_8916()
                                                .method_8915(variantNbt(ChickenVariants.TEMPERATE.location()))
                                        )
                                    ),
                                class_77.method_411(ModItems.BROWN_EGG.get())
                                    .method_421(
                                        class_215.method_917(
                                            class_47.class_50.field_935,
                                            class_2048.class_2049.method_8916()
                                                .method_8915(variantNbt(ChickenVariants.WARM.location()))
                                        )
                                    ),
                                class_77.method_411(ModItems.BLUE_EGG.get())
                                    .method_421(
                                        class_215.method_917(
                                            class_47.class_50.field_935,
                                            class_2048.class_2049.method_8916()
                                                .method_8915(variantNbt(ChickenVariants.COLD.location()))
                                        )
                                    )
                            )
                        )
                )
        );
    }
}