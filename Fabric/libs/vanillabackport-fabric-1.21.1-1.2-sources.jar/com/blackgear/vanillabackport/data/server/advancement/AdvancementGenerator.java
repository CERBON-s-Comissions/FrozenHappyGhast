package com.blackgear.vanillabackport.data.server.advancement;

import com.blackgear.vanillabackport.common.level.blocks.CreakingHeartBlock;
import com.blackgear.vanillabackport.common.level.blocks.CreakingHeartState;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlockStateProperties;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import com.blackgear.vanillabackport.common.registries.entities.ModEntityTypes;
import com.blackgear.vanillabackport.common.registries.items.ModItems;
import com.blackgear.vanillabackport.common.triggers.SpearMobsTrigger;
import com.blackgear.vanillabackport.core.data.tags.ModBlockTags;
import com.blackgear.vanillabackport.core.data.tags.ModItemTags;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricAdvancementProvider;
import net.minecraft.advancements.*;
import net.minecraft.advancements.critereon.*;
import net.minecraft.class_161;
import net.minecraft.class_174;
import net.minecraft.class_175;
import net.minecraft.class_1802;
import net.minecraft.class_189;
import net.minecraft.class_2040;
import net.minecraft.class_2048;
import net.minecraft.class_205;
import net.minecraft.class_2073;
import net.minecraft.class_2090;
import net.minecraft.class_212;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_2561;
import net.minecraft.class_2741;
import net.minecraft.class_2769;
import net.minecraft.class_2960;
import net.minecraft.class_3542;
import net.minecraft.class_4550;
import net.minecraft.class_4559;
import net.minecraft.class_4711;
import net.minecraft.class_5258;
import net.minecraft.class_5279;
import net.minecraft.class_5341;
import net.minecraft.class_5409;
import net.minecraft.class_6862;
import net.minecraft.class_7225;
import net.minecraft.class_8548;
import net.minecraft.class_8551;
import net.minecraft.class_8779;
import net.minecraft.class_8782;
import net.minecraft.world.level.storage.loot.predicates.*;

import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import java.util.stream.Stream;

public class AdvancementGenerator extends FabricAdvancementProvider {
    public AdvancementGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registryLookup) {
        super(output, registryLookup);
    }

    @Override
    public void generateAdvancement(class_7225.class_7874 provider, Consumer<class_8779> consumer) {
        // Adventure advancements
        class_8779 adventure = class_161.class_162.method_707().method_695(class_2960.method_60656("adventure/root"));

        class_161.class_162.method_707()
            .method_701(adventure)
            .method_697(
                ModBlocks.CREAKING_HEART.get(),
                class_2561.method_43471("advancements.adventure.heart_transplanter.title"),
                class_2561.method_43471("advancements.adventure.heart_transplanter.description"),
                null,
                class_189.field_1254,
                true,
                true,
                false
            )
            .method_704(class_8782.class_8797.field_1257)
            .method_705(
                "place_creaking_heart_dormant",
                placedBlockWithProperties(ModBlocks.CREAKING_HEART.get(), ModBlockStateProperties.CREAKING_HEART_STATE, CreakingHeartState.DORMANT)
            )
            .method_705(
                "place_creaking_heart_awake",
                placedBlockWithProperties(ModBlocks.CREAKING_HEART.get(), ModBlockStateProperties.CREAKING_HEART_STATE, CreakingHeartState.AWAKE)
            )
            .method_705(
                "place_pale_oak_log", placedBlockActivatesCreakingHeart(ModBlockTags.PALE_OAK_LOGS)
            )
            .method_694(consumer, "adventure/heart_transplanter");
        
        class_8779 killAMob = class_161.class_162.method_707().method_695(class_2960.method_60656("adventure/kill_a_mob"));
        class_161.class_162.method_707()
            .method_701(killAMob)
            .method_697(
                ModItems.IRON_SPEAR.get(),
                class_2561.method_43471("advancements.adventure.spear_many_mobs.title"),
                class_2561.method_43471("advancements.adventure.spear_many_mobs.description"),
                null,
                class_189.field_1249,
                true,
                true,
                false
            )
            .method_705("spear_many_mobs", SpearMobsTrigger.TriggerInstance.spearMobs(5))
            .method_694(consumer, "adventure/spear_many_mobs");

        // Husbandry advancements
        class_8779 husbandry = class_161.class_162.method_707().method_695(class_2960.method_60656("husbandry/root"));

        class_161.class_162.method_707()
            .method_701(husbandry)
            .method_697(
                ModBlocks.DRIED_GHAST.get(),
                class_2561.method_43471("advancements.husbandry.place_dried_ghast_in_water.title"),
                class_2561.method_43471("advancements.husbandry.place_dried_ghast_in_water.description"),
                null,
                class_189.field_1254,
                true,
                true,
                false
            )
            .method_705(
                "place_dried_ghast_on_water",
                placedBlockWithProperties(ModBlocks.DRIED_GHAST.get(), class_2741.field_12508, String.valueOf(true))
            )
            .method_694(consumer, "husbandry/place_dried_ghast_in_water");


        class_161.class_162.method_707()
            .method_701(husbandry)
            .method_697(
                class_1802.field_8626,
                class_2561.method_43471("advancements.husbandry.uh_oh.title"),
                class_2561.method_43471("advancements.husbandry.uh_oh.description"),
                null,
                class_189.field_1254,
                true,
                true,
                false
            )
            .method_704(class_8782.class_8797.field_1257)
            .method_705(
                "pick_up_dropped_tnt",
                class_5279.class_5280.method_27978(
                    class_5258.method_27973(),
                    Optional.of(class_2073.class_2074.method_8973().method_8975(ModItemTags.SULFUR_CUBE_ARCHETYPE_EXPLOSIVE).method_8976()),
                    Optional.of(class_2048.method_51704(
                        class_2048.class_2049.method_8916()
                            .method_8921(ModEntityTypes.SULFUR_CUBE.get())
                            .method_8919(class_2040.class_2041.method_8897().method_29935(false))
                            .method_8920()
                    ))
                )
            )
            .method_705(
                "give_tnt_directly",
                class_5409.class_5410.method_30099(
                    Optional.empty(),
                    class_2073.class_2074.method_8973().method_8975(ModItemTags.SULFUR_CUBE_ARCHETYPE_EXPLOSIVE),
                    Optional.of(class_2048.method_51704(
                        class_2048.class_2049.method_8916()
                            .method_8921(ModEntityTypes.SULFUR_CUBE.get())
                            .method_8919(class_2040.class_2041.method_8897().method_29935(false))
                            .method_8920()
                    ))
                )
            ).method_694(consumer, "husbandry/uh_oh");
    }

    private class_175<class_4711.class_4712> placedBlockActivatesCreakingHeart(class_6862<class_2248> block) {
        class_5341.class_210[] conditions = Stream.of(class_2350.values()).map(direction -> {
            class_4559.class_4560 creakingHeartProperties = class_4559.class_4560.method_22523().method_22525(CreakingHeartBlock.AXIS, direction.method_10166());
            class_4550.class_4710 placedPaleOakLogBlock = class_4550.class_4710.method_23880().method_29233(block).method_27963(creakingHeartProperties);
            class_2382 blockOffset = direction.method_10163();
            class_5341.class_210 placedPaleOakLogTest = class_205.method_884(class_2090.class_2091.method_22484().method_27989(placedPaleOakLogBlock));
            class_5341.class_210 creakingHeartBlockTest = class_205.method_30151(class_2090.class_2091.method_22484().method_27989(class_4550.class_4710.method_23880().method_27962(ModBlocks.CREAKING_HEART.get()).method_27963(creakingHeartProperties)), new class_2338(blockOffset));
            class_5341.class_210 existingPaleOakLogTest = class_205.method_30151(class_2090.class_2091.method_22484().method_27989(placedPaleOakLogBlock), new class_2338(blockOffset.method_35862(2)));
            return class_8548.method_51723(placedPaleOakLogTest, creakingHeartBlockTest, existingPaleOakLogTest);
        }).toArray(class_5341.class_210[]::new);
        return class_4711.class_4712.method_51712(class_8551.method_51727(conditions));
    }

    private static <T extends Comparable<T>> class_175<class_4711.class_4712> placedBlockWithProperties(class_2248 block, class_2769<T> property, String value) {
        class_4559.class_4560 builder = class_4559.class_4560.method_22523().method_22526(property, value);
        class_5258 location = class_5258.method_27973(new class_212.class_213(block).method_22584(builder).build());
        return class_174.field_1191.method_53699(new class_4711.class_4712(Optional.empty(), Optional.of(location)));
    }

    private static <T extends Comparable<T> & class_3542> class_175<class_4711.class_4712> placedBlockWithProperties(class_2248 block, class_2769<T> property, T value) {
        return placedBlockWithProperties(block, property, value.method_15434());
    }
}