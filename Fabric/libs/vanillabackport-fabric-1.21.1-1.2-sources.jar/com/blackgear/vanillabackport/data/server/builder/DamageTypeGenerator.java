package com.blackgear.vanillabackport.data.server.builder;

import com.blackgear.vanillabackport.common.registries.entities.ModDamageTypes;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricDynamicRegistryProvider;
import net.minecraft.class_5321;
import net.minecraft.class_7225;
import net.minecraft.class_7924;
import net.minecraft.class_8110;
import java.util.concurrent.CompletableFuture;

public class DamageTypeGenerator extends FabricDynamicRegistryProvider {
    public DamageTypeGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected void configure(class_7225.class_7874 provider, Entries entries) {
        this.add(provider, entries, ModDamageTypes.SULFUR_CUBE_HOT);
    }

    private void add(class_7225.class_7874 provider, Entries entries, class_5321<class_8110> key) {
        final class_7225.class_7226<class_8110> registry = provider.method_46762(class_7924.field_42534);
        entries.add(key, registry.method_46747(key).comp_349());
    }

    @Override
    public String method_10321() {
        return "damage_types";
    }
}