package com.blackgear.vanillabackport.data.server.tags;

import com.blackgear.vanillabackport.common.registries.entities.ModDamageTypes;
import com.blackgear.vanillabackport.core.data.tags.ModDamageTypeTags;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_2474;
import net.minecraft.class_7225;
import net.minecraft.class_7784;
import net.minecraft.class_7924;
import net.minecraft.class_8103;
import net.minecraft.class_8110;
import net.minecraft.class_8111;

public class DamageTypeTagGenerator extends class_2474<class_8110> {
    public DamageTypeTagGenerator(class_7784 output, CompletableFuture<class_7225.class_7874> lookupProvider) {
        super(output, class_7924.field_42534, lookupProvider);
    }

    @Override
    protected void method_10514(class_7225.class_7874 provider) {
        this.method_10512(class_8103.field_43116)
            .method_46835(ModDamageTypes.SULFUR_CUBE_HOT);
        this.method_10512(class_8103.field_42246)
            .method_46835(ModDamageTypes.SULFUR_CUBE_HOT);
        this.method_10512(ModDamageTypeTags.SULFUR_CUBE_WITH_BLOCK_IMMUNE_TO)
            .method_40565(
                class_8111.field_42321,
                class_8111.field_42344,
                class_8111.field_42352,
                class_8111.field_42345,
                class_8111.field_42357,
                class_8111.field_42356,
                class_8111.field_42358,
                class_8111.field_42354,
                class_8111.field_42339,
                class_8111.field_42360,
                class_8111.field_42319,
                class_8111.field_42323,
                class_8111.field_42320,
                class_8111.field_42331,
                class_8111.field_42332,
                class_8111.field_42355,
                class_8111.field_42359,
                class_8111.field_47737,
                ModDamageTypes.SULFUR_CUBE_HOT,
                class_8111.field_42353,
                class_8111.field_42328,
                class_8111.field_42322
            );
        this.method_10512(ModDamageTypeTags.NO_KNOCKBACK)
            .method_40565(
                class_8111.field_42331,
                class_8111.field_42332,
                class_8111.field_42334,
                class_8111.field_42335,
                class_8111.field_42336,
                class_8111.field_42337,
                class_8111.field_42338,
                class_8111.field_42339,
                ModDamageTypes.SULFUR_CUBE_HOT,
                class_8111.field_42340,
                class_8111.field_42341,
                class_8111.field_42342,
                class_8111.field_42343,
                class_8111.field_42344,
                class_8111.field_42345,
                class_8111.field_42346,
                class_8111.field_42347,
                class_8111.field_42348,
                class_8111.field_42349,
                class_8111.field_42350,
                class_8111.field_42351,
                class_8111.field_42352,
                class_8111.field_42353,
                class_8111.field_42354,
                class_8111.field_42355,
                class_8111.field_44868,
                class_8111.field_44869
            );
    }
}