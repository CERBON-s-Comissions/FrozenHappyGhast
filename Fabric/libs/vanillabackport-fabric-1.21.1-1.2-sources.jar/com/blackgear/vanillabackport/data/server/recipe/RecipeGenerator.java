package com.blackgear.vanillabackport.data.server.recipe;

import com.blackgear.vanillabackport.common.api.modules.bundle_ui.BundleColoring;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import com.blackgear.vanillabackport.common.registries.items.ModItems;
import com.blackgear.vanillabackport.core.data.tags.ModItemTags;
import com.blackgear.vanillabackport.core.data.BlockFamilies;
import com.google.common.collect.ImmutableMap;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_1935;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2447;
import net.minecraft.class_2450;
import net.minecraft.class_2454;
import net.minecraft.class_2456;
import net.minecraft.class_3489;
import net.minecraft.class_5794;
import net.minecraft.class_7225;
import net.minecraft.class_7699;
import net.minecraft.class_7701;
import net.minecraft.class_7800;
import net.minecraft.class_8790;
import net.minecraft.data.recipes.*;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import static net.minecraft.class_2446.*;

public class RecipeGenerator extends VanillaRecipeProvider {
    private static final Map<class_5794.class_5796, FamilyStonecutterRecipeProvider> STONECUTTER_RECIPE_BUILDERS = ImmutableMap.<class_5794.class_5796, FamilyStonecutterRecipeProvider>builder()
        .put(class_5794.class_5796.field_28539, (exporter, result, base) -> method_33715(exporter, class_7800.field_40634, result, base, 2))
        .put(class_5794.class_5796.field_28540, (exporter, result, base) -> method_33715(exporter, class_7800.field_40634, result, base, 1))
        .put(class_5794.class_5796.field_28544, (exporter, result, base) -> method_33715(exporter, class_7800.field_40635, result, base, 1))
        .put(class_5794.class_5796.field_28534, (exporter, result, base) -> method_33715(exporter, class_7800.field_40634, result, base, 1))
        .put(class_5794.class_5796.field_28542, (exporter, result, base) -> method_33715(exporter, class_7800.field_40634, result, base, 1))
        .put(class_5794.class_5796.field_33689, (exporter, result, base) -> method_33715(exporter, class_7800.field_40634, result, base, 1))
        .build();

    public RecipeGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    public void buildRecipes(class_8790 output) {
        BlockFamilies.getAllFamilies()
            .filter(class_5794::method_33478)
            .forEach(family -> method_33535(output, family, class_7699.method_45398(class_7701.field_40177)));
        method_24475(output, ModBlocks.PALE_OAK_PLANKS.get(), ModItemTags.PALE_OAK_LOGS, 4);
        method_24476(output, ModBlocks.PALE_OAK_WOOD.get(), ModBlocks.PALE_OAK_LOG.get());
        method_24476(output, ModBlocks.STRIPPED_PALE_OAK_WOOD.get(), ModBlocks.STRIPPED_PALE_OAK_LOG.get());
        method_24478(output, ModItems.PALE_OAK_BOAT.get(), ModBlocks.PALE_OAK_PLANKS.get());
        method_42754(output, ModItems.PALE_OAK_CHEST_BOAT.get(), ModItems.PALE_OAK_BOAT.get());
        method_46208(output, ModBlocks.PALE_OAK_HANGING_SIGN.getFirst().get(), ModBlocks.STRIPPED_PALE_OAK_LOG.get());
        method_24885(output, ModBlocks.PALE_MOSS_CARPET.get(), ModBlocks.PALE_MOSS_BLOCK.get());

        method_36444(output, class_1802.field_8492, ModBlocks.OPEN_EYEBLOSSOM.get(), "orange_dye");
        method_36444(output, class_1802.field_8298, ModBlocks.CLOSED_EYEBLOSSOM.get(), "gray_dye");
        method_36444(output, class_1802.field_8192, ModBlocks.WILDFLOWERS.get(), "yellow_dye");

        method_46209(output, class_7800.field_40634, ModBlocks.RESIN_BRICKS.get(), ModItems.RESIN_BRICK.get());
        method_36325(output, class_7800.field_40642, ModBlocks.RESIN_CLUMP.get(), class_7800.field_40634, ModBlocks.RESIN_BLOCK.get());
        shaped(class_7800.field_40642, ModBlocks.CREAKING_HEART.get())
            .method_10434('R', ModBlocks.RESIN_BLOCK.get())
            .method_10434('L', ModBlocks.PALE_OAK_LOG.get())
            .method_10439(" L ")
            .method_10439(" R ")
            .method_10439(" L ")
            .method_10429("has_resin_block", method_10426(ModBlocks.RESIN_BLOCK.get()))
            .method_10431(output);
        class_2454.method_17802(class_1856.method_8091(ModBlocks.RESIN_CLUMP.get()), class_7800.field_40642, ModItems.RESIN_BRICK.get(), 0.1f, 200)
            .method_10469("has_resin_clump", method_10426(ModBlocks.RESIN_CLUMP.get()))
            .method_10431(output);
        method_33715(output, class_7800.field_40634, ModBlocks.RESIN_BRICK_SLAB.get(), ModBlocks.RESIN_BRICKS.get(), 2);
        method_33717(output, class_7800.field_40634, ModBlocks.RESIN_BRICK_STAIRS.get(), ModBlocks.RESIN_BRICKS.get());
        method_33717(output, class_7800.field_40634, ModBlocks.RESIN_BRICK_WALL.get(), ModBlocks.RESIN_BRICKS.get());
        method_33717(output, class_7800.field_40634, ModBlocks.CHISELED_RESIN_BRICKS.get(), ModBlocks.RESIN_BRICKS.get());

        this.dryGhast(output, ModBlocks.DRIED_GHAST.get());

        this.harness(output, ModItems.WHITE_HARNESS.get(), class_2246.field_10446);
        this.harness(output, ModItems.ORANGE_HARNESS.get(), class_2246.field_10095);
        this.harness(output, ModItems.MAGENTA_HARNESS.get(), class_2246.field_10215);
        this.harness(output, ModItems.LIGHT_BLUE_HARNESS.get(), class_2246.field_10294);
        this.harness(output, ModItems.YELLOW_HARNESS.get(), class_2246.field_10490);
        this.harness(output, ModItems.LIME_HARNESS.get(), class_2246.field_10028);
        this.harness(output, ModItems.PINK_HARNESS.get(), class_2246.field_10459);
        this.harness(output, ModItems.GRAY_HARNESS.get(), class_2246.field_10423);
        this.harness(output, ModItems.LIGHT_GRAY_HARNESS.get(), class_2246.field_10222);
        this.harness(output, ModItems.CYAN_HARNESS.get(), class_2246.field_10619);
        this.harness(output, ModItems.PURPLE_HARNESS.get(), class_2246.field_10259);
        this.harness(output, ModItems.BLUE_HARNESS.get(), class_2246.field_10514);
        this.harness(output, ModItems.BROWN_HARNESS.get(), class_2246.field_10113);
        this.harness(output, ModItems.GREEN_HARNESS.get(), class_2246.field_10170);
        this.harness(output, ModItems.RED_HARNESS.get(), class_2246.field_10314);
        this.harness(output, ModItems.BLACK_HARNESS.get(), class_2246.field_10146);

        method_36444(output, class_1802.field_8330, ModBlocks.CACTUS_FLOWER.get(), "pink_dye");

        class_2454.method_17802(class_1856.method_8106(class_3489.field_15558), class_7800.field_40642, ModBlocks.LEAF_LITTER.get(), 0.1F, 200)
            .method_10469("has_leaves", method_10420(class_3489.field_15558))
            .method_10431(output);

        class_2456.method_10476(BundleColoring::new).method_53820(output, "bundle_coloring");

        // Chaos Cubed

        this.generateStonecutterRecipes(output, BlockFamilies.SULFUR, class_7699.method_45398(class_7701.field_40177));
        this.generateStonecutterRecipes(output, BlockFamilies.POLISHED_SULFUR, class_7699.method_45398(class_7701.field_40177));
        this.generateStonecutterRecipes(output, BlockFamilies.SULFUR_BRICKS, class_7699.method_45398(class_7701.field_40177));
        this.generateStonecutterRecipes(output, BlockFamilies.CINNABAR, class_7699.method_45398(class_7701.field_40177));
        this.generateStonecutterRecipes(output, BlockFamilies.POLISHED_CINNABAR, class_7699.method_45398(class_7701.field_40177));
        this.generateStonecutterRecipes(output, BlockFamilies.CINNABAR_BRICKS, class_7699.method_45398(class_7701.field_40177));
        class_2447.method_10436(class_7800.field_40634, ModBlocks.SULFUR_BRICKS.get(), 4)
            .method_10434('S', ModBlocks.POLISHED_SULFUR.get())
            .method_10439("SS")
            .method_10439("SS")
            .method_10429("has_polished_sulfur", method_10426(ModBlocks.POLISHED_SULFUR.get()))
            .method_10431(output);
        class_2447.method_10436(class_7800.field_40634, ModBlocks.CINNABAR_BRICKS.get(), 4)
            .method_10434('S', ModBlocks.POLISHED_CINNABAR.get())
            .method_10439("SS")
            .method_10439("SS")
            .method_10429("has_polished_cinnabar", method_10426(ModBlocks.POLISHED_CINNABAR.get()))
            .method_10431(output);
        method_33715(output, class_7800.field_40634, ModBlocks.SULFUR_BRICKS.get(), ModBlocks.POLISHED_SULFUR.get(), 1);
        method_33715(output, class_7800.field_40634, ModBlocks.CINNABAR_BRICKS.get(), ModBlocks.POLISHED_CINNABAR.get(), 1);

        class_2447.method_10436(class_7800.field_40634, ModBlocks.SULFUR.get(), 1)
            .method_10434('S', ModBlocks.SULFUR_SPIKE.get())
            .method_10439("SS")
            .method_10439("SS")
            .method_10429("has_sulfur_spike", method_10426(ModBlocks.SULFUR_SPIKE.get()))
            .method_10431(output);
        method_47522(output, class_7800.field_40634, ModBlocks.POTENT_SULFUR.get(), ModBlocks.SULFUR.get());
        
        // Copper Age
        this.shelf(output, ModBlocks.ACACIA_SHELF.get(), class_1802.field_8072);
        this.shelf(output, ModBlocks.BAMBOO_SHELF.get(), class_1802.field_41065);
        this.shelf(output, ModBlocks.BIRCH_SHELF.get(), class_1802.field_8767);
        this.shelf(output, ModBlocks.CHERRY_SHELF.get(), class_1802.field_42693);
        this.shelf(output, ModBlocks.CRIMSON_SHELF.get(), class_1802.field_21983);
        this.shelf(output, ModBlocks.DARK_OAK_SHELF.get(), class_1802.field_8808);
        this.shelf(output, ModBlocks.JUNGLE_SHELF.get(), class_1802.field_8334);
        this.shelf(output, ModBlocks.MANGROVE_SHELF.get(), class_1802.field_37515);
        this.shelf(output, ModBlocks.OAK_SHELF.get(), class_1802.field_8415);
        this.shelf(output, ModBlocks.PALE_OAK_SHELF.get(), ModBlocks.STRIPPED_PALE_OAK_LOG.get());
        this.shelf(output, ModBlocks.SPRUCE_SHELF.get(), class_1802.field_8624);
        this.shelf(output, ModBlocks.WARPED_SHELF.get(), class_1802.field_21984);
        
        shaped(class_7800.field_40635, ModBlocks.COPPER_CHEST.get())
            .method_10434('#', class_1802.field_27022)
            .method_10434('X', class_1802.field_8106)
            .method_10439("###")
            .method_10439("#X#")
            .method_10439("###")
            .method_10429("has_copper_chest", method_10426(ModBlocks.COPPER_CHEST.get()))
            .method_10431(output);
        
        shaped(class_7800.field_40635, ModBlocks.COPPER_TORCH.getFirst().get(), 4)
            .method_10428('X', class_1856.method_8091(class_1802.field_8713, class_1802.field_8665))
            .method_10434('#', class_1802.field_8600)
            .method_10434('C', ModItems.COPPER_NUGGET.get())
            .method_10439("C")
            .method_10439("X")
            .method_10439("#")
            .method_10429("has_copper_nugget", method_10426(ModItems.COPPER_NUGGET.get()))
            .method_10431(output);
        shaped(class_7800.field_40635, ModBlocks.COPPER_LANTERN.unaffected().get())
            .method_10434('#', ModBlocks.COPPER_TORCH.getFirst().get())
            .method_10434('X', ModItems.COPPER_NUGGET.get())
            .method_10439("XXX")
            .method_10439("X#X")
            .method_10439("XXX")
            .method_10429("has_copper_torch", method_10426(ModBlocks.COPPER_TORCH.getFirst().get()))
            .method_10431(output);
        shaped(class_7800.field_40635, ModBlocks.COPPER_BARS.unaffected().get(), 16)
            .method_10434('#', class_1802.field_27022)
            .method_10439("###")
            .method_10439("###")
            .method_10429("has_copper_ingot", method_10426(class_1802.field_27022))
            .method_10431(output);
        shaped(class_7800.field_40635, ModBlocks.COPPER_CHAIN.unaffected().get())
            .method_10434('I', class_1802.field_27022)
            .method_10434('N', ModItems.COPPER_NUGGET.get())
            .method_10439("N")
            .method_10439("I")
            .method_10439("N")
            .method_10429("has_copper_nugget", method_10426(ModItems.COPPER_NUGGET.get()))
            .method_10429("has_copper_ingot", method_10426(class_1802.field_27022))
            .method_10431(output);
        
        waxRecipes(output, ModBlocks.COPPER_CHEST.get(), ModBlocks.WAXED_COPPER_CHEST.get());
        waxRecipes(output, ModBlocks.EXPOSED_COPPER_CHEST.get(), ModBlocks.WAXED_EXPOSED_COPPER_CHEST.get());
        waxRecipes(output, ModBlocks.WEATHERED_COPPER_CHEST.get(), ModBlocks.WAXED_WEATHERED_COPPER_CHEST.get());
        waxRecipes(output, ModBlocks.OXIDIZED_COPPER_CHEST.get(), ModBlocks.WAXED_OXIDIZED_COPPER_CHEST.get());
        
        waxRecipes(output, ModBlocks.COPPER_GOLEM_STATUE.get(), ModBlocks.WAXED_COPPER_GOLEM_STATUE.get());
        waxRecipes(output, ModBlocks.EXPOSED_COPPER_GOLEM_STATUE.get(), ModBlocks.WAXED_EXPOSED_COPPER_GOLEM_STATUE.get());
        waxRecipes(output, ModBlocks.WEATHERED_COPPER_GOLEM_STATUE.get(), ModBlocks.WAXED_WEATHERED_COPPER_GOLEM_STATUE.get());
        waxRecipes(output, ModBlocks.OXIDIZED_COPPER_GOLEM_STATUE.get(), ModBlocks.WAXED_OXIDIZED_COPPER_GOLEM_STATUE.get());
        
        waxRecipes(output, class_2246.field_27171, ModBlocks.WAXED_LIGHTNING_ROD.get());
        waxRecipes(output, ModBlocks.EXPOSED_LIGHTNING_ROD.get(), ModBlocks.WAXED_EXPOSED_LIGHTNING_ROD.get());
        waxRecipes(output, ModBlocks.WEATHERED_LIGHTNING_ROD.get(), ModBlocks.WAXED_WEATHERED_LIGHTNING_ROD.get());
        waxRecipes(output, ModBlocks.OXIDIZED_LIGHTNING_ROD.get(), ModBlocks.WAXED_OXIDIZED_LIGHTNING_ROD.get());
        
        // Mounts of Mayhem
        
        method_29728(output, ModItems.DIAMOND_SPEAR.get(), class_7800.field_40639, ModItems.NETHERITE_SPEAR.get());
        method_29728(output, class_1802.field_8807, class_7800.field_40639, ModItems.NETHERITE_HORSE_ARMOR.get());
        method_29728(output, ModItems.DIAMOND_NAUTILUS_ARMOR.get(), class_7800.field_40639, ModItems.NETHERITE_NAUTILUS_ARMOR.get());
        
        // Wilderness Bound
        
        method_24475(output, ModBlocks.POPLAR_PLANKS.get(), ModItemTags.POPLAR_LOGS, 4);
        method_24476(output, ModBlocks.POPLAR_WOOD.get(), ModBlocks.POPLAR_LOG.get());
        method_24476(output, ModBlocks.STRIPPED_POPLAR_WOOD.get(), ModBlocks.STRIPPED_POPLAR_LOG.get());
        method_24478(output, ModItems.POPLAR_BOAT.get(), ModBlocks.POPLAR_PLANKS.get());
        method_42754(output, ModItems.POPLAR_CHEST_BOAT.get(), ModItems.POPLAR_BOAT.get());
        method_46208(output, ModBlocks.POPLAR_HANGING_SIGN.getFirst().get(), ModBlocks.STRIPPED_POPLAR_LOG.get());
        this.shelf(output, ModBlocks.POPLAR_SHELF.get(), ModBlocks.STRIPPED_POPLAR_LOG.get());
        
        List<class_1792> dyes = List.of(class_1802.field_8226, class_1802.field_8345, class_1802.field_8099, class_1802.field_8632, class_1802.field_8298, class_1802.field_8408, class_1802.field_8273, class_1802.field_8851, class_1802.field_8131, class_1802.field_8669, class_1802.field_8492, class_1802.field_8330, class_1802.field_8296, class_1802.field_8264, class_1802.field_8192, class_1802.field_8446);
        List<class_1792> wool_stairs = List.of(ModBlocks.BLACK_WOOL_STAIRS.get().method_8389(), ModBlocks.BLUE_WOOL_STAIRS.get().method_8389(), ModBlocks.BROWN_WOOL_STAIRS.get().method_8389(), ModBlocks.CYAN_WOOL_STAIRS.get().method_8389(), ModBlocks.GRAY_WOOL_STAIRS.get().method_8389(), ModBlocks.GREEN_WOOL_STAIRS.get().method_8389(), ModBlocks.LIGHT_BLUE_WOOL_STAIRS.get().method_8389(), ModBlocks.LIGHT_GRAY_WOOL_STAIRS.get().method_8389(), ModBlocks.LIME_WOOL_STAIRS.get().method_8389(), ModBlocks.MAGENTA_WOOL_STAIRS.get().method_8389(), ModBlocks.ORANGE_WOOL_STAIRS.get().method_8389(), ModBlocks.PINK_WOOL_STAIRS.get().method_8389(), ModBlocks.PURPLE_WOOL_STAIRS.get().method_8389(), ModBlocks.RED_WOOL_STAIRS.get().method_8389(), ModBlocks.YELLOW_WOOL_STAIRS.get().method_8389(), ModBlocks.WHITE_WOOL_STAIRS.get().method_8389());
        List<class_1792> wool_slabs = List.of(ModBlocks.BLACK_WOOL_SLAB.get().method_8389(), ModBlocks.BLUE_WOOL_SLAB.get().method_8389(), ModBlocks.BROWN_WOOL_SLAB.get().method_8389(), ModBlocks.CYAN_WOOL_SLAB.get().method_8389(), ModBlocks.GRAY_WOOL_SLAB.get().method_8389(), ModBlocks.GREEN_WOOL_SLAB.get().method_8389(), ModBlocks.LIGHT_BLUE_WOOL_SLAB.get().method_8389(), ModBlocks.LIGHT_GRAY_WOOL_SLAB.get().method_8389(), ModBlocks.LIME_WOOL_SLAB.get().method_8389(), ModBlocks.MAGENTA_WOOL_SLAB.get().method_8389(), ModBlocks.ORANGE_WOOL_SLAB.get().method_8389(), ModBlocks.PINK_WOOL_SLAB.get().method_8389(), ModBlocks.PURPLE_WOOL_SLAB.get().method_8389(), ModBlocks.RED_WOOL_SLAB.get().method_8389(), ModBlocks.YELLOW_WOOL_SLAB.get().method_8389(), ModBlocks.WHITE_WOOL_SLAB.get().method_8389());
        List<class_1792> harness = List.of(ModItems.BLACK_HARNESS.get(), ModItems.BLUE_HARNESS.get(), ModItems.BROWN_HARNESS.get(), ModItems.CYAN_HARNESS.get(), ModItems.GRAY_HARNESS.get(), ModItems.GREEN_HARNESS.get(), ModItems.LIGHT_BLUE_HARNESS.get(), ModItems.LIGHT_GRAY_HARNESS.get(), ModItems.LIME_HARNESS.get(), ModItems.MAGENTA_HARNESS.get(), ModItems.ORANGE_HARNESS.get(), ModItems.PINK_HARNESS.get(), ModItems.PURPLE_HARNESS.get(), ModItems.RED_HARNESS.get(), ModItems.YELLOW_HARNESS.get(), ModItems.WHITE_HARNESS.get());
        List<class_1792> cushion = List.of(ModItems.BLACK_CUSHION.get(), ModItems.BLUE_CUSHION.get(), ModItems.BROWN_CUSHION.get(), ModItems.CYAN_CUSHION.get(), ModItems.GRAY_CUSHION.get(), ModItems.GREEN_CUSHION.get(), ModItems.LIGHT_BLUE_CUSHION.get(), ModItems.LIGHT_GRAY_CUSHION.get(), ModItems.LIME_CUSHION.get(), ModItems.MAGENTA_CUSHION.get(), ModItems.ORANGE_CUSHION.get(), ModItems.PINK_CUSHION.get(), ModItems.PURPLE_CUSHION.get(), ModItems.RED_CUSHION.get(), ModItems.YELLOW_CUSHION.get(), ModItems.WHITE_CUSHION.get());
        method_51890(output, dyes, wool_stairs, "wool_stairs");
        method_51890(output, dyes, wool_slabs, "wool_slabs");
        method_51890(output, dyes, harness, "harness_dye");
        method_51890(output, dyes, cushion, "cushion_dye");
        
        this.cushionRecipe(output, ModBlocks.WHITE_WOOL_SLAB.get().method_8389(), ModItems.WHITE_CUSHION.get());
        this.cushionRecipe(output, ModBlocks.ORANGE_WOOL_SLAB.get().method_8389(), ModItems.ORANGE_CUSHION.get());
        this.cushionRecipe(output, ModBlocks.MAGENTA_WOOL_SLAB.get().method_8389(), ModItems.MAGENTA_CUSHION.get());
        this.cushionRecipe(output, ModBlocks.LIGHT_BLUE_WOOL_SLAB.get().method_8389(), ModItems.LIGHT_BLUE_CUSHION.get());
        this.cushionRecipe(output, ModBlocks.YELLOW_WOOL_SLAB.get().method_8389(), ModItems.YELLOW_CUSHION.get());
        this.cushionRecipe(output, ModBlocks.LIME_WOOL_SLAB.get().method_8389(), ModItems.LIME_CUSHION.get());
        this.cushionRecipe(output, ModBlocks.PINK_WOOL_SLAB.get().method_8389(), ModItems.PINK_CUSHION.get());
        this.cushionRecipe(output, ModBlocks.GRAY_WOOL_SLAB.get().method_8389(), ModItems.GRAY_CUSHION.get());
        this.cushionRecipe(output, ModBlocks.LIGHT_GRAY_WOOL_SLAB.get().method_8389(), ModItems.LIGHT_GRAY_CUSHION.get());
        this.cushionRecipe(output, ModBlocks.CYAN_WOOL_SLAB.get().method_8389(), ModItems.CYAN_CUSHION.get());
        this.cushionRecipe(output, ModBlocks.PURPLE_WOOL_SLAB.get().method_8389(), ModItems.PURPLE_CUSHION.get());
        this.cushionRecipe(output, ModBlocks.BLUE_WOOL_SLAB.get().method_8389(), ModItems.BLUE_CUSHION.get());
        this.cushionRecipe(output, ModBlocks.BROWN_WOOL_SLAB.get().method_8389(), ModItems.BROWN_CUSHION.get());
        this.cushionRecipe(output, ModBlocks.GREEN_WOOL_SLAB.get().method_8389(), ModItems.GREEN_CUSHION.get());
        this.cushionRecipe(output, ModBlocks.RED_WOOL_SLAB.get().method_8389(), ModItems.RED_CUSHION.get());
        this.cushionRecipe(output, ModBlocks.BLACK_WOOL_SLAB.get().method_8389(), ModItems.BLACK_CUSHION.get());

        List<class_5794> concrete_families = List.of(BlockFamilies.BLACK_CONCRETE, BlockFamilies.BLUE_CONCRETE,
            BlockFamilies.BROWN_CONCRETE, BlockFamilies.CYAN_CONCRETE, BlockFamilies.GRAY_CONCRETE,
            BlockFamilies.GREEN_CONCRETE, BlockFamilies.LIGHT_BLUE_CONCRETE, BlockFamilies.LIGHT_GRAY_CONCRETE,
            BlockFamilies.LIME_CONCRETE, BlockFamilies.MAGENTA_CONCRETE, BlockFamilies.ORANGE_CONCRETE,
            BlockFamilies.PINK_CONCRETE, BlockFamilies.PURPLE_CONCRETE, BlockFamilies.RED_CONCRETE,
            BlockFamilies.YELLOW_CONCRETE, BlockFamilies.WHITE_CONCRETE);
        concrete_families.forEach(blockFamily -> this.generateStonecutterRecipes(output, blockFamily, class_7699.method_45398(class_7701.field_40177)));
        
        shaped(class_7800.field_40635, ModBlocks.STRAW_BED.get(), 4)
            .method_10434('X', class_1802.field_17528)
            .method_10439("XXX")
            .method_10429("has_hay_block", method_10426(class_1802.field_17528))
            .method_10429("has_straw_bed", method_10426(ModBlocks.STRAW_BED.get()))
            .method_10431(output);
    }

    public static class_2447 shaped(class_7800 category, class_1935 entry) {
        return class_2447.method_10437(category, entry);
    }

    public static class_2447 shaped(class_7800 category, class_1935 entry, int amount) {
        return class_2447.method_10436(category, entry, amount);
    }

    private void dryGhast(class_8790 output, class_1935 ghast) {
        class_2447.method_10437(class_7800.field_40634, ghast)
            .method_10434('#', class_1802.field_8070)
            .method_10434('X', class_1802.field_8067)
            .method_10439("###")
            .method_10439("#X#")
            .method_10439("###")
            .method_10435("dry_ghast")
            .method_10429(method_32807(class_1802.field_8070), method_10426(class_1802.field_8070))
            .method_10431(output);
    }

    private void harness(class_8790 output, class_1935 harness, class_1935 carpet) {
        class_2447.method_10437(class_7800.field_40637, harness)
            .method_10434('#', carpet)
            .method_10434('G', class_1802.field_8280)
            .method_10434('L', class_1802.field_8745)
            .method_10439("LLL")
            .method_10439("G#G")
            .method_10435("harness")
            .method_10429("has_dried_ghast", method_10426(ModBlocks.DRIED_GHAST.get()))
            .method_10431(output);
    }

    private void generateStonecutterRecipes(class_8790 exporter, class_5794 family, class_7699 flagSet) {
        family.method_33474().forEach((variant, result) -> {
            if (result.method_45322().method_45400(flagSet)) {
                class_2248 base = family.method_33469();
                this.generateStonecutterRecipe(exporter, family, variant, base);
            }
        });
    }

    private void generateStonecutterRecipe(class_8790 exporter, class_5794 family, class_5794.class_5796 variant, class_2248 base) {
        FamilyStonecutterRecipeProvider recipeFunction = STONECUTTER_RECIPE_BUILDERS.get(variant);
        if (recipeFunction != null) {
            recipeFunction.create(exporter, family.method_33470(variant), base);
        }

        if (variant == class_5794.class_5796.field_28542 || variant == class_5794.class_5796.field_33689) {
            class_5794 childVariantFamily = BlockFamilies.getFamily(family.method_33470(variant));
            if (childVariantFamily != null) {
                childVariantFamily.method_33474().forEach((childVariant, r) -> this.generateStonecutterRecipe(exporter, childVariantFamily, childVariant, base));
            }
        }
    }
    
    public void shelf(class_8790 output, class_1935 result, class_1935 strippedLogs) {
        shaped(class_7800.field_40635, result, 6)
            .method_10434('#', strippedLogs)
            .method_10439("###")
            .method_10439("   ")
            .method_10439("###")
            .method_10435("shelf")
            .method_10429(method_32807(strippedLogs), method_10426(strippedLogs))
            .method_10431(output);
    }
    
    public void cushionRecipe(class_8790 output, class_1792 woolSlab, class_1792 result) {
        shaped(class_7800.field_40635, result, 1)
            .method_10434('#', woolSlab)
            .method_10435("cushion")
            .method_10429(method_32807(woolSlab), method_10426(woolSlab))
            .method_10439("###")
            .method_10431(output);
    }
    
    public static void waxRecipes(class_8790 output, class_2248 unwaxed, class_2248 waxed) {
        class_2450.method_10447(class_7800.field_40634, waxed)
            .method_10454(unwaxed)
            .method_10454(class_1802.field_20414)
            .method_10452(method_33716(waxed))
            .method_10442(method_32807(unwaxed), method_10426(unwaxed))
            .method_36443(output, method_33714(waxed, class_1802.field_20414));
    }

    @FunctionalInterface
    private interface FamilyStonecutterRecipeProvider {
        void create(class_8790 exporter, class_1935 result, class_1935 base);
    }

    @Override
    public String method_10321() {
        return "Vanilla Backport recipes";
    }
}