package com.blackgear.vanillabackport.data.server.builder;

import com.blackgear.vanillabackport.common.registries.worldgen.ModNoises;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricDynamicRegistryProvider;
import net.minecraft.class_5216.class_5487;
import net.minecraft.class_5321;
import net.minecraft.class_7225;
import net.minecraft.class_7924;
import java.util.concurrent.CompletableFuture;

public class NoiseGenerator extends FabricDynamicRegistryProvider {
    public NoiseGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected void configure(class_7225.class_7874 provider, Entries entries) {
        this.add(provider, entries, ModNoises.SULFUR_CAVE_GRADIENT);
        this.add(provider, entries, ModNoises.SMALL_PATCH);
    }

    private void add(class_7225.class_7874 provider, Entries entries, class_5321<class_5487> key) {
        final class_7225.class_7226<class_5487> registry = provider.method_46762(class_7924.field_41244);
        entries.add(key, registry.method_46747(key).comp_349());
    }

    @Override
    public String method_10321() {
        return "worldgen/noise";
    }
}