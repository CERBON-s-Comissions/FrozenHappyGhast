package com.blackgear.vanillabackport.data.server.tags;

import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import com.blackgear.vanillabackport.core.data.tags.ModBlockTags;
import com.blackgear.vanillabackport.core.data.tags.loader.ConventionalBlockTags;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_3481;
import net.minecraft.class_6862;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;

public class BlockTagGenerator extends FabricTagProvider.BlockTagProvider {
    public BlockTagGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected void method_10514(class_7225.class_7874 provider) {
        new BlockItemTagGenerator() {
            @Override
            protected TagHolder tag(class_6862<class_2248> block, class_6862<class_1792> item) {
                return new TagHolder(null, BlockTagGenerator.this.getOrCreateTagBuilder(block));
            }
        }.addTags();

        this.getOrCreateTagBuilder(class_3481.field_39030)
            .add(ModBlocks.PALE_OAK_LOG.get())
            .add(ModBlocks.POPLAR_LOG.get());

        this.getOrCreateTagBuilder(class_3481.field_15460)
            .add(ModBlocks.CACTUS_FLOWER.get());

        this.getOrCreateTagBuilder(class_3481.field_15470)
            .add(
                ModBlocks.POTTED_OPEN_EYEBLOSSOM.get(),
                ModBlocks.POTTED_CLOSED_EYEBLOSSOM.get(),
                ModBlocks.POTTED_PALE_OAK_SAPLING.get(),
                ModBlocks.POTTED_POPLAR_SAPLING.get()
            );

        this.getOrCreateTagBuilder(class_3481.field_15492)
            .add(ModBlocks.PALE_OAK_SIGN.getSecond().get())
            .add(ModBlocks.POPLAR_SIGN.getSecond().get());

        this.getOrCreateTagBuilder(class_3481.field_40104)
            .add(ModBlocks.PALE_OAK_HANGING_SIGN.getSecond().get())
            .add(ModBlocks.POPLAR_HANGING_SIGN.getSecond().get());

        this.getOrCreateTagBuilder(class_3481.field_22276)
            .add(ModBlocks.CACTUS_FLOWER.get())
            .add(ModBlocks.COPPER_TORCH.getFirst().get());

        this.getOrCreateTagBuilder(class_3481.field_28040)
            .add(ModBlocks.WILDFLOWERS.get(), ModBlocks.LEAF_LITTER.get());

        this.getOrCreateTagBuilder(class_3481.field_43170)
            .add(ModBlocks.PALE_MOSS_CARPET.get(), ModBlocks.RESIN_CLUMP.get());

        this.getOrCreateTagBuilder(class_3481.field_33713)
            .add(ModBlocks.CREAKING_HEART.get())
            .method_26792(ModBlockTags.WOODEN_SHELVES);

        this.getOrCreateTagBuilder(class_3481.field_33714)
            .add(
                ModBlocks.PALE_OAK_LEAVES.get(),
                ModBlocks.PALE_MOSS_BLOCK.get(),
                ModBlocks.PALE_MOSS_CARPET.get(),
                ModBlocks.RED_POPLAR_LEAVES.get(),
                ModBlocks.ORANGE_POPLAR_LEAVES.get(),
                ModBlocks.YELLOW_POPLAR_LEAVES.get(),
                ModBlocks.STRAW_BED.get()
            );

        this.getOrCreateTagBuilder(class_3481.field_33715)
            .add(
                ModBlocks.RESIN_BRICKS.get(),
                ModBlocks.RESIN_BRICK_SLAB.get(),
                ModBlocks.RESIN_BRICK_WALL.get(),
                ModBlocks.RESIN_BRICK_STAIRS.get(),
                ModBlocks.CHISELED_RESIN_BRICKS.get(),
                ModBlocks.CINNABAR.get(),
                ModBlocks.CINNABAR_SLAB.get(),
                ModBlocks.CINNABAR_STAIRS.get(),
                ModBlocks.CINNABAR_WALL.get(),
                ModBlocks.POLISHED_CINNABAR.get(),
                ModBlocks.POLISHED_CINNABAR_SLAB.get(),
                ModBlocks.POLISHED_CINNABAR_STAIRS.get(),
                ModBlocks.POLISHED_CINNABAR_WALL.get(),
                ModBlocks.CINNABAR_BRICKS.get(),
                ModBlocks.CINNABAR_BRICK_SLAB.get(),
                ModBlocks.CINNABAR_BRICK_STAIRS.get(),
                ModBlocks.CINNABAR_BRICK_WALL.get(),
                ModBlocks.CHISELED_CINNABAR.get(),
                ModBlocks.SULFUR.get(),
                ModBlocks.POTENT_SULFUR.get(),
                ModBlocks.SULFUR_SLAB.get(),
                ModBlocks.SULFUR_STAIRS.get(),
                ModBlocks.SULFUR_WALL.get(),
                ModBlocks.POLISHED_SULFUR.get(),
                ModBlocks.POLISHED_SULFUR_SLAB.get(),
                ModBlocks.POLISHED_SULFUR_STAIRS.get(),
                ModBlocks.POLISHED_SULFUR_WALL.get(),
                ModBlocks.SULFUR_BRICKS.get(),
                ModBlocks.SULFUR_BRICK_SLAB.get(),
                ModBlocks.SULFUR_BRICK_STAIRS.get(),
                ModBlocks.SULFUR_BRICK_WALL.get(),
                ModBlocks.CHISELED_SULFUR.get()
            )
            .method_26792(ModBlockTags.SPELEOTHEMS)
            .method_26792(ModBlockTags.COPPER_CHESTS)
            .method_26792(ModBlockTags.COPPER_GOLEM_STATUES)
            .method_26792(ModBlockTags.LIGHTNING_RODS)
            .method_26792(ModBlockTags.LANTERNS)
            .method_26792(ModBlockTags.CHAINS)
            .method_26792(ModBlockTags.BARS)
            .method_26792(ModBlockTags.CONCRETE_SLABS)
            .method_26792(ModBlockTags.CONCRETE_STAIRS);
        
        this.getOrCreateTagBuilder(class_3481.field_33719)
            .method_26792(ModBlockTags.COPPER_CHESTS)
            .method_26792(ModBlockTags.LIGHTNING_RODS);
        
        this.getOrCreateTagBuilder(class_3481.field_44470)
            .add(
                ModBlocks.PALE_MOSS_CARPET.get(),
                ModBlocks.BUSH.get(),
                ModBlocks.FIREFLY_BUSH.get(),
                ModBlocks.LEAF_LITTER.get(),
                ModBlocks.SHORT_DRY_GRASS.get(),
                ModBlocks.TALL_DRY_GRASS.get(),
                ModBlocks.RED_SHRUB.get(),
                ModBlocks.SHELF_MUSHROOM.get()
            );
        
        this.getOrCreateTagBuilder(ModBlockTags.REQUIRED_FOR_POPLAR_LEAF_AMBIENCE)
            .forceAddTag(class_3481.field_39030);

        this.getOrCreateTagBuilder(class_3481.field_42607)
            .add(ModBlocks.PALE_MOSS_BLOCK.get());

        this.getOrCreateTagBuilder(ModBlockTags.HAPPY_GHAST_AVOIDS)
            .add(
                class_2246.field_16999,
                class_2246.field_10029,
                class_2246.field_10606,
                class_2246.field_10092,
                class_2246.field_10036
            )
            .forceAddTag(ModBlockTags.SPELEOTHEMS);

        this.getOrCreateTagBuilder(ModBlockTags.TRIGGERS_AMBIENT_DESERT_SAND_BLOCK_SOUNDS)
            .add(class_2246.field_10102, class_2246.field_10534);

        this.getOrCreateTagBuilder(ModBlockTags.TRIGGERS_AMBIENT_DESERT_DRY_VEGETATION_BLOCK_SOUNDS)
            .forceAddTag(class_3481.field_36265)
            .add(class_2246.field_10102, class_2246.field_10534);

        this.getOrCreateTagBuilder(ModBlockTags.TRIGGERS_AMBIENT_DRIED_GHAST_BLOCK_SOUNDS)
            .add(class_2246.field_10114, class_2246.field_22090);

        this.getOrCreateTagBuilder(ModBlockTags.SPAWN_FALLING_LEAVES)
            .add(
                class_2246.field_10503,
                class_2246.field_10539,
                class_2246.field_10335,
                class_2246.field_10098,
                class_2246.field_10035,
                class_2246.field_28673,
                class_2246.field_28674
            );

        this.getOrCreateTagBuilder(ModBlockTags.SPAWN_FALLING_NEEDLES)
            .add(class_2246.field_9988);

        this.getOrCreateTagBuilder(ModBlockTags.ALLOWS_LEAF_LITTER)
            .add(
                class_2246.field_10503,
                class_2246.field_10539,
                class_2246.field_10035
            )
            .add(ModBlocks.RED_POPLAR_LEAVES.get(), ModBlocks.ORANGE_POPLAR_LEAVES.get(), ModBlocks.YELLOW_POPLAR_LEAVES.get());

        this.getOrCreateTagBuilder(ModBlockTags.SUPPORTS_CACTUS)
            .forceAddTag(class_3481.field_15466);

        this.getOrCreateTagBuilder(ModBlockTags.SUPPORT_OVERRIDE_CACTUS_FLOWER)
            .add(class_2246.field_10029, class_2246.field_10362);

        this.getOrCreateTagBuilder(ModBlockTags.CREAKING_HEART_HOLDERS)
            .forceAddTag(ModBlockTags.PALE_OAK_LOGS);

        this.getOrCreateTagBuilder(ModBlockTags.CAMELS_SPAWNABLE_ON)
            .forceAddTag(class_3481.field_15466);

        this.getOrCreateTagBuilder(class_3481.field_38832)
            .add(
                ModBlocks.CINNABAR.get(),
                ModBlocks.SULFUR.get(),
                ModBlocks.POTENT_SULFUR.get()
            );

        this.getOrCreateTagBuilder(class_3481.field_37399)
            .add(
                ModBlocks.CINNABAR.get(),
                ModBlocks.SULFUR.get()
            );

        this.getOrCreateTagBuilder(ModBlockTags.CAUSES_PERIODIC_GEYSER_ERUPTIONS)
            .add(class_2246.field_10092);

        this.getOrCreateTagBuilder(ModBlockTags.CAUSES_CONTINUOUS_GEYSER_ERUPTIONS)
            .add(class_2246.field_10164);

        this.getOrCreateTagBuilder(ModBlockTags.SPELEOTHEMS)
            .add(
                class_2246.field_28048,
                ModBlocks.SULFUR_SPIKE.get()
            );

        this.getOrCreateTagBuilder(ModBlockTags.SULFUR_SPIKE_REPLACEABLE)
            .add(
                ModBlocks.SULFUR.get(),
                ModBlocks.CINNABAR.get()
            );

        this.getOrCreateTagBuilder(ModBlockTags.SUPPRESSES_BOUNCE)
            .add(class_2246.field_21211);
        
        this.getOrCreateTagBuilder(ModBlockTags.COPPER_CHESTS).add(
            ModBlocks.COPPER_CHEST.get(),
            ModBlocks.EXPOSED_COPPER_CHEST.get(),
            ModBlocks.WEATHERED_COPPER_CHEST.get(),
            ModBlocks.OXIDIZED_COPPER_CHEST.get(),
            ModBlocks.WAXED_COPPER_CHEST.get(),
            ModBlocks.WAXED_EXPOSED_COPPER_CHEST.get(),
            ModBlocks.WAXED_WEATHERED_COPPER_CHEST.get(),
            ModBlocks.WAXED_OXIDIZED_COPPER_CHEST.get()
        );
        
        this.getOrCreateTagBuilder(ModBlockTags.INCORRECT_FOR_COPPER_TOOL)
            .forceAddTag(class_3481.field_33717)
            .forceAddTag(class_3481.field_33718);
        
        this.getOrCreateTagBuilder(ModBlockTags.TRANSPORT_ITEM_SOURCE_BLOCKS)
            .forceAddTag(ModBlockTags.COPPER_CHESTS);
        
        this.getOrCreateTagBuilder(ModBlockTags.TRANSPORT_ITEM_DESTINATION_BLOCKS)
            .add(class_2246.field_10034)
            .add(class_2246.field_10380)
            .forceAddTag(ConventionalBlockTags.CHESTS);

        this.getOrCreateTagBuilder(ModBlockTags.CUSHION_USES_COLLISION_SHAPE)
            .forceAddTag(class_3481.field_26985)
            .add(class_2246.field_10312)
            .add(class_2246.field_17563);
    }

    protected DualTagHolder getDualTagBuilder(class_6862<class_2248> forge, class_6862<class_2248> fabric) {
        return new DualTagHolder(this.getOrCreateTagBuilder(fabric), this.getOrCreateTagBuilder(forge));
    }

    protected record DualTagHolder(FabricTagProvider<class_2248>.FabricTagBuilder forge, FabricTagProvider<class_2248>.FabricTagBuilder fabric) {
        public DualTagHolder add(class_2248 entry) {
            this.forge.add(entry);
            this.fabric.add(entry);
            return this;
        }

        public DualTagHolder add(class_2248... toAdd) {
            this.forge.add(toAdd);
            this.fabric.add(toAdd);
            return this;
        }

        public DualTagHolder addOptional(class_2960 location) {
            this.forge.method_35922(location);
            this.fabric.method_35922(location);
            return this;
        }

        public DualTagHolder addTag(class_6862<class_2248> tag) {
            this.forge.method_26792(tag);
            this.fabric.method_26792(tag);
            return this;
        }

        public DualTagHolder addOptionalTag(class_6862<class_2248> tag) {
            this.forge.addOptionalTag(tag);
            this.fabric.addOptionalTag(tag);
            return this;
        }
    }
}