package com.blackgear.vanillabackport.data;

import com.blackgear.vanillabackport.common.level.worldgen.structure.AbandonedCampStructurePools;
import com.blackgear.vanillabackport.common.registries.entities.ModDamageTypes;
import com.blackgear.vanillabackport.common.registries.enchantment.ModEnchantments;
import com.blackgear.vanillabackport.common.registries.items.ModJukeboxSongs;
import com.blackgear.vanillabackport.common.registries.items.ModPaintingVariants;
import com.blackgear.vanillabackport.common.registries.items.ModTrimMaterials;
import com.blackgear.vanillabackport.common.registries.worldgen.ModBiomes;
import com.blackgear.vanillabackport.common.registries.worldgen.ModNoises;
import com.blackgear.vanillabackport.common.worldgen.features.ChaosCubedFeatures;
import com.blackgear.vanillabackport.common.worldgen.features.SpringToLifeFeatures;
import com.blackgear.vanillabackport.common.worldgen.features.TheGardenAwakensFeatures;
import com.blackgear.vanillabackport.common.worldgen.features.WildernessBoundFeatures;
import com.blackgear.vanillabackport.common.worldgen.placements.ChaosCubedPlacements;
import com.blackgear.vanillabackport.common.worldgen.placements.SpringToLifePlacements;
import com.blackgear.vanillabackport.common.worldgen.placements.TheGardenAwakensPlacements;
import com.blackgear.vanillabackport.common.worldgen.placements.WildernessBoundPlacements;
import com.blackgear.vanillabackport.common.worldgen.structures.WildernessBoundStructureSets;
import com.blackgear.vanillabackport.common.worldgen.structures.WildernessBoundStructures;
import com.blackgear.vanillabackport.data.client.LangGenerator;
import com.blackgear.vanillabackport.data.client.ModelGenerator;
import com.blackgear.vanillabackport.data.client.WaypointStyleProvider;
import com.blackgear.vanillabackport.data.server.advancement.AdvancementGenerator;
import com.blackgear.vanillabackport.data.server.builder.*;
import com.blackgear.vanillabackport.data.server.loot.BlockLootGenerator;
import com.blackgear.vanillabackport.data.server.loot.ChestLootGenerator;
import com.blackgear.vanillabackport.data.server.loot.EntityLootGenerator;
import com.blackgear.vanillabackport.data.server.loot.GiftLootGenerator;
import com.blackgear.vanillabackport.data.server.recipe.RecipeGenerator;
import com.blackgear.vanillabackport.data.server.tags.*;
import net.fabricmc.fabric.api.datagen.v1.DataGeneratorEntrypoint;
import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;
import net.minecraft.class_7877;
import net.minecraft.class_7924;

public class DataGenerator implements DataGeneratorEntrypoint {
    @Override
    public void onInitializeDataGenerator(FabricDataGenerator generator) {
        FabricDataGenerator.Pack pack = generator.createPack();

        // CLIENT SIDE
        pack.addProvider(ModelGenerator::new);
        pack.addProvider(LangGenerator::new);
        pack.addProvider(WaypointStyleProvider::new);

        // SERVER SIDE
        pack.addProvider(AdvancementGenerator::new);

        pack.addProvider(BlockLootGenerator::new);
        pack.addProvider(GiftLootGenerator::new);
        pack.addProvider(EntityLootGenerator::new);
        pack.addProvider(ChestLootGenerator::new);

        pack.addProvider(RecipeGenerator::new);

        pack.addProvider(BiomeTagGenerator::new);
        pack.addProvider(BlockTagGenerator::new);
        pack.addProvider(ItemTagGenerator::new);
        pack.addProvider(EntityTypeTagGenerator::new);
        pack.addProvider(DamageTypeTagGenerator::new);
        pack.addProvider(PaintingVariantTagGenerator::new);
        pack.addProvider(EnchantmentTagGenerator::new);
        pack.addProvider(StructureTagGenerator::new);

        pack.addProvider(PaintVariantsGenerator::new);
        pack.addProvider(TrimMaterialGenerator::new);
        pack.addProvider(BiomeGenerator::new);
        pack.addProvider(NoiseGenerator::new);
        pack.addProvider(DamageTypeGenerator::new);
        pack.addProvider(ConfiguredFeatureGenerator::new);
        pack.addProvider(PlacedFeatureGenerator::new);
        pack.addProvider(StructureGenerator::new);
        pack.addProvider(JukeboxSongGenerator::new);
        pack.addProvider(EnchantmentGenerator::new);
    }

    @Override
    public void buildRegistry(class_7877 builder) {
        builder.method_46777(class_7924.field_41209, ModPaintingVariants.REGISTRIES::bootstrap);
        builder.method_46777(class_7924.field_42083, ModTrimMaterials.REGISTRIES::bootstrap);
        builder.method_46777(class_7924.field_52176, ModJukeboxSongs.REGISTRIES::bootstrap);
        builder.method_46777(class_7924.field_41236, ModBiomes.REGISTRIES::bootstrap);
        builder.method_46777(class_7924.field_41244, ModNoises.REGISTRIES::bootstrap);
        builder.method_46777(class_7924.field_42534, ModDamageTypes.REGISTRIES::bootstrap);
        builder.method_46777(class_7924.field_41265, ModEnchantments.REGISTRIES::bootstrap);
        builder.method_46777(class_7924.field_41239, TheGardenAwakensFeatures.REGISTRIES::bootstrap);
        builder.method_46777(class_7924.field_41239, SpringToLifeFeatures.REGISTRIES::bootstrap);
        builder.method_46777(class_7924.field_41239, ChaosCubedFeatures.REGISTRIES::bootstrap);
        builder.method_46777(class_7924.field_41239, WildernessBoundFeatures.REGISTRIES::bootstrap);
        builder.method_46777(class_7924.field_41245, TheGardenAwakensPlacements.REGISTRIES::bootstrap);
        builder.method_46777(class_7924.field_41245, SpringToLifePlacements.REGISTRIES::bootstrap);
        builder.method_46777(class_7924.field_41245, ChaosCubedPlacements.REGISTRIES::bootstrap);
        builder.method_46777(class_7924.field_41245, WildernessBoundPlacements.REGISTRIES::bootstrap);
        builder.method_46777(class_7924.field_41246, WildernessBoundStructures.REGISTRIES::bootstrap);
        builder.method_46777(class_7924.field_41248, WildernessBoundStructureSets.REGISTRIES::bootstrap);
        builder.method_46777(class_7924.field_41249, AbandonedCampStructurePools::bootstrap);
    }
}