package com.blackgear.vanillabackport.data.client;

import com.blackgear.vanillabackport.client.api.modules.waypoints.WaypointStyle;
import com.blackgear.vanillabackport.common.api.modules.waypoints.WaypointStyleAsset;
import com.blackgear.vanillabackport.common.api.modules.waypoints.WaypointStyleAssets;
import com.google.gson.JsonElement;
import com.mojang.serialization.Codec;
import com.mojang.serialization.JsonOps;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.minecraft.class_2405;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7403;
import net.minecraft.class_7784;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.function.BiConsumer;
import java.util.function.Function;

@Environment(EnvType.CLIENT)
public class WaypointStyleProvider implements class_2405 {
    private final class_7784.class_7489 pathProvider;
    
    public WaypointStyleProvider(FabricDataOutput output) {
        this.pathProvider = output.method_45973(class_7784.class_7490.field_39368, "waypoint_style");
    }
    
    private static void bootstrap(BiConsumer<class_5321<WaypointStyleAsset>, WaypointStyle> consumer) {
        consumer.accept(
            WaypointStyleAssets.DEFAULT,
            new WaypointStyle(
                128,
                332,
                List.of(
                    class_2960.method_60656("default_0"),
                    class_2960.method_60656("default_1"),
                    class_2960.method_60656("default_2"),
                    class_2960.method_60656("default_3")
                )
            )
        );
        consumer.accept(
            WaypointStyleAssets.BOWTIE,
            new WaypointStyle(
                64,
                332,
                List.of(
                    class_2960.method_60656("bowtie"),
                    class_2960.method_60656("default_0"),
                    class_2960.method_60656("default_1"),
                    class_2960.method_60656("default_2"),
                    class_2960.method_60656("default_3")
                )
            )
        );
        consumer.accept(
            WaypointStyleAssets.LODESTONE,
            new WaypointStyle(
                128,
                332,
                List.of(
                    class_2960.method_60656("lodestone_0"),
                    class_2960.method_60656("lodestone_1"),
                    class_2960.method_60656("lodestone_2")
                )
            )
        );
        consumer.accept(
            WaypointStyleAssets.DEATH,
            new WaypointStyle(
                128,
                332,
                List.of(
                    class_2960.method_60656("death_0"),
                    class_2960.method_60656("death_1"),
                    class_2960.method_60656("death_2")
                )
            )
        );
        consumer.accept(
            WaypointStyleAssets.NORTH,
            new WaypointStyle(
                128,
                332,
                List.of(
                    class_2960.method_60656("north")
                )
            )
        );
        consumer.accept(
            WaypointStyleAssets.SOUTH,
            new WaypointStyle(
                128,
                332,
                List.of(
                    class_2960.method_60656("south")
                )
            )
        );
        consumer.accept(
            WaypointStyleAssets.WEST,
            new WaypointStyle(
                128,
                332,
                List.of(
                    class_2960.method_60656("west")
                )
            )
        );
        consumer.accept(
            WaypointStyleAssets.EAST,
            new WaypointStyle(
                128,
                332,
                List.of(
                    class_2960.method_60656("east")
                )
            )
        );
        consumer.accept(
            WaypointStyleAssets.CORNER,
            new WaypointStyle(
                128,
                332,
                List.of(
                    class_2960.method_60656("corner")
                )
            )
        );
    }
    
    @Override
    public CompletableFuture<?> method_10319(class_7403 cache) {
        Map<class_5321<WaypointStyleAsset>, WaypointStyle> waypointStyles = new HashMap<>();
        bootstrap((id, asset) -> {
            if (waypointStyles.putIfAbsent(id, asset) != null) {
                throw new IllegalStateException("Tried to register waypoint style twice for id: " + id);
            }
        });
        
        return save(cache, WaypointStyle.CODEC, o -> this.pathProvider.method_44107(o.method_29177()), waypointStyles);
    }
    
    private static <T, E> CompletableFuture<?> save(class_7403 cache, Codec<E> codec, Function<T, Path> pathGetter, Map<T, E> contents) {
        return save(cache, e -> codec.encodeStart(JsonOps.INSTANCE, e).getOrThrow(), pathGetter, contents);
    }
    
    private static <T, E> CompletableFuture<?> save(class_7403 cache, Function<E, JsonElement> serializer, Function<T, Path> pathGetter, Map<T, E> contents) {
        return CompletableFuture.allOf(contents.entrySet().stream().map(entry -> {
            Path path = pathGetter.apply(entry.getKey());
            JsonElement json = serializer.apply(entry.getValue());
            return class_2405.method_10320(cache, json, path);
        }).toArray(CompletableFuture[]::new));
    }
    
    @Override
    public String method_10321() {
        return "Waypoint Style Definitions";
    }
}