package com.blackgear.vanillabackport.data.client;

import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import com.blackgear.vanillabackport.common.registries.items.ModItems;
import com.blackgear.vanillabackport.core.data.BlockFamilies;
import com.blackgear.vanillabackport.data.client.model.provider.VanillaBlockModels;
import com.blackgear.vanillabackport.data.client.model.provider.VanillaItemModels;
import com.blackgear.vanillabackport.data.client.model.provider.VanillaModelGenerator;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.minecraft.class_1738;
import net.minecraft.class_2246;
import net.minecraft.class_4910;
import net.minecraft.class_4946;
import net.minecraft.class_5794;

public class ModelGenerator extends VanillaModelGenerator {
    public ModelGenerator(FabricDataOutput output) {
        super(output);
    }

    @Override
    public void generateBlockStateModels(VanillaBlockModels gen) {
        BlockFamilies.getAllFamilies()
            .filter(class_5794::method_33477)
            .forEach(family -> gen.method_25650(family.method_33469()).method_33522(family));

        // The Garden Awakens
        gen.method_46190(ModBlocks.STRIPPED_PALE_OAK_LOG.get(), ModBlocks.PALE_OAK_HANGING_SIGN.getFirst().get(), ModBlocks.PALE_OAK_HANGING_SIGN.getSecond().get());
        gen.method_25641(ModBlocks.PALE_MOSS_BLOCK.get());
        gen.method_25622(ModBlocks.PALE_OAK_LEAVES.get(), class_4946.field_23049);
        gen.method_25676(ModBlocks.PALE_OAK_LOG.get())
            .method_25730(ModBlocks.PALE_OAK_LOG.get())
            .method_25728(ModBlocks.PALE_OAK_WOOD.get());
        gen.method_25676(ModBlocks.STRIPPED_PALE_OAK_LOG.get())
            .method_25730(ModBlocks.STRIPPED_PALE_OAK_LOG.get())
            .method_25728(ModBlocks.STRIPPED_PALE_OAK_WOOD.get());
        gen.method_25545(ModBlocks.PALE_OAK_SAPLING.get(), ModBlocks.POTTED_PALE_OAK_SAPLING.get(), class_4910.class_4913.field_22840);
        gen.method_25545(ModBlocks.OPEN_EYEBLOSSOM.get(), ModBlocks.POTTED_OPEN_EYEBLOSSOM.get(), class_4910.class_4913.field_22840);
        gen.method_25545(ModBlocks.CLOSED_EYEBLOSSOM.get(), ModBlocks.POTTED_CLOSED_EYEBLOSSOM.get(), class_4910.class_4913.field_22840);
        gen.createMossyCarpet(ModBlocks.PALE_MOSS_CARPET.get());
        gen.createHangingMoss(ModBlocks.PALE_HANGING_MOSS.get());
        gen.createCreakingHeart(ModBlocks.CREAKING_HEART.get());
        gen.createMultiface(ModBlocks.RESIN_CLUMP.get(), ModBlocks.RESIN_CLUMP.get().method_8389());
        gen.method_25641(ModBlocks.RESIN_BLOCK.get());
        gen.createSpawnEgg(ModItems.CREAKING_SPAWN_EGG.get());

        // Chase the Skies
        gen.createDriedGhastBlock();
        gen.createSpawnEgg(ModItems.HAPPY_GHAST_SPAWN_EGG.get());

        // Spring to Life
        gen.method_25548(ModBlocks.BUSH.get(), class_4910.class_4913.field_22839);
        gen.method_25603(ModBlocks.FIREFLY_BUSH.get(), class_4910.class_4913.field_22840);
        gen.method_25537(ModBlocks.FIREFLY_BUSH.get().method_8389());
        gen.createLeafLitter(ModBlocks.LEAF_LITTER.get());
        gen.method_49378(ModBlocks.WILDFLOWERS.get());
        gen.method_25548(ModBlocks.CACTUS_FLOWER.get(), class_4910.class_4913.field_22840);
        gen.method_25548(ModBlocks.SHORT_DRY_GRASS.get(), class_4910.class_4913.field_22840);
        gen.method_25548(ModBlocks.TALL_DRY_GRASS.get(), class_4910.class_4913.field_22840);

        // Chaos Cubed
        gen.method_25641(ModBlocks.POTENT_SULFUR.get());
        gen.createSpeleothem(ModBlocks.SULFUR_SPIKE.get());
        gen.createSpawnEgg(ModItems.SULFUR_CUBE_SPAWN_EGG.get());
        
        // Copper Age
        gen.createChest(ModBlocks.COPPER_CHEST.get(), class_2246.field_27119);
        gen.createChest(ModBlocks.EXPOSED_COPPER_CHEST.get(), class_2246.field_27118);
        gen.createChest(ModBlocks.WEATHERED_COPPER_CHEST.get(), class_2246.field_27117);
        gen.createChest(ModBlocks.OXIDIZED_COPPER_CHEST.get(), class_2246.field_27116);
        
        gen.createChest(ModBlocks.WAXED_COPPER_CHEST.get(), class_2246.field_27119);
        gen.createChest(ModBlocks.WAXED_EXPOSED_COPPER_CHEST.get(), class_2246.field_27118);
        gen.createChest(ModBlocks.WAXED_WEATHERED_COPPER_CHEST.get(), class_2246.field_27117);
        gen.createChest(ModBlocks.WAXED_OXIDIZED_COPPER_CHEST.get(), class_2246.field_27116);
        
        gen.createShelf(ModBlocks.ACACIA_SHELF.get(), class_2246.field_10622);
        gen.createShelf(ModBlocks.BAMBOO_SHELF.get(), class_2246.field_41073);
        gen.createShelf(ModBlocks.BIRCH_SHELF.get(), class_2246.field_10366);
        gen.createShelf(ModBlocks.CHERRY_SHELF.get(), class_2246.field_42732);
        gen.createShelf(ModBlocks.CRIMSON_SHELF.get(), class_2246.field_22119);
        gen.createShelf(ModBlocks.DARK_OAK_SHELF.get(), class_2246.field_10244);
        gen.createShelf(ModBlocks.JUNGLE_SHELF.get(), class_2246.field_10254);
        gen.createShelf(ModBlocks.MANGROVE_SHELF.get(), class_2246.field_37548);
        gen.createShelf(ModBlocks.OAK_SHELF.get(), class_2246.field_10519);
        gen.createShelf(ModBlocks.PALE_OAK_SHELF.get(), ModBlocks.STRIPPED_PALE_OAK_LOG.get());
        gen.createShelf(ModBlocks.SPRUCE_SHELF.get(), class_2246.field_10436);
        gen.createShelf(ModBlocks.WARPED_SHELF.get(), class_2246.field_22112);
        
        gen.createCopperGolemStatue(ModBlocks.COPPER_GOLEM_STATUE.get(), class_2246.field_27119);
        gen.createCopperGolemStatue(ModBlocks.EXPOSED_COPPER_GOLEM_STATUE.get(), class_2246.field_27118);
        gen.createCopperGolemStatue(ModBlocks.WEATHERED_COPPER_GOLEM_STATUE.get(), class_2246.field_27117);
        gen.createCopperGolemStatue(ModBlocks.OXIDIZED_COPPER_GOLEM_STATUE.get(), class_2246.field_27116);
        gen.createCopperGolemStatue(ModBlocks.WAXED_COPPER_GOLEM_STATUE.get(), class_2246.field_27119);
        gen.createCopperGolemStatue(ModBlocks.WAXED_EXPOSED_COPPER_GOLEM_STATUE.get(), class_2246.field_27118);
        gen.createCopperGolemStatue(ModBlocks.WAXED_WEATHERED_COPPER_GOLEM_STATUE.get(), class_2246.field_27117);
        gen.createCopperGolemStatue(ModBlocks.WAXED_OXIDIZED_COPPER_GOLEM_STATUE.get(), class_2246.field_27116);
        
        gen.createLightningRod(null, ModBlocks.WAXED_LIGHTNING_ROD.get());
        gen.createLightningRod(ModBlocks.EXPOSED_LIGHTNING_ROD.get(), ModBlocks.WAXED_EXPOSED_LIGHTNING_ROD.get());
        gen.createLightningRod(ModBlocks.WEATHERED_LIGHTNING_ROD.get(), ModBlocks.WAXED_WEATHERED_LIGHTNING_ROD.get());
        gen.createLightningRod(ModBlocks.OXIDIZED_LIGHTNING_ROD.get(), ModBlocks.WAXED_OXIDIZED_LIGHTNING_ROD.get());
        
        gen.method_25677(ModBlocks.COPPER_TORCH.getFirst().get(), ModBlocks.COPPER_TORCH.getSecond().get());
        
        ModBlocks.COPPER_LANTERN.waxedMapping().forEach((from, to) -> gen.createCopperLantern(from.get(), to.get()));
        ModBlocks.COPPER_BARS.waxedMapping().forEach((from, to) -> gen.createCopperBars(from.get(), to.get()));
        ModBlocks.COPPER_CHAIN.waxedMapping().forEach((from, to) -> gen.createCopperChain(from.get(), to.get()));
        
        gen.createSpawnEgg(ModItems.COPPER_GOLEM_SPAWN_EGG.get());
        
        gen.createSpawnEgg(ModItems.PARCHED_SPAWN_EGG.get());
        gen.createSpawnEgg(ModItems.CAMEL_HUSK_SPAWN_EGG.get());
        gen.createSpawnEgg(ModItems.NAUTILUS_SPAWN_EGG.get());
        gen.createSpawnEgg(ModItems.ZOMBIE_NAUTILUS_SPAWN_EGG.get());
        
        // Wilderness Bound
        gen.method_46190(ModBlocks.STRIPPED_POPLAR_LOG.get(), ModBlocks.POPLAR_HANGING_SIGN.getFirst().get(), ModBlocks.POPLAR_HANGING_SIGN.getSecond().get());
        gen.method_25622(ModBlocks.RED_POPLAR_LEAVES.get(), class_4946.field_23049);
        gen.method_25622(ModBlocks.ORANGE_POPLAR_LEAVES.get(), class_4946.field_23049);
        gen.method_25622(ModBlocks.YELLOW_POPLAR_LEAVES.get(), class_4946.field_23049);
        gen.method_25676(ModBlocks.POPLAR_LOG.get())
            .method_25730(ModBlocks.POPLAR_LOG.get())
            .method_25728(ModBlocks.POPLAR_WOOD.get());
        gen.method_25676(ModBlocks.STRIPPED_POPLAR_LOG.get())
            .method_25730(ModBlocks.STRIPPED_POPLAR_LOG.get())
            .method_25728(ModBlocks.STRIPPED_POPLAR_WOOD.get());
        gen.method_25545(ModBlocks.POPLAR_SAPLING.get(), ModBlocks.POTTED_POPLAR_SAPLING.get(), class_4910.class_4913.field_22840);
        gen.method_25548(ModBlocks.RED_SHRUB.get(), class_4910.class_4913.field_22839);
        gen.createShelfMushroom();
        gen.createShelf(ModBlocks.POPLAR_SHELF.get(), ModBlocks.STRIPPED_PALE_OAK_LOG.get());
        gen.createStrawBed();
    }

    @Override
    public void generateItemModels(VanillaItemModels gen) {
        // The Garden Awakens
        gen.createFlatItem(ModItems.RESIN_BRICK.get());
        gen.createFlatItem(ModItems.PALE_OAK_BOAT.get());
        gen.createFlatItem(ModItems.PALE_OAK_CHEST_BOAT.get());

        // Chase the Skies
        gen.createFlatItem(ModItems.WHITE_HARNESS.get());
        gen.createFlatItem(ModItems.ORANGE_HARNESS.get());
        gen.createFlatItem(ModItems.MAGENTA_HARNESS.get());
        gen.createFlatItem(ModItems.LIGHT_BLUE_HARNESS.get());
        gen.createFlatItem(ModItems.YELLOW_HARNESS.get());
        gen.createFlatItem(ModItems.LIME_HARNESS.get());
        gen.createFlatItem(ModItems.PINK_HARNESS.get());
        gen.createFlatItem(ModItems.GRAY_HARNESS.get());
        gen.createFlatItem(ModItems.LIGHT_GRAY_HARNESS.get());
        gen.createFlatItem(ModItems.CYAN_HARNESS.get());
        gen.createFlatItem(ModItems.PURPLE_HARNESS.get());
        gen.createFlatItem(ModItems.BLUE_HARNESS.get());
        gen.createFlatItem(ModItems.BROWN_HARNESS.get());
        gen.createFlatItem(ModItems.GREEN_HARNESS.get());
        gen.createFlatItem(ModItems.RED_HARNESS.get());
        gen.createFlatItem(ModItems.BLACK_HARNESS.get());
        gen.createMusicDisc(ModItems.MUSIC_DISC_TEARS.get());

        // Hot as Lava
        gen.createMusicDisc(ModItems.MUSIC_DISC_LAVA_CHICKEN.get());

        // Spring to Life
        gen.createFlatItem(ModItems.BLUE_EGG.get());
        gen.createFlatItem(ModItems.BROWN_EGG.get());
        
        // Copper Age
        gen.createFlatItem(ModItems.COPPER_NUGGET.get());
        gen.createHandheldItem(ModItems.COPPER_AXE.get());
        gen.createHandheldItem(ModItems.COPPER_HOE.get());
        gen.createHandheldItem(ModItems.COPPER_PICKAXE.get());
        gen.createHandheldItem(ModItems.COPPER_SHOVEL.get());
        gen.createHandheldItem(ModItems.COPPER_SWORD.get());
        gen.method_48523((class_1738) ModItems.COPPER_HELMET.get());
        gen.method_48523((class_1738) ModItems.COPPER_CHESTPLATE.get());
        gen.method_48523((class_1738) ModItems.COPPER_LEGGINGS.get());
        gen.method_48523((class_1738) ModItems.COPPER_BOOTS.get());
        gen.createFlatItem(ModItems.COPPER_HORSE_ARMOR.get());
        
        // Mounts of Mayhem
        gen.createFlatItem(ModItems.COPPER_NAUTILUS_ARMOR.get());
        gen.createFlatItem(ModItems.IRON_NAUTILUS_ARMOR.get());
        gen.createFlatItem(ModItems.GOLDEN_NAUTILUS_ARMOR.get());
        gen.createFlatItem(ModItems.DIAMOND_NAUTILUS_ARMOR.get());
        gen.createFlatItem(ModItems.NETHERITE_NAUTILUS_ARMOR.get());
        
        gen.createFlatItem(ModItems.NETHERITE_HORSE_ARMOR.get());
        
        gen.createHandheldItem(ModItems.WOODEN_SPEAR.get());
        gen.createHandheldItem(ModItems.STONE_SPEAR.get());
        gen.createHandheldItem(ModItems.COPPER_SPEAR.get());
        gen.createHandheldItem(ModItems.IRON_SPEAR.get());
        gen.createHandheldItem(ModItems.GOLDEN_SPEAR.get());
        gen.createHandheldItem(ModItems.DIAMOND_SPEAR.get());
        gen.createHandheldItem(ModItems.NETHERITE_SPEAR.get());
        
        // Chaos Cubed
        gen.createFlatItem(ModItems.SULFUR_CUBE_BUCKET.get());
        gen.createMusicDisc(ModItems.MUSIC_DISC_BOUNCE.get());
        
        // Wilderness Bound
        gen.createFlatItem(ModItems.POPLAR_BOAT.get());
        gen.createFlatItem(ModItems.POPLAR_CHEST_BOAT.get());
        gen.createFlatItem(ModItems.WHITE_CUSHION.get());
        gen.createFlatItem(ModItems.ORANGE_CUSHION.get());
        gen.createFlatItem(ModItems.MAGENTA_CUSHION.get());
        gen.createFlatItem(ModItems.LIGHT_BLUE_CUSHION.get());
        gen.createFlatItem(ModItems.YELLOW_CUSHION.get());
        gen.createFlatItem(ModItems.LIME_CUSHION.get());
        gen.createFlatItem(ModItems.PINK_CUSHION.get());
        gen.createFlatItem(ModItems.GRAY_CUSHION.get());
        gen.createFlatItem(ModItems.LIGHT_GRAY_CUSHION.get());
        gen.createFlatItem(ModItems.CYAN_CUSHION.get());
        gen.createFlatItem(ModItems.PURPLE_CUSHION.get());
        gen.createFlatItem(ModItems.BLUE_CUSHION.get());
        gen.createFlatItem(ModItems.BROWN_CUSHION.get());
        gen.createFlatItem(ModItems.GREEN_CUSHION.get());
        gen.createFlatItem(ModItems.RED_CUSHION.get());
        gen.createFlatItem(ModItems.BLACK_CUSHION.get());
    }
}