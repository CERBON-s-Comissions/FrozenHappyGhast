package com.blackgear.vanillabackport.data.client.model;

import net.minecraft.class_4944;
import net.minecraft.class_4946;

public class ModTexturedModels {
    public static final class_4946.class_4947 MOSSY_CARPET_SIDE = class_4946.method_25918(ModTextureMappings::side, ModModelTemplates.MOSSY_CARPET_SIDE);
    public static final class_4946.class_4947 LEAF_LITTER_1 = class_4946.method_25918(class_4944::method_25872, ModModelTemplates.LEAF_LITTER_1);
    public static final class_4946.class_4947 LEAF_LITTER_2 = class_4946.method_25918(class_4944::method_25872, ModModelTemplates.LEAF_LITTER_2);
    public static final class_4946.class_4947 LEAF_LITTER_3 = class_4946.method_25918(class_4944::method_25872, ModModelTemplates.LEAF_LITTER_3);
    public static final class_4946.class_4947 LEAF_LITTER_4 = class_4946.method_25918(class_4944::method_25872, ModModelTemplates.LEAF_LITTER_4);
    public static final class_4946.class_4947 CHAIN = class_4946.method_25918(class_4944::method_25872, ModModelTemplates.CHAIN);
}