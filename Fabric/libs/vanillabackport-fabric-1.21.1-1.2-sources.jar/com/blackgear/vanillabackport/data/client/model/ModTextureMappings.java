package com.blackgear.vanillabackport.data.client.model;

import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import net.minecraft.class_2248;
import net.minecraft.class_4944;
import net.minecraft.class_4945;

public class ModTextureMappings {
    public static class_4944 side(class_2248 block) {
        return class_4944.method_25883(class_4945.field_23018, class_4944.method_25860(block));
    }

    public static class_4944 driedGhast(String string) {
        return new class_4944()
            .method_25868(class_4945.field_23012, class_4944.method_25866(ModBlocks.DRIED_GHAST.get(), string + "_north"))
            .method_25868(class_4945.field_23014, class_4944.method_25866(ModBlocks.DRIED_GHAST.get(), string + "_bottom"))
            .method_25868(class_4945.field_23015, class_4944.method_25866(ModBlocks.DRIED_GHAST.get(), string + "_top"))
            .method_25868(class_4945.field_23019, class_4944.method_25866(ModBlocks.DRIED_GHAST.get(), string + "_north"))
            .method_25868(class_4945.field_23020, class_4944.method_25866(ModBlocks.DRIED_GHAST.get(), string + "_south"))
            .method_25868(class_4945.field_23021, class_4944.method_25866(ModBlocks.DRIED_GHAST.get(), string + "_west"))
            .method_25868(class_4945.field_23022, class_4944.method_25866(ModBlocks.DRIED_GHAST.get(), string + "_east"))
            .method_25868(ModTextureSlots.TENTACLES, class_4944.method_25866(ModBlocks.DRIED_GHAST.get(), string + "_tentacles"));
    }
    
    public static class_4944 bars(class_2248 block) {
        return new class_4944()
            .method_25868(ModTextureSlots.BARS, class_4944.method_25860(block))
            .method_25868(class_4945.field_23032, class_4944.method_25860(block));
    }
}
