package com.blackgear.vanillabackport.data.client.model.provider;

import com.blackgear.vanillabackport.common.level.blocks.CreakingHeartBlock;
import com.blackgear.vanillabackport.common.level.blocks.DriedGhastBlock;
import com.blackgear.vanillabackport.common.level.blocks.HangingMossBlock;
import com.blackgear.vanillabackport.common.level.blocks.MossyCarpetBlock;
import com.blackgear.vanillabackport.common.level.blocks.CreakingHeartState;
import com.blackgear.vanillabackport.common.level.blocks.SideChainPart;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlockStateProperties;
import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import com.blackgear.vanillabackport.data.client.model.ModModelTemplates;
import com.blackgear.vanillabackport.data.client.model.ModTextureMappings;
import com.blackgear.vanillabackport.data.client.model.ModTexturedModels;
import com.google.gson.JsonElement;
import com.mojang.datafixers.util.Pair;
import net.minecraft.class_156;
import net.minecraft.class_1792;
import net.minecraft.class_1935;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2741;
import net.minecraft.class_2742;
import net.minecraft.class_2746;
import net.minecraft.class_2754;
import net.minecraft.class_2960;
import net.minecraft.class_4778;
import net.minecraft.class_4910;
import net.minecraft.class_4917;
import net.minecraft.class_4918;
import net.minecraft.class_4922;
import net.minecraft.class_4925;
import net.minecraft.class_4926;
import net.minecraft.class_4935;
import net.minecraft.class_4936;
import net.minecraft.class_4941;
import net.minecraft.class_4942;
import net.minecraft.class_4943;
import net.minecraft.class_4944;
import net.minecraft.class_4945;
import net.minecraft.class_4946;
import net.minecraft.class_5691;
import net.minecraft.data.models.blockstates.*;
import net.minecraft.data.models.model.*;
import net.minecraft.world.level.block.state.properties.*;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

public class VanillaBlockModels extends class_4910 {
    private static final class_2960 TEMPLATE_SPAWN_EGG = class_4941.method_25845("template_spawn_egg");
    private static final List<Pair<class_2350, Function<class_2960, class_4935>>> MULTIFACE_GENERATOR = List.of(
        Pair.of(class_2350.field_11043, path -> class_4935.method_25824().method_25828(class_4936.field_22887, path)),
        Pair.of(class_2350.field_11034, path -> class_4935.method_25824()
            .method_25828(class_4936.field_22887, path)
            .method_25828(class_4936.field_22886, class_4936.class_4937.field_22891)
            .method_25828(class_4936.field_22888, true)),
        Pair.of(class_2350.field_11035, path -> class_4935.method_25824()
            .method_25828(class_4936.field_22887, path)
            .method_25828(class_4936.field_22886, class_4936.class_4937.field_22892)
            .method_25828(class_4936.field_22888, true)),
        Pair.of(class_2350.field_11039, path -> class_4935.method_25824()
            .method_25828(class_4936.field_22887, path)
            .method_25828(class_4936.field_22886, class_4936.class_4937.field_22893)
            .method_25828(class_4936.field_22888, true)),
        Pair.of(class_2350.field_11036, path -> class_4935.method_25824()
            .method_25828(class_4936.field_22887, path)
            .method_25828(class_4936.field_22885, class_4936.class_4937.field_22893)
            .method_25828(class_4936.field_22888, true)),
        Pair.of(class_2350.field_11033, path -> class_4935.method_25824()
            .method_25828(class_4936.field_22887, path)
            .method_25828(class_4936.field_22885, class_4936.class_4937.field_22891)
            .method_25828(class_4936.field_22888, true))
    );

    public VanillaBlockModels(Consumer<class_4917> blockStateOutput, BiConsumer<class_2960, Supplier<JsonElement>> modelOutput, Consumer<class_1792> skippedAutoModelsOutput) {
        super(blockStateOutput, modelOutput, skippedAutoModelsOutput);
    }

    public void createSpawnEgg(class_1935 item) {
        this.method_25538(item.method_8389(), TEMPLATE_SPAWN_EGG);
    }

    public void createMossyCarpet(class_2248 block) {
        class_2960 baseModel = class_4946.field_23044.method_25923(block, this.field_22831);
        class_2960 tallSideModel = ModTexturedModels.MOSSY_CARPET_SIDE
            .get(block)
            .method_25917(mapping -> mapping.method_25868(class_4945.field_23018, class_4944.method_25866(block, "_side_tall")))
            .method_25915(block, "_side_tall", this.field_22831);
        class_2960 shortSideModel = ModTexturedModels.MOSSY_CARPET_SIDE
            .get(block)
            .method_25917(mapping -> mapping.method_25868(class_4945.field_23018, class_4944.method_25866(block, "_side_small")))
            .method_25915(block, "_side_small", this.field_22831);

        class_4922 generator = class_4922.method_25758(block);
        class_4918.class_4921 terminal = class_4918.method_25744().method_25751(MossyCarpetBlock.BASE, false);
        generator.method_25760(class_4918.method_25744().method_25751(MossyCarpetBlock.BASE, true), class_4935.method_25824().method_25828(class_4936.field_22887, baseModel));
        generator.method_25760(terminal, class_4935.method_25824().method_25828(class_4936.field_22887, baseModel));

        field_28548.stream().map(Pair::getFirst).forEach(direction -> {
            class_2754<class_4778> property = MossyCarpetBlock.getPropertyForFace(direction);
            if (property != null && block.method_9564().method_28498(property)) {
                terminal.method_25751(property, class_4778.field_22178);
            }
        });

        for (Pair<class_2350, Function<class_2960, class_4935>> pair : field_28548) {
            class_2350 direction = pair.getFirst();
            class_2754<class_4778> property = MossyCarpetBlock.getPropertyForFace(direction);

            if (property != null) {
                Function<class_2960, class_4935> function = pair.getSecond();
                generator.method_25760(class_4918.method_25744().method_25751(property, class_4778.field_22180), function.apply(tallSideModel));
                generator.method_25760(class_4918.method_25744().method_25751(property, class_4778.field_22179), function.apply(shortSideModel));
                generator.method_25760(terminal, function.apply(tallSideModel));
            }
        }

        this.field_22830.accept(generator);
    }

    public void createHangingMoss(class_2248 block) {
        class_4926 dispatch = class_4926.method_25783(HangingMossBlock.TIP).method_25795(value -> {
            String suffix = value ? "_tip" : "";
            class_4944 textureMapping = class_4944.method_25880(class_4944.method_25866(block, suffix));
            class_2960 path = class_4913.field_22840.method_25726().method_25847(block, suffix, textureMapping, this.field_22831);
            return class_4935.method_25824().method_25828(class_4936.field_22887, path);
        });

        this.method_25600(block);
        this.field_22830.accept(class_4925.method_25769(block).method_25775(dispatch));
    }

    public void createCreakingHeart(class_2248 block) {
        class_2960 base = class_4946.field_23055.method_25923(block, this.field_22831);
        class_2960 baseSide = class_4946.field_23056.method_25923(block, this.field_22831);
        class_2960 awake = this.createCreakingHeartModel(class_4946.field_23055, block, "_awake");
        class_2960 awakeSide = this.createCreakingHeartModel(class_4946.field_23056, block, "_awake");
        class_2960 dormant = this.createCreakingHeartModel(class_4946.field_23055, block, "_dormant");
        class_2960 dormantSide = this.createCreakingHeartModel(class_4946.field_23056, block, "_dormant");

        class_4926 state = class_4926.method_25784(class_2741.field_12496, CreakingHeartBlock.STATE)
            .method_25797(class_2350.class_2351.field_11052, CreakingHeartState.UPROOTED, createVariant(base, class_4936.class_4937.field_22890, class_4936.class_4937.field_22890))
            .method_25797(class_2350.class_2351.field_11051, CreakingHeartState.UPROOTED, createVariant(baseSide, class_4936.class_4937.field_22891, class_4936.class_4937.field_22890))
            .method_25797(class_2350.class_2351.field_11048, CreakingHeartState.UPROOTED, createVariant(baseSide, class_4936.class_4937.field_22891, class_4936.class_4937.field_22891))
            .method_25797(class_2350.class_2351.field_11052, CreakingHeartState.DORMANT, createVariant(dormant, class_4936.class_4937.field_22890, class_4936.class_4937.field_22890))
            .method_25797(class_2350.class_2351.field_11051, CreakingHeartState.DORMANT, createVariant(dormantSide, class_4936.class_4937.field_22891, class_4936.class_4937.field_22890))
            .method_25797(class_2350.class_2351.field_11048, CreakingHeartState.DORMANT, createVariant(dormantSide, class_4936.class_4937.field_22891, class_4936.class_4937.field_22891))
            .method_25797(class_2350.class_2351.field_11052, CreakingHeartState.AWAKE, createVariant(awake, class_4936.class_4937.field_22890, class_4936.class_4937.field_22890))
            .method_25797(class_2350.class_2351.field_11051, CreakingHeartState.AWAKE, createVariant(awakeSide, class_4936.class_4937.field_22891, class_4936.class_4937.field_22890))
            .method_25797(class_2350.class_2351.field_11048, CreakingHeartState.AWAKE, createVariant(awakeSide, class_4936.class_4937.field_22891, class_4936.class_4937.field_22891));

        this.field_22830.accept(class_4925.method_25769(block).method_25775(state));
    }

    private class_4935 createVariant(class_2960 model, class_4936.class_4937 xRot, class_4936.class_4937 yRot) {
        class_4935 variant = class_4935.method_25824().method_25828(class_4936.field_22887, model);

        if (xRot != class_4936.class_4937.field_22890) variant = variant.method_25828(class_4936.field_22885, xRot);
        if (yRot != class_4936.class_4937.field_22890) variant = variant.method_25828(class_4936.field_22886, yRot);

        return variant;
    }

    private class_2960 createCreakingHeartModel(class_4946.class_4947 provider, class_2248 block, String suffix) {
        return provider.method_35912(mapping -> mapping
            .method_25868(class_4945.field_23018, class_4944.method_25866(block, suffix))
            .method_25868(class_4945.field_23013, class_4944.method_25866(block, "_top" + suffix))
        ).method_25922(block, suffix, this.field_22831);
    }

    public void createMultiface(class_2248 block, class_1792 item) {
        this.method_25537(item);
        class_2960 model = class_4941.method_25842(block);
        class_4922 generator = class_4922.method_25758(block);

        class_4918.class_4921 terminalCondition = class_156.method_654(
            class_4918.method_25744(),
            condition -> class_4910.field_28548.stream()
                .map(Pair::getFirst)
                .forEach((facingDirection) -> {
                    if (block.method_9564().method_28498(facingDirection)) {
                        condition.method_25751(facingDirection, false);
                    }
                })
        );

        for(Pair<class_2746, Function<class_2960, class_4935>> pair : class_4910.field_28548) {
            class_2746 booleanProperty = pair.getFirst();
            Function<class_2960, class_4935> function = pair.getSecond();
            if (block.method_9564().method_28498(booleanProperty)) {
                generator.method_25760(class_4918.method_25744().method_25751(booleanProperty, true), function.apply(model));
                generator.method_25760(terminalCondition, function.apply(model));
            }
        }

        this.field_22830.accept(generator);
    }

    public void createDriedGhastBlock() {
        class_2960 model = class_4941.method_25843(ModBlocks.DRIED_GHAST.get(), "_hydration_0");
        this.method_25623(ModBlocks.DRIED_GHAST.get(), model);
        Function<Integer, class_2960> hydrationModel = level -> {
            String suffix = switch (level) {
                case 1 -> "_hydration_1";
                case 2 -> "_hydration_2";
                case 3 -> "_hydration_3";
                default -> "_hydration_0";
            };
            class_4944 mapping = ModTextureMappings.driedGhast(suffix);
            return ModModelTemplates.DRIED_GHAST.method_25847(ModBlocks.DRIED_GHAST.get(), suffix, mapping, this.field_22831);
        };

        this.field_22830
            .accept(
                class_4925.method_25769(ModBlocks.DRIED_GHAST.get())
                    .method_25775(class_4926.method_25783(DriedGhastBlock.HYDRATION_LEVEL).method_25795(level -> class_4935.method_25824().method_25828(class_4936.field_22887, hydrationModel.apply(level))))
                    .method_25775(class_4910.method_25599())
            );
    }

    public void createLeafLitter(class_2248 block) {
        class_2960 resourceLocation = ModTexturedModels.LEAF_LITTER_1.method_25923(block, this.field_22831);
        class_2960 resourceLocation2 = ModTexturedModels.LEAF_LITTER_2.method_25923(block, this.field_22831);
        class_2960 resourceLocation3 = ModTexturedModels.LEAF_LITTER_3.method_25923(block, this.field_22831);
        class_2960 resourceLocation4 = ModTexturedModels.LEAF_LITTER_4.method_25923(block, this.field_22831);
        this.method_25537(block.method_8389());
        this.field_22830.accept(
            class_4922.method_25758(block)
                .method_25760(
                    class_4918.method_25744()
                        .method_25751(ModBlockStateProperties.SEGMENT_AMOUNT, 1)
                        .method_25751(class_2741.field_12481, class_2350.field_11043),
                    class_4935.method_25824()
                        .method_25828(class_4936.field_22887, resourceLocation)
                ).method_25760(
                    class_4918.method_25744()
                        .method_25751(ModBlockStateProperties.SEGMENT_AMOUNT, 1)
                        .method_25751(class_2741.field_12481, class_2350.field_11034),
                    class_4935.method_25824()
                        .method_25828(class_4936.field_22887, resourceLocation)
                        .method_25828(class_4936.field_22886, class_4936.class_4937.field_22891)
                ).method_25760(
                    class_4918.method_25744()
                        .method_25751(ModBlockStateProperties.SEGMENT_AMOUNT, 1)
                        .method_25751(class_2741.field_12481, class_2350.field_11035),
                    class_4935.method_25824()
                        .method_25828(class_4936.field_22887, resourceLocation)
                        .method_25828(class_4936.field_22886, class_4936.class_4937.field_22892)
                ).method_25760(
                    class_4918.method_25744()
                        .method_25751(ModBlockStateProperties.SEGMENT_AMOUNT, 1)
                        .method_25751(class_2741.field_12481, class_2350.field_11039),
                    class_4935.method_25824()
                        .method_25828(class_4936.field_22887, resourceLocation)
                        .method_25828(class_4936.field_22886, class_4936.class_4937.field_22893)
                ).method_25760(
                    class_4918.method_25744()
                        .method_25752(ModBlockStateProperties.SEGMENT_AMOUNT, 2, 3)
                        .method_25751(class_2741.field_12481, class_2350.field_11043),
                    class_4935.method_25824()
                        .method_25828(class_4936.field_22887, resourceLocation2)
                ).method_25760(
                    class_4918.method_25744()
                        .method_25752(ModBlockStateProperties.SEGMENT_AMOUNT, 2, 3)
                        .method_25751(class_2741.field_12481, class_2350.field_11034),
                    class_4935.method_25824()
                        .method_25828(class_4936.field_22887, resourceLocation2)
                        .method_25828(class_4936.field_22886, class_4936.class_4937.field_22891)
                ).method_25760(
                    class_4918.method_25744()
                        .method_25752(ModBlockStateProperties.SEGMENT_AMOUNT, 2, 3)
                        .method_25751(class_2741.field_12481, class_2350.field_11035),
                    class_4935.method_25824()
                        .method_25828(class_4936.field_22887, resourceLocation2)
                        .method_25828(class_4936.field_22886, class_4936.class_4937.field_22892)
                ).method_25760(
                    class_4918.method_25744()
                        .method_25752(ModBlockStateProperties.SEGMENT_AMOUNT, 2, 3)
                        .method_25751(class_2741.field_12481, class_2350.field_11039),
                    class_4935.method_25824()
                        .method_25828(class_4936.field_22887, resourceLocation2)
                        .method_25828(class_4936.field_22886, class_4936.class_4937.field_22893)
                ).method_25760(
                    class_4918.method_25744()
                        .method_25751(ModBlockStateProperties.SEGMENT_AMOUNT, 3)
                        .method_25751(class_2741.field_12481, class_2350.field_11043),
                    class_4935.method_25824()
                        .method_25828(class_4936.field_22887, resourceLocation3)
                ).method_25760(
                    class_4918.method_25744()
                        .method_25751(ModBlockStateProperties.SEGMENT_AMOUNT, 3)
                        .method_25751(class_2741.field_12481, class_2350.field_11034),
                    class_4935.method_25824()
                        .method_25828(class_4936.field_22887, resourceLocation3)
                        .method_25828(class_4936.field_22886, class_4936.class_4937.field_22891)
                ).method_25760(
                    class_4918.method_25744()
                        .method_25751(ModBlockStateProperties.SEGMENT_AMOUNT, 3)
                        .method_25751(class_2741.field_12481, class_2350.field_11035),
                    class_4935.method_25824()
                        .method_25828(class_4936.field_22887, resourceLocation3)
                        .method_25828(class_4936.field_22886, class_4936.class_4937.field_22892)
                ).method_25760(
                    class_4918.method_25744()
                        .method_25751(ModBlockStateProperties.SEGMENT_AMOUNT, 3)
                        .method_25751(class_2741.field_12481, class_2350.field_11039),
                    class_4935.method_25824()
                        .method_25828(class_4936.field_22887, resourceLocation3)
                        .method_25828(class_4936.field_22886, class_4936.class_4937.field_22893)
                ).method_25760(
                    class_4918.method_25744()
                        .method_25751(ModBlockStateProperties.SEGMENT_AMOUNT, 4)
                        .method_25751(class_2741.field_12481, class_2350.field_11043),
                    class_4935.method_25824()
                        .method_25828(class_4936.field_22887, resourceLocation4)
                ).method_25760(
                    class_4918.method_25744()
                        .method_25751(ModBlockStateProperties.SEGMENT_AMOUNT, 4)
                        .method_25751(class_2741.field_12481, class_2350.field_11034),
                    class_4935.method_25824()
                        .method_25828(class_4936.field_22887, resourceLocation4)
                        .method_25828(class_4936.field_22886, class_4936.class_4937.field_22891)
                ).method_25760(
                    class_4918.method_25744()
                        .method_25751(ModBlockStateProperties.SEGMENT_AMOUNT, 4)
                        .method_25751(class_2741.field_12481, class_2350.field_11035),
                    class_4935.method_25824()
                        .method_25828(class_4936.field_22887, resourceLocation4)
                        .method_25828(class_4936.field_22886, class_4936.class_4937.field_22892)
                ).method_25760(
                    class_4918.method_25744()
                        .method_25751(ModBlockStateProperties.SEGMENT_AMOUNT, 4)
                        .method_25751(class_2741.field_12481, class_2350.field_11039),
                    class_4935.method_25824()
                        .method_25828(class_4936.field_22887, resourceLocation4)
                        .method_25828(class_4936.field_22886, class_4936.class_4937.field_22893)
                )
        );
    }

    public void createSpeleothem(class_2248 block) {
        this.method_25540(block);
        class_4926.class_4928<class_2350, class_5691> generator = class_4926.method_25784(class_2741.field_28062, class_2741.field_28063);

        for (class_5691 thickness : class_5691.values()) {
            generator.method_25797(class_2350.field_11036, thickness, this.createSpeleothemVariant(class_2350.field_11036, thickness, block));
        }

        for (class_5691 thickness : class_5691.values()) {
            generator.method_25797(class_2350.field_11033, thickness, this.createSpeleothemVariant(class_2350.field_11033, thickness, block));
        }

        this.field_22830.accept(class_4925.method_25769(block).method_25775(generator));
    }

    private class_4935 createSpeleothemVariant(class_2350 direction, class_5691 thickness, class_2248 block) {
        String suffix = "_" + direction.method_15434() + "_" + thickness.method_15434();
        class_4944 texture = class_4944.method_25880(class_4944.method_25866(block, suffix));
        return class_4935.method_25824().method_25828(class_4936.field_22887, class_4943.field_28080.method_25847(block, suffix, texture, this.field_22831));
    }
    
    public void createChest(class_2248 chest, class_2248 particles) {
        class_4911 generator = new class_4911(class_4941.method_25842(chest), particles);
        generator.method_25715(chest);
        
        ModModelTemplates.CHEST.method_25852(class_4941.method_25840(chest.method_8389()), class_4944.method_25901(particles), this.field_22831);
    }
    
    public void createCopperGolemStatue(class_2248 block, class_2248 particle) {
        class_4911 generator = new class_4911(class_4941.method_25842(block), particle);
        generator.method_25715(block);
        
        ModModelTemplates.COPPER_GOLEM_STATUE.method_25852(class_4941.method_25840(block.method_8389()), class_4944.method_25901(particle), this.field_22831);
    }
    
    public void createCopperChain(class_2248 unwaxed, class_2248 waxed) {
        class_2960 block = ModTexturedModels.CHAIN.method_25923(unwaxed, this.field_22831);
        this.method_31063(unwaxed, block);
        this.method_31063(waxed, block);
        class_2960 item = class_4943.field_22938.method_25852(class_4941.method_25840(unwaxed.method_8389()), class_4944.method_25871(unwaxed.method_8389()), this.field_22831);
        this.method_25538(waxed.method_8389(), item);
    }
    
    public void createCopperBars(class_2248 unwaxed, class_2248 waxed) {
        class_4944 textures = ModTextureMappings.bars(unwaxed);
        class_2960 postEndResource = ModModelTemplates.BARS_POST_ENDS.method_25846(unwaxed, textures, this.field_22831);
        class_2960 postResource = ModModelTemplates.BARS_POST.method_25846(unwaxed, textures, this.field_22831);
        class_2960 capResource = ModModelTemplates.BARS_CAP.method_25846(unwaxed, textures, this.field_22831);
        class_2960 capAltResource = ModModelTemplates.BARS_CAP_ALT.method_25846(unwaxed, textures, this.field_22831);
        class_2960 sideResource = ModModelTemplates.BARS_POST_SIDE.method_25846(unwaxed, textures, this.field_22831);
        class_2960 sideAltResource = ModModelTemplates.BARS_POST_SIDE_ALT.method_25846(unwaxed, textures, this.field_22831);
        this.createBars(unwaxed, postEndResource, postResource, capResource, capAltResource, sideResource, sideAltResource);
        this.createBars(waxed, postEndResource, postResource, capResource, capAltResource, sideResource, sideAltResource);
        this.method_25600(unwaxed);
        this.method_25623(waxed, class_4941.method_25840(unwaxed.method_8389()));
    }
    
    private void createBars(class_2248 block, class_2960 postEnd, class_2960 post, class_2960 cap, class_2960 capAlt, class_2960 side, class_2960 sideAlt) {
        this.field_22830
            .accept(
                class_4922.method_25758(block)
                    .method_25763(class_4935.method_25824().method_25828(class_4936.field_22887, postEnd))
                    .method_25760(
                        class_4918.method_25744()
                            .method_25751(class_2741.field_12489, false)
                            .method_25751(class_2741.field_12487, false)
                            .method_25751(class_2741.field_12540, false)
                            .method_25751(class_2741.field_12527, false),
                        class_4935.method_25824().method_25828(class_4936.field_22887, post)
                    )
                    .method_25760(
                        class_4918.method_25744()
                            .method_25751(class_2741.field_12489, true)
                            .method_25751(class_2741.field_12487, false)
                            .method_25751(class_2741.field_12540, false)
                            .method_25751(class_2741.field_12527, false),
                        class_4935.method_25824().method_25828(class_4936.field_22887, cap)
                    )
                    .method_25760(
                        class_4918.method_25744()
                            .method_25751(class_2741.field_12489, false)
                            .method_25751(class_2741.field_12487, true)
                            .method_25751(class_2741.field_12540, false)
                            .method_25751(class_2741.field_12527, false),
                        class_4935.method_25824().method_25828(class_4936.field_22887, cap).method_25828(class_4936.field_22886, class_4936.class_4937.field_22891)
                    )
                    .method_25760(
                        class_4918.method_25744()
                            .method_25751(class_2741.field_12489, false)
                            .method_25751(class_2741.field_12487, false)
                            .method_25751(class_2741.field_12540, true)
                            .method_25751(class_2741.field_12527, false),
                        class_4935.method_25824().method_25828(class_4936.field_22887, capAlt)
                    )
                    .method_25760(
                        class_4918.method_25744()
                            .method_25751(class_2741.field_12489, false)
                            .method_25751(class_2741.field_12487, false)
                            .method_25751(class_2741.field_12540, false)
                            .method_25751(class_2741.field_12527, true),
                        class_4935.method_25824().method_25828(class_4936.field_22887, capAlt).method_25828(class_4936.field_22886, class_4936.class_4937.field_22891)
                    )
                    .method_25760(
                        class_4918.method_25744().method_25751(class_2741.field_12489, true),
                        class_4935.method_25824().method_25828(class_4936.field_22887, side)
                    )
                    .method_25760(
                        class_4918.method_25744().method_25751(class_2741.field_12487, true),
                        class_4935.method_25824().method_25828(class_4936.field_22887, side).method_25828(class_4936.field_22886, class_4936.class_4937.field_22891)
                    )
                    .method_25760(
                        class_4918.method_25744().method_25751(class_2741.field_12540, true),
                        class_4935.method_25824().method_25828(class_4936.field_22887, sideAlt)
                    )
                    .method_25760(
                        class_4918.method_25744().method_25751(class_2741.field_12527, true),
                        class_4935.method_25824().method_25828(class_4936.field_22887, sideAlt).method_25828(class_4936.field_22886, class_4936.class_4937.field_22891)
                    )
            );
    }
    
    public void createLightningRod(class_2248 unwaxed, class_2248 waxed) {
        if (unwaxed == null) {
            class_2960 on = class_4941.method_25843(class_2246.field_27171, "_on");
            class_2960 off = class_4941.method_25842(class_2246.field_27171);
            this.field_22830.accept(class_4925.method_25770(waxed, class_4935.method_25824().method_25828(class_4936.field_22887, class_4941.method_25842(waxed))).method_25775(this.method_25675()).method_25775(method_25565(class_2741.field_12484, on, off)));
            this.method_25623(waxed, class_4941.method_25840(class_2246.field_27171.method_8389()));
        } else {
            class_2960 on = class_4941.method_25843(class_2246.field_27171, "_on");
            class_2960 off = ModModelTemplates.LIGHTNING_ROD.method_25846(unwaxed, class_4944.method_25872(unwaxed), this.field_22831);
            this.field_22830.accept(class_4925.method_25770(unwaxed, class_4935.method_25824().method_25828(class_4936.field_22887, class_4941.method_25842(unwaxed))).method_25775(this.method_25675()).method_25775(method_25565(class_2741.field_12484, on, off)));
            this.field_22830.accept(class_4925.method_25770(waxed, class_4935.method_25824().method_25828(class_4936.field_22887, class_4941.method_25842(waxed))).method_25775(this.method_25675()).method_25775(method_25565(class_2741.field_12484, on, off)));
            this.method_25623(waxed, class_4941.method_25840(unwaxed.method_8389()));
        }
    }
    
    public void createCopperLantern(class_2248 unwaxed, class_2248 waxed) {
        class_2960 ground = class_4946.field_23050.method_25923(unwaxed, this.field_22831);
        class_2960 hanging = class_4946.field_23051.method_25923(unwaxed, this.field_22831);
        this.method_25537(unwaxed.method_8389());
        this.method_25623(waxed, class_4941.method_25840(unwaxed.method_8389()));
        this.field_22830.accept(class_4925.method_25769(unwaxed).method_25775(method_25565(class_2741.field_16561, hanging, ground)));
        this.field_22830.accept(class_4925.method_25769(waxed).method_25775(method_25565(class_2741.field_16561, hanging, ground)));
    }
    
    public final void createShelf(final class_2248 block, final class_2248 particle) {
        class_4944 mapping = new class_4944()
            .method_25868(class_4945.field_23010, class_4944.method_25860(block))
            .method_25868(class_4945.field_23012, class_4944.method_25860(particle));
        class_4922 generator = class_4922.method_25758(block);
        this.addShelfPart(block, mapping, generator, ModModelTemplates.SHELF_BODY, null, null);
        this.addShelfPart(block, mapping, generator, ModModelTemplates.SHELF_UNPOWERED, false, null);
        this.addShelfPart(block, mapping, generator, ModModelTemplates.SHELF_UNCONNECTED, true, SideChainPart.UNCONNECTED);
        this.addShelfPart(block, mapping, generator, ModModelTemplates.SHELF_LEFT, true, SideChainPart.LEFT);
        this.addShelfPart(block, mapping, generator, ModModelTemplates.SHELF_CENTER, true, SideChainPart.CENTER);
        this.addShelfPart(block, mapping, generator, ModModelTemplates.SHELF_RIGHT, true, SideChainPart.RIGHT);
        this.field_22830.accept(generator);
        this.method_25623(block, ModModelTemplates.SHELF_INVENTORY.method_25846(block, mapping, this.field_22831));
    }
    
    public final void addShelfPart(
        final class_2248 block,
        final class_4944 mapping,
        final class_4922 generator,
        final class_4942 template,
        @Nullable final Boolean isPowered,
        @Nullable final SideChainPart sideChainPart
    ) {
        class_2960 modelLocation = template.method_25846(block, mapping, this.field_22831);
        forEachHorizontalDirection((direction, rotation) -> {
            class_4935 variant = class_4935.method_25824()
                .method_25828(class_4936.field_22887, modelLocation)
                .method_25828(class_4936.field_22886, rotation);
            generator.method_25760(shelfCondition(direction, isPowered, sideChainPart), variant);
        });
    }
    
    public static void forEachHorizontalDirection(BiConsumer<class_2350, class_4936.class_4937> consumer) {
        List.of(Pair.of(class_2350.field_11043, class_4936.class_4937.field_22890), Pair.of(class_2350.field_11034, class_4936.class_4937.field_22891), Pair.of(class_2350.field_11035, class_4936.class_4937.field_22892), Pair.of(class_2350.field_11039, class_4936.class_4937.field_22893))
            .forEach(pair -> {
                class_2350 direction = pair.getFirst();
                class_4936.class_4937 rotation = pair.getSecond();
                consumer.accept(direction, rotation);
            });
    }
    
    public static class_4918 shelfCondition(class_2350 direction, @Nullable Boolean isPowered, @Nullable SideChainPart sideChainPart) {
        class_4918.class_4921 facing = class_4918.method_25744().method_25751(class_2741.field_12481, direction);
        if (isPowered == null) {
            return facing;
        } else {
            class_4918.class_4921 powered = class_4918.method_25744().method_25751(class_2741.field_12484, isPowered);
            return sideChainPart != null ? class_4918.method_35870(facing, powered, class_4918.method_25744().method_25751(ModBlockStateProperties.SIDE_CHAIN_PART, sideChainPart)) : class_4918.method_35870(facing, powered);
        }
    }
    
    public void createShelfMushroom() {
        class_2960 shelfMushroom = class_4941.method_25843(ModBlocks.SHELF_MUSHROOM.get(), "_stage0");
        this.method_25623(ModBlocks.SHELF_MUSHROOM.get(), shelfMushroom);
        this.field_22830.accept(class_4925.method_25769(ModBlocks.SHELF_MUSHROOM.get())
            .method_25775(class_4926.method_25783(class_2741.field_12521)
                .method_25793(0, class_4935.method_25824().method_25828(class_4936.field_22887, class_4941.method_25843(ModBlocks.SHELF_MUSHROOM.get(), "_stage0")))
                .method_25793(1, class_4935.method_25824().method_25828(class_4936.field_22887, class_4941.method_25843(ModBlocks.SHELF_MUSHROOM.get(), "_stage1"))))
            .method_25775(method_25599())
        );
    }
    
    public void createStrawBed() {
        class_2248 strawBed = ModBlocks.STRAW_BED.get();
        class_2960 head = class_4941.method_25843(strawBed, "_head");
        class_2960 foot = class_4941.method_25843(strawBed, "_foot");
        this.method_25540(strawBed);
        this.field_22830.accept(createStrawBed(strawBed, head, foot));
    }
    
    private static class_4925 createStrawBed(class_2248 block, class_2960 headModelLocation, class_2960 footModelLocation) {
        return class_4925.method_25769(block)
            .method_25775(
                class_4926.method_25784(class_2741.field_12481, class_2741.field_12483)
                    .method_25797(class_2350.field_11043, class_2742.field_12560, class_4935.method_25824().method_25828(class_4936.field_22887, headModelLocation).method_25828(class_4936.field_22886, class_4936.class_4937.field_22892))
                    .method_25797(class_2350.field_11035, class_2742.field_12560, class_4935.method_25824().method_25828(class_4936.field_22887, headModelLocation))
                    .method_25797(class_2350.field_11034, class_2742.field_12560, class_4935.method_25824().method_25828(class_4936.field_22887, headModelLocation).method_25828(class_4936.field_22886, class_4936.class_4937.field_22893))
                    .method_25797(class_2350.field_11039, class_2742.field_12560, class_4935.method_25824().method_25828(class_4936.field_22887, headModelLocation).method_25828(class_4936.field_22886, class_4936.class_4937.field_22891))
                    .method_25797(class_2350.field_11043, class_2742.field_12557, class_4935.method_25824().method_25828(class_4936.field_22887, footModelLocation).method_25828(class_4936.field_22886, class_4936.class_4937.field_22892))
                    .method_25797(class_2350.field_11035, class_2742.field_12557, class_4935.method_25824().method_25828(class_4936.field_22887, footModelLocation))
                    .method_25797(class_2350.field_11034, class_2742.field_12557, class_4935.method_25824().method_25828(class_4936.field_22887, footModelLocation).method_25828(class_4936.field_22886, class_4936.class_4937.field_22893))
                    .method_25797(class_2350.field_11039, class_2742.field_12557, class_4935.method_25824().method_25828(class_4936.field_22887, footModelLocation).method_25828(class_4936.field_22886, class_4936.class_4937.field_22891))
            );
    }
}