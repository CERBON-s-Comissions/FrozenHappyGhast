package com.blackgear.vanillabackport.data.client.model;

import java.util.Optional;
import net.minecraft.class_2960;
import net.minecraft.class_4942;
import net.minecraft.class_4945;

public class ModModelTemplates {
    public static final class_4942 MOSSY_CARPET_SIDE = block("mossy_carpet_side", class_4945.field_23018);
    public static final class_4942 DRIED_GHAST = block(
        "dried_ghast",
        class_4945.field_23012,
        class_4945.field_23015,
        class_4945.field_23014,
        class_4945.field_23019,
        class_4945.field_23020,
        class_4945.field_23021,
        class_4945.field_23022,
        ModTextureSlots.TENTACLES
    );
    public static final class_4942 LEAF_LITTER_1 = block("template_leaf_litter_1", "_1", class_4945.field_23011);
    public static final class_4942 LEAF_LITTER_2 = block("template_leaf_litter_2", "_2", class_4945.field_23011);
    public static final class_4942 LEAF_LITTER_3 = block("template_leaf_litter_3", "_3", class_4945.field_23011);
    public static final class_4942 LEAF_LITTER_4 = block("template_leaf_litter_4", "_4", class_4945.field_23011);
    
    public static final class_4942 CHEST = item("chest", class_4945.field_23012);
    public static final class_4942 COPPER_GOLEM_STATUE = item("template_copper_golem_statue", class_4945.field_23012);
    
    public static final class_4942 CHAIN = block("template_chain", class_4945.field_23011);
    public static final class_4942 LIGHTNING_ROD = block("template_lightning_rod", class_4945.field_23011);
    
    public static final class_4942 BARS_CAP = block("template_bars_cap", "_cap", ModTextureSlots.BARS, class_4945.field_23032);
    public static final class_4942 BARS_CAP_ALT = block("template_bars_cap_alt", "_cap_alt", ModTextureSlots.BARS, class_4945.field_23032);
    public static final class_4942 BARS_POST = block("template_bars_post", "_post", ModTextureSlots.BARS, class_4945.field_23032);
    public static final class_4942 BARS_POST_ENDS = block("template_bars_post_ends", "_post_ends", ModTextureSlots.BARS, class_4945.field_23032);
    public static final class_4942 BARS_POST_SIDE = block("template_bars_side", "_side", ModTextureSlots.BARS, class_4945.field_23032);
    public static final class_4942 BARS_POST_SIDE_ALT = block("template_bars_side_alt", "_side_alt", ModTextureSlots.BARS, class_4945.field_23032);
    
    public static final class_4942 SHELF_BODY = block("template_shelf_body", class_4945.field_23010, class_4945.field_23012);
    public static final class_4942 SHELF_INVENTORY = block("template_shelf_inventory", "_inventory", class_4945.field_23010, class_4945.field_23012);
    public static final class_4942 SHELF_UNPOWERED = block("template_shelf_unpowered", "_unpowered", class_4945.field_23010, class_4945.field_23012);
    public static final class_4942 SHELF_UNCONNECTED = block("template_shelf_unconnected", "_unconnected", class_4945.field_23010, class_4945.field_23012);
    public static final class_4942 SHELF_LEFT = block("template_shelf_left", "_left", class_4945.field_23010, class_4945.field_23012);
    public static final class_4942 SHELF_CENTER = block("template_shelf_center", "_center", class_4945.field_23010, class_4945.field_23012);
    public static final class_4942 SHELF_RIGHT = block("template_shelf_right", "_right", class_4945.field_23010, class_4945.field_23012);
    
    private static class_4942 block(String name, class_4945... slots) {
        return new class_4942(Optional.of(class_2960.method_60656("block/" + name)), Optional.empty(), slots);
    }
    
    private static class_4942 item(String name, class_4945... slots) {
        return new class_4942(Optional.of(class_2960.method_60656("item/" + name)), Optional.empty(), slots);
    }

    private static class_4942 block(String name, String suffix, class_4945... slots) {
        return new class_4942(Optional.of(class_2960.method_60656("block/" + name)), Optional.of(suffix), slots);
    }
}