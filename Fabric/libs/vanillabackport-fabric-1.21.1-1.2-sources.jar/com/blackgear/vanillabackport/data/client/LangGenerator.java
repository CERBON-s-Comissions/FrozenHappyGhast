package com.blackgear.vanillabackport.data.client;

import com.blackgear.vanillabackport.common.registries.blocks.ModBlocks;
import com.blackgear.vanillabackport.common.registries.entities.ModAttributes;
import com.blackgear.vanillabackport.common.registries.entities.ModEntityTypes;
import com.blackgear.vanillabackport.common.registries.entities.ModMobEffects;
import com.blackgear.vanillabackport.common.registries.items.ModItems;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricLanguageProvider;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;

public class LangGenerator extends FabricLanguageProvider {
    public LangGenerator(FabricDataOutput dataOutput, CompletableFuture<class_7225.class_7874> registryLookup) {
        super(dataOutput, registryLookup);
    }

    @Override
    public void generateTranslations(class_7225.class_7874 provider, TranslationBuilder builder) {
        // THE GARDEN AWAKENS

        // Biomes
        builder.add("biome.minecraft.pale_garden", "Pale Garden");

        // Blocks
        builder.add(ModBlocks.PALE_HANGING_MOSS.get(), "Pale Hanging Moss");
        builder.add(ModBlocks.PALE_MOSS_BLOCK.get(), "Pale Moss Block");
        builder.add(ModBlocks.PALE_MOSS_CARPET.get(), "Pale Moss Carpet");

        builder.add(ModBlocks.PALE_OAK_BUTTON.get(), "Pale Oak Button");
        builder.add(ModBlocks.PALE_OAK_DOOR.get(), "Pale Oak Door");
        builder.add(ModBlocks.PALE_OAK_FENCE.get(), "Pale Oak Fence");
        builder.add(ModBlocks.PALE_OAK_FENCE_GATE.get(), "Pale Oak Fence Gate");
        builder.add(ModBlocks.PALE_OAK_HANGING_SIGN.getFirst().get(), "Pale Oak Hanging Sign");
        builder.add(ModBlocks.PALE_OAK_LEAVES.get(), "Pale Oak Leaves");
        builder.add(ModBlocks.PALE_OAK_LOG.get(), "Pale Oak Log");
        builder.add(ModBlocks.PALE_OAK_PLANKS.get(), "Pale Oak Planks");
        builder.add(ModBlocks.PALE_OAK_PRESSURE_PLATE.get(), "Pale Oak Pressure Plate");
        builder.add(ModBlocks.PALE_OAK_SAPLING.get(), "Pale Oak Sapling");
        builder.add(ModBlocks.PALE_OAK_SIGN.getFirst().get(), "Pale Oak Sign");
        builder.add(ModBlocks.PALE_OAK_SLAB.get(), "Pale Oak Slab");
        builder.add(ModBlocks.PALE_OAK_STAIRS.get(), "Pale Oak Stairs");
        builder.add(ModBlocks.PALE_OAK_TRAPDOOR.get(), "Pale Oak Trapdoor");
        builder.add("block.minecraft.pale_oak_wall_hanging_sign", "Pale Oak Wall Hanging Sign");
        builder.add("block.minecraft.pale_oak_wall_sign", "Pale Oak Wall Sign");
        builder.add(ModBlocks.PALE_OAK_WOOD.get(), "Pale Oak Wood");
        builder.add(ModBlocks.STRIPPED_PALE_OAK_LOG.get(), "Stripped Pale Oak Log");
        builder.add(ModBlocks.STRIPPED_PALE_OAK_WOOD.get(), "Stripped Pale Oak Wood");

        builder.add(ModBlocks.OPEN_EYEBLOSSOM.get(), "Open Eyeblossom");
        builder.add(ModBlocks.CLOSED_EYEBLOSSOM.get(), "Closed Eyeblossom");
        builder.add(ModBlocks.POTTED_PALE_OAK_SAPLING.get(), "Potted Pale Oak Sapling");
        builder.add(ModBlocks.POTTED_OPEN_EYEBLOSSOM.get(), "Potted Open Eyeblossom");
        builder.add(ModBlocks.POTTED_CLOSED_EYEBLOSSOM.get(), "Potted Closed Eyeblossom");

        builder.add(ModBlocks.CREAKING_HEART.get(), "Creaking Heart");

        builder.add(ModBlocks.RESIN_CLUMP.get(), "Resin Clump");
        builder.add(ModBlocks.RESIN_BLOCK.get(), "Block of Resin");
        builder.add(ModBlocks.RESIN_BRICKS.get(), "Resin Bricks");
        builder.add(ModBlocks.RESIN_BRICK_STAIRS.get(), "Resin Brick Stairs");
        builder.add(ModBlocks.RESIN_BRICK_SLAB.get(), "Resin Brick Slab");
        builder.add(ModBlocks.RESIN_BRICK_WALL.get(), "Resin Brick Wall");
        builder.add(ModBlocks.CHISELED_RESIN_BRICKS.get(), "Chiseled Resin Bricks");

        // Items
        builder.add(ModItems.PALE_OAK_BOAT.get(), "Pale Oak Boat");
        builder.add(ModItems.PALE_OAK_CHEST_BOAT.get(), "Pale Oak Boat with Chest");
        builder.add(ModItems.RESIN_BRICK.get(), "Resin Brick");
        builder.add(ModItems.CREAKING_SPAWN_EGG.get(), "Creaking Spawn Egg");

        // Entities
        builder.add(ModEntityTypes.CREAKING.get(), "Creaking");
        builder.add(ModEntityTypes.CUSTOM_BOAT.get(), "Boat");
        builder.add(ModEntityTypes.CUSTOM_CHEST_BOAT.get(), "Boat with Chest");

        // Trims
        builder.add("trim_material.minecraft.resin", "Resin Material");

        // Block Subtitles
        builder.add("subtitles.block.creaking_heart.hurt", "Creaking Heart grumbles");
        builder.add("subtitles.block.creaking_heart.idle", "Eerie noise");
        builder.add("subtitles.block.creaking_heart.spawn", "Creaking Heart awakens");

        builder.add("subtitles.block.pale_hanging_moss.idle", "Eerie noise");

        builder.add("subtitles.block.eyeblossom.close", "Eyeblossom closes");
        builder.add("subtitles.block.eyeblossom.idle", "Eyeblossom whispers");
        builder.add("subtitles.block.eyeblossom.open", "Eyeblossom opens");

        // Entity Subtitles
        builder.add("subtitles.entity.creaking.activate", "Creaking watches");
        builder.add("subtitles.entity.creaking.ambient", "Creaking creaks");
        builder.add("subtitles.entity.creaking.deactivate", "Creaking calms");
        builder.add("subtitles.entity.creaking.attack", "Creaking attacks");
        builder.add("subtitles.entity.creaking.death", "Creaking crumbles");
        builder.add("subtitles.entity.creaking.freeze", "Creaking stops");
        builder.add("subtitles.entity.creaking.spawn", "Creaking manifests");
        builder.add("subtitles.entity.creaking.sway", "Creaking is hit");
        builder.add("subtitles.entity.creaking.twitch", "Creaking twitches");
        builder.add("subtitles.entity.creaking.unfreeze", "Creaking moves");

        builder.add("subtitles.entity.parrot.imitate.creaking", "Parrot creaks");
        builder.add("subtitles.entity.parrot.imitate.camel_husk", "Parrot grumphs");
        builder.add("subtitles.entity.parrot.imitate.parched", "Parrot crackles");
        builder.add("subtitles.entity.parrot.imitate.zombie_nautilus", "Parrot gargles");

        // Chase the Skies
        builder.add(ModBlocks.DRIED_GHAST.get(), "Dried Ghast");

        builder.add(ModItems.HAPPY_GHAST_SPAWN_EGG.get(), "Happy Ghast Spawn Egg");

        builder.add(ModItems.WHITE_HARNESS.get(), "White Harness");
        builder.add(ModItems.ORANGE_HARNESS.get(), "Orange Harness");
        builder.add(ModItems.MAGENTA_HARNESS.get(), "Magenta Harness");
        builder.add(ModItems.LIGHT_BLUE_HARNESS.get(), "Light Blue Harness");
        builder.add(ModItems.YELLOW_HARNESS.get(), "Yellow Harness");
        builder.add(ModItems.LIME_HARNESS.get(), "Lime Harness");
        builder.add(ModItems.PINK_HARNESS.get(), "Pink Harness");
        builder.add(ModItems.GRAY_HARNESS.get(), "Gray Harness");
        builder.add(ModItems.LIGHT_GRAY_HARNESS.get(), "Light Gray Harness");
        builder.add(ModItems.CYAN_HARNESS.get(), "Cyan Harness");
        builder.add(ModItems.PURPLE_HARNESS.get(), "Purple Harness");
        builder.add(ModItems.BLUE_HARNESS.get(), "Blue Harness");
        builder.add(ModItems.BROWN_HARNESS.get(), "Brown Harness");
        builder.add(ModItems.GREEN_HARNESS.get(), "Green Harness");
        builder.add(ModItems.RED_HARNESS.get(), "Red Harness");
        builder.add(ModItems.BLACK_HARNESS.get(), "Black Harness");

        builder.add("item.minecraft.music_disc_tears", "Music Disc");
        builder.add("item.minecraft.music_disc_tears.desc", "Amos Roddy - Tears");

        builder.add("jukebox_song.minecraft.tears", "Amos Roddy - Tears");

        builder.add("item.minecraft.music_disc_lava_chicken", "Music Disc");
        builder.add("item.minecraft.music_disc_lava_chicken.desc", "Hyper Potions - Lava Chicken");

        builder.add("jukebox_song.minecraft.lava_chicken", "Hyper Potions - Lava Chicken");

        builder.add("painting.minecraft.dennis.author", "Sarah Boeving");
        builder.add("painting.minecraft.dennis.title", "Dennis");

        builder.add(ModEntityTypes.HAPPY_GHAST.get(), "Happy Ghast");

        builder.add("subtitles.block.dried_ghast.ambient", "Sounds of dryness");
        builder.add("subtitles.block.dried_ghast.ambient_water", "Dried Ghast rehydrates");
        builder.add("subtitles.block.dried_ghast.place_in_water", "Dried Ghast soaks");
        builder.add("subtitles.block.dried_ghast.transition", "Dried Ghast feels better");

        builder.add("subtitles.entity.ghastling.ambient", "Ghastling coos");
        builder.add("subtitles.entity.ghastling.death", "Ghastling dies");
        builder.add("subtitles.entity.ghastling.hurt", "Ghastling hurts");
        builder.add("subtitles.entity.ghastling.spawn", "Ghastling appears");

        builder.add("subtitles.entity.happy_ghast.ambient", "Happy Ghast croons");
        builder.add("subtitles.entity.happy_ghast.death", "Happy Ghast dies");
        builder.add("subtitles.entity.happy_ghast.hurt", "Happy Ghast hurts");
        builder.add("subtitles.entity.happy_ghast.harness_goggles_down", "Happy Ghast is ready");
        builder.add("subtitles.entity.happy_ghast.harness_goggles_up", "Happy Ghast stops");
        builder.add("subtitles.entity.happy_ghast.unequip", "Harness unequips");
        builder.add("subtitles.entity.happy_ghast.equip", "Harness equips");
        
        builder.add("attribute.name.waypoint_receive_range", "Waypoint Receive Range");
        builder.add("attribute.name.waypoint_transmit_range", "Waypoint Transmit Range");
        
        builder.add("argument.waypoint.invalid", "Selected entity is not a waypoint");
        builder.add("commands.waypoint.list.empty", "No waypoints in %s");
        builder.add("commands.waypoint.list.success", "%s waypoint(s) in %s: %s");
        builder.add("commands.waypoint.modify.color", "Waypoint color is now %s");
        builder.add("commands.waypoint.modify.color.reset", "Reset waypoint color");
        builder.add("commands.waypoint.modify.style", "Waypoint style changed");
        
        builder.add("gamerule.locatorBar", "Enable player Locator Bar");
        builder.add("gamerule.locatorBar.description", "When enabled, a bar is shown on the screen to indicate the direction of players.");

        // Spring to Life
        builder.add(ModBlocks.BUSH.get(), "Bush");
        builder.add(ModBlocks.FIREFLY_BUSH.get(), "Firefly Bush");
        builder.add(ModBlocks.WILDFLOWERS.get(), "Wildflowers");
        builder.add(ModBlocks.CACTUS_FLOWER.get(), "Cactus Flower");
        builder.add(ModBlocks.SHORT_DRY_GRASS.get(), "Short Dry Grass");
        builder.add(ModBlocks.TALL_DRY_GRASS.get(), "Tall Dry Grass");
        builder.add(ModBlocks.LEAF_LITTER.get(), "Leaf Litter");

        builder.add(ModItems.BLUE_EGG.get(), "Blue Egg");
        builder.add(ModItems.BROWN_EGG.get(), "Brown Egg");

        builder.add("subtitles.block.firefly_bush.idle", "Fireflies buzz");

        builder.add("subtitles.block.sand.idle", "Sandy sounds");
        builder.add("subtitles.block.deadbush.idle", "Dry sounds");
        builder.add("subtitles.block.dry_grass.ambient", "Windy sounds");

        builder.add("subtitles.entity.wolf.bark", "Wolf barks");
        builder.add("subtitles.entity.wolf.pant", "Wolf pants");
        builder.add("subtitles.entity.wolf.whine", "Wolf whines");

        // Bundles of Bravery
        builder.add("item.minecraft.bundle.empty", "Empty");
        builder.add("item.minecraft.bundle.empty.description", "Can hold a mixed stack of items");
        builder.add("item.minecraft.bundle.full", "Full");

        builder.add("subtitles.item.bundle.insert_fail", "Bundle full");

        builder.add(ModItems.BLACK_BUNDLE.get(), "Black Bundle");
        builder.add(ModItems.WHITE_BUNDLE.get(), "White Bundle");
        builder.add(ModItems.GRAY_BUNDLE.get(), "Gray Bundle");
        builder.add(ModItems.LIGHT_GRAY_BUNDLE.get(), "Light Gray Bundle");
        builder.add(ModItems.LIGHT_BLUE_BUNDLE.get(), "Light Blue Bundle");
        builder.add(ModItems.BLUE_BUNDLE.get(), "Blue Bundle");
        builder.add(ModItems.CYAN_BUNDLE.get(), "Cyan Bundle");
        builder.add(ModItems.YELLOW_BUNDLE.get(), "Yellow Bundle");
        builder.add(ModItems.RED_BUNDLE.get(), "Red Bundle");
        builder.add(ModItems.PURPLE_BUNDLE.get(), "Purple Bundle");
        builder.add(ModItems.MAGENTA_BUNDLE.get(), "Magenta Bundle");
        builder.add(ModItems.PINK_BUNDLE.get(), "Pink Bundle");
        builder.add(ModItems.GREEN_BUNDLE.get(), "Green Bundle");
        builder.add(ModItems.LIME_BUNDLE.get(), "Lime Bundle");
        builder.add(ModItems.BROWN_BUNDLE.get(), "Brown Bundle");
        builder.add(ModItems.ORANGE_BUNDLE.get(), "Orange Bundle");
        
        // Copper Age
        
        builder.add(ModBlocks.COPPER_CHEST.get(), "Copper Chest");
        builder.add(ModBlocks.EXPOSED_COPPER_CHEST.get(), "Exposed Copper Chest");
        builder.add(ModBlocks.WEATHERED_COPPER_CHEST.get(), "Weathered Copper Chest");
        builder.add(ModBlocks.OXIDIZED_COPPER_CHEST.get(), "Oxidized Copper Chest");
        
        builder.add(ModBlocks.WAXED_COPPER_CHEST.get(), "Waxed Copper Chest");
        builder.add(ModBlocks.WAXED_EXPOSED_COPPER_CHEST.get(), "Waxed Exposed Copper Chest");
        builder.add(ModBlocks.WAXED_WEATHERED_COPPER_CHEST.get(), "Waxed Weathered Copper Chest");
        builder.add(ModBlocks.WAXED_OXIDIZED_COPPER_CHEST.get(), "Waxed Oxidized Copper Chest");
        
        builder.add(ModBlocks.OAK_SHELF.get(), "Oak Shelf");
        builder.add(ModBlocks.BIRCH_SHELF.get(), "Birch Shelf");
        builder.add(ModBlocks.SPRUCE_SHELF.get(), "Spruce Shelf");
        builder.add(ModBlocks.JUNGLE_SHELF.get(), "Jungle Shelf");
        builder.add(ModBlocks.ACACIA_SHELF.get(), "Acacia Shelf");
        builder.add(ModBlocks.DARK_OAK_SHELF.get(), "Dark Oak Shelf");
        builder.add(ModBlocks.CRIMSON_SHELF.get(), "Crimson Shelf");
        builder.add(ModBlocks.WARPED_SHELF.get(), "Warped Shelf");
        builder.add(ModBlocks.MANGROVE_SHELF.get(), "Mangrove Shelf");
        builder.add(ModBlocks.BAMBOO_SHELF.get(), "Bamboo Shelf");
        builder.add(ModBlocks.CHERRY_SHELF.get(), "Cherry Shelf");
        builder.add(ModBlocks.PALE_OAK_SHELF.get(), "Pale Oak Shelf");
        
        builder.add(ModBlocks.COPPER_GOLEM_STATUE.get(), "Copper Golem Statue");
        builder.add(ModBlocks.EXPOSED_COPPER_GOLEM_STATUE.get(), "Exposed Copper Golem Statue");
        builder.add(ModBlocks.WEATHERED_COPPER_GOLEM_STATUE.get(), "Weathered Copper Golem Statue");
        builder.add(ModBlocks.OXIDIZED_COPPER_GOLEM_STATUE.get(), "Oxidized Copper Golem Statue");
        
        builder.add(ModBlocks.WAXED_COPPER_GOLEM_STATUE.get(), "Waxed Copper Golem Statue");
        builder.add(ModBlocks.WAXED_EXPOSED_COPPER_GOLEM_STATUE.get(), "Waxed Exposed Copper Golem Statue");
        builder.add(ModBlocks.WAXED_WEATHERED_COPPER_GOLEM_STATUE.get(), "Waxed Weathered Copper Golem Statue");
        builder.add(ModBlocks.WAXED_OXIDIZED_COPPER_GOLEM_STATUE.get(), "Waxed Oxidized Copper Golem Statue");
        
        builder.add(ModBlocks.EXPOSED_LIGHTNING_ROD.get(), "Exposed Lightning Rod");
        builder.add(ModBlocks.WEATHERED_LIGHTNING_ROD.get(), "Weathered Lightning Rod");
        builder.add(ModBlocks.OXIDIZED_LIGHTNING_ROD.get(), "Oxidized Lightning Rod");
        
        builder.add(ModBlocks.WAXED_LIGHTNING_ROD.get(), "Waxed Lightning Rod");
        builder.add(ModBlocks.WAXED_EXPOSED_LIGHTNING_ROD.get(), "Waxed Exposed Lightning Rod");
        builder.add(ModBlocks.WAXED_WEATHERED_LIGHTNING_ROD.get(), "Waxed Weathered Lightning Rod");
        builder.add(ModBlocks.WAXED_OXIDIZED_LIGHTNING_ROD.get(), "Waxed Oxidized Lightning Rod");
        
        builder.add(ModItems.COPPER_GOLEM_SPAWN_EGG.get(), "Copper Golem Spawn Egg");
        
        builder.add(ModItems.COPPER_SWORD.get(), "Copper Sword");
        builder.add(ModItems.COPPER_AXE.get(), "Copper Axe");
        builder.add(ModItems.COPPER_PICKAXE.get(), "Copper Pickaxe");
        builder.add(ModItems.COPPER_SHOVEL.get(), "Copper Shovel");
        builder.add(ModItems.COPPER_HOE.get(), "Copper Hoe");
        
        builder.add(ModItems.COPPER_HELMET.get(), "Copper Helmet");
        builder.add(ModItems.COPPER_CHESTPLATE.get(), "Copper Chestplate");
        builder.add(ModItems.COPPER_LEGGINGS.get(), "Copper Leggings");
        builder.add(ModItems.COPPER_BOOTS.get(), "Copper Boots");
        
        builder.add(ModItems.COPPER_HORSE_ARMOR.get(), "Copper Horse Armor");
        builder.add(ModItems.COPPER_NUGGET.get(), "Copper Nugget");
        
        builder.add(ModBlocks.COPPER_TORCH.getFirst().get(), "Copper Torch");
        
        builder.add(ModBlocks.COPPER_LANTERN.unaffected().get(), "Copper Lantern");
        builder.add(ModBlocks.COPPER_LANTERN.exposed().get(), "Exposed Copper Lantern");
        builder.add(ModBlocks.COPPER_LANTERN.weathered().get(), "Weathered Copper Lantern");
        builder.add(ModBlocks.COPPER_LANTERN.oxidized().get(), "Oxidized Copper Lantern");
        
        builder.add(ModBlocks.COPPER_LANTERN.waxed().get(), "Waxed Copper Lantern");
        builder.add(ModBlocks.COPPER_LANTERN.waxedExposed().get(), "Waxed Exposed Copper Lantern");
        builder.add(ModBlocks.COPPER_LANTERN.waxedWeathered().get(), "Waxed Weathered Copper Lantern");
        builder.add(ModBlocks.COPPER_LANTERN.waxedOxidized().get(), "Waxed Oxidized Copper Lantern");
        
        builder.add(ModBlocks.COPPER_CHAIN.unaffected().get(), "Copper Chain");
        builder.add(ModBlocks.COPPER_CHAIN.exposed().get(), "Exposed Copper Chain");
        builder.add(ModBlocks.COPPER_CHAIN.weathered().get(), "Weathered Copper Chain");
        builder.add(ModBlocks.COPPER_CHAIN.oxidized().get(), "Oxidized Copper Chain");
        
        builder.add(ModBlocks.COPPER_CHAIN.waxed().get(), "Waxed Copper Chain");
        builder.add(ModBlocks.COPPER_CHAIN.waxedExposed().get(), "Waxed Exposed Copper Chain");
        builder.add(ModBlocks.COPPER_CHAIN.waxedWeathered().get(), "Waxed Weathered Copper Chain");
        builder.add(ModBlocks.COPPER_CHAIN.waxedOxidized().get(), "Waxed Oxidized Copper Chain");
        
        builder.add(ModBlocks.COPPER_BARS.unaffected().get(), "Copper Bars");
        builder.add(ModBlocks.COPPER_BARS.exposed().get(), "Exposed Copper Bars");
        builder.add(ModBlocks.COPPER_BARS.weathered().get(), "Weathered Copper Bars");
        builder.add(ModBlocks.COPPER_BARS.oxidized().get(), "Oxidized Copper Bars");
        
        builder.add(ModBlocks.COPPER_BARS.waxed().get(), "Waxed Copper Bars");
        builder.add(ModBlocks.COPPER_BARS.waxedExposed().get(), "Waxed Exposed Copper Bars");
        builder.add(ModBlocks.COPPER_BARS.waxedWeathered().get(), "Waxed Weathered Copper Bars");
        builder.add(ModBlocks.COPPER_BARS.waxedOxidized().get(), "Waxed Oxidized Copper Bars");
        
        builder.add(ModEntityTypes.COPPER_GOLEM.get(), "Copper Golem");
        
        builder.add("subtitles.block.shelf.activate", "Shelf activates");
        builder.add("subtitles.block.shelf.deactivate", "Shelf deactivates");
        builder.add("subtitles.block.shelf.multi_swap", "Items swap");
        builder.add("subtitles.block.shelf.place_item", "Item placed");
        builder.add("subtitles.block.shelf.single_swap", "Item swaps");
        builder.add("subtitles.block.shelf.take_item", "Item taken");
        
        builder.add("subtitles.block.copper_chest.close", "Chest closes");
        builder.add("subtitles.block.copper_chest.open", "Chest opens");
        
        builder.add("subtitles.item.armor.equip_copper", "Copper armor clonks");
        
        builder.add("subtitles.entity.copper_golem_become_statue", "Copper Golem is petrified");
        builder.add("subtitles.entity.copper_golem_oxidized.death", "Copper Golem dies");
        builder.add("subtitles.entity.copper_golem_oxidized.hurt", "Copper Golem hurts");
        builder.add("subtitles.entity.copper_golem_oxidized.spin", "Copper Golem's head spins");
        builder.add("subtitles.entity.copper_golem_weathered.death", "Copper Golem dies");
        builder.add("subtitles.entity.copper_golem_weathered.hurt", "Copper Golem hurts");
        builder.add("subtitles.entity.copper_golem_weathered.spin", "Copper Golem's head spins");
        builder.add("subtitles.entity.copper_golem.death", "Copper Golem dies");
        builder.add("subtitles.entity.copper_golem.hurt", "Copper Golem hurts");
        builder.add("subtitles.entity.copper_golem.item_drop", "Copper Golem is placing an item");
        builder.add("subtitles.entity.copper_golem.item_no_drop", "Copper Golem can't place item");
        builder.add("subtitles.entity.copper_golem.no_item_get", "Copper Golem is picking up item");
        builder.add("subtitles.entity.copper_golem.no_item_no_get", "Copper Golem can't pick up item");
        builder.add("subtitles.entity.copper_golem.spawn", "Copper Golem appears");
        builder.add("subtitles.entity.copper_golem.spin", "Copper Golem's head spins");
        
        builder.add("subtitles.weather.end_flash", "End Flash rumbles");
        
        builder.add("block_type.vanillabackport.shelf", "%s Shelf");
        
        // Mounts of Mayhem
        builder.add(ModEntityTypes.PARCHED.get(), "Parched");
        builder.add(ModEntityTypes.CAMEL_HUSK.get(), "Camel Husk");
        builder.add(ModEntityTypes.NAUTILUS.get(), "Nautilus");
        builder.add(ModEntityTypes.ZOMBIE_NAUTILUS.get(), "Zombie Nautilus");

        builder.add(ModItems.COPPER_NAUTILUS_ARMOR.get(), "Copper Nautilus Armor");
        builder.add(ModItems.IRON_NAUTILUS_ARMOR.get(), "Iron Nautilus Armor");
        builder.add(ModItems.GOLDEN_NAUTILUS_ARMOR.get(), "Golden Nautilus Armor");
        builder.add(ModItems.DIAMOND_NAUTILUS_ARMOR.get(), "Diamond Nautilus Armor");
        builder.add(ModItems.NETHERITE_NAUTILUS_ARMOR.get(), "Netherite Nautilus Armor");
        
        builder.add(ModItems.NETHERITE_HORSE_ARMOR.get(), "Netherite Horse Armor");
        
        builder.add(ModItems.WOODEN_SPEAR.get(), "Wooden Spear");
        builder.add(ModItems.STONE_SPEAR.get(), "Stone Spear");
        builder.add(ModItems.COPPER_SPEAR.get(), "Copper Spear");
        builder.add(ModItems.IRON_SPEAR.get(), "Iron Spear");
        builder.add(ModItems.GOLDEN_SPEAR.get(), "Golden Spear");
        builder.add(ModItems.DIAMOND_SPEAR.get(), "Diamond Spear");
        builder.add(ModItems.NETHERITE_SPEAR.get(), "Netherite Spear");
        
        builder.add(ModItems.CAMEL_HUSK_SPAWN_EGG.get(), "Camel Husk Spawn Egg");
        builder.add(ModItems.NAUTILUS_SPAWN_EGG.get(), "Nautilus Spawn Egg");
        builder.add(ModItems.PARCHED_SPAWN_EGG.get(), "Parched Spawn Egg");
        builder.add(ModItems.ZOMBIE_NAUTILUS_SPAWN_EGG.get(), "Zombie Nautilus Spawn Egg");
        
        builder.add(ModMobEffects.BREATH_OF_THE_NAUTILUS.comp_349(), "Breath of the Nautilus");
        
        builder.add("enchantment.minecraft.lunge", "Lunge");
        builder.add("enchantment.minecraft.lunge.desc", "The user lunges forward when using the spear");
        
        builder.add("advancements.adventure.spear_many_mobs.title", "Mob Kabob");
        builder.add("advancements.adventure.spear_many_mobs.description", "Hit five mobs in the same Charge attack using the Spear");
        
        builder.add("subtitles.entity.camel_husk.ambient", "Camel Husk grumphs");
        builder.add("subtitles.entity.camel_husk.dash", "Camel Husk yeets");
        builder.add("subtitles.entity.camel_husk.dash_ready", "Camel Husk recovers");
        builder.add("subtitles.entity.camel_husk.death", "Camel Husk dies");
        builder.add("subtitles.entity.camel_husk.eat", "Camel Husk eats");
        builder.add("subtitles.entity.camel_husk.hurt", "Camel Husk hurts");
        builder.add("subtitles.entity.camel_husk.saddle", "Saddle equips");
        builder.add("subtitles.entity.camel_husk.sit", "Camel Husk sits down");
        builder.add("subtitles.entity.camel_husk.stand", "Camel Husk stands up");
        
        builder.add("subtitles.entity.zombie_horse.angry", "Zombie Horse neighs");
        builder.add("subtitles.entity.zombie_horse.eat", "Zombie Horse eats");
        
        builder.add("subtitles.entity.parched.ambient", "Parched crackles");
        builder.add("subtitles.entity.parched.death", "Parched dies");
        builder.add("subtitles.entity.parched.hurt", "Parched hurts");
        
        builder.add("subtitles.entity.baby_nautilus.ambient", "Baby Nautilus chitters");
        builder.add("subtitles.entity.baby_nautilus.ambient_land", "Baby Nautilus chitters");
        builder.add("subtitles.entity.baby_nautilus.death", "Baby Nautilus dies");
        builder.add("subtitles.entity.baby_nautilus.death_land", "Baby Nautilus dies");
        builder.add("subtitles.entity.baby_nautilus.eat", "Baby Nautilus eats");
        builder.add("subtitles.entity.baby_nautilus.hurt", "Baby Nautilus hurts");
        builder.add("subtitles.entity.baby_nautilus.hurt_land", "Baby Nautilus hurts");
        builder.add("subtitles.entity.baby_nautilus.swim", "Baby Nautilus swims");
        
        builder.add("subtitles.entity.nautilus.ambient", "Nautilus clacks");
        builder.add("subtitles.entity.nautilus.ambient_land", "Nautilus clacks");
        builder.add("subtitles.entity.nautilus.dash", "Nautilus jets");
        builder.add("subtitles.entity.nautilus.dash_land", "Nautilus jets");
        builder.add("subtitles.entity.nautilus.dash_ready", "Nautilus recovers");
        builder.add("subtitles.entity.nautilus.dash_ready_land", "Nautilus recovers");
        builder.add("subtitles.entity.nautilus.death", "Nautilus dies");
        builder.add("subtitles.entity.nautilus.death_land", "Nautilus dies");
        builder.add("subtitles.entity.nautilus.eat", "Nautilus eats");
        builder.add("subtitles.entity.nautilus.hurt", "Nautilus hurts");
        builder.add("subtitles.entity.nautilus.hurt_land", "Nautilus hurts");
        builder.add("subtitles.entity.nautilus.swim", "Nautilus swims");
        
        builder.add("subtitles.entity.zombie_nautilus.ambient", "Zombie Nautilus clacks");
        builder.add("subtitles.entity.zombie_nautilus.ambient_land", "Zombie Nautilus clacks");
        builder.add("subtitles.entity.zombie_nautilus.dash", "Zombie Nautilus jets");
        builder.add("subtitles.entity.zombie_nautilus.dash_land", "Zombie Nautilus jets");
        builder.add("subtitles.entity.zombie_nautilus.dash_ready", "Zombie Nautilus recovers");
        builder.add("subtitles.entity.zombie_nautilus.dash_ready_land", "Zombie Nautilus recovers");
        builder.add("subtitles.entity.zombie_nautilus.death", "Zombie Nautilus dies");
        builder.add("subtitles.entity.zombie_nautilus.death_land", "Zombie Nautilus dies");
        builder.add("subtitles.entity.zombie_nautilus.eat", "Zombie Nautilus eats");
        builder.add("subtitles.entity.zombie_nautilus.hurt", "Zombie Nautilus hurts");
        builder.add("subtitles.entity.zombie_nautilus.hurt_land", "Zombie Nautilus hurts");
        builder.add("subtitles.entity.zombie_nautilus.swim", "Zombie Nautilus swims");
        
        builder.add("subtitles.item.armor.equip_nautilus", "Nautilus Armor equips");
        builder.add("subtitles.item.armor.unequip_nautilus", "Nautilus Armor unequips");
        builder.add("subtitles.item.nautilus_saddle_equip", "Saddle equips");
        builder.add("subtitles.item.nautilus_saddle_underwater_equip", "Saddle equips");
        
        builder.add("subtitles.item.spear.attack", "Spear jabs");
        builder.add("subtitles.item.spear.hit", "Spear hits");
        builder.add("subtitles.item.spear.lunge", "Spear lunges");
        builder.add("subtitles.item.spear.use", "Charges with Spear");
        
        builder.add("subtitles.item.spear_wood.attack", "Spear jabs");
        builder.add("subtitles.item.spear_wood.hit", "Spear hits");
        builder.add("subtitles.item.spear_wood.use", "Charges with Spear");
        
        // Chaos Cubed

        builder.add("biome.minecraft.sulfur_caves", "Sulfur Caves");

        builder.add(ModBlocks.CINNABAR.get(), "Cinnabar");
        builder.add(ModBlocks.CINNABAR_SLAB.get(), "Cinnabar Slab");
        builder.add(ModBlocks.CINNABAR_STAIRS.get(), "Cinnabar Stairs");
        builder.add(ModBlocks.CINNABAR_WALL.get(), "Cinnabar Wall");
        builder.add(ModBlocks.POLISHED_CINNABAR.get(), "Polished Cinnabar");
        builder.add(ModBlocks.POLISHED_CINNABAR_SLAB.get(), "Polished Cinnabar Slab");
        builder.add(ModBlocks.POLISHED_CINNABAR_STAIRS.get(), "Polished Cinnabar Stairs");
        builder.add(ModBlocks.POLISHED_CINNABAR_WALL.get(), "Polished Cinnabar Wall");
        builder.add(ModBlocks.CINNABAR_BRICKS.get(), "Cinnabar Bricks");
        builder.add(ModBlocks.CINNABAR_BRICK_SLAB.get(), "Cinnabar Brick Slab");
        builder.add(ModBlocks.CINNABAR_BRICK_STAIRS.get(), "Cinnabar Brick Stairs");
        builder.add(ModBlocks.CINNABAR_BRICK_WALL.get(), "Cinnabar Brick Wall");
        builder.add(ModBlocks.CHISELED_CINNABAR.get(), "Chiseled Cinnabar");
        builder.add(ModBlocks.POTENT_SULFUR.get(), "Potent Sulfur");
        builder.add(ModBlocks.SULFUR_SPIKE.get(), "Sulfur Spike");
        builder.add(ModBlocks.SULFUR.get(), "Sulfur");
        builder.add(ModBlocks.SULFUR_SLAB.get(), "Sulfur Slab");
        builder.add(ModBlocks.SULFUR_STAIRS.get(), "Sulfur Stairs");
        builder.add(ModBlocks.SULFUR_WALL.get(), "Sulfur Wall");
        builder.add(ModBlocks.POLISHED_SULFUR.get(), "Polished Sulfur");
        builder.add(ModBlocks.POLISHED_SULFUR_SLAB.get(), "Polished Sulfur Slab");
        builder.add(ModBlocks.POLISHED_SULFUR_STAIRS.get(), "Polished Sulfur Stairs");
        builder.add(ModBlocks.POLISHED_SULFUR_WALL.get(), "Polished Sulfur Wall");
        builder.add(ModBlocks.SULFUR_BRICKS.get(), "Sulfur Bricks");
        builder.add(ModBlocks.SULFUR_BRICK_SLAB.get(), "Sulfur Brick Slab");
        builder.add(ModBlocks.SULFUR_BRICK_STAIRS.get(), "Sulfur Brick Stairs");
        builder.add(ModBlocks.SULFUR_BRICK_WALL.get(), "Sulfur Brick Wall");
        builder.add(ModBlocks.CHISELED_SULFUR.get(), "Chiseled Sulfur");

        builder.add(ModEntityTypes.SULFUR_CUBE.get(), "Sulfur Cube");
        builder.add("entity.minecraft.sulfur_cube.content", "Contains: %s");
        builder.add("entity.minecraft.sulfur_cube.explosion_disabled", "Sulfur Cube explosions are disabled");

        builder.add(ModItems.SULFUR_CUBE_BUCKET.get(), "Bucket of Sulfur Cube");
        builder.add(ModItems.SULFUR_CUBE_SPAWN_EGG.get(), "Sulfur Cube Spawn Egg");

        builder.add("subtitles.entity.sulfur_cube.absorb", "Sulfur Cube full");
        builder.add("subtitles.entity.sulfur_cube.bounce", "Sulfur Cube bounces");
        builder.add("subtitles.entity.sulfur_cube.death", "Sulfur Cube dies");
        builder.add("subtitles.entity.sulfur_cube.eject", "Block removed");
        builder.add("subtitles.entity.sulfur_cube.hit", "Sulfur Cube hit");
        builder.add("subtitles.entity.sulfur_cube.hurt", "Sulfur Cube hurts");
        builder.add("subtitles.entity.sulfur_cube.push", "Sulfur Cube pushed");
        builder.add("subtitles.entity.sulfur_cube.jump", "Sulfur Cube bounces");

        builder.add("subtitles.entity.small_sulfur_cube.death", "Small Sulfur Cube dies");
        builder.add("subtitles.entity.small_sulfur_cube.eat", "Small Sulfur Cube puts on mass");
        builder.add("subtitles.entity.small_sulfur_cube.hurt", "Small Sulfur Cube hurts");
        builder.add("subtitles.entity.small_sulfur_cube.jump", "Small Sulfur Cube bounces");

        builder.add("subtitles.item.bucket.fill_sulfur_cube", "Sulfur Cube scooped");

        builder.add("subtitles.block.potent_sulfur.geyser_eruption", "Sulfur spring bursts");
        builder.add("subtitles.block.potent_sulfur.noxious_gas", "Noxious gas appears");

        builder.add(ModAttributes.AIR_DRAG_MODIFIER, "Air Drag Modifier");
        builder.add(ModAttributes.BOUNCINESS, "Bounciness");
        builder.add(ModAttributes.FRICTION_MODIFIER, "Friction Modifier");

        builder.add("item.minecraft.music_disc_bounce", "Music Disc");
        builder.add("item.minecraft.music_disc_bounce.desc", "fingerspit - Bounce");

        builder.add("jukebox_song.minecraft.bounce", "fingerspit - Bounce");

        builder.add("death.attack.sulfurCubeHot", "%1$s died because not just the floor is lava");
        builder.add("death.attack.sulfurCubeHot.player", "%2$s showed %1$s that not just the floor is lava");

        // Advancements
        builder.add("advancements.adventure.heart_transplanter.title", "Heart Transplanter");
        builder.add("advancements.adventure.heart_transplanter.description", "Place a Creaking Heart with the correct alignment between two Pale Oak Log blocks");

        builder.add("advancements.husbandry.whole_pack.title", "The Whole Pack");
        builder.add("advancements.husbandry.whole_pack.description", "Tame one of each Wolf variant");

        builder.add("advancements.husbandry.remove_wolf_armor.title", "Shear Brilliance");
        builder.add("advancements.husbandry.remove_wolf_armor.description", "Remove Wolf Armor from a Wolf using Shears");

        builder.add("advancements.husbandry.repair_wolf_armor.title", "Good as New");
        builder.add("advancements.husbandry.repair_wolf_armor.description", "Fully repair damaged Wolf Armor using Armadillo Scutes");

        builder.add("advancements.husbandry.place_dried_ghast_in_water.title", "Stay Hydrated!");
        builder.add("advancements.husbandry.place_dried_ghast_in_water.description", "Place a Dried Ghast block into water");

        builder.add("advancements.husbandry.uh_oh.title", "Uh Oh");
        builder.add("advancements.husbandry.uh_oh.description", "Have a Sulfur Cube absorb a TNT block");

        // Misc
        builder.add(ModEntityTypes.CUSHION.get(), "Cushion");
        builder.add("biome.minecraft.dappled_forest", "Dappled Forest");
        
        builder.add(ModBlocks.POPLAR_LOG.get(), "Poplar Log");
        builder.add(ModBlocks.STRIPPED_POPLAR_LOG.get(), "Stripped Poplar Log");
        builder.add(ModBlocks.POPLAR_WOOD.get(), "Poplar Wood");
        builder.add(ModBlocks.STRIPPED_POPLAR_WOOD.get(), "Stripped Poplar Wood");
        builder.add(ModBlocks.POPLAR_PLANKS.get(), "Poplar Planks");
        builder.add(ModBlocks.POPLAR_STAIRS.get(), "Poplar Stairs");
        builder.add(ModBlocks.POPLAR_SLAB.get(), "Poplar Slab");
        builder.add(ModBlocks.POPLAR_SIGN.getFirst().get(), "Poplar Sign");
        builder.add(ModBlocks.POPLAR_HANGING_SIGN.getFirst().get(), "Poplar Hanging Sign");
        builder.add(ModBlocks.POPLAR_BUTTON.get(), "Poplar Button");
        builder.add(ModBlocks.POPLAR_PRESSURE_PLATE.get(), "Poplar Pressure Plate");
        builder.add(ModBlocks.POPLAR_DOOR.get(), "Poplar Door");
        builder.add(ModBlocks.POPLAR_FENCE.get(), "Poplar Fence");
        builder.add(ModBlocks.POPLAR_FENCE_GATE.get(), "Poplar Fence Gate");
        builder.add(ModBlocks.POPLAR_TRAPDOOR.get(), "Poplar Trapdoor");
        builder.add(ModBlocks.POPLAR_SHELF.get(), "Poplar Shelf");
        builder.add(ModItems.POPLAR_BOAT.get(), "Poplar Boat");
        builder.add(ModItems.POPLAR_CHEST_BOAT.get(), "Poplar Chest Boat");
        builder.add(ModBlocks.RED_POPLAR_LEAVES.get(), "Red Poplar Leaves");
        builder.add(ModBlocks.ORANGE_POPLAR_LEAVES.get(), "Orange Poplar Leaves");
        builder.add(ModBlocks.YELLOW_POPLAR_LEAVES.get(), "Yellow Poplar Leaves");
        builder.add(ModBlocks.POPLAR_SAPLING.get(), "Poplar Sapling");
        builder.add(ModBlocks.POTTED_POPLAR_SAPLING.get(), "Potted Poplar Sapling");
        builder.add(ModBlocks.RED_SHRUB.get(), "Red Shrub");
        builder.add(ModBlocks.SHELF_MUSHROOM.get(), "Shelf Mushroom");
        builder.add(ModBlocks.STRAW_BED.get(), "Straw Bed");
        
        builder.add(ModBlocks.BLACK_WOOL_STAIRS.get(), "Black Wool Stairs");
        builder.add(ModBlocks.WHITE_WOOL_STAIRS.get(), "White Wool Stairs");
        builder.add(ModBlocks.GRAY_WOOL_STAIRS.get(), "Gray Wool Stairs");
        builder.add(ModBlocks.LIGHT_GRAY_WOOL_STAIRS.get(), "Light Gray Wool Stairs");
        builder.add(ModBlocks.LIGHT_BLUE_WOOL_STAIRS.get(), "Light Blue Wool Stairs");
        builder.add(ModBlocks.BLUE_WOOL_STAIRS.get(), "Blue Wool Stairs");
        builder.add(ModBlocks.CYAN_WOOL_STAIRS.get(), "Cyan Wool Stairs");
        builder.add(ModBlocks.YELLOW_WOOL_STAIRS.get(), "Yellow Wool Stairs");
        builder.add(ModBlocks.RED_WOOL_STAIRS.get(), "Red Wool Stairs");
        builder.add(ModBlocks.PURPLE_WOOL_STAIRS.get(), "Purple Wool Stairs");
        builder.add(ModBlocks.MAGENTA_WOOL_STAIRS.get(), "Magenta Wool Stairs");
        builder.add(ModBlocks.PINK_WOOL_STAIRS.get(), "Pink Wool Stairs");
        builder.add(ModBlocks.GREEN_WOOL_STAIRS.get(), "Green Wool Stairs");
        builder.add(ModBlocks.LIME_WOOL_STAIRS.get(), "Lime Wool Stairs");
        builder.add(ModBlocks.BROWN_WOOL_STAIRS.get(), "Brown Wool Stairs");
        builder.add(ModBlocks.ORANGE_WOOL_STAIRS.get(), "Orange Wool Stairs");
        
        builder.add(ModBlocks.BLACK_WOOL_SLAB.get(), "Black Wool Slab");
        builder.add(ModBlocks.WHITE_WOOL_SLAB.get(), "White Wool Slab");
        builder.add(ModBlocks.GRAY_WOOL_SLAB.get(), "Gray Wool Slab");
        builder.add(ModBlocks.LIGHT_GRAY_WOOL_SLAB.get(), "Light Gray Wool Slab");
        builder.add(ModBlocks.LIGHT_BLUE_WOOL_SLAB.get(), "Light Blue Wool Slab");
        builder.add(ModBlocks.BLUE_WOOL_SLAB.get(), "Blue Wool Slab");
        builder.add(ModBlocks.CYAN_WOOL_SLAB.get(), "Cyan Wool Slab");
        builder.add(ModBlocks.YELLOW_WOOL_SLAB.get(), "Yellow Wool Slab");
        builder.add(ModBlocks.RED_WOOL_SLAB.get(), "Red Wool Slab");
        builder.add(ModBlocks.PURPLE_WOOL_SLAB.get(), "Purple Wool Slab");
        builder.add(ModBlocks.MAGENTA_WOOL_SLAB.get(), "Magenta Wool Slab");
        builder.add(ModBlocks.PINK_WOOL_SLAB.get(), "Pink Wool Slab");
        builder.add(ModBlocks.GREEN_WOOL_SLAB.get(), "Green Wool Slab");
        builder.add(ModBlocks.LIME_WOOL_SLAB.get(), "Lime Wool Slab");
        builder.add(ModBlocks.BROWN_WOOL_SLAB.get(), "Brown Wool Slab");
        builder.add(ModBlocks.ORANGE_WOOL_SLAB.get(), "Orange Wool Slab");

        builder.add(ModBlocks.BLACK_CONCRETE_STAIRS.get(), "Black Concrete Stairs");
        builder.add(ModBlocks.WHITE_CONCRETE_STAIRS.get(), "White Concrete Stairs");
        builder.add(ModBlocks.GRAY_CONCRETE_STAIRS.get(), "Gray Concrete Stairs");
        builder.add(ModBlocks.LIGHT_GRAY_CONCRETE_STAIRS.get(), "Light Gray Concrete Stairs");
        builder.add(ModBlocks.LIGHT_BLUE_CONCRETE_STAIRS.get(), "Light Blue Concrete Stairs");
        builder.add(ModBlocks.BLUE_CONCRETE_STAIRS.get(), "Blue Concrete Stairs");
        builder.add(ModBlocks.CYAN_CONCRETE_STAIRS.get(), "Cyan Concrete Stairs");
        builder.add(ModBlocks.YELLOW_CONCRETE_STAIRS.get(), "Yellow Concrete Stairs");
        builder.add(ModBlocks.RED_CONCRETE_STAIRS.get(), "Red Concrete Stairs");
        builder.add(ModBlocks.PURPLE_CONCRETE_STAIRS.get(), "Purple Concrete Stairs");
        builder.add(ModBlocks.MAGENTA_CONCRETE_STAIRS.get(), "Magenta Concrete Stairs");
        builder.add(ModBlocks.PINK_CONCRETE_STAIRS.get(), "Pink Concrete Stairs");
        builder.add(ModBlocks.GREEN_CONCRETE_STAIRS.get(), "Green Concrete Stairs");
        builder.add(ModBlocks.LIME_CONCRETE_STAIRS.get(), "Lime Concrete Stairs");
        builder.add(ModBlocks.BROWN_CONCRETE_STAIRS.get(), "Brown Concrete Stairs");
        builder.add(ModBlocks.ORANGE_CONCRETE_STAIRS.get(), "Orange Concrete Stairs");

        builder.add(ModBlocks.BLACK_CONCRETE_SLAB.get(), "Black Concrete Slab");
        builder.add(ModBlocks.WHITE_CONCRETE_SLAB.get(), "White Concrete Slab");
        builder.add(ModBlocks.GRAY_CONCRETE_SLAB.get(), "Gray Concrete Slab");
        builder.add(ModBlocks.LIGHT_GRAY_CONCRETE_SLAB.get(), "Light Gray Concrete Slab");
        builder.add(ModBlocks.LIGHT_BLUE_CONCRETE_SLAB.get(), "Light Blue Concrete Slab");
        builder.add(ModBlocks.BLUE_CONCRETE_SLAB.get(), "Blue Concrete Slab");
        builder.add(ModBlocks.CYAN_CONCRETE_SLAB.get(), "Cyan Concrete Slab");
        builder.add(ModBlocks.YELLOW_CONCRETE_SLAB.get(), "Yellow Concrete Slab");
        builder.add(ModBlocks.RED_CONCRETE_SLAB.get(), "Red Concrete Slab");
        builder.add(ModBlocks.PURPLE_CONCRETE_SLAB.get(), "Purple Concrete Slab");
        builder.add(ModBlocks.MAGENTA_CONCRETE_SLAB.get(), "Magenta Concrete Slab");
        builder.add(ModBlocks.PINK_CONCRETE_SLAB.get(), "Pink Concrete Slab");
        builder.add(ModBlocks.GREEN_CONCRETE_SLAB.get(), "Green Concrete Slab");
        builder.add(ModBlocks.LIME_CONCRETE_SLAB.get(), "Lime Concrete Slab");
        builder.add(ModBlocks.BROWN_CONCRETE_SLAB.get(), "Brown Concrete Slab");
        builder.add(ModBlocks.ORANGE_CONCRETE_SLAB.get(), "Orange Concrete Slab");
        
        builder.add(ModItems.BLACK_CUSHION.get(), "Black Cushion");
        builder.add(ModItems.WHITE_CUSHION.get(), "White Cushion");
        builder.add(ModItems.GRAY_CUSHION.get(), "Gray Cushion");
        builder.add(ModItems.LIGHT_GRAY_CUSHION.get(), "Light Gray Cushion");
        builder.add(ModItems.LIGHT_BLUE_CUSHION.get(), "Light Blue Cushion");
        builder.add(ModItems.BLUE_CUSHION.get(), "Blue Cushion");
        builder.add(ModItems.CYAN_CUSHION.get(), "Cyan Cushion");
        builder.add(ModItems.YELLOW_CUSHION.get(), "Yellow Cushion");
        builder.add(ModItems.RED_CUSHION.get(), "Red Cushion");
        builder.add(ModItems.PURPLE_CUSHION.get(), "Purple Cushion");
        builder.add(ModItems.MAGENTA_CUSHION.get(), "Magenta Cushion");
        builder.add(ModItems.PINK_CUSHION.get(), "Pink Cushion");
        builder.add(ModItems.GREEN_CUSHION.get(), "Green Cushion");
        builder.add(ModItems.LIME_CUSHION.get(), "Lime Cushion");
        builder.add(ModItems.BROWN_CUSHION.get(), "Brown Cushion");
        builder.add(ModItems.ORANGE_CUSHION.get(), "Orange Cushion");
        
        builder.add("subtitles.entity.cushion.break", "Cushion breaks");
        builder.add("subtitles.entity.cushion.get_up", "Gets up from Cushion");
        builder.add("subtitles.entity.cushion.place", "Cushion placed");
        builder.add("subtitles.entity.cushion.sit", "Sits on Cushion");
        
        builder.add("subtitles.block.straw_bed.break_leave", "Straw Bed breaks");
        builder.add("subtitles.block.poplar_leaves.ambient", "Leaves rustling");
        builder.add("subtitles.block.shelf_mushroom.bounce", "Something bounces on a Shelf Mushroom");
        
        builder.add("filled_map.bamboo_camp_map", "Bamboo Camp Map");
        builder.add("filled_map.bamboo_jungle_abandoned_camp", "Bamboo Jungle Abandoned Camp Map");
        builder.add("filled_map.birch_forest_abandoned_camp", "Birch Forest Abandoned Camp Map");
        builder.add("filled_map.birch_forest_camp_map", "Birch Forest Camp Map");
        builder.add("filled_map.cherry_grove_abandoned_camp", "Cherry Grove Abandoned Camp Map");
        builder.add("filled_map.cherry_grove_camp_map", "Cherry Grove Camp Map");
        builder.add("filled_map.dappled_forest_abandoned_camp", "Dappled Forest Abandoned Camp Map");
        builder.add("filled_map.dappled_forest_camp_map", "Dappled Forest Camp Map");
        builder.add("filled_map.flower_forest_abandoned_camp", "Flower Forest Abandoned Camp Map");
        builder.add("filled_map.flower_forest_camp_map", "Flower Forest Camp Map");
        builder.add("filled_map.pale_garden_abandoned_camp", "Pale Garden Abandoned Camp Map");
        builder.add("filled_map.pale_garden_camp_map", "Pale Garden Camp Map");
        builder.add("filled_map.swamp_abandoned_camp", "Swamp Abandoned Camp Map");
        builder.add("filled_map.swamp_camp_map", "Swamp Camp Map");
        builder.add("filled_map.windswept_forest_abandoned_camp", "Windswept Forest Abandoned Camp Map");
        builder.add("filled_map.windswept_forest_camp_map", "Windswept Forest Camp Map");
        
        // Bundled Tabs
        builder.add("bundled_tab.bundles_of_bravery.title", "Bundles of Bravery");
        builder.add("bundled_tab.the_garden_awakens.title", "The Garden Awakens");
        builder.add("bundled_tab.spring_to_life.title", "Spring to Life");
        builder.add("bundled_tab.chase_the_skies.title", "Chase The Skies");
        builder.add("bundled_tab.hot_as_lava.title", "Hot as Lava");
        builder.add("bundled_tab.copper_age.title", "Copper Age");
        builder.add("bundled_tab.mounts_of_mayhem.title", "Mounts of Mayhem");
        builder.add("bundled_tab.chaos_cubed.title", "Chaos Cubed");
        builder.add("bundled_tab.wilderness_bound.title", "Wilderness Bound");
        builder.add("bundled_tab.miscellaneous.title", "Miscellaneous");
        
        // Options
        builder.add("options.music_frequency", "Music Frequency");
        builder.add("options.music_frequency.constant", "Constant");
        builder.add("options.music_frequency.default", "Default");
        builder.add("options.music_frequency.frequent", "Frequent");
        builder.add("options.music_frequency.tooltip", "Changes how frequently music plays while in a game world.");

        builder.add("options.musicToast", "Music Toast");
        builder.add("options.musicToast.never", "Never");
        builder.add("options.musicToast.never.tooltip", "No music toast is shown.");
        builder.add("options.musicToast.pauseMenu", "Pause Menu");
        builder.add("options.musicToast.pauseMenu.tooltip", "A music toast is constantly displayed in the in-game pause menu while a song is playing.");
        builder.add("options.musicToast.pauseMenuAndToast", "Pause Menu and Toast");
        builder.add("options.musicToast.pauseMenuAndToast.tooltip", "Displays a toast when a song starts playing. The same toast is constantly displayed in the in-game pause menu while a song is playing.");
        
        // Music
        builder.add("music.game.a_familiar_room", "Aaron Cherof - A Familiar Room");
        builder.add("music.game.an_ordinary_day", "Kumi Tanioka - An Ordinary Day");
        builder.add("music.game.ancestry", "Lena Raine - Ancestry");
        builder.add("music.game.below_and_above", "Amos Roddy - Below and Above");
        builder.add("music.game.broken_clocks", "Amos Roddy - Broken Clocks");
        builder.add("music.game.bromeliad", "Aaron Cherof - Bromeliad");
        builder.add("music.game.clark", "C418 - Clark");
        builder.add("music.game.comforting_memories", "Kumi Tanioka - Comforting Memories");
        builder.add("music.game.creative.aria_math", "C418 - Aria Math");
        builder.add("music.game.creative.biome_fest", "C418 - Biome Fest");
        builder.add("music.game.creative.blind_spots", "C418 - Blind Spots");
        builder.add("music.game.creative.dreiton", "C418 - Dreiton");
        builder.add("music.game.creative.haunt_muskie", "C418 - Haunt Muskie");
        builder.add("music.game.creative.taswell", "C418 - Taswell");
        builder.add("music.game.crescent_dunes", "Aaron Cherof - Crescent Dunes");
        builder.add("music.game.danny", "C418 - Danny");
        builder.add("music.game.deeper", "Lena Raine - Deeper");
        builder.add("music.game.dry_hands", "C418 - Dry Hands");
        builder.add("music.game.ebb", "fingerspit - Ebb");
        builder.add("music.game.echo_in_the_wind", "Aaron Cherof - Echo in the Wind");
        builder.add("music.game.eld_unknown", "Lena Raine - Eld Unknown");
        builder.add("music.game.end.alpha", "C418 - Alpha");
        builder.add("music.game.end.boss", "C418 - Boss");
        builder.add("music.game.end.the_end", "C418 - The End");
        builder.add("music.game.endless", "Lena Raine - Endless");
        builder.add("music.game.featherfall", "Aaron Cherof - Featherfall");
        builder.add("music.game.fireflies", "Amos Roddy - Fireflies");
        builder.add("music.game.floating_dream", "Kumi Tanioka - Floating Dream");
        builder.add("music.game.haggstrom", "C418 - Haggstrom");
        builder.add("music.game.home", "fingerspit - Home");
        builder.add("music.game.infinite_amethyst", "Lena Raine - Infinite Amethyst");
        builder.add("music.game.key", "C418 - Key");
        builder.add("music.game.komorebi", "Kumi Tanioka - komorebi");
        builder.add("music.game.left_to_bloom", "Lena Raine - Left to Bloom");
        builder.add("music.game.lilypad", "Amos Roddy - Lilypad");
        builder.add("music.game.living_mice", "C418 - Living Mice");
        builder.add("music.game.memories", "fingerspit - Memories");
        builder.add("music.game.mice_on_venus", "C418 - Mice on Venus");
        builder.add("music.game.minecraft", "C418 - Minecraft");
        builder.add("music.game.nether.ballad_of_the_cats", "C418 - Ballad of the Cats");
        builder.add("music.game.nether.concrete_halls", "C418 - Concrete Halls");
        builder.add("music.game.nether.crimson_forest.chrysopoeia", "Lena Raine - Chrysopoeia");
        builder.add("music.game.nether.dead_voxel", "C418 - Dead Voxel");
        builder.add("music.game.nether.nether_wastes.rubedo", "Lena Raine - Rubedo");
        builder.add("music.game.nether.soulsand_valley.so_below", "Lena Raine - So Below");
        builder.add("music.game.nether.warmth", "C418 - Warmth");
        builder.add("music.game.nightly", "fingerspit - Nightly");
        builder.add("music.game.one_more_day", "Lena Raine - One More Day");
        builder.add("music.game.os_piano", "Amos Roddy - O's Piano");
        builder.add("music.game.oxygene", "C418 - Oxygène");
        builder.add("music.game.pokopoko", "Kumi Tanioka - pokopoko");
        builder.add("music.game.puzzlebox", "Aaron Cherof - Puzzlebox");
        builder.add("music.game.shores", "fingerspit - Shores");
        builder.add("music.game.stand_tall", "Lena Raine - Stand Tall");
        builder.add("music.game.subwoofer_lullaby", "C418 - Subwoofer Lullaby");
        builder.add("music.game.swamp.aerie", "Lena Raine - Aerie");
        builder.add("music.game.swamp.firebugs", "Lena Raine - Firebugs");
        builder.add("music.game.swamp.labyrinthine", "Lena Raine - Labyrinthine");
        builder.add("music.game.sweden", "C418 - Sweden");
        builder.add("music.game.watcher", "Aaron Cherof - Watcher");
        builder.add("music.game.water.axolotl", "C418 - Axolotl");
        builder.add("music.game.water.dragon_fish", "C418 - Dragon Fish");
        builder.add("music.game.water.shuniji", "C418 - Shuniji");
        builder.add("music.game.wending", "Lena Raine - Wending");
        builder.add("music.game.wet_hands", "C418 - Wet Hands");
        builder.add("music.game.yakusoku", "Kumi Tanioka - yakusoku");
        
        builder.add("music.menu.beginning_2", "C418 - Beginning 2");
        builder.add("music.menu.floating_trees", "C418 - Floating Trees");
        builder.add("music.menu.moog_city_2", "C418 - Moog City 2");
        builder.add("music.menu.mutation", "C418 - Mutation");
    }
}