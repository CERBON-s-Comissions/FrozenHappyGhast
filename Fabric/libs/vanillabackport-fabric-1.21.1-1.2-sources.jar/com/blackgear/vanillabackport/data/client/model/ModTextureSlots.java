package com.blackgear.vanillabackport.data.client.model;

import com.blackgear.vanillabackport.core.mixin.client.access.TextureSlotAccessor;
import net.minecraft.class_4945;

public class ModTextureSlots {
    public static final class_4945 TENTACLES = TextureSlotAccessor.create("tentacles");
    public static final class_4945 BARS = TextureSlotAccessor.create("bars");
}