package com.blackgear.vanillabackport.data.server.tags;

import com.blackgear.vanillabackport.common.registries.ModBlocks;
import com.blackgear.vanillabackport.core.data.tags.ModBlockTags;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_2246;
import net.minecraft.class_3481;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;

public class BlockTagGenerator extends FabricTagProvider.BlockTagProvider {
    public BlockTagGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected void method_10514(class_7225.class_7874 provider) {
        // Wood-related block tags
        addWoodRelatedTags();

        // Building blocks
        addBuildingBlockTags();

        // Nature blocks
        addNatureTags();

        // Tool mineable blocks
        addToolTags();

        // Special behavior tags
        addSpecialBehaviorTags();

        this.getOrCreateTagBuilder(ModBlockTags.HAPPY_GHAST_AVOIDS)
            .add(
                class_2246.field_16999,
                class_2246.field_10029,
                class_2246.field_10606,
                class_2246.field_10092,
                class_2246.field_10036,
                class_2246.field_28048
            );
    }

    private void addWoodRelatedTags() {
        this.getOrCreateTagBuilder(class_3481.field_15471)
            .add(ModBlocks.PALE_OAK_PLANKS.get());

        this.getOrCreateTagBuilder(class_3481.field_15499)
            .add(ModBlocks.PALE_OAK_BUTTON.get());

        this.getOrCreateTagBuilder(class_3481.field_15494)
            .add(ModBlocks.PALE_OAK_DOOR.get());

        this.getOrCreateTagBuilder(class_3481.field_15502)
            .add(ModBlocks.PALE_OAK_STAIRS.get());

        this.getOrCreateTagBuilder(class_3481.field_15468)
            .add(ModBlocks.PALE_OAK_SLAB.get());

        this.getOrCreateTagBuilder(class_3481.field_17619)
            .add(ModBlocks.PALE_OAK_FENCE.get());

        this.getOrCreateTagBuilder(class_3481.field_25147)
            .add(ModBlocks.PALE_OAK_FENCE_GATE.get());

        this.getOrCreateTagBuilder(class_3481.field_15477)
            .add(ModBlocks.PALE_OAK_PRESSURE_PLATE.get());

        this.getOrCreateTagBuilder(class_3481.field_15491)
            .add(ModBlocks.PALE_OAK_TRAPDOOR.get());

        this.getOrCreateTagBuilder(class_3481.field_15472)
            .add(ModBlocks.PALE_OAK_SIGN.getFirst().get());

        this.getOrCreateTagBuilder(class_3481.field_15492)
            .add(ModBlocks.PALE_OAK_SIGN.getSecond().get());

        this.getOrCreateTagBuilder(class_3481.field_40103)
            .add(ModBlocks.PALE_OAK_HANGING_SIGN.getFirst().get());

        this.getOrCreateTagBuilder(class_3481.field_40104)
            .add(ModBlocks.PALE_OAK_HANGING_SIGN.getSecond().get());

        this.getOrCreateTagBuilder(class_3481.field_23210)
            .method_26792(ModBlockTags.PALE_OAK_LOGS);

        this.getOrCreateTagBuilder(class_3481.field_39030)
            .add(ModBlocks.PALE_OAK_LOG.get());

        this.getOrCreateTagBuilder(ModBlockTags.PALE_OAK_LOGS)
            .add(ModBlocks.PALE_OAK_LOG.get())
            .add(ModBlocks.PALE_OAK_WOOD.get())
            .add(ModBlocks.STRIPPED_PALE_OAK_LOG.get())
            .add(ModBlocks.STRIPPED_PALE_OAK_WOOD.get());
    }

    private void addBuildingBlockTags() {
        this.getOrCreateTagBuilder(class_3481.field_15459)
            .add(ModBlocks.RESIN_BRICK_STAIRS.get());

        this.getOrCreateTagBuilder(class_3481.field_15469)
            .add(ModBlocks.RESIN_BRICK_SLAB.get());

        this.getOrCreateTagBuilder(class_3481.field_15504)
            .add(ModBlocks.RESIN_BRICK_WALL.get());
    }

    private void addNatureTags() {
        this.getOrCreateTagBuilder(class_3481.field_15503)
            .add(ModBlocks.PALE_OAK_LEAVES.get());

        this.getOrCreateTagBuilder(class_3481.field_33714)
            .add(ModBlocks.PALE_OAK_LEAVES.get());

        this.getOrCreateTagBuilder(class_3481.field_15462)
            .add(ModBlocks.PALE_OAK_SAPLING.get());

        this.getOrCreateTagBuilder(class_3481.field_29822)
            .add(ModBlocks.PALE_MOSS_BLOCK.get());

        this.getOrCreateTagBuilder(class_3481.field_20339)
            .add(ModBlocks.OPEN_EYEBLOSSOM.get())
            .add(ModBlocks.CLOSED_EYEBLOSSOM.get());

        this.getOrCreateTagBuilder(class_3481.field_15470)
            .add(ModBlocks.POTTED_OPEN_EYEBLOSSOM.get())
            .add(ModBlocks.POTTED_CLOSED_EYEBLOSSOM.get())
            .add(ModBlocks.POTTED_PALE_OAK_SAPLING.get());
    }

    private void addToolTags() {
        this.getOrCreateTagBuilder(class_3481.field_33713)
            .add(ModBlocks.CREAKING_HEART.get());

        this.getOrCreateTagBuilder(class_3481.field_33714)
            .add(ModBlocks.PALE_MOSS_BLOCK.get())
            .add(ModBlocks.PALE_MOSS_CARPET.get());

        this.getOrCreateTagBuilder(class_3481.field_33715)
            .add(ModBlocks.RESIN_BRICKS.get())
            .add(ModBlocks.RESIN_BRICK_SLAB.get())
            .add(ModBlocks.RESIN_BRICK_WALL.get())
            .add(ModBlocks.RESIN_BRICK_STAIRS.get())
            .add(ModBlocks.CHISELED_RESIN_BRICKS.get());
    }

    private void addSpecialBehaviorTags() {
        this.getOrCreateTagBuilder(class_3481.field_44470)
            .add(ModBlocks.PALE_MOSS_CARPET.get());

        this.getOrCreateTagBuilder(class_3481.field_42607)
            .add(ModBlocks.PALE_MOSS_BLOCK.get());

        this.getOrCreateTagBuilder(class_3481.field_43170)
            .add(ModBlocks.PALE_MOSS_CARPET.get())
            .add(ModBlocks.RESIN_CLUMP.get());
    }
}