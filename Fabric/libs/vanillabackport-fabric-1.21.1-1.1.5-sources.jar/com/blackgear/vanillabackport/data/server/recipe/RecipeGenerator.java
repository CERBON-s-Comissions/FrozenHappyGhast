package com.blackgear.vanillabackport.data.server.recipe;

import com.blackgear.vanillabackport.common.registries.ModBlocks;
import com.blackgear.vanillabackport.common.registries.ModItems;
import com.blackgear.vanillabackport.core.data.tags.ModItemTags;
import com.blackgear.vanillabackport.data.client.BlockFamilies;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_1935;
import net.minecraft.class_2246;
import net.minecraft.class_2447;
import net.minecraft.class_2454;
import net.minecraft.class_5794;
import net.minecraft.class_7225;
import net.minecraft.class_7699;
import net.minecraft.class_7701;
import net.minecraft.class_7800;
import net.minecraft.class_8790;
import java.util.concurrent.CompletableFuture;

public class RecipeGenerator extends FabricRecipeProvider {
    public RecipeGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    public void method_10419(class_8790 output) {
        BlockFamilies.getAllFamilies()
            .filter(class_5794::method_33478)
            .forEach(family -> method_33535(output, family, class_7699.method_45398(class_7701.field_40177)));
        method_24475(output, ModBlocks.PALE_OAK_PLANKS.get(), ModItemTags.PALE_OAK_LOGS, 4);
        method_24476(output, ModBlocks.PALE_OAK_WOOD.get(), ModBlocks.PALE_OAK_LOG.get());
        method_24476(output, ModBlocks.STRIPPED_PALE_OAK_WOOD.get(), ModBlocks.STRIPPED_PALE_OAK_LOG.get());
        method_24478(output, ModItems.PALE_OAK_BOAT.get(), ModBlocks.PALE_OAK_PLANKS.get());
        method_42754(output, ModItems.PALE_OAK_CHEST_BOAT.get(), ModItems.PALE_OAK_BOAT.get());
        method_46208(output, ModBlocks.PALE_OAK_HANGING_SIGN.getFirst().get(), ModBlocks.STRIPPED_PALE_OAK_LOG.get());
        method_24885(output, ModBlocks.PALE_MOSS_CARPET.get(), ModBlocks.PALE_MOSS_BLOCK.get());

        method_36444(output, class_1802.field_8492, ModBlocks.OPEN_EYEBLOSSOM.get(), "orange_dye");
        method_36444(output, class_1802.field_8298, ModBlocks.CLOSED_EYEBLOSSOM.get(), "gray_dye");

        method_46209(output, class_7800.field_40634, ModBlocks.RESIN_BRICKS.get(), ModItems.RESIN_BRICK.get());
        method_36325(output, class_7800.field_40642, ModBlocks.RESIN_CLUMP.get(), class_7800.field_40634, ModBlocks.RESIN_BLOCK.get());
        shaped(class_7800.field_40642, ModBlocks.CREAKING_HEART.get())
            .method_10434('R', ModBlocks.RESIN_BLOCK.get())
            .method_10434('L', ModBlocks.PALE_OAK_LOG.get())
            .method_10439(" L ")
            .method_10439(" R ")
            .method_10439(" L ")
            .method_10429("has_resin_block", method_10426(ModBlocks.RESIN_BLOCK.get()))
            .method_10431(output);
        class_2454.method_17802(class_1856.method_8091(ModBlocks.RESIN_CLUMP.get()), class_7800.field_40642, ModItems.RESIN_BRICK.get(), 0.1f, 200)
            .method_10469("has_resin_clump", method_10426(ModBlocks.RESIN_CLUMP.get()))
            .method_10431(output);
        method_33715(output, class_7800.field_40634, ModBlocks.RESIN_BRICK_SLAB.get(), ModBlocks.RESIN_BRICKS.get(), 2);
        method_33717(output, class_7800.field_40634, ModBlocks.RESIN_BRICK_STAIRS.get(), ModBlocks.RESIN_BRICKS.get());
        method_33717(output, class_7800.field_40634, ModBlocks.RESIN_BRICK_WALL.get(), ModBlocks.RESIN_BRICKS.get());
        method_33717(output, class_7800.field_40634, ModBlocks.CHISELED_RESIN_BRICKS.get(), ModBlocks.RESIN_BRICKS.get());

        this.dryGhast(output, ModBlocks.DRIED_GHAST.get());

        this.harness(output, ModItems.WHITE_HARNESS.get(), class_2246.field_10446);
        this.harness(output, ModItems.ORANGE_HARNESS.get(), class_2246.field_10095);
        this.harness(output, ModItems.MAGENTA_HARNESS.get(), class_2246.field_10215);
        this.harness(output, ModItems.LIGHT_BLUE_HARNESS.get(), class_2246.field_10294);
        this.harness(output, ModItems.YELLOW_HARNESS.get(), class_2246.field_10490);
        this.harness(output, ModItems.LIME_HARNESS.get(), class_2246.field_10028);
        this.harness(output, ModItems.PINK_HARNESS.get(), class_2246.field_10459);
        this.harness(output, ModItems.GRAY_HARNESS.get(), class_2246.field_10423);
        this.harness(output, ModItems.LIGHT_GRAY_HARNESS.get(), class_2246.field_10222);
        this.harness(output, ModItems.CYAN_HARNESS.get(), class_2246.field_10619);
        this.harness(output, ModItems.PURPLE_HARNESS.get(), class_2246.field_10259);
        this.harness(output, ModItems.BLUE_HARNESS.get(), class_2246.field_10514);
        this.harness(output, ModItems.BROWN_HARNESS.get(), class_2246.field_10113);
        this.harness(output, ModItems.GREEN_HARNESS.get(), class_2246.field_10170);
        this.harness(output, ModItems.RED_HARNESS.get(), class_2246.field_10314);
        this.harness(output, ModItems.BLACK_HARNESS.get(), class_2246.field_10146);

        shaped(class_7800.field_40639, class_1802.field_8175)
            .method_10434('X', class_1802.field_8745)
            .method_10434('#', class_1802.field_8620)
            .method_10439(" X ")
            .method_10439("X#X")
            .method_10429("has_leather", method_10426(class_1802.field_8745))
            .method_10431(output);
        shaped(class_7800.field_40638, class_1802.field_8719, 2)
            .method_10434('~', class_1802.field_8276)
            .method_10439("~~ ")
            .method_10439("~~ ")
            .method_10439("  ~")
            .method_10429("has_string", method_10426(class_1802.field_8276))
            .method_10431(output);
    }

    public static class_2447 shaped(class_7800 category, class_1935 entry) {
        return class_2447.method_10437(category, entry);
    }

    public static class_2447 shaped(class_7800 category, class_1935 entry, int amount) {
        return class_2447.method_10436(category, entry, amount);
    }

    private void dryGhast(class_8790 output, class_1935 ghast) {
        class_2447.method_10437(class_7800.field_40634, ghast)
            .method_10434('#', class_1802.field_8070)
            .method_10434('X', class_1802.field_8067)
            .method_10439("###")
            .method_10439("#X#")
            .method_10439("###")
            .method_10435("dry_ghast")
            .method_10429(method_32807(class_1802.field_8070), method_10426(class_1802.field_8070))
            .method_10431(output);
    }

    private void harness(class_8790 output, class_1935 harness, class_1935 carpet) {
        class_2447.method_10437(class_7800.field_40637, harness)
            .method_10434('#', carpet)
            .method_10434('G', class_1802.field_8280)
            .method_10434('L', class_1802.field_8745)
            .method_10439("LLL")
            .method_10439("G#G")
            .method_10435("harness")
            .method_10429("has_dried_ghast", method_10426(ModBlocks.DRIED_GHAST.get()))
            .method_10431(output);
    }
}