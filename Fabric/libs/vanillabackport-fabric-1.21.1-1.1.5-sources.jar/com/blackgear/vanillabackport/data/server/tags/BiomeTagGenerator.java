package com.blackgear.vanillabackport.data.server.tags;

import com.blackgear.vanillabackport.common.registries.ModBiomes;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_1959;
import net.minecraft.class_2474;
import net.minecraft.class_6908;
import net.minecraft.class_7225;
import net.minecraft.class_7784;
import net.minecraft.class_7924;

public class BiomeTagGenerator extends class_2474<class_1959> {
    public BiomeTagGenerator(class_7784 output, CompletableFuture<class_7225.class_7874> lookupProvider) {
        super(output, class_7924.field_41236, lookupProvider);
    }

    @Override
    protected void method_10514(class_7225.class_7874 provider) {
        this.method_10512(class_6908.field_36517).method_46835(ModBiomes.PALE_GARDEN);
        this.method_10512(class_6908.field_36501).method_46835(ModBiomes.PALE_GARDEN);
        this.method_10512(class_6908.field_37395).method_46835(ModBiomes.PALE_GARDEN);
        this.method_10512(class_6908.field_37393).method_46835(ModBiomes.PALE_GARDEN);
    }
}