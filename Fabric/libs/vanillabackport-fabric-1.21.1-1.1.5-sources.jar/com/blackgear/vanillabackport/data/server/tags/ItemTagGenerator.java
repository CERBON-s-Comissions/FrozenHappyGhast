package com.blackgear.vanillabackport.data.server.tags;

import com.blackgear.vanillabackport.common.registries.ModBlocks;
import com.blackgear.vanillabackport.common.registries.ModItems;
import com.blackgear.vanillabackport.core.data.tags.ModItemTags;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_1802;
import net.minecraft.class_3489;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;

public class ItemTagGenerator extends FabricTagProvider.ItemTagProvider {
    public ItemTagGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected void method_10514(class_7225.class_7874 provider) {
        // Wood-related block tags
        addWoodRelatedTags();

        // Building blocks
        addBuildingBlockTags();

        // Nature blocks
        addNatureTags();

        this.getOrCreateTagBuilder(class_3489.field_41891)
            .add(ModItems.RESIN_BRICK.get());

        this.getOrCreateTagBuilder(ModItemTags.HARNESSES)
            .add(
                ModItems.WHITE_HARNESS.get(),
                ModItems.ORANGE_HARNESS.get(),
                ModItems.MAGENTA_HARNESS.get(),
                ModItems.LIGHT_BLUE_HARNESS.get(),
                ModItems.YELLOW_HARNESS.get(),
                ModItems.LIME_HARNESS.get(),
                ModItems.PINK_HARNESS.get(),
                ModItems.GRAY_HARNESS.get(),
                ModItems.LIGHT_GRAY_HARNESS.get(),
                ModItems.CYAN_HARNESS.get(),
                ModItems.PURPLE_HARNESS.get(),
                ModItems.BLUE_HARNESS.get(),
                ModItems.BROWN_HARNESS.get(),
                ModItems.GREEN_HARNESS.get(),
                ModItems.RED_HARNESS.get(),
                ModItems.BLACK_HARNESS.get()
            );
        this.getOrCreateTagBuilder(ModItemTags.HAPPY_GHAST_FOOD).add(class_1802.field_8543);
        this.getOrCreateTagBuilder(ModItemTags.HAPPY_GHAST_TEMPT_ITEMS)
            .method_26792(ModItemTags.HAPPY_GHAST_FOOD)
            .method_26792(ModItemTags.HARNESSES);
    }

    private void addWoodRelatedTags() {
        this.getOrCreateTagBuilder(class_3489.field_15537)
            .add(ModBlocks.PALE_OAK_PLANKS.get().method_8389());

        this.getOrCreateTagBuilder(class_3489.field_15555)
            .add(ModBlocks.PALE_OAK_BUTTON.get().method_8389());

        this.getOrCreateTagBuilder(class_3489.field_15552)
            .add(ModBlocks.PALE_OAK_DOOR.get().method_8389());

        this.getOrCreateTagBuilder(class_3489.field_15557)
            .add(ModBlocks.PALE_OAK_STAIRS.get().method_8389());

        this.getOrCreateTagBuilder(class_3489.field_15534)
            .add(ModBlocks.PALE_OAK_SLAB.get().method_8389());

        this.getOrCreateTagBuilder(class_3489.field_17620)
            .add(ModBlocks.PALE_OAK_FENCE.get().method_8389());

        this.getOrCreateTagBuilder(class_3489.field_40858)
            .add(ModBlocks.PALE_OAK_FENCE_GATE.get().method_8389());

        this.getOrCreateTagBuilder(class_3489.field_15540)
            .add(ModBlocks.PALE_OAK_PRESSURE_PLATE.get().method_8389());

        this.getOrCreateTagBuilder(class_3489.field_15550)
            .add(ModBlocks.PALE_OAK_TRAPDOOR.get().method_8389());

        this.getOrCreateTagBuilder(class_3489.field_15533)
            .add(ModBlocks.PALE_OAK_SIGN.getFirst().get().method_8389());

        this.getOrCreateTagBuilder(class_3489.field_40108)
            .add(ModBlocks.PALE_OAK_HANGING_SIGN.getFirst().get().method_8389());

        this.getOrCreateTagBuilder(class_3489.field_23212)
            .method_26792(ModItemTags.PALE_OAK_LOGS);

        this.getOrCreateTagBuilder(ModItemTags.PALE_OAK_LOGS)
            .add(ModBlocks.PALE_OAK_LOG.get().method_8389())
            .add(ModBlocks.PALE_OAK_WOOD.get().method_8389())
            .add(ModBlocks.STRIPPED_PALE_OAK_LOG.get().method_8389())
            .add(ModBlocks.STRIPPED_PALE_OAK_WOOD.get().method_8389());

        this.getOrCreateTagBuilder(class_3489.field_15536)
            .add(ModItems.PALE_OAK_BOAT.get());

        this.getOrCreateTagBuilder(class_3489.field_38080)
            .add(ModItems.PALE_OAK_CHEST_BOAT.get());
    }

    private void addBuildingBlockTags() {
        this.getOrCreateTagBuilder(class_3489.field_15526)
            .add(ModBlocks.RESIN_BRICK_STAIRS.get().method_8389());

        this.getOrCreateTagBuilder(class_3489.field_15535)
            .add(ModBlocks.RESIN_BRICK_SLAB.get().method_8389());

        this.getOrCreateTagBuilder(class_3489.field_15560)
            .add(ModBlocks.RESIN_BRICK_WALL.get().method_8389());
    }

    private void addNatureTags() {
        this.getOrCreateTagBuilder(class_3489.field_15558)
            .add(ModBlocks.PALE_OAK_LEAVES.get().method_8389());

        this.getOrCreateTagBuilder(class_3489.field_15528)
            .add(ModBlocks.PALE_OAK_SAPLING.get().method_8389());

        this.getOrCreateTagBuilder(class_3489.field_36269)
            .add(ModBlocks.PALE_MOSS_BLOCK.get().method_8389());

        this.getOrCreateTagBuilder(class_3489.field_20344)
            .add(ModBlocks.OPEN_EYEBLOSSOM.get().method_8389())
            .add(ModBlocks.CLOSED_EYEBLOSSOM.get().method_8389());
    }
}